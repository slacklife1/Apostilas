<?php

// ######################################
// ####     Shout  Version 2.1         ##
// ####    By:  HockeyGod, GrafxGuye   ##
// ####    and Two4Roughing            ##
// ####   http://www.cheesehole.net    ##
// ######################################

// You may freely distribute this script as long as you do not make any
// changes to the original code and this disclaimer stays intact.  
// This script copyright 2002 cheesehole.net 

// ################  Edit Variables     ######################

$datfile = "shout.txt";
// This is the name of text file where all 
// the text is stored.

// Simply include this file include("shout.txt"); where you want
// the text to appear in your page.


$MAX_LENGTH = 35;
// This is the max length of the user's entry.  you should
// also make your input box's maxlength the same number or smaller
//  Basically this is just for error checking and to make sure
// the script was called from the page, not by itself.

// #############  DO NOT EDIT BELOW THIS LINE  ################

$c = preg_replace("/</","&lt;",$c);
$c = preg_replace("/>/","&gt;",$c); 

$comfile = file($datfile);
if ($c != "") {
if (strlen($c) < $MAX_LENGTH) {
$fd = fopen ($datfile, "w");
$c = stripslashes($c);
fwrite ($fd, "<div style='width:112px; overflow:hidden'>>>$c</div>\n");
for ($i = 0; $i <=9; $i++) {
fwrite ($fd, $comfile[$i]);
}
}
fclose($fd);
}
Header("Location: $HTTP_REFERER");
?>
