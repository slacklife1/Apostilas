Shout version 2.1

By HockeyGod, GrafxGuye and Two4Roughing

Copyright 2002  http://www.cheesehole.net

Find more scripts by HockeyGod @ http://www.hockeygod.tk



INSTRUCTIONS:

1.  Make a file called shout.txt and upload it to your server.

	CHMOD this file to 777
2.  Open shout.php with a text editor and change the max length
    to however many characters you want to limit it to.

3.  Use either PHP or SSL to include shout.txt into your page where you want the text to show up.

4. Use the following html to submit text to the shout script.
   Be sure to change the maxlength to a number less than or equal to   the max that you set in the script.

<form method="POST" action="shout.php">
<input size="15" maxlength="25" type="text" name="c">
<input type="submit" value="Shout">
</form>



DISCLAIMER:

Cheesehole.net offers no warranty or help whatsoever.  Sorry that's what you get with free stuff.

You may distribute this script freely as long as the disclaimer  and code remain un-modified and this text file accompanies it.

All materials copyright 2002  http://www.cheesehole.net

