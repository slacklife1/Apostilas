<?php

   /**
    **  index.php -- Displays the main frameset
    **
    **  Copyright (c) 1999-2002 The SquirrelMail development team
    **  Licensed under the GNU GPL. For full terms see the file COPYING.
    **
    **  Redirects to the login page.
    **
    **  $Id: index.php,v 1.3 2002/02/06 20:12:56 philippe_mingo Exp $
    **/

   header("Location:../../../src/login.php\n\n");
   exit();

?>