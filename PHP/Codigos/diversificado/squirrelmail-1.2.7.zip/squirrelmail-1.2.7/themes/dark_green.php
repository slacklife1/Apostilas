<?php
   /** Author:       Jason Munro 
       Date:         June 10 2002
       Theme Name:   "Dark Green"
    **/

    global $color;
    $color[0]   = "#0a2801"; 
    $color[1]   = "#F88888";
    $color[2]   = "#ff7171";
    $color[3]   = "#0a2801";
    $color[4]   = "#000000";
    $color[5]   = "#0e3503";
    $color[6]   = "#D0D0D0";
    $color[7]   = "#cfcfa0";
    $color[8]   = "#D0D0D0";
    $color[9]   = "#0e3503";
    $color[10]  = "#0a2801";
    $color[11]  = "#AAAA44";
    $color[12]  = "#0a2801";
    $color[13]  = "#FF7733";
    $color[14]  = "#FF3377";
?>
