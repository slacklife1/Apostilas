<?php
setCookie("c_user_name", $user_name, time() + 2678400);
setCookie("c_chat_type", $chat_type, time() + 2678400);
setCookie("c_design", $design, time() + 2678400);

include("inc_common.php");
include("inc_user_class.php");
#check for nickname;
if ((strlen($user_name)<3) or (strlen($user_name)>15))
{
	$error_text ="$w_incorrect_nick<br><a href=\"index.php\">$w_try_again</a>";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}


if (ereg("[^_a-zA-Z0-9]", $user_name))
{
	$error_text ="$w_incorrect_nick<br><a href=\"index.php\">$w_try_again</a>";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}

$session = md5(uniqid(rand()));

#ban check
include($ld_engine_path."ban_check.php");
if (check_ban($user_name, $REMOTE_ADDR))
{
	$error_text=$w_banned;
	include($file_path."designes/".$design."/error_page.php"); 
	exit;
}

#???????????
if(!isset($c_user_color)) {$user_color=$default_color;}
else $user_color = $c_user_color;
$shower = "messages.php?session=$session";
if (!isset($chat_type)) $chat_type = $chat_types[0];
if (!in_array($chat_type, $chat_types)) $chat_type = $chat_types[0];

if ($chat_type=="tail") $shower = "$daemon_url?$session";
elseif ($chat_type=="reload") $shower = "messages.php?session=$session";
elseif ($chat_type=="php_tail") $shower = "tail.php?session=$session";
elseif ($chat_type=="js_tail") $shower = "js_frameset.php?session=$session";

$registered_user = 0;
$users = array();
include($ld_engine_path."voc_user_data.php");


include($engine_path."voc.php");

$messages_to_show = array();
if ($hi)
	$messages_to_show[] = time() . "\t<b>$w_rob_name</b>\t\t<font color=\"".$registered_colors[$default_color][1]."\">".str_replace("~", $user_name, $w_rob_login)."</font>\t$DefaultColorNum";


$toDay = date("jn");
$birthDay = $bDay.$bMon;
#$birthDay = date("jn",mktime(0,0,0,$bDay , $bMon, date("Y")));
if ($toDay == $birthDay)
	$messages_to_show[] = time() . "\t<b>$w_rob_name</b>\t\t<font color=\"".$registered_colors[$highlighted_color][1]."\">".str_replace("~", $user_name, $w_rob_hb)."<font>\t9";

include($engine_path."messages_put.php");

include($file_path."designes/".$design."/voc.php");
?>