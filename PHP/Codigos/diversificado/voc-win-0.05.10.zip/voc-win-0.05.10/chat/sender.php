<?php
include("inc_common.php");
include($engine_path."users_get_list.php");

if (!$exists) 
{
	$error_text = "$w_no_user";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}

//functions
function addFaces($mesg)
{
//return $mesg;
	global $total_pics, $max_images, $chat_url;
  $l = 0;
  $temp = "";
  for ($i = 0; $i < strlen($mesg); $i++)
    {
      $oi = $i;
      $ok = 1;
      if (($mesg[$i] == ':' || $mesg[$i] == '=' || $mesg[$i] == ';')  and ($mesg[$i-1] != 't' or $mesg[$i-5] != '&' ))
	{
	  $alt = "";
	  $brows = "normal";
	  if ($i >= 4)
	    {
	      if (($mesg[$i - 1] == ';') and ($mesg[$i - 2] == 't') and  ($mesg[$i - 4] == '&'))
		{
		  if ($mesg[$i - 3] == 'g')
		    {
			$brows = "mad";
			$alt = "&gt;"; /*Orig: $alt = "]";*/
		    }
		  elseif ($mesg[$i - 3] == 'l')
		    {
			$brows = "upset";
			$alt = "&lt;"; /*Orig = $alt="[";*/
		    }
		}
	    }
	  $prefix = "";
	  if ($mesg[$i] == ';')
	    {
		$prefix = "wink-";
		$alt .= ";";
	    }
	  else { $alt .= ":"; }
	  $i++;
	  if ($mesg[$i] == '^' || $mesg[$i] == '-' || $mesg[$i] == '\'')
	  {  $i++;  $alt.="-";}
	  $mouth = "";
//	  $z = strlen($alt);
//	  $alt[$z] = $mesg[$i-1];
/*	  $alt[$z + 1] = '\0'; */
	  if ($mesg[$i] == ')' || $mesg[$i] == 'D' || $mesg[$i] == ']')
	  { $mouth = "smile"; $alt .= ")";}
	  elseif ($mesg[$i] == '(')
	  { $mouth ="frown"; $alt .= "(";}
	  elseif ($mesg[$i] == '|')
	  {$mouth = "shy"; $alt .= "|";}
	  elseif ($mesg[$i] == 'P' || $mesg[$i] == 'p' || $mesg[$i] == '�' || $mesg[$i] == '�')
	  {$mouth = "tongue"; $alt .= "P";}
	  elseif ($mesg[$i] == 'O' || $mesg[$i] == 'o' || $mesg[$i] == '�' || $mesg[$i] == '�')
	  {$mouth = "amazed"; $alt .= "o";}
		if ($total_pics<$max_images)
		{
			if (strlen($mouth) != 0)
			{
				$ok = 0;
				$face = $prefix . $mouth . "-" . $brows;
				$face = "<img src=\"".$chat_url."faces/$face.gif\" alt=\"$alt\" width=16 height=16>";
				
				/*	      $temp[$l] = '\0'; */
				if (strcmp($brows, "normal") != 0)
				{ 
					$l = strlen ($temp) -4;
					$temp = substr($temp,0,$l); 
				}
					

	
				$temp .= $face;
				$total_pics++;
					//echo "debug: $total_pics $max_images";
					//		 }
					
					$l = strlen($temp);
					
					
			}
			else
			{
				$i = $oi;
				$ok = 1;
			}
		}
		else {$ok = 1;$i = $oi;$l = strlen($temp);}
	}
		
      if ($ok == 1)
	{
	  $temp .= $mesg[$i];
	  $l++;
/*	  $temp[$l] = '\0';*/
	}
    }
return $temp;
}

function addURLS($str)
{
  $temp = "";
  $l = 0;
  global $chat_url;
  for ($i = 0; $i < strlen($str); $i++)
    {
      if ($str[$i] == 'h' && $str[$i + 1] == 't' &&
          $str[$i + 2] == 't' && $str[$i + 3] == 'p' &&
          ($str[$i + 4] == ':' || $str[$i + 4] == ';') && $str[$i + 5] == '/' &&
          $str[$i + 6] == '/')
        {
	  if ($str[$i + 4] == ';')
	   { $str[$i + 4] = ':'; }
	  
          $url = substr($str, $i);

/*	    $min = strpos($url, " ", 0);
	    if (strpos($url, ",", 0)<$min) {$min = strpos($url, ",");}
	    if (strpos($url, "\"", 0)<$min) {$min = strpos($url, "\"");}
	    if (strpos($url, "&gt;", 0)<$min) {$min = strpos($url, "&gt;");}
	  
            $url = substr($url,0,$min);  
*/
          if (strchr($url, " ") != False)
          {  $url = substr($url,0,strpos($url, " "));  }
          if (strchr($url, ",") != False)
          {  $url = substr($url,0,strpos($url, ","));  }
          if (strchr($url, "\"") != False)
          {  $url = substr($url,0,strpos($url, "\""));  }
	  
          if (strstr($url, "&gt;") != False)
          {  $url = substr($url,0,strpos($url, "&gt;"));  }
	    //$temp2 = "<a href=\"".$chat_url."go.php?url=".str_replace("&","&amp;",$url)."\" target=_blank>$url</a>";
		//$temp2 = "<a href=\"".$chat_url."go.php?url=".$url."\" target=_blank>$url</a>";
		$temp2 = "<a href=\"".$chat_url."go.php?url=".urlencode($url)."\" target=_blank>$url</a>";
	    $temp .= $temp2;
          $i = $i + strlen($url) - 1;
          $l = strlen($temp);
        }
      else
        {
	  $temp .= $str[$i];
	  $l++;
        }
    }
  return $temp;
}
//end of functions


if (!isset($user_color)) {$user_color=$default_color;}
$user_color = intval($user_color);
if (($user_color < 0) or ($user_color >= count($registered_colors))) {$user_color=$default_color;}
SetCookie("c_user_color", $user_color, time() + 2678400);

$error_text = "";
$error = 0;
$total_pics = 0;
$messages_to_show = array();
if (!isset($mesg)){$mesg = "";}
$mesg = str_replace("\t","", $mesg);
$mesg = str_replace("\n","", $mesg);
if (!isset($whisper)) {$whisper = "";}


if ($mesg !="")
{
	if ($whisper != "")
	{
		for($i=0; $i<sizeof($users); $i++)
		{
			$data = explode("\t", $users[$i]);
			if ($data[0] == $whisper) 
			if($data[5] == 0) $rndNumTest=$data[1];
			else $rndNumTest = $whisper;
		}
			
		if ($rndNumTest == "")
		{
			$error_text .= $w_whisper_out."<br>\n";
			$error = 1;
		}
	}

	$converts = file($converts_file);
	$numOfImgPhrases = count($converts);
	for ($i=0;$i<$numOfImgPhrases;$i++)
	{
		list ($imgPhrase[$i], $imgURL[$i]) = explode("\t",$converts[$i]);
	}
	
	if (get_magic_quotes_gpc()) $mesg = stripslashes($mesg);
	
	if (strlen($mesg)>512)  
	{
		$error_text .= $w_too_long."<br>\n"; 
		$error = 1;
	}
	
	if (!$error)
	{
		$mesg = htmlspecialchars($mesg);
		$mesg = wordwrap($mesg, 75," ", 1);
		$mesg = addURLS($mesg);
		$mesg = addFaces($mesg);
		if ((substr_count($mesg,"**")+ substr_count($mesg,"**n")) <7)
		{
			$mesg = str_replace("**n","<br>",$mesg);
			$mesg = str_replace("**","<br>",$mesg);
		}
		for ($j=0; $j<$numOfImgPhrases; $j++)
		{
			$total_pics+=substr_count($mesg,$imgPhrase[$j]);
			if ($max_images+1 >= $total_pics)
				$mesg = str_replace($imgPhrase[$j], $imgURL[$j], $mesg);
		}
		
		#for old versions of PHP, which cannot use ===
		$test_mesg = " " . $mesg;
		
		$t_color = $registered_colors[$user_color][1];
		if (strpos($test_mesg, "/me ") == 1)
			$messages_to_show[] = time() . "\t\t\t<b>$user_name " . substr($mesg, 4) . "</b>\t$default_color";
		else 
			$messages_to_show[] = time() . "\t$user_name\t$rndNumTest\t<font color=$t_color>$mesg</font>\t$color";
		
		
		if (!$whisper)
		{
			$phrases = file($robotspeak_file);
			for ($i=0;$i<count($phrases); $i++)
			{
				$phrase = str_replace("\n","",$phrases[$i]);
				list($user_phrase, $robot_answer, $prob) = split("\t", $phrase);
				$user_phrase = htmlspecialchars($user_phrase);
				$robot_answer = htmlspecialchars($robot_answer);
				
				if (stristr($mesg, $user_phrase) != False)
				{
					if (rand(0, 10)>= (10-$prob))
					{
						$robot_answer = str_replace("~", $user_name, $robot_answer);
						$messages_to_show[] = time() . "\t<b>$w_rob_name</b>\t\t$robot_answer\t$default_color";
						//		$newMes = time() . "\tVoice\t\t$answer\t$DefaultColorNum";
						break;
					}
				}
			}
		}
		include($engine_path."messages_put.php");
	}
}

$out_users = array();

for ($i=0;$i<count($users);$i++)
{
	list($out_users[$i]["nickname"], $unused, $unused, $unused, $unused, $unused, $unused, $unused)
		= explode("\t", $users[$i]);
}

$total_users = count($out_users);

include($file_path."designes/".$design."/sender.php");

?>