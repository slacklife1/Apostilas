<?php
set_time_limit(0);
include("inc_common.php");
include($engine_path."users_get_list.php");

if (!$exists) 
{
	$error_text = "$w_no_user";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}

include($engine_path."messages_get_list.php");
include($engine_path."ignore_get.php");
$out_messages = array();

readfile($file_path."designes/".$design."/daemon_html_header.html");
flush();
$last_id = 0;
$total_messages = count($messages);
$start_at = ($total_messages > 10) ? ($total_messages-9) : 0;
$last_id = show_messages($last_id, $messages,$ignored_users,$start_at);

$abort_counter = 0;
while(1==1)
{
	$abort_counter++;
	sleep(2);
	include($engine_path."users_get_list.php");
	if (!$exists) 
	{
		echo  "$w_no_user";
		exit;
	}
	include($engine_path."messages_get_list.php");
	include($engine_path."ignore_get.php");
	$new_last_id = show_messages($last_id, $messages,$ignored_users);
	if ($new_last_id != $last_id) 
	{
		$abort_counter = 0;
		$last_id = $new_last_id;
	}
	if ($abort_counter>25) 
	{
		echo "<jk>";
		flush();
	}
	
}


function show_messages($last_id, $messages, $ignored_users,$start_at = 0)
{
	global $message_format, $private_message, $private_hidden,$w_whisper_to,$session,$user_name,$is_regist,$users,$w_unknown_user;
	$total_messages = count($messages);
	
	for ($i=$start_at;$i<$total_messages;$i++)
	{
		$to_out = "";
		#$color is not used anymore
		list($message_id,$mesTime,$fromNick,$private,$message,$color) = explode ("\t", $messages[$i]);
		if ($message_id > $last_id)
		{
			if(!isset($ignored_users[strtolower($fromNick)]))
			{
				if ($private == "")
				{
					$to_out = str_replace("[HOURS]",date("H",$mesTime),$message_format);
				}
				else
				{
					if (($private == $session) or (($private == $user_name) and ($is_regist)))
					{
						$to_out = str_replace("[HOURS]",date("H",$mesTime),$private_message);
						$private = $user_name;
					}
					elseif($fromNick == $user_name)
					{
						$toNick = $w_unknown_user;
						for($ttt=0; $ttt<count($users); $ttt++)
						{
							$data = explode("\t", $users[$ttt]);
							if (($data[1] == $private) or ($data[0] == $private)) {$toNick=$data[0];break;}
						}
						$private = $toNick;
						$to_out = str_replace("[HOURS]",date("H",$mesTime),$private_message);
					}
					else 
						$to_out = str_replace("[HOURS]",date("H",$mesTime),$private_hidden);
				}
				$to_out = str_replace("[MIN]",date("i",$mesTime),$to_out);
				$to_out = str_replace("[SEC]",date("s",$mesTime),$to_out);
				$to_out = str_replace("[NICK]",$fromNick,$to_out);
				$to_out = str_replace("[TO]",$private,$to_out);
				$to_out = str_replace("[PRIVATE]",$w_whisper_to,$to_out);
				$to_out = str_replace("[MESSAGE]",$message,$to_out);
				echo $to_out."<br><script>scroll(1,10000000)</script>\n";
				flush();
			}
		}
	}
	return $message_id;
}

?>
