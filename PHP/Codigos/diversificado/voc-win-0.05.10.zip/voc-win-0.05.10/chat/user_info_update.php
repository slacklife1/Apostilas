<?php
include("inc_common.php");
include($engine_path."users_get_list.php");

if (!$exists) 
{
	$error_text = "$w_no_user";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}
include("inc_user_class.php");
include($ld_engine_path."users_get_object.php");

$info_message = "";

if ( (!$passwd1) or ($passwd1 != $passwd2) )
	$info_message .=  "$w_pas_not_changed.<br>\n";
else 
{
	$info_message .= "$w_pas_changed.<br>\n"; 
	$current_user->password = $passwd1;
}
if ($showGroup1 == "on") $current_user->show_group_1=1; else $current_user->show_group_1 = 0;
if ($showGroup2 == "on") $current_user->show_group_2=1; else $current_user->show_group_2=0;


$pic_name = strtolower($current_user->nickname) . ".big.gif";
if (!file_exists($file_path."photos/$pic_name")) $pic_name="";
if ($pic_name == "")
{
	$pic_name = strtolower($current_user->nickname) . ".big.jpg";
	if (!file_exists($file_path."photos/$pic_name")) $pic_name="";
}
$big_picture = $pic_name;
$pic_name = strtolower($current_user->nickname) . ".gif";
if (!file_exists($file_path."photos/$pic_name")) $pic_name="";
if ($pic_name == "")
{
	$pic_name = strtolower($current_user->nickname) . ".jpg";
	if (!file_exists($file_path."photos/$pic_name")) $pic_name="";
}
$small_picture = $pic_name;


if (($big_photo_name != "" and $big_photo_name != "none") or $big_del == "on")
{
	if ($big_picture != "") @unlink($file_path."photos/".$big_picture);
}
if (($small_photo_name != "" and $small_photo_name != "none") or $sm_del == "on")
{
	if ($small_picture != "") @unlink($file_path."photos/".$small_picture);
}

#saving users photos
#not really good. 
#I have also version which uses GD-library
#but it's not clear for me now, should I include it here or not.
#'cause it's not easy to determine which gd-functions are supported by ISP
if ($big_photo_name != "" and $big_photo_name != "none")
{
	$newFileLocation = strtolower($current_user->nickname);
	$newFileExtensions = strtolower(substr($big_photo_name, strrpos($big_photo_name,'.')+1, strlen($big_photo_name)));
	$tmpName = $newFileLocation.".big.".$newFileExtensions;
	if ($newFileExtensions == "gif" or $newFileExtensions == "jpg")
		@move_uploaded_file ($big_photo, $file_path."photos/$tmpName");
}
if ($small_photo_name != "" and $small_photo_name != "none")
{
	$newFileLocation = strtolower($current_user->nickname);
	$newFileExtensions = strtolower(substr($small_photo_name, strrpos($small_photo_name,'.')+1, strlen($small_photo_name)));
	$tmpName = $newFileLocation.".".$newFileExtensions;
	if ($small_photo_size>4096) echo "too big file<br>\n";
	else
	{
		if ($newFileExtensions == "gif" or $newFileExtensions == "jpg")
			@move_uploaded_file ($small_photo, $file_path."photos/$tmpName");
	}
}

#for blank fields:
error_reporting(0);

if (get_magic_quotes_gpc())
{
	$current_user->surname = htmlspecialchars(stripslashes($surname));
	$current_user->firstname = htmlspecialchars(stripslashes($firstname));
	$current_user->city = htmlspecialchars(stripslashes($city));
	$current_user->about = htmlspecialchars(stripslashes($comments));
	$current_user->about = str_replace("\n","<br>", $current_user->about);
	$current_user->email = htmlspecialchars(stripslashes($email));
	$current_user->url = htmlspecialchars(stripslashes($url));
	$current_user->icquin = htmlspecialchars(stripslashes($icquin));
}
else
{
	$current_user->surname = htmlspecialchars($surname);
	$current_user->firstname = htmlspecialchars($firstname);
	$current_user->city = htmlspecialchars($city);
	$current_user->about = htmlspecialchars($comments);
	$current_user->about = str_replace("\n","<br>", $current_user->about);
	$current_user->email = htmlspecialchars($email);
	$current_user->url = htmlspecialchars($url);
	$current_user->icquin = htmlspecialchars($icquin);
}
$current_user->b_day = intval($day);
$current_user->b_month = intval($month);
$current_user->b_year = intval($year);
$current_user->sex = intval($sex);
error_reporting(15);
include($ld_engine_path."user_info_update.php");

include($file_path."designes/".$design."/user_info_update.php");
?>