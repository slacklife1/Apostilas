<?php
include("inc_common.php");
include($engine_path."users_get_list.php");

if (!$exists) 
{
	$error_text = "$w_no_user";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}

include("inc_user_class.php");
include($ld_engine_path."users_get_object.php");

$pic_name = strtolower($current_user->nickname) . ".big.gif";
if (!file_exists($file_path."photos/$pic_name")) $pic_name="";
if ($pic_name == "")
{
	$pic_name = strtolower($current_user->nickname) . ".big.jpg";
	if (!file_exists($file_path."photos/$pic_name")) $pic_name="";
}
$big_picture = $pic_name;
$pic_name = strtolower($current_user->nickname) . ".gif";
if (!file_exists($file_path."photos/$pic_name")) $pic_name="";
if ($pic_name == "")
{
	$pic_name = strtolower($current_user->nickname) . ".jpg";
	if (!file_exists($file_path."photos/$pic_name")) $pic_name="";
}
$small_picture = $pic_name;

include($file_path."designes/".$design."/user_info.php");
?>