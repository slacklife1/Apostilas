<?php
include("inc_common.php");
include($engine_path."users_get_list.php");

if (!$exists) 
{
	$error_text = "$w_no_user";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}

$board_operation = "view";
include($ld_engine_path."board_process_message.php");

include($file_path."designes/".$design."/board_view.php");
?>