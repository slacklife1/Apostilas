<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body bgcolor=white text=black link=orange vlink=yellow>
<font face=verdana size=-1>
Welcome at Voodoo Chat HelpFile.
<p>
You clicked 'help' in the menu of this chat and came to this site. If you're not a registered user then some of the possibilities in this chat are not activated.
</p>
<p>
<ul>
<li><font color="red">HELP</font> - This site
<li><font color="red">INF0 ABOUT USERS</font> - Here you find extensive information about a user, if he supplied it after registering. Fill in the name or use a wildcard, p.e. 'in*', it shows all users tahat start with 'in', p.e. inge, ingrid, ingeborg etc.
<li><font color="red">PICTURES</font> - Here you find the explanation of the use of smileys.
<li><font color="red">FEEDBACK</font> - Because I want to know if the chatmeets your expectations, you can supply me with information.
<li><font color="red">REGISTRATION</font> - Register and get more possibilities, like sending personal messages to other users without the other chatters see this. 
</ul>
</p>

<p>
If you register you get another possibility in the menu, <font color="red">MY INFO</font>, here you can fill in your personal information, so that other chatters can see who they're talking to. You can make this information visible by clicking on 'info' behind the name of the chatter in the right column.
</p>
<p>
If you chat you can use the following possibilities, p.e.:
<ul>
<li>/me [p.e., is sleepy] = shows: [your name] is sleepy, irc-stile
<li>** = new line
<li>http://bla-bla.bla = will shows as a link
</ul>
</p>
<p>
PUB means Personal User Board)</p>
<p>
If you are registered and are an administrator you can BAN or ALERT chatters via the menuoption <font color="red">GUN!</font>
<p>
Have fun!
</p>
</font>
</body>
</html>
