<?php
//new
$w_only_one_tail = "Sorry, you can use only one connection to the chat at moment. You can try to reload this frame.";

//server

$w_server_restarting = "Server goes down. Trying to reconnect...";

//common
$w_banned = "You are banned";
$w_timeout = "Time out";
$w_no_user = "No such user in the chat!";
$w_title = "Voodoo chat";

//copyright
$w_copyright = "&copy; 1999-2002 by <a href=\"http://voc.sourceforge.net\">Vlad Vostrykh</a>";
//welcome
$w_welcome = "Voodoo chat";
$w_enter_login_nick = "Enter your nick";
$w_login = "(Nick should be from 3 up to 15 symbols length<br> and can contains latin letters and underscore sign &quot;_&quot;)";
$w_login_button = "&nbsp;Login&nbsp;";
$w_select_design = "Chat design";
$w_select_type = "Chat type";
$w_chat_type["tail"] = "Continuous";
$w_chat_type["php_tail"] = "php-stream";
$w_chat_type["reload"] = "Classic, resfresh-type";
$w_chat_type["js_tail"] = "js-stream emulator";

$w_whisper_to = "whisper to somebody";

//bottom:
$w_whisper = "Whisper";
$w_no_whisper = "All";
$w_color = "Color";
$w_say = "Say";
$w_logout = "Logout";
$w_too_long = "Too long message!";
$w_whisper_out = "No whipser-addressat";

//tail:
$mod_text = "And remember,<br>respect is everything!<br><br>";
$w_disconnected = "No such user in the chat!";
$w_unknown_user = "No such user in the chat!";

//who
$w_show_photos = "Show photos";
$w_dont_show_photos = "Hide photos";
$w_in_chat = "Now in the chat";
$w_nobody_in = "nobody in the chat";
$w_people = "people";
function w_people($num)
{
	if ($num == 1) return "man";
	else return "people";
}

$w_info = "Info about";

//shower
$w_history = "History";

//top
$w_help = "Help";
$w_send_mes = "Send message to the userboard";
$w_info_about = "Info about users";
$w_relogon = "Re-Login";
$w_pictures = "Pictures";
$w_gun = "Gun!";
$w_registration = "Registration";
$w_about_me = "My Info";
$w_feedback = "Feedback";



//alerter
$w_pub = "PUB";
$w_messages = "messages";
$w_new = "new";
$w_used = "space used";

//i am
$w_personal_data = "Your personal info";
$w_show_data = "Show data of this group to users";
$w_surname = "Surname";
$w_name = "Name";
$w_birthday = "Birhday";
$w_city = "City";
$w_gender = "Sex";
$w_male = "Male";
$w_female = "Female";
$w_unknown = "Unknown";
$w_addit_info = "Additional info";
$w_small_photo = "Small photo (40x40 pixels)";
$w_check_for_delete = "Click here to delete, or just";
$w_other_photo = "Choose photo if you want to replace current one";
$w_big_photo = "Big photo (.gif or .jpeg)";
$w_email = "e-mail";
$w_homepage = "HomePage URL";
$w_icq = "ICQ UIN";
$w_if_wanna_change_password = "If you want to change your current password, type new one twice below. If not, leave this fiealds blank";
$w_new_password = "New password";
$w_confirm_password = "Confirm password";
$w_update = "Update";

//updateData
$w_incorrect_password = "Incorrect password";
$w_pas_not_changed = "Password NOT changed";
$w_pas_changed = "Password changed!";
$w_succ_updated = "Your data has been successfully updated!";


//frameset
$w_enter_password = "please, enter your password";
$w_incorrect_nick = "Incorrect nick!";
$w_try_again = "try again";
$w_already_used = "This nick is already used in the chat!";

//Robot words... ~ will replaced with user nick
$w_rob_name = "Robik";
$w_rob_login = "~ has joined. Welcome!";
$w_rob_hb = "~&gt; <b>HAPPY BIRTHDAY!</b>";
$w_rob_logout = "~ has left.";
$w_rob_idle = "~ was idle over 3 minutes and has been disconnected.";

//fullinfo
$w_no_such_reg_user = "Sorry, no such registered user";

//userinfo    ~ will replaced with user nick
$w_search_results = "Search result";
$w_select_nick = "Choose nick";
$w_enter_nick = "Enter nick for search";
$w_search_comment = "(sign * mean any number of any symbols)";
$w_search_button = "Search!";
$w_search_no_found = "~ not found";
$w_search = "User search";

//snd
$w_message_text = "Message body";
$w_send = "Send";
$w_enter_nick_to_send = "Send to";
$w_user_wrote = "~ wrote:";
$w_not_shure_in_nick = "If you don't know nick exactly, try to search it (sign * mean any number of any symbols)";

//postMessage
$w_incorrec_nick_to_send = "Incorrect addressat";
$w_message_sended = "Your message successfully sent";
$w_message_error = "Error while sending message. Addressat's mailbox is full";
$w_back_to_send = "Return to the sending form";

//meOp
// ~ - from User, * - time
$w_back_to_userboard = "Return to the PUB";
$w_status = "&nbsp;";
$w_from = "From";
$w_subject = "Subject";
$w_no_subject = "No subject";
$w_at_date = "Date";
$w_from_line = "From ~, sent at *";
$w_date_format = "d/m/Y, H:i";
$w_answer = "Reply";
$w_delete = "delete";
$w_del_checked = "Delete checked";
$w_stat[0] = " ";
$w_stat[1] = "<b>N</b>";
$w_stat[2] = "<b>R</b>";
$w_stat[3] = " ";

//pictures
$w_symbols = "Phrase";
$w_picture = "Picture";
$w_about_smiles = "
<b>Standart smiles</b>try >;-p :-) <;-o and smting like this :)<br><br>
You can click on the picture below to insert pic-code into your message
";

//admin
$w_no_admin_rights = "You don't have administrator privileges";
$w_admin_action = "Action";
$w_admin_alert = "alert";
$w_admin_kill = "ban";
$w_admin_ip_kill = "ban by ip-address";
$w_admin_reason = "reason";
$w_admin_ban = "BAN";
$w_alert_text = "<b>~</b> got alert from <b>*</b>. Reson: <b>#</b>";
$w_kill_text = "<b>*</b> bans <b>~</b> for $. Reason: <b>#</b>";
$w_kill_time = "ban for";
$w_times[0]["name"] = "10 mins";
$w_times[0]["value"] = 600;
$w_times[1]["name"] = "1 hour";
$w_times[1]["value"] = 3600;
$w_times[2]["name"] = "5 hours";
$w_times[2]["value"] = 18000;
$w_times[3]["name"] = "day";
$w_times[3]["value"] = 86400;
$w_times[4]["name"] = "week";
$w_times[4]["value"] = 604800;




//leave
$w_leave = "Thanx for using our chat!<br><br><a href=\"index.php\">Back to the chat</a>";

//registration
//in the 'top' section $w_registration = "�����������";
$w_password = "Password";
$w_reg_text = $w_login;
$w_password_mismatch = "Password mismatch";
$w_succesfull_reg = "Your nick ~ has been successfully registered.";
$w_reg_error = "Error while registration proccess. Try again later..";

//feedback
$w_feed_headline = "You can send us your feedback:";
$w_feed_name = "Name/Surname";
$w_feed_message = "Your message";
$w_feed_sent_ok = "Your message has been sent. Thanx!";
$w_feed_error = "Error while sending proccess. Try again later..";



$registered_colors[0][0] = "beige"; 
$registered_colors[0][1] = "beige" ; 

$registered_colors[1][0] = "maroon"; 
$registered_colors[1][1] = "maroon"; 

$registered_colors[2][0] = "cyan"; 
$registered_colors[2][1] = "cyan"; 

$registered_colors[3][0] = "yellow"; 
$registered_colors[3][1] = "yellow" ; 

$registered_colors[4][0] = "tan"; 
$registered_colors[4][1] = "tan" ; 

$registered_colors[5][0] = "green"; 
$registered_colors[5][1] = "green" ; 

$registered_colors[6][0] = "firebrick"; 
$registered_colors[6][1] = "firebrick" ; 

$registered_colors[7][0] = "lightcoral"; 
$registered_colors[7][1] = "lightcoral" ; 

$registered_colors[8][0] = "brown"; 
$registered_colors[8][1] = "brown" ; 

$registered_colors[9][0] = "red"; 
$registered_colors[9][1] = "red" ; 

$registered_colors[10][0] = "lavender"; 
$registered_colors[10][1] = "lavender" ; 

$registered_colors[11][0] = "lime"; 
$registered_colors[11][1] = "lime" ; 

$registered_colors[12][0] = "salmon"; 
$registered_colors[12][1] = "salmon" ; 

$registered_colors[13][0] = "seagreen"; 
$registered_colors[13][1] = "seagreen" ; 

$registered_colors[14][0] = "olive"; 
$registered_colors[14][1] = "olive" ; 

$registered_colors[15][0] = "darkorange"; 
$registered_colors[15][1] = "darkorange" ; 

$registered_colors[16][0] = "orchid"; 
$registered_colors[16][1] = "orchid" ; 

$registered_colors[17][0] = "peru"; 
$registered_colors[17][1] = "peru" ; 

$registered_colors[18][0] = "purple"; 
$registered_colors[18][1] = "purple" ; 

$registered_colors[19][0] = "deeppink"; 
$registered_colors[19][1] = "deeppink" ; 

$registered_colors[20][0] = "chartreuse"; 
$registered_colors[20][1] = "chartreuse" ; 

$registered_colors[21][0] = "gray"; 
$registered_colors[21][1] = "gray" ; 

$registered_colors[22][0] = "blue"; 
$registered_colors[22][1] = "blue" ; 

$registered_colors[23][0] = "plum"; 
$registered_colors[23][1] = "plum" ; 

$registered_colors[24][0] = "blueviolet"; 
$registered_colors[24][1] = "blueviolet" ; 

$registered_colors[25][0] = "magenta"; 
$registered_colors[25][1] = "magenta" ; 

$registered_colors[26][0] = "khaki"; 
$registered_colors[26][1] = "khaki" ; 

$registered_colors[27][0] = "black"; 
$registered_colors[27][1] = "black" ; 

$registered_colors[28][0] = "chocolate"; 
$registered_colors[28][1] = "chocolate" ; 

$registered_colors[29][0] = "�Dark-blue"; 
$registered_colors[29][1] = "#000080" ; 

$default_color = 27;#black;
$highlighted_color = 9; #red;

?>
