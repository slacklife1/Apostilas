<?php
#trying to get preffered design from cookies
if ((isset($c_design)) and (!isset($design))) $design = $c_design;
include("inc_common.php");

include($file_path."designes/".$design."/index.php");
?>