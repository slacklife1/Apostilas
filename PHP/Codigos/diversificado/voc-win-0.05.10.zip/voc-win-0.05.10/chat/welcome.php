<?php
include("inc_common.php");
if (!isset($c_user_name)) $c_user_name = "";

if (in_array($c_chat_type,$chat_types))
        $chat_type = $c_chat_type;
	else $chat_type = $chat_types[0];
include($file_path."designes/".$design."/welcome.php");
?>
