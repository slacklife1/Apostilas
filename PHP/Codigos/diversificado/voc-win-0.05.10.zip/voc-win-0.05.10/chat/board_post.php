<?php
include("inc_common.php");
include($engine_path."users_get_list.php");

if (!$exists) 
{
	$error_text = "$w_no_user";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}

if (get_magic_quotes_gpc()) 
{
	$message = stripslashes($message);
	$subject = stripslashes($subject);
}
$message = htmlspecialchars($message);
$message = str_replace("\n","<br>",$message);
$message = str_replace("\r","",$message);
$message = str_replace("\t"," ",$message);
$message = str_replace("  "," &nbsp;",$message);

$subject = str_replace("\t"," ",$subject);

$info_message = "";

include($ld_engine_path."board_post_message.php");

include($file_path."designes/".$design."/board_post.php");
?>