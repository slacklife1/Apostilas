<html>
<head>
<?php
echo "<meta http-equiv=\"refresh\" content=\"0;URL=".urldecode($url)."\">";
?>
<body>
<a href="<?php echo urldecode($url); ?>">press</a>
</body></html>