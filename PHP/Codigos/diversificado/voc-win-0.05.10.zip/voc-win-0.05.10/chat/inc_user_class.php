<?php
class User
{
	var $nickname;
	var $password;
	var $surname;
	var $firstname;
	var $email;
	var $url;
	var $icq_uin;
	var $photo_url;
	var $about;
	var $user_class;
	var $last_visit;
	var $b_day;
	var $b_month;
	var $b_year;
	var $show_group_1;
	var $show_group_2;
	var $sex;
	var $city;
	var $registered_at;
}


?>