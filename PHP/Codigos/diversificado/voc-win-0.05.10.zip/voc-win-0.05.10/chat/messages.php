<?php
include("inc_common.php");
include($engine_path."users_get_list.php");

if (!$exists) 
{
	$error_text = "$w_no_user";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}

include($engine_path."messages_get_list.php");
include($engine_path."ignore_get.php");
$out_messages = array();

#actually, I can add possibility to set the number of messages to show into user profile
#but since this method (refreshing show) is not primary in the chat, 
#I don't want to spend my time for it :)
$start_at = ($total_messages > 30) ? ($total_messages-29) : 0;
for ($i=$start_at;$i<$total_messages;$i++)
{
	$to_out = "";
	#$color is not used anymore
	list($lastID,$mesTime,$fromNick,$private,$message,$color) = explode ("\t", $messages[$i]);
	if(!isset($ignored_users[strtolower($fromNick)]))
	{
		if ($private == "")
		{
			$to_out = str_replace("[HOURS]",date("H",$mesTime),$message_format);
		}
		else
		{
			if (($private == $session) or (($private == $user_name) and ($is_regist)))
			{
				$to_out = str_replace("[HOURS]",date("H",$mesTime),$private_message);
				$private = $user_name;
			}
			elseif($fromNick == $user_name)
			{
				$toNick = $w_unknown_user;
				for($ttt=0; $ttt<count($users); $ttt++)
				{
					$data = explode("\t", $users[$ttt]);
					if (($data[1] == $private) or ($data[0] == $private)) {$toNick=$data[0];break;}
				}
				$private = $toNick;
				$to_out = str_replace("[HOURS]",date("H",$mesTime),$private_message);
			}
			else 
				$to_out = str_replace("[HOURS]",date("H",$mesTime),$private_hidden);
		}
		$to_out = str_replace("[MIN]",date("i",$mesTime),$to_out);
		$to_out = str_replace("[SEC]",date("s",$mesTime),$to_out);
		$to_out = str_replace("[NICK]",$fromNick,$to_out);
		$to_out = str_replace("[TO]",$private,$to_out);
		$to_out = str_replace("[PRIVATE]",$w_whisper_to,$to_out);
		$to_out = str_replace("[MESSAGE]",$message,$to_out);
		$out_messages[] = $to_out."<br><script>scroll(1,10000000)</script>\n";
	}
}
include($file_path."designes/".$design."/messages.php");
?>