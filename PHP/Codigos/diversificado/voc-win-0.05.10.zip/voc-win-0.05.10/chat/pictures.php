<?php
include("inc_common.php");
#for determining design:
include($engine_path."users_get_list.php");

$pic_phrases = array();
$pic_urls = array();
include($ld_engine_path."pictures.php");


include($file_path."designes/".$design."/pictures.php");
?>