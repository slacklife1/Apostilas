<?php
include("inc_common.php");
include($engine_path."users_get_list.php");
include($engine_path."messages_get_list.php");

$out_messages = "";
$start_at = ($total_messages > 10) ? ($total_messages-9) : 0;
for ($i=$start_at; $i<$total_messages; $i++)
{
	list($lastID,$mesTime,$fromNick,$private,$message,$color) = explode ("\t", $messages[$i]);
	$message = strip_tags($message);
	$message = wordwrap($message, 75," ", 1);
	
	$mesTime = date("H:i", $mesTime);
	if ($private == "")
	{
	//    if ($fromNick == "<b>$w_rob_name</b>") { echo "[$fromNick]&nbsp;$message<br>\n";
	//	}
	//	else
	//	{
		$out_messages .=  "$mesTime [$fromNick]&nbsp;$message<br>\n";
	//	}
	}
	else
	{
		$out_messages .=  "$mesTime [$fromNick] &nbsp;$w_whisper_to<br>\n";
	}
}



$out_users = "";
for ($i=0; $i<count($users); $i++)
{
  $data = explode("\t", $users[$i]);
  $out_users .= $data[0]."<br>\n";
}

if(count($users) == 0) {$out_users_header =  "$w_nobody_in\n";}
  else { $out_users_header = "$w_in_chat: <b>".count($users)."</b> ".w_people(count($users)).".\n"; }


include($file_path."designes/".$design."/shower.php");



?>