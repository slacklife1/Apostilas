#!/usr/bin/perl -w
my $data_path = "/home/voodoo/www/voc/data/";
 
print "Content-type: text/html\n\n";
print "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">
<html>
<head>
	<title>daemon starter</title>
</head>
<body bgcolor=\"white\">";

$buffer=$ENV{'QUERY_STRING'};
@pairs = split(/&/, $buffer);
foreach $pair (@pairs) 
{
	($name, $value) = split(/=/, $pair);
	$value =~ tr/+/ /;
	$value =~ s/%(..)/pack("c",hex($1))/ge; 
	$name=~tr/+/ /; 
	$name=~ s/%(..)/pack("c",hex($1))/ge; 
	$input{$name} = $value;
}
if ($input{'op'} eq "start")
{

	system('cd '.$data_path.'daemon/; perl ./daemon.pl 2>&1');
	sleep(3);
	print "</pre>";
}
if ($input{'op'} eq "stop")
{
	print "<pre>";
	system('cd '.$data_path.'daemon/; kill `cat daemon.pid` 2>&1');
	sleep(3);
	print "</pre>";
}
my $pid_file = $data_path."daemon/daemon.pid";
my $log_file = $data_path."daemon/daemon.log";

$config = $data_path."voc.conf";
eval('require("$config")') or die "cannot process config file $config";

open(PIDFILE, "< $pid_file");
@pidfile = <PIDFILE>;
close(PIDFILE);
if (scalar(@pidfile)>0) {$pid = $pidfile[0];} else {$pid = "";}
print "Status:<br>";
if ($pid eq ""){print "Daemon is not running<br>\n";}
else {print "Daemon is running with pid= $pid<br>\n";}

print "<b>Proccesses information:</b><br><pre>";
system('ps -aux |grep '.$pid);
print "</pre>\n<b>Netstat information:</b><br><pre>";
system('netstat -na |grep '.$daemon_port);
print "</pre>\n";
print "<hr>";
print "<a href=\"daemon_admin.pl?op=view\">Reload stat page</a> | ";
if ($pid eq "") { print "<a href=\"daemon_admin.pl?op=start\">start daemon</a>";}
else {print "<a href=\"daemon_admin.pl?op=stop\">stop daemon</a>";}
print "<hr>Last 20 lines in the log file:<br>";
open(LOGFILE, "< $log_file");
@logfile = <LOGFILE>;
close(LOGFILE);
my $start_at = (scalar(@logfile)>20)? scalar(@logfile)-20: 0;
for ($i=$start_at;$i<scalar(@logfile);$i++)
{
	print $logfile[$i]."<br>\n";
}
exit;

