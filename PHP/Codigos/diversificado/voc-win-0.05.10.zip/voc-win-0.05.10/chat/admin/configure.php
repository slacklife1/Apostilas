<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>Voodoo chat -- configurator</title>
<style>
body, td
{
	font-family: Verdana, arial;
	font-size: 10pt;
	color:black;
}
.input
{
    BACKGROUND-COLOR: white;
    BORDER-BOTTOM: black 1pt solid;
    BORDER-LEFT: black 1pt solid;
    BORDER-RIGHT: black 1pt solid;
    BORDER-TOP: black 1pt solid
    COLOR: black;
    FONT-SIZE: 10pt;
    MARGIN: 0px;
    PADDING-BOTTOM: 0px;
    PADDING-LEFT: 2px;
    PADDING-RIGHT: 0px;
    PADDING-TOP: 0px;
    font-family: Verdana, arial, Helvetica;
}
a, a:hover, a:visited
{
	color:black;
}
</style>
</head>

<body bgcolor="white">
<?php
if (!isset($step)) $step = 0;
else $step = intval($step);
if (!isset($saved)) $saved = 0;
else $saved = intval($saved);


clearstatcache();
$error = 0;
switch ($step)
{
	case 0:
		echo "<h3>step 0</h3>";
		$error = 0;
		$conf_file_path = realpath("../");
		echo "<form method=\"post\" action=\"configure.php\">";
		echo "trying to locate <b>inc_common.php</b>...<br>";
		if (!isset($conf_inc_config)) $conf_inc_config = $conf_file_path."/inc_common.php";
		$can_write = is_writeable($conf_inc_config);
		$is_file = is_file($conf_inc_config);
		if (!$is_file) {echo "<b>Not found:</b>";$error=1;} else echo "<b>found:</b>";
		echo "<input type=\"text\" name=\"conf_inc_config\" value=\"$conf_inc_config\" class=\"input\" size=\"50\"><br>";
		if  ($can_write)
			echo  "Writeable, <b>Ok</b>";
		else
		{
			echo "<b>Cannot write to config file</b>! Please, change file attributes (you can do it with your FTP-client)";
			$error = 1;
		}
		echo "<br>If this is incorrect information, change the path to correct one<hr>";
		
		
		echo "trying to locate <b>data</b>-directory<br>";
		$config_lines = @file($conf_inc_config);
		if (!isset($conf_data_path)) 
		{
			for ($i=0;$i<count($config_lines);$i++)
			{
				list($param,$value) = split("=",$config_lines[$i]);
				if (trim($param) == "\$data_path") eval($config_lines[$i]);
			}
			if (is_dir(realpath($data_path))) $conf_data_path = $data_path;
		}
		if (!isset($conf_data_path)) $conf_data_path = realpath($conf_file_path."/../data")."/";
		
		
		$is_dir = is_dir($conf_data_path);
		if (!$is_dir) {echo "<b>Not found:</b>";$error=1;} else echo "<b>found:</b>";
		echo "<input type=\"text\" name=\"conf_data_path\" value=\"$conf_data_path\" class=\"input\" size=\"50\"><br>";
		
		echo "<br><b>Should be ended with the slash!!!!</b> If this is incorrect information, change the path to correct one<hr>";
		
		echo "<a href=\"javascript:document.forms[0].step.value='0';document.forms[0].submit();\">test changes</a>";
		if (!$error) 
			echo "<br>Looks <b>Ok</b>, <a href=\"javascript:document.forms[0].step.value='1';document.forms[0].submit();\">Save and go to the next step</a>";
		
		echo "<input type=\"hidden\" name=\"step\" value=\"\">";
		echo "</form>";
	break; //end of case 0

	case 1:
		echo "<h3>step 1</h3>";
		echo "<form method=\"post\" action=\"configure.php\">";
		if (!isset($conf_file_path)) $conf_file_path = dirname($conf_inc_config)."/";
		if ($saved != 1)
		{
			echo "saving data to inc_common.php:";
			$config_lines = file($conf_inc_config);
			$fp = fopen($conf_inc_config,"w");
			flock($fp, LOCK_EX);
			for ($i=0;$i<count($config_lines);$i++)
			{
				list($param,$value) = split("=",$config_lines[$i]);
				if (trim($param) == "\$data_path") $config_lines[$i] = "\$data_path = \"".$conf_data_path."\";\n";
			}
			fwrite($fp, implode("",$config_lines));
			fflush($fp);
			flock($fp, LOCK_UN);
			fclose($fp);
			echo "<b>Done</b><hr>";
		}
		echo "checking files in the <b>data</b> directory";
		$files_list = array("banlist.dat","converts.dat","ignored.dat","messages.dat","robotspeak.dat","users.dat","voc.conf","who.dat");
		for ($i=0;$i<count($files_list);$i++)
		{
			echo "<br>";
			$real_name =realpath($conf_data_path."/".$files_list[$i]);
			$can_write = is_writeable($real_name);
			$is_file = is_file($real_name);
			if (!$is_file) {echo "<b>Not found:</b>";$error=1;} else echo "<b>found:</b>";
			echo "$real_name<br>";
			if  ($can_write)
				echo  "Writeable, <b>Ok</b>";
			else
			{
				echo "<b>Cannot write to this file</b>! Please, change file attributes (you can do it with your FTP-client)";
				$error = 1;
			}
			echo "<br>";
		}
		echo "<hr>";
		echo "checking subdirectories in the <b>data</b>";
		$files_list = array("board","users");
		for ($i=0;$i<count($files_list);$i++)
		{
			echo "<br>";
			$real_name =realpath($conf_data_path."/".$files_list[$i]);
			$can_write = is_writeable($real_name);
			$is_file = is_dir($real_name);
			if (!$is_file) {echo "<b>Not found:</b>";$error=1;} else echo "<b>found:</b>";
			echo "$real_name<br>";
			if  ($can_write)
				echo  "Writeable, <b>Ok</b>";
			else
			{
				echo "<b>Cannot write to this directory</b>! Please, change file attributes (you can do it with your FTP-client)";
				$error = 1;
			}
			echo "<br>";
		}
		echo "<hr>";
		echo "<a href=\"javascript:document.forms[0].step.value='1';document.forms[0].submit();\">test again</a>";
		if (!$error) 
			echo "<br>Looks <b>Ok</b>, <a href=\"javascript:document.forms[0].step.value='2';document.forms[0].submit();\">Go to the next step</a>";
		
		echo "<input type=\"hidden\" name=\"step\" value=\"\">";
		echo "<input type=\"hidden\" name=\"saved\" value=\"1\">";
		echo "<input type=\"hidden\" name=\"conf_data_path\" value=\"$conf_data_path\">";
		echo "<input type=\"hidden\" name=\"conf_file_path\" value=\"$conf_file_path\">";
		echo "</form>";
	break; //end of case 1

	case 2:
		echo "<h3>step 2</h3>";
		echo "<form method=\"post\" action=\"configure.php\">";
		
		if (isset($save))
		{
			echo "saving data to voc.conf:<br>\n";
			$fp = fopen($conf_data_path."/voc.conf","w");
			flock($fp, LOCK_EX);
			$to_save = "#Config file for the Voodoo chat\n#generated automatically by the chat/admin/configure.php script\n\n";
			if(get_magic_quotes_gpc())
			{
				$to_save .= "\$keep_whisper = ". stripslashes($conf_keep_whisper).";\n";
				$to_save .= "\$max_images = ". stripslashes($conf_max_images).";\n";
				$to_save .= "\$max_mailbox_size = ". stripslashes($conf_max_mailbox_size).";\n";
				$to_save .= "\$language = \"". stripslashes($conf_language)."\";\n";
				$to_save .= "\$disconnect_time = ". stripslashes($conf_disconnect_time).";\n\n";
				$to_save .= "\$admin_mail = '". stripslashes($conf_admin_mail)."';\n\n";
				$to_save .= "\$language = \"". stripslashes($conf_language)."\";\n";
				$to_save .= "\$message_format = \"". stripslashes($conf_message_format)."\";\n";
				$to_save .= "\$private_message = \"". stripslashes($conf_private_message)."\";\n";
				$to_save .= "\$private_hidden = \"". stripslashes($conf_private_hidden)."\";\n\n";
				$to_save .= "\$engine = \"files\";\n";
				$to_save .= "\$long_life_data_engine = \"files\";\n\n";
				$to_save .= "\$chat_url = \"". stripslashes($conf_chat_url)."\";\n";
				$to_save .= "\$daemon_host = \"". stripslashes($conf_daemon_host)."\";\n";
				$to_save .= "\$daemon_port = ". stripslashes($conf_daemon_port).";\n";
				$to_save .= "\$daemon_listen = \"". stripslashes($conf_daemon_listen)."\";\n";
				$to_save .= "\$max_connect = ". stripslashes($conf_max_connect).";\n";
				$to_save .= "\$file_path = \"". stripslashes($conf_file_path)."\";\n";
				for($j=0;$j<count($conf_designes);$j++)
					$to_save .= "\$designes[$j] = \"".stripslashes($conf_designes[$j])."\";\n";
				if (!in_array($conf_default_design, $conf_designes)) $conf_default_design = $conf_designes[0];
				$to_save .= "\$default_design = \"". stripslashes($conf_default_design)."\";\n";
				for($j=0;$j<count($conf_chat_types);$j++)
					$to_save .= "\$chat_types[$j] = \"".stripslashes($conf_chat_types[$j])."\";\n";
			}
			else
			{
				$to_save .= "\$keep_whisper = $conf_keep_whisper;\n";
				$to_save .= "\$max_images = $conf_max_images;\n";
				$to_save .= "\$max_mailbox_size = $conf_max_mailbox_size;\n";
				$to_save .= "\$language = \"$conf_language\";\n";
				$to_save .= "\$disconnect_time = $conf_disconnect_time;\n\n";
				$to_save .= "\$admin_mail = '".$conf_admin_mail."';\n\n";
				$to_save .= "\$message_format = \"$conf_message_format\";\n";
				$to_save .= "\$private_message = \"$conf_private_message\";\n";
				$to_save .= "\$private_hidden = \"$conf_private_hidden\";\n";
				$to_save .= "\$engine = \"files\";\n";
				$to_save .= "\$long_life_data_engine = \"files\";\n\n";
				$to_save .= "\$chat_url = \"$conf_chat_url\";\n";
				$to_save .= "\$daemon_host = \"$conf_daemon_host\";\n";
				$to_save .= "\$daemon_port = $conf_daemon_port;\n";
				$to_save .= "\$daemon_listen = \"$conf_daemon_listen\";\n";
				$to_save .= "\$max_connect = $conf_max_connect;\n";
				$to_save .= "\$file_path = \"$conf_file_path\";\n";
				for($j=0;$j<count($conf_designes);$j++)
					$to_save .= "\$designes[$j] = \"".$conf_designes[$j]."\";\n";
				if (!in_array($conf_default_design, $conf_designes)) $conf_default_design = $conf_designes[0];
				$to_save .= "\$default_design = \"$conf_default_design\";\n";			
				for($j=0;$j<count($conf_chat_types);$j++)
					$to_save .= "\$chat_types[$j] = \"".$conf_chat_types[$j]."\";\n";
					
			}
		//	echo $to_save;
			fwrite($fp, $to_save);
			fflush($fp);
			flock($fp, LOCK_UN);
			fclose($fp);
			echo "Ok<hr>\n";
		
		}
		
		echo "getting data from voc.conf<br>";
		eval(implode("",file($conf_data_path."/voc.conf")));
		echo "parameters:<br>";
		echo "keep whispering: <select name=\"conf_keep_whisper\" class=\"input\">";
		echo "<option value=\"0\"";
		if (!$keep_whisper) echo "selected";
		echo ">No</option>";
		echo "<option value=\"1\"";
		if ($keep_whisper) echo "selected";
		echo ">Yes</option>";
		echo "</select><br>*When user send a private mesage, his addressat-choice can be saved and preselected after 'sender'-frame fill loaded. <br><br>\n";
		
		echo "Maximum number of images: <input type=\"text\" size=\"3\" class=\"input\" name=\"conf_max_images\" value=\"$max_images\"><br>";
		echo "*The maximum number of images user can insert into his message<br><br>\n";
		
		echo "Maximum size of mailbox (in bytes): <input type=\"text\" size=\"5\" class=\"input\" name=\"conf_max_mailbox_size\" value=\"$max_mailbox_size\"><br>";
		echo "*If the size of the user's mailbox will be more than this value, no incoming messages to his mailbox will be accepted<br><br>\n";
		
		echo "System-language: <input type=\"text\" size=\"5\" class=\"input\" name=\"conf_language\" value=\"$language\"><br>";
		echo "*The language for system. Currently available values: en, ru, ger. Check <b>chat/languages</b> directory<br><br>\n";
		
		echo "Disconnect time (in seconds): <input type=\"text\" size=\"5\" class=\"input\" name=\"conf_disconnect_time\" value=\"$disconnect_time\"><br>";
		echo "*In case user doesn't refresh any window, system will consider that he is present during this time <br><br>\n";
		
		echo "Administator's email: <input type=\"text\" size=\"25\" class=\"input\" name=\"conf_admin_mail\" value=\"$admin_mail\"><br>";
		echo "*This email address will be used in the feedback page<br><br>\n";
		
		echo "Ordynary message's format:<input type=\"text\" size=\"75\" class=\"input\" name=\"conf_message_format\" value=\"".str_replace("\"","&quot;",$message_format)."\"><br>";
		echo "*Message's format. [HOUR] will be replaced with the hour of send time, [MESSAGE] -- with the message text, e.t.c<br><br>\n";
		
		echo "Private message's format:<input type=\"text\" size=\"75\" class=\"input\" name=\"conf_private_message\" value=\"".str_replace("\"","&quot;",$private_message)."\"><br>";
		echo "*Format for the private message in case user should see it (owner or the addressat)<br><br>\n";
		
		echo "Hidden private message's format:<input type=\"text\" size=\"75\" class=\"input\" name=\"conf_private_hidden\" value=\"".str_replace("\"","&quot;",$private_hidden)."\"><br>";
		echo "*Format for the private message in case user shouldn't see it (all other users). [PRIVATE] will be replaced with \$w_whisper_to from the language file<br><br>\n";
		
		echo "Chat url: <input type=\"text\" size=\"75\" class=\"input\" name=\"conf_chat_url\" value=\"$chat_url\"><br>";
		echo "*The URL which you type into browser to get start page of the chat. It should be ended with slash!!!<br>";
		echo "I guess, it should be something like ";
		echo "<b>http://".$SERVER_NAME.dirname(dirname($REQUEST_URI))."/</b>";
		echo "<br><br>\n";
		
		echo "Daemon URL: <input type=\"text\" size=\"75\" class=\"input\" name=\"conf_daemon_host\" value=\"$daemon_host\"><br>";
		echo "*This is URL where user can connect to the daemon (see also <b>Daemon Listen</b>). Usually it's just <b>http://".$SERVER_NAME."</b><br>\n";
		echo "The Daemon will emulate HTTP-server, so don't put anything after server name, even slash is too much!<br><br>\n";
		
		echo "Daemon Port: <input type=\"text\" size=\"75\" class=\"input\" name=\"conf_daemon_port\" value=\"$daemon_port\"><br>";
		echo "*At this port daemon will listening for incoming request. If you don't have root-rights, you can only set ports which &gt;1024!<br><br>\n";
		
		echo "Daemon Listen to: <input type=\"text\" size=\"75\" class=\"input\" name=\"conf_daemon_listen\" value=\"$daemon_listen\"><br>";
		echo "*At this IP (which corresponds to one network-interface) Daemon will listening for incoming requests.";
		echo "You can try to set it to <b>0.0.0.0</b> -- in this case Daemon will listeting at all interfaces. You can also try to use DomainName.<br><br>\n";
		
		echo "Maximum connects: <input type=\"text\" size=\"3\" class=\"input\" name=\"conf_max_connect\" value=\"$max_connect\"><br>";
		echo "*The maximum number of users that can connect to this daemon<br><br>\n";
		
		echo "System path to root of the web-chat interface: <input type=\"text\" size=\"75\" class=\"input\" name=\"conf_file_path\" value=\"$file_path\"><br>";
		echo "*This is the system path to your <b>chat/</b> directory. Should be ended with slash!!!<br>";
		echo "I guess, it should be something like <b>$conf_file_path</b><br><br>\n";
		
		$all_chat_types = array("tail","reload","php_tail","js_tail");
		echo "Chat Types: ";
		echo "<select name=\"conf_chat_types[]\" multiple class=\"input\">";
		for($i=0;$i<count($all_chat_types);$i++)
		{
			echo "<option value=\"".$all_chat_types[$i]."\"";
			if (in_array($all_chat_types[$i],$chat_types)) echo " selected";
			echo ">".$all_chat_types[$i]."</option>\n";
		}
		echo "</select><br>\n";
		echo "*Different chat types which will available for users. I recommend to use 'tail' and 'reload'<br><br>\n";
		
		
		echo "Chat designes: ";
		echo "<select name=\"conf_designes[]\" multiple class=\"input\">";
		$handle = opendir($conf_file_path."designes/");
		$conf_def_design = "<select name=\"conf_default_design\" class=\"input\">\n";
		while (false !== ($tmp_file = readdir($handle))) 
		{
			if ($tmp_file!="." and $tmp_file != "..")
			{
				$conf_def_design .= "<option value=\"$tmp_file\"";
				if($tmp_file == $default_design) $conf_def_design .= " selected";
				$conf_def_design .= ">$tmp_file</option>\n";
				
				echo "<option value=\"$tmp_file\"";
				if (in_array($tmp_file,$designes)) echo " selected";
				echo ">$tmp_file</option>\n";
			}
		}
		$conf_def_design .= "</select>";
		closedir($handle);
		echo "</select><br>\n";
		echo "*The name of design which used to Chat-layout. Check <b>chat/designes</b> directory for list of available designes.<br>\n";

		echo "Select default design: $conf_def_design<br>\n";
		echo "*The preselected design for the users who first time coming to your chat. Should be one of the possible chat designes, otherwise the first one will be used as default<br><br>\n";
		
		echo "<a href=\"javascript:document.forms[0].step.value='2';document.forms[0].submit();\">Save!</a>";
		if (!$error) 
			echo "<br>Looks <b>Ok</b>, <a href=\"javascript:document.forms[0].step.value='3';document.forms[0].submit();\">Go to the next step (DON'T FORGET TO SAVE CHANGES!!!)</a>";
		
		echo "<input type=\"hidden\" name=\"conf_data_path\" value=\"$conf_data_path\">";
		echo "<input type=\"hidden\" name=\"conf_file_path\" value=\"$conf_file_path\">";
		echo "<input type=\"hidden\" name=\"step\" value=\"\">";
		echo "<input type=\"hidden\" name=\"save\" value=\"1\">";
		echo "</form>";
	break; //end of case 2
	
	case 3:
		echo "<h3>step 2 -- checking daemon</h3>";
		echo "<form method=\"post\" action=\"configure.php\">";
		echo "checking files in the <b>data</b> directory";
		$files_list = array("daemon.pid","daemon.log");
		for ($i=0;$i<count($files_list);$i++)
		{
			echo "<br>";
			$real_name =realpath($conf_data_path."/daemon/".$files_list[$i]);
			$can_write = is_writeable($real_name);
			$is_file = is_file($real_name);
			if (!$is_file) {echo "<b>Not found:</b>";$error=1;} else echo "<b>found:</b>";
			echo "$real_name<br>";
			if  ($can_write)
				echo  "Writeable, <b>Ok</b>";
			else
			{
				echo "<b>Cannot write to this file</b>! Please, change file attributes (you can do it with your FTP-client)";
				$error = 1;
			}
			echo "<br>";
		}
		echo "<br>";
		$real_name =realpath($conf_data_path."/daemon/daemon.pl");
		$can_write = is_writeable($real_name);
		$is_file = is_file($real_name);
		if (!$is_file) {echo "<b>Not found:</b>";$error=1;} else echo "<b>found:</b>";
		echo "$real_name<br>";
		if  ($can_write)
			echo  "Writeable, <b>Ok</b>";
		else
		{
			echo "<b>Cannot write to this file</b>! Please, change file attributes (you can do it with your FTP-client)";
			$error = 1;
		}
		echo "<br>";
		if  (is_executable($real_name))
			echo  "Executable, <b>Ok</b>";
		else
		{
			echo "<b>Cannot Execute to this file</b>! Please, change file attributes (you can do it with your FTP-client)";
			$error = 1;
		}
		echo "<hr>";
		echo "Checking for neccessary Perl-modules<br>\n";
		
		$need_modules = array("POSIX","IO::Socket","IO::Select","Socket","Fcntl","Time::localtime");
		for ($i=0;$i<count($need_modules);$i++)
		{
			echo "<br>".$need_modules[$i].":<br>";
			passthru("perl -e 'use ".$need_modules[$i].";' 2>&1",$res);
			if  (!$res) echo "<b>Ok</b>";
			else
			{
				echo "<b>FAILED!!!</b> you need to install this Perl-module!";
				$error = 1;
			}
			echo "<br>\n";
		}
		echo "<a href=\"javascript:document.forms[0].step.value='3';document.forms[0].submit();\">Test again!</a>";
		if (!$error) 
			echo "<br>Looks <b>Ok</b>, Configuration finished. Go to <a href=\"./\">Admin zone</a> and try to start daemon";
		
		echo "<input type=\"hidden\" name=\"conf_data_path\" value=\"$conf_data_path\">";
		echo "<input type=\"hidden\" name=\"conf_file_path\" value=\"$conf_file_path\">";
		echo "<input type=\"hidden\" name=\"step\" value=\"\">";
		echo "<input type=\"hidden\" name=\"save\" value=\"1\">";
		echo "</form>";
	break;//end of case 3

}//end of switch
?>


</body>
</html>
