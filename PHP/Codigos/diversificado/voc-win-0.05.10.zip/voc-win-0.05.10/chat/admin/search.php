<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>Untitled</title>
</head>

<body>
<?php
include("../inc_common.php");
if ($tstInfoUser !="")
{

echo "$w_search_results<br>\n";
$users = array();
$users = file($user_data_file);
$t_id = 0;
$ttt = str_replace("*","([[:alnum:]]+)",$tstInfoUser);
for ($i=0; $i<count($users);$i++)
{
	$user = str_replace("\n","",$users[$i]);
	list($t_id, $t_nickname, $t_password, $t_class) = explode("\t",$user);

	if (eregi($ttt,$t_nickname))
	{
		echo "<a href=\"moderators.php?user_id=$t_id\">$t_nickname</a><br>\n";
	}
}
}
?>


</body>
</html>
