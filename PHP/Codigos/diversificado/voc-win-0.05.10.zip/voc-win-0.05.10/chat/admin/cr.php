<html>
<head>
	<title> Voodoo Chat. Class Room </title>
<style type="text/css">td, body {font-size: 12px;font-family: Arial, Helvetica, sans-serif;color: black;}
.input{font-size: 11px;background: #ffffff;font-family: Arial, Helvetica, sans-serif;}
h1 {font-size: 22px; font-weight: bold; font-family: Arial, Helvetica, sans-serif;color: black;}
.copyRi{font-size:11px; font-family: Arial, Helvetica, sans-serif;color:#777777;}
a {font-size: 12px;font-family: Arial, Helvetica, sans-serif;color: black; text-decoration: underline;}  
</style>
</head>
<body bgcolor=white>
<?php

function get_probability($id, $prob = 5)
{
	$html = "<select name=\"prob$id\">\n";
	for ($i=0;$i<11;$i++)
	{
		$html .= "<option value=$i";
		if ($i == $prob) $html .= " selected";
		$html .= ">$i</option>\n";
	}
	$html .= "</select>\n";
	return $html;
}
include("../inc_common.php");

if (isset($maxID)) 
{
	unset($phrases);
	$phrases = array();
	for ($i=0; $i<=$maxID;$i++)
	{
		$tmpPhrase="phrase" . $i;
		$phrase = $$tmpPhrase;
		/*    $phrase = str_replace("\\\"","\"",$phrase);*/
		//    $phrase = htmlspecialchars($phrase);
		//	$phrase = addslashes($phrase);
		$phrase = str_replace("\t","",$phrase);
		$tmpAnswer = "answer" .$i;
		$answer = $$tmpAnswer;
		$answer = str_replace("\t","", $answer);
		$tmpProb = "prob".$i;
		$prob = $$tmpProb;
		/*    $answer = str_replace("\\\"","\"",$answer);*/
		//    $answer = htmlspecialchars($answer);
		//    $answer = addslashes($answer);
		if (($phrase != "") and ($answer != ""))
		{
			$phrases[count($phrases)] = $phrase."\t".$answer."\t".$prob;
		}
		$fp = fopen($robotspeak_file,"w");
		fwrite($fp, implode("\n", $phrases));
		fclose($fp);
	}
}



echo "sign  ~ will be replaced with the Nick of sender<br><form method=\"post\" action=\"cr.php\">\n";
echo "<input type=\"hidden\" name=\"teacher\" value=\"$teacher\">\n";
echo "<input type=\"hidden\" name=\"teacherPassword\" value=\"$teacherPassword\">\n";
$phrases = file($robotspeak_file);
$ID = 0;
for ($i=0;$i<count($phrases); $i++)
{
	$phrase = str_replace("\n","",$phrases[$i]);
	list($user_phrase, $robot_answer, $prob) = split("\t", $phrase);
	$user_phrase = str_replace("\"","&quot;", $user_phrase);
	$robot_answer = str_replace("\"","&quot;", $robot_answer);
	echo "$ID: <input type=\"text\" name=\"phrase$ID\" value=\"$user_phrase\"> -- <input type=\"text\" name=\"answer$ID\" value=\"$robot_answer\" size=40>";
	echo get_probability($ID, $prob);
	echo "<br>\n";
	$ID++;
}

	echo "New: <input type=\"text\" name=\"phrase$ID\"> -- <input type=\"text\" name=\"answer$ID\" size=40> -- ";
	echo get_probability($ID);
	echo "<br>\n";
	echo "<input type=\"hidden\" name=\"maxID\" value=\"$ID\">";
	echo "<input type=\"Submit\" value=\"Save\"><input type=\"reset\" value=\"Reset\">\n";
	echo "</form>\n";
?>


</body></html>