<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>Untitled</title>
</head>

<body>
<?php
include("../inc_common.php");

$user_id = intval($user_id);
require("../inc_user_class.php");
$user = unserialize(implode("",file($data_path."users/".$user_id.".user")));

if ($class_to_set!="")
{
	$user->user_class = $class_to_set;
	$fp = fopen ($data_path."users/".$user_id.".user", "w");
	flock($fp, LOCK_EX);
	fwrite($fp,serialize($user));
	flock($fp, LOCK_UN);
	fflush($fp);
	fclose($fp);
	
	$users = array();
	$users = file($user_data_file);
	$t_id = 0;
	for ($i=0; $i<count($users);$i++)
	{
		$tt_user = str_replace("\n","",$users[$i]);
		list($t_id, $t_nickname, $t_password, $t_class) = explode("\t",$tt_user);
		if ($t_id == $user_id)
		{
			$users[$i] = $t_id ."\t". $t_nickname ."\t". $t_password ."\t". $class_to_set ."\n";
			break;
		}
	}
	$fp = fopen($user_data_file, "w");
	flock($fp, LOCK_EX);
	fwrite($fp,implode("",$users));
	fflush($fp);
	flock($fp, LOCK_UN);
	fclose($fp);
}

?>
<form method="post" action="moderators.php">
<input type="hidden" name="user_id" value="<?php echo $user_id;?>">
class 4 user <?php echo $user->nickname;?>:<br><select name="class_to_set">
<option <?php if ($user->user_class=="user") echo "selected";?>>user
<option <?php if ($user->user_class=="admin") echo "selected";?>>admin
</select>
<br>
<input type="submit" value="update">
</form>
</body>
</html>
