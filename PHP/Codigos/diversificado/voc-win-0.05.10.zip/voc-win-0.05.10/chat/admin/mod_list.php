<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>Untitled</title>
</head>

<body>
<?php
include("../inc_common.php");
echo "moderators list<br>\n";
$users = array();
$users = file($user_data_file);
for ($i=0; $i<count($users);$i++)
{
	$user = str_replace("\n","",$users[$i]);
	list($t_id, $t_nickname, $t_password, $t_class) = explode("\t",$user);
	if ($t_class=="admin")
	{
		echo "<a href=\"moderators.php?user_id=$t_id\">$t_nickname</a><br>\n";
	}
}

?>


</body>
</html>
