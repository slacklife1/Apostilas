<html>
<body bgcolor="gray">
hello?
<script language="javascript">
<?php
error_reporting(15);
include("inc_common.php");
include($engine_path."users_get_list.php");

if (!$exists) 
{
	$error_text = "$w_no_user";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}
include($engine_path."messages_get_list.php");
include($engine_path."ignore_get.php");
$out_messages = array();
echo "with (window.parent.voc_js_main.window.document)\n{";
if (!isset($last_message))
{
	$header_string = file($file_path."designes/".$design."/daemon_html_header.html");
	echo "open('text/html','replace');";
	for($i=0;$i<count($header_string);$i++)
		echo "write('".str_replace("'","\'",str_replace("\n","",$header_string[$i]))."');\n";
	
	$total_messages = count($messages);
	$start_at = ($total_messages > 10) ? ($total_messages-9) : 0;
	$last_id = show_messages(0, $messages,$ignored_users,$start_at);

}
else
{
	$last_message = intval($last_message);
	$last_id = show_messages($last_message, $messages,$ignored_users);
	if ($last_message == $last_id) echo "write('');\n";
}
echo "}\n";
?>
with (window.parent.voc_js_main.window)
{
	if (typeof(scrollBy) != 'undefined')
	{
		scrollBy(0, 100000);
		scrollBy(0, 100000);
	}
	else if (typeof(scroll) != 'undefined')
	{
		scroll(0, 100000);
		scroll(0, 100000);
	}
}
<?php
echo "window.setTimeout('document.location.href=\"js_writer.php?session=$session&last_message=$last_id\"',5000);\n";

function show_messages($last_id, $messages, $ignored_users,$start_at = 0,$last_message)
{
	global $message_format, $private_message, $private_hidden,$w_whisper_to,$session,$user_name,$is_regist,$users,$w_unknown_user;
	$total_messages = count($messages);
	
	for ($i=$start_at;$i<$total_messages;$i++)
	{
		$to_out = "";
		#$color is not used anymore
		list($message_id,$mesTime,$fromNick,$private,$message,$color) = explode ("\t", $messages[$i]);
		if ($message_id > $last_id)
		{
			if(!isset($ignored_users[strtolower($fromNick)]))
			{
				if ($private == "")
				{
					$to_out = str_replace("[HOURS]",date("H",$mesTime),$message_format);
				}
				else
				{
					if (($private == $session) or (($private == $user_name) and ($is_regist)))
					{
						$to_out = str_replace("[HOURS]",date("H",$mesTime),$private_message);
						$private = $user_name;
					}
					elseif($fromNick == $user_name)
					{
						$toNick = $w_unknown_user;
						for($ttt=0; $ttt<count($users); $ttt++)
						{
							$data = explode("\t", $users[$ttt]);
							if (($data[1] == $private) or ($data[0] == $private)) {$toNick=$data[0];break;}
						}
						$private = $toNick;
						$to_out = str_replace("[HOURS]",date("H",$mesTime),$private_message);
					}
					else 
						$to_out = str_replace("[HOURS]",date("H",$mesTime),$private_hidden);
				}
				$to_out = str_replace("[MIN]",date("i",$mesTime),$to_out);
				$to_out = str_replace("[SEC]",date("s",$mesTime),$to_out);
				$to_out = str_replace("[NICK]",$fromNick,$to_out);
				$to_out = str_replace("[TO]",$private,$to_out);
				$to_out = str_replace("[PRIVATE]",$w_whisper_to,$to_out);
				$to_out = str_replace("[MESSAGE]",$message,$to_out);
				$to_out = str_replace("'","\'",$to_out);
				echo "write('$to_out<br>');\n";

			}
		}
	}
	return $message_id;
}
?>
</script>
</body>
</html>
