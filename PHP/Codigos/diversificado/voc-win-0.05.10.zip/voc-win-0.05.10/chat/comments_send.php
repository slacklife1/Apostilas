<?php
include("inc_common.php");
#for determining design:
include($engine_path."users_get_list.php");

if (get_magic_quotes_gpc())
{
	$name = stripslashes($name);
	$name = urlencode($name);
	$email = stripslashes($email);
	$comment = stripslashes($comment);
}
$success = mail($admin_mail, "comments from chat", "From: $name\nEMail: $email\n--------\n$comment\n", "From: <$email>\nReturn-Path: $admin_mail\nContent-Type: text/plain;\nContent-Transfer-Encoding: 8bit");
if ($success) $info_message = $w_feed_sent_ok;
else  $info_message = $w_feed_error;
include($file_path."designes/".$design."/comments_send.php");
?>
