<?php
$fp = fopen ($data_path."users/".$is_regist.".user", "w");
flock($fp, LOCK_EX);
fwrite($fp,serialize($current_user));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);



$users = file($user_data_file);
for ($i=0;$i<count($users);$i++)
{
	list($id, $nickname, $password, $class) = explode("\t",$users[$i]);
	if ($id == $is_regist) 
	{
		$users[$i] = "$id\t$nickname\t".$current_user->password."\t$class";
	}
}

$fp = fopen($user_data_file,"w");
flock($fp, LOCK_EX);
fwrite($fp,implode("",$users));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);
$info_message .= $w_succ_updated."<br>";
?>