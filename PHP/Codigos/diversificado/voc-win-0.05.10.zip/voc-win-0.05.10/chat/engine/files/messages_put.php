<?php
if(count($messages_to_show))
{
	unset($messages);
	unset($newMessages);
	$messages = array();
	$fp_mes = fopen($messages_file, "a+");
	flock($fp_mes, LOCK_EX);
	fseek($fp_mes,0);
	
	while($ttt=fgets($fp_mes, 8192))
	{
		if ($ttt !="")$messages[] = $ttt;#do nothing
	}
	$total_messages = count($messages);
	
	$last_id = 0;
	if ($total_messages) list($last_id) = explode("\t",$messages[$total_messages-1]);
	$last_id++;
	
	for ($i=0;$i<count($messages_to_show);$i++)
	{
		$messages[] = $last_id."\t".str_replace("\n"," ",$messages_to_show[$i])."\n";
		$last_id++;
	}
	$total_messages = count($messages);
	$start_at = ($total_messages > 40)? ($total_messages-40) : 0;
	
	ftruncate($fp_mes,0);
	for ($i=$start_at; $i<$total_messages;$i++)
	{
		fwrite($fp_mes, $messages[$i]);
	}
	$putj=0;
	
	fflush($fp_mes);
	flock($fp_mes, LOCK_UN);
	fclose($fp_mes);
}
?>
