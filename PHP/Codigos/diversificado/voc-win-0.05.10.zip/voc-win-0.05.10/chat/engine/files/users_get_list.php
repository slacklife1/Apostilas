<?php
if(!isset($session)) $session = "0";
if(!is_string($session)) $session = "0";

if(!defined("_CMP_")):
define("_CMP_",1);
function cmp($a, $b)
{
	return strcmp(strtoupper($a), strtoupper($b));
}
endif;
$users = array();

$fp = fopen($who_in_chat_file, "a+");
flock($fp, LOCK_EX);
fseek($fp,0);

$exists = 0;
$is_regist = 0;
$user_name = "";
while($data = fgetcsv ($fp, 1000, "\t") )
{
	if ($data[1] == $session)
	{
		$user_name = $data[0];
		$data[2]=time();
		$exists = 1;
		#$exists2 = $j;
		$is_regist = $data[5];
		$user_ip = $data[7];
		$design = $data[8];
		if (!in_array($design, $designes)) $design = $default_designe;
		$current_design = $chat_url."designes/".$design."/";
	}
	if ($data[2] > time()-$disconnect_time)
	{
		$users[] = $data[0] . "\t" . $data[1] . "\t" . $data[2] . "\t" . $data[3]. "\t" . $data[4]. "\t" . $data[5] . "\t" . $data[6]."\t" . $data[7]. "\t" . $data[8] . "\n";
	}
	else
	{
		$to_discon_session = $data[1];
		$to_discon_user_name = $data[0];
		include($file_path."idle_disconnect.php");
	}
}
if (count($users)) usort($users, "cmp");
else $users = array();

ftruncate($fp,0);

fwrite($fp,implode("",$users));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);
?>
