<?php
unset($users);
$users = array();
$fp = fopen($banlist_file, "a+");
if (!flock($fp, LOCK_EX)) die ("can't lock file");
fseek($fp,0);
while($data = fgetcsv ($fp, 1000, "\t") )
{
	$who = $data[0];
	$until = $data[1];
	if ($until>time())
		$users[count($users)] = $who."\t".$until;
}
$users[count($users)] = $to_ban."\t".($w_times[$kill_time]["value"] + time());
ftruncate($fp,0);
if (!is_array($users)) $users = array();
fwrite($fp,implode("\n",$users));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);
		
unset($users);
$users = array();
$j=0;
$fp = fopen($who_in_chat_file, "a+");
if (!flock($fp, LOCK_EX)) die ("can't lock file");
fseek($fp,0);
while($data = fgetcsv ($fp, 1000, "\t") )
{
  if (strcasecmp($data[0],$nameToBan)!=0) 
  {
    $users[$j] = $data[0] . "\t" . $data[1] . "\t" . $data[2] . "\t" . $data[3]. "\t" . $data[4]. "\t" . $data[5] . "\t" . $data[6]."\t" . $data[7]. "\t". $data[8] ."\n";
    $j++;
  }
  else
  {
	$to_discon_session = $data[1];
	$to_discon_user_name = $data[0];
	include($engine_path."ignor_clear.php");
  }
}
if (!is_array($users)) $users = array();
ftruncate($fp,0);
fwrite($fp,implode("",$users));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);
?>