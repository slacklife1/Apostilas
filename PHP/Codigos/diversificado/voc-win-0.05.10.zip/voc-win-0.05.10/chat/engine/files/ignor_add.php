<?php
$fp = fopen($ignored_file, "a+");
if (!flock($fp, LOCK_EX)) die ("can't lock file");
fseek($fp,0);

$ign_exists=0;
$ign_users = array();

while($data = fgetcsv ($fp, 1000, "\t") )
{
	$data[1] = str_replace("\n", "", $data[1]);
	if (($data[0] == $session) and ($data[1] == $add_to_ignor)) {$ign_exists=1;break;}
	$ign_users[count($ign_users)] = $data[0]."\t".$data[1];
}
if (!$ign_exists)
{
	$ign_users[count($ign_users)] = $session . "\t" . $add_to_ignor;
}
ftruncate($fp,0);
fwrite($fp,implode("\n",$ign_users));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);
unset($ign_users);
?>