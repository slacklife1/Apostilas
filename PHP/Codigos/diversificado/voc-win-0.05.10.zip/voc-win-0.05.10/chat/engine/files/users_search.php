<?php

$ttt_users = array();
$ttt_users = file($user_data_file);

$ttt = str_replace("*","([[:alnum:]]+)",$user_to_search);

for ($i=0; $i<count($ttt_users);$i++)
{
	$user = str_replace("\n","",$ttt_users[$i]);
	list($t_id, $t_nickname, $t_password, $t_class) = explode("\t",$user);

	if (eregi($ttt,$t_nickname))
	{
		$u_ids[] = $t_id;
		$u_names[] = $t_nickname;
	}
}
unset($ttt_users);

?>