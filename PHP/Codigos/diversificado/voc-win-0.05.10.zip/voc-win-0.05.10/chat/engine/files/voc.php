<?php
function cmp($a, $b)
{
	return strcmp(strtoupper($a), strtoupper($b));
}
$users = array();

$fp = fopen($who_in_chat_file, "a+");
flock($fp, LOCK_EX);
fseek($fp,0);

$is_regist = 0;
$j = 0;
$hi = 0;
while($data = fgetcsv ($fp, 1000, "\t") )
{
	if (strtoupper($data[0]) == strtoupper($user_name))
		if (!$registered_user) 
		{
			$error_text = "$w_already_used<br><a href=\"index.php\">$w_try_again</a>";
			include($file_path."designes/".$design."/error_page.php");
			exit;
		}
		else 
		{
			$data[0] = $user_name;
			$data[1] = $session;
			$data[2] = time();
			$data[3] = 0;
			$data[4] = "";
			#check for small photo
			$tmp_name = strtolower($user_name) . ".gif";
			$tmp_name2 = strtolower($user_name) . ".jpg";
			if (file_exists($file_path."photos/$tmp_name")) 
				$data[4] = $tmp_name;
			elseif(file_exists($file_path."photos/$tmp_name2")) 
				$data[4] = $tmp_name2;
			$data[5] = $registered_user;
			$data[6] = "0";
			$data[7] = $REMOTE_ADDR;
			if (!in_array($design, $designes)) $design = $default_design;
			$data[8] = $design;
			$exists = $registered_user;
			$hi = 0;
		}
	if ($data[2] > time()-$disconnect_time) 
	{
		$users2[$j] = $data[0] . "\t" . $data[1] . "\t" . $data[2] . "\t" . $data[3] . "\t" . $data[4] . "\t" . $data[5] . "\t" . $data[6]."\t".$data[7]. "\t" . $data[8] . "\n";
		$j++;
	}
	else
	{
		$to_discon_session = $data[1];
		$to_discon_user_name = $data[0];
		include($file_path."idle_disconnect.php");
	}
}
if (!is_array($users2)) $users2 = array();
if (!$exists)
{
	$data[0] = $user_name;
	$data[1] = $session;
	$data[2] = time();
	$data[3] = 0;
	$data[4] = "";
	#check for small photo
	$tmp_name = strtolower($user_name) . ".gif";
	$tmp_name2 = strtolower($user_name) . ".jpg";
	if (file_exists($file_path."photos/$tmp_name")) 
		$data[4] = $tmp_name;
	elseif(file_exists($file_path."photos/$tmp_name2")) 
		$data[4] = $tmp_name2;
	$data[5] = $registered_user;
	$data[6] = "0";
	$data[7] = $REMOTE_ADDR;
	if (!in_array($design, $designes)) $design = $default_design;
	$data[8] = $design;
	$exists = $registered_user;
	$hi = 1;
	$users2[] = $data[0] . "\t" . $data[1] . "\t" . $data[2] . "\t" . $data[3] . "\t" . $data[4] . "\t" . $data[5] . "\t" . $data[6]."\t".$data[7]. "\t" . $data[8] . "\n";
}
usort($users2, "cmp");
$total = count($users2);
ftruncate($fp,0);
fwrite($fp,implode("",$users2));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);


?>