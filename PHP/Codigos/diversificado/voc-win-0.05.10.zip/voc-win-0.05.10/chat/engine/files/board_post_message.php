<?php

if ($max_mailbox_size>@filesize($data_path."board/".$send_to_id.".msg"))
{
	$fp = fopen($data_path."board/".$send_to_id.".msg","a+");
	if (!flock($fp, LOCK_EX)) die ("can't lock file");
	fseek($fp,0);
	
	$fs = filesize($data_path."board/".$send_to_id.".msg");
	$new_mes = intval(str_replace("\t\n","",fgets($fp, 100)))+1;
	
	$all_other =  fread ($fp,filesize($data_path."board/".$send_to_id.".msg"));
	$last_id = intval(substr($all_other,0,strpos($all_other,"\t")));
	$last_id++;
	$to_write = "$last_id\t1\t$user_name\t$is_regist\t".time()."\t$subject\t$message\t\n";
	ftruncate($fp,0);
	fwrite($fp,$new_mes."\t\n");
	fwrite($fp, $to_write.$all_other);
	
	fflush($fp);
	flock($fp, LOCK_UN);
	fclose($fp);
	$info_message = $w_message_sended;
}
else $info_message = $w_message_error;


?>
