<?
$users = file($user_data_file);


$registered_user = 0;
for ($i=0; $i<count($users);$i++)
{

	$user = str_replace("\n","",$users[$i]);
	list($t_id, $t_nickname, $t_password, $t_class) = explode("\t",$user);
	if (strcasecmp($t_nickname,$user_name)==0)
	{
		$registered_user = $t_id;
		if (!isset($password)) {$password = "";}
		if ($t_password != $password)
		{
			include($file_path."designes/".$design."/voc_password_required.php");
			exit;
		}
		break;
	}
}



if ($registered_user)
{
		$current_user = unserialize(implode("",file($data_path."users/".$registered_user.".user")));
		$bDay = $current_user->b_day;
		$bMon = $current_user->b_month;
}





?>