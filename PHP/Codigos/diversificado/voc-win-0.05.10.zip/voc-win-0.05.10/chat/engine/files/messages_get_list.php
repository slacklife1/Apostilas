<?php

unset($messages);
$messages = array();
$fp = fopen($messages_file, "a+");
flock($fp, LOCK_EX);
fseek($fp,0);

while($ttt=fgets($fp, 1024))
{
	if ($ttt !="")$messages[] = $ttt;
	#do nothing
}
flock($fp, LOCK_UN);
fclose($fp);
#$messages = file($messages_file);
if (!is_array($messages)) $messages = array();
$total_messages = count($messages);

?>