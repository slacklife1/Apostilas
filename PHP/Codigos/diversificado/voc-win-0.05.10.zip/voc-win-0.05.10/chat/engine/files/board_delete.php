<?php

if (is_array($mess_to_del) and $is_regist)
{
	$fp = fopen($data_path."board/".$is_regist.".msg","a+");
	if (!flock($fp, LOCK_EX)) die ("can't lock file");
	fseek($fp,0);
	$fs = filesize($data_path."board/".$is_regist.".msg");
	$new_mes = str_replace("\t\n","",fgets($fp, 100));
	$to_write = "";
	while($message = fgetcsv($fp, $fs, "\t\n"))
	{
		list($t_id, $status, $from_nick, $from_id, $at_date, $subject, $body) = $message;
		if ($t_id) 
			if (!in_array($t_id,$mess_to_del))
				$to_write .= "$t_id\t$status\t$from_nick\t$from_id\t$at_date\t$subject\t$body\t\n";
			else if ($status == 1) $new_mes--;
	}
	
	ftruncate($fp,0);
	fwrite($fp,$new_mes."\t\n");
	fwrite($fp, $to_write);
	
	fflush($fp);
	flock($fp, LOCK_UN);
	fclose($fp);
}

?>