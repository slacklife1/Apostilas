<?php
if ($is_regist)
{
		$current_user = unserialize(implode("",file($data_path."users/".$is_regist.".user")));
}




?>