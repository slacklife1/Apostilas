<?php
$users = array();
$users = file($user_data_file);
$t_id = 0;
for ($i=0; $i<count($users);$i++)
{
	$user = str_replace("\n","",$users[$i]);
	list($t_id, $t_nickname, $t_password, $t_class) = explode("\t",$user);
	if (strcasecmp($t_nickname,$new_user_name)==0)
	{
		$error_text ="$w_already_used<br><a href=\"registration_form.php\">$w_try_again</a>";
		include($file_path."designes/".$design."/error_page.php");
		exit;
	}
}
$t_id=intval($t_id);
$t_id++;
$users[count($users)] = "".$t_id."\t".$new_user_name."\t".$passwd1."\tuser\n";
$fp = fopen($user_data_file, "w");
flock($fp, LOCK_EX);
fwrite($fp,implode("",$users));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);

include($file_path."inc_user_class.php");
$user = new User;
$user->nickname = $new_user_name;
$user->password = $passwd1;
$user->show_group_1 = 1;
$user->show_group_2 = 1;

$fp = fopen ($data_path."users/".$t_id.".user", "w");
flock($fp, LOCK_EX);
fwrite($fp,serialize($user));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);

$fp = fopen($data_path."board/".$t_id.".msg","w");
flock($fp, LOCK_EX);
fwrite($fp,"0\t\n");
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);

$out_message =  str_replace("~", $new_user_name, $w_succesfull_reg);
?>