<?php
$fp_ign = fopen($ignored_file, "a+");
if (!flock($fp_ign, LOCK_EX)) die ("can't lock file");
fseek($fp_ign,0);
$ign_users = array();

while($data = fgetcsv ($fp_ign, 1000, "\t") )
{
	$data[1] = str_replace("\n", "", $data[1]);
	if (($data[0] != $to_discon_session))
		$ign_users[count($ign_users)] = $data[0]."\t".$data[1];
}
ftruncate($fp_ign,0);
fwrite($fp_ign,implode("\n",$ign_users));
fflush($fp_ign);
flock($fp_ign, LOCK_UN);
fclose($fp_ign);
unset($ign_users);

?>