<?php
unset($ignored_users);
$ignored_users = array();
$fp = fopen($ignored_file, "a+");
if (!flock($fp, LOCK_EX)) die ("can't lock file");
fseek($fp,0);
while($data = fgetcsv ($fp, 1000, "\t") )
{
	if (($data[0] == $session)) {$ignored_users[strtolower(str_replace("\n","",$data[1]))] = 1;}
}
flock($fp, LOCK_UN);
fclose($fp);
?>
