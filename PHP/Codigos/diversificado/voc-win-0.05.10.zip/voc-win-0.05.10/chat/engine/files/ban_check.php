<?php
function check_ban($name, $ip)
{
	$banned = 0;
	global $banlist_file;
	
	$users = array();
	$fp = fopen($banlist_file, "a+");
	if (!flock($fp, LOCK_EX)) die ("can't lock file");
	fseek($fp,0);
	while($data = fgetcsv ($fp, 1000, "\t") )
	{
		$who = $data[0];
		$until = $data[1];
		if ($until>time())
		{
			$users[count($users)] = $who."\t".$until;
			if ((strcasecmp($who, $name)==0) or ($who==$ip)) $banned = 1;
		}
	}
	ftruncate($fp,0);
	if (!is_array($users)) $users = array();
	fwrite($fp,implode("\n",$users));
	fflush($fp);
	flock($fp, LOCK_UN);
	fclose($fp);
	return $banned;
}


?>