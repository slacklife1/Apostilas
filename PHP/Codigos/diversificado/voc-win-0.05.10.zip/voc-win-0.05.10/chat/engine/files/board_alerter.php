<?php
$fp = fopen($data_path."board/".$is_regist.".msg","a+");
if (!flock($fp, LOCK_EX)) die ("can't lock file");
fseek($fp,0);
$new_board_messages = fgets($fp, 100);

if ($new_board_messages == "") $new_board_messages = "0";
//���� ��� �����
//$num = intval($num);
if (!flock($fp, LOCK_UN));
fclose($fp);
$percentage = round(filesize ($data_path."board/".$is_regist.".msg") / $max_mailbox_size *100);


?>