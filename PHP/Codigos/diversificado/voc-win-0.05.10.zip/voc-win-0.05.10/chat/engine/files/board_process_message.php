<?php
$board_message = array();

$fp = fopen($data_path."board/".$is_regist.".msg","a+");
if (!flock($fp, LOCK_EX)) die ("can't lock file");
fseek($fp,0);
$fs = filesize($data_path."board/".$is_regist.".msg");
#first string contains the number of new messages
$new_mes = str_replace("\t\n","",fgets($fp, 100));
#probably it's needed for windows version:
$new_mes = str_replace("\r","",$new_mes);

while($message = fgetcsv($fp, $fs, "\t\n"))
{
	list($t_id, $status, $from_nick, $from_id, $at_date, $subject, $body) = $message;
	if ($t_id==$id)
	{
		if ($status == 1) {$status = 0; $new_mes--;}
		if ($board_operation == "reply") $status = 2;
		if ($subject == "") $subject = $w_no_subject;
		$board_message["id"] = $id;
		$board_message["status"] = $w_stat[$status];
		$board_message["from"] = $from_nick;
		$board_message["from_id"] = $from_id;
		$board_message["subject"] = $subject;
		$board_message["date"] = date($w_date_format,$at_date);
		$board_message["body"] = $body;
	}
	if ($t_id) $to_write .= "$t_id\t$status\t$from_nick\t$from_id\t$at_date\t$subject\t$body\t\n";

}
ftruncate($fp,0);
fwrite($fp,$new_mes."\t\n");
fwrite($fp, $to_write);
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);

?>
