<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
<SCRIPT LANGUAGE="JavaScript">
<!--
window.setTimeout('location.reload()',20000);
//-->
</script>
<NOSCRIPT>
<meta http-equiv="refresh" content="20;URL=shower.php">
</noscript>
</head>

<body bgcolor="#96afff">
<center>
<table border="1" bordercolor="white" cellspacing="0" cellpadding="2">
<tr><td><?php echo $w_history;?>:</td><td><?php echo $out_users_header;?></td></tr>
<tr><td><?php echo $out_messages;?></td><td><?php echo $out_users;?></td></tr>
<tr><td colspan="2"><?php echo $w_copyright;?></td></tr>
</table>
</center>
</body>
</html>
