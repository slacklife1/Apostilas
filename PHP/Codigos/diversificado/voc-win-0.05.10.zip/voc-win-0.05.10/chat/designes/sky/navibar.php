<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
<script language="JavaScript">
<!--
function open_win(win_file, win_title)
{
window.open(win_file, win_title, 'resizable=yes,width=600,height=350,toolbar=no,scrollbars=yes,location=no,menubar=no,status=no');
}

//-->
</script>
</head>

<body bgcolor="#96afff">
<a href="javascript:;" onclick="javascript:open_win('languages/help_<?php echo $language;?>.php', 'help');"><img src="<?php echo $current_design;?>images/navi_help.gif" width="78" height="45" border="0" alt="<?php echo $w_help;?>"></a>
<a href="javascript:;" onclick="javascript:open_win('users.php?session=<?php echo $session;?>', 'usersinfo');"><img src="<?php echo $current_design;?>images/navi_users_info.gif" width="118" height="45" border="0" alt="<?php echo $w_info_about;?>"></a>
<a href="javascript:;" onclick="javascript:open_win('pictures.php?session=<?php echo $session;?>', 'pictures');"><img src="<?php echo $current_design;?>images/navi_pictures.gif" width="101" height="45" border="0" alt="<?php echo $w_pictures;?>"></a>
<a href="javascript:;" onclick="javascript:open_win('comments.php?session=<?php echo $session;?>', 'feedback');"><img src="<?php echo $current_design;?>images/navi_feedback.gif" width="108" height="45" border="0" alt="<?php echo $w_feedback;?>"></a>
<?php if (!$is_regist) {?>
<a href="javascript:;" onclick="javascript:open_win('registration_form.php?session=<?php echo $session;?>', 'registration');"><img src="<?php echo $current_design;?>images/navi_registration.gif" width="122" height="45" border="0" alt="<?php echo $w_registration; ?>"></a>
<?php }else{?>
<a href="javascript:;" onclick="javascript:open_win('user_info.php?session=<?php echo $session;?>', 'perosnalinfo');"><img src="<?php echo $current_design;?>images/navi_change_info.gif" width="118" height="45" border="0" alt="<?php echo $w_about_me;?>"></a>

<?php if  ($current_user->user_class=="admin") {?>
<a href="javascript:;" onclick="javascript:open_win('admin.php?session=<?php echo $session;?>', 'gun');"><img src="<?php echo $current_design;?>images/navi_gun.php.gif" width="79" height="45" border="0" alt="<?php echo $w_gun;?>"></a>
<?php }}?>
</body>
</html>
