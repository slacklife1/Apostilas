<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title><?php echo $w_welcome ?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>
<body bgcolor="#96afff">
<center>
<form action="voc.php" method="POST" target="_parent">
<table border="0" cellpadding="2" cellspacing="0">
<tr><td colspan="3" align="center"><img src="<?php echo $current_design;?>images/logo.gif" width="287" height="104" border="0" alt=""><a href="http://voc.sourceforge.net" target="_blank"><img src="http://voc.sourceforge.net/pr.php" width="88" height="31" border="0"></a></td></tr>
<tr><td><?php echo $w_enter_login_nick;?>:</td><td><input type="text" name="user_name" size="15" class="input" value="<?php echo $c_user_name; ?>"></td>
	<td><input type="image" src="<?php echo $current_design;?>images/buttons_login.gif" width="75" height="45" border="0"></td></tr>
<tr><td colspan="2"><small><?php echo $w_login;?></small></td><td> </td></tr>
<?php
if(count($chat_types)>1)
{?>
<tr><td><?php echo $w_select_type;?>:</td><td><select name="chat_type" class="input">
<?php
for($i=0;$i<count($chat_types);$i++)
{
	echo "<option value=\"".$chat_types[$i]."\"";
	if ($chat_type == $chat_types[$i]) echo " selected";
	echo ">".$w_chat_type[$chat_types[$i]]."</option>\n";
}
?>
</select></td><td> </td></tr><?php }?>
<?php
if(count($designes)>1)
{?>
<tr><td><?php echo $w_select_design;?>:</td><td><select name="design" onChange="javascript:parent.document.location='index.php?design='+this.options[this.selectedIndex].value;" class="input">
<?php
	for ($i=0;$i<count($designes);$i++)
	{
		echo "<option value=\"".$designes[$i]."\"";
		if ($designes[$i] == $design) echo " selected";
		echo ">".$designes[$i]."</option>\n";
	}
	echo "</select>\n";
?>
</select></td><td> </td></tr><?php }else echo "<input type=\"hidden\" name=\"design\" value=\"$design\">\n";?>

</table>
</form>

</body>
</html>
