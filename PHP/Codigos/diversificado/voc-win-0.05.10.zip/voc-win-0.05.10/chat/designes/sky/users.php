<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff">
<?php 
echo $info_message; 
if (count($u_ids))
{
	echo "$w_search_results<br>";
	for ($i=0;$i<count($u_ids);$i++)
		echo "<a href=\"fullinfo.php?user_id=".$u_ids[$i]."&session=$session\">".$u_names[$i]."</a><br>\n";
}?>
<img src="<?php echo $current_design;?>images/who_line.gif" width="224" height="9" border="0" alt="">
<br>
<?php echo $w_search;?>
<form method="post" action="users.php">
<input type="hidden" name="session" value="<?php echo $session;?>">
<table border="0"><tr><td valign="middle">
<?php echo $w_enter_nick;?>: <input type="text" name="look_for" class="input"> </td>
<td valign="middle">
<input type="image" src="<?php echo $current_design;?>images/buttons_search.gif" width="82" height="42" border="0">
</td></tr></table>
<?php echo $w_not_shure_in_nick?>
</form>
</body>
</html>
