<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
<script language="JavaScript">
<!--
function addPic(picName)
{
	opener.parent.voc_sender.document.forms[0].mesg.value = opener.parent.voc_sender.document.forms[0].mesg.value + picName;
	opener.parent.voc_sender.document.forms[0].mesg.focus();
}
//-->
</script>
</head>

<body bgcolor="#96afff"onload="window.focus();">
<?php echo $w_about_smiles;?>
<table border=1 bordercolor="white" cellpadding="2" cellspacing="0">
<tr><td><?php echo $w_symbols; ?></td><td><?php echo $w_picture;?></td></tr>
<?php
for ($i=0;$i<count($pic_phrases);$i++)
  	echo "<tr><td>".$pic_phrases[$i]."</td><td><a href=\"javascript:addPic('".$pic_phrases[$i]."');\">".$pic_urls[$i]."</a></td></tr>\n";
?>
</table>
</body>
</html>
