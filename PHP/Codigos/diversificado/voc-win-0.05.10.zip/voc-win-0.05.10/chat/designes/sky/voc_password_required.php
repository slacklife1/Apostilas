<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff" onload="javscript:document.forms[0].password.focus();">
<form method="post" action="voc.php">
<input type="hidden" name="user_name" value="<?php echo $user_name;?>">
<input type="hidden" name="chat_type" value="<?php echo $chat_type;?>">
<input type="hidden" name="design" value="<?php echo $design;?>">
<table border="0"><tr>
<td valign="middle"><?php echo $w_enter_password;?>:<input type="password" name="password" class="input"></td>
<td valign="middle"><input type="image" src="<?php echo $current_design;?>images/buttons_login.gif" width="75" height="45" border="0"></td>
</tr>
</table>
</form>
</body>
</html>
