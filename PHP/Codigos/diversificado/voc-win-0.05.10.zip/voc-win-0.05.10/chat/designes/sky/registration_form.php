<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_tilte;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff">

<form method="post" action="registration_add.php">
<?php echo $w_registration;?>
<table border="0">
<tr><td><?php echo $w_enter_login_nick;?>: </td><td><input type="text" size=15 maxlength=15 name="new_user_name" value="<?php echo $user_name; ?>" class="input"></td></tr>
<tr><td colspan="2"><small><?php echo $w_login; ?></small></td></tr>
<tr><td><?php echo $w_password;?>: </td><td><input type="password" maxlength=25 size=15 name="passwd1" class="input"></td></tr>
<tr><td><?php echo $w_confirm_password;?>: </td><td><input type="password" maxlength=25 size=15 name="passwd2" class="input"></td></tr>
</table>
<input type="image" src="<?php echo $current_design;?>images/navi_registration.gif" width="122" height="45" border="0" alt="<?php echo $w_registration;?>">
</form>

</body>
</html>
