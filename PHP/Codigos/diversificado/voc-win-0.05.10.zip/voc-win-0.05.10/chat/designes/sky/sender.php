<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
<script>
function SendTo(NickName)
{
  document.forms[0].mesg.focus();
  document.forms[0].mesg.value = document.forms[0].mesg.value + NickName + "> ";
}
</script>
</head>

<body bgcolor="#96afff" onload="javascript:document.forms[0].mesg.focus();">
<form action="sender.php" method="post" target="_self">
<input type="hidden" name="session" value="<?php echo $session; ?>">
<table border="0" cellpadding="1" cellspacing="0">
<tr><td><?php echo $w_whisper;?>:&nbsp;</td><td><?php echo $w_color;?>:</td><td colspan="2"> </td></tr>
<tr><td valign="middle">
<select name="whisper" class="input">
<option value=""><?php echo $w_no_whisper;?></option>
<?php
for ($i=0;$i<count($out_users);$i++)
{
	if ($out_users[$i]["nickname"] != $user_name)
	{
		echo "<option value=\"".$out_users[$i]["nickname"]."\"";
		if ($out_users[$i]["nickname"] == $whisper) echo " selected";
		echo ">".$out_users[$i]["nickname"]."</option>\n";
	}
}
?>
</select>
</td><td valign="middle">
<select name="user_color" class="input">
<?php for($i=0;$i<count($registered_colors);$i++)
{
	echo "<option value=\"$i\"";
	if ($i == $user_color) echo " selected";
	echo " style=\"color:".$registered_colors[$i][1]."\">".$registered_colors[$i][0]."</option>\n";
}?>
</select></td><td valign="middle">
<input type="text" name="mesg" maxlength="512" class="input" size="30"></td><td valign="middle">
<input type="image" src="<?php echo $current_design;?>images/buttons_send.gif" width="62" height="40" alt="" border="0">
<a href="logout.php?session=<?php echo $session;?>" target="_parent"><img src="<?php echo $current_design;?>images/buttons_logout.gif" width="74" height="40" alt="" border="0"></a>

</td></tr>
</table>
</form>
</body>
</html>
