<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff">
<center>
<?php echo $w_leave;?>
</center>
</body>
</html>
