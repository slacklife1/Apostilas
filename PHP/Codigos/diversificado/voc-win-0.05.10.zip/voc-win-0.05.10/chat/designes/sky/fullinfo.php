<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff">
<?php 
if (!$is_regist) echo $w_no_such_reg_user;
else
{	
	echo "$w_info <b>".$current_user->nickname.":</b>\n";
	echo "<table border=\"1\" bordercolor=\"white\" cellpadding=\"2\" cellspacing=\"0\">";
	if ($current_user->show_group_1 == 1)
	{
		echo "<tr><td>$w_name: </td><td>".$current_user->surname . " " .$current_user->firstname. "</td></tr>\n";
		echo "<tr><td>$w_birthday: </td><td>" . $current_user->b_day ." / " . $current_user->b_month ." / ".$current_user->b_year ."</td></tr>\n";
		echo "<tr><td>$w_gender: </td><td>".$sexStr."</td></tr>\n";
		echo "<tr><td>$w_city: </td><td>".$current_user->city."</td></tr>\n";
		echo "<tr><td>$w_addit_info: </td><td>". $current_user->about."</td></tr>\n";
	}
	if ($current_user->show_group_2 == 1)
	{
		echo "<tr><td>$w_email: </td><td><a href=\"mailto:" . $current_user->email . "\">".$current_user->email."</a></td></tr>\n";
		echo "<tr><td>$w_homepage: </td><td><a href=\"".$current_user->url."\" target=\"_blank\">".$current_user->url."</a></td></tr>\n";
		echo "<tr><td>$w_icq: </td><td>".$current_user->icquin."</td></tr>\n";
	}
	
	echo "<tr><td colspan=\"2\"><a href=\"board_send.php?session=$session&send_to_id=$is_regist\">$w_send_mes</a></td></tr>";
	if (($current_user->show_group_1) == 1 and ($pic_name != "")) { echo "<tr><td colspan=\"2\"><img src=\"photos/$pic_name\"></td></tr>";}
	echo "</table>";
}
?>
</body>
</html>
