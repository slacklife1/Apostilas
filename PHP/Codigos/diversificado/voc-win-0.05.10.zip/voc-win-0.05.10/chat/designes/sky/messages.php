<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
<script language="JavaScript">
<!--
window.setTimeout('location.reload()',20000);

function update()
{
	window.setTimeout('location.reload()',1000);
}
//-->
</script>
<noscript>
<?php
echo "<meta http-equiv=\"refresh\" content=\"20;URL=messages.php?session=$session\">\n";
?>
</noscript>
</head>

<body bgcolor="#96afff">
<?php echo $mod_text;?>

<?php 
for ($i=0;$i<count($out_messages);$i++)
{
	echo $out_messages[$i];
}
?>


</body>
</html>
