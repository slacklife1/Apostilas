<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_tilte;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff">
<?php if ($is_regist){?>
<a href="board_list.php?session=<?php echo $session;?>"><?php echo $w_back_to_userboard;?></a><br>

<?php 
	}
echo $info_message;?>
<?php if (count($u_ids)) {?>
<form method="post" action="board_post.php">
<input type="hidden" name="session" value="<?php echo $session;?>">
<table border="0">
<tr><td>
<?php echo $w_select_nick;?>: </td><td><select name="send_to_id" class="input">
<?php 
for($i=0;$i<count($u_ids);$i++)
{
	echo "<option value=\"".$u_ids[$i]."\">".$u_names[$i]."</option>\n";
}?>
</select></td></tr>
<tr><td><?php echo $w_subject;?>: </td><td><input type="text" name="subject" size="20" maxlength="50" value="<?php echo $tmp_subject;?>" class="input"></td></tr>
<tr><td valign="top"><?php  echo $w_message_text;?>:</td>
<td><textarea cols="40" rows="10" name="message" class="input">
<?php echo $tmp_body;?>
</textarea></td>
</table>
<input type="image" src="<?php echo $current_design;?>images/buttons_send.gif" width="62" height="40" alt="<?php echo $w_send;?>" border="0">
</form>
<?php }?>
<img src="<?php echo $current_design;?>images/who_line.gif" width="224" height="9" border="0" alt="">
<form method="post" action="board_send.php">
<input type="hidden" name="session" value="<?php echo $session;?>">

<?php echo $w_not_shure_in_nick;?>
<table border="0"><tr><td valign="middle"><?php echo $w_enter_nick;?>: <input type="text" name="send_to" maxlength="15" class="input"></td>
<td valign="middle"><input type="image" src="<?php echo $current_design;?>images/buttons_search.gif" width="82" height="42" border="0"></tr></tr>
</table>
</form>
</body>
</html>
