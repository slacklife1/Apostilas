<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff">
<?php echo $info_message;?>

<a href="user_info.php?session=<?php echo $session;?>"><?php echo $w_about_me;?></a>


</body>
</html>
