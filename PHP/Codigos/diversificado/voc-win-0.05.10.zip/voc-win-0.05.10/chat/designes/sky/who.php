<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
<SCRIPT LANGUAGE="JavaScript">
<!--
window.setTimeout('location.reload()',20000);

function info(u_name)
{
window.open('fullinfo.php?session=<?php echo $session;?>&user_id='+u_name, 'Info', 'resizable=yes,width=600,height=350,toolbar=no,scrollbars=yes,location=no,menubar=no,status=no');
}
//-->
</script>
<NOSCRIPT>
<?php
echo "<meta http-equiv=\"refresh\" content=\"20;URL=who.php?session=$session&photoss=$photoss\">\n";
?>
</noscript>	
</head>

<body bgcolor="#96afff">
<center>
<table width="230" border="0" cellpadding="0" cellspacing="0">
<tr><td align="center" colspan="3">
<?php if($photoss == "yes"){?>
<a href="who.php?session=<?php echo $session;?>&photoss=no"><img src="<?php echo $current_design;?>images/who_toggle.gif" width="188" height="52" border="0" alt="<?php echo $w_dont_show_photos;?>"></a>
<?php }else{ ?>
<a href="who.php?session=<?php echo $session;?>&photoss=yes"><img src="<?php echo $current_design;?>images/who_toggle.gif" width="188" height="52" border="0" alt="<?php echo $w_show_photos;?>"></a>
<?php }?>
</td></tr>
<tr><td align="center" colspan="3">
<?php echo "$w_in_chat: <b>$total_users</b> ".w_people($total_users);?>
</td></tr>
<tr><td colspan="3"> &nbsp;</td></tr>


<?php 
for($i=0;$i<$total_users;$i++)
{
?>
<tr><td align="left" valign="bottom">
<?php echo "<a href=\"javascript:parent.voc_sender.SendTo('".$out_users[$i]["nickname"]."')\">".$out_users[$i]["nickname"]."</a>";?> 
</td>


<?php
echo "<td valign=\"bottom\">";
if (isset($ignored_users[strtolower($out_users[$i]["nickname"])]))
	echo "<a href=\"who.php?session=$session&photoss=$photoss&remove_from_ignor=".$out_users[$i]["nickname"]."\"><img src=\"".$current_design."images/who_2visible.gif\" width=\"45\" height=\"35\" border=\"0\" alt=\"make visible\"></a>";
else echo "<a href=\"who.php?session=$session&photoss=$photoss&add_to_ignor=".$out_users[$i]["nickname"]."\"><img src=\"".$current_design."images/who_2ignor.gif\" width=\"41\" height=\"35\" border=\"0\" alt=\"ignore\"></a>";
echo "</td><td valign=\"bottom\">";
if ($out_users[$i]["user_id"])
{
	if (($photoss == "yes") and ($out_users[$i]["small_photo"] != ""))
	{
		echo "<a href=\"javascript:;\" onclick=\"javascript:info('".$out_users[$i]["user_id"]."')\"><img src=\"photos/".$out_users[$i]["small_photo"]."\" border=\"0\" width=\"40\" heigth=\"40\"></a>";
	}
	else 
	{
		echo "<a href=\"javascript:;\" onclick=\"javascript:info('".$out_users[$i]["user_id"]."')\"><img src=\"".$current_design."images/who_info.gif\" width=\"59\" height=\"35\" border=\"0\" alt=\"$w_info\"></a>";
	}

}
else echo "&nbsp;";
echo "</td></tr>";
?>

<tr><td height="9" valign="top" colspan="3">
<img src="<?php echo $current_design;?>images/who_line.gif" width="224" height="9" border="0" alt="">
</td></tr>
<?php
}
?>



</table>
</center>
</body>
</html>
