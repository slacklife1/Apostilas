<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
<script language="JavaScript">
<!--
    window.setTimeout("location.reload()",60000);
function open_win(win_file, win_title)
{
window.open(win_file, win_title, 'resizable=yes,width=500,height=350,toolbar=no,scrollbars=yes,location=no,menubar=no,status=no');
}

//-->
</script>
<noscript>
<?php
echo "<meta http-equiv=\"refresh\" content=\"60;URL=alerter.php?session=$session\">\n";
?>
</noscript>
</head>

<body bgcolor="#96afff" background="<?php echo $current_design;?>images/back_alerter_blank.gif">
<a href="javascript:;" onclick="javascript:open_win('board_list.php?session=<?php echo $session;?>');"><?php echo $w_pub;?></a>
 - (<?php echo "$new_board_messages $w_new";?>, <?php echo $percentage;?>%<?php echo $w_used;?>) <br>
<a href="javascript:;" onclick="javascript:open_win('board_send.php?session=<?php echo $session;?>');"><?php echo $w_send_mes;?></a>
</body>
</html>
