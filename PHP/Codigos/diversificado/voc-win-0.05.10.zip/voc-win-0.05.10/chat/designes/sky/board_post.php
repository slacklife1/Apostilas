<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_tilte;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff">
<?php echo $info_message;?>
<br>
<img src="<?php echo $current_design;?>images/who_line.gif" width="224" height="9" border="0" alt="">
<br>
<?php if ($is_regist){?>
<a href="board_list.php?session=<?php echo $session;?>"><?php echo $w_back_to_userboard;?></a> &nbsp; &nbsp; 
<?php }?>
<a href="board_send.php?session=<?php echo $session;?>"><?php echo $w_back_to_send;?></a>
</body>
</html>
