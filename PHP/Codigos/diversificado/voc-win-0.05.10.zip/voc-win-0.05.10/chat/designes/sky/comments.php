<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff">

<?php echo $w_feed_headline; ?><br>


<form method="post" action="comments_send.php">

<table border="0">
<tr><td><?php echo $w_feed_name;?>: </td><td><input type="text" name="name" class="input"></td></tr>
<tr><td>eMail: </td><td><input type="text" name="email" class="input"></td></tr>
<tr><td valign="top"><?php echo $w_feed_message;?>: </td><td>
<textarea name="comment" rows="10" cols="35" class="input"></textarea></td></tr>
<tr><td colspan="2"><input type="image" src="<?php echo $current_design;?>images/buttons_send.gif" width="62" height="40" alt="" border="0"></td></tr>
</table>
</form>
</body>
</html>
