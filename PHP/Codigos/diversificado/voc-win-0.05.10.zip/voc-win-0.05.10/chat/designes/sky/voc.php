<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<frameset cols="*,250" frameborder="no" framespacing="0" border="0" borderwidth="0">
  <frameset rows="50,*, 60" frameborder="no" framespacing="0" border="0" borderwidth="0">
    <frame src="navibar.php?session=<?php echo $session;?>" noresize scrolling="no" marginwidth="0" marginheight="0">
    <frame src="<?php echo $shower;?>" name="voc_shower" noresize>
    <frame src="sender.php?session=<?php echo $session; ?>&user_color=<?php echo $user_color; ?>" name="voc_sender" noresize scrolling="no" marginwidth="0" marginheight="0">
  </frameset>
  <frameset rows="50, *" frameborder="no" framespacing="0" border="0" borderwidth="0">
    <frame src="<?php
	if ($registered_user)
		echo "alerter.php?session=$session";
	else echo $current_design."alerter_blank.php";
	
	
	?>" noresize scrolling="no" marginwidth="0" marginheight="0">

	<frame src="who.php?session=<?php echo $session;?>" name="voc_who" marginwidth="0" marginheight="0">
  </frameset>
</frameset>
</html>

