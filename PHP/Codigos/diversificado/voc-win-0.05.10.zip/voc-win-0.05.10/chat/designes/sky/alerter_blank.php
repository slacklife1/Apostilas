<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<?php include("../../inc_common.php");?>
<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff" background="<?php echo $current_design;?>images/back_alerter_blank.gif">
&nbsp;
</body>
</html>
