<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_tilte;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff">

<?php 
echo "<b>$w_from:</b> ".$board_message["from"]."<br><b>$w_at_date:</b> ".$board_message["date"]."<br><b>$w_subject:</b> ".htmlspecialchars($board_message["subject"])."\n";
echo "<br><img src=\"".$current_design."images/who_line.gif\" width=\"224\" height=\"9\" border=\"0\" alt=\"\"><br>";
echo $board_message["body"];
?>
<br>
<img src="<?php echo $current_design;?>images/who_line.gif" width="224" height="9" border="0" alt="">
<br>

<?php if ($board_message["from_id"]){?>
<a href="board_send.php?session=<?php echo $session;?>&message_id=<?php echo $board_message["id"];?>"><img src="<?php echo $current_design;?>images/buttons_reply.gif" width="65" height="48" border="0" alt="<?php echo $w_answer;?>"></a> &nbsp; &nbsp; &nbsp; &nbsp;
<?php }?>
<a href="board_delete.php?session=<?php echo $session;?>&mess_to_del[]=<?php echo $board_message["id"];?>"><img src="<?php echo $current_design;?>images/buttons_delete.gif" width="68" height="48" border="0" alt="<?php echo $w_delete;?>"></a><br>
<br><a href="board_list.php?session=<?php echo $session;?>"><?php echo $w_back_to_userboard;?></a><br>
</body>
</html>
