<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_tilte;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff">
<form method="post" action="board_delete.php">
<input type="hidden" name="session" value="<?php echo $session;?>">
<table border="0">
<tr><td><?php echo $w_status;?>&nbsp;</td><td><?php echo $w_from;?>&nbsp;</td><td><?php echo $w_subject;?>&nbsp;</td><td><?php echo $w_at_date;?>&nbsp;</td><td></td></tr>
<tr><td height="9" valign="top" colspan="5">
<img src="<?php echo $current_design;?>images/who_line.gif" width="224" height="9" border="0" alt="">
</td></tr>

<?php
for ($i=0;$i<count($board_messages);$i++)
{
?>
<tr><td><?php echo $board_messages[$i]["status"];?></td>
<td><?php echo $board_messages[$i]["from"];?></td>
<td>
<a href="board_view.php?session=<?php echo $session;?>&id=<?php echo $board_messages[$i]["id"];?>"><?php echo htmlspecialchars($board_messages[$i]["subject"]);?> </a></td>
<td><?php echo $board_messages[$i]["date"];?></td>
<td><input type="checkbox" name="mess_to_del[]" value="<?php echo $board_messages[$i]["id"];?>"></td></tr>
<tr><td height="9" valign="top" colspan="5">
<img src="<?php echo $current_design;?>images/who_line.gif" width="224" height="9" border="0" alt="">
</td></tr>

<?php }?>
</table>
<input type="image" src="<?php echo $current_design;?>images/buttons_delete_checked.gif" width="137" height="49" border="0" alt="<?php echo $w_del_checked;?>">
</form>
</body>
</html>
