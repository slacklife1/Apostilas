<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff">
<form method=post action="user_info_update.php"s enctype="multipart/form-data">
<input type="hidden" name="MAX_FILE_SIZE" value="300000">
<input type="hidden" name="session" value="<?php echo $session;?>">
<?php echo $w_personal_data.", <b>".$current_user->nickname ."</b>:<br>";?>
<img src="<?php echo $current_design;?>images/who_line.gif" width="224" height="9" border="0" alt=""><br>
<input type=checkbox name="showGroup1"<?php if ($current_user->show_group_1 == 1) echo " checked";?>><?php echo $w_show_data;?>

<table border="0">
<tr><td><?php echo $w_surname;?>: </td><td><input type="text" size="15" name="surname" value="<?php echo $current_user->surname;?>" class="input"></td></tr>
<tr><td><?php echo $w_name;?>: </td><td><input type="text" size="15" name="firstname" value="<?php echo $current_user->firstname;?>" class="input"></td></tr>
<tr><td><?php echo $w_birthday;?>: </td><td><select name="day" class="input"><option value="">--</option>
<?php
for ($i=1; $i<32; $i++)
{
	echo "<option";
	if ($i == $current_user->b_day) echo " selected";
	echo ">$i\n";
}?></select> / <select name="month" class="input"><option value="">--</option>
<?php
for ($i=1; $i<13; $i++)
{
	echo "<option";
	if ($i == $current_user->b_month) echo " selected";
	echo ">$i\n";
}?></select> / <select name="year" class="input"><option value="">--</option>
<?php
for ($i=1950; $i<2001; $i++)
{
	echo "<option";
	if ($i == $current_user->b_year) echo " selected";
	echo ">$i\n";
}?></select></td></tr>
<tr><td><?php echo $w_city;?>: </td><td><input type="text" name="city" size="10" value="<?php echo $current_user->city;?>" class="input"></td></tr>
<?php
echo "<tr><td>$w_gender: </td><td><select name=\"sex\" class=\"input\">";
$sex = $current_user->sex;
echo "<option value=0";
if ($sex == 0) echo " selected";
echo ">$w_unknown</option>\n<option value=1";
if ($sex == 1) echo " selected";
echo ">$w_male</option>\n<option value=2";
if ($sex == 2) echo " selected";
echo ">$w_female</option>\n</select></td></tr>\n";

#small picture:
echo "<tr><td>$w_small_photo: </td><td>";
if ($small_picture != "")
	echo "<img src=\"photos/$small_picture\"><br><input type=\"checkbox\" name=\"sm_del\">$w_check_for_delete<br>";
echo "$w_other_photo <input type=\"file\" name=\"small_photo\" class=\"input\"></td></tr>";


echo "<tr><td>$w_big_photo: </td><td>";
if ($big_picture != "") 
{
	echo "<img src=\"photos/$big_picture\"><br>";
	echo "<input type=\"checkbox\" name=\"big_del\">$w_check_for_delete<br>";

}
	echo "$w_other_photo <input type=\"file\" name=\"big_photo\" class=\"input\"></td></tr>";
?>
<tr><td><?php echo $w_addit_info?>: </td><td>
<textarea name="comments" rows="10" cols="30" class="input"><?php echo str_replace("<br>","\n",$current_user->about);?>
</textarea></td></tr>
</table>
<img src="<?php echo $current_design;?>images/who_line.gif" width="224" height="9" border="0" alt="">
<br>
<input type=checkbox name="showGroup2"<?php if ($current_user->show_group_2 == 1) echo " checked";?>><?php echo $w_show_data;?><br>
<table border="0">
<tr><td><?php echo $w_email;?>: </td><td><input type="text" size="15" name="email" value="<?php echo $current_user->email;?>" class="input"></td></tr>
<tr><td><?php echo $w_homepage;?>: </td><td><input type="text" size="15" name="url" value="<?php echo $current_user->url;?>" class="input"></td></tr>
<tr><td><?php echo $w_icq;?>: </td><td><input type="text" size="15" name="icquin" value="<?php echo $current_user->icquin;?>" class="input"></td></tr>
</table>
<img src="<?php echo $current_design;?>images/who_line.gif" width="224" height="9" border="0" alt="">
<table border="0">
<tr><td colspan="2"><?php echo $w_if_wanna_change_password;?></td></tr>
<tr><td><?php echo $w_new_password;?>: </td><td><input type="password" name="passwd1" class="input"></td></tr>
<tr><td><?php echo $w_confirm_password;?>: </td><td><input type="password" name="passwd2" class="input"></td></tr>
</table>
<img src="<?php echo $current_design;?>images/who_line.gif" width="224" height="9" border="0" alt="">
<br>
<input type="image" src="<?php echo $current_design;?>images/buttons_update.gif" width="76" height="45" border="0" alt="<?php echo $w_update;?>">
</form>
</body>
</html>
