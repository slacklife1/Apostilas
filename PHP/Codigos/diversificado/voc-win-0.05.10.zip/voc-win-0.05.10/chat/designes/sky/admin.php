<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_tilte;?></title>
	<link rel="STYLESHEET" type="text/css" href="<?php echo $current_design;?>sky_style.css">
</head>

<body bgcolor="#96afff">

<body>
<?php echo $w_select_nick;?>: <form method="post" action="admin.php">
<input type="hidden" name="session" value="<?php echo $session;?>">
<?php
for ($i=0; $i<count($users); $i++)
{
  $data = explode("\t", $users[$i]);
  $name = $data[0];
  $ip = str_replace("\n","",$data[7]);
  echo "<input type=\"radio\" name=\"toBan\" value=\"$name:$ip\">$name, $ip<br>\n";
}
?><br>
<table border="0">
<tr><td><?php echo $w_admin_action;?>: </td><td><select name="action" class="input">
<option value=1><?php echo $w_admin_alert;?></option>
<option value=2><?php echo $w_admin_kill;?></option>
<option value=3><?php echo $w_admin_ip_kill;?></option>
</select></td></tr>
<tr><td><?php echo $w_kill_time;?>: </td><td><select name="kill_time" class="input">
<?php
for ($i=0;$i<count($w_times);$i++)
{
	echo "<option value=\"$i\">".$w_times[$i]["name"]."</option>";
}?>
</select></td></tr>
<tr><td><?php echo $w_admin_reason;?>: </td><td><input type="text" name="cause" class="input"></td></tr>
</table>
<input type="image" src="<?php echo $current_design;?>images/buttons_gun.gif" width="73" height="42" border="0" alt="<?php echo $w_admin_ban;?>">

</form>


</body>
</html>
