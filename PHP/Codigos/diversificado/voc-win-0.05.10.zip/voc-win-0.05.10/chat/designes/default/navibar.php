<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body>
<a href="languages/help_<?php echo $language;?>.php" target="_blank"><?php echo $w_help;?></a>
<a href="users.php?session=<?php echo $session;?>" target="_blank"><?php echo $w_info_about;?></a>
<a href="pictures.php?session=<?php echo $session;?>" target="_blank"><?php echo $w_pictures;?></a>
<a href="comments.php?session=<?php echo $session;?>" target="_blank"><?php echo $w_feedback;?></a>
<?php if (!$is_regist) {?>
<a href="registration_form.php?session=<?php echo $session;?>" target="_blank"><?php echo $w_registration; ?></a>
<?php }else{?>
<a href="user_info.php?session=<?php echo $session;?>" target="_blank"><?php echo $w_about_me;?></a>

<?php if  ($current_user->user_class=="admin") {?>
<a href="admin.php?session=<?php echo $session;?>" target="_blank"><?php echo $w_gun;?></a>
<?php }}?>
</body>
</html>
