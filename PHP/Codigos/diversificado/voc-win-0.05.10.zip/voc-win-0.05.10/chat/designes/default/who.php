<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
<SCRIPT LANGUAGE="JavaScript">
<!--
window.setTimeout('location.reload()',20000);
//-->
</script>
<NOSCRIPT>
<?php
echo "<meta http-equiv=\"refresh\" content=\"20;URL=who.php?session=$session&photoss=$photoss\">\n";
?>
</noscript>	
</head>

<body>
<?php if($photoss == "yes"){?>
<a href="who.php?session=<?php echo $session;?>&photoss=no"><?php echo $w_dont_show_photos;?></a>
<?php }else{ ?>
<a href="who.php?session=<?php echo $session;?>&photoss=yes"><?php echo $w_show_photos;?></a>
<?php }?>
<hr>
<?php echo "$w_in_chat: <b>$total_users</b> ".w_people($total_users);?>
<hr>
<?php 
for($i=0;$i<$total_users;$i++)
{
?>
<?php echo $out_users[$i]["nickname"];?> 


<?php if ($out_users[$i]["user_id"]) {?> <a href="fullinfo.php?user_id=<?php echo $out_users[$i]["user_id"];?>&session=<?php echo $session;?>" target="_blank">info</a> <?php }?>


<?php if (isset($ignored_users[strtolower($out_users[$i]["nickname"])])) {?>
<a href="who.php?session=<?php echo $session;?>&photoss=<?php echo $photoss;?>&remove_from_ignor=<?php echo $out_users[$i]["nickname"];?>">+2visible</a>
<?php }else{?>
<a href="who.php?session=<?php echo $session;?>&photoss=<?php echo $photoss;?>&add_to_ignor=<?php echo $out_users[$i]["nickname"];?>">-2ignor</a>
<?php }?>

<?php if (($photoss == "yes") and ($out_users[$i]["small_photo"] != "")) {?>
<img src="photos/<?php echo $out_users[$i]["small_photo"];?>" border="0" width="40" heigth="40">
<?php }?>

<br>

<?php
}
?>

</body>
</html>
