<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body bgcolor="white">

<form method="post" action="registration_add.php">
<?php echo $w_registration;?>
<?php echo $w_enter_login_nick;?>: <input type="text" size=15 maxlength=15 name="new_user_name" value="<?php echo $user_name; ?>"><br>
<?php echo $w_login; ?><br>
<?php echo $w_password;?>: <input type="password" maxlength=25 size=15 name="passwd1"><br>
<?php echo $w_confirm_password;?>: <input type="password" maxlength=25 size=15 name="passwd2"><br>
<input type="submit" value="<?php echo $w_registration;?>">
</form>

</body>
</html>
