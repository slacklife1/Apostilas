<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body>
<?php echo $info_message;?>
<hr>

<?php if ($is_regist){?>
<a href="board_list.php?session=<?php echo $session;?>"><?php echo $w_back_to_userboard;?></a><br>
<?php }?>
<a href="board_send.php?session=<?php echo $session;?>"><?php echo $w_back_to_send;?></a>
</body>
</html>
