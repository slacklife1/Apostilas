<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body>
<?php echo $w_select_nick;?>: <form method="post" action="admin.php">
<input type="hidden" name="session" value="<?php echo $session;?>">
<?php
for ($i=0; $i<count($users); $i++)
{
  $data = explode("\t", $users[$i]);
  $name = $data[0];
  $ip = str_replace("\n","",$data[7]);
  echo "<input type=\"radio\" name=\"toBan\" value=\"$name:$ip\">$name, $ip<br>\n";
}
?><br>

<?php echo $w_admin_action;?>: <select name="action">
<option value=1><?php echo $w_admin_alert;?></option>
<option value=2><?php echo $w_admin_kill;?></option>
<option value=3><?php echo $w_admin_ip_kill;?></option>
</select><br>
<?php echo $w_kill_time;?>: <select name="kill_time">
<?php
for ($i=0;$i<count($w_times);$i++)
{
	echo "<option value=\"$i\">".$w_times[$i]["name"]."</option>";
}?>
</select><br>
<?php echo $w_admin_reason;?>: <input type="text" name="cause">
<br><input type="submit" value="<?php echo $w_admin_ban;?>">
</form>


</body>
</html>
