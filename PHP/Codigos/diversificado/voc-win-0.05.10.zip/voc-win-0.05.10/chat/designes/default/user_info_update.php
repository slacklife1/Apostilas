<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body>
<?php echo $info_message;?>

<a href="user_info.php?session=<?php echo $session;?>"><?php echo $w_about_me;?></a>


</body>
</html>
