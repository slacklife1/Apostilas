<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body bgcolor="white">
<form method=post action="user_info_update.php"s enctype="multipart/form-data">
<input type="hidden" name="MAX_FILE_SIZE" value="300000">
<input type="hidden" name="session" value="<?php echo $session;?>">
<?php echo $w_personal_data.", <b>".$current_user->nickname ."</b>:<br>";?>

<input type=checkbox name="showGroup1"<?php if ($current_user->show_group_1 == 1) echo " checked";?>><?php echo $w_show_data;?><br>
<?php echo $w_surname;?>: <input type="text" size="15" name="surname" value="<?php echo $current_user->surname;?>"><br>
<?php echo $w_name;?>: <input type="text" size="15" name="firstname" value="<?php echo $current_user->firstname;?>"><br>
<?php echo $w_birthday;?>: <select name="day"><option value="">--</option>
<?php
for ($i=1; $i<32; $i++)
{
	echo "<option";
	if ($i == $current_user->b_day) echo " selected";
	echo ">$i\n";
}?></select> / <select name="month"><option value="">--</option>
<?php
for ($i=1; $i<13; $i++)
{
	echo "<option";
	if ($i == $current_user->b_month) echo " selected";
	echo ">$i\n";
}?></select> / <select name="year"><option value="">--</option>
<?php
for ($i=1950; $i<2001; $i++)
{
	echo "<option";
	if ($i == $current_user->b_year) echo " selected";
	echo ">$i\n";
}?></select><br>
<?php echo $w_city;?>: <input type="text" name="city" size="10" value="<?php echo $current_user->city;?>"><br>
<?php
echo "$w_gender: <select name=\"sex\">";
$sex = $current_user->sex;
echo "<option value=0";
if ($sex == 0) echo " selected";
echo ">$w_unknown</option>\n<option value=1";
if ($sex == 1) echo " selected";
echo ">$w_male</option>\n<option value=2";
if ($sex == 2) echo " selected";
echo ">$w_female</option>\n</select><br>\n";

#small picture:
echo "$w_small_photo: <br>";
if ($small_picture != "")
	echo "<img src=\"photos/$small_picture\"><br><input type=\"checkbox\" name=\"sm_del\">$w_check_for_delete<br>";
echo "$w_other_photo <input type=\"file\" name=\"small_photo\"><br><br>";


echo "$w_big_photo: <br>";
if ($big_picture != "") 
{
	echo "<img src=\"photos/$big_picture\"><br>";
	echo "<input type=\"checkbox\" name=\"big_del\">$w_check_for_delete<br>";

}
	echo "$w_other_photo <input type=\"file\" name=\"big_photo\">";
?>
<br>
<?php echo $w_addit_info?>: 
<textarea name="comments" rows="10" cols="30"><?php echo str_replace("<br>","\n",$current_user->about);?>
</textarea>
<hr>
<input type=checkbox name="showGroup2"<?php if ($current_user->show_group_2 == 1) echo " checked";?>><?php echo $w_show_data;?><br>

<?php echo $w_email;?>: <input type="text" size="15" name="email" value="<?php echo $current_user->email;?>"><br>
<?php echo $w_homepage;?>: <input type="text" size="15" name="url" value="<?php echo $current_user->url;?>"><br>
<?php echo $w_icq;?>: <input type="text" size="15" name="icquin" value="<?php echo $current_user->icquin;?>">
<hr>
<?php echo $w_if_wanna_change_password;?> <br>
<?php echo $w_new_password;?>: <input type="password" name="passwd1"><br>
<?php echo $w_confirm_password;?>: <input type="password" name="passwd2"><br>
<hr>
<input type="submit" value="<?php echo $w_update;?>">

</form>
</body>
</html>
