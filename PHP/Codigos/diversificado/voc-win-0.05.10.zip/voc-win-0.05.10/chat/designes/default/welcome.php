<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title><?php echo $w_welcome ?></title>
</head>
<body bgcolor=white>

<form action="voc.php" method="POST" target="_parent">
<?php echo $w_title ?><br><a href="http://voc.sourceforge.net" target="_blank"><img src="http://voc.sourceforge.net/pr.php" width="88" height="31" border="0"></a><br>
<?php echo $w_enter_login_nick;?>:<input type="text" name="user_name" size=15 value="<?php echo $c_user_name; ?>"><br>
<?php
if(count($chat_types)>1)
{
 echo $w_select_type;?>:<br>
<select name="chat_type" class="input">
<?php
for($i=0;$i<count($chat_types);$i++)
{
	echo "<option value=\"".$chat_types[$i]."\"";
	if ($chat_type == $chat_types[$i]) echo " selected";
	echo ">".$w_chat_type[$chat_types[$i]]."</option>\n";
}
?>
</select>
<?php }?>

<?php
if(count($designes)>1)
{
	echo "$w_select_design: <select name=\"design\" onChange=\"javascript:parent.document.location='index.php?design='+this.options[this.selectedIndex].value;\">";
	for ($i=0;$i<count($designes);$i++)
	{
		echo "<option value=\"".$designes[$i]."\"";
		if ($designes[$i] == $design) echo " selected";
		echo ">".$designes[$i]."</option>\n";
	}
	echo "</select>\n";
}
else echo "<input type=\"hidden\" name=\"design\" value=\"$design\">\n";
?>
<br>
<input type="Submit" value="<?php echo $w_login_button ?>">

</form>
</body>
</html>
