<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>
<frameset cols="*,250" frameborder="no" framespacing="0" border="0" borderwidth="0">
  <frameset rows="31,*, 60" frameborder="no" framespacing="0" border="0" borderwidth="0">
    <frame src="navibar.php?session=<?php echo $session;?>" noresize scrolling="no" marginwidth="0" marginheight="0">
    <frame src="<?php echo $shower;?>" name="voc_shower" noresize>
    <frame src="sender.php?session=<?php echo $session; ?>&user_color=<?php echo $user_color; ?>" name="voc_sender" noresize scrolling="no" marginwidth="0" marginheight="0">
  </frameset>
<?php

if ($registered_user)
{

?>
  <frameset rows="*, 60" frameborder="no" framespacing="0" border="0" borderwidth="0">
	<frame src="who.php?session=<?php echo $session;?>" name="voc_who" marginwidth="0" marginheight="0">
    <frame src="alerter.php?session=<?php echo $session;?>" noresize scrolling="no" marginwidth="0" marginheight="0">
  </frameset>
<?php
}
else
{
?>
	<frame src="who.php?session=<?php echo $session;?>" name="voc_who" marginwidth="0" marginheight="0">
<?php
}
?>
</frameset>
</html>
