<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body>
<?php if ($is_regist){?>
<a href="board_list.php?session=<?php echo $session;?>"><?php echo $w_back_to_userboard;?></a><br>

<?php 
	}
echo $info_message;?>
<?php if (count($u_ids)) {?>
<form method="post" action="board_post.php">
<input type="hidden" name="session" value="<?php echo $session;?>">
<?php echo $w_select_nick;?>: <select name="send_to_id">
<?php 
for($i=0;$i<count($u_ids);$i++)
{
	echo "<option value=\"".$u_ids[$i]."\">".$u_names[$i]."</option>\n";
}?>
</select><br>
<?php echo $w_subject;?>: <input type="text" name="subject" size="20" maxlength="50" value="<?php echo $tmp_subject;?>"><br>
<?php  echo $w_message_text;?>:<br>
<textarea cols="40" rows="10" name="message">
<?php echo $tmp_body;?>
</textarea>
<br>
<input type="submit" value="<?php echo $w_send;?>">
</form>
<?php }?>
<hr>
<form method="post" action="board_send.php">
<input type="hidden" name="session" value="<?php echo $session;?>">

<?php echo $w_not_shure_in_nick."<br>".$w_enter_nick;?>: <input type="text" name="send_to" maxlength="15">
<input type="submit" value="<?php echo $w_search_button;?>">
</form>
</body>
</html>
