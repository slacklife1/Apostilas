<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body>

<?php 
echo "<b>$w_from:</b> ".$board_message["from"]."<br><b>$w_at_date:</b> ".$board_message["date"]."<br><b>$w_subject:</b> ".htmlspecialchars($board_message["subject"])."<hr>\n";
echo $board_message["body"];
?>
<hr>
<a href="board_list.php?session=<?php echo $session;?>"><?php echo $w_back_to_userboard;?></a><br>
<?php if ($board_message["from_id"]){?>
<a href="board_send.php?session=<?php echo $session;?>&message_id=<?php echo $board_message["id"];?>"><?php echo $w_answer;?></a><br>
<?php }?>
<a href="board_delete.php?session=<?php echo $session;?>&mess_to_del[]=<?php echo $board_message["id"];?>"><?php echo $w_delete;?></a><br>

</body>
</html>
