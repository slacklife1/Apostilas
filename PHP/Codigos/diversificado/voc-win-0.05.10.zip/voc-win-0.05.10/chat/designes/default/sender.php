<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body>
<form action="sender.php" method="post" target="_self">
<input type="hidden" name="session" value="<?php echo $session; ?>">
<?php echo $w_whisper;?><select name="whisper">
<option value=""><?php echo $w_no_whisper;?></option>
<?php
for ($i=0;$i<count($out_users);$i++)
{
	if ($out_users[$i]["nickname"] != $user_name)
	{
		echo "<option value=\"".$out_users[$i]["nickname"]."\"";
		if ($out_users[$i]["nickname"] == $whisper) echo " selected";
		echo ">".$out_users[$i]["nickname"]."</option>\n";
	}
}
?>
</select>
<?php echo $w_color;?>
<select name="user_color">
<?php for($i=0;$i<count($registered_colors);$i++)
{
	echo "<option value=\"$i\"";
	if ($i == $user_color) echo " selected";
	echo ">".$registered_colors[$i][0]."</option>\n";
}?>
</select>
<input type="text" name="mesg" maxlength="512">
<input type="submit" value="<?php echo $w_say;?>">
<input type="button" value="<?php echo $w_logout;?>" onclick="javascript:parent.location='logout.php?session=<?php echo $session;?>';">
</form>
</body>
</html>
