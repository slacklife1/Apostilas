<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body bgcolor="white" onload="javscript:document.forms[0].password.focus();">
<form method="post" action="voc.php"><?php echo $w_enter_password;?>:
<input type="hidden" name="user_name" value="<?php echo $user_name;?>">
<input type="hidden" name="chat_type" value="<?php echo $chat_type;?>">
<input type="hidden" name="design" value="<?php echo $design;?>">
<input type="password" name="password"><br>
<input type="submit" value="<?php echo $w_login_button;?>">
</body>
</html>
