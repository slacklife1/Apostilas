<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title><?php echo $w_welcome;?></title>
</head>
<frameset rows="180,*"  frameborder=no framespacing=0 border=0 borderwidth=0>
  <frame src="welcome.php?design=<?php echo $design; ?>" noresize scrolling="no" marginwidth=2 marginheight=2>
  <frame src="shower.php?design=<?php echo $design; ?>" noresize marginwidth=2 marginheight=2>
</frameset>
</html>
