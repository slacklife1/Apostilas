<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body>
<?php 
echo $info_message; 
if (count($u_ids))
{
	echo "$w_search_results<br>";
	for ($i=0;$i<count($u_ids);$i++)
		echo "<a href=\"fullinfo.php?user_id=".$u_ids[$i]."&session=$session\">".$u_names[$i]."</a><br>\n";
}?>
<hr>

<?php echo $w_search;?>
<form method="post" action="users.php">
<input type="hidden" name="session" value="<?php echo $session;?>">
<?php echo $w_enter_nick;?>: <input type="text" name="look_for"> 
<input type="submit" value="<?php echo $w_search_button;?>"><br>
<?php echo $w_not_shure_in_nick?>
</form>
</body>
</html>
