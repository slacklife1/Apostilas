<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
<script language="JavaScript">
<!--
    window.setTimeout("location.reload()",60000);
//-->
</script>
<noscript>
<?php
echo "<meta http-equiv=\"refresh\" content=\"60;URL=alerter.php?session=$session\">\n";
?>
</noscript>
</head>

<body bgcolor="white">
<a href="board_list.php?session=<?php echo $session;?>" target="_blank"><?php echo $w_pub;?></a>
 - (<?php echo "$new_board_messages $w_new";?>, <?php echo $percentage;?>%<?php echo $w_used;?>) <br>
<a href="board_send.php?session=<?php echo $session;?>" target="_blank"><?php echo $w_send_mes;?></a>
</body>
</html>
