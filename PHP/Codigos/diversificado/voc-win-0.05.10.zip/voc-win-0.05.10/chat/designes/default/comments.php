<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body>

<?php echo $w_feed_headline; ?><br>


<form method="post" action="comments_send.php">
<?php echo $w_feed_name;?>: <input type="text" name="name"><br>
eMail: <input type="text" name="email"><br>
<?php echo $w_feed_message;?>:<br>
<textarea name="comment" rows="10" cols="35"></textarea><br>
<input type="submit" value="<?php echo $w_send;?>">
</form>
</body>
</html>
