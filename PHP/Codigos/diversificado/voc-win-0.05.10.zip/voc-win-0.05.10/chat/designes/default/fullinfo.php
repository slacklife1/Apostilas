<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title><?php echo $w_title;?></title>
</head>

<body>
<?php 
if (!$is_regist) echo $w_no_such_reg_user;
else
{	
	echo "$w_info <b>".$current_user->nickname.":</b><br>\n";
	if ($current_user->show_group_1 == 1)
	{
		if ($pic_name != "") { echo "<img src=\"photos/$pic_name\"><br>\n";}
		echo "$w_name: ".$current_user->surname . " " .$current_user->firstname. "<br>\n";
		echo "$w_birthday: " . $current_user->b_day ." / " . $current_user->b_month ." / ".$current_user->b_year ."<br>\n";
		echo "$w_gender: ".$sexStr."<br>\n";
		echo "$w_addit_info: ". $current_user->about."<br>\n";
	}
	if ($current_user->show_group_2 == 1)
	{
		echo "$w_email: <a href=\"mailto:" . $current_user->email . "\">".$current_user->email."</a><br>\n";
		echo "$w_homepage:<a href=\"".$current_user->url."\" target=\"_blank\">".$current_user->url."</a><br>\n";
		echo "$w_icq: ".$current_user->icquin."<br>\n";
	}
	
	echo "<a href=\"board_send.php?session=$session&send_to_id=$is_regist\">$w_send_mes</a>";
}
?>
</body>
</html>
