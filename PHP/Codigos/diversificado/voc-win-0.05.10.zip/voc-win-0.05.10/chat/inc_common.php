<?php
if (!defined("_COMMON_")):
define("_COMMON_", 1);

# the path, where stored all data -- i.e. messages, user-boards etc. and also config file
#Recommended to put this directory outside of your web-site access-path
$data_path = "c:/inetpub/data/";





#loading parameters from config file
eval(implode("",file($data_path."voc.conf")));




#loading language pack
include($file_path."languages/".$language.".php");


#determening the current design
if (!isset($design)) $design = $default_design;
else if (!in_array($design, $designes)) $design = $default_design;
$current_design = $chat_url."designes/".$design."/";


#setting necessary variables
$daemon_url = $daemon_host.":".$daemon_port."/";
$engine_path = $file_path."engine/".$engine."/";
$ld_engine_path = $file_path."engine/".$long_life_data_engine."/";

$user_data_file = $data_path."users.dat";
$who_in_chat_file = $data_path."who.dat";
$messages_file = $data_path."messages.dat";
$ignored_file = $data_path."ignored.dat";
$converts_file = $data_path."converts.dat";
$robotspeak_file = $data_path."robotspeak.dat";
$banlist_file = $data_path."banlist.dat";
endif;
?>