<?php
include("inc_common.php");
include($engine_path."users_get_list.php");

if (!$exists) 
{
	$error_text = "$w_no_user";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}

include($ld_engine_path."board_get_messages.php");

include($file_path."designes/".$design."/board_list.php");
?>