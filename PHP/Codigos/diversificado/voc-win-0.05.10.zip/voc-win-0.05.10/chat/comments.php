<?php
include("inc_common.php");
#for determining design:
include($engine_path."users_get_list.php");


include($file_path."designes/".$design."/comments.php");
?>