<?php
include("inc_common.php");
#only to determine design:
include($engine_path."users_get_list.php");


if(!isset($user_id))$user_id = 0;
$user_id = intval($user_id);
#fake for including files, without functions
$is_regist = $user_id;
if ($is_regist)
{
	include("inc_user_class.php");
	include($ld_engine_path."users_get_object.php");
}

$pic_name = strtolower($current_user->nickname) . ".big.gif";
if (!file_exists($file_path."photos/$pic_name")) $pic_name="";
if ($pic_name == "")
{
$pic_name = strtolower($current_user->nickname) . ".big.jpg";
if (!file_exists($file_path."photos/$pic_name")) $pic_name="";
}

$sex = $current_user->sex;
switch ($sex)
{
	case 0: $sexStr = $w_unknown; break;
	case 1: $sexStr = $w_male; break;
	case 2: $sexStr = $w_female; break;
}

include($file_path."designes/".$design."/fullinfo.php");
?>