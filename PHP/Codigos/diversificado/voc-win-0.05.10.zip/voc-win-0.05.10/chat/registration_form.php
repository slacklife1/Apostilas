<?php
include("inc_common.php");
#for determining design and user_name
include($engine_path."users_get_list.php");

include($file_path."designes/".$design."/registration_form.php");
?>