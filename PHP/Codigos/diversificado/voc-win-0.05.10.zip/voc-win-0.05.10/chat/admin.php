<?php
include("inc_common.php");
include($engine_path."users_get_list.php");

if (!$exists) 
{
	$error_text = "$w_no_user";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}

include("inc_user_class.php");
include($ld_engine_path."users_get_object.php");


if ($current_user->user_class!="admin")
{
	$error_text = "$w_no_admin_rights";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}

if(!isset($toBan)) $toBan="";
if($toBan !="")
{
		if ($action == 1)
	{
		list($nameToBan, $ipToBan) = explode(":", $toBan);
		$messages_to_show[] = time() . "\t\t\t<font color=\"".$registered_colors[$default_color][1]."\">".str_replace("#",$cause,str_replace("*", $user_name,str_replace("~", $nameToBan,$w_alert_text)))."</font>\t$default_color";
	}
	if (($action == 2) or ($action == 3))
	{
		list($nameToBan, $ipToBan) = explode(":", $toBan);
		$to_ban = ($action == 2) ? $nameToBan : $ipToBan;
		$messages_to_show[] = time() . "\t\t\t<font color=\"".$registered_colors[$default_color][1]."\">".str_replace("$",$w_times[$kill_time]["name"],str_replace("#",$cause,str_replace("*", $user_name,str_replace("~", $nameToBan,$w_kill_text))))."</font>\t$default_color";
		include($ld_engine_path."admin.php");
	}
}

include($engine_path."messages_put.php");
include($file_path."designes/".$design."/admin.php");

?>