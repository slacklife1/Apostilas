<?php
include("inc_common.php");
include($engine_path."users_get_list.php");

if (!$exists) 
{
	$error_text = "$w_no_user";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}
if (!isset($photoss)) {$photoss = "no";}

if (isset($add_to_ignor))
	if ($add_to_ignor != "")
	{
		include($engine_path."ignor_add.php");
		Header("Location: who.php?session=$session&photoss=$photoss&".time());
		exit;
	}
if (isset($remove_from_ignor))
	if ($remove_from_ignor != "")
	{
		include($engine_path."ignor_remove.php");
		Header("Location: who.php?session=$session&photoss=$photoss&".time());
		exit;
	}
unset($ignored_users);
$ignored_users = array();
$out_users = array();
include($engine_path."ignore_get.php");

for ($i=0;$i<count($users);$i++)
{
	list($out_users[$i]["nickname"], $unused, $unused, $unused, $out_users[$i]["small_photo"], $out_users[$i]["user_id"], $unused, $unused)
		= explode("\t", $users[$i]);
}
$total_users = count($out_users);

include($file_path."designes/".$design."/who.php");
?>