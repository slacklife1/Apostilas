<?php
include("inc_common.php");
include($engine_path."logout.php");

if ($exists)
{
	$messages_to_show = array();
	$messages_to_show[] = time() . "\t<b>$w_rob_name</b>\t\t<font color=\"".$registered_colors[$default_color][1]."\">".str_replace("~", $user_name, $w_rob_logout)."</font>\t$default_color;";
	include($engine_path."messages_put.php");
}

include($file_path."designes/".$design."/logout.php");
?>