<?php
include("inc_common.php");
#for determining design
include($engine_path."users_get_list.php");
if(!isset($new_user_name))$new_user_name = "";
if (!isset($passwd1)) $passwd1 = "";
if (!isset($passwd2)) $passwd2 = "";

if (get_magic_quotes_gpc())
{
	$new_user_name = stripslashes($new_user_name);
	$passwd1 = stripslashes($passwd1);
	$passwd2 = stripslashes($passwd2);
}
if ((strlen($new_user_name)<3) or (strlen($new_user_name)>15))
{
	$error_text ="$w_incorrect_nick<br><a href=\"index.php\">$w_try_again</a>";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}
if (ereg("[^_a-zA-Z0-9]", $new_user_name))
{
	$error_text ="$w_incorrect_nick<br><a href=\"index.php\">$w_try_again</a>";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}
if (strlen($passwd1)<1)
{
	$error_text = $w_enter_password."<a href=\"registration_form.php\">$w_try_again</a>";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}
if ($passwd1 != $passwd2) 
{
	$error_text = $w_password_mismatch."<a href=\"registration_form.php\">$w_try_again</a>";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}

include($ld_engine_path."registration_add.php");
include($file_path."designes/".$design."/registration_add.php");
?>