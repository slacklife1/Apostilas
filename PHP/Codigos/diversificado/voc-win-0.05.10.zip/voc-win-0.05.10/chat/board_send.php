<?php
include("inc_common.php");
include($engine_path."users_get_list.php");

if (!$exists) 
{
	$error_text = "$w_no_user";
	include($file_path."designes/".$design."/error_page.php");
	exit;
}

$u_ids = array();
$u_names = array();
$tmp_body = "";
$tmp_subject = "";

$info_message = "";

if(!isset($message_id))
{
	if (isset($send_to))
	{
		$user_to_search = $send_to;
		include($ld_engine_path."users_search.php");
		if (!count($u_ids)) $info_message = "<b>".str_replace("~","&quot;<b>$send_to</b>&quot;",$w_search_no_found)."</b><br>";
	}
	if (isset($send_to_id))
	{
		include("inc_user_class.php");
		$ttt = $is_regist;
		$is_regist = intval($send_to_id); #fake again :(
		include($ld_engine_path."users_get_object.php");
		$u_ids[] = $is_regist;
		$is_regist = $ttt;
		$u_names[] = $current_user->nickname;
	}
}
else
{
	$board_operation = "reply";
	$id = $message_id;
	include($ld_engine_path."board_process_message.php");
	$u_ids[] = $board_message["from_id"];
	$u_names[] = $board_message["from"];
	$tmp_body =  str_replace("<br>","\n",$board_message["body"]);
	$tmp_body  = "\n\n_______ ".str_replace("~", $board_message["from"], $w_user_wrote)." ______\n$tmp_body";
	$tmp_subject = str_replace("\"","&quot;","Re: ".$board_message["subject"]);
}

include($file_path."designes/".$design."/board_send.php");
?>
