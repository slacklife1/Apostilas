/**********************************************************
 *             phpAutoMembersArea                         *
 *           Author:  Seiretto.com                        *
 *    phpAutoMembersArea � Copyright 2003 Seiretto.com    *
 *              All rights reserved.                      *
 **********************************************************
 *        Launch Date:  Dec 2003                          *
 *                                                        *
 *     Version    Date              Comment               *
 *     1.0       15th Dec 2003      Original release      *
 *                                                        *
 *  NOTES:                                                *
 *        Requires:  PHP 4.2.3 (or greater)               *
 *                   and MySQL                            *
 **********************************************************/

Any files within this folder will be secure provided that:
- you host on a Unix or Linux platform (not Windows)
- the .htaccess file remains unchanged in this folder.

*Google will not be able to index the files (Hoohh Bloody Rrraahhhh).
*Members will not be able to access the files without a successful login.
*Other web sites will be unable to link to the files in this folder.



