<?
$image_file="content/pamalogo-from-secure-folder.jpg";
?>
<br><br>
<img src="_getimage.php?image_file=<? echo $image_file; ?>">
<br><big>
<br>
<p>View the source of <strong>&quot;members/content/PHP image example 2.php&quot;</strong><br>
and <strong>&quot;members/_getimage.php&quot;</strong> to see how to achieve this.<br>
<br></p>
<br>
<b>TIP: files added to the content folder that start with an underscore (_) will not show on the above menu</b>
<br>
<br>
Have fun  ;-)<p><br>
<br></big>
<br>
</p>
