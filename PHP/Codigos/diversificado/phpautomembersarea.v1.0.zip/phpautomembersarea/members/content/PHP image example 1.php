<?
echo "<big><b>Run PHP and send output here...</b>"
?>
<br>
<br>
<br>
Include images from the upper (parent) folder. Like this:</big>
<p></font><font size="3">&lt;<font COLOR="#800080">img </font><font COLOR="#ff0000">src=&quot;</font><font
COLOR="#0000ff">../pamalogo.gif</font><font COLOR="#ff0000">&quot;</font>&gt; </font></p>
<big><B>As displayed below:</b><br><br>
<img src="../pamalogo.gif">
<br>
<br>
<blockquote>
  <blockquote>
    <p>Note that the <strong>src</strong> for the <strong>img</strong> tag is <strong>NOT</strong>
    within a secure folder. Please see <b>&quot;PHP image example 2.php&quot;</b> for details on how
    to include images from a secure folder.<br>
    </p>
  </blockquote>
</blockquote>
</big>

