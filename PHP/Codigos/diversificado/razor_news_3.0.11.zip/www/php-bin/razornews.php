<?

###############################################################################
#
#  razornews.php
#  RazorNews 3.0.10
#  Author:  Peter Adams (adams@editors-wastebasket.org)
#  Date Created: 7 March 2001
#  Last Modified: 18 February 2002
#
#  Description:
#    This file contains all code necessary to determine which file to use.  It
#    also determines if the script is used as an SSI.  If so, it does not read
#    in the template file.
#
# Copyright (c) InterKan.Net, Inc.  All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. The name of the author may not be used to endorse or promote
#    products derived from this software without specific prior
#    written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
# GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
# OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
###############################################################################

# Path to the include directory (php-inc, but default).
$path = "/home/demo/php-inc/Razor";

############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################

# Global Include Files ########################################################
include $path . "/db.cls.php";                 # CLASS:  Database Connection
include $path . "/template.cls.php";           # CLASS:  Template
include $path . "/auth_lib.inc.php";           # GLOBAL: Authentication Library
include $path . "/global.inc.php";             # GLOBAL: Function Library
include $path . "/config.inc.php";             # Configuration Settings

# Variable Declaration ########################################################
$HTML_OUTPUT = "";                             # Primary HTML output container
$NAVIGATION = "";                              # Navigation menu container
$SUBTITLE = "";                                # Subtitle container
$TITLE = "";                                   # Title table container
$LIST = "";                                    # Announcement list container
$news = false;                                 # Announcement recordset
$i_temp = false;                               # Single Announcement template
$t = false;                                    # SSI Table template
$year = (isset($year)) ? $year : date('Y');    # Default year
$valid = false;                                # Valid User boolean
$query = false;                                # SQL query

# Get the announcement recordset
$query = "SELECT * FROM " . $announcement_table .
          " ORDER BY lock_status DESC,date DESC" .
          " LIMIT 0," . $num_listed;
if (is_string($news = $d->query($query))) {
    echo show_error($news);
	exit;
}
	
# Build the table header (with or without the border)
$TITLE .= "\n<TABLE CLASS='RNTitleTable' WIDTH='100%' CELLSPACING='0'>\n\n";
$TITLE .= "<TR CLASS='RNTableTopHeader'>\n<TD CLASS='RNTableTopHeader' ALIGN='LEFT'>";
$TITLE .= $a_title . "</TD>\n";

# Build the news list
if ((is_array($news)) && (count($news) > 0)) {
     # Only show the archive link if the number of archived news items is greater than the number of items shown on the front page.
     if (($use_archive) && (count($d->query("SELECT * FROM " . $announcement_table)) > count($news))) {
          $TITLE .= "<TD ALIGN='RIGHT' VALIGN='TOP' CLASS='RNTableTopHeader'>";
          $TITLE .= "<A HREF='/" . $rn_dir . "?az=show_archive' CLASS='RNArchiveLink'>";
          $TITLE .= $archive_link_name . "</A></TD>\n";
     }
     $TITLE .= "</TR>\n\n</TABLE>\n\n";
	 
     # Get the template
	 $i_temp = new template($single_tpl);

     # There are announcements, build the display
	 if ($i_temp->open()) {
    	 foreach ($news as $n) {
              # Get the URL for the announcement's details
              $URL = "/" . $rn_dir . "?az=show_details&aid=" . $n['newsID'];

              # Build the "more" bar
    		  $more_bar = "<A HREF='" . $URL . ((in_array($n['category'], $alert_list))
			              ? "' CLASS='RNAlertLink" : "") . "'>Read More</A>&nbsp;|&nbsp;" .
	    	              ((! $allow_comments) ? ""
		    			  : "<A HREF='#'>" .
			    		  "<IMG SRC='" . $graphicsurl .  "/comment.gif' ALIGN='ABSMIDDLE' " .
				    	  "BORDER='0' ALT='Click to post comments'></A>&nbsp;") . 
					      "<A HREF='" . $detailsurl . "?az=show_details_print&aid=" . $n['newsID'] . "'>" .
    					  "<IMG SRC='" . $graphicsurl . "/print.gif' VALIGN='ABSMIDDLE'" .
	    				  "BORDER='0' ALT='Click for a printer-friendly version'></A>";
		  
              # Build the markers array
              $markers = array('ANNOUNCEMENT_TEXT' => getCaption(strip_tags($n['text']), $caption_words),
	    	                   'TEXT' => format_long_text(web_links(email_links($n['text'], $caption_words))),
				    		   'DATE' => format_date($n['date']),
					    	   'CATEGORY' => $n['category'],
    						   'TITLE' => $n['title'],
	    					   'URL' => $URL . ((in_array($n['category'], $alert_list)) ? "\" CLASS=\"RNAlertLink" : ""),
		    				   'MORE' => $more_bar
			    			  );

    		  # Set the marker content
	     	  $i_temp->set_markers($markers);
	  	  
    		  # Remove the special table tags
              $i_temp->content = eregi_replace("\<TABLE[a-zA-Z0-9\'\"\%\= ]* NAME=['\"]{1}REMOVED['\"]{1}[a-zA-Z0-9\'\"\%\= ]*\>", "", $i_temp->content);
              $i_temp->content = eregi_replace("\<\/TABLE NAME=['\"]{1}REMOVED['\"]{1}\>", "", $i_temp->content);
              $i_temp->content = eregi_replace("\<TR[a-zA-Z0-9\'\"\%\= ]* NAME=['\"]{1}REMOVED['\"]{1}[a-zA-Z0-9\'\"\%\= ]*\>", "", $i_temp->content);
              $i_temp->content = eregi_replace("\<\/TR NAME=['\"]{1}REMOVED['\"]{1}\>", "", $i_temp->content);
              $i_temp->content = eregi_replace("\<TD[a-zA-Z0-9\'\"\%\= ]* NAME=['\"]{1}REMOVED['\"]{1}[a-zA-Z0-9\'\"\%\= ]*\>", "", $i_temp->content);
              $i_temp->content = eregi_replace("\<\/TD NAME=['\"]{1}REMOVED['\"]{1}\>", "", $i_temp->content);

              # Build the announcement row
              $LIST .= $i_temp->content;
         }
	}
}
else {
     $TITLE .= "</TR>\n\n</TABLE>\n\n";
	 $LIST .= "<TR BGCOLOR='" . $td_bgcolor . "'>\n<TD ALIGN='CENTER' CLASS='RNStandardText'><B>";
     $LIST .= "There is no news to display at this time.</B></TD>\n</TR>\n\n";
}

# Open the template
$t = new template($ssi_table_tpl);

if (! $t->open())
    echo show_error('100', "#FF0000", $ssi_table_tpl);

# Add a table tag in if necessary
if ((! ereg("NAME=['\"]{1}REMOVED['\"]{1}", $t->content)) && (! is_array($news))) {
    $LIST = "<TABLE CLASS='RNStandardTable'>\n\n" . $LIST . "</TABLE>\n\n";
}

# Build the markers and replace the content
$markers = array('TITLE' => $TITLE,
                 'LIST' => $LIST
				);
$t->set_markers($markers);

# Remove the special table tags
$t->content = eregi_replace("\<TABLE[a-zA-Z0-9\'\"\%\= ]* NAME=['\"]{1}REMOVED['\"]{1}[a-zA-Z0-9\'\"\%\= ]*\>", "", $t->content);
$t->content = eregi_replace("\<\/TABLE NAME=['\"]{1}REMOVED['\"]{1}\>", "", $t->content);
$t->content = eregi_replace("\<TR[a-zA-Z0-9\'\"\%\=\# ]* NAME=['\"]{1}REMOVED['\"]{1}[a-zA-Z0-9\'\"\%\=\# ]*\>", "", $t->content);
$t->content = eregi_replace("\<\/TR NAME=['\"]{1}REMOVED['\"]{1}\>", "", $t->content);
$t->content = eregi_replace("\<TD[a-zA-Z0-9\'\"\%\=\# ]* NAME=['\"]{1}REMOVED['\"]{1}[a-zA-Z0-9\'\"\%\=\# ]*\>", "", $t->content);
$t->content = eregi_replace("\<\/TD NAME=['\"]{1}REMOVED['\"]{1}\>", "", $t->content);

echo $t->content;

?>
