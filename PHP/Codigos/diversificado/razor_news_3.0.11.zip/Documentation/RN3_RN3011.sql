# Updates database structure to v.3.0.11

# Update the Announcements table
ALTER TABLE `RN_Announcements` ADD `lock_status` MEDIUMINT(10) DEFAULT '0' NOT NULL;