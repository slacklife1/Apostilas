# Updates database structure to v.3.0

# Administrative Actions
CREATE TABLE `RN_Admin_Actions` (
  `action_az` VARCHAR(50) NOT NULL, 
  `title` VARCHAR(50) NOT NULL, 
  `groupID` MEDIUMINT(10) NOT NULL,
  PRIMARY KEY (`action_az`),
  INDEX (`action_az`),
  UNIQUE (`action_az`)
) COMMENT = 'Razor News Administrative Actions';

# Administrative Groups
CREATE TABLE `RN_Admin_Groups` (
  `groupID` MEDIUMINT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY, 
  `title` VARCHAR(50) NOT NULL,
  INDEX (`groupID`),
  UNIQUE (`groupID`)
) COMMENT = 'Razor News Administrative Action Groupings';

# Administrative Action Access control
CREATE TABLE `RN_Admin_Action_Control` (
  `action_az` VARCHAR(50) NOT NULL, 
  `groupID` MEDIUMINT(10) NOT NULL,
  PRIMARY KEY (`action_az`, `groupID`)
) COMMENT = 'Razor News Administrative Action Permissions by group';

# Group Table
CREATE TABLE `ADM_Groups` (
  `groupID` MEDIUMINT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY, 
  `name` VARCHAR(20) NOT NULL,
  UNIQUE (`groupID`)
) COMMENT = 'Razor News User Groups';

# Session Data
CREATE TABLE ADM_Sessions (
  sessionID varchar(32) NOT NULL default '',
  data text NOT NULL,
  expiration bigint(14) NOT NULL,
  PRIMARY KEY  (sessionID)
) TYPE=MyISAM COMMENT='Razor News session information';

# Update User Table format
ALTER TABLE `RN_Logins` DROP `usernumber`;
ALTER TABLE `RN_Logins` CHANGE `usergroup` `groupID` MEDIUMINT(10) NOT NULL;
ALTER TABLE `RN_Logins` ADD `first_name` TEXT NOT NULL AFTER `password`,
 ADD `last_name` TEXT NOT NULL AFTER `first_name`,
 ADD `email` TEXT NOT NULL AFTER `last_name`,
 ADD `active` ENUM('Y','N') DEFAULT 'N' NOT NULL AFTER `email`;

# Update table names
ALTER TABLE `RN_Logins` RENAME `ADM_Users`;

# Insert Data
INSERT INTO `RN_Admin_Actions` (`action_az`, `title`, `groupID`) VALUES ('user_mgr', 'User Manager', '0');
INSERT INTO `RN_Admin_Actions` (`action_az`, `title`, `groupID`) VALUES ('group_mgr', 'Group Manager', '0');
INSERT INTO `RN_Admin_Actions` (`action_az`, `title`, `groupID`) VALUES ('admin', 'Announcement Administration', '0');
INSERT INTO `ADM_Groups` (`groupID`, `name`) VALUES ('', 'Administrator');
INSERT INTO `RN_Admin_Action_Control` (`action_az`, `groupID`) VALUES ('admin', '1');
INSERT INTO `RN_Admin_Action_Control` (`action_az`, `groupID`) VALUES ('group_mgr', '1');
INSERT INTO `RN_Admin_Action_Control` (`action_az`, `groupID`) VALUES ('user_mgr', '1');

# Update User table with admin group (applied to all users)
UPDATE `ADM_Users` SET groupID = '1';