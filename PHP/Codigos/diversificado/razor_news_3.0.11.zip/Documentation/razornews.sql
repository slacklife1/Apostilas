#
# Table structure for table `ADM_Groups`
#

CREATE TABLE ADM_Groups (
  groupID mediumint(10) NOT NULL auto_increment,
  name varchar(12) NOT NULL default '',
  PRIMARY KEY  (groupID),
  UNIQUE KEY name (name),
  KEY groupID (groupID)
) TYPE=MyISAM COMMENT='Americart Catalog Manager user group possibilities';
# --------------------------------------------------------

#
# Table structure for table `ADM_Sessions`
#

CREATE TABLE ADM_Sessions (
  sessionID varchar(32) NOT NULL default '',
  data text NOT NULL,
  expiration bigint(14) default NULL,
  PRIMARY KEY  (sessionID)
) TYPE=MyISAM COMMENT='Americart Catalog Manager session information';
# --------------------------------------------------------

#
# Table structure for table `ADM_Users`
#

CREATE TABLE ADM_Users (
  userid varchar(15) NOT NULL default '',
  password text NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text NOT NULL,
  active enum('Y','N') NOT NULL default 'Y',
  groupID mediumint(10) NOT NULL default '0',
  PRIMARY KEY  (userid),
  UNIQUE KEY usernumber (userid),
  KEY userid (userid)
) TYPE=MyISAM COMMENT='Americart User list';
# --------------------------------------------------------

#
# Table structure for table `RN_Admin_Action_Control`
#

CREATE TABLE RN_Admin_Action_Control (
  action_az varchar(50) NOT NULL default '',
  groupID mediumint(10) NOT NULL default '0',
  PRIMARY KEY  (action_az,groupID)
) TYPE=MyISAM COMMENT='Razor News Administrative Action Permissions by group';
# --------------------------------------------------------

#
# Table structure for table `RN_Admin_Actions`
#

CREATE TABLE RN_Admin_Actions (
  action_az varchar(50) NOT NULL default '',
  title varchar(50) NOT NULL default '',
  groupID mediumint(10) NOT NULL default '0',
  PRIMARY KEY  (action_az),
  UNIQUE KEY action_az (action_az),
  KEY action_az_2 (action_az)
) TYPE=MyISAM COMMENT='Razor News Administrative Actions';
# --------------------------------------------------------

#
# Table structure for table `RN_Admin_Groups`
#

CREATE TABLE RN_Admin_Groups (
  groupID mediumint(10) NOT NULL auto_increment,
  title varchar(50) NOT NULL default '',
  PRIMARY KEY  (groupID),
  UNIQUE KEY groupID (groupID),
  KEY groupID_2 (groupID)
) TYPE=MyISAM COMMENT='Razor News Administrative Action Groupings';
# --------------------------------------------------------

#
# Table structure for table `RN_Announcements`
#

CREATE TABLE RN_Announcements (
  newsID mediumint(10) NOT NULL auto_increment,
  category text NOT NULL,
  title text NOT NULL,
  date date NOT NULL default '0000-00-00',
  text longtext NOT NULL,
  lock_status mediumint(10) NOT NULL default '0',
  PRIMARY KEY  (newsID),
  UNIQUE KEY annID_2 (newsID),
  KEY annID (newsID)
) TYPE=MyISAM COMMENT='Razor News Announcement storage table';

# DEFAULT DATA

INSERT INTO ADM_Groups VALUES (1, 'Administrator');
# --------------------------------------------------------

INSERT INTO ADM_Users VALUES ('admin', MD5('admin'), 'Your', 'Webmaster', 'webmaster@your-domain.com', 'Y', 1);
# --------------------------------------------------------

INSERT INTO RN_Admin_Action_Control VALUES ('admin', 1);
INSERT INTO RN_Admin_Action_Control VALUES ('group_mgr', 1);
INSERT INTO RN_Admin_Action_Control VALUES ('user_mgr', 1);
# --------------------------------------------------------

INSERT INTO RN_Admin_Actions VALUES ('user_mgr', 'User Manager', 0);
INSERT INTO RN_Admin_Actions VALUES ('group_mgr', 'Group Manager', 0);
INSERT INTO RN_Admin_Actions VALUES ('admin', 'Announcement Administration', 0);
# --------------------------------------------------------

