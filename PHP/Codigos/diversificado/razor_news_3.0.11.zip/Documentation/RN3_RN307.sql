# Updates database structure to v.3.0.7

# Update the sessions table
ALTER TABLE `ADM_Sessions` CHANGE `expiration` `expiration` BIGINT(14) DEFAULT NULL;