<?

###############################################################################
#
#  admin_users.inc.php
#  Author:  Peter Adams (adams@editors-wastebasket.org)
#  http://www.editors-wastebasket.org/pta/
#  Date Created: 4 February 2002
#  Last Modified: 7 February 2002
#
#  Description:
#    This file contains code for all user administration functions.
#
# Copyright (c) Peter Adams.  All rights reserved.
#
###############################################################################

############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################

function show_main($user = false, $error = false) {
/******************************************************************************
Displays the main user management menu.  Primary area displays a user form or
user list if more than one user was found; toolbar displays a form to search
by string for username or e-mail
******************************************************************************/
    # Global Variables
	global $user_table, $SCRIPT_NAME, $_QUERY, $cfg, $d, $REQUEST_METHOD;

	# Local Variables
	$output = "";    # HTML Output container
	$users = false;    # User information recordset

	# Retrieve user info if a name was submitted
	if ($user) {
	    $query = "SELECT * FROM " . $user_table .
		         " WHERE " . $_QUERY['field'] .
				 (($REQUEST_METHOD == 'POST') ? " LIKE '%" . $user . "%'"
				 : " = '" . $user . "'") .
				 " ORDER BY " . $_QUERY['field'];
		if (is_string($users = $d->query($query)))
		    return show_error($users);
	}

	# Begin the layout table
	$output .= "<TABLE BORDER='0' WIDTH='100%' ALIGN='CENTER' CELLPADDING='2'" .
	           " CELLSPACING='1'>\n\n";

    # Display the path taken to the current point + Add link
	$output .= "<TR>\n<TD VALIGN='TOP' CLASS='RNAdminPath'>";
	$output .= "<A HREF='" . $SCRIPT_NAME . "' CLASS='RNAdminPath'>Administration</A> &gt; ";
	$output .= "User Administration</TD>\n<TD CLASS='RNAdminPath' ALIGN='RIGHT'>";
	$output .= "<A HREF='" . $SCRIPT_NAME . "?az=user_mgr' CLASS='RNAdminPath'>Add</A></TD>\n";
	$output .= "</TR>\n\n";

	# Display the Primary content region
	$output .= "<TR>\n<TD VALIGN='TOP' WIDTH='75%'>";
    $output .= user_form($users, $error);

	# User Management Toolbar
	$output .= "</TD><TD VALIGN='TOP' WIDTH='25%'>";

	# If no users found, let admin know
	if ($user && (! $users))
    	$output .= show_error('206');

    $output .= "<FORM METHOD='POST' ACTION='" . $SCRIPT_NAME . "'>\n";
	$output .= "<INPUT TYPE='HIDDEN' NAME='az' VALUE='" . $_QUERY['az'] . "'>\n";
	$output .= "<INPUT TYPE='HIDDEN' NAME='cmd' VALUE='edit'>\n";
	$output .= "<TABLE CLASS='RNStandardTable'>\n\n";
	$output .= "<TR>\n<TD CLASS='RNTableTopHeader'>";
	$output .= "Edit User ...</TD>\n</TR>\n\n";
	$output .= "<TR>\n<TD CLASS='RNTableRow1' ALIGN='CENTER'>";
	$output .= "<INPUT TYPE='TEXT' NAME='id' SIZE='10'><BR>\n";
	$output .= "<SPAN CLASS='RNUserSearchOption'>";
	$output .= "<INPUT TYPE='RADIO' NAME='field' VALUE='userid' CHECKED>Username";
	$output .= "<INPUT TYPE='RADIO' NAME='field' VALUE='email'>E-mail</SPAN><BR>";
	$output .= "<INPUT TYPE='submit' VALUE='Edit/Search'>\n";
	$output .= "</TD>\n</TR>\n\n";
	$output .= "</TABLE>\n</FORM>\n\n";

	# End the layout table
	$output .= "</TD>\n</TR>\n\n";
	$output .= "</TABLE>\n\n";

    # Return the HTML container
	return $output;
}

function user_form($users, $error) {
/******************************************************************************
Displays the user add/edit form.  Includes delete button at the bottom if
viewing a specific user.
******************************************************************************/
    # Global Variables
	global $group_table, $SCRIPT_NAME, $_QUERY, $d, $st_dir;

	# Local Variables
	$output = "";      # HTML output
	$query = false;    # SQL query
	$groups = false;   # User Groups Recordset
	$row = 1;

	# Retrieve the user groups
	$query = "SELECT * FROM " . $group_table .
	         " ORDER BY name";
	if (is_string($groups = $d->query($query)))
	    return show_error($groups);

	if ((! $users) || (count($users) == 1)) {
    	# Start the form
    	$output .= "<FORM METHOD='POST' ACTION='" . $SCRIPT_NAME . "'>\n";
	    $output .= "<INPUT TYPE='HIDDEN' NAME='az' VALUE='" . $_QUERY['az'] . "'>\n";
    	$output .= "<INPUT TYPE='HIDDEN' NAME='cmd' VALUE='" .
	               ((($_QUERY['cmd'] == 'edit') && ($users)) ? "update" : "add") . "'>\n";

    	# Start the Table
	    $output .= "<TABLE CLASS='RNStandardTable'>\n\n";

    	# UserID
	    $output .= "<TR>\n<TD CLASS='RNTableSideHeader'>User ID:</TD>\n" .
		           "<TD CLASS='RNTableRow1'>" .
		           ((($users) && ($_QUERY['cmd'] == 'edit')) ? (($users) ? $users[0][userid] : $_QUERY['id']) .
				   "<INPUT TYPE='HIDDEN' NAME='id' VALUE='" . (($users) ? $users[0][userid] : $_QUERY['id']) . "'>\n"
				   : "<INPUT TYPE='TEXT' NAME='id' SIZE='20' MAXLENGTH='50' VALUE='" .
				   (($error) ? $_QUERY['id'] : "") . "'>" ) .
				   "</TD>\n</TR>\n\n";

    	# Password
	    $output .= "<TR>\n<TD CLASS='RNTableSideHeader'>Password:</TD>\n" .
		           "<TD CLASS='RNTableRow2'>" .
				   "<INPUT TYPE='PASSWORD' NAME='password1' SIZE='20'" .
				   (($users) ? "" : " VALUE='" .
				   (($error) ? $_QUERY['password1'] : "") . "'") .
				   "></TD>\n</TR>\n\n";

    	# Password Confirmation
	    $output .= "<TR>\n<TD CLASS='RNTableSideHeader'>&nbsp;&nbsp;Confirm:</TD>\n" .
		           "<TD CLASS='RNTableRow1'>" .
				   "<INPUT TYPE='PASSWORD' NAME='password2' SIZE='20'" .
				   (($users) ? "" : " VALUE='" .
				   (($error) ? $_QUERY['password2'] : "") . "'") .
				   "></TD>\n</TR>\n\n";

    	# First Name
	    $output .= "<TR>\n<TD CLASS='RNTableSideHeader'>First Name:</TD>\n" .
		           "<TD CLASS='RNTableRow2'>" .
				   "<INPUT TYPE='TEXT' NAME='first_name' SIZE='25'" .
				   (($users) ? " VALUE='" . $users[0]['first_name'] . "'" : " VALUE='" .
				   (($error) ? $_QUERY['first_name'] : "") . "'") .
				   "></TD>\n</TR>\n\n";

    	# Last Name
	    $output .= "<TR>\n<TD CLASS='RNTableSideHeader'>Last Name:</TD>\n" .
		           "<TD CLASS='RNTableRow1'>" .
				   "<INPUT TYPE='TEXT' NAME='last_name' SIZE='25'" .
				   (($users) ? " VALUE='" . $users[0]['last_name'] . "'" : " VALUE='" .
				   (($error) ? $_QUERY['last_name'] : "") . "'") .
				   "></TD>\n</TR>\n\n";

    	# E-mail Address
	    $output .= "<TR>\n<TD CLASS='RNTableSideHeader'>E-mail:</TD>\n" .
		           "<TD CLASS='RNTableRow2'>" .
				   "<INPUT TYPE='TEXT' NAME='email' SIZE='25'" .
				   (($users) ? " VALUE='" . $users[0]['email'] . "'" : " VALUE='" .
				   (($error) ? $_QUERY['email'] : "") . "'") .
				   "></TD>\n</TR>\n\n";

    	# User Status
	    $output .= "<TR>\n<TD CLASS='RNTableSideHeader'>Status:</TD>\n" .
		           "<TD CLASS='RNTableRow1'>" .
				   "<INPUT TYPE='RADIO' NAME='active' VALUE='Y'" .
				   ((($users[0]['active'] == 'Y') || ($_QUERY['active'] == 'Y')) ? " CHECKED" : "") .
				   ">Active" .
				   "<INPUT TYPE='RADIO' NAME='active' VALUE='N'" .
				   ((($users[0]['active'] == 'N') || ($_QUERY['active'] == 'N')) ? " CHECKED" : "") .
				   ">Disabled</TD>\n</TR>\n\n";

		# User Group
	    $output .= "<TR>\n<TD CLASS='RNTableSideHeader'>Group:</TD>\n" .
		           "<TD CLASS='RNTableRow2'>" .
				   "<SELECT NAME='groupID'>";
		foreach ($groups as $group) {
		    $output .= "<OPTION VALUE='" . $group['groupID'] . "'" .
			           (($users[0]['groupID'] == $group['groupID'])
					   || ($error && (($_QUERY['groupID'] == $group['groupID'])))
					   ? " SELECTED" : "") .
					   ">" . $group['name'] . "</OPTION>\n";
		}
		$output .= "</SELECT>\n</TD>\n</TR>\n\n";

		# Button Row
		$output .= "<TR>\n<TD  COLSPAN='2' CLASS='RNTableFooter'>\n" .
		           "<INPUT TYPE='submit' VALUE='" .
				   (($users && ($_QUERY['cmd'] == 'edit')) ? "Update" : "Add") .
				   " User'>\n" .
				   "<INPUT TYPE='reset' VALUE='Reset Form'>\n" .
				   (($users) ? "&nbsp;&nbsp;<INPUT TYPE='submit' NAME='delete_user' VALUE='Delete User'>" : "") .
				   "</TD>\n</TR>\n\n";


    	# End the form and table
    	$output .= "</TABLE>\n\n</FORM>\n\n";
	}
	elseif ($users && (count($users) > 1)) {
		# More than one user record was returned
	    $output .= "<TABLE CLASS='RNStandardTable'>\n\n";

		# Header row
		$output .= "<TR>\n<TD CLASS='RNTableTopHeader'>User ID</TD>\n" .
		           "<TD CLASS='RNTableTopHeader'>Name</TD>\n" .
				   "<TD CLASS='RNTableTopHeader'>E-mail Address</TD>\n" .
				   "<TD CLASS='RNTableTopHeader'>Permissions</TD>\n" .
				   "<TD CLASS='RNTableTopHeader' ALIGN='CENTER'>Active</TD>\n</TR>\n\n";

		# Print out the information
		foreach ($users as $user) {
		    $output .= "<TR>\n<TD CLASS='RNTableRow" . ((($row % 2) == 0) ? "2" : "1") . "'>" .
			           "<A HREF='" . $SCRIPT_NAME . "?az=" . $_QUERY['az'] . "&cmd=edit&id=" .
					   $user['userid'] . "&field=userid'>" . $user['userid'] . "</A></TD>\n" .
					   "<TD CLASS='RNTableRow" . ((($row % 2) == 0) ? "2" : "1") . "'>" .
					   $user['first_name'] . " " . $user['last_name'] . "</TD>\n" .
					   "<TD CLASS='RNTableRow" . ((($row % 2) == 0) ? "2" : "1") . "'>" .
					   "<A HREF='mailto:" . $user['email'] . "'>" . $user['email'] . "</A>" .
					   "</TD>\n" .
					   "<TD CLASS='RNTableRow" . ((($row % 2) == 0) ? "2" : "1") . "'>" .
					   get_group_name($user['groupID']) . "</TD>\n" .
					   "<TD CLASS='RNTableRow" . ((($row % 2) == 0) ? "2" : "1") . "' ALIGN='CENTER'>" .
					   $user['active'] . "</TD></TR>\n\n";
			$row++;
		}

    	# End the form and table
    	$output .= "</TABLE>\n\n</FORM>\n\n";
	}

	# Return the HTML container
	return $output;
}

function add_user() {
/******************************************************************************
Adds a new user record to the database.
******************************************************************************/
    # Global Variables
	global $user_table, $_QUERY, $d;

	# Local Variables
	$query = false;     # SQL query
	$success = false;   # Success Boolean

    # Set the variables to check and verify completion
    $check['password1'] = $_QUERY['password1'];
	$check['password2'] = $_QUERY['password2'];
	$check['id'] = $_QUERY['id'];
	$check['first_name'] = $_QUERY['first_name'];
	$check['last_name'] = $_QUERY['last_name'];
	$check['email'] = $_QUERY['email'];
	$check['active'] = $_QUERY['active'];
	$check['groupID'] = $_QUERY['groupID'];

	# Make sure all information was submitted
	if (! ($success = valid_admin_user_submit($check))) {
        # Make sure the passwords match
		if ($_QUERY['password1'] != $_QUERY['password2'])
		    return show_error('203');

		# Build the query and add to the database
	    $query = "INSERT INTO " . $user_table .
	             " (userid,password,first_name,last_name,email,active,groupID)" .
			     " VALUES " .
    			 " ('" . $_QUERY['id'] .
	    		 "',MD5('" . $_QUERY['password1'] . "')" .
		    	 ",'" . $_QUERY['first_name'] .
			     "','" . $_QUERY['last_name'] .
    			 "','" . $_QUERY['email'] .
	    		 "','" . $_QUERY['active'] .
		    	 "','" . $_QUERY['groupID'] . "')";
		if (is_string($success = $d->query($query)))
		    return show_error($success);

		# Return no message
		return "";
	}
	else
	    return show_error($success);
}

function update_user() {
/******************************************************************************
Updates an existing user record in the database.
******************************************************************************/
    # Global Variables
	global $user_table, $_QUERY, $d;

	# Local Variables
	$query = false;     # SQL query
	$success = false;   # Success Boolean

    # Set the variables to check and verify completion
	if ($_QUERY['password1'] || $_QUERY['password2']) {
	    $check['password1'] = $_QUERY['password1'];
		$check['password2'] = $_QUERY['password2'];
	}
	$check['id'] = $_QUERY['id'];
	$check['first_name'] = $_QUERY['first_name'];
	$check['last_name'] = $_QUERY['last_name'];
	$check['email'] = $_QUERY['email'];
	$check['active'] = $_QUERY['active'];
	$check['groupID'] = $_QUERY['groupID'];

	# Make sure all information was submitted
	if (! ($success = valid_admin_user_submit($check))) {
        # Make sure the passwords match
		if ($_QUERY['password1'] != $_QUERY['password2'])
		    return show_error('203');

		# Build the query and add to the database
	    $query = "UPDATE " . $user_table . " SET";
		if ($_QUERY['password1']) {
		    $query .= " password = MD5('" . $_QUERY['password1'] . "'),";
		}
		$query .=" first_name = '" . $_QUERY['first_name'] . "'," .
		    	 " last_name = '" . $_QUERY['last_name'] . "'," .
		    	 " email = '" . $_QUERY['email'] . "'," .
		    	 " active = '" . $_QUERY['active'] . "'," .
		    	 " groupID = '" . $_QUERY['groupID'] . "'" .
				 " WHERE userid = '" . $_QUERY['id'] . "'";
		if (is_string($success = $d->query($query)))
		    return show_error($success);

		# Return no message
		return "";
	}
	else
	    return show_error($success);
}

function valid_admin_user_submit($values) {
/******************************************************************************
Validates that all information was submitted.
******************************************************************************/
    # Local Variables
	$valid = true;    # Boolean check

	foreach ($values as $value) {
	    if (is_void($value)) {
		    $valid = false;
			break;
		}
	}
	if (! $valid) $valid = "400";
	else $valid = false;
	return $valid;
}

function remove_user($user) {
/******************************************************************************
Remove a user from the user table.
******************************************************************************/
    # Global Variables
	global $d, $user_table;

	# Local Variables
	$query = false;     # SQL query
	$success = false;   # Success Boolean

	# Build the query and remove the user
	$query = "DELETE FROM " . $user_table .
	         " WHERE userid = '" . $user . "'";
	if (is_string($success = $d->query($query)))
	    return show_error($success);

	# Return an empty value
	return "";
}

function confirm_remove($user) {
/******************************************************************************
Verify the deletion of a userid.
******************************************************************************/
    # Global Variables
	global $SCRIPT_NAME;

	# Local Variables
	$output = "";    # HTML output container

    # Start the table
    $output .= "<TABLE CLASS='RNStandardTable'>\n\n";

    # Caption
    $output .= "<TR>\n<TD ALIGN='CENTER' COLSPAN='2' CLASS='RNSubtitle'>";
    $output .= "Remove user: " . $user . "</TD>\n</TR>\n\n";

    # Confirm: Yes/No
    $output .= "<TR>\n<TD ALIGN='RIGHT' WIDTH='50%'>\n";
    $output .= "<FORM METHOD='POST' ACTION='" . $SCRIPT_NAME . "'>";
    $output .= "<INPUT TYPE='HIDDEN' NAME='az' VALUE='user_mgr'>\n";
    $output .= "<INPUT TYPE='HIDDEN' NAME='cmd' VALUE='rmv_user'>\n";
    $output .= "<INPUT TYPE='HIDDEN' NAME='id' VALUE='" . $user . "'>\n";
    $output .= "<INPUT TYPE='submit' VALUE='Yes'>\n";
    $output .= "</FORM>\n</TD><TD ALIGN='LEFT' WIDTH='50%'>\n";
    $output .= "<FORM METHOD='POST' ACTION='" . $SCRIPT_NAME . "'>";
    $output .= "<INPUT TYPE='HIDDEN' NAME='az' VALUE='user_mgr'>\n";
    $output .= "<INPUT TYPE='submit' VALUE='No'>\n";
    $output .= "</FORM>\n</TD>\n</TR>\n\n";

    # End the table
    $output .= "</TABLE>\n\n";

    # Return the output
    return $output;
}

?>
