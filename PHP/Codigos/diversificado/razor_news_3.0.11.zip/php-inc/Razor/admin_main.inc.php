<?

###############################################################################
#
#  show_archive.inc.php
#  Author:  Peter Adams (adams@editors-wastebasket.org)
#  http://www.editors-wastebasket.org/pta/
#  Date Created: 12 March 2001
#  Last Modified: 11 February 2002
#
#  Description:
#    This file contains default information to be displayed by the admin
#    application.
#
# Copyright (c) InterKan.Net, Inc.  All rights reserved.
#
###############################################################################

############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################

function show_main() {
/******************************************************************************
Print the default text for the administration.
******************************************************************************/
    # Local Variables
	$output = "";

    # Build the basic information.
    $output .= "<P CLASS='RNStandardText'>Select an option from the menu to make changes.  You may\n";
    $output .= "add/delete events, import event results, manage announcements,\n";
    $output .= "add/delete links.</P>\n\n";

    # Return the output
	return $output;
}

?>
