<?

###############################################################################
#
#  show_archive.inc.php
#  Author:  Peter Adams (adams@editors-wastebasket.org)
#  Date Created: 7 March 2001
#  Last Modified: 18 February 2002
#
#  Description:
#    This file contains all code necessary to display the announcement archive.
#
# Copyright (c) InterKan.Net, Inc.  All rights reserved.
#
###############################################################################

############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################

function show_archive($offset = 0, $limit, $year) {
/*****************************************************************************
Display the details for the specified announcement.
*****************************************************************************/
    # Global Variables
	global $announcement_table, $d, $SCRIPT_NAME;
	
    # Local Variables
	$output = "";         # HTML output container
    $query = false;       # SQL Query
    $archive = false;     # Archive Recordset
    $URL = "";          # Announcement details URL
    $num_pages = 0;       # Number of pages in the archive

    # Get the Archive recordset
    $query = "SELECT * FROM " . $announcement_table .
             " WHERE date >= '" . $year . "-01-01'" .
			 " AND date < '" . ((integer) $year + 1) . "-01-01'" .
             " ORDER BY date DESC" .
             " LIMIT " . $offset . "," . $limit;
    if (is_string($archive = $d->query($query)))
	    return show_error($archive);
		
    # Build the output
    if (is_array($archive) && count($archive) > 0) {
         foreach ($archive as $a) {
             $URL = $SCRIPT_NAME . "?az=show_details&aid=" . $a['newsID'] . "&year=" . $year;
             $output .= "<P CLASS='RNStandardText'><B>(" . format_date($a['date']) . ")</B> -\n";
             $output .= "<A HREF='" . $URL . "'>" . $a['title'] . "</A></P>\n\n";
         }
    }
    else {
        $output .= "<P CLASS='RNStandardText'><B><I>No Archived Announcements for " .
		           $year . "</I></B></FONT></P>";
    }

    # Return the HTML container
	return $output;
}

?>
