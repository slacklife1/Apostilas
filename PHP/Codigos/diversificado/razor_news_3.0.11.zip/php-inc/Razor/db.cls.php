<?

###############################################################################
#
#  db.cls.php
#  Author:  Peter Adams (pta@interkan.net)
#  http://www.interkan.net
#  Date Created: 10 October 2001
#  Last Modified: 12 October 2001
#
#  Description:
#    This file contains code for obtaining a database connection and submitting
#    queries to a mySQL database.
#
# Copyright (c) InterKan.Net, Inc.  All rights reserved.
#
###############################################################################

############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################

class db {

    # Property variable declaration
    var $link = false;     # Link to the database
    var $host = false;     # Hosting server
    var $user = false;     # Database username
    var $pass = false;     # Database Password
    var $dbname = false;   # Database Name

    function db($h, $u, $p, $d) {
    /**************************************************************************
    Constructor:  Automatically connects to the database using the submitted
    parameters (host, user, pass) and assigns the database to use with the
    submitted name (db)
    **************************************************************************/
        # Assign the paramters to the corresponding properties
        $this->host   = $h;
        $this->user   = $u;
        $this->pass   = $p;
        $this->dbname = $d;

        # Get the persistent link identifier
        if ($this->link = $this->connect()) {
            if (! $this->assign_db()) {
                return "201";
            }
        }
        else
            return "200";
    } # End db
    
    function connect() {
    /**************************************************************************
    Connect to the database and return the persistent link identifier or false
    if an error occurs.
    **************************************************************************/
        # Success boolean check
        $success = @mysql_pconnect($this->host, $this->user, $this->pass);
        
        return $success;
    } # End connect

    function assign_db() {
    /**************************************************************************
    Assigns the database that will be used.
    **************************************************************************/
        # Success boolean check
        $success = @mysql_select_db($this->dbname, $this->link);

        return $success;
    } # End assign_db

    function query($q) {
    /**************************************************************************
    Queries the database and places the result in an array.
    **************************************************************************/
        # Method variables
        $success = false; # Success boolean check
        $result = false;  # Result object returned by query
        $rec = false;     # Individual record
        $r = false;       # Result array to be returned

        # Get the results
        if ($result = @mysql_query($q, $this->link)) {
            # For each returned record, get the record as an array
            if (@mysql_num_rows($result)>0) {
                for ($i=0; $i<@mysql_num_rows($result); $i++) {
                    $rec = @mysql_fetch_array($result, MYSQL_ASSOC);
                    # For each field, get the field name and field value
                    # and assign it to the correct place in the returned
                    # array.
					while (list($field,$value) = each($rec)) {
						$r[$i][$field] = $value;
                    }
                }
                # Free up the memory from the result
                @mysql_free_result($result);
            }
        }
        else {
            $r = "202";
        }
        # Return the value of r (an array if the query was
        # successful or false if the query was not)
		return $r;
    } # End query
    
    function list_tables() {
    /**************************************************************************
    Gets the list of tables in the current database and returns them as an
    array.
    **************************************************************************/
        # Method variables
        $success = false; # Success boolean check
        $i = 0;           # Integer counter
        $list = false;    # Table list holder
        
        # Get the list
        if ($success = @mysql_list_tables($this->dbname, $this->link)) {
            # If successful, then put the table names into an array
            while (list($name) = @mysql_tablename($success)) {
                $list[$i] = $name;
                $i++;
            }
            # Free up the memory from the result
            @mysql_free_result($success);
        }

        # Return the array of table names or false if the
        # query was unsuccessful.
        return $list;
    } # End list_tables

    function list_fields($table) {
    /**************************************************************************
    Gets the list of fields in the current table and returns them as an array.
    **************************************************************************/
        # Method variables
        $success = false; # Success boolean check
        $i = 0;           # Integer counter
        $list = false;    # Field list holder
        $query = false;   # SQL query (SHOW)
        $r = false;       # Temp Record Holder

        # Get the list
        $query = "SHOW COLUMNS FROM " . $table;
        if ($success = @mysql_query($query, $this->link)) {
            # If successful, then put the field names into an array
            for ($i=0; $i<mysql_num_rows($success); $i++) {
                $r = mysql_fetch_array($success);
                $list[$i] = array('name' => $r[Field],
                                 'type' => $r[Type],
                                 'null' => $r[Null],
                                 'key' => $r[Key],
                                 'extra' => $r[Extra],
                                 'default' => $r['Default']
                                );
            }
            # Free up the memory from the result
            @mysql_free_result($success);
        }

        # Return the array of field names or false if the
        # query was unsuccessful.
        return $list;
    } # End list_fields
    
    function insert_id() {
    /**************************************************************************
    Returns the last insert ID if an auto_increment took place during the last
    query.
    **************************************************************************/
        return mysql_insert_id($this->link);
    }

    function error() {
    /**************************************************************************
    Returns the error message returned by the last operation if any.
    **************************************************************************/
        return mysql_error();
    }
}

?>