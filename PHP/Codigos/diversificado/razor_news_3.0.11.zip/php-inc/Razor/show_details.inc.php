<?

###############################################################################
#
#  show_details.inc.php
#  Author:  Peter Adams (adams@editors-wastebasket.org)
#  http://www.editors-wastebasket.org/pta/
#  Date Created: 8 March 2001
#  Last Modified: 18 February 2002
#
#  Description:
#    This file contains all code necessary to get announcement details.
#
# Copyright (c) InterKan.Net, Inc.  All rights reserved.
#
###############################################################################

############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################

function show_details($id, $year) {
/*****************************************************************************
Display the details for the specified announcement.
*****************************************************************************/
    # Global Variables
	global $announcement_table, $d, $SCRIPT_NAME, $num_listed, $use_archive;
	global $archive_link_name;
	
	# Local Variables
	$output = "";         # HTML output container
	$query = false;       # SQL query;
	$news = false;        # Announcement recordset
	
    # Get the Archive recordset
    $query = "SELECT * FROM " . $announcement_table .
             " WHERE newsID = '" . $id . "'";
	
	if (is_string($news = $d->query($query)))
		return show_error($news);
    
	# Get the number of announcements in the table
    $query = "SELECT * FROM " . $announcement_table;
	$t = $d->query($query);

    # Build the Basic header label information
    $output .= "<TABLE CELLSPACING='0' CLASS='RNTableNoBorder' WIDTH='100%'>\n\n";
    $output .= "<TR CLASS='RNTitleTable'>\n<TD CLASS='RNTitleTable'>";
    $output .= $news[0]['title'] . " - " . format_date($news[0]['date']) . "</TD>\n";
    $output .= "<TD ALIGN='RIGHT' CLASS='RNTitleTable'>";
    if (($use_archive) && (count($t) > $num_listed)) {
        $output .= "<A HREF='" . $SCRIPT_NAME . "?az=show_archive&year=" . $year . "' CLASS='RNArchiveLink'>";
        $output .= $archive_link_name . "</A>";
    }
    $output .= "&nbsp;</TD>\n";
    $output .= "</TR>\n\n";
     
    # Build the Announcement text area
    $output .= "<TR CLASS='RNTableRow1'>\n<TD VALIGN='TOP' COLSPAN='2'>";
    $output .= "<P CLASS='RNStandardText'>" . format_long_text(email_links(web_links(stripslashes($news[0]['text'])))) . "</P>\n</TD>\n";
    $output .= "</TR>\n\n</TABLE>\n\n";

    # Return the output container
	return $output;
}

function show_printable_details($id, $year) {
/*****************************************************************************
Display the details for the specified announcement in a printer-friendly
format.
*****************************************************************************/
    # Global Variables
	global $announcement_table, $d, $SCRIPT_NAME;
	
	# Local Variables
	$output = "";         # HTML output container
	$query = false;       # SQL query;
	$news = false;        # Announcement recordset
	
    # Get the Archive recordset
    $query = "SELECT * FROM " . $announcement_table .
             " WHERE newsID = '" . $id . "'";
	if (is_string($news = $d->query($query)))
	    return show_error($news);
		
    # First the border
	$output .= "<TABLE BORDER='0' CELLPADDING='2' CELLSPACING='0' WIDTH='100%' ALIGN='CENTER'>\n\n";
	$output .= "<TR>\n<TD BGCOLOR='#000000'>\n\n";
			 
	# Actual announcement containing table
	$output .= "<TABLE BORDER='0' CELLPADDING='10' CELLSPACING='0' WIDTH='100%' ALIGN='CENTER'>\n\n";
	$output .= "<TR>\n<TD BGCOLOR='#FFFFFF'>\n\n";
			 
	# Announcement Header
	$output .= "<B>" . $news[0]['title'] . "</B><BR>\n";
	$output .= "<B>Date:</B>&nbsp;" . format_date($news[0]['date']) . "<BR>\n\n";
			 
	# Announcement
	$output .= "<P>" . format_long_text($news[0]['text']) . "</P>\n\n";
	$output .= "</TD>\n</TR>\n\n";
	$output .= "</TABLE>\n\n";
			 
	# End the border table
	$output .= "</TD>\n</TR>\n\n";
	$output .= "</TABLE>\n\n";
			 
	$output .= "<P ALIGN='CENTER'><A HREF='" . $HTTP_REFERER . "'>Back</A></P>\n\n";

    # Return the HTML container
	return $output;
}

?>
