<?

###############################################################################
#
#  admin_groups.inc.php
#  Author:  Peter Adams (adams@editors-wastebasket.org)
#  http://www.editors-wastebasket.org/pta/
#  Date Created: 12 October 2001
#  Last Modified: 6 February 2002
#
#  Description:
#    Handles changes to permission levels for existing groups and the
#    addition and rermoval of new and existing groups.
#
# Copyright (c) Peter Adams.  All rights reserved.
#
###############################################################################

############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################

function show_permissions() {
/******************************************************************************
Organizes and prints a list of actions and their permission levels (what groups
have permission to execute the action).  User groups are displayed next to check
boxes.  If the box is checked, the group has access.  Changes are made on a
per-action basis (each action must be updated separately).
******************************************************************************/
    # Get required global variables
    global $admin_action_table, $group_table, $admin_control_table, $d, $az;
	global $SCRIPT_NAME, $_QUERY;
    
    # Function veriables
    $output = "";         # HTML output
    $query = false;       # SQL query
    $action_list = false; # Group Permissions Recordset
    $groups = false;      # User groups recordset
	$count = 1;           # Integer Counter

    # Build the SQL query and get the listing
    $query = "SELECT DISTINCT action_az,title FROM " . $admin_action_table .
             " ORDER BY title";

    if (is_array($action_list = $d->query($query))) {
        if (count($action_list) > 0) {
            # Build a new query to get the list of user groups
            $query = "SELECT groupID,name FROM " . $group_table .
                     " ORDER BY name";

			if (is_array($groups = $d->query($query))) {
                # Display a title

	            # Begin the layout table
	            $output .= "<TABLE BORDER='0' WIDTH='100%' ALIGN='CENTER' CELLPADDING='2'" .
	                       " CELLSPACING='1'>\n\n";

                # Display the path taken to the current point + Add link
            	$output .= "<TR>\n<TD VALIGN='TOP' COLSPAN ='2' CLASS='RNAdminPath'>";
            	$output .= "<A HREF='" . $SCRIPT_NAME . "' CLASS='RNAdminPath'>Administration</A> &gt; ";
            	$output .= "User Permissions</TD>\n";
            	$output .= "</TR>\n\n";

                $output .= "<TR>\n<TD VALIGN='TOP' WIDTH='75%'>";
				$output .= "<TABLE CLASS='RNStandardTable'>\n\n";
                # Recordset was returned
                foreach ($action_list as $action) {
                    # Build the table row
                    $output .= "<FORM METHOD='POST' METHOD='" . $SCRIPT_NAME . "'>";
                    $output .= "<INPUT TYPE='HIDDEN' NAME='az' VALUE='" . $_QUERY['az'] . "'>\n";
                    $output .= "<INPUT TYPE='HIDDEN' NAME='cmd' VALUE='update'>\n";
                    $output .= "<INPUT TYPE='HIDDEN' NAME='action' VALUE='" . $action['action_az'] . "'>\n";
                    $output .= "<TR CLASS='RNTableRow" . ((($count % 2) == 0) ? "2" : "1") . "'>\n";
                    $output .= "<TD WIDTH='80' CLASS='RNTableSideHeader'>Action:</TD>\n";
                    $output .= "<TD COLSPAN='2'>" . $action['title'] . "</TD>\n";
                    $output .= "</TR>\n\n";

                    $output .= "<TR CLASS='RNTableRow" . ((($count % 2) == 0) ? "2" : "1") . "'>\n";
                    $output .= "<TD WIDTH='80' CLASS='RNTableSideHeader'>Groups:</FONT></TD>\n";

                    # Display the list of user groups with checkboxes
                    # boxes are checked if group has permission
                    $output .= "<TD>";
                    for ($i=0; $i<count($groups); $i++) {
                        $output .= "<INPUT TYPE='CHECKBOX' NAME='s_group[" . $i . "]' VALUE='" .
						           $groups[$i]['groupID'] . "'";
                        
						# Check for group access to the action
						$query = "SELECT * FROM " . $admin_control_table .
						         " WHERE action_az = '" . $action['action_az'] . "'" .
								 " AND groupID = '" . $groups[$i]['groupID'] . "'";
						if ($t = $d->query($query)) {
                            $output .= " CHECKED";
                        }
                        $output .= ">" . $groups[$i]['name'] . "\n";
                    }
                    $output .= "</TD>\n";
                    $output .= "<TD ALIGN='RIGHT'>";
                    $output .= "<INPUT TYPE='submit' VALUE='Update'></TD>\n";
                    $output .= "</TR>\n</FORM>\n\n";
					$count++;
                }
                # End the Action/Permission table
                $output .= "</TABLE>\n\n</TD>\n\n";
                $output .= "<TD ALIGN='CENTER' VALIGN='TOP' WIDTH='25%'>\n\n";
                
                # Display the group list
                $output .= show_group_list($groups);

                # End the layout table
                $output .= "</TD>\n</TR>\n\n</TABLE>\n\n";
            }
            else {
                $output = show_error($groups);
            }
        }
    }
    else {
        $output = show_error($action_list);
    }

    # return the output
    return $output;
}

function show_group_list($groups) {
/******************************************************************************
Displays a table with a form to add new groups and a list of existing groups
with links to remove them if necessary.
******************************************************************************/
    # Global Variables
	global $SCRIPT_NAME, $_QUERY;
	
	# Function variables
    $output = false;  # HTML content holder
    $i = 0;           # Integer counter
    $j = 0;           # Integer counter

    # Begin the Group Add/Delete table
    $output .= "<FORM METHOD='POST' ACTION='" . $SCRIPT_NAME . "'>\n";
    $output .= "<INPUT TYPE='HIDDEN' NAME='az' VALUE='" . $_QUERY['az'] . "'>\n";
    $output .= "<INPUT TYPE='HIDDEN' NAME='cmd' VALUE='add'>\n";
    $output .= "<TABLE CLASS='RNStandardTable'>\n\n";
    $output .= "<TR CLASS='RNTableTopHeader'>\n<TD COLSPAN='2'>\n";
	$output .= "Add Group</TD>\n</TR>\n\n<TR CLASS='RNTableRow1' ALIGN='CENTER'>\n<TD>\n";
    $output .= "<INPUT TYPE='TEXT' NAME='add_name' SIZE='12' MAXLENGTH='12'><BR>";
    $output .= "<INPUT TYPE='submit' VALUE='Add Group'>\n";
    $output .= "</TD>\n</TR>\n\n</TABLE>\n</FORM>\n\n";

    # Table Header
    $output .= "<TABLE CLASS='RNStandardTable'>\n\n";
    $output .= "<TR CLASS='RNTableTopHeader'>\n<TH COLSPAN='2'>";
    $output .= "Group List</TD>\n</TR>\n\n";

    # Display user list and action
    for ($i=0; $i<count($groups); $i++) {
        $output .= "<TR CLASS='RNTableRow" . (((($i + 1) % 2) == 0) ? "2" : "1") . "'>\n";
		$output .= "<TD ALIGN='LEFT'>";
        $output .= $groups[$i]['name'] . "</TD>\n";
        $output .= "<TD ALIGN='RIGHT'>";
        $output .= "<A HREF='" . $SCRIPT_NAME . "?az=group_mgr&cmd=c_rmv_group&group=" . $groups[$i]['groupID'] . "'>";
        $output .= "Delete</A></TD>\n</TR>\n\n";
    }

    # End the Group Add/Delete table
    $output .= "</TABLE>\n\n";

    # Return the output
    return $output;
}

function add_group($name, $table) {
/******************************************************************************
Insert a new group into the database.
******************************************************************************/
    # Global Variables
    global $d;
    
    # Function variables
    $query = false;    # SQL query
    $success = false;  # Success boolean
    
    # Build the SQL query
    $query = "INSERT INTO " . $table .
             " (name) VALUES ('" . $name . "')";

    # Execute the query and check the results
    if (! is_string($success = $d->query($query))) {
        return false;
    }
    else {
        # Return the error message
        return show_error($success, "#FF0000");
    }
}

function set_permissions($action) {
/******************************************************************************
Update permissions for the specified action.
******************************************************************************/
    # Global variables
    global $d, $admin_control_table, $s_group;
    
    # Function variables
    $query = false;    # SQL query
    $success = false;  # Success boolean

    # Delete existing permissions
	$query = "DELETE FROM " . $admin_control_table .
	         " WHERE action_az = '" . $action . "'";
	if (is_string($t = $d->query($query)))
	     return show_error($t);
    
    # Build the list of groups
    if (count($s_group)>0) {
        foreach ($s_group as $g) {
            $query = "INSERT INTO " . $admin_control_table . 
			         " (action_az,groupID)" .
					 " VALUES ('" . $action . "','" . $g . "')";
			if (is_string($t = $d->query($query)))
			    return show_error($t);
        }
    }

    return false;
}

function remove_group($name, $table) {
/******************************************************************************
Removes an existing group from the database.
******************************************************************************/
    # Global Variables
    global $d, $admin_control_table;

    # Function variables
    $query = false;    # SQL query
    $success = false;  # Success boolean

    # Build the SQL query
    $query = "DELETE FROM " . $table .
             " WHERE groupID = '" . $name . "'";

    # Execute the query and check the results
    if (! is_string($success = $d->query($query))) {
        $query = "DELETE FROM " . $admin_control_table .
		         " WHERE groupID = '" . $name . "'";
		if (is_string($success = $d->query($query)))
		    return show_error($success);
		return "";
    }
    else {
        # Return the error message
        return show_error($success, "#FF0000");
    }
}

function confirm_remove($name) {
/******************************************************************************
Prints a form to confirm the removal of the specified group.
******************************************************************************/
    # Global variables
    global $conf, $SCRIPT_NAME;
    
    # Function variables
    $output = "";     # HTML output container
    
    # Start the table
    $output .= "<TABLE CLASS='RNStandardTable'>\n\n";
    
    # Caption
    $output .= "<TR CLASS='RNSubtitle'>\n<TD ALIGN='CENTER' COLSPAN='2'>";
    $output .= "Remove group: " . get_group_name($name) . "</TD>\n</TR>\n\n";
    
    # Confirm: Yes/No
    $output .= "<TR>\n<TD ALIGN='RIGHT' WIDTH='50%'>\n";
    $output .= "<FORM METHOD='POST' ACTION='" . $SCRIPT_NAME . "'>";
    $output .= "<INPUT TYPE='HIDDEN' NAME='az' VALUE='group_mgr'>\n";
    $output .= "<INPUT TYPE='HIDDEN' NAME='cmd' VALUE='rmv_group'>\n";
    $output .= "<INPUT TYPE='HIDDEN' NAME='id' VALUE='" . $name . "'>\n";
    $output .= "<INPUT TYPE='submit' VALUE='Yes'>\n";
    $output .= "</FORM>\n</TD><TD ALIGN='LEFT' WIDTH='50%'>\n";
    $output .= "<FORM METHOD='POST' ACTION='" . $SCRIPT_NAME . "'>";
    $output .= "<INPUT TYPE='HIDDEN' NAME='az' VALUE='group_mgr'>\n";
    $output .= "<INPUT TYPE='submit' VALUE='No'>\n";
    $output .= "</FORM>\n</TD>\n</TR>\n\n";
    
    # End the table
    $output .= "</TABLE>\n\n";
    
    # Return the output
    return $output;
}

?>