<?

###############################################################################
#
#  global_sess.inc.php
#  Author:  Peter Adams (pta@interkan.net)
#  http://www.interkan.net
#  Date Created: 3 January 2002
#  Last Modified: 3 May 2002
#
#  Description:
#    Contains all functions for updating session data in a database table.
#
# Copyright (c) 2001-2002
#      InterKan.Net, Inc.  All rights reserved.
#
###############################################################################

############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################

# Set the session handling functions
session_set_save_handler("on_session_write", "on_session_end",
                         "on_session_read", "on_session_write",
						 "on_session_destroy", "on_session_gc");

function on_session_start($save_path, $session_name) {
/******************************************************************************
Initializes session information
******************************************************************************/
    # Global Variables
	global $HTTP_HOST, $HTTP_COOKIE_VARS, $_QUERY, $session_expire;

	# One year's worth of seconds
	$one_year = 31536000;

	# Place a cookie on the user's box with the session ID in it.
	#if (! $HTTP_COOKIE_VARS[$session_name]) {
    #    if ($_QUERY['save_session'] == 'on') {
    #		setcookie($session_name,
	#		          "%%" . $session_name,
	#				  time() + $one_year,
	#				  "/",
	#				  eregi_replace("^www.", "", $HTTP_HOST));
	#		$session_expire = $one_year;
	#	}
	#	else {
    #		setcookie($session_name,
	#		          $session_name,
	#				  time() + $session_expire,
	#				  "/",
	#				  $HTTP_HOST);
	#    }
	#}
	#else {
	#    if (substr($HTTP_COOKIE_VARS[$session_name], 0, 2) == "%%") {
	#		$session_expire = 31536000;
	#	}
	#}

	return;
}

function on_session_end() {
/******************************************************************************
Perform any end session actions.
******************************************************************************/
    # Do nothing since we used a persistent connection
	return;
}

function on_session_read($key) {
/******************************************************************************
Retrieve the session data and return it to the application
******************************************************************************/
    # Global variables
	global $d, $session_table, $PHPSESSID;

	# Function Variables
	$query = false;     # SQL query
	$session_i = false; # Session information recordset

	# Build the query
	$query = "SELECT data FROM " . $session_table .
	         " WHERE (sessionID = '" . $PHPSESSID . "'" .
			 " AND expiration >= NOW() + 0)";

	if (! is_string($session_i = $d->query($query))) {
	    # Return the session data
		return $session_i[0][data];
	}
}

function on_session_write($key, $val) {
/******************************************************************************
Writes the session data to the table
******************************************************************************/
    # Global variables
	global $d, $session_table, $session_expire, $PHPSESSID;

	# Function variables
	$ins_q = false;     # Insert SQL query
	$upd_q = false;     # Update SQL query
	$written = false;   # success check

	# Make the data SQL query safe
	$val = addslashes($val);

	# Build the queries and write the info
	$ins_q = "INSERT INTO " . $session_table .
	          " VALUES('" . $PHPSESSID . "', '" . $val . "', NOW() + ";
	$ins_q .= isset($session_expire) ? $session_expire : "3600";
	$ins_q .= ")";
	$upd_q = "UPDATE " . $session_table .
	         " SET data = '" . $val . "'," .
	         " expiration = NOW() + ";
	$upd_q .= isset($session_expire) ? $session_expire : "3600";
	$upd_q .= " WHERE sessionID = '" . $key . "'";

	# Try and insert, then update if an error occured (session already exists)
	if (is_string($written = $d->query($ins_q))) {
		$written = $d->query($upd_q);
	}

	return;
}

function on_session_destroy($key) {
/******************************************************************************
Deletes all session data when session is ended/unset
******************************************************************************/
    # Global variables
	global $d, $session_table, $PHPSESSID;

	# Function Variables
	$query = false;     # SQL query
	$destroyed = false; # Success check

	# Build the query & execute
	$query = "DELETE FROM " . $session_table .
	         " WHERE sessionID = '" . $PHPSESSID . "'";
	$d->query($query);

	return;
}

function on_session_gc($max_lifetime) {
/******************************************************************************
Deletes all expired sessions
******************************************************************************/
    # Global variables
	global $d, $session_table;

    # Function Variables
	$query = false;     # SQL query
	$destroyed = false; # Success check

	# Build the query & execute
	$query = "DELETE FROM " . $session_table .
	         " WHERE expiration < NOW()";
	$d->query($query);

	return;
}

?>
