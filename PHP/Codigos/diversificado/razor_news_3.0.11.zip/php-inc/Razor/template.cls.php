<?

###############################################################################
#
#  template.cls.php
#  Author:  Peter Adams (pta@interkan.net)
#  http://www.interkan.net
#  Date Created: 10 October 2001
#  Last Modified: 14 May 2002
#
#  Description:
#    Contains a for opening, reading and processing templates.
#
# Copyright (c) 2001
#      InterKan.Net, Inc.  All rights reserved.
#
###############################################################################

############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################

class template {

    # Property Variable Declaration
    var $content  = false; # Template content
    var $filename = false; # Template Filename
	var $original = false; # Original template content
    
    function template($file = false) {
    /**************************************************************************
    Constructor:  Specifies the template file to be used.
    **************************************************************************/
        # Assign the template filename
        $this->filename = $file;
    } # End template

    function open() {
    /**************************************************************************
    Reads the content of the file into the content property.
    **************************************************************************/
        # Method variables
        $line = false; # Temporary holding variable
        $i = 0;        # Integer counter

        # Open the filename if it exists and the property is set
        if (@file_exists($this->filename)) {
            # Reset the content property
            $this->original = "";
            
            # Get the file contents by line
            $line = file($this->filename);
            if (is_array($line)) {
                # echo "it checked out as an array.";
                for ($i=0; $i<count($line); $i++) {
                    # Build the content
                    $this->original .= $line[$i];
                }
            }
            # Return true since the file was opened (for error checking)
            if (is_array($line))
                $line = true;
            else
                $line = false;
        }
        return $line;
    } # End open

    function set_markers($markers) {
    /**************************************************************************
    Replace markers in the template with generated content.
    **************************************************************************/
        if (is_array($markers)) {
            # Keep the original content and manipulate the other stuff
			$this->content = $this->original;
   
            # Translate the SSI content
            $this->get_ssi();
			
			# Replace each instance of all markers
            while (list($marker,$content) = each($markers)) {
                $this->content = ereg_replace("\{" . $marker . "\}", $content, $this->content);
            }
        }
    } # End set_marker
    
    function get_ssi() {
    /**************************************************************************
    Retrieve server side include files for inclusion in the template.
    **************************************************************************/
        # Global variables
        global $HTTP_HOST;
        
        # Local variables
        $ssi_pattern =         # Pattern for matching an SSI statement
             "\<\!\-\-\#include virtual=[\"\']{1}([\.\/\_A-Z0-9\-]+)[\"\']{1} \-\-\>";
        $ssi_content = "";     # SSI file contents -- retrieved via HTTP
        
        if (is_string($this->content)) {
            # First do a search for any SSI statements
            while (eregi($ssi_pattern, $this->content, $includes)) {
                # Looks like some includes were found, lets get the files
                if (is_array($includes)) {
                    if (! empty($includes[1]) && $includes[1] != "" && ! ereg("^" . $ssi_pattern . "$", $includes[1])) {
                        # Get the SSI content
                        $t = @file("http://" . $HTTP_HOST . $includes[1]);

                        # Build to a single string
                        while (list($k,$v) = @each($t)) {
                            $ssi_content .= $v;
                        }

                        # Replace the SSI statement
                        $this->content = eregi_replace("\<\!\-\-\#include virtual=[\"\']{1}" . $includes[1] . "[\"\']{1} \-\-\>", $ssi_content, $this->content);
                        
                        # Clear the SSI content
                        $ssi_content = "";
                    }
                }
            }
        }
    }
}

?>
