<?

###############################################################################
#
#  admin_announcement.inc.php
#  Author:  Peter Adams (adams@editors-wastebasket.org)
#  http://www.editors-wastebasket.org/pta/
#  Date Created: 8 March 2001
#  Last Modified: 23 May 2002
#
#  Description:
#    This file contains all code necessary to generate a form used to add a
#    new announcement as well as a list of announcements with buttons to
#    delete one from the database.
#
# Copyright (c) InterKan.Net, Inc.  All rights reserved.
#
###############################################################################

############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################

# Initialize Module-specific marker variables
$SUBTITLE = "<P CLASS='RNSubtitle'>" . $a_title . "<BR> - " .
            (($_QUERY['cmd'] == 'edit') ? "Edit" : "Add") . " Announcement -</P>\n\n";

function show_main($valid = true, $edit = false, $news = false, $year = '%') {
/******************************************************************************
Print the announcement add form.
******************************************************************************/
    # Global Variables
	global $SCRIPT_NAME, $category_list, $alert_list, $_QUERY, $d;
	
	# Local Variables
	$output = "";      # HTML output container
	$i = 0;            # Integer counter
    $row = 0;          # Row counter
	
    # Start the form and specify the actions
    $output .= "<FORM METHOD='POST' ACTION='" . $SCRIPT_NAME . "'>\n";
    $output .= "<INPUT TYPE='HIDDEN' NAME='az' VALUE='admin'>\n";
    $output .= "<INPUT TYPE='HIDDEN' NAME='cmd' VALUE='" . 
	           ((($edit && (! $valid)) || $edit) ? "update" : "add") . "'>\n";
	$output .= "<INPUT TYPE='HIDDEN' NAME='year' VALUE='" . $year . "'>\n";
	$output .= "<INPUT TYPE='HIDDEN' NAME='aid' VALUE='" . ((! $valid) ? $_QUERY['aid'] : $news['newsID']) . "'>\n";

    # HEADER
    $output .= "<TABLE CLASS='RNStandardTable'>\n\n";
    $output .= "<TR>\n<TD COLSPAN='2'>\n";
    $output .= "<TABLE CLASS='RNAdminMenu'>\n";
    $output .= "<TR CLASS='RNTableTopHeader'>\n";
    $output .= "<TD ALIGN='CENTER'>";
    $output .= "Add Announcement</TD>\n</TR>\n\n</TABLE>\n";
    $output .= "</TD>\n</TR>\n\n";

    # INPUT BOXES
    $output .= "<TR VALIGN='TOP'>\n<TD CLASS='RNTableSideHeader'>";
    $output .= "Category:</TD>\n";
    $output .= "<TD CLASS='RNTableRow" . ((($row % 2) == 0) ? "1" : "2") . "'><SELECT NAME='category'>\n";
    
	# First the Regular Category List
	for ($i=0; $i<count($category_list); $i++) {
        $output .= "<OPTION VALUE='". $category_list[$i] . "'";
        if ((($_QUERY['category'] == $category_list[$i]) && (! $valid))
		   || ($edit && ($news['category'] == $category_list[$i]))) {
            $output .= " SELECTED";
        }
        $output .= ">" . $category_list[$i] . "</OPTION>\n";
    }
	
	# Then the Alert Category List
    for ($i=0; $i<count($alert_list); $i++) {
        $output .= "<OPTION VALUE='". $alert_list[$i] . "'";
        if ((($_QUERY['category'] == $alert_list[$i]) && (! $valid))
		   || ($edit && ($news['category'] == $alert_list[$i]))) {
            $output .= " SELECTED";
        }
        $output .= ">" . $alert_list[$i] . "</OPTION>\n";
    }
    $output .= "</SELECT></TD>\n</TR\n\n";

    # Increment the row
    $row++;

    $output .= "<TR VALIGN='TOP'>\n<TD CLASS='RNTableSideHeader'>";
    $output .= "Announcement Heading:</TD>\n";
    $output .= "<TD CLASS='RNTableRow" . ((($row % 2) == 0) ? "1" : "2") . "'><INPUT TYPE='TEXT' NAME='heading' SIZE='30'";
    if (! $valid) {
        $output .= " VALUE='" . $_QUERY['heading'] . "'";
    }
	elseif ($edit) {
	    $output .= " VALUE='" . $news['title'] . "'";
	}
    $output .= ">";
    $output .= "</TD>\n</TR\n\n";
    
    # Increment the row
    $row++;

    $output .= "<TR>\n<TD VALIGN='TOP' CLASS='RNTableSideHeader'>";
    $output .= "Announcement:</TD>\n";
    $output .= "<TD CLASS='RNTableRow" . ((($row % 2) == 0) ? "1" : "2") . "'><TEXTAREA NAME='a_text' COLS='40' ROWS='10' WRAP='VIRTUAL'>";
    if (! $valid) {
        $output .= $_QUERY['a_text'];
    }
	elseif ($edit) {
	    $output .= $news['text'];
	}
    $output .= "</TEXTAREA>";
    $output .= "</TD>\n</TR\n\n";
    
    # Increment the Row
    $row++;

    # SUBMIT AND CLEAR BUTTONS
    $output .= "<TR>\n<TD COLSPAN='2'>&nbsp;&nbsp;&nbsp;&nbsp;";
    $output .= "<INPUT TYPE='submit' VALUE='" . (($edit) ? "Update" : "Add") . " Announcement'>\n";
    $output .= "<INPUT TYPE='reset' VALUE='Clear Form'></TD>\n</TR>\n\n";
    $output .= "<TR>\n<TD>&nbsp;</TD>\n</TR>\n\n";

    # End Output
    $output .= "</TABLE>\n\n";
    $output .= "</FORM>\n";

    # Return the output
    return $output;
}

function show_list($offset = 0, $limit, $year) {
/******************************************************************************
Print a list of the announcements in the database with links to edit or delete.
******************************************************************************/
    # Global Variables
	global $announcement_table, $SCRIPT_NAME, $d;
	
	# Local Variables
    $output = "";          # HTML Output container
	$query = false;        # SQL query
	$a_rset = false;       # Archive Recordset
    $row = 1;          # Current Row
    $num_pages = 0;        # Number of pages in the archive
	
    # Get the Archive recordset
    $query = "SELECT * FROM " . $announcement_table .
             " WHERE date >= '" . $year . "-01-01'" .
			 " AND date < '" . ((integer) $year + 1) . "-01-01'" .
             " ORDER BY date DESC" .
             " LIMIT " . $offset . "," . $limit;
	if (is_string($a_rset = $d->query($query)))
	    return show_error($a_rset);

    # Build the listing
    if (is_array($a_rset)) {
        $output .= "<TABLE CLASS='RNTableNoBorder'>\n\n";
        foreach ($a_rset as $a) {
            if (($row % 2) == 0) {
                $class = "RNTableRow2";
            }
            else {
                $class = "RNTableRow1";
            }
          
		    # ANNOUNCEMENT INFORMATION
            $output .= "<TR>\n<TD ALIGN='LEFT' CLASS='" . $class . "'>";
            $output .= $a['title'] . " (<A HREF='" .
                       $SCRIPT_NAME . "?az=admin&cmd=list&sub=change_lock&aid=" .
                       $a['newsID'] . "&start=" . $offset . "&year=" . $year . "' CLASS='" . $class . "'><B>" .
                       (($a['lock_status'] > 0) ? "Unlock" : "Lock") . "</B></A>)";
            $output .= "<BR>\n(" . format_date($a['date']) . ")\n";
            $output .= "</TD>\n";

            # FUNCTIONS
            $output .= "<TH ALIGN='RIGHT' WIDTH='100' CLASS='" . $class . "'>";
            $output .= "<A HREF='" . $SCRIPT_NAME . "?az=admin&cmd=edit&aid=" . $a['newsID'] .
			           "&year=" . $year . "' CLASS='" . $class . "'>";
            $output .= "Edit</A><BR>\n";
            $output .= "<A HREF='" . $SCRIPT_NAME . "?az=admin&cmd=c_rmv&aid=" .
			           $a['newsID'] . "&year=" . $year . "' CLASS='" . $class . "'>";
            $output .= "Delete</A>\n";
            $output .= "</TH>\n</TR>\n\n";
			
			# Increment the row moron!
			$row++;
        }
        $output .= "</TABLE>\n\n";
    }
    else {
        $output .= "<P CLASS='RNErrorMessage'>";
        $output .= "No Announcements for " . $year . ".</P>";
    }
	
	# Return the HTML container
	return $output;
}

function show_edit($aid, $year) {
/******************************************************************************
Display a form to edit the announcement.
******************************************************************************/
    # Global Variables
	global $announcement_table, $d;
	
	# Local Variables
	$output = "";      # HTML output container

    # Get the Archive recordset
    $query = "SELECT * FROM " . $announcement_table .
             " WHERE newsID = '" . $aid . "'" .
			 " LIMIT 1";
    if (is_string($news = $d->query($query)))
	    return show_error($news);
		
    # Show the edit form
	$output .= show_main(true, true, $news[0], $year);
	
	# Return HTML container
	return $output;
}

function change_lock($id) {
/******************************************************************************
Change the lock status of an announcement.  Make sure only X-1 announcements
are locked (where X is the number of announcements displayed on the front
page).
******************************************************************************/
    # Global variables
    global $announcement_table, $d, $num_listed;
    
    # Local Variables
    $query = false;     # SQL query
    $success = false;   # Success boolean
    $news = false;      # News recordset
    
    # Check the current lock status of the specified announcement
    $query = "SELECT lock_status FROM " . $announcement_table .
             " WHERE newsID = '" . $id . "'" .
             " LIMIT 1";
    if (is_string($news = $d->query($query)))
        return show_error($news);
        
    # Change the status of the specified announcement
    if ($news[0]['lock_status'] > 0) {
        # Change the status of only the specified announcement
        $query = "UPDATE " . $announcement_table .
                 " SET lock_status = '0'" .
                 " WHERE newsID = '" . $id . "'" .
                 " LIMIT 1";
    }
    else {
        # Update all announcements
        $query = "UPDATE " . $announcement_table .
                 " SET lock_status = (lock_status + 1)" .
                 " WHERE ((lock_status > 0)" .
                 " AND lock_status < " . $num_listed . ")" .
                 " OR newsID = '" . $id . "'";
    }
    if (is_string($success = $d->query($query)))
        return show_error($success);
        
    # Check the X-1 condition
    $query = "UPDATE " . $announcement_table .
             " SET lock_status = '0'" .
             " WHERE lock_status >= '" . $num_listed . "'";
    if (is_string($news = $d->query($query)))
        return show_error($news);
        
    # Return boolean value
    return false;
}

function add_announcement() {
/******************************************************************************
Add a new announcement to the database.
******************************************************************************/
    # Global Variables
	global $announcement_table, $_QUERY, $d;

    # Local Variables
	$today = date('Y-m-d');    # Today's Date
	$error = false;            # Error occurrence boolean/message
	
	# Validate the information
	if ($error = validate_announcement_info())
	    return $error;
	 
	# Build the INSERT query
    $query = "INSERT INTO " . $announcement_table .
             " (category, title, text, date)" .
             " VALUES ('" . $_QUERY['category'] .
             "','" . htmlspecialchars($_QUERY['heading'], ENT_QUOTES) .
             "','" . ereg_replace("'", "&#039;", $_QUERY['a_text']) .
             "','" . $today . "')";
	if (is_string($news = $d->query($query)))
        return show_error($news);
    
	# Return error stuff
	return $error;
}

function update_announcement() {
/******************************************************************************
Update and existing announcement.
******************************************************************************/
    # Global Variables
	global $announcement_table, $_QUERY, $d;
	
	# Local Variables
	$output = "";     # HTML output container
	$query = false;   # SQL query
	
	# Validate the information
	if ($error = validate_announcement_info())
	    return $error;
	 
    # Build the UPDATE query
    $query = "UPDATE " . $announcement_table .
             " SET category = '" . $_QUERY['category'] . "'," .
             "title = '" . htmlspecialchars($_QUERY['heading'], ENT_QUOTES) . "'," .
             "text = '" . ereg_replace("'", "&#039;", $_QUERY['a_text']) . "'" .
             " WHERE newsID = '" . $_QUERY['aid'] . "'";

    if (is_string($s = $d->query($query)))
        return show_error($s);

	# Return HTML container
	return $output;
}

function confirm_remove($aid, $year) {
/******************************************************************************
Verify the user really wants to remove the announcement.
******************************************************************************/
    # Global Variables
	global $SCRIPT_NAME;
	
	# Local Variables
    $output = "";    # HTML output container
	
    # HEADING
    $output .= "<BR><TABLE CLASS='RNStandardTable'>\n";
    $output .= "<TR>\n<TD COLSPAN='2'>\n";
    $output .= "<TABLE CLASS='RNAdminMenu'>\n";
    $output .= "<TR CLASS='RNHeader'>\n";
    $output .= "<TD ALIGN='CENTER'>";
    $output .= "Delete announcement #" . $aid . "?</TD>\n</TR>\n\n</TABLE>\n";
    $output .= "</TD>\n</TR>\n\n";

    # YES
    $output .= "<TR>\n<TD ALIGN='RIGHT'>";
    $output .= "<FORM METHOD='POST' ACTION='" . $SCRIPT_NAME . "'>\n";
    $output .= "<INPUT TYPE='HIDDEN' NAME='az' VALUE='admin'>\n";
    $output .= "<INPUT TYPE='HIDDEN' NAME='cmd' VALUE='rmv'>\n";
	$output .= "<INPUT TYPE='HIDDEN' NAME='year' VALUE='" . $year . "'>\n";
    $output .= "<INPUT TYPE='HIDDEN' NAME='aid' VALUE='" . $aid . "'>\n";
    $output .= "<INPUT TYPE='submit' VALUE='Yes'>";
    $output .= "</FORM></TD>\n";

    # NO
    $output .= "<TD ALIGN='LEFT'><FORM METHOD='POST' ACTION='" . $SCRIPT_NAME . "'>\n";
    $output .= "<INPUT TYPE='HIDDEN' NAME='az' VALUE='admin'>\n";
    $output .= "<INPUT TYPE='HIDDEN' NAME='cmd' VALUE='list'>\n";
	$output .= "<INPUT TYPE='HIDDEN' NAME='year' VALUE='" . $year . "'>\n";
    $output .= "<INPUT TYPE='submit' VALUE='No'>";
    $output .= "</FORM></TD>\n</TR>\n\n</TABLE>\n\n";

    # Return the output container
	return $output;
}

function remove_announcement($aid) {
/******************************************************************************
Delete an existing announcement
******************************************************************************/
    # Global Variables
	global $announcement_table, $d;
	
	# Local Variables
	$query = false;    # SQL query
	$error = false;    # Error message holder/boolean
	
    # Build the DELETE query
    $query = "DELETE FROM " . $announcement_table .
             " WHERE newsID = '" . $aid . "'";
          
    # Delete or return error message
	if (is_string($s = $d->query($query)))
        return show_error($s);

	# Return the response
    return $error;
}

function validate_announcement_info() {
/******************************************************************************
Validate the information submitted to the application.
******************************************************************************/
    # Global Variables
	global $_QUERY;
	
	# Local Variables
	$error = false;    # Error 
	
	# Validate submitted values
    if (empty($_QUERY['category']))
        return show_error('400');

    if (empty($_QUERY['heading']))
        return show_error('401');

    if (empty($_QUERY['a_text']))
        return show_error('402');

   # Return error message
   return $error;
}

?>
