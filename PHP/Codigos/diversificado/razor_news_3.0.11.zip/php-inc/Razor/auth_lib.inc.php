<?

###############################################################################
#
#  auth_lib.inc.php
#  Author:  Peter Adams (adams@editors-wastebasket.org)
#  http://www.editors-wastebasket.org/pta/
#  Date Created: 11 October 2001
#  Last Modified: 7 February 2002
#
#  Description:
#    Displays the login form and authenticates users.
#
# Copyright (c) Peter Adams.  All rights reserved.
#
###############################################################################

############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################

function show_login_form($tpl) {
/******************************************************************************
Display an HTML formatted form requesting the userid and password of the user.
******************************************************************************/
    # Global variables
    global $cfg, $SCRIPT_NAME, $rn_dir;
    
    # Function Variables
    $output = "";      # HTML output container
	$l_form = false;   # Login form template class instance
	$markers = false;  # Markers array
		
	# Begin the FORM
	$output .= "<FORM METHOD='POST' ACTION='" . $SCRIPT_NAME . "'>\n";
	$output .= "<INPUT TYPE='HIDDEN' NAME='cmd' VALUE='login'>\n";
	
	# Get the login form
	$l_form = new template($tpl);
	
	if (! $l_form->open())
	    return show_error('100', $tpl);
	
	# Set the markers and replace those in the template
	$markers = array('FONT' => $cfg[font_face],
					 'SIZE' => $cfg[font_size]
					);
	$l_form->set_markers($markers);
	$output .= $l_form->content;
	
	# End the FORM
	$output .= "</FORM>\n\n";
	
	# Return the HTML form
	return $output;
}

function auth_user($user, $password) {
/******************************************************************************
Authenticates the submitted user.
******************************************************************************/
    # Get Global Variables
    global $d, $user_table;

    # Function Variables
    $s = false;      # Success Boolean
    $query = false;  # SQL query
    
    # Check the user
    $query = "SELECT userid,password FROM " . $user_table .
             " WHERE (userid = '" . $user . "' AND" .
             " password = MD5('" . $password . "'))";
    if (($s = $d->query($query)) && (count($s) == 1)) {
		# User was authenticated
        return true;
    }
    else {
	    # User was invalid
        return false;
    }
}

function get_user_group($user) {
/******************************************************************************
Get the group the user belongs to and return it.
******************************************************************************/
    # Global variables
    global $d, $user_table;
    
    # Function variables
    $group = false;   # Group name to be returned
    $query = false;   # SQL Query
    $rset = false;    # Username recordset

    # Build the SQL query
    $query = "SELECT groupID FROM " . $user_table .
             " WHERE userid = '" . $user . "'";

    # Get the user recordset
    if (is_array($rset = $d->query($query)))
        $group = $rset[0]['groupID'];
    else
        # There was an error with the database query
        $group = show_error($rset, "#FF0000");

    # Return the group or error message
    return $group;
} # End get_group

function validate_user_action($group, $action) {
/******************************************************************************
Checks to make sure the user has access to the specified action.  Displays an
error message if the user does not.
******************************************************************************/
    # Global variables
    global $d, $admin_control_table, $cfg;
    
    # Function Variables
    $s = false;      # Success Boolean
    $query = false;  # SQL query
    $access = false;  # Access boolean

    # Check the group's permission for specified action
    if ($group != "") {
        $query = "SELECT action_az,groupID FROM " . $admin_control_table .
                 " WHERE action_az = '" . $action . "'" .
                 " AND groupID = '" . $group . "'";
		if (is_array($s = $d->query($query))) {
            if (count($s) == 1) {
                $access = true;
            }
        }
    }
    
    # Return the validation (true/false)
	return $access;
}

function logout($tpl_f) {
/******************************************************************************
Log the user out of the system.
******************************************************************************/
    # Global Variables
    global $tpl, $cfg;
    
    # Unset all data and destroy the session
    session_destroy();
	session_unset();
    
    # Display a logged out message
    $markers = array('HTML_MAIN' => show_error('901') . show_login_form($tpl_f),
                     'MENU' => "",
					 'NAVIGATION' => "",
					 'SUBTITLE' => "<P CLASS='RNSubtitle'>Logout...</P>",
                    );
    display_output($markers, $tpl);
    exit;
}

?>