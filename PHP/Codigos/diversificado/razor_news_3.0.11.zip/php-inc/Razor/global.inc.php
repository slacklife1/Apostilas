<?

###############################################################################
#
#  global.inc.php
#  Author:  Peter Adams (adams@editors-wastebasket.org)
#  Date Created: 7 March 2001
#  Last Modified: 15 February 2002
#
#  Description:
#    This file is used as a global library file, containing all frequently
#    used functions.  It is included by default.
#
# Copyright (c) InterKan.Net, Inc.  All rights reserved.
#
###############################################################################

function display_output($markers, $template) {
/******************************************************************************
Displays the completed output to the user.
******************************************************************************/
    # Build the displayed content
    $t = new template($template);

	if (! $t->open()) {
        echo show_error("100", "#FF0000", $template);
        exit;
    }
    $t->set_markers($markers);

    # Display the completed content
    echo $t->content;
	exit;
} # End display_output

function email_links($text) {
/*****************************************************************************
Formats any e-mail addresses found in text as clickable links.
*****************************************************************************/
     # Break out each word in the text
     $t = explode(" ", $text);

     for ($i=0; $i<count($t); $i++) {
          # Break away any new lines from the end of any words.
          $w = explode("\n", $t[$i]);

          for ($j=0; $j<count($w); $j++) {

               # For each word, check for an e-mail address
               if (ereg("([A-Za-z0-9_\-\.]+\@[A-Za-z0-9_\.\-]+[A-Za-z]+)", $w[$j], $email)) {

                    # If there are matches, change them into links
                    if (is_array($email)) {
                         $w[$j] = eregi_replace($email[0], "<A HREF='mailto:" . $email[0] . "'>" . $email[0] . "</A>", $w[$j]);
                    }
               unset($email);
               }
			if ($j == 0) {
                    $t[$i] = $w[$j];
               }
			else {
				$t[$i] .= "\n" . $w[$j];
			}
		}
          if ($i == 0) {
               $new = $t[$i];
          }
          else {
               $new .= " " . $t[$i];
     	}
	}
     return $new;
} // End email_links function

function format_date($date) {
/*****************************************************************************
Formats the date to the following:  Mmmmmm dd, YYYY
*****************************************************************************/
     $m = array('', 'January', 'February', 'March', 'April',
               'May', 'June', 'July', 'August', 'September', 'October',
               'November', 'December');
     $temp = explode("-", $date);
     $year = $temp[0];
     $month = $temp[1];
     $day = $temp[2];

 	$month = eregi_replace("^0", "", $month);
     $month = $m[$month];
 	$day = eregi_replace("^0", "", $day);

	$output = $month . " " . $day . ", " . $year;
	return $output;
} // End format_date function

function format_long_text($text) {
/*****************************************************************************
Formats long announcements into neatly organized paragraphs.
*****************************************************************************/
    $output = eregi_replace("\n", "<BR>\n", $text);
    return $output;
} // End format_long_text function

function get_admin_menu() {
/*****************************************************************************
This function builds the administration menu HTML.
*****************************************************************************/
     # Global Variables
	 global $th_bgcolor, $th_fgcolor, $archive_size, $adminurl;
	 global $mainurl;
     
	 # Initialize variables
     $output = "";

     # Build the menu
     $output .= "<TABLE CLASS='RNAdminMenu'>\n\n";
     $output .= "<TR CLASS='RNAdminMenuItem'>\n<TD WIDTH='75' CLASS='RNAdminMenuItem'>";
     $output .= "MENU:</TD>\n<TD CLASS='RNAdminMenuItem'>";
     $output .= "<A HREF='" . $adminurl . "?az=admin' CLASS='RNAdminMenuItem'>";
     $output .= "Add Announcement</A> |\n";
     $output .= "<A HREF='" . $adminurl . "?az=admin&cmd=list' CLASS='RNAdminMenuItem'>";
     $output .= "List Announcements</A> |\n";
     $output .= "<A HREF='" . $adminurl . "?az=user_mgr' CLASS='RNAdminMenuItem'>";
     $output .= "User Manager</A> |\n";
     $output .= "<A HREF='" . $adminurl . "?az=group_mgr' CLASS='RNAdminMenuItem'>";
     $output .= "User Permissions</A> |\n";
     $output .= "<A HREF='" . $adminurl . "?az=logout' CLASS='RNAdminMenuItem'>";
     $output .= "Logout</A>\n";
     $output .= "</TD>\n</TR>\n\n</TABLE>\n\n";

     # Return results
     return $output;
} // End adminMenu

function getCaption($text, $length) {
/*****************************************************************************
This function determines if the passed text is larger than the caption word
limit.  If so, then the text is reduced to the caption word limit and a
"[ More ]" link is added to the end.
*****************************************************************************/
     # Initialize variables
     $new_text = ""; // Caption text to be returned
     
     # Compare text length
     if (strlen($text) > $length) {
          $new_text .= substr($text, 0, $length);
          $new_text .= " ...&nbsp;&nbsp;[&nbsp;<A HREF=\"{URL}\">More</A> ]";
          return $new_text;
     }
     else {
          return $text;
     }
} // End getCaption function

function get_group_name($id) {
/******************************************************************************
Retrieve the name of the group with the specified ID.
******************************************************************************/
    # Global Variables
	global $group_table, $d;
	
    # Local Variables
	$query = false;
	
	# Build the query and return the name
	$query = "SELECT name FROM " . $group_table .
	         " WHERE groupID = '" . $id . "'";
	if (is_string($t = $d->query($query)))
	    return show_error($t);
	
	# Return the group
	return $t[0]['name'];
}

function is_void($str, $mode=false) {
/******************************************************************************
Validates that a string contained actual data.
******************************************************************************/
   $str = trim($str);
   if (strlen($str)==0) return true;
   else if (($mode==true) && ($str=="0")) return true;
   else return false;
}

function news_list_navigation($start, $archive_listed, $year, $action = 'show_archive') {
/*****************************************************************************
This function builds the navigation menu HTML.
*****************************************************************************/
    # Global Variables
	global $announcement_table, $SCRIPT_NAME, $d;
	
	# Local Variables
	$output = "";        # HTML output container
	$query = false;      # SQL query
	$num_pages = 0;      # Number of pages
    $n_rset = false;     # Navigation Recordset
    $n = false;          # Navigation Record

    # Build Navigation Menu (Previous Page)
    $output .= "<TABLE CLASS='RNListNavigationTable'>\n\n";
    $output .= "<TR>\n<TD CLASS='RNListNavigation' ALIGN='LEFT' WIDTH='75'>";

    # Build the query
    if (($start > 0) && ($start >= $archive_listed)) {
        $query = "SELECT * FROM " . $announcement_table .
                 " WHERE date >= '" . $year . "-01-01'" .
				 " AND date < '" . ((integer) $year + 1) . "-01-01'" .
                 " ORDER BY date DESC" .
                 " LIMIT " . Abs(($archive_listed - $start)) . "," . $archive_listed;
        if (is_string($n_rset = $d->query($query)))
    	    return (show_error($n_rset) . "</TD></TR></TABLE>");
		
		# Check the count and display link or empty space	
    	if (is_array($n_rset) && count($n_rset) > 0) {
    		$output .= "<A HREF='" . $SCRIPT_NAME . "?az=" . $action . "&cmd=list&start=" .
	    	           Abs(($archive_listed - $start)) . "&year=" . $year . "' CLASS='RNListNavigation'>";
            $output .= "Previous</A>";
        }
		else {
		    $output .= "&nbsp;";
		}
    }
    else {
	    # Not adding any previous link
        $output .= "&nbsp;";
    }

    # End Previous link
    $output .= "</TD>\n";
    $output .= "<TD ALIGN='CENTER' CLASS='RNListNavigation'>";

    # Check for archived items in the previous year
    $query = "SELECT * FROM " . $announcement_table .
             " WHERE (date >= '" . ((integer) $year - 1) . "-01-01'" .
		     " AND date < '" . $year . "-01-01')";
    if (is_string($n_rset = $d->query($query)))
	    return (show_error($n_rset) . "</TD></TR></TABLE>");
		
	if (is_array($n_rset) && count($n_rset) > 0) {
    	$output .= "[&nbsp;<A HREF='" . $SCRIPT_NAME . "?az=" . $action . "&cmd=list&start=0" .
                   "&year=" . ((integer) $year - 1) . "' CLASS='RNListNavigation'>" . ((integer) $year - 1) .
            	   "</A>&nbsp;]&nbsp;&nbsp;";
    }
	
    # Build Navigation Menu (By Number of Pages)
    $query = "SELECT * FROM " . $announcement_table .
	         " WHERE date >= '" . $year . "-01-01' AND" .
			 " date < '" . ((integer) $year + 1) . "-01-01'" .
             " ORDER BY date DESC";

    if (is_string($n_rset = $d->query($query)))
	    return (show_error($n_rset) . "</TD></TR></TABLE>");

    # Get the number of pages
    $num_pages = ceil((count($n_rset) / $archive_listed));

    # Add the individual page links only if more than one page
    if ($num_pages>1) {
    	$output .= "[&nbsp;<B>" . $year . ":</B>&nbsp;";
        for ($i=0; $i<$num_pages; $i++) {
            $output .= "<A HREF='" . $SCRIPT_NAME . "?az=" . $action . "&cmd=list&start=" .
			           ($archive_listed * $i) . "&year=" . $year . "' CLASS='RNListNavigation'>";
			$output .= (($archive_listed * $i) == $start) ? "<B>" : "";
            $output .= ($i + 1) . "</A>" . ((($archive_listed * $i) == $start) ? "</B>" : "") . "&nbsp;";
        }
        $output .= "&nbsp;]";
    }
    else {
        $output .= "[&nbsp;<B>" . $year . "</B>&nbsp;]";
    }

    # Check for archived items in the next year
    $query = "SELECT * FROM " . $announcement_table .
             " WHERE (date >= '" . ((integer) $year + 1) . "-01-01'" .
		     " AND date < '" . ((integer) $year + 2) . "-01-01')";
    if (is_string($n_rset = $d->query($query)))
	    return (show_error($n_rset) . "</TD></TR></TABLE>");

	if (is_array($n_rset) && count($n_rset) > 0) {
        $output .= "&nbsp;&nbsp;[&nbsp;<A HREF='" . $SCRIPT_NAME . "?az=" . $action . "&cmd=list&start=0" .
	                   "&year=" . ((integer) $year + 1) . "' CLASS='RNListNavigation'>" . ((integer) $year + 1) .
			    	   "</A>&nbsp;]&nbsp;&nbsp;";
    }
	
    $output .= "</TD>\n";
    $output .= "<TD ALIGN='RIGHT' WIDTH='75' CLASS='RNListNavigation'>";

    # Build Navigation Menu (Next Page)
    $query = "SELECT * FROM " . $announcement_table .
             " WHERE date >= '" . $year . "-01-01'" .
			 " AND date < '" . ((integer) $year + 1) . "-01-01'" .
             " ORDER BY date DESC" .
             " LIMIT " . Abs(($archive_listed + $start)) . "," . $archive_listed;

    if (is_string($n_rset = $d->query($query)))
	    return (show_error($n_rset) . "</TD></TR></TABLE>");

	if (is_array($n_rset) && count($n_rset) > 0) {
        $output .= "<A HREF='" . $SCRIPT_NAME . "?az=" . $action . "&cmd=list&start=" .
		           ($archive_listed + $start) . "&year=" . $year . "' CLASS='RNListNavigation'>";
        $output .= "Next</A>";
    }
    else {
        $output .= "&nbsp;";
    }
    $output .= "</TD>\n";
    $output .= "</TR>\n\n";
    $output .= "</TABLE><BR>\n\n";
	
	# Return the HTML container
	return $output;
}

function show_error($num, $tpl = false) {
/******************************************************************************
Displays the main administration menu.
******************************************************************************/
     # Global variables
     global $d, $service_email;

     # Function Variables
     $output = false;  # Returned value
     $db_err = $d->error();

     # Array of error messages
     $msg = array();

     # File system errors
     $msg['100'] = 'Could not open template (' . $tpl . ').';

     # Database connection/query errors
     $msg['200'] = 'Could not connect to database server. Please e-mail the <A HREF="mailto:' . $service_email . '">administrator</A> and notify them of this error. (<B>Database said:</B> ' . $db_err . ')';
     $msg['201'] = 'Could not access the database. Please e-mail the <A HREF="mailto:' . $service_email . '">administrator</A> and notify them of this error. (<B>Database said:</B> ' . $db_err . ')';
     $msg['202'] = 'Database query unsuccessful.  Please e-mail the <A HREF="mailto:' . $service_email . '">administrator</A> and notify them of the error.  (<B>Database said:</B> ' . $db_err . ')';
	 $msg['206'] = 'User not found.  Please check spelling.';

     # Authentication errors
     $msg['300'] = 'Authentication Error.  Incorrect username or password.';
     $msg['301'] = 'Authentication Error.  You are not authorized for this action. Your attempt has been reported.';
     $msg['302'] = 'Authentication Error.  There was an error destroying your session information.  (<B>MySQL said:</B> ' . $db_err . ')';
     $msg['303'] = 'Authentication Error.  Your username has been disabled by the <A HREF="mailto:' . $service_email . '">administrator</A>.';

     # Data validation errors
     $msg['400'] = 'Validation Error.  Category was not selected.  Please choose a category.';
     $msg['401'] = 'Validation Error.  Heading was not given.  Please enter a heading.';
	 $msg['402'] = 'Validation Error.  You did not supply any text for the announcement.';

     # Miscellaneous Messages
     $msg['901'] = 'You have successfully logged out.  <A HREF="/">Click here</A> to return home.';
     
     # Build the error message
     $output = "<TABLE CLASS='RNErrorTable' ALIGN='CENTER'>\n\n";
     $output .= "<TR>\n<TD ALIGN='LEFT'>\n";
     if ($num < 900) {
         $output .= "<SPAN CLASS='RNErrorNum'>Error #" . $num . ":</SPAN>\n";
     }
     $output .= $msg['' . $num ] . "</TD>\n</TR>\n\n</TABLE>\n\n";

     # Return the error message
     return $output;
}

function web_links($text) {
/*****************************************************************************
Formats any Internet addresses found in text as clickable links.
*****************************************************************************/
   # Split the text up by spaces
   $t = explode(" ", $text);

   for ($i=0; $i<count($t); $i++) {

      # Get rid of any new line characters
      $w = explode("\n", $t[$i]);

      # For each "word", check for a URL
      for ($j=0; $j<count($w); $j++) {

         # Check for a URL with and ending filename
         if (eregi("^[hft]+tp:\/\/[A-Za-z0-9_\.\-]+\/[\/A-Za-z0-9_\-]+\/[A-Za-z0-9_\.\@\-]+[A-Za-z]{1,5}", $w[$j], $url)) {

            # if a match is made, replaced the text with a link;
            # target is set to open up in the same frame
            if (is_array($url)) {
               $w[$j] = ereg_replace($url[0], "<A HREF='" . $url[0] . "' TARGET='_self'>" . $url[0] . "</A>", $w[$j]);
            }
            unset($url);
         }

         # Check for a URL with a subdirectory or just a domain
         elseif (eregi("^[hft]+tp:\/\/[A-Za-z0-9_\-\.]+\/[\/A-Za-z0-9_\-]+\/", $w[$j], $url)
            || eregi("^[hft]+tp:\/\/[A-Za-z0-9_\-\.]+\/", $w[$j], $url)) {

            # if a match is made, replace the text with a link;
            # target is set to open in the full browser window
            if (is_array($url)) {
               $w[$j] = eregi_replace($url[0], "<A HREF='" . $url[0] . "' TARGET='_top'>". $url[0] . "</A>", $w[$j]);
            }
            unset($url);
         }

         # Start piecing everything back together
         if ($j == 0) {
            $t[$i] = $w[$j];
         }
         else {
            $t[$i] .= "\n" . $w[$j];
         }
      }
      if ($i == 0) {
         $linked_text = $t[$i];
      }
      else {
         $linked_text .= " " . $t[$i];
      }
   }
   return $linked_text;
} // End web_links function

?>
