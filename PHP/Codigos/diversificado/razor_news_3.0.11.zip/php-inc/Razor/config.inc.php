<?

###############################################################################
#
#  config.inc.php
#  Author:  Peter Adams (adams@editors-wastebasket.org)
#  http://www.editors-wastebasket.org/pta/
#  Date Created: 7 March 2001
#  Last Modified: 23 May 2002
#
#  Description:
#    This file contains all global variables that are used throughout the
#    RazorNews announcement management program.
#
# Copyright (c) InterKan.Net, Inc.  All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. The name of the author may not be used to endorse or promote
#    products derived from this software without specific prior
#    written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
# GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
# OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
###############################################################################

##################### GENERAL INFO ########################

# Categories to be included
$category_list = array('ANNOUNCEMENT', 'SOFTWARE UPDATE');
$alert_list = array('ANNOUNCEMENT/ALERT', 'ALERT');

# Title (i.e. Announcements, What's New, etc.)
$a_title = "Announcements";

# Should the archive be used?
# If set to true, a link will be shown so a user can see past announcements
# Link only displayed if the total number of announcements is more than the
# number of announcements listed
$use_archive = true;

# Can comments be posted?
# If set to true, a link will be shown so a user can post comments about the
# news item.  Not currently implemented
$allow_comments = false;

##################### FORMAT ##############################

# Template File
$tpl = "/home/demo/www/Templates/news.htm";

# Single Item Template File
$single_tpl = "/home/demo/www/Library/rn_listing_format.lbi";

# Login Form Template File
$login_form_tpl = "/home/demo/www/Library/rn_login_form.lbi";

# Login Form Template File
$ssi_table_tpl = "/home/demo/www/Library/rn_ssi_table.lbi";

# Archive Link Name
# Text to be used as the archive link
$archive_link_name = "Archive";

# Number of announcements to show in the announcement list.
$num_listed = 4;

# Number of items listed per page in the archive
$archive_listed = 10;

# Caption size (# of characters)
# If the announcement text is displayed on the front page, limit the size of the
# text.
$caption_words = 250;

# Outline the table with a border (true or false)
# if set to true, then a border will be placed around each announcement with
# the same color as defined in $th_bgcolor
$use_border = true;

##################### URLS/DIRECTORIES ######################

# Installed directory on server
$rn_dir = "News/";

# Graphics URL - location of images provided by script
$graphicsurl = "/Graphics/News";

# Service E-mail
# E-mail for people in charge of providing access.
$service_email = "webmaster@interkan.net";

#################### DATABASE #############################

# Database Information
$db_host = "localhost";
$db_user = "";
$db_pass = "";
$db_name = "";

# Database Tables
$user_table          = "ADM_Users";
$group_table         = "ADM_Groups";
$session_table       = "ADM_Sessions";
$announcement_table  = "RN_Announcements";
$comment_table       = "RN_Comments";
$admin_action_table  = "RN_Admin_Actions";
$admin_group_table   = "RN_Admin_Groups";
$admin_control_table = "RN_Admin_Action_Control";

############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################
############################### DO NOT MODIFY #################################

# Database connection
if (is_string($d = new db($db_host, $db_user, $db_pass, $db_name))) {
    # An error occurred during initialization
    $HTML_MAIN = show_error($d, "#FF0000");
}

?>
