<?
####################################
#    Protegendo p�ginas v. 2.0     #
#  Script desenvolvido por |paes|  #
####################################
include("config.php");
include("include.php");
include("verifica.php");

if($usuario == $adminl){
echo"<font face=\"$fonte\" size=\"$tfonte\"><b>Administrar Usu�rios</b> (<a href=logado.php>�� Voltar</a>)<br>";
$sql = "SELECT * FROM users";

$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

if(mysql_num_rows($resultado)>0) {

while ($linha=mysql_fetch_array($resultado)) {
$id = $linha["id"];
$login = $linha["login"];
echo"
<font face=\"$fonte\" size=\"$tfonte\"><a href=administrar.php?acao=mod&user=$id>$login</a><br>";
}
}
}else{
echo"<HTML>
<title>$nsite</title>
<font face=\"$fonte\" size=\"$tfonte\">Voc� <b>n�o �</b> um administrador para poder cadastrar um usu�rio.<br>
Voc� <b>apenas pode</b> visitar as p�ginas restritas.<br><br>
<a href=logado.php>�� Voltar</a></font></HTML>
";
}
if($usuario == $adminl && $acao == mod){
$sql = "SELECT * FROM users WHERE id='$user'";

$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

if(mysql_num_rows($resultado)>0) {

while ($linha=mysql_fetch_array($resultado)) {
$id = $linha["id"];
$login = $linha["login"];
$nome = $linha["nome"];
$email = $linha["email"];
$senhau = $linha["senha"];
if($login == $adminl){
echo"
<HTML>
<title>$nsite</title>
<font face=\"$fonte\" size=\"$tfonte\">
<form action=\"administrar.php?acao=modificar\" method=\"post\">
<table width=\"50%\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
<tr><td class=\"texto\"><font face=\"$fonte\" size=\"$tfonte\">Nome:&nbsp;</font></td><td><input class=\"campo\" value=\"$nome\" name=\"nome\" type=\"text\" size=\"30\"></td></tr>
<tr><td class=\"texto\"><font face=\"$fonte\" size=\"$tfonte\">E-mail:&nbsp;</font></td><td><input class=\"campo\" value=\"$email\" name=\"email\" type=\"text\" value=\"\" size=\"30\"></td></tr>
<tr><td class=\"texto\"><font face=\"$fonte\" size=\"$tfonte\">Login:&nbsp;</font></td><td><font face=\"$fonte\" size=\"$tfonte\">$login</td></tr>
<tr><td class=\"texto\"><font face=\"$fonte\" size=\"$tfonte\">Senha:&nbsp;</font></td><td><font face=\"$fonte\" size=\"$tfonte\">$senhau</td></tr>
<tr><td class=\"texto\"></td><td><input type=\"hidden\" name=\"user\" value=\"$id\"><input class=\"campo\" name=\"modificar\" type=\"submit\" value=\"Modificar\"></td></tr>
<tr><td class=\"texto\"></td><td><font face=\"$fonte\" size=\"$tfonte\">Deletar usu�rio</font></td></tr>
<tr><td class=\"texto\"></td><td><font face=\"$fonte\" size=\"$tfonte\"><a href=administrar.php>�� Voltar</a></font></td></tr>
</table>
</HTML>";
}else{
echo"
<HTML>
<title>$nsite</title>
<font face=\"$fonte\" size=\"$tfonte\">
<form action=\"administrar.php?acao=modificar\" method=\"post\">
<table width=\"50%\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
<tr><td class=\"texto\"><font face=\"$fonte\" size=\"$tfonte\">Nome:&nbsp;</font></td><td><input class=\"campo\" value=\"$nome\" name=\"nome\" type=\"text\" size=\"30\"></td></tr>
<tr><td class=\"texto\"><font face=\"$fonte\" size=\"$tfonte\">E-mail:&nbsp;</font></td><td><input class=\"campo\" value=\"$email\" name=\"email\" type=\"text\" value=\"\" size=\"30\"></td></tr>
<tr><td class=\"texto\"><font face=\"$fonte\" size=\"$tfonte\">Login:&nbsp;</font></td><td><font face=\"$fonte\" size=\"$tfonte\">$login</td></tr>
<tr><td class=\"texto\"><font face=\"$fonte\" size=\"$tfonte\">Senha:&nbsp;</font></td><td><font face=\"$fonte\" size=\"$tfonte\">$senhau</td></tr>
<tr><td class=\"texto\"></td><td><input type=\"hidden\" name=\"user\" value=\"$id\"><input class=\"campo\" name=\"modificar\" type=\"submit\" value=\"Modificar\"></td></tr>
<tr><td class=\"texto\"></td><td><font face=\"$fonte\" size=\"$tfonte\"><a href=administrar.php?acao=del&user=$id>Deletar usu�rio</a></font></td></tr>
<tr><td class=\"texto\"></td><td><font face=\"$fonte\" size=\"$tfonte\"><a href=administrar.php>�� Voltar</a></font></td></tr>
</table>
</HTML>";
}}}
}
if($usuario == $adminl && $acao == modificar){
$sql = "UPDATE users SET nome ='$nome', email ='$email', senha ='$senha' WHERE id = '$user'";
$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");
echo"<font face=\"$fonte\" size=\"$tfonte\">Usu�rio modificado com sucesso.";
}
if($usuario == $adminl && $acao == del){
$sql = "DELETE FROM users WHERE id='$user'";
$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a exclus�o dos dados.");
echo"<font face=\"$fonte\" size=\"$tfonte\">Usu�rio deletado com sucesso.
<meta http-equiv=\"refresh\" content=\"2;URL=administrar.php\">
";
}
?>