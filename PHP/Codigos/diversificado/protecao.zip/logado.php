<?
####################################
#    Protegendo p�ginas v. 2.0     #
#  Script desenvolvido por |paes|  #
####################################
include("config.php");
include("include.php");
include("verifica.php");

if($usuario == $adminl){
echo"
<font face=$fonte size=$tfonte>
Bem vindo <b>$usuario.</b><br>
<a href=cadastrar.php>Cadastrar usu�rios</a><br>
<a href=administrar.php>Administrar Usu�rios</a><br>
<a href=?acao=sair>Logout</a><br><br>
Voc� pode:<br>
 - Cadastrar novos usu�rios<br>
 - Administrar usu�rios<br>
 - Visitar p�ginas restritas do site <a href=$usite>$nsite</a>";
}else{
echo"
<font face=$fonte size=$tfonte>
Bem vindo <b>$usuario.</b><br>
<a href=?acao=sair>Logout</a><br><br>
Voc� pode:<br>
 - Visitar p�ginas restritas do site <a href=$usite>$nsite</a>";
}
?>
<?
include("copyright.php");
?>