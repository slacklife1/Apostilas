<?
####################################
#    Protegendo p�ginas v. 2.0     #
#  Script desenvolvido por |paes|  #
####################################
?>
<br><br><br><br><font face="verdana" size="1"><center>Copyright 2003 - Todos os direitos reservados<br>
P�gina Protegida por <a href="mailto:guarru@ig.com.br" target="new">|paes| Script</a></font></center>