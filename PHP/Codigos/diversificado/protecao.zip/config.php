<?
####################################
#    Protegendo p�ginas v. 2.0     #
#  Script desenvolvido por |paes|  #
####################################
// Endere�o do seu servidor MySQL
$dbhost='localhost';

// Usu�rio do MySQL
$dbuser='';

// Senha do MySQL
$dbpasswd='';

// Nome do Banco de dados
$dbname='_protecao';

####################################
#	 	  N�o altere			   #
####################################
// Conex�o com o Banco de Dados
$conexao = @mysql_connect($dbhost, $dbuser, $dbpasswd) or die ("N�o foi poss�vel conectar-se ao servidor MySQL");
$db = @mysql_select_db($dbname) or die ("N�o foi poss�vel selecionar o banco de dados <b>$dbname</b>");
?>