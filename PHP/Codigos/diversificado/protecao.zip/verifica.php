<?
####################################
#    Protegendo p�ginas v. 2.0     #
#  Script desenvolvido por |paes|  #
####################################
####################################
#	 	  N�o altere			   #
####################################
// Sistema para verificar se o usu�rio j� est� logado ou n�o
if(!$HTTP_COOKIE_VARS["usuario"] && !$HTTP_COOKIE_VARS["senha"]){
header("Location: login.php");
}
if($acao == sair){
setcookie("usuario");
setcookie("senha");
header("location: login.php");
}
?>