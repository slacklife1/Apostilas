<?
####################################
#    Protegendo p�ginas v. 2.0     #
#  Script desenvolvido por |paes|  #
####################################
?>
<?
$description = mysql_error();
if($acao == instalar){
include("config.php");
$conexao = @mysql_connect($dbhost, $dbuser, $dbpasswd) or die ("N�o foi poss�vel conectar-se ao servidor MySQL");
$db = @mysql_select_db($dbname) or die ("N�o foi poss�vel selecionar o banco de dados <b>$dbname</b>");
$sql = mysql_query ("CREATE TABLE users(
id TINYINT (3) DEFAULT '0' not null AUTO_INCREMENT,
nome VARCHAR (150) not null ,
email VARCHAR (255) not null ,
login VARCHAR (15) not null ,
senha VARCHAR (15) not null ,
PRIMARY KEY (id)
);");

$sql = mysql_query ("CREATE TABLE config(
admin VARCHAR (100) not null, 
admine VARCHAR (255) not null, 
adminl VARCHAR (15) not null, 
admins VARCHAR (15) not null,
nsite VARCHAR (100) not null, 
usite VARCHAR (255) not null, 
fonte VARCHAR (50) not null, 
tfonte VARCHAR (2) not null
);");

$sql = mysql_query("Insert into users values('1', '$admin', '$admine', '$adminl', '$admins')");
$sql = mysql_query("Insert into config values('$admin', '$admine', '$adminl', '$admins', '$nsite', '$usite', '$fonte', '$tfonte')");
echo"<font face=verdana size=2>
Erro: $description<BR>
Script instalado com sucesso.<br>
Guarde essas informa��es:<br>
<b>Login do Administrador:</b> $adminl<br>
<b>Senha do Administrador:</b> $admins
<br><br>
<a href=login.php>Fazer Login</a>";
}else{
echo"
<html>

<head>
<title>Instalando Script - Vers�o 2.0</title>
</head>

<body>

<form method='POST' action='instalar.php?acao=instalar'>
 <font face=verdana size=2> <b>Informa��es Gerais:<br>
  </b>Nome do site:<br>
  <input type='text' name='nsite' size='20'><br>
  URL do site:<br>
  <input type='text' name='usite' size='20'><br>
  Nome da Fonte:<br>
  <input type='text' name='fonte' size='20'><br>
  Tamanho da Fonte:<br>
  <input type='text' name='tfonte' size='20'><br>
  Nome do Administrador:<br>
  <input type='text' name='admin' size='20'><br>
  Seu e-mail:<br>
  <input type='text' name='admine' size='20'><br>
  Login do admin:<br>
  <input type='text' name='adminl' size='20'><br>
  Senha do admin:<br>
  <input type='text' name='admins' size='20'><br>
  <input type='submit' value='Instalar Script'></font></p>
</form>

</body>

</html>
";
}
?>
