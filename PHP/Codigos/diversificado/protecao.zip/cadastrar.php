<?
####################################
#    Protegendo p�ginas v. 2.0     #
#  Script desenvolvido por |paes|  #
####################################
include("config.php");
include("include.php");
include("verifica.php");

if($usuario == $adminl){
  if($acao == 'cadastra'){
$sql = "SELECT * FROM users where login='$login'";

$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

if(mysql_num_rows($resultado)>0) {

while ($linha=mysql_fetch_array($resultado)) {
$login = $linha["loginc"];
}
}
    if($login == $loginc){
echo"<HTML>
<title>$nsite</title>
<font face=\"$fonte\" size=\"$tfonte\">O usu�rio <b>$loginc</b> j� est� cadastrado.<br>
<a href=javascript:history.go(-1)>�� Voltar</a></font>";
}else{
$nome = $HTTP_POST_VARS["nome"];
$email = $HTTP_POST_VARS["email"];
$login = $HTTP_POST_VARS["login"];
$senha = $HTTP_POST_VARS["senha"];

$sql = mysql_query("Insert into users values('$id', '$nome', '$email', '$login', '$senha')");

if($sql){
echo "
<HTML>
<title>$nsite</title>
<font face=\"$fonte\" size=\"$tfonte\">O usu�rio <b>$login</b> foi cadastrado com sucesso. Agora ele poder� acessar as partes restritas de seu site.<br>
Mas lembre-se... apenas voc� pode adicionar usu�rios.</font>
<meta http-equiv=\"refresh\" content=\"5;URL=logado.php\">
</HTML>";
} else {
echo "<HTML>
<title>$nsite</title>N�o foi poss�vel cadastrar esse usu�rio...
<meta http-equiv=\"refresh\" content=\"2;URL=cadastrar.php\">
</HTML>";
}
}
} else {
echo"
<HTML>
<title>$nsite</title>
<font face=\"$fonte\" size=\"$tfonte\">
<form action=\"cadastrar.php?acao=cadastra\" method=\"post\">
<table width=\"50%\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
<tr><td class=\"texto\"><font face=\"$fonte\" size=\"$tfonte\">Nome:&nbsp;</font></td><td><input class=\"campo\" name=\"nome\" type=\"text\" size=\"30\"></td></tr>
<tr><td class=\"texto\"><font face=\"$fonte\" size=\"$tfonte\">E-mail:&nbsp;</font></td><td><input class=\"campo\" name=\"email\" type=\"text\" value=\"\" size=\"30\"></td></tr>
<tr><td class=\"texto\"><font face=\"$fonte\" size=\"$tfonte\">Login:&nbsp;</font></td><td><input class=\"campo\" name=\"login\" type=\"text\" size=\"15\"></td></tr>
<tr><td class=\"texto\"><font face=\"$fonte\" size=\"$tfonte\">Senha:&nbsp;</font></td><td><input class=\"campo\" name=\"senha\" type=\"password\" size=\"15\"></td></tr>
<tr><td class=\"texto\"></td><td><input class=\"campo\" name=\"cadastrar\" type=\"submit\" value=\"Cadastrar\"></td></tr>
<tr><td class=\"texto\"></td><td><font face=\"$fonte\" size=\"$tfonte\"><a href=javascript:history.go(-1)>�� Voltar</a></font></td></tr>
</table>
</HTML>
";
}
}
else{
echo"<HTML>
<title>$nsite</title>
<font face=\"$fonte\" size=\"$tfonte\">Voc� <b>n�o �</b> um administrador para poder cadastrar um usu�rio.<br>
Voc� <b>apenas pode</b> visitar as p�ginas restritas.<br><br>
<a href=logado.php>�� Voltar</a></font></HTML>

";
}

?>
<?
include("copyright.php");
?>