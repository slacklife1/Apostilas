<?
####################################
#    Protegendo p�ginas v. 2.0     #
#  Script desenvolvido por |paes|  #
####################################
include("config.php");
include("include.php");

$query = mysql_query("Select * From users where login='$login' and senha='$senha'");
$valida = mysql_fetch_array($query);

$user = $valida["login"];
$pass = $valida["senha"];

if($login == '' || $senha == ''){
echo"
<HTML>
<title>$nsite</title>
<font face=\"$fonte\" size=\"$tfonte\">
<form action=\"login.php\" method=\"post\">
<table align=\"center\" width=\"25%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
<tr><td><font face=\"$fonte\" size=\"$tfonte\">Login:</font></td><td><input name=\"login\" type=\"text\"></td></tr>
<tr><td><font face=\"$fonte\" size=\"$tfonte\">Senha:</font></td><td><input name=\"senha\" type=\"password\"></td></tr>
<tr><td>&nbsp;</td><td><input name=\"logar\" type=\"submit\" value=\"Logar\"></td></tr>
</table>
</form>
</HTML>";
} elseif($login == $user && $senha == $pass){
setcookie("usuario", $login);
setcookie("senha", $senha);
header("Location: logado.php");
} elseif($login != $valida["login"] || $senha != $valida["senha"]){
echo "<font face=\"$fonte\" size=\"$tfonte\">Usu�rio ou senha inv�lido.<br><a href=mailto:$admine>Contate o administrador</a> se voc� tem certeza de que os dados est�o corretos.<br><br>
<a href=login.php>�� Voltar</a></font>";
}

?>
<?
include("copyright.php");
?>