<?
####################################
#    Protegendo p�ginas v. 2.0     #
#  Script desenvolvido por |paes|  #
####################################
####################################
#	 	  N�o altere			   #
####################################
// Sistema para verificar se � administrador
include("config.php");
$sql = "SELECT * FROM config";

$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

if(mysql_num_rows($resultado)>0) {

while ($linha=mysql_fetch_array($resultado)) {
$adminl = $linha["adminl"];
$nsite = $linha["nsite"];
$usite = $linha["usite"];
$nsite = $linha["nsite"];
$fonte = $linha["fonte"];
$tfonte = $linha["tfonte"];
}}
?>