<?php

/* +----------------------------------------------------------------------+
   | Copyright (c) 2002/03 GKOM Corp.							          |
   +----------------------------------------------------------------------+
		Code Title	 : A simple PHP image counter
		Description	 : This program read the counter number from cnum.txt
					   and display image number them on the web page using 
					   php command.
		Date created : 10/10/03
		Author		 : GKOM (gkom99@yahoo.com)
   +----------------------------------------------------------------------+*/


	$fp = fopen ("./cnum.txt", "r");
	$txt_number = fread ($fp, filesize ("./cnum.txt"));
	fclose($fp);
?>
<html>
		<head>
			<title>Counter number</title>
		</head>
		<body>
		<center>
		<?php
			$txt_num = (int)($txt_number) + 1;
			$txt_number = (string)($txt_num);
			$len = strlen($txt_number);
			while($len!=$i && $len!=0)
			{
				echo "<img src=.\\numbers\\". $txt_number[$i].".jpg alt=\"You are visitor number $txt_number\" width=20 Height=22>";
				$i++;
			}
			$fp = fopen ("./cnum.txt", "w");
			fwrite ($fp, $txt_number);
			fclose($fp);
		?>
		</center>
		</body>
</html>

