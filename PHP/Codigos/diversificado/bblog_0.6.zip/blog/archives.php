<?php
include "bblog/config.php";
$bBlog->display('archives.html');
?>
