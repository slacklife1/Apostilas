<?php
include "bblog/config.php";

if(is_numeric(@$_GET['postid'])) {
    $bBlog->assign('postid',$_GET['postid']);
    $bBlog->show_post = $_GET['postid'];
    $bBlog->display('post.html');
    exit;
}

if(is_numeric(@$_GET['sectionid'])) {
    $bBlog->assign('sectionid',$_GET['sectionid']);
    $bBlog->assign('sectionname',$bBlog->sect_by_name[$_GET['sectionid']]);
    $bBlog->show_section = $_GET['sectionid'];
}


$bBlog->display('index.html');
?>
