<?php
include "bblog/config.php";
// make_post_query takes paramaters, and returns a mysql query .
header("Content-Type: text/xml");
?><rss version="0.92">
  <channel>
    <title><?=htmlspecialchars(C_BLOGNAME)?></title>
    <link><?=C_BLOGURL?></link>
    <description><?=C_BLOG_DESCRIPTION?></description>
<?php
$q = $bBlog->make_post_query(array("num"=>20));
$posts = $bBlog->get_posts($q);
foreach($posts as $post) {
?>    <item>
      <title><?=htmlspecialchars($post['title'])?></title>
      <description><?=htmlspecialchars($post['body'])?></description>
      <link><?=$post['permalink']?></link>
    </item>
<?php
}
?>
  </channel>
</rss>
