Welcome to bBlog!
www.bBlog.com

About bBlog
-----------
bBlog is a PHP blogging application, written using Smarty, and OOP style coding.

Documentation, including install instructions, is at www.bblog.com/docs/

If you get stuck *after reading the documentation* please go to http://www.bblog.com/forum.php for help


Licence
-------
See LICENCE.txt ( GPL )


Credits
-------
See CREDITS.txt


Known Bugs
----
See BUGS.txt file
If you find a bug, you can report it in the bugs forum at http://www.bblog.com/forum.php

