<?php
// init.php - Start the bBlog engine, include needed files
// init.php - author: Eaden McKee <email@eadz.co.nz>

/*
** bBlog Weblog http://www.bblog.com/
** Copyright (C) 2003  Eaden McKee <email@eadz.co.nz>
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
// start counting.

// define the table names
define('T_CONFIG',TBL_PREFIX.'config');
define('T_POSTS',TBL_PREFIX.'posts');
define('T_SECTIONS',TBL_PREFIX.'sections');
define('T_MODIFIERS',TBL_PREFIX.'modifiers');
define('T_PLUGINS',TBL_PREFIX.'plugins');
define('T_TEMPLATES',TBL_PREFIX.'templates');
define('T_COMMENTS',TBL_PREFIX.'comments');

// legacy, will be deleted
define('C_BLOGURL',BLOGURL);

// prevent errors when _open_basedir is set
ini_set('include_path','./:../');

define('SMARTY_DIR',	BBLOGROOT.'libs/');

// include  needed files
include BBLOGROOT.'libs/Smarty.class.php';
include BBLOGROOT.'libs/ez_sql.php';
include BBLOGROOT.'inc/bBlog.class.php';
include BBLOGROOT.'inc/functions.php';
include BBLOGROOT.'inc/templates.php';


// start your engines
$bBlog = new bBlog();
$mtime = explode(" ",microtime());
$bBlog->begintime = $mtime[1] + $mtime[0];

// this is only here until I work out the best way to do theming.
//$bBlog->clear_compiled_tpl();


$bBlog->template_dir 	= BBLOGROOT.'templates/'.C_TEMPLATE;
$bBlog->compile_dir = BBLOGROOT.'compiled_templates/';

if(defined('IN_BBLOG_ADMIN')) {
       $bBlog->compile_id = 'admin';
} else $bBlog->compile_id = C_TEMPLATE;

// if we are using templates from the database then the compile dir needs to be different
// NOT USED AT THE MOMENT!
if(C_DB_TEMPLATES == "true")
    $bBlog->register_resource("db", array("db_get_template","db_get_timestamp","db_get_secure","db_get_trusted"));


$bBlog->plugins_dir = array(BBLOGROOT.'smarty_plugins',BBLOGROOT.'bBlog_plugins');
$bBlog->use_sub_dirs	= FALSE; // change to true if you have a lot of templates

define('BBLOG_VERSION',"0.6");
$bBlog->assign("bBlog_version",BBLOG_VERSION);

// if you want debugging, this is the place
// you'd turn on debugging by adding ?gdb=true to the end of a url
// it's disabled by default for security reasons
// if($_GET['gdb']) $bBlog->debugging=TRUE;
 
// if you want to use php in your templates
// $bBlog->php_handling=SMARTY_PHP_ALLOW;
?>
