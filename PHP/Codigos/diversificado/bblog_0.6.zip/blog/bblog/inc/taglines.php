<?php
// taglines.php - random taglines 
$taglines = array();
$taglines[] = "In need of a tagline since 2003";
$taglines[] = "Smarty based blog software";
$taglines[] = "Have something to say?";
$taglines[] = "Version ".BBLOG_VERSION;
$taglines[] = "The revolution will be blogged";
$taglines[] = "Forged in Middle-Earth";
$taglines[] = "So fresh and so clean";
$taglines[] = "Simple, Powerful, Hackable, Extenable";
$tl_n = array_rand($taglines);
$bBlog->assign('tagline',$taglines[$tl_n]);
?>
