<?php
function identify_admin_help () {
  return array (
    'name'           =>'help',
    'type'           =>'admin',
    'nicename'       =>'Help',
    'description'    =>'Displays Help',
    'authors'         =>'Eaden McKee',
    'licence'         =>'GPL'
  );
}
if(is_numeric($_GET['pid'])) {
	$pluginrow = $bBlog->get_row("select * from ".T_PLUGINS." where id='".$_GET['pid']."'");
	$bBlog->assign("title","Help: ".$pluginrow->type." : ".$pluginrow->nicename);
	$bBlog->assign("helptext",$pluginrow->help);
} else {
	$bBlog->assign("title","Help");
	$bBlog->assign("helptext",'Visit the <a href="http://www.bBlog.com/forum.php" target="_blank">bBlog forum</a> for help.');
}
$bBlog->display("help.html");
?>
