<?php
// modifier.date_format.php - smarty modifier to format a timestamp
function smarty_modifier_date_format($date, $format="F j, Y, g:i a") {
  // locale should be defined in a config file, not case by case
  define('C_LOCALE','en_GB');
  setlocale(LC_TIME,C_LOCALE);
  
  switch ($format) {
    case "full": return strftime("%A, %d. %B %Y, %H:%M", $date);
    
    case "date": return strftime("%A, %d. %B %Y", $date);
    
    case "shortdate": return strftime("%x", $date);
    
    case "time": return strftime("%H:%M", $date);    
    
    case "s1" : return date("F j, Y, g:i a",$date);
    
    case "s2" : return date("F j, Y",$date);
    
    // called Jim in reference to RevJim ( revjim.net ) who first used this format ( afict )
    case "jim" : return since($date)." on ".date("F j, Y",$date); 
    
    case "since" : return since($date);
  
  }

  return date($format,$date);
}

function identify_modifier_date_format () {
  return array (
    'name'           =>'date_format',
    'type'           =>'smarty_modifier',
    'nicename'       =>'Format Date',
    'description'    =>'Date format takes a timestamp, and turns it into a nice looking date',
    'authors'         =>'Dean Allen, Eaden McKee',
    'licence'         =>'Textpattern'
  );
}

function bblog_modifier_date_format_help () {
?>
<p>Date format takes a timestamp, and turns it into a nice looking date.
<br />It is used as a modifier inside a template. For example, if you are in a
 <span class="tag">{post} {/post}</span> loop, you will have the varible {$post.dateposted}
 set which will contain a timestamp of when the post was made,
 and you will apply the date_format modifier to this tag.</p>
<p>Examples :<br />
<span class="tag">{$post.dateposted|date_format}</span> will return a date like May 26, 2003, 2:29 pm<br />
<span class="tag">{$post.dateposted|date_format:since}</span> will return Posted 7 hours ago<br />
<span class="tag">{$post.dateposted|date_format:"F j, Y"}</span> will return May 26, 2003. The "F j, Y" is in php date() format, for more infomation see <a href="http://www.php.net/date">php.net/date</a></p>


<?
}


function since($stamp) {
// from textpattern
// (c) Dean Allen http://www.textpattern.com/
// usage of this requires agreement with the
// texpattern licence aggreement :
/*
This is Textpattern
Copyright (c) 2003 by Dean Allen
All rights reserved


_______
LICENSE

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

* Neither the name Textpattern nor the names of its contributors may be used to
  endorse or promote products derived from this software without specific
  prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

		$post = $stamp;
		$now = (time());
		$diff = ($now - $post);
	if ($diff <= 3600) {
		$mins = round($diff / 60);
		if($mins<=1){
			$since = ($mins==1)?"1 minute":"a few seconds";
		} else {
			$since = "$mins minutes";
		}
	} else if (($diff <= 86400) && ($diff > 3600)) {
		$hours = round($diff / 3600);
			if ($hours <= 1) {
				$since = "1 hour";
			} else {
				 $since = "$hours hours";
			}
	} else if ($diff >= 86400) {
		$days = round($diff / 86400);
			if ($days <= 1) {
				$since = "1 day";
			} else {
				$since = "$days days";
			}
	}
			$since = "Posted ".$since." ago";
			return $since;
	}
?>
