<?php
// modifier.readmore.php - a readmore hack
function smarty_modifier_readmore($text, $postid) {
	global $bBlog;
	$link = $bBlog->_get_entry_permalink($postid);
	  $textar = explode('<!-- read more -->',$text);
	  if(sizeof($textar) > 1) 
		  return $textar[0]."<br /><a href='$link'>Read More</a>";
	else    return $text;
	  
}

function identify_modifier_readmore () {
  return array (
    'name'           =>'readmore',
    'type'           =>'smarty_modifier',
    'nicename'       =>'Read More',
    'description'    =>'Chops a post short with a readmore link',
    'authors'         =>'Eaden McKee',
    'licence'         =>'GPL',
    'help'	    =>'Usage:<br>
Use the readmore modifier on the {$post.body} tag, to cut off text at the HTML comment &lt;-- read more --&gt; .<br>
Example : {$post.body|readmore:$post.postid}<br>
The $post.postid is used to create the link. To make this work you need to put the above html comment in a post where you want it cut off.  '
  );
}

?>
