<?php
/*
** bBlog Weblog http://www.bblog.com/
** Copyright (C) 2003  Eaden McKee <email@eadz.co.nz>
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

function identify_admin_options () {
  return array (
    'name'           =>'options',
    'type'           =>'builtin',
    'nicename'       =>'Options',
    'description'    =>'Allows you to change options',
    'authors'         =>'Eaden McKee',
    'licence'         =>'GPL',
    'help'            =>''
  );
}

$bBlog->get_modifiers();



$optionformrows = array();

$options = get_options();

if($_POST['submit'] == 'Save Options') { // saving options..
 $updatevars = array();
 foreach($options as $option) {

     if(!isset($_POST[$option['name']])) break;

     switch ($option['type']) {
              case "text"  :
              case "email" :
              case "url"   :
                   $updatevars[] = array(
                                 "name" =>$option['name'],
                                 "value" => my_addslashes($_POST[$option['name']])
                                 );
                    break;
              case "password" :
                   if($_POST[$option['name']] != '')

                   $updatevars[] = array(
                                 "name" => $option['name'],
                                 "value" => md5($_POST[$option['name']])
                                 );
                   break;

              case "templateselect" :
                   // make sure we're not being poked.
                   if(ereg('^[[:alnum:]]+$',$_POST[$option['name']])) {
                      $updatevars[] = array(
                                    "name" => $option['name'],
                                    "value" => strtolower($_POST[$option['name']])
                                    );

                   }
                   break;

              case "statusselect" :
                   if($_POST[$option['name']] == 'live')
                         $updatevars[]= array(
                                        "name" => $option['name'],
                                        "value" => 'live'
                                        );
                                        
                    if($_POST[$option['name']] == 'draft')
                         $updatevars[]= array(
                                        "name" => $option['name'],
                                        "value" => 'draft'
                                        );
                   break;

              case "modifierselect" :
                   if(ereg('^[[:alnum:]]+$',$_POST[$option['name']]))
                         $updatevars[] = array(
                                       "name"=>$option['name'],
                                       "value"=>$_POST[$option['name']]
                                       );

                   break;
	      case "truefalse" : 
			$updatevars[] = array(
				"name"=>$option['name'],
				"value"=>$_POST[$option['name']]
				);
			break;
              default: break;


  } // switch
 } // foreach


} // if
if($_POST['submit'] == 'Save Options') {
  foreach($updatevars as $update) {
   $bBlog->query("update ".T_CONFIG." set value='".$update['value']."' where `name`='".$update['name']."'");
   } // foreach
   $bBlog->assign("showmessage",TRUE);
   $bBlog->assign("showoptions",'no');
   $bBlog->assign("message_title","Options Updated");
   $bBlog->assign("message_content","Your changes have been saved.<br><a href='index.php?b=options&r=".rand(20,214142124)."'>Click here to continue</a>");

} else {

foreach($options as $option) {
        $formleft = $option['label'];
        switch ($option['type']) {
              case "text"  :
              case "email" :
              case "url"   :
                   $formright = '<input type="text" name="'.$option['name'].'"
                                    class="bf" value="'.$option['value'].'">';
                   break;

              case "password" :
                   $formright = '<input type="password" name="'.$option['name'].'"
                                    class="bf" value="'.$option['value'].'">';
                   break;

              case "templateselect" :
                   $formright = '<select name="'.$option['name'].'" class="bf">';
                   // TODO make this work  ;)
                   $formright .= '<option value="grey"';
		   if($option['value'] == "grey") $formright .=" selected";
		   $formright .= '>Grey';
                   $formright .= '<option value="blue"';
		   if($option['value'] == "blue") $formright .=" selected";
		   $formright .= '>Blue (old)';
                   $formright .= '</select>';
                   break;

              case "statusselect" :
                   $formright = '<select name="'.$option['name'].'" class="bf">';
                   $formright .= '<option value="live" ';
                   if(C_DEFAULT_STATUS == 'live') $formright .= 'selected';
                   $formright .= '>Live';
                   $formright .= '<option value="draft" ';
                   if(C_DEFAULT_STATUS == 'draft') $formright .= 'selected';
                   $formright .= '>Draft';
                   $formright .= '</select>';
                   break;

              case "truefalse" :
                   $formright = '<select name="'.$option['name'].'" class="bf">';
                   $formright .= '<option value="true" ';
                   if($option['value'] == 'true') $formright .= 'selected';
                   $formright .= '>Yes';
                   $formright .= '<option value="false" ';
                   if($option['value'] == 'false') $formright .= 'selected';
                   $formright .= '>No';
                   $formright .= '</select>';
                   break;
              case "modifierselect" :
                   $formright = '<select name="'.$option['name'].'" class="bf">';
                   foreach($bBlog->modifiers as $mod) {
                       $formright .= '<option value="'.$mod->name.'" ';
                       if(C_DEFAULT_MODIFIER == $mod->name) $formright .= 'selected';
                       $formright .= '>'.$mod->nicename;
                   }
                   $formright .= '</select>';
                   break;

              default: $formright = ''; break;

        }
        $optionrows[] = array("left" => $formleft,"right" => $formright);
        // have help here too someday :)


}
$bBlog->assign("optionrows",$optionrows);
} // end of else
$bBlog->display("options.html");


function get_options () {
$options = array();

/* // user and pass is now set in config.php
$options[] = array(
    "name"  => "USER",
    "label" => "Username",
    "value" => C_USER,
    "type"  => "text"
    );

$options[] = array(
    "name" => "PASS",
    "label" => "Password",
    "type"  => "password"
    );
*/

$options[] = array(
     "name"  => "EMAIL",
     "label" => "Email Address",
     "value" => C_EMAIL,
     "type"  => "email"
     );

$options[] = array(
     "name" => "BLOGNAME",
     "label" => "Blog Name",
     "value" => C_BLOGNAME,
     "type"  => "text"
     );

$options[] = array(
     "name" => "BLOG_DESCRIPTION",
     "label" => "Blog Description",
     "value" => C_BLOG_DESCRIPTION,
     "type"  => "text"
     );

$options[] = array(
    "name" => "TEMPLATE",
    "label" => "Template",
    "value" => C_TEMPLATE,
    "type"  => "text"
    );

$options[] = array(
    "name" => "DEFAULT_MODIFIER",
    "label" => "Default Modifier",
    "value" => C_DEFAULT_MODIFIER,
    "type" => "modifierselect"
    );

$options[] = array(
     "name" => "DEFAULT_STATUS",
     "label" => "Default Post Status",
     "value" => C_DEFAULT_STATUS,
     "type" => "statusselect"
     );
$options[] = array(
     "name"  => "PING",
     "label" => "Ping weblogs.com and blo.gs",
     "value" => C_PING,
     "type"  => "truefalse"
     );
$options[] = array(
     "name"  => "NOTIFY",
     "label" => "Send notifications for new comments",
     "value" => C_NOTIFY,
     "type"  => "truefalse"
     );
return $options;
}








?>
