<html><body><h1>?</h1>
<p>Read INSTALL.txt</p>
</body></html>
<?php die; ?>
