<?php
// index.php - bBlog admin interface
// index.php - author: Eaden McKee <email@eadz.co.nz>
/*
** bBlog Weblog http://www.bblog.com/
** Copyright (C) 2003  Eaden McKee <email@eadz.co.nz>
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
$loggedin = FALSE;
define('IN_BBLOG_ADMIN',TRUE);
// include the config and main code
include "config.php";

include BBLOGROOT.'inc/taglines.php';
// default title
$title = 'Admin';

// make sure the page is never cached - we should probally set no-cache headers also.
$bBlog->setmodifytime(time());

$bBlog->assign_by_ref('title',$title);
$bBlog->template_dir = BBLOGROOT.'inc/admin_templates';
$bBlog->compile_id = 'admin';
// check to see if we're not logged in
if(!$bBlog->admin_logged_in()) {
     if($_POST['username'] && $_POST['password']) { // we're trying to log in.
         $loggedin = $bBlog->userauth($_POST['username'],$_POST['password'],TRUE);

     }

} else $loggedin = TRUE;  // we're already logged in.
if($_POST['submit'] == 'Login') $bBlog->assign('tried2login',TRUE);
if(!$loggedin) { // we are not logged in! Display the login page
   $menu[0]['url']='index.php';
   $menu[0]['name']='Login';
   $menu[0]['active']=TRUE;
   $bBlog->assign_by_ref('menu',$menu);
   $title= 'Login';
   $bBlog->display("login.html");
   exit;
}

// we're logged in, Hoorah!
// set up the menu

$menu[0]['name']='Post';
$menu[0]['url']='index.php?b=post';

$menu[1]['name']='Archives';
$menu[1]['url']='index.php?b=archives';

$menu[2]['name']='Sections';
$menu[2]['url']='index.php?b=plugins&amp;p=sections';

$menu[3]['name'] = 'Comments';
$menu[3]['url']  = 'index.php?b=plugins&amp;p=comments';

$menu[4]['name'] = 'Options';
$menu[4]['url']  = 'index.php?b=options';

$menu[5]['name'] = 'Plugins';
$menu[5]['url']  = 'index.php?b=plugins';
//$menu[4]['name']='Help';
//$menu[4]['url']='index.php?b=help';



$bBlog->assign_by_ref('menu',$menu);


if(isset($_GET['b'])) $b = $_GET['b']; else $b = 'post';
if(isset($_POST['b'])) $b = $_POST['b'];

if($b == 'login') $b = 'post'; // the default action when just logged in

switch ($b) {

    case 'post' :
         $menu[0]['active'] = TRUE;
         $title = 'Post Entry';
         include BBLOGROOT.'bBlog_plugins/builtin.post.php';
         break;

    case 'archives' :
         $menu[1]['active'] = TRUE;
         $title = 'Archives';
         include BBLOGROOT.'bBlog_plugins/builtin.archives.php';
         break;

    case 'options' :
         $menu[4]['active'] = TRUE;
         $title='Options';
         include BBLOGROOT.'bBlog_plugins/builtin.options.php';
         break;

    case 'plugins' :
	 if($_GET['p'] == 'comments' or $_POST['p'] == 'comments') $menu[3]['active']= TRUE;
	 elseif($_GET['p'] == 'sections' or $_POST['p'] == 'sections') $menu[2]['active']= TRUE;
	 else   $menu[5]['active'] = TRUE;
         $title='Plugins';
         include BBLOGROOT.'bBlog_plugins/builtin.plugins.php';
         break;

    case 'help' :
         $menu[4]['active'] = TRUE;
         $title='Help';
         include BBLOGROOT.'bBlog_plugins/builtin.help.php';
         break;

    case 'logout' :
         $bBlog->admin_logout();
         header('Location: index.php');
         break;

    default :
          $bBlog->assign('errormsg','Unknown b value in admin index.php');
          $title = 'Error';
          $bBlog->display('error.html');
          break;
}
?>
