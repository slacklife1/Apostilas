<?php
// can you get to level 6?
switch($step) {
	case 0:
		// tests to get to next level :
		// 1 - agree to terms
		if($_POST['agree'] != 'yes') {
			if($_POST['submit']) $message = "<p style='color:red;'>You must agree to the terms</p>";
			break;
		} 
		$config['install_type'] = $_POST['install_type'];
		if($_POST['install_type'] == 'upgrade') {
			$config['upgrade_from'] = $_POST['upgrade_from'];
		}
		$step=1;
		break;
	case 1:
		// tests to get to next level
		// 1 - things need to be writable
		ob_start(); // we don't want any errors
		if(check_writable()) $step = 2;
		ob_end_clean();
		break;
	case 2:
		// tests : 
		// 1 - mysql connects
		// 2 - everything is set
		$allfilled=TRUE;
		
		if($_POST['blogname']) 
			$config['blogname'] = $_POST['blogname'];
			else $allfilled=FALSE;

		if($_POST['blogdescription']) 
			$config['blogdescription'] = $_POST['blogdescription'];
			else $allfilled=FALSE;

		if($_POST['username']) 
			$config['username'] = $_POST['username'];
			else $allfilled=FALSE;
		
		if($_POST['password']) 
			$config['password'] = $_POST['password'];
			else $allfilled=FALSE;
		
		if($_POST['mysql_username']) 
			$config['mysql_username'] = $_POST['mysql_username'];
			else $allfilled=FALSE;
		
		if($_POST['mysql_database'])
			$config['mysql_database'] = $_POST['mysql_database'];
			else $allfilled=FALSE;
		
		if($_POST['mysql_host'])
			$config['mysql_host'] = $_POST['mysql_host'];
			else $allfilled=FALSE;
		
		if($_POST['mysql_password']) 
			$config['mysql_password'] = $_POST['mysql_password'];


		if(!$allfilled) {
			$message = "<p style='color:red;'>You must fill all fields</p>";
			break;
		}

		// try to connect to db
		$db = new db($config['mysql_username'],$config['mysql_password'],$config['mysql_database'],$config['mysql_host']);
		if(is_array($EZSQL_ERROR)) {
			$message = $EZSQL_ERROR[0]['error_str'];
			
			break;
		}
		$func = 'upgrade_from_'.$config['upgrade_from'].'_pre';
		if($config['install_type'] == 'upgrade') {
			$step = 3;
		} else {
			$step = 4;
		}
		break;

	case 3:


		break;

}

?>
