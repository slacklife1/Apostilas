<?php
session_start();

/*###################################################
phpTextEditor v2.0 (04/09/02)
http://php.rij73.com
Copyright (C) 2002  rij73

Please post in the forum at http://php.rij73.com 
if you have any questions or comments.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/###################################################

include ("config.inc");

//password check
if(($valid_pass != $editor_password) or ($valid_user != $editor_username)) {

echo "<html><head><title>$title</title><style type=\"text/css\"><!--";

include ("style.inc");

echo "--></style></head>";
echo "<body onload=\"document.login.valid_user.focus()\"><table align=center width=750 height=\"90%\"><tr><td align=center valign=middle><form name=\"login\" method=\"post\" action=\"login.php\">";
echo "$user<br><input type=\"text\" name=\"valid_user\"><br><br>$pass<br><input type=\"password\" name=\"valid_pass\"><br><br><input type=\"submit\" name=\"submit\" value=\"login\">";
echo "</form></td></tr></table></body>";

} //end password check

//password okay, send to script!
elseif(($valid_pass == $editor_password) or ($valid_user == $editor_username)){
session_register('valid_user');
session_register('valid_pass');
header("Location: $editor_script");
}
?>

