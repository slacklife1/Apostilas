<?php
session_start();

/*###################################################
phpTextEditor v2.0 (04/09/02)
http://php.rij73.com
Copyright (C) 2002  rij73

Please post in the forum at http://php.rij73.com 
if you have any questions or comments.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/###################################################

include ("config.inc");

//password check
if(($valid_pass == $editor_password) and ($valid_user == $editor_username)){

if ($editfile=="$go_home") { //check if we should list home dir.
header("Location:$editor_script?action=listdir&dir=$path_to_root"); 
}

if(is_dir($editfile)) { //check if we should list other directory
header("Location:$editor_script?action=listdir&dir=$editfile"); 
}

############################################################################

//create a file
if ($action == create) {
$newfile = trim($dir."/".$newfile); //remove blank spaces
if (!file_exists($newfile)) {
  touch($newfile); // Create blank file
  chmod($newfile,0666); 
		if ($allow_chmod == 1) { //check to see if chmod'ing enabled
		chmod($dir, $dir_perms);
		} //endif
  header("Location:$editor_script?action=read&editfile=$newfile"); 
	
}
else {
		if ($allow_chmod == 1) { //check to see if chmod'ing enabled
		chmod($dir, $dir_perms);
		} //endif
header("Location:$editor_script?action=fileexists"); 
}

}

############################################################################

//header
echo "<html><head><title>$title</title><style type=\"text/css\"><!--";

include ("style.inc");

echo "--></style></head><body onload=\"document.filecall.editfile.focus()\">";
echo "<center><h3>$title</h3></center>";

############################################################################

//file name submit form
echo "<table width=600 align=center><tr><td><form name=\"filecall\" action=\"$editor_script\"><center>$enter: <input type=\"text\" name=\"editfile\"><input type=\"hidden\" name=\"action\" value=\"read\">&nbsp;<input type=\"submit\" value=\"$go\"></center><hr size=1 noshade></form>"; 

############################################################################

//file exists
if ($action==fileexists) {
echo "<br><br><br><br><br><center><b>$exists</b></center><br><br><br><br><br><br><br>";
}

############################################################################

//confirm delete
if ($action==deleteconfirm) {
$editfile = trim($editfile);		
if (file_exists($editfile)){ //file existence check
echo "<center>$sure <b>"."$editfile"."</b>?</center>";
			echo "<center><form action=\"$editor_script\"><input type=\"hidden\" name=\"action\" value=\"deletefile\"><input type=\"hidden\" name=\"editfile\" value=\"$editfile\"><input type=\"submit\" value=\"$yes\"></form>";			
			echo "<form action=\"$editor_script\"><input type=\"hidden\" name=\"action\" value=\"read\"><input type=\"hidden\" name=\"editfile\" value=\"$editfile\"><input type=\"submit\" value=\"$no\"></form></center>";			
}
else {
echo "<br><br><br><br><br><center><b>$no_exist</b></center><br><br><br><br><br><br><br>"; }
}

############################################################################

//delete a file
if ($action == deletefile){
unlink($editfile);
echo "<br><br><br><br><br><center><b>$done</b></center><br><br><br><br><br><br><br>";
}

############################################################################

//rename a file
if ($action == rename){
if (@rename($editfile, $newname)){
echo "<br><br><br><br><br><center><b>$done</b></center><br><br><br><br><br><br><br>";
		if ($allow_chmod == 1) { //check to see if chmod'ing enabled
		chmod($dir, $dir_perms);
		} //endif

}
else {
echo "<br><br><br><br><br><center><b>$no_rename</b></center><br><br><br><br><br><br><br>";
		if ($allow_chmod == 1) { //check to see if chmod'ing enabled
		chmod($dir, $dir_perms);
		} //endif

}
}

############################################################################

//list directory

		$dir_perms = fileperms($dir);
		$dir_perms = sprintf("%o",$dir_perms);
		$dir_perms=(substr($dir_perms,4));

if ($action == listdir) {
$dir_handle = @opendir($dir) or die("Unable to open $dir");
echo "<table align=center><tr><td>";
echo "<center>$dir<hr size=1 noshade></center>";
while($file = readdir($dir_handle)) {
		if ($file == "." or $file == "..") continue;
		$ext = substr($file, -4);
    if (in_array($ext, $forbidden)) continue;
		echo "<a href=\"$editor_script?action=read&editfile=$dir/$file&dir=$dir&frombrowse=1\">$dir/$file</a><br>";
}

//create file form

		if ($allow_chmod == 1) { //check to see if chmod'ing enabled
		chmod($dir, 0777);
		} //endif

if (is_writable($dir)) { 
echo "<form action=\"$editor_script\"><input type=\"hidden\" name=\"action\" value=\"create\"><input type=\"hidden\" name=\"dir_perms\" value=\"$dir_perms\"><input type=\"hidden\" name=\"dir\" value=\"$dir\"><input type=\"text\" name=\"newfile\">&nbsp;<input type=\"submit\" value=\"$createfile\"></form>";
}

closedir($dir_handle);
echo "<hr size=1 noshade><center><A HREF=\"javascript:history.go(-1)\">$back</A></center>";
echo "</td></tr></table>";
} //end action list

############################################################################

//read the file
if ($action == read){ 
		$editfile = trim($editfile); //remove blank spaces
		if (file_exists($editfile)){ //file existence check
		
		//return permissions in the normal format
		$perms = fileperms($editfile);
		$perms = sprintf("%o",$perms);
		$perms=(substr($perms,3));
		$dir_perms = fileperms($dir);
		$dir_perms = sprintf("%o",$dir_perms);
		$dir_perms=(substr($dir_perms,4));


		//return filesize in KB
		$size = number_format((filesize($editfile)/1024), 2);			
				
		if ($allow_chmod == 1) { //check to see if chmod'ing enabled
		chmod($editfile, 0666); //make file writable
		} //endif
		
		if (!is_writable($editfile)) //tell you if it's not writable
		{echo "<center><b>$no_perm</b></center><br>";}		
		
		//read the file and file info into the window		
		$file = $editfile; 
		$fp = fopen($file,"r"); 
		$fp_contents = fread($fp,filesize($file)); 
		fclose($fp); 
		
			//write filenames to log
			$log="log"; 
			if ($editfile != $log) { //don't add the log file itself!
				$log_fp = fopen($log,"r"); 
				$log_contents = fread($log_fp,filesize($log)); 
				fclose($log_fp); 
				$newlog = date($dateformat)."&nbsp;&nbsp;&nbsp;"."$editfile"."\n"."$log_contents";
				$log_fp2 = fopen($log, "w");
				fwrite($log_fp2, "$newlog");
				fclose($log_fp2); 
			} //end logging
			
		echo "<form action=\"$editor_script\" method=\"post\">\n";
		$fp_contents = str_replace("</textarea>","</!textarea>","$fp_contents");
		$fp_contents = str_replace("</TEXTAREA>","</!textarea>","$fp_contents");
		echo "<table cellpadding=0 cellspacing=1 border=0 width=\"100%\">";
		echo "<tr><td colspan=\"2\" align=\"center\"><b>$editfile</b> - $size KB";
		if ($allow_chmod != 1) {echo " - $permissions $perms";}
		echo "</td></tr>";
		echo "<tr><td rowspan=20 width=\"100%\"><textarea style=\"width:100%\" rows=\"29\" name=\"modification\">$fp_contents</textarea></td>";

//this is for that little scrollbar index	
echo "
<td class=\"index2\">1</td></tr>
<tr><td class=\"index1\">2</td></tr>
<tr><td class=\"index2\">3</td></tr>
<tr><td class=\"index1\">4</td></tr>
<tr><td class=\"index2\">5</td></tr>
<tr><td class=\"index1\">6</td></tr>
<tr><td class=\"index2\">7</td></tr>
<tr><td class=\"index1\">8</td></tr>
<tr><td class=\"index2\">9</td></tr>
<tr><td class=\"index1\">10</td></tr>
<tr><td class=\"index2\">11</td></tr>
<tr><td class=\"index1\">12</td></tr>
<tr><td class=\"index2\">13</td></tr>
<tr><td class=\"index1\">14</td></tr>
<tr><td class=\"index2\">15</td></tr>
<tr><td class=\"index1\">16</td></tr>
<tr><td class=\"index2\">17</td></tr>
<tr><td class=\"index1\">18</td></tr>
<tr><td class=\"index2\">19</td></tr>
<tr><td class=\"index1\">20</td></tr>
";

		if ($allow_chmod == 1) { //show chmod box if chmod enabled
		echo "<tr><td colspan=\"2\" align=\"center\">$permissions: <input type=\"text\" name=\"setperm\" size=\"5\" value=\"$perms\" onfocus=\"value=''\"></td></tr>";
		} //endif
		
		//send the filename info through
		echo "<input type=\"hidden\" name=\"action\" value=\"modify\"><input type=\"hidden\" name=\"editedfile\" value=\"$editfile\">";

		if (is_writable($editfile)) { //show submit button if writeable
			echo "<tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" value=\"$modify\"> <input type=\"reset\" value=\"$reset\"></td></tr></form>\n";

//rename
		if (($allow_chmod == 1) and ($frombrowse == 1)) { //check to see if chmod'ing enabled
		chmod($dir, 0777);
		} //endif

			if (is_writable($dir)) {
			echo "<tr><td colspan=\"2\" align=\"center\"><form action=\"$editor_script\"><input type=\"hidden\" name=\"action\" value=\"rename\"><input type=\"hidden\" name=\"dir_perms\" value=\"$dir_perms\"><input type=\"hidden\" name=\"dir\" value=\"$dir\"><input type=\"hidden\" name=\"editfile\" value=\"$editfile\">$new_name: <input type=\"text\" name=\"newname\" value=\"$editfile\"> <input type=\"submit\" value=\"$rename\"></td></tr></form>";
			}

			if ($allow_delete==1) { //show delete button
			echo "<tr><td colspan=\"2\" align=\"center\"><br><form action=\"$editor_script\"><input type=\"hidden\" name=\"action\" value=\"deleteconfirm\"><input type=\"hidden\" name=\"editfile\" value=\"$editfile\"><input type=\"submit\" value=\"$delete\"></td></tr></form>";			
			}
			
			echo "</table>";
		} //endif
		
			else { //no submit button if not writable
				echo "</table></form>\n";
			} //endelse
} //end file existence check

		else {
		echo "<br><br><br><br><br><center><b>$no_exist</b></center><br><br><br><br><br><br><br>"; }

} //end action read

############################################################################

//modify the file
if ($action == modify){ 
if (file_exists($editedfile)) {
			$file = $editedfile;
			$openFILE = fopen($file,"w"); 
			$modification = stripslashes($modification);
			$modification = str_replace("</!textarea>","</textarea>","$modification");
			fwrite($openFILE,$modification); 
			fclose($openFILE);
			
			if ($allow_chmod == 1) { //check chmod'ing
				$newperm = "0".$setperm;
				chmod($editfile, $newperm);
			} //endif
			
			echo "<br><br><br><br><br><center><b>$done</b></center><br><br><br><br><br><br><br>";
}
else {
		echo "<br><br><br><br><br><center><b>$no_exist</b></center><br><br><br><br><br><br><br>";
}
}
//end action modify

############################################################################

// footer	
echo "<hr size=1 noshade><div align=\"right\">&copy; 2002, <a href=\"http://php.rij73.com\">$version</a></div></td></tr></body></html>";

############################################################################

} //end password check
else (header("Location: login.php")); //send to login page
?>
