#######################################
phpTextEditor v2.0 (04/09/02)
http://php.rij73.com
Copyright (C) 2002  rij73

Please post in the forum at http://php.rij73.com if you use
this software. I'd really like to know what you think.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
#######################################

installation:
--
edit the config.inc file:
1> set the username and password for access to the script
2> set the chmod function to 1 if you want (see below)
3> you may change any of the other variables, but it isn't necessary
4> you may change the name of index.php, but be sure to change the
		corresponding variable in the config file

feel free to edit the style.inc file

upload the contents of the folder to your server.
CHMOD the 'log' file to 666 (or 777).

use:
--
Browse to index.php (or your renamed script). You will be prompted to login.
Login remains active until you restart your browser.

enter the browsing command (default is "list")
	click on files you wish to view/edit, or click directory names
		to list
	if a file is not writable (because of permissions) you will be told so
		but you can still view it
	if it is writable, you can edit/rename/delete to your heart's content!
	if you have allowed chmod, you may change the permissions 
		(defaults to file's initial chmod value)
	if a directory is writable, you will also be given the option of creating
		a file
	
enter "log" to see the names of files you've viewed along with the
	date and time they were seen. (You may clear this log by editing
	it right there in the text window.)

enter "help" for a brief overview

*HINT: to use this program as an online notebook, create a directory called
	"notes"	(or whatever) in your editor directory. Make that directory writable.
	Then, just enter the command "notes" (or whatever) to see what is in there.
	You can	create notes, edit them, and delete them!
	
*IMPORTANT NOTE: in order for this script to allow you to edit files with
	the <textarea> tag in them, I had to make it do something funny. so,
	when editing such files, don't be surprised to see that all the 
	</textarea> tags were changed to <!/textarea>. they are changed back again,
	not to worry. there is no problem at all, though, if you write </textarea>
	into a file.

#######################################

the CHMOD function:

	When the $allow_chmod variable is set to 0, you will only be able to edit files that are writable (ie permissions at 666 or 777). If you want to be able to edit all files, set this to 1. Then, you will be able to edit anything and the program will restore the permissions when you are finished (or you may change them).

	IMPORTANT NOTE ABOUT PHP SAFE MODE: Setting $allow_chmod to 1 will give you errors if your server is running in php safe mode. If that is the case and the server owner won't turn off safe mode, you must leave it set at 0 and you will only be able to edit writable files. Sorry...

#######################################
