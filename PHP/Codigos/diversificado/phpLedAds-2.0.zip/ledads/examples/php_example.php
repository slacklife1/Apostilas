<?php
	require('../ad_class.php');
	
	$adcode = $pla_class->adcode( );
?>

	I've already fetched the ad content, now i'm going to display it:<br>

<?php
	echo $adcode
?>