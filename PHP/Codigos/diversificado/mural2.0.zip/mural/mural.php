<?
// Cabe�alho
#################################################
require("biblioteca/fasttemplate.php");
require("biblioteca/paginacao.php");
require("config.php");
require("idiomas/${idioma}.php");
require("funcoes.php");
$mural = new FastTemplate('templates/'.$template.'/');
$nav   = new Paginacao($total_reg,2);
$mural->define(array('pagina' => 'mural.htm'));
$mural->assign('{Titulo}', $idioma_titulo);
$mural->assign('{Css}','templates/'.$template.'/');
$mural->assign('{Copyright}', $copyright);
$mural->assign('{IdiomaTotal}', $idioma_total);
$mural->assign('{IdiomaMostrando}', $idioma_mostrando);
$mural->assign('{IdiomaDe}', $idioma_de);
$mural->assign('{IdiomaPagina}', $idioma_pagina);
// Inicio
#################################################
conecta();
$nav->query("SELECT * FROM mural ORDER BY id DESC");
$sql2  = mysql_query("SELECT * FROM mural")or die("<font color=#FF0000><b>$idioma_selecio_dados</b></font>");
$tr = mysql_num_rows($sql2);
// Cabe�alho
#################################################
if ($_COOKIE['ip'])
   $mural->assign('{Menu1}',"<a href=\"mural.php\" onClick=\"javascript:flood()\" onmouseover=\"window.status='$idioma_post_mensagem'; return true;\">$idioma_post_mensagem</a>\n");
else
   $mural->assign('{Menu1}',"<a href=\"javascript:abrir_form('form.php')\" onmouseover=\"window.status='$idioma_post_mensagem'; return true;\">$idioma_post_mensagem</a>");
$mural->assign('{Menu2}',"<a href=\"javascript:abrir('ajuda.php')\" onmouseover=\"window.status='$idioma_ajuda'; return true;\">$idioma_ajuda</a>"); 
$mural->assign('{Menu3}',"<a href=\"admin.php\" onmouseover=\"window.status='$idioma_admin'; return true;\">$idioma_admin</a></b>");
// Sistema de Navega��o
#################################################
$pagina=$nav->print_info();
$mural->assign('{Tr}', $pagina['total']);
$mural->assign('{Nav}', $nav->print_link());
// Resultados na tela
#################################################
if($tr == 0){ 
  $mural->define_dynamic('erro','pagina');
  $mural->assign('{Erro}',$idioma_nao_encontrada);
  $mural->parse('ERRO','.erro');
  $mural->define_dynamic('tabela','pagina');
  $mural->clear_dynamic('tabela'); 
}
else{
  $mural->define_dynamic('erro','pagina');
  $mural->clear_dynamic('erro'); 
  $mural->define_dynamic('tabela','pagina');
  while ($resultado=$nav->result_assoc()) {
    $mural->assign('{Cor}', ($coralternada++ %2 ? $corFundoTabela01 : $corFundoTabela02));
    $mural->assign('{Nome}', stripslashes(strip_tags($resultado['nome'], '<i>')));
    $mural->assign('{Para}', stripslashes(strip_tags($resultado['para'], '<i>')));
    $mural->assign('{Email}', stripslashes(strtolower(strip_tags ($resultado['email']))));
    $mural->assign('{Data}', $resultado['data']);
    $mural->assign('{Mensagem}', codifica_url(filtro(quebra_linha(stripslashes($resultado['mensagem'])))));
    $mural->parse('TABELA','.tabela');
  }
}
// Rodap�
#################################################
mysql_close($conexao);
if(!$_GET['pagina'])
$pc = "1";
else
$pc = $_GET['pagina'];
$mural->assign('{Nav4}', $pc);
$mural->assign('{Nav5}', $pagina['total']/$total_reg);
$mural->parse('OUTPUT','pagina');
$mural->FastPrint('OUTPUT');
?>