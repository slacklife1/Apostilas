<?
// Cabe�alho
#################################################
require("biblioteca/fasttemplate.php");
require("biblioteca/paginacao.php");
require("config.php");
require("idiomas/${idioma}.php");
require("funcoes.php");
$mural = new FastTemplate('templates/'.$template.'/');
$nav   = new Paginacao(20,2);
$mural->define (array('pagina' => 'admin.htm'));
$mural->assign('{Titulo}', $idioma_titulo);
$mural->assign('{Copyright}', $copyright);
$mural->assign('{Css}','templates/'.$template.'/');
// Cookies
#################################################
conecta();
$sql = mysql_query("SELECT * FROM usuario");
$nav->query("SELECT * FROM mural ORDER BY id DESC");
while($resultado = mysql_fetch_array($sql)){
   $user = $resultado['usuario'];
   $password   = $resultado['senha'];
}
if($HTTP_COOKIE_VARS['usuario'] != $user AND $HTTP_COOKIE_VARS['senha'] != $password){
   header("Location: login.php");
}
// Vari�veis
#################################################
$mural->assign('{IdiomaTituloAdmin}', $idioma_tit_admin);
$mural->assign('{IdiomaOpcaoAdmin}', $idioma_opcao_admin);
$mural->assign('{IdiomaEditarAdmin}', $idioma_editar_admin);
$mural->assign('{IdiomaExcluirAdmin}', $idioma_excluir3_admin);
$mural->assign('{IdiomaMudarAdmin}', $idioma_mudar_admin);
$mural->assign('{IdiomaFiltroAdmin}', $idioma_filtro_admin);
$mural->assign('{IdiomaApagaFiltroAdmin}', $idioma_filtro_del);
$mural->assign('{IdiomaSairAdmin}', $idioma_sair_admin);
$mural->assign('{IdiomaTotal}', $idioma_total);
$mural->assign('{Titulo}', $idioma_titulo);
$mural->assign('{IdiomaMostrando}', $idioma_mostrando);
$mural->assign('{IdiomaDe}', $idioma_de);
$mural->assign('{IdiomaPagina}', $idioma_pagina);
// Sair
#################################################
if($HTTP_GET_VARS['acao'] == "sair"){
   sair(); 
}
// Nav
#################################################
$pagina=$nav->print_info();
$mural->assign('{Tr}', $pagina['total']);
$mural->assign('{Nav}', $nav->print_link());
// Apagar Todas
#################################################
if($HTTP_GET_VARS['acao'] == "apagar_todas"){
   $mural->define_dynamic('visualizar','pagina');
   $mural->clear_dynamic('visualizar');
   if($pagina['total'] != 0){
      $mural->define_dynamic('erro','pagina');
	  $mural->assign('{Erro}',"$idioma_acao_excluir<br><br><a href=\"?acao=apagar_msg&opcao=sim\">$idioma_sim_excluir</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"admin.php\">$idioma_nao_excluir</a>");
      $mural->parse('ERRO','.erro');
  	  $mural->define_dynamic('visualizar','pagina');
 	  $mural->clear_dynamic('visualizar');
 	  $mural->define_dynamic('edicao','pagina');
 	  $mural->clear_dynamic('edicao');
 	  $mural->define_dynamic('mudar_senha','pagina');
 	  $mural->clear_dynamic('mudar_senha');
 	  $mural->define_dynamic('filtro','pagina');
 	  $mural->clear_dynamic('filtro');
	  $mural->define_dynamic('sel','pagina');
      $mural->clear_dynamic('sel');
	  $mural->define_dynamic('nav','pagina');
      $mural->clear_dynamic('nav');
   }
   else{
      $mural->define_dynamic('erro','pagina');
      $mural->assign('{Erro}',$idioma_nao_encontrada);
      $mural->parse('ERRO','.erro');
      $mural->define_dynamic('visualizar','pagina');
      $mural->clear_dynamic('visualizar');
      $mural->define_dynamic('edicao','pagina');
      $mural->clear_dynamic('edicao');
      $mural->define_dynamic('mudar_senha','pagina');
      $mural->clear_dynamic('mudar_senha');
      $mural->define_dynamic('filtro','pagina');
      $mural->clear_dynamic('filtro');
      $mural->define_dynamic('sel','pagina');
      $mural->clear_dynamic('sel');
	  $mural->define_dynamic('nav','pagina');
      $mural->clear_dynamic('nav');
   }

}
if($HTTP_GET_VARS['acao'] == "apagar_msg" && $HTTP_GET_VARS['opcao'] == "sim"){
   mysql_query ("TRUNCATE TABLE mural");
   $mural->assign('{Erro}',$idioma_sucesso_admin);
   $mural->define_dynamic('visualizar','pagina');
   $mural->clear_dynamic('visualizar');
   $mural->define_dynamic('edicao','pagina');
   $mural->clear_dynamic('edicao');
   $mural->define_dynamic('mudar_senha','pagina');
   $mural->clear_dynamic('mudar_senha');
   $mural->define_dynamic('filtro','pagina');
   $mural->clear_dynamic('filtro');
   $mural->define_dynamic('sel','pagina');
   $mural->clear_dynamic('sel');
   $mural->define_dynamic('nav','pagina');
   $mural->clear_dynamic('nav');
}
// Visualizar
#################################################
if($_SERVER['QUERY_STRING']==''){
   $mural->define_dynamic('visualizar','pagina');
   $mural->assign('{IdiomaOpDesAdmin}',$idioma_op_des_admin);   
   $mural->assign('{IdiomaEditarAdmin}',$idioma_editar_admin);   
   $mural->assign('{IdiomaOpDesAdmin}',$idioma_op_des_admin);   
   $mural->assign('{IdiomaOpDesAdmin}',$idioma_op_des_admin);
   $mural->assign('{IdiomaBrowserAdmin}',$idioma_browser_admin);   
   $mural->assign('{IdiomaIpAdmin}',$idioma_ip_admin);
   $mural->define_dynamic('sel','pagina');
   $mural->assign('{IdiomaExcluirSelecionadasAdmin}',$idioma_del_sel_admin);   
   if($pagina['total'] == 0){
      $mural->define_dynamic('erro','pagina');
	  $mural->assign('{Erro}',$idioma_nao_encontrada);
      $mural->parse('ERRO','.erro');
      $mural->clear_dynamic('visualizar');
	  $mural->define_dynamic('edicao','pagina');
	  $mural->clear_dynamic('edicao');
  	  $mural->define_dynamic('mudar_senha','pagina');
	  $mural->clear_dynamic('mudar_senha');
	  $mural->define_dynamic('filtro','pagina');
      $mural->clear_dynamic('filtro');
	  $mural->define_dynamic('sel','pagina');
      $mural->clear_dynamic('sel');
	  $mural->define_dynamic('nav','pagina');
      $mural->clear_dynamic('nav');
   }
   else{
      $mural->define_dynamic('erro','pagina');
      $mural->clear_dynamic('erro');
	  $mural->define_dynamic('edicao','pagina');
	  $mural->clear_dynamic('edicao');
  	  $mural->define_dynamic('mudar_senha','pagina');
	  $mural->clear_dynamic('mudar_senha');
	  $mural->define_dynamic('filtro','pagina');
      $mural->clear_dynamic('filtro');
	  while($resultado=$nav->result_assoc()){
         $mural->assign('{Codigo}',$resultado['id']);
	     $mural->assign('{Ip}',$resultado['ip']);
	     $mural->assign('{Browser}',$resultado['browser']);
   	     $mural->assign('{Nome}',stripslashes(strip_tags ($resultado['nome'], '<i>')));
	     $mural->assign('{Email}',stripslashes(strip_tags (strtolower ($resultado['email']))));
	     $mural->assign('{Data}',$resultado['data']);
	     $mural->assign('{Comentario}',codifica_url(quebra_linha(stripslashes($resultado['mensagem']))));
         $mural->parse('VISUALIZAR','.visualizar');
	  }
   }
   $mural->parse('SEL','.sel');
}
// Apagar
#################################################
if($HTTP_GET_VARS['acao'] == 'apagar'){
   if($HTTP_POST_VARS['id'] != ''){
      foreach($HTTP_POST_VARS['id'] as $v){
         mysql_query("DELETE FROM mural WHERE id=$v") or die ("Erro ao apagar arquivo");
      } 
      mysql_query ("OPTIMIZE TABLE mural") or die ("Erro ao apagar arquivo");
      echo "<script language=javascript>location.replace('admin.php');</script>\n";
   }
}
// Mudar Senha
#################################################
if($HTTP_GET_VARS['acao'] == "mudar_senha"){
   $mural->define_dynamic('erro','pagina');
   $mural->clear_dynamic('erro');
   $mural->define_dynamic('visualizar','pagina');
   $mural->clear_dynamic('visualizar');
   $mural->define_dynamic('edicao','pagina');
   $mural->clear_dynamic('edicao');
   $mural->define_dynamic('filtro','pagina');
   $mural->clear_dynamic('filtro');
   $mural->define_dynamic('sel','pagina');
   $mural->clear_dynamic('sel');
   $mural->define_dynamic('nav','pagina');
   $mural->clear_dynamic('nav');
   $mural->assign('{IdiomaAlterAdmin}',$idioma_alter_admin);   
   $mural->assign('{IdiomaUsuarioLogin}',$idioma_usuario_login);   
   $mural->assign('{IdiomaSenhaLogin}',$idioma_senha_login);   
   $mural->assign('{IdiomaEnviarAdmin}',$idioma_enviar_admin);
}	  
// Mudar Senha Sim
#################################################
if($HTTP_GET_VARS['acao'] == "senha" && $HTTP_GET_VARS['mudar'] == "sim"){
   $pass = $HTTP_POST_VARS['senha1'];
   @mysql_query ("UPDATE usuario SET usuario='$HTTP_POST_VARS[usuario1]', senha='$pass'");
   $mural->define_dynamic('erro','pagina');
   $mural->assign('{Erro}',$idioma_alter_sucess);
   $mural->parse('ERRO','.erro');
   $mural->define_dynamic('visualizar','pagina');
   $mural->clear_dynamic('visualizar');
   $mural->define_dynamic('edicao','pagina');
   $mural->clear_dynamic('edicao');
   $mural->define_dynamic('mudar_senha','pagina');
   $mural->clear_dynamic('mudar_senha');
   $mural->define_dynamic('filtro','pagina');
   $mural->clear_dynamic('filtro');
   $mural->define_dynamic('sel','pagina');
   $mural->clear_dynamic('sel');
   $mural->define_dynamic('nav','pagina');
   $mural->clear_dynamic('nav');
}		
// Edi��o
#################################################
if($HTTP_GET_VARS['acao'] == "editar" && $HTTP_GET_VARS['id'] == $id){
   $nav->query("SELECT * FROM mural WHERE id='$id'");
   $mural->define_dynamic('edicao','pagina');
   $mural->assign('{IdiomaEdicaoAdmin}',$idioma_edicao_admin);
   $mural->assign('{IdiomaNome}',$idioma_nome);
   $mural->assign('{IdiomaPara}',$idioma_para);
   $mural->assign('{IdiomaEmail}',$idioma_email);
   $mural->assign('{IdiomaMensagem}',$idioma_msg);
   $mural->assign('{IdiomaEnviar}',$idioma_enviar);
   $mural->assign('{Codigo}',$id);
   $mural->define_dynamic('erro','pagina');
   $mural->clear_dynamic('erro');
   $mural->define_dynamic('visualizar','pagina');
   $mural->clear_dynamic('visualizar');
   $mural->define_dynamic('mudar_senha','pagina');
   $mural->clear_dynamic('mudar_senha');
   $mural->define_dynamic('filtro','pagina');
   $mural->clear_dynamic('filtro');
   $mural->define_dynamic('sel','pagina');
   $mural->clear_dynamic('sel');
   $mural->define_dynamic('nav','pagina');
   $mural->clear_dynamic('nav');
   while($resultado=$nav->result_assoc()){
      $mural->assign('{Nome}',$resultado['nome']);
      $mural->assign('{Para}',$resultado['para']);
      $mural->assign('{Email}',$resultado['email']);
      $mural->assign('{Msg}',decodifica_msg($resultado['mensagem']));
   }
   $mural->parse('EDICAO','.edicao');
}
// Edi��o Sim
#################################################
if($HTTP_GET_VARS['acao'] == "editar_post" && $HTTP_GET_VARS['id'] == $id && $HTTP_GET_VARS['editar'] == "sim"){
   $msg = codifica_msg($HTTP_POST_VARS['comentario']);
   mysql_query("UPDATE mural SET nome='$HTTP_POST_VARS[nome]', para='$HTTP_POST_VARS[para]', email='$HTTP_POST_VARS[email]', mensagem='$msg' WHERE id='$id'")
   or die ("Erro ao editar post");
   $mural->define_dynamic('erro','pagina');
   $mural->assign('{Erro}',"$idioma_edicao_sucess <br> <a href=\"admin.php\">$idioma_edicao_outras</a>");
   $mural->parse('ERRO','.erro');
   $mural->define_dynamic('visualizar','pagina');
   $mural->clear_dynamic('visualizar');
   $mural->define_dynamic('edicao','pagina');
   $mural->clear_dynamic('edicao');
   $mural->define_dynamic('mudar_senha','pagina');
   $mural->clear_dynamic('mudar_senha');
   $mural->define_dynamic('filtro','pagina');
   $mural->clear_dynamic('filtro');
   $mural->define_dynamic('sel','pagina');
   $mural->clear_dynamic('sel');
   $mural->define_dynamic('nav','pagina');
   $mural->clear_dynamic('nav');
}
// Filtro
#################################################
if($HTTP_GET_VARS['acao'] == "filtro" && $HTTP_GET_VARS['modo'] == "adicionar"){
   $mural->define_dynamic('filtro','pagina');
   $mural->assign('{IdiomaEnviarFiltro}',$idioma_env_filtro);
   $mural->assign('{IdiomaCensurada}',$idioma_censurada);
   $mural->assign('{IdiomaGerenFiltro}',$idioma_geren_filtro);
   $mural->assign('{IdiomaSubstituir}',$idioma_substituir);
   $mural->define_dynamic('erro','pagina');
   $mural->clear_dynamic('erro');
   $mural->define_dynamic('visualizar','pagina');
   $mural->clear_dynamic('visualizar');
   $mural->define_dynamic('edicao','pagina');
   $mural->clear_dynamic('edicao');
   $mural->define_dynamic('mudar_senha','pagina');
   $mural->clear_dynamic('mudar_senha');
   $mural->define_dynamic('edicao','pagina');
   $mural->clear_dynamic('edicao');
   $mural->define_dynamic('sel','pagina');
   $mural->clear_dynamic('sel');
   $mural->define_dynamic('nav','pagina');
   $mural->clear_dynamic('nav');
   $mural->parse('FILTRO','.filtro');
}
// Filtro Sim
#################################################
if($HTTP_GET_VARS['acao'] == "filtro" && $HTTP_GET_VARS['modo'] == "add" && $HTTP_GET_VARS['executar'] == "ok"){
   $msg_errada = $HTTP_POST_VARS['msg_censurada'];
   $msg_correta = "[b]$HTTP_POST_VARS[msg_subst][/b]";
   mysql_query("INSERT INTO filtro (msg_errada, msg_correta) VALUES ('$msg_errada','$msg_correta')");
   mysql_query("OPTIMIZE TABLE filtro");
   $mural->define_dynamic('erro','pagina');
   $mural->assign('{Erro}',$idioma_filtro_sucess);
   $mural->parse('ERRO','.erro');
   $mural->define_dynamic('visualizar','pagina');
   $mural->clear_dynamic('visualizar');
   $mural->define_dynamic('edicao','pagina');
   $mural->clear_dynamic('edicao');
   $mural->define_dynamic('mudar_senha','pagina');
   $mural->clear_dynamic('mudar_senha');
   $mural->define_dynamic('filtro','pagina');
   $mural->clear_dynamic('filtro');
   $mural->define_dynamic('edicao','pagina');
   $mural->clear_dynamic('edicao');
   $mural->define_dynamic('sel','pagina');
   $mural->clear_dynamic('sel');
   $mural->define_dynamic('nav','pagina');
   $mural->clear_dynamic('nav');
}
// Filtro Excluir
#################################################
if($HTTP_GET_VARS['acao'] == "filtro" && $HTTP_GET_VARS['modo'] == "excluir"){
   $sql=mysql_query("SELECT id, msg_errada, msg_correta FROM filtro");
   $linha=mysql_num_rows($sql);
   $mural->define_dynamic('erro','pagina');
   $mural->define_dynamic('visualizar','pagina');
   $mural->clear_dynamic('visualizar');
   $mural->define_dynamic('edicao','pagina');
   $mural->clear_dynamic('edicao');
   $mural->define_dynamic('mudar_senha','pagina');
   $mural->clear_dynamic('mudar_senha');
   $mural->define_dynamic('filtro','pagina');
   $mural->clear_dynamic('filtro');
   $mural->define_dynamic('edicao','pagina');
   $mural->clear_dynamic('edicao');
   $mural->define_dynamic('sel','pagina');
   $mural->clear_dynamic('sel');
   $mural->define_dynamic('nav','pagina');
   $mural->clear_dynamic('nav');
   if($linha != '0'){
      while($resultado=mysql_fetch_array($sql)){
         $mural->define_dynamic('erro','pagina');
 		 $mural->assign('{Erro}',"<a href=\"?acao=filtro&modo=del&confirma=sim&id=$resultado[id]\">$resultado[msg_errada]</a><br>");
         $mural->parse('ERRO','.erro');
	  }
   }	 
   else{
      $mural->define_dynamic('erro','pagina');
      $mural->assign('{Erro}',$idioma_sem_filtro); 
      $mural->parse('ERRO','.erro');
  }
} 
// Filtro Excluir Sim
#################################################
if($HTTP_GET_VARS['acao'] == "filtro" && $HTTP_GET_VARS['modo'] == "del" && $HTTP_GET_VARS['confirma'] == "sim"){
   if($id != ''){
	  $sql_del = mysql_query ("DELETE FROM filtro WHERE id='$id'");
	             mysql_query ("OPTIMIZE TABLE filtro");
	  echo "<script language=javascript>location.replace('$PHP_SELF?acao=filtro&modo=excluir');</script>\n";
   }
}
mysql_close($conexao);
if(!$_GET['pagina'])
$pc = "1";
else
$pc = $_GET['pagina'];
$mural->assign('{Nav4}', $pc);
$mural->assign('{Nav5}', $pagina['total']/$total_reg);
$mural->parse('OUTPUT','pagina');
$mural->FastPrint('OUTPUT');
?>
