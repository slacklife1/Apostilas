<?
class Paginacao{
	var $inter4u;
	var $p;
	var $pagina;
	var $q;
	var $query;
	var $anterior;
	var $proximo;
	var $numero;

function paginacao($max_pagina=5, $max_link=5, $proximo="Anterior", $anterior="Pr�xima", $numero="%%numero%%"){
	$this->next=$anterior;
	$this->prev=$proximo;
	$this->numero=$numero;
	$this->p["max_pagina"]=$max_pagina;
	$this->p["max_link"]=$max_link;
	$_SERVER["QUERY_STRING"]=preg_replace("/pagina=[0-9]*/","",$_SERVER["QUERY_STRING"]);
	if(empty($_GET["pagina"])){
		$this->pagina=1;
	}
	else{
		$this->pagina=$_GET["pagina"];
	}
}

function query($query){
	// Somente Seleciona
	if(!preg_match("/^[\s]*select*/i",$query)){
		$query="select ".$query;
	}
	// Filtra a Query
    $query_temp=preg_replace("/select .* from (.*)/si","select count(*) from \\1",$query);
	$result_temp=mysql_query($query_temp) or die ("Erro de Query");
	list($this->p["count"]) = mysql_fetch_row($result_temp);
	// Total de P�ginas
	$this->p["total_pagina"]=ceil($this->p["count"]/$this->p["max_pagina"]);
	// Filtra P�gina
	if($this->pagina<=1)
    	$this->pagina=1;
	elseif($this->pagina>$this->p["total_pagina"])
		$this->pagina=$this->p["total_pagina"];
	// Query
	$this->p["nav"]=$this->pagina*$this->p["max_pagina"]-$this->p["max_pagina"];
	$query=$query." limit ".$this->p["nav"].",".$this->p["max_pagina"];
	$query=mysql_query($query) or die("Erro");
	$this->query=$query;
}
	
function result(){
	return $result=mysql_fetch_object($this->query);
}

function result_assoc(){
	return mysql_fetch_assoc($this->query);
}

function print_no(){
	$numero=$this->p["nav"]+=1;
	return $numero;
}

function print_info(){
	$pagina=array();
	$pagina["inicio"]=$this->p["nav"]+1;
	$pagina["fim"]=$this->p["nav"]+$this->p["max_pagina"];
	$pagina["total"]=$this->p["count"];
	$pagina["total_paginas"]=$this->p["total_pagina"];
	if($pagina["fim"] > $pagina["total"]) {
		$pagina["fim"]=$pagina["total"];
	}
	if(empty($this->p["count"])) {
		$pagina["inicio"]=0;
	}
	return $pagina;
}

function print_link(){
	// Gera Template
	function numero($i,$numero){
		return ereg_replace("^(.*)%%numero%%(.*)$","\\1$i\\2",$numero);
	}
	$print_link = false;
	if($this->p["count"]>$this->p["max_pagina"]){
	// Imprime Anterior
	if($this->pagina>1)
		$print_link .= "<a href=\"".$_SERVER["PHP_SELF"]."?pagina=".($this->pagina-1)."\">".$this->prev."</a>\n";
	// Seta N�mero
	$this->p["bawah"]=$this->pagina-$this->p["max_link"];
	if($this->p["bawah"]<1) $this->p["bawah"]=1;
    	$this->p["atas"]=$this->pagina+$this->p["max_link"];
	if($this->p["atas"]>$this->p["total_pagina"]) $this->p["atas"]=$this->p["total_pagina"];
	// Imprime In�cio
    	if($this->pagina<>1){
			for ($i=$this->p["bawah"];$i<=$this->pagina-1;$i++)
			if(numero($i,$this->numero)<10)
				$print_link .="<a href=\"".$_SERVER["PHP_SELF"]."?pagina=$i\">[0".numero($i,$this->numero)."]</a>\n";
			else
				$print_link .="<a href=\"".$_SERVER["PHP_SELF"]."?pagina=$i\">[".numero($i,$this->numero)."]</a>\n";
		}
	// Imprime Ativo
	if($this->p["total_pagina"]>1)
		if(numero($this->pagina,$this->numero)<10)
    		  $print_link .= "<b>[0".numero($this->pagina,$this->numero)."]</b>\n";
		else
			  $print_link .= "<b>[".numero($this->pagina,$this->numero)."]</b>\n";
	// Imprime FIm
	for ($i=$this->pagina+1;$i<=$this->p["atas"];$i++)
		if(numero($i,$this->numero)<10)
             $print_link .= "<a href=\"".$_SERVER["PHP_SELF"]."?pagina=$i\">[0".numero($i,$this->numero)."]</a>\n";
	    else
             $print_link .= "<a href=\"".$_SERVER["PHP_SELF"]."?pagina=$i\">[".numero($i,$this->numero)."]</a>\n";
	// Imprime Pr�ximo
	if($this->pagina<$this->p["total_pagina"])
		$print_link .= "<a href=\"".$_SERVER["PHP_SELF"]."?pagina=".($this->pagina+1)."\">".$this->next."</a>\n";
	return $print_link;
	}
}
}
?>