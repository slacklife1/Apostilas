<?
// Cabe�alho
#################################################
require("biblioteca/fasttemplate.php");
require("config.php");
require("idiomas/${idioma}.php");
require("funcoes.php");
$mural = new FastTemplate('templates/'.$template.'/');
$mural->define(array('pagina' => 'form.htm'));
$mural->assign('{Titulo}', $idioma_titulo);
$mural->assign('{Copyright}', $copyright);

// Faz a inser��o dos dados no mural
#################################################
if($HTTP_POST_VARS['acao'] == "cadastrar"){
  conecta();
  $ip      = getenv("REMOTE_ADDR");
  $browser = getenv("HTTP_USER_AGENT");
  $nome    = $HTTP_POST_VARS['nome'];
  $para    = $HTTP_POST_VARS['para'];
  $email   = $HTTP_POST_VARS['email'];
  $data    = date('d/m/y H:i');
  $msg     = codifica_msg(strip_tags($HTTP_POST_VARS['comentario']));
  if(empty($nome)){
    $erro = $idioma_nome_vazio; $err = 1;
  }
  if(empty($para)){
    $erro = $idioma_para_vazio; $err = 1;
  }
  elseif(!eregi("^[0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\\.[a-z]{2,3}$",$email)){ 
	$erro = $idioma_email_errado; $err = 1;
  }
  elseif(empty($msg)){
    $erro = $idioma_msg_vazia; $err = 1;
  }
  else{
    @mysql_query("INSERT INTO mural (ip, browser, nome, para, email, data, mensagem) VALUES ('$ip','$browser','$nome','$para','$email','$data','$msg')")
    or die("<font color=#FF0000><b>$idioma_inserir_dados</b></font>");
    setcookie("ip", $ip, time()+(60*$tempo_cookie), "/");
    echo "<script language=\"javascript\">\n function closeWindow(){\n window.close();\n }\n opener.location.href = opener.location;\n setTimeout('closeWindow()', 100);\n </script>\n";
  }
}
if($err == 1){
  $mural->define_dynamic('Erro','pagina');
  $mural->assign("{Erro}", $erro);
  $mural->parse('ERRO','.Erro');
}
else{
  $mural->define_dynamic('Erro','pagina');
  $mural->clear_dynamic('Erro');
}  

// Vari�veis
#################################################
$mural->assign("{Nome}", $nome);
$mural->assign("{Para}", $para);
$mural->assign("{Email}", $email);
$mural->assign("{Mensagem}", decodifica_msg($msg));
$mural->assign("{IdiomaCaracteres}", $idioma_caracteres);
$mural->assign("{IdiomaCaracteres2}", $idioma_caracteres2);
$mural->assign("{IdiomaNome}", $idioma_nome);
$mural->assign("{IdiomaPara}", $idioma_para);
$mural->assign("{IdiomaEmail}", $idioma_email);
$mural->assign("{IdiomaMensagem}", $idioma_mensagem);
$mural->assign("{IdiomaEnviar}", $idioma_enviar);
$mural->assign("{IdiomaCodigo}", $idioma_codigo);
$mural->assign("{IdiomaAdmin}", $idioma_admin);
$mural->assign("{IdiomaAjuda}", $idioma_ajuda);
$mural->assign("{IdiomaVoltar}", $idioma_back_mural);
$mural->assign('{Css}','templates/'.$template.'/');
$mural->parse('OUTPUT','pagina');
$mural->FastPrint('OUTPUT');
mysql_close($conexao);
?>