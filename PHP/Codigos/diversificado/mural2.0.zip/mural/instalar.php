<?
include("config.php");
include("funcoes.php");
include("idiomas/${idioma}.php");

if($HTTP_GET_VARS['acao'] == "instalar" && $HTTP_GET_VARS['etapa'] == 1){
  $config = "<?\n";
  $config.= "\$host             = '$HTTP_POST_VARS[host]';\n";       
  $config.= "\$usuario          = '$HTTP_POST_VARS[usuario]';\n";            
  $config.= "\$senha            = '$HTTP_POST_VARS[senha]';\n";                 
  $config.= "\$banco            = '$HTTP_POST_VARS[banco]';\n";           
  $config.= "\$total_reg        = '$HTTP_POST_VARS[exibido]';\n";                 
  $config.= "\$idioma           = '$HTTP_POST_VARS[idioma]';\n";    
  $config.= "\$v_mural          = '1.4';\n";
  $config.= "\$tempo_cookie     = '$HTTP_POST_VARS[tempo_cookie]';\n";
  $config.= "\$template         = '$HTTP_POST_VARS[template]';\n";
  $config.= "\$corFundoTabela01 = 'CCCCCC';\n";
  $config.= "\$corFundoTabela02 = 'EEEEEE';\n";
  $config.= "?>\n";
  
  $fp = fopen("config.php", "w");
  fputs($fp, $config);
  fclose($fp);
  
  $resultado = "<p align=left><font color=#FF0000>
  <strong>INSTRU&Ccedil;&Otilde;ES:</strong><br> Primeira parte conclu&iacute;da</font><br>
  Clique no bot&atilde;o prosseguir para continuar a instala&ccedil;&atilde;o<br>
  </p><form action=instalar.php?acao=instalar&etapa=2 method=post>
  <table width=100% border=0 cellpadding=3 cellspacing=0 class=tabela>
  <tr><td width=100%> <div align=center>
  <input name=Submit type=submit class=botao value=PROSSEGUIR>
  </div></td></tr></table></form>";
}

elseif($HTTP_GET_VARS['acao'] == "instalar" && $HTTP_GET_VARS['etapa'] == 2){
  conecta();
  @mysql_query("CREATE TABLE mural (
  id smallint(6) NOT NULL auto_increment,
  ip varchar(20) default NULL,
  browser varchar(100) NOT NULL default '',
  nome varchar(100) NOT NULL default '',
  para varchar(30) default NULL,
  email varchar(30) NOT NULL default '',
  data varchar(24) default NULL,
  mensagem text NOT NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM COMMENT='Mural de Recados';") or die("Ocorreu um erro ao adicionar a tabela mural (".mysql_error().")");
  @mysql_query("CREATE TABLE smilies (
  cod varchar(5) NOT NULL default '',
  link varchar(20) NOT NULL default '',
  nome varchar(20) NOT NULL default '',
  PRIMARY KEY  (cod)
) TYPE=MyISAM COMMENT='Tabela dos Smilies do Mural';") or die("Ocorreu um erro ao adicionar a tabela smilies (".mysql_error().")");
  @mysql_query("CREATE TABLE usuario (
  usuario varchar(50) NOT NULL default '',
  senha varchar(15) NOT NULL default '',
  PRIMARY KEY  (usuario)
) TYPE=MyISAM COMMENT='Tabela de Administra��o';") or die("Ocorreu um erro ao adicionar a tabela usuario (".mysql_error().")");
  @mysql_query("CREATE TABLE filtro (
  id smallint(6) NOT NULL auto_increment,
  msg_errada varchar(200) default NULL,
  msg_correta varchar(200) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM COMMENT='Tabela de Filtro de Palavr�es';") or die("Ocorreu um erro ao adicionar a tabela filtro (".mysql_error().")"); 
  mysql_close($conexao);
  
  $resultado = "<p align=left><font color=#FF0000><strong>INSTRU&Ccedil;&Otilde;ES:</strong><br>
  Todas as tabelas foram adicionadas com sucesso</font><br>
  Para concluir a instala&ccedil;&atilde;o, coloque seu nome de usuario e senha 
  para a administra&ccedil;&atilde;o<br>
  </p><form action=instalar.php?acao=instalar&etapa=3 method=post>
  <table width=100% border=0 cellpadding=3 cellspacing=0 class=tabela>
  <tr><td width=7%>Usu&aacute;rio:</td>
  <td width=93%><input name=user type=text class=campos2 id=user size=30></td>
  </tr><tr><td>Senha:</td>
  <td><input name=password type=password class=campos2 id=password size=30></td>
  </tr><tr><td colspan=2> <div align=center><br>
  <input name=Submit type=submit class=botao value=FINALIZAR>
  </div></td></tr></table></form>";
}

elseif ($HTTP_GET_VARS['acao'] == "instalar" && $HTTP_GET_VARS['etapa'] == 3){
  conecta();
  $pass = $HTTP_POST_VARS['password'];
  @mysql_query("INSERT INTO usuario VALUES ('$HTTP_POST_VARS[user]', '$pass')") or die("Ocorreu um erro ao adicionar usuario e senha na tabela (".mysql_error().")");
  @mysql_query("INSERT INTO smilies VALUES (':anj:', '001.gif', 'anjo')");
  @mysql_query("INSERT INTO smilies VALUES (':ner:', '002.gif', 'nervoso')");
  @mysql_query("INSERT INTO smilies VALUES (':dog:', '003.gif', 'cachorro')");
  @mysql_query("INSERT INTO smilies VALUES (':lov:', '004.gif', 'coracao_quebrado')");
  @mysql_query("INSERT INTO smilies VALUES (':bol:', '005.gif', 'bolo')");
  @mysql_query("INSERT INTO smilies VALUES (':enj:', '006.gif', 'enjoado')");
  @mysql_query("INSERT INTO smilies VALUES (':cho:', '007.gif', 'chorando')");
  @mysql_query("INSERT INTO smilies VALUES (':tim:', '008.gif', 'timido')");
  @mysql_query("INSERT INTO smilies VALUES (':cor:', '009.gif', 'coracao')");
  @mysql_query("INSERT INTO smilies VALUES (':bej:', '010.gif', 'beijo')");
  @mysql_query("INSERT INTO smilies VALUES (':lua:', '011.gif', 'lua')");
  @mysql_query("INSERT INTO smilies VALUES (':msn:', '012.gif', 'msn')");
  @mysql_query("INSERT INTO smilies VALUES (':mid:', '013.gif', 'musica')");
  @mysql_query("INSERT INTO smilies VALUES (':esp:', '014.gif', 'espanto')");
  @mysql_query("INSERT INTO smilies VALUES (':tel:', '015.gif', 'telefone')");
  @mysql_query("INSERT INTO smilies VALUES (':pre:', '016.gif', 'presente')");
  @mysql_query("INSERT INTO smilies VALUES (':ale:', '017.gif', 'alegre')");
  @mysql_query("INSERT INTO smilies VALUES (':flo:', '018.gif', 'flor')");
  @mysql_query("INSERT INTO smilies VALUES (':tri:', '019.gif', 'triste')");
  @mysql_query("INSERT INTO smilies VALUES (':ocu:', '020.gif', 'oculos')");
  @mysql_query("INSERT INTO smilies VALUES (':est:', '021.gif', 'estrela')");
  @mysql_query("INSERT INTO smilies VALUES (':sor:', '022.gif', 'sorriso')");
  @mysql_query("INSERT INTO smilies VALUES (':lin:', '023.gif', 'lingua')");
  @mysql_query("INSERT INTO smilies VALUES (':olh:', '024.gif', 'olhando')");
  mysql_close($conexao);
  
  $resultado = "<p align=left><font color=#FF0000><strong>INSTALA&Ccedil;&Atilde;O CONCLU&Iacute;DA:</strong><br>
  Todas as tabelas foram adicionadas com sucesso!<br>
  Nome de usu&aacute;rio e senha foram configurados!<br>
  Instala&ccedil;&atilde;o bem sucedida!</font></p>
  <p align=left><font color=#FF0000><strong>OBSERVA&Ccedil;&Atilde;O!</strong><br>
  Para sua seguran&ccedil;a, apague o arquivo instalar.php do servidor</font></p>
  <p align=left><font color=#FF0000><br>
  </font> <a href=mural.php>Clique aqui para entrar no mural</a><br>
  <a href=admin.php>Clique aqui para entrar na administra&ccedil;&atilde;o do 
  mural</a></p>";
}
else{
  $resultado = "<font color=\"#FF0000\"><strong>INSTRU&Ccedil;&Otilde;ES:</strong></font><br>
          Preencha todos os campos com informa&ccedil;&otilde;es do seu banco 
          de dados Mysql.<br>
          Caso n&atilde;o saiba as informa&ccedil;&otilde;es, pe&ccedil;a para 
          o administrador de sua hospedagem.<br>
          Ap&oacute;s preencher corretamente todos os campos, clique no bot&atilde;o 
          PROSSEGUIR.<br>
          Obs: O arquivo \"config.php\" precisa estar com permiss&atilde;o (chmod) 
          666.<br></p>
          <form action=\"instalar.php?acao=instalar&etapa=1\" method=\"post\">
          <table width=\"100%\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\" class=\"tabela\">
          <tr><td width=\"46%\">Nome do host do mysql:</td>
          <td width=\"54%\"><input name=\"host\" type=\"text\" class=\"campos2\"value=\"$host\" size=\"30\"></td>
          </tr><tr><td>Usu&aacute;rio do mysql:</td>
          <td><input name=\"usuario\" type=\"text\" class=\"campos2\" value=\"$usuario\" size=\"30\"></td>
          </tr><tr><td>Senha do mysql:</td>
          <td><input name=\"senha\" type=\"password\" class=\"campos2\" value=\"$senha\" size=\"30\"></td>
          </tr><tr><td>Nome do banco de dados:</td>
          <td><input name=\"banco\" type=\"text\" class=\"campos2\" value=\"$banco\" size=\"30\"></td>
          </tr><tr><td>Quantidade de recados por p&aacute;gina:</td>
          <td><input name=\"exibido\" type=\"text\" class=\"campos2\" value=\"$total_reg\" size=\"30\"></td>
          </tr><tr><td>Tempo para nova mensagem:</td>
          <td><input name=\"tempo_cookie\" type=\"text\" class=\"campos2\" value=\"$tempo_cookie\" size=\"30\"></td>
          </tr><tr><td>Idioma do mural:</td>
          <td><input name=\"idioma\" type=\"text\" class=\"campos2\" value=\"$idioma\" size=\"30\"></td>
          </tr><tr><td> <div align=\"left\">Template:<br>
          </div></td>
            <td><input name=\"template\" type=\"text\" class=\"campos2\" id=\"template\" value=\"$template\" size=\"30\"></td>
          </tr>
          <tr>
            <td colspan=\"2\"><div align=\"center\">
              <br>
              <input name=\"Submit\" type=\"submit\" class=\"botao\" value=\"PROSSEGUIR\">
            </div></td>
          </tr>
          </table>
          <div align=\"center\"></div></form>";
}
echo "<title>$idioma_titulo - Instala��o</title>
<link href=\"templates/default/mural.css\" rel=\"stylesheet\" type=\"text/css\">
<body>
<table width=\"488\" border=\"0\" align=\"center\" cellpadding=\"6\" cellspacing=\"0\" class=\"tabela\">
  <tr> 
    <td width=\"118\"><div align=\"center\"><b><img src=\"imagens/instalar.gif\" width=\"118\" height=\"110\"></b></div></td>
    <td width=\"361\"><b><font color=\"#FF0000\" size=\"4\">INSTALA&Ccedil;&Atilde;O DO MURAL</font></b></td>
  </tr>
  <tr> 
    <td colspan=\"2\"><div align=\"justify\">$resultado</div></td>
  </tr>
</table>";
?>