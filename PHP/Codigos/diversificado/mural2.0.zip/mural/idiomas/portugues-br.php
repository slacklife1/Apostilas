<?
#######################################################################
#                           MURAL DE RECADOS                          # 
#                                v 2.0                                #
#                   Script criado e testado por Inter4u               #
#                     Eldon Pinheiro - Brumado - BA                   #
#          Esse script � gratuito e pode ser usado livremente         #
#             Pe�o que deixe o meu link de email no final             #
#          Para relatar bugs e novidades, favor contactar-me          #
#                       inter4u@inter4u.com.br                        #
#                        eldon@intermix.com.br                        #
#######################################################################

######################## PORTUGU�S BRASILEIRO #########################

############################### MURAL #################################
$idioma_titulo         = 'Mural';
$idioma_enviar         = 'Enviar Mensagem';
$idioma_versao         = 'Vers�o';
$idioma_nome           = 'Nome';
$idioma_para           = 'Para';
$idioma_email          = 'Email';
$idioma_mensagem       = 'Mensagem';
$idioma_caracteres     = 'Ainda restam';
$idioma_caracteres2    = 'caracteres';
$idioma_total          = 'Total de Recados';
$idioma_controle       = 'Controle';
$idioma_codigo         = 'C�digos do Mural';
$idioma_enviar_email   = 'Envie um E-Mail';
$idioma_ajuda          = 'Ajuda do Mural';
$idioma_admin          = 'Administra��o';
$idioma_post_mensagem  = 'Deixe sua Mensagem';
$idioma_back_mural     = 'Voltar para o Mural';
$idioma_mostrando      = 'Mostrando';
$idioma_de             = 'de';
$idioma_pagina         = 'p�ginas';
############################### LOGIN #################################
$idioma_tit_login      = 'Administra��o do Mural';
$idioma_usuario_login  = 'Usu�rio';
$idioma_senha_login    = 'Senha';
$idioma_entrar_login   = 'Entrar na Administra��o';
############################### ADMIN #################################
$idioma_tit_admin      = 'Administra��o do Mural de Recados';
$idioma_opcao_admin    = 'Selecione a op��o desejada';
$idioma_editar_admin   = 'Editar mensagens';
$idioma_excluir3_admin = 'Excluir todas as mensagens';
$idioma_mudar_admin    = 'Mudar Senha';
$idioma_sair_admin     = 'Sair';
$idioma_acao_excluir   = 'Deseja realmente excluir todas as mensagens?';
$idioma_sim_excluir    = 'Sim';
$idioma_nao_excluir    = 'N�o';
$idioma_sucesso_admin  = 'Mensagens exclu�das com sucesso!';
$idioma_op_des_admin   = 'Selecione a op��o desejada';
$idioma_editar_admin   = 'Editar';
$idioma_browser_admin  = 'Browser';
$idioma_ip_admin       = 'IP';
$idioma_excluir2_admin = 'Excluir outras';
$idioma_alter_admin    = 'Altera��o de Nome de Usu�rio e Senha';
$idioma_enviar_admin   = 'Enviar';
$idioma_alter_sucess   = 'Nome de Usu�rio e Senha alterados com sucesso!';
$idioma_filtro_sucess  = 'Filtro adicionado com sucesso!';
$idioma_filtro_admin   = 'Adicionar Filtros';
$idioma_filtro_del     = 'Excluir Filtros';
$idioma_env_filtro     = 'Adicionar Filtro';
$idioma_sem_filtro     = 'Nenhum Filtro Encontrado';
$idioma_del_sel_admin  = 'Excluir Selecionadas';
$idioma_edicao_admin   = 'Edi��o de Post';
$idioma_edicao_sucess  = 'Mensagem Editada com Sucesso';
$idioma_edicao_outras  = 'Editar Outras?';
$idioma_censurada      = 'Palavra Censurada';
$idioma_geren_filtro   = 'Gerenciar Filtros';
$idioma_substituir     = 'Substituir Por';
############################### AJUDA #################################
$idioma_ajuda_titulo   = 'Ajuda - C�digos';
$idioma_ajuda_tit      = 'C&oacute;digos que poder&atilde;o ser<br> usados no Mural';
$idioma_ajuda_end      = 'Endere�os';
$idioma_ajuda_ou       = 'ou';
$idioma_fechar         = 'Fechar';
$idioma_sublinhado     = 'Sublinhado';
$idioma_italico        = 'It�lico';
$idioma_negrito        = 'Negrito';
############################### ERROS #################################
$idioma_nao_encontrada = 'Nenhuma mensagem encontrada';
$idioma_nome_vazio     = 'O campo nome est� vazio';
$idioma_para_vazio     = 'Remeta para algu�m';
$idioma_email_errado   = 'Preencha o email corretamente';
$idioma_msg_vazia      = 'Preencha alguma coisa na mensagem';
$idioma_inserir_dados  = 'Erro ao inserir dados no Banco de Dados';
$idioma_selecio_dados  = 'Erro ao selecionar Banco de Dados';
$idioma_conectar       = 'N�o foi poss�vel conectar ao Banco de Dados';
$idioma_selecionar     = 'N�o foi poss�vel selecionar o Banco de Dados';
$idioma_erro_login     = 'Nome de Usu�rio ou Senha Inv�lidos';
############################## SMILIES ################################
$idioma_smilie_01      = 'Anjo';
$idioma_smilie_02      = 'Nervoso';
$idioma_smilie_03      = 'Cachorro';
$idioma_smilie_04      = 'Cora��o Partido';
$idioma_smilie_05      = 'Bolo';
$idioma_smilie_06      = 'Enjoado';
$idioma_smilie_07      = 'Chorando';
$idioma_smilie_08      = 'T�mido';
$idioma_smilie_09      = 'Cora��o';
$idioma_smilie_10      = 'Beijo';
$idioma_smilie_11      = 'Lua';
$idioma_smilie_12      = 'Msn';
$idioma_smilie_13      = 'M�sica';
$idioma_smilie_14      = 'Espantado';
$idioma_smilie_15      = 'Telefone';
$idioma_smilie_16      = 'Presente';
$idioma_smilie_17      = 'Feliz';
$idioma_smilie_18      = 'Flor';
$idioma_smilie_19      = 'Triste';
$idioma_smilie_20      = 'Playboy';
$idioma_smilie_21      = 'Estrela';
$idioma_smilie_22      = 'Sorriso';
$idioma_smilie_23      = 'L�ngua';
$idioma_smilie_24      = 'Piscando';
#######################################################################
?>