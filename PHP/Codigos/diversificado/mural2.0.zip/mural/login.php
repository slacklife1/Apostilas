<?
// Cabe�alho
#################################################
require("biblioteca/fasttemplate.php");
require("config.php");
require("idiomas/${idioma}.php");
require("funcoes.php");
$mural = new FastTemplate('templates/'.$template.'/');
$mural-> define (array('pagina' => 'login.htm'));
$mural->assign('{Titulo}', $idioma_titulo);
$mural->assign('{Copyright}', $copyright);
$mural->assign('{Css}','templates/'.$template.'/');
// Inicio
#################################################
$mural->assign('{Erro}', '');
$mural->assign('{IdiomaTituloAdmin}', $idioma_tit_login);
$mural->assign('{IdiomaUsuario}', $idioma_usuario_login);
$mural->assign('{IdiomaSenha}', $idioma_senha_login);
$mural->assign('{IdiomaEntrar}', $idioma_entrar_login);
if ($HTTP_GET_VARS['acao'] == "logar"){
   conecta();
   $sql = mysql_query("SELECT * FROM usuario");
   while ($resultado = mysql_fetch_array($sql)){
      $usuario = $resultado['usuario'];
	  $senha   = $resultado['senha'];
   }
   if ($HTTP_POST_VARS['usuario'] == $usuario AND $HTTP_POST_VARS['senha'] == $senha){
       setcookie("usuario", $usuario);
       setcookie("senha", $senha);
       header ("Location: admin.php");
       mysql_close($conexao);
   }
   else{
      $mural->assign('{Erro}', $idioma_erro_login);
   }
}
$mural->parse('OUTPUT','pagina');
$mural->FastPrint('OUTPUT');
?>