<?
$host             = 'localhost';
$usuario          = 'root';
$senha            = '';
$banco            = 'mural';
$total_reg        = '8';
$idioma           = 'portugues-br';
$v_mural          = '2.0';
$tempo_cookie     = '1';
$template         = 'default';
$corFundoTabela01 = 'CCCCCC';
$corFundoTabela02 = 'EEEEEE';
?>
