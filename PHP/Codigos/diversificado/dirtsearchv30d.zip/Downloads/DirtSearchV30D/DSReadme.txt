#               -------------
#                 DirtSearch 
#               -------------
#               Search Engine
#
#         File: Readme.txt
#  Description: Text Documentation
#       Author: Robert Sammons
#        Email: rsammons@dirtdobber.net
#          Web: http://www.dirtdobber.net/
#      Version: 3.0
#
# Copyright 1999, 2000 DirtDobber.Net  All Rights Reserved.
#

TABLE OF CONTENTS

I.	Introduction and Copyright information
	A. 	Copyright information
	B.	About DirtSearch
	C.	System Requirements
II.	Initial Installation
	A.	Moving the files to your server
	B.	Running the Setup.php3 script
	C.	Importing existing categories and links from DirtSearch 2.0
	D.  	Importing links from Links 2.0 (flatfile)
III.	Administration Features
	A.	Changing variables set during Setup.php3 run
	B.	Manually changing variable files
	C.	Managing categories
	D.	Managing websites
		1. 	Searching websites
		2. 	Validating websites
		3. 	Modifying websites
		4.	Deleting or deactivating websites
		5.	Adding a review or detail section
	E.	E-mail manager
IV.	User Features
	A.	Adding websites
	B.	Searching websites	
	C.	Modifying websites
	D.	Voting for websites
	E.	Adding comments
	F.	Mailing lists
	G.	Webmail (features explained for upcoming release)
V.	Problems
VI.	Future Plans



I.	INTRODUCTION
----------------------------------------------------
	Thanks for your interest in DirtSearch 3.0D.  I have spent a fair amount of 
time developing this set of scripts and hope that it is of use to you as a site owner or 
webmaster.  If you have any problems, comments, questions, requests, etc., do not
hesitiate to contact me at dirtsearch@dirtdobber.net


A.	COPYRIGHT NOTICE:
----------------------------------------------------
This script is being offered as SHAREWARE.  It may be used and
modified free of charge for personal, non-profit and academic 
use under the following conditions:

    1. All copyright notices, and headers remain intact and
       unmodified in the source.
    2. The 'Powered by: DirtSearch...' text
       remains/is placed on each template page or page the engine creates.
    3. The text is linked to:
            http://www.dirtdobber.net/scripts/
    4. The URL where the script is being used is registered via e-mail:
            Send an e-mail with your NAME (first and last), the URL of the website DirtSearch is 
	    installed on, and your e-mail address to register@dirtdobber.net
    5. The mail footers within the program where mail is sent is left in place if you use mail functions.

Use outside of these conditions requires a registration fee of $200 US.

Commercial use must register the script for a one time fee of $200 US.

Commercial use is considered ANY site which has a purpose of making money
including but not limited to: Licensed businesses and corporations, 
Sites which sell or advertise the sale of banner space, sites which
participate in click through or affiliate programs, sites which charge
membership fees or other fees at their website, sites which sell items
or services at their website.

With registration you receive 4 hours of customization to the scripts 
for your site 3 months of email tech support, free upgrades
within the version number, and discounts on other products/add ons. This
is the minimum you will receive.  With paid registration, you also do not 
have to display the link back to DirtDobber.Net, however all file headers 
and copyright information must remain in place.  Registration is good for
one domain/IP only.

You may pay by check online, or using the address on the registration page.  
You will receive notification by e-mail when your check has cleared if you
mail a check.  Hopefully I'll add credit card support soon.

Selling the code for this program, or a program derived from DirtSearch without 
prior written consent is expressly forbidden. Similarly, redistributing
this program, or a program derived from DirtSearch, over the Internet, CD-Rom 
or any other medium is expressly forbidden without prior written consent. 
By using this program you agree to indemnify DirtDobber.Net 
from any liability, and you agree to the terms stated above.

Please do not take credit for this script. 

B.	ABOUT THE SCRIPTS
----------------------------------------------------
DirtSearch is a web search engine running on various database platforms and 
integrating using PHP as the front end.  Currently support has been tested for 
MySQL only.  There are many administrative functions as well as user functions 
built into DirtSearch, and some add-ins in development to allow use of webmail 
on your site as well as banner rotations built into the search engine (and will 
display banners depending on search results).

C.	SYSTEM REQUIREMENTS
----------------------------------------------------
DirtSearch requires the following:

    * PHP3 module installed on your web server (preferably built into the apache module).
    * Database access (MySQL has been tested, but should support mSQL, ODBC, 
	and PostgreSQL without modification.  If you run into problems on any of 
	these databases, please let me know the nature of the problem).
    * FTP access to your account.

II.	INSTALLATION
----------------------------------------------------

This will give you a brief overview of installation from the time of download

A.	MOVING FILES TO YOUR SERVER
----------------------------------------------------

1. After unzipping the file, you should have the dirtsearch.php3 and dirtsearch.php3.bak
	 files in the main directory.  These files should be placed OUTSIDE of a 
	directory viewable by the web server.  If you are unable to do this, please 
	place it in a password protected directory.  chmod the dirtsearch.php3 and 
	dirtsearch.php3.bak files as 777 (read/write/execute).

2. All the script files need to be in the same directory.  You may name this folder 
	anything you wish (Search, Dirtsearch, etc.).  You just need to change the
	var.php3 file to point to the dirtsearch.php3 file.  Please use the direct PATH 
	to this file, and not a URL.

3. Place all administration files into and administration folder under the folder containing 
	your search script files.  This folder should be password protected, however, 
	I have added mySQL authentication within the administration files to help those 
	who don't have password protection on directories have some protection.  You may 
	either use that and not password protect the directory, or use both.  Change the 
	admininc.php3 file variables for the location of dirtsearch.php3 and dirtsearch.php3.bak

4. Place all template files into a template directory.  I keep mine within the administration 
	folder, however, it doesn't really matter where you put them.  You could put 
	them on the webserver, off the webserver, or wherever.  As long as you can 
	call them with a path.  NOTE:  If you wish to use the text editor in DirtSearch 3.0, 
	you will have to chmod your template files as 777 (read/write/execute) so that the
	engine has writes to update your files.

B.	RUNNING THE SETUP.PHP3 FILE
----------------------------------------------------

To setup the dirtsearch.php3 file with the correct variables (a list is below with some 
examples), you will need to run the setup.php3 file.  Simply fill in the forms, and 
the required information will be written to the dirtsearch.php3 file for you and the 
tables will be created in the database.  Please remember, if you are not upgrading 
from DirtSearch V.2 or importing links and categories from Links 2.0, then you must add 
at least one category and one website in that category before you can use the engine 
without getting errors.

Database Type: Select one of the items in the list.  If your host does not support any of 
these databases, you will need to find a host that does.  For best support, I recommend
finding one which uses mySQL as the other database platforms at this time have not been
tested.

Database Hostname:  Typically this is 'localhost' however, if this does not work, contact
your system administrator for the host name you should use

Database Name: The name of the database to connect to.

Database User Name: Username to use to login to the database specified above

Database Password: Password to use with the username above

Administrative E-mail: Your e-mail address

Administrative Username:  This is the username (can be anything up to 15 characters) you will 
use to login to the admin area

Administrative Password:  This is the password (up to 15 characters) you will use to login to
the admin area.

Search Engine URL (Root URL): FULL URL, http://www.myhost.com/dirtsearch for example.  Do NOT include the last /

Administrative Area URL:  FULL URL, http://www.myhost.com/dsadmin for example.  Do NOT include the last /

Templates Path: PATH, NOT URL to the templates area, /home/dirtdobber/www/dstemplate for example.  Do NOT include the last /

Style Sheet: URL and filename of the stylesheet to use for the search engine (if any)

Site Title:  Your site's title (can be anything)

Meta Description: Meta description for the pages in the search engine

Meta Keywords: Meta keywords for the pages in the search engine

Background Color: Color to use for the background (will be overwritten by the CSS if one is specified and it is different)

Background Image: Background image to use on the templates

Minimum Votes:  (numeric) number of votes required to be listed as popular

Minimum Visits: (numeric) number of visits required to be popular

Days to keep in "newest":  (numeric) Number of days to keep a site in the newest of the 3 new site categories

Days to keep in "newer":  (numeric) Number of days to keep a site in the 2nd group of the 3 new site categories

Days to keep in "new":  (numeric) Number of days to keep a site in the oldest of the 3 new site categories

Require someone to be in a category to add a link: Select Yes or No

List Subcategories as links under main categories:  Select Yes or No (Yes will do the yahoo style clickable subcats, No will put the category description under the main categories)

Number of Links to display:  Default number of results to display on pages (search, rookie, vet, or category pages)

Max links to display on high flyers:  Number of links to place in each of the two categories on the high flyers page.

Admin must validate new websites:  Select Yes or No (Yes will require you to validate a link before it's searchable)

Admin must validate modified websites:  Select Yes or No (Yes will require you to validate a modified link before it's searchable)

Number of columns on index page:  (numeric) Number of columns to display the categories in

DirtSearch password encryption string:  The string to use to encrypt user passwords to the database.  NOTE:  Do NOT change this once users are added.  Doing so will make their passwords invalid.



C.	IMPORTING EXISTING CATEGORIES AND LINKS FROM DIRTSEARCH V.2.
----------------------------------------------------
If you are upgrading from a previous version, you will notice within the install folder, a couple of extra scripts.
These scripts are the catxfer and linkxfer php3 scripts.  These will pull your existing categories and links into
the new tables and formats.  NOTE: RUN CATXFER FIRST, THEN LINKXFER!
  

D.	IMPORTING CATEGORIES AND LINKS FROM Links 2.0
----------------------------------------------------
If you are running Links 2.0 and would like to import your data from that into DirtSearch
Version 3.0, please run spin.php3 (Version 3.0....do not use the old version) and it will 
import those for you.

III.	ADMINISTRATIVE FEATURES
----------------------------------------------------
This section will briefly explain administrative features available on DirtSearch 3.0

A.	DROPPING OLD TABLES
----------------------------------------------------

NOTE:  You will NOT need to do this if you are not upgrading from a previous version 
of DirtSearch.

NOTE:  PLEASE DO NOT DROP TABLES UNTIL YOU HAVE VERIFIED THAT THE 
LINK IMPORTS WORKED CORRECTLY FOR BOTH CATEGORIES AND WEBSITES.

Once you have upgraded to DirtSearch V3.0 from an older version of DirtSearch, you 
will need to drop the old database tables (AFTER IMPORTING AND VERIFYING 
THE IMPORT WORKED CORRECTLY).  To do this, run the tabledrop.php3 file 
included in the install folder.

B.	CHANGING VARIABLES SET DURING THE RUN OF SETUP.PHP3
----------------------------------------------------
By going to the admin section and logging in as a DirtSearch administrator, you may 
change the system variables simply by selecting that option on the form and then 
filling the new variables.  The change to the search engine should be immediate.

C.	MANUALLY CHANGING VARIABLES AND DIRTSEARCH.PHP3
----------------------------------------------------
Alternatively, you may alter the dirtsearch.php3 file manually.  Please use caution in 
doing this.


D.	MANAGING CATEGORIES
----------------------------------------------------
You may add and delete categories from the admin section.  To add a category, log in and choose the option to add
categories.  Enter in the information.  If you wish to add a subcategory, simply select a category to place the new
category under.  For example, if you want to create the category football under sports, type in football, and select
sports from the dropdown list.  DO NOT USE THE / FOR SUBCATEGORIES ANYMORE.

NEW:  If you fill in the URL field of a category with a URL (including http://) the category will simply link to that
URL instead of containing links under it.

To delete a category, select the one you wish to delete from the list and hit the button.  The category will
be deleted from the database.

E.	MANAGING WEBSITES
----------------------------------------------------

1.	SEARCHING WEBSITES
----------------------------------------------------
From the admin area, you may search for websites using many fields.  This is also how the new validate and deactivate listings 
works.  To validate or deactivate, you simply change the priority of the website.  Anything less than zero will not be
searchable to the public.  The higher the priority, the higher it will be listed in the public searches.

2.	VALIDATING WEBSITES
----------------------------------------------------
To validate a website, you may do the search for sites at priority less than 0, and then either "activate" them by pressing
the button, or modify them and select the priority level.

3. 	MODIFYING WEBSITES
----------------------------------------------------
To modify sites, do a search and press the modify button on the site you wish to modify.

4.	DELETING OR DEACTIVATING WEBSITES
----------------------------------------------------
Deleting a site deletes the entire listing from the database.  Deactivating it puts it back to unsearchable but allows you
to reactivate it at a later date without having to enter all information back into the database again.

5.	ADDING A REVIEW OR DETAIL SECTION
----------------------------------------------------
COMING SOON!  This is requiring a little more work than I thought.  Should be out next week with a simple replacement of the
admin.php3 file.

E.	E-MAIL MANAGER
----------------------------------------------------
You may e-mail people on your mailing list, or your link owners.  All link owners receive mail unless they delete their site from
the database.  Anyone who signs up on your site with a website or a vote, or whatever else (webmail coming soon) will be entered
into the mailing list.  They have a simple URL to visit to remove their e-mail from the list if they do not wish to receive mail.


IV.	USER FEATURES
----------------------------------------------------

A.	ADDING WEBSITES
----------------------------------------------------
For a user to add a website, he simply fills in the form.  The username and password will be used later if he/she wishes to remove
or modify the website listing.  The username and password can also be used for voting and adding comments/webmail (coming soon)

Once a user has added a website, he/she may add more websites under the same username and modify any or all of them from one location
and from one username.

B.	SEARCHING WEBSITES
----------------------------------------------------
The user simply types in the search terms they wish to find.  Terms are listed by priority, hits, rating, votes.

C.	MODIFYING WEBSITES
----------------------------------------------------
To modify a website the user simply logs in to their account and chooses the website to modify.

D.	VOTING FOR WEBSITES
----------------------------------------------------
To vote for a website, the user must enter his username and password.  This prevents duplicate voting.  If the user does not 
have a username/password, he can create one from the login screen.

E.	ADDING COMMENTS
----------------------------------------------------
COMING SOON!

F.	MAILING LISTS
----------------------------------------------------
Right now the user is automatically entered into the mailing lists by adding their site or adding a username.  I should soon have the
script up which will allow them to add their e-mail address without creating an entire account.

G.	WEBMAIL
----------------------------------------------------
This should be released within the next month as a module for DirtSearch.

H.	BANNER ROTATION PROGRAM
----------------------------------------------------
This should be released within the next month as a module for DirtSearch or a standalone program.

V.	PROBLEMS
----------------------------------------------------
Due to the time constraints and some personal/family problems, I did this in very little 
time.  I do hope I've fixed some of the problems with VET and ROOKIE sites, and I hope 
I've made setup and administration easier.  I also hope that database queries were sped 
up increasing the speed of your site loading.  However, there is the chance (probability) 
that some errors got through the crack.  Hopefully nothing major, but there's the chance.  
If you find problems, please notify me at dirtsearch@dirtdobber.net  You may also sign up 
for the DirtSearch maling list to get information quicker, or post questions or suggestions 
on the forum.  Also, if you have features you would like to see, or if you would like
 help modifying DirtSearch to match your needs, please let me know and I'll try to 
help out where I can.


VI.	FUTURE PLANS
----------------------------------------------------
Within the next month I hope to have the following features added or implemented:

Static or dynamic options (build pages, or run the engine from the database
Capabilities for Oracle, Oracle8, Microsoft SQL Server, and flatfile (text) databases
Testing for mSQL, PostgreSQL, and ODBC databases completed
Language translation packages (Template files in other languages) for download
Banner rotation program which integrates with the search engine to display ads which
	 relate to the search term or category in question or runs standalone
Web based e-mail completed with integration into DirtSearch tables
Spidering ability (spidering an added site to find others on the same web server and 
	adding them to the database)

There are other features which I plan to add down the road, however, these will be the 
first.

Good Luck and have fun!

Robert Sammons
rsammons@dirtdobber.net