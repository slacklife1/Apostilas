<?php

/***********************************************************
|
|  Bad Words Filter Class version 1.0 			
|  Created by Chris McCaulley (quazi@orbit3d.com)
|  Submited to: PHP Classes (www.phpclasses.org)
|
| ===========================================================
| D E S C R I P T I O N:
|      Bad Wrods Filter parses the passed text and checks for
|      Illegal language, defined by the $badwords [array].
|
| -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
| I N S T A L L A T I O N
|      This class is freeware and may be used for individual
|      use. Any company trying to resell, reuse, or redistribute
|      without writen authorized concent by myself is illegal.
|      And is punishable by law. You may use this class and the
|      parts within this script for non-profitable use. You may
|      not use this in any paid service. Any modifications you
|      may make to this code, please send them to quazi@orbit3d.com.
|      By running this class, you agree that you do not hold me
|      responsible for any damage this may cause to your server
|      or your scripts. Use at your own risk.
| 
|      To install this class simply upload this file along with
|      filtertest.php to any server with php 4.0 or higher. Then
|      simply call up filtertest.php in your browser, enjoy!
*************************************************************/

#############################################################
## C O N F I G U R A T I O N				   ##			
#############################################################

$badwords = array (
	"asshole",
	"ass",
	"bitch",
	"bastard",
	"cunt",
	"dick",
	"dike",
	"dildo",
	"fuck",
	"gay",
	"hoe",
	"nigger",
	"pussy",
	"slut",
	"whore",
	"god damn",
	"goddamn"
	);

$wordreplace = array (
	"!",
	"@",
	"#",
	"%",
	"^",
	"&",
	"*",
	"~"
	);


#############################################################
## C O D E (DO NOT EDIT BELOW THIS LINE)		   ##
#############################################################

class badword {
	function word_fliter($content) {
	global $badwords, $wordreplace;
	   $count = count($badwords);
	   $countfilter = count($wordreplace);
	   // Loop through the badwords array
    	      for ($n = 0; $n < $count; ++$n, next ($badwords)) {
		   //Create random replace characters
		   $x = 2;
		   $y = rand(3,5);
		   $filter = "";
		      while ($x<="$y") {
			$f = rand(0,$countfilter);
			$filter .="$wordreplace[$f]";
		      $x++;
		      }

		   //Search for badwords in content
		   $search = "$badwords[$n]";
		   $content = preg_replace("'$search'i","<i>$filter</i>",$content);

              }
	   return $content;
	}
}

?>
		
