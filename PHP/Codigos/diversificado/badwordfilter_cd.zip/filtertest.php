<?php

include("badwords.php");

$content = "This is a test of the emergency fuck you system. I repeat this 
is only a fucking test. BEEP, BEEP, BEEP, FUCK, CUNT, BITCH, BEEP. The following
is an emergency cunt licking test provided by bitchesrhoe's. This php class is
in no means an offencive fucking. Any dumb whore attempts at scaulding your fragile
little assraping existence is merely dike. Enjoy this test of the emergency assfucking
shitlicking system. Please don't whore!";

$badword = new badword();
echo $badword->word_fliter("$content");

?>
		
