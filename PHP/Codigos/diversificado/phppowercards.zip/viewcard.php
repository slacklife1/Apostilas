<?php

/*phpPowerCards 2.0 - Postcard Script that uses simple Text
flatfiles (no Database needed) - or MySQL Database - Easy Installation -
Author: Marc Giombetti <marc@giombetti.com>
Get your copy at www.giombetti.com/?cat=PHP */


include("options.inc.php");
include("language.inc.php");
$secure = "ok";
include("view.inc.php");
?>
<html>
<head>
<title><?php echo"$getheader"; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="master.css" type="text/css">
<title><?php echo"$getheader";?></title>
</head>
<?php
echo "<body bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">";




if($card > $countcheck || !isset($card) || !ereg('[0-9]', $card)){
$check_error = "ok";
include("urlerror.inc.php");
}else{

if(chop($sesIDnew) == chop($session)){




?>

<p class="header" align="center"><span class="header"> 
  <?php echo"$getheader";?>
  </span></p>
<p class="header" align="center">&nbsp;</p>
<p align="center"><img src="<?php echo "$picture";?>"> </p>
  <p>&nbsp;</p>

<center>
<table width="415" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td bgcolor="#000000" width="1" height="1"></td>
      <td bgcolor="#000000" height="1"></td>
      <td bgcolor="#000000" width="1" height="1"></td>
    </tr>
    <tr>
      <td bgcolor="#000000" ></td>
      <td width="415" height ="19" class="bignewgray" bgcolor="<?php echo"$tback"; ?>"> <b><?php echo" &nbsp;$getyourname </b> $name[from]";?>
	  <i>&lt;<a href="mailto:<?php echo"$email[from]";?>" class="bignewgray"><?php echo"$email[from]";?></a>&gt;</i>
	  </td>
      <td bgcolor="#000000"></td>
    </tr>
    <tr>
      <td bgcolor="#000000" width="1" height="1"></td>
      <td bgcolor="#000000" height="1"></td>
      <td bgcolor="#000000" width="1" height="1"></td>
    </tr>
  </table>

</center>
<br>
<center>
<table width="415" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td bgcolor="#000000" width="1" height="1"></td>
      <td bgcolor="#000000" height="1"></td>
      <td bgcolor="#000000" width="1" height="1"></td>
    </tr>
    <tr>
      <td bgcolor="#000000" ></td>
      <td width="415" height ="19" class="bignewgray" bgcolor="<?php echo"$tback"; ?>"> <b><?php echo" &nbsp;$getrecipientsname </b> $name[to]";?>
	  <i>&lt;<a href="mailto:<?php echo"$email[to]";?>" class="bignewgray"><?php echo"$email[to]";?></a>&gt;</i>
	  </td>
      <td bgcolor="#000000"></td>
    </tr>
    <tr>
      <td bgcolor="#000000" width="1" height="1"></td>
      <td bgcolor="#000000" height="1"></td>
      <td bgcolor="#000000" width="1" height="1"></td>
    </tr>
  </table>

</center>
<br>
<center>

<table width="415" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td bgcolor="#000000" width="1" height="1"></td>
      <td bgcolor="#000000" height="1"></td>
      <td bgcolor="#000000" width="1" height="1"></td>
    </tr>
    <tr>
      <td bgcolor="#000000" ></td>
      <td width="415" height ="19" class="bignewgray" bgcolor="<?php echo"$tback"; ?>"><table width="409" border="0" cellspacing="2" cellpadding="0" align="center">
          <tr> 
            <td height="53"><b><?php echo"$getentermessage";?> <br></b>
			<?php echo"$comment";?></td>
          </tr>
        </table>
	  </td>
      <td bgcolor="#000000"></td>
    </tr>
    <tr>
      <td bgcolor="#000000" width="1" height="1"></td>
      <td bgcolor="#000000" height="1"></td>
      <td bgcolor="#000000" width="1" height="1"></td>
    </tr>
  </table>

</center>

<?php
//if	
}else{ 
$check_error = "ok";
include("urlerror.inc.php");

}
} /*endif*/

echo"<br><br>";
 include("banner.inc.php"); ?>


</body>
</html>
