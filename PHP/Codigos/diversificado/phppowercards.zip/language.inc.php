<?php
/*phpPowerCards 2.0 - Postcard Script that uses simple Text
flatfiles (no Database needed) - or MySQL Database - Easy Installation -
Author: Marc Giombetti <marc@giombetti.com>
Get your copy at www.giombetti.com/?cat=PHP */


/*
english = english
lux = luxemburgish
ger = german
dutch = dutch
francais = french
slovak = slovak
*/

//please chose your language
$language = "english";

include("language/$language.inc.php")

?>
