<?php
/*phpPowerCards 2.0 - Postcard Script that uses simple Text
flatfiles (no Database needed) - or MySQL Database - Easy Installation -
Author: Marc Giombetti <marc@giombetti.com>
Get your copy at www.giombetti.com/?cat=PHP */

//script url to receive cards
$script_location = "http://www.giombetti.com/site/html/cards/viewcard.php?card=";

//please chodse which database to use (txt - mysql)
//$database = "txt";
$database = "mysql";

//password for the administration
$adminpassword = "123456";

//number of rows to show ass default in the admin panel
$stsel = "25";

//color definitions
$bgcolor = "#cc9966";
$text = "#333333";
$link = "#333333";
$vlink = "#333333";
$alink = "#333333";

//css files
$cssfile = "master.css";

//table backgrounf
$tback = "#cccccc";

//error color
$errorcolor = "red";

//session id data
$sessionID = md5(uniqid(rand()));

//bg color for tables in the admin script
$hadcolor = "#999999";
$adcolor = "#E7CEB6";


/*data file
->only for the txt usage

ATTENTION:this is not secute - because everyone who knows this file will be able to access it. I would recommend you to put the file outside the wwwroot, ass example
/home/sites/www.giombetti.com/postcard.txt"
*/ 
$file = "postcard.txt";


/*for mysql usage only */
$dbhost = "localhost";
$user = "root";
$password = "";
$db = "giombetti";
$table = "powercards";


?>