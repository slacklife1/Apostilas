<?php
/*phpPowerCards 2.0 - Postcard Script that uses simple Text
flatfiles (no Database needed) - or MySQL Database - Easy Installation -
Author: Marc Giombetti <marc@giombetti.com>
Get your copy at www.giombetti.com/?cat=PHP */

//file for inserting data to the text file

include("language.inc.php");
$fp = fopen("$file","a");

//checking email syntax
if(!ereg('.@.{5}', $email[to]) || !ereg('.@.{5}', $email[from])){$allow = "ok"; include("emailerror.inc.php");}else{$check = "ok";}


if(isset($check)){
$comment = eregi_replace("�"," ",$comment);
$comment = eregi_replace("\n","<br>",htmlentities($comment));




fputs($fp, $email[to]. "��" .$email[from]. "��" .$name[to]. "��" .$name[from]. "��" .$picture. "��" .$comment. "��" .$sessionID. "\n");

$cardnumber = count(file($file));



//sending mail
include("language/$language.mail.inc.php");
mail("$name[to] <$email[to]>", "$mailsubject", $mailmessage,
     "From:$name[from] <$email[from]>\nReply-To: $email[from]\nX-Mailer: PHP/" . phpversion());

$sendokcheck = "ok";
include("sendok.inc.php");

fclose($fp);
//to be continued...


} /*endif*/
?>