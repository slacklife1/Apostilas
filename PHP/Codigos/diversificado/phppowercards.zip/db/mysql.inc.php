<?php
/*phpPowerCards 2.0 - Postcard Script that uses simple Text
flatfiles (no Database needed) - or MySQL Database - Easy Installation -
Author: Marc Giombetti <marc@giombetti.com>
Get your copy at www.giombetti.com/?cat=PHP */

//file for inserting data to the mysql database
include("language.inc.php");

$conn = mysql_connect($dbhost,$user,$password);
if($conn){

	//selecting table
$conn = mysql_select_db($db, $conn);

//checking email syntax
if(!ereg('.@.{5}', $email[to]) || !ereg('.@.{5}', $email[from])){$allow = "ok"; include("emailerror.inc.php");}else{$check = "ok";}


if(isset($check)){
$comment = eregi_replace("�"," ",$comment);
$comment = eregi_replace("\n","<br>",htmlentities($comment));

 }/*endif*/

//writing data into the table
$insert = "INSERT into $table (emailto, emailfrom, nameto, namefrom, picture, comment, sessionID, seencard)";
$insert .="VALUES ('$email[to]', '$email[from]', '$name[to]', '$name[from]', '$picture',";
$insert .="'$comment', '$sessionID', 'false')";

$result = mysql_query($insert);
if($result){
	$cardnumber =mysql_insert_id();

//sending mail
include("language/$language.mail.inc.php");
mail("$name[to] <$email[to]>", "$mailsubject", $mailmessage,
     "From:$name[from] <$email[from]>\nReply-To: $email[from]\nX-Mailer: PHP/" . phpversion());

$sendokcheck = "ok";
include("sendok.inc.php");

}else{
	echo"<p>".mysql_error($conn);



 }/*endif*/
}/*endif*/
mysql_close();



?>