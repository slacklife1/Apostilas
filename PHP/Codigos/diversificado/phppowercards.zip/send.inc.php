<?php /*phpPowerCards 2.0 - Postcard Script that uses simple Text
flatfiles (no Database needed) - or MySQL Database - Easy Installation -
Author: Marc Giombetti <marc@giombetti.com>
Get your copy at www.giombetti.com/?cat=PHP */
include("options.inc.php");
include("language.inc.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title>Sending Postcard...</title>
</head>
<?php
echo "<body bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">";





$readfile = file("$file");

/* des werter gin fir folgendes benotzt
$email[to]         -> who the mail is send to
$email[from]       -> from who the mail came it
$name[to]          -> the name of the person who will get the mail
$name[from]        -> the name of the person who send the mail
$picture           -> the full picture-url
$comment           -> comment
$session[ID]       -> a simple sessionID

niewen values
$cardnumber        -> the card number
*/

if($email[to] && $email[from] && $name[to] && $name[from] && $picture && $comment){

include("db/$database.inc.php");


}else{

//if the data is not properly filled out
echo "<center>"; 
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="50">&nbsp;</td>
    <td width="415" height="50"> 
      <table width="415" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td bgcolor="#000000" width="1" height="1"></td>
          <td bgcolor="#000000" height="1"></td>
          <td bgcolor="#000000" width="1" height="1"></td>
        </tr>
        <tr> 
          <td bgcolor="#000000" ></td>
          <td width="415" height ="19" class="bignewgray" bgcolor="<?php echo"$errorcolor"; ?>"> 
            <table width="409" border="0" cellspacing="2" cellpadding="0" align="center">
              <tr> 
                <td height="53"><b> 
                  <?php echo"$fielderror";?><br>
                  <br>
                  </b> 
                  <?php
if(empty($name[to])){echo "$needrecipientsname<br><br>";}
if(empty($email[to])){echo "$needrecipientsmail<br><br>";}
if(empty($name[from])){echo "$needyourname<br><br>";}
if(empty($email[from])){echo "$needyourmail<br><br>";}
if(empty($comment)){echo "$needentermessage<br><br>";}
?><center><b><a href="javascript:history.back(-1)" class="bignewgray"><?php echo"$back"; ?><a></b></center>
</td><br>
              </tr>
            </table>
          </td>
          <td bgcolor="#000000"></td>
        </tr>
        <tr> 
          <td bgcolor="#000000" width="1" height="1"></td>
          <td bgcolor="#000000" height="1"></td>
          <td bgcolor="#000000" width="1" height="1"></td>
        </tr>
      </table>
    </td>
    <td height="50">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

<?php
echo "</center>";
}
?>

</body>
</html>
