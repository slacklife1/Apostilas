<?php
//luxemburgish language file

//postcard sending interface
$header = "{Verschicken Sie ihre Postkarte:}";
$yourname = "Dein Name:";
$yourmail = "Deine Email:";
$recipientsname = "Der Name des Empf�nders:";
$recipientsmail = "Die Email des Empf�ngers:";
$entermessage = "Ihre Nachricht:"; 								
$needyourname = "- Sie haben vergessen Ihren Namen einzugeben!";		 			$needyourmail = "- Sie haben vergessen Ihre Email einzugeben!";		 				
$needrecipientsname = "- Sie haben vergessen den Namen des Empf�ngers einzugeben!";
$needrecipientsmail = "- Sie haben vergessen die Email des Empf�ngers einzugeben!";
$needentermessage = "- Es wurde keine Nachricht eingegeben"; 								
$syntaxemail[to] = "- Die Email des Empf�ngers ist nicht g�ltig  -  <empf�nger@seinhost.de>";		
$syntaxemail[from] = "- Ihre Email ist nicht g�ltigt - <du@deinhost.de>";
$back = "Zur�ck";


//getting data//
$getheader = "{deine Postkarte:}";
$getyourname = "Von:";
$getrecipientsname = "F�r:";
$getentermessage = "Machricht:";


//errors
$picerror = "Es wurde kein Bild ausgew�hlt";
$fielderror = "Folgende Fehler sind aufgetreten:";
$nosession = "- Sie haben keine Zugangsber�chtigung zu dieser Karte <br><br> �berpr�fen sie die Adresse die Ihnen zugesand wurde, sonst bekommen sie keinen Zugang";



/*don't change anything above this line */
$header = htmlentities("$header");
$yourname = htmlentities("$yourname");
$yourmail = htmlentities("$yourmail");
$recipientsname = htmlentities("$recipientsname");							$recipientsmail = htmlentities("$recipientsmail");							$entermessage = htmlentities("$entermessage");
$needyourname = htmlentities("$needyourname");
$needyourmail = htmlentities("$needyourmail");
$needrecipientsname = htmlentities("$needrecipientsname");
$needrecipientsmail = htmlentities("$needrecipientsmail");
$needentermessage = htmlentities("$needentermessage");
$syntaxemail[to] = htmlentities("$syntaxemail[to]");
$syntaxemail[from] = htmlentities("$syntaxemail[from]");	
$back = htmlentities("$back");	
$getheader = htmlentities("$getheader");
$getyourname = htmlentities("$getyourname");
$getrecipientsname = htmlentities("$getrecipientsname");
$getentermessage = htmlentities("$getentermessage");
$picerror = htmlentities("$picerror");
$fielderror = htmlentities("$fielderror");
?>