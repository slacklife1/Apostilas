<?php
//english language file

//postcard sending interface
$header = "{Send your postcard:}";
$yourname = "Your name:";
$yourmail = "Your email";
$recipientsname = "The recipient's name:";
$recipientsmail = "The recipient's email:";
$entermessage = "Your message:"; 								
$needyourname = "- You need to enter your name!";		 					
$needyourmail = "- You need to enter your email!";		 				
$needrecipientsname = "- You need to enter the recipient's name!";
$needrecipientsmail = "- You need to enter the recipient's email!";
$needentermessage = "- You need to enter a message"; 								
$syntaxemail[to] = "- The recipient's email is incorrect  -  <he@hishost.com>";		
$syntaxemail[from] = "- Your email is incorrect  -  <you@yourhost.com>";
$back = "Back";

//getting data//
$getheader = "{Your postcard:}";
$getyourname = "From:";
$getrecipientsname = "To:";
$getentermessage = "Message:";


//errors
$picerror = "No picture was choosen";
$fielderror = "The following error(s) occured:";
$nosession = "- You are not allowed to see this card!! <br><br> Check the URL that was sent to you in the email, and retry";



/*don't change anything above this line */
$header = htmlentities("$header");
$yourname = htmlentities("$yourname");
$yourmail = htmlentities("$yourmail");
$recipientsname = htmlentities("$recipientsname");							$recipientsmail = htmlentities("$recipientsmail");							$entermessage = htmlentities("$entermessage");
$needyourname = htmlentities("$needyourname");
$needyourmail = htmlentities("$needyourmail");
$needrecipientsname = htmlentities("$needrecipientsname");
$needrecipientsmail = htmlentities("$needrecipientsmail");
$needentermessage = htmlentities("$needentermessage");
$syntaxemail[to] = htmlentities("$syntaxemail[to]");
$syntaxemail[from] = htmlentities("$syntaxemail[from]");	
$back = htmlentities("$back");	
$getheader = htmlentities("$getheader");
$getyourname = htmlentities("$getyourname");
$getrecipientsname = htmlentities("$getrecipientsname");
$getentermessage = htmlentities("$getentermessage");
$picerror = htmlentities("$picerror");
$fielderror = htmlentities("$fielderror");
?>