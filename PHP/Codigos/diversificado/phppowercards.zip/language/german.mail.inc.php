<?php
//luxemburgish language file - for sending emails

$mailok = "Ihre Postkarte wurde versandt:";
$mailnumber = "- Ihre Postkarte wurde verschickt, mir der Nummer:";
$mailsubject = "Sie bekamen eine Postkarte Yuhuuu";
$mailmessage = "Sie bekamen eine Postkarte von $name[from] -> $email[from] <-

Um Ihre Postkarte abzuholen surfen sie zu:
$script_location$cardnumber&session=$sessionID

(Wenn Sie diesen Link nicht anklicken k�nnen, kopieren sie ihn mit Ctrl+V
und pasten Sie ihn mit Ctrl+V wieder in den Browser)


Surfen sie auch zu
PHPdev - Free Scripts - phpPowerCards 1.0
http://www.giombetti.com";

?>