<?php
//luxemburgish language file - for sending emails

$mailok = "Den Postcard gouf versch�ckt:";
$mailnumber = "- Deng Postcard gouf versch�ckt mat der Nummer:";
$mailsubject = "Du krus eng Giombetti.com Postcard - Yuhuu!!!";
$mailmessage = "Du krus eng Postcard fum $name[from] -> $email[from] <-

Fir deng Postcard kucken ze goen surf op:
$script_location$cardnumber&session=$sessionID
andems de op D'Adress clicks!

(Wann dat net geet dann kopeier des URL mat Ctrl+C,
an paste se dann mat Ctrl+V rem an den Browser)


Surf och lanscht op:
SMS - Witzer -Fotoen - LGE News - An nach vill m�i!  
http://www.giombetti.com";

?>