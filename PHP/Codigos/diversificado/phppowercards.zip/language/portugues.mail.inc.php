<?php
//brazilian portuguese language file - for sending emails -- a tradu��o do e-mail

$mailok = "Seu cart�o foi enviado:";
$mailnumber = "- Seu cart�o foi enviado, usando o n�mero:";
$mailsubject = "Voc� recebeu um cart�o virtual";
$mailmessage = "Ol�, $name[from] -> $email[from] <- enviou um cart�o para voc�.

Para ver seu cart�o, aponte o seu navegador (clique) no link abaixo:
$script_location$cardnumber&session=$sessionID

(Caso voc� n�o consiga clicar no link acima, copie (CTRL+C) e cole (CRTL+V)
na barra de endere�os do seu navegador.


Visite:
PHPdev - phpPowerCards - e tenha um script como este em sua p�gina (p�gina em ingl�s)
http://www.giombetti.com";

?>