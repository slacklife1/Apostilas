<?php
//brazilian portuguese language file (arquivo de tradu��o para o Portugu�s)

//postcard sending interface
$header = "{Envie um cart�o:}";
$yourname = "Seu nome:";
$yourmail = "Seu e-mail";
$recipientsname = "Nome do destinat�rio:";
$recipientsmail = "E-mail do destinat�rio:";
$entermessage = "Mensagem:"; 								
$needyourname = "- por favor, informe seu nome.";		 					
$needyourmail = "- por favor, informe seu e-mail";		 				
$needrecipientsname = "- por favor, informe o nome do destinat�rio";
$needrecipientsmail = "- por favor, informe o e-mail do destinat�rio";
$needentermessage = "- seu cart�o precisa de uma mensagem"; 								
$syntaxemail[to] = "- o e-mail do destinat�rio parece estar incorreto  -  <nome@viavilas.com.br>";		
$syntaxemail[from] = "- seu e-mail parece estar incorreto   -  <voce@viavilas.com.br>";
$back = "voltar";

//getting data//
$getheader = "{Seu cart�o:}";
$getyourname = "De:";
$getrecipientsname = "Para:";
$getentermessage = "Mensagem:";


//errors
$picerror = "Voc� n�o escolheu uma imagem";
$fielderror = "O(s) seguinte(s) erro(s) ocorrerram:";
$nosession = "- Voc� n�o tem autoriza��o para ver este cart�o. <br><br> Verifique o e-mail que lhe foi enviado, e tente novamente.";



/*don't change anything above this line */
$header = htmlentities("$header");
$yourname = htmlentities("$yourname");
$yourmail = htmlentities("$yourmail");
$recipientsname = htmlentities("$recipientsname");							$recipientsmail = htmlentities("$recipientsmail");							$entermessage = htmlentities("$entermessage");
$needyourname = htmlentities("$needyourname");
$needyourmail = htmlentities("$needyourmail");
$needrecipientsname = htmlentities("$needrecipientsname");
$needrecipientsmail = htmlentities("$needrecipientsmail");
$needentermessage = htmlentities("$needentermessage");
$syntaxemail[to] = htmlentities("$syntaxemail[to]");
$syntaxemail[from] = htmlentities("$syntaxemail[from]");	
$back = htmlentities("$back");	
$getheader = htmlentities("$getheader");
$getyourname = htmlentities("$getyourname");
$getrecipientsname = htmlentities("$getrecipientsname");
$getentermessage = htmlentities("$getentermessage");
$picerror = htmlentities("$picerror");
$fielderror = htmlentities("$fielderror");
?>