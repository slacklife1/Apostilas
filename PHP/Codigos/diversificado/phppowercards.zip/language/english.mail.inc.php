<?php
//english language file - for sending emails

$mailok = "Your postcard was sent:";
$mailnumber = "- Your postcard was sent, using the number:";
$mailsubject = "Got a postcard Hit Yaaa!!!!!";
$mailmessage = "Got a postcard from $name[from] -> $email[from] <-

To see your card surf to:
$script_location$cardnumber&session=$sessionID

(If you cant click on the link, copy the URL with CTRL+C
and paste it into your browser using CTRL+V)


Surf to:
PHPdev - phpPowerCards - get this script at  
http://www.giombetti.com";

?>