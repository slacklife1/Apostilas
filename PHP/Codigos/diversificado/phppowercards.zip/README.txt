phpPowerCards - 2.10

Release: A bug in the admin panel was fixed!
 
Autor: Marc Giombetti <marc@giombetti.com>
www.giombetti.com/?cat=PHP

This Package Includes:
/language/english.inc.php	/english language file
/language/english.mail.inc.php	/english language file
/language/german.inc.php	/german language file
/language/german.mail.inc.php	/german language file
/language/lux.inc.php           /luxemburgish language file
/language/lux.mail.inc.php      /luxemburgish language file

/db/txt.inc.php			/the file to use the script with text files
/db/mysql.inc.php		/the file to use the script with mySQL

postcards.sql			/the file with the sql table

index.php			//the main file
viewcard.php			//the file to see the postcards
		
options.inc.php			//edit this file
language.inc.php		//chose the language
view.inc.php			//script file
emailerror.inc.php		//script file
send.inc.php			//script file
urlerror.inc.php		//script file
senok.inc.php			//script file
banner.inc.php			//an optional banner file
postcard.txt   			//file where the data is stored
admin.php			//the default admin file
admin.inc.php			//an admin include file
master.css			//a css styleseet file
README.txt			//this file



******************INSTALL NOTES******************
Export all the files in one directory.

->if you use the mySQL version of the script, please create the table using this structure
->postcards.sql - you can use a script like phpMyAdmin to setup this table, or you can do so
->using telnet or even PHP

Edit the following files:
options.inc.php    -->choose the colors,the kind of database to use (txt/MySQL) etc
language.inc.php   -->chose your language
		   -->english, german, and luxemburgish are the standard
		      languages included in this script!
		      if you want another language translate the language file and the
		      mail-language file (this files are in the /language directory)
banner.inc.php     -->if you want to, you can add a banner to this file
master.css         -->I would not recommend you to edit this file
postcard.txt       -->CHmode this file to 777 - you can put this file outside the wwwroot,
		      but it isn't nessescary - when you do so, edit the $file variable in 
		      the options.inc.php



NOW:
Upload all the files to your Webserver and don't forget to chmode the postcard.txt to 777
After uploading call this script in your browser:
as example:
http://www.yourdomain.com/cards/index.php?picture=http://www.picurl.com/pics/01.jpg
To check the stats of your cardsystem, call this URL
http://www.yourdomain.com/cards/admin.php
in your browser. (Note that the default admin password is: 123456)



->enjoy


If there are any Problems, RTFM, surf to www.giombetti.com/?cat=PHP and take a look
in the forums or contact me at marc@giombetti.com.

###### Personalised Scripts ######
If you want a modified version of
any of my scripts, please mail me
and i'll write it for a small fee
###### Personalised Scripts ######


