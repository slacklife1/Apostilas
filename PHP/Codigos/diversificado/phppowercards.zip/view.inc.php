<?php
/*phpPowerCards 2.0 - Postcard Script that uses simple Text
flatfiles (no Database needed) - or MySQL Database - Easy Installation -
Author: Marc Giombetti <marc@giombetti.com>
Get your copy at www.giombetti.com/?cat=PHP */

if($secure == "ok"){

//$card >value to select which card to choose
include("options.inc.php");

if($database == "txt"){
	$d0 = file("$file");
	$data = explode ("��", $d0[$card]);
	$countcheck = count(file("$file"));

 }
elseif($database == "mysql")
 {
	$conn = mysql_connect($dbhost,$user,$password);
	if($conn){

	//selecting table
$conn = mysql_select_db($db, $conn);

$read = "SELECT emailto,emailfrom,nameto,namefrom,picture,comment,sessionID from $table WHERE id = '$card'";
$predata = mysql_query($read);

$count = "SELECT ID FROM $table ORDER BY id DESC";
$countcheck = mysql_query($count);
$countcheck = mysql_fetch_array($countcheck);
$countcheck = $countcheck[ID];

$seencard = "UPDATE $table SET seencard = 'true' WHERE id = $card";
if(!isset($mode)){mysql_query($seencard);}
if($predata){

	$data = mysql_fetch_row($predata);
	if($data){}
	}else{
		echo "<p>".mysql_error($conn); }
	

 }/*endif*/
}/*endif*/


//converting arrays to old variables
$email[to] = $data[0];
$email[from] = $data[1];
$name[to] = $data[2];
$name[from] = $data[3];
$picture = $data[4];
$comment = stripslashes($data[5]);
$sesIDnew = $data[6];
}/*endif */
?>