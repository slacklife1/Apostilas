<?php /*phpPowerCards 2.0 - Postcard Script that uses simple Text
flatfiles (no Database needed) - or MySQL Database - Easy Installation -
Author: Marc Giombetti <marc@giombetti.com>
Get your copy at www.giombetti.com/?cat=PHP */



include("language.inc.php");
include("options.inc.php");
/*do not edit between here */

$crypted_admin = base64_encode("$adminpassword");

if($pass == "$adminpassword" || $cpass == "$crypted_admin"){
	$checkvalue = "$pass";
	$checkvalue2 = "$crypted_admin";
	include("admin.inc.php");
}else{

?>

<html>
<head>
<title>phpPowerCards 2.0 - Webadmin Interface</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="<?php echo "$cssfile"; ?>" type="text/css">
</head>
<?php
echo "<body bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">";
?>
<body bgcolor="#FFFFFF" text="#000000">
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr> 
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td>
      <table width="250" border="1" cellspacing="0" cellpadding="0" bordercolor="#666666">
        <tr> 
          <td bgcolor="<?php echo"$hadcolor"; ?>"><font face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#FFFFFF" class="bignewgray">phpPowerCards 
            2.0 - Login</font></b></font></td>
        </tr>
        <tr> 
          <td height="22" bgcolor="<?php echo"$adcolor"; ?>"> 
            <form name="form1" method="post" action="<?php echo"$PHP_SELF"; ?>">
              <div align="center"><br>
                <br>
                <input type="password" name="pass">
                <input type="submit" name="Submit2" value="Login">
                <br>
                <br>
                <br>
              </div>
            </form>
          </td>
        </tr>
        <tr> 
          <td bgcolor="<?php echo"$hadcolor"; ?>"><font face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#FFFFFF" class="bignewgray">Please 
            enter your Password</font></b></font></td>
        </tr>
      </table>
    </td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td width="250">&nbsp; </td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>

<?php 
			  include("banner.inc.php");
}
?>