<?php
/*phpPowerCards 2.0 - Postcard Script that uses simple Text
flatfiles (no Database needed) - or MySQL Database - Easy Installation -
Author: Marc Giombetti <marc@giombetti.com>
Get your copy at www.giombetti.com/?cat=PHP */

include("language.inc.php");
include("options.inc.php");
?>
<html>
<head>
<title><?php echo"$header";?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="<?php echo "$cssfile"; ?>" type="text/css">
</head>
<?php
if($send == "true"){
include("send.inc.php");
}else{
echo "<body bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">";
;?>

<div align="center" class="header"> 
  <p class="header"><span class="header"> 
    <?php echo"$header";?>
    </span></p>
  <p class="header">&nbsp;</p>
  <p> <?php if(isset($picture)){ ?> <img src="<?php echo "$picture";?>"> <?php }else{echo "<br><b>$picerror</b><br><br>";}?> </p>
  <form name="form" method="post" action="<?php echo"$PHP_SELF?send=true"; ?>">
    <p> 
      <input type="hidden" name="picture" value="<?php echo "$picture";?>">
    </p>
    <table border=0 cellspacing=0 cellpadding=5 align="center" width="430" >
      <tr> 
        <td> 
          <div align="left"> <span class="bignewgray"> 
            <?php echo"$recipientsname";?>
            </span><br>
            <input type="TEXT" size="25" name="name[to]">
          </div>
        </td>
        <td> 
          <div align="left"><span class="bignewgray">
            <?php echo"$recipientsmail";?>
            </span><br>
            <input type="TEXT" size="25" name="email[to]">
          </div>
        </td>
      </tr>
    </table>
    <br>
    <center>
      <table border=0 cellspacing=0 cellpadding=5 width="430" >
        <tr> 
          <td> <span class="bignewgray"> 
            <?php echo"$yourname";?>
            </span><br>
            <input type="TEXT" size="25" name="name[from]">
          </td>
          <td> <span class="bignewgray"> 
            <?php echo"$yourmail";?>
            </span><br>
            <input type="TEXT" size="25" name="email[from]">
          </td>
        </tr>
      </table>
    </center>
    <br>
    <center>
      <table border=0 cellspacing=0 cellpadding=5 >
        <tr> 
          <td> 
            <p class="bignewgray"> 
              <?php echo"$entermessage";?>
            </p>
            <p align="center"> 
              <textarea name="comment" wrap="VIRTUAL" cols="50" rows="9"></textarea>
              <br>
            </p>
            <p>&nbsp;</p>
          </td>
        </tr>
      </table>
      <table width="100" border="0" cellspacing="5" cellpadding="5">
        <tr> 
          <td> 
            <input type="SUBMIT" name="L&ouml;schen" value="Send">
          </td>
          <td> 
            <input type="RESET" name="reset" value="L&ouml;schen">
          </td>
        </tr>
      </table>
      <br>
    </center>
    <p>&nbsp; </p>
    </form>
  
</div>
<?php } 
include("banner.inc.php");
?>
</body>
</html>
