<?php
/*phpPowerCards 2.0 - Postcard Script that uses simple Text
flatfiles (no Database needed) - or MySQL Database - Easy Installation -
Author: Marc Giombetti <marc@giombetti.com>
Get your copy at www.giombetti.com/?cat=PHP */
include("language.inc.php");
include("options.inc.php");

if(isset($pass)){$cpass = base64_encode($pass);}
if($checkvalue == "$adminpassword" || $cpass == "$crypted_admin"){



/*do not edit between here */


?>
<html>
<head>
<title>phpPowerCards 2.0 - Webadmin Interface</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="<?php echo "$cssfile"; ?>" type="text/css">
</head>
<?php
echo "<body bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">";
?>
<p class="header"></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="70%" class="header" height="3">{phpPowerCards 2.0 - Webadmin Interface 


      <?if($database == "mysql")
		{echo"(mySQL-Version)}";
	 }elseif($database == "txt")
		 {echo"(TXT-Version)}";
}
?>
    </td>
    <td width="20%" height="3">&nbsp;</td>
    <td width="40" height="3"> 
      <div align="right"><a href="<?php echo"$PHP_SELF?pass=logout"; ?>" class="bignewgray">[Logout]</a></div>
    </td>
  </tr>
</table>
<?php
if($database == "mysql"){ 
/*starting mysql content */ ?>
<br>
<br>
</span>
<table width="95%" border="0" cellspacing="1" cellpadding="1" align="center"> 
<tr> 
    <td width="35" class="bignewgray" bgcolor="<?php echo"$hadcolor";?>">
      <div align="center"><b>[ID]</b></div>
    </td>
	 <td width="10" class="bignewgray" bgcolor="<?php echo"$hadcolor";?>">
      <div align="center"><b>[?]</b></div>
    </td>
    <td class="bignewgray" bgcolor="<?php echo"$hadcolor"; ?>">
      <div align="center"><b>[Sender's name]</b></div>
    </td>
    <td class="bignewgray" bgcolor="<?php echo"$hadcolor"; ?>">
      <div align="center"><b>[Receipient's name]</b></div>
    </td>
    <td class="bignewgray" bgcolor="<?php echo"$hadcolor"; ?>">
      <div align="center"><b>[Comment]</b></div>
    </td>
    <td class="bignewgray" bgcolor="<?php echo"$hadcolor"; ?>">
      <div align="center"><b>[Options]</b></div>
    </td>
  </tr>

<?php
if($database == "mysql"){
	$conn = mysql_connect($dbhost,$user,$password);
if($conn){
	//selecting table
	$conn = mysql_select_db($db, $conn);

//how many rows are there???
$rows = "SELECT * from $table";
$rows = mysql_query($rows);
$rows = mysql_num_rows($rows);


//checks how many rows to show
if(!isset($selection)){
	$sel = "$stsel";
}else{
	if($selection == "ALL"){
	$sel = "$rows";
	}else{
	$sel = "$selection";
	}
}
for($i=$rows-$show;$i > $rows - $sel -$show ;$i--){
$selectionquery = "SELECT * FROM $table WHERE ID = $i";
$values = mysql_query($selectionquery);
if($values)
	{
$data = mysql_fetch_row($values);
if(empty($data)){break;}
if($data[8] == "true"){
$seencolor = "#33CC33";
}else{
$seencolor = "#CC0000";
}
/*and here */

	} ?>
<tr> 
    <td width="35" class="bignewgray" bgcolor="<?php echo"$adcolor"; ?>"> 
      <div align="center"><?php echo"$data[0]"; ?></div>
    </td>
		 <td width="10" class="bignewgray" bgcolor="<?php echo"$seencolor";?>">
      <div align="center"><b></b></div>
    </td>
    <td width="170" class="bignewgray" bgcolor="<?php echo"$adcolor"; ?>"> 
      <div align="center"><?php echo"<a href=\"mailto:$data[2]\" class=\"bignewgray\">$data[4]</a>"; ?></div>
    </td>
    <td width="170" class="bignewgray" bgcolor="<?php echo"$adcolor"; ?>"> 
      <div align="center"><?php echo"<a href=\"mailto:$data[1]\" class=\"bignewgray\">$data[3]</a>"; ?></div>
    </td>
    <td class="bignewgray" bgcolor="<?php echo"$adcolor"; ?>"> 
      <div align="center"><?php echo"$data[6]"; ?></div>
    </td>
    <td  width="130" class="bignewgray" bgcolor="<?php echo"$adcolor"; ?>"> 
      <div align="center"><?php echo"<a href=\"$script_location$data[0]&mode=admin&session=$data[7]\" class=\"bignewgray\"  target=\"_blank\">See this card</a>";?></div>
    </td>
  </tr>
<?php
  }/*endif */
 }/*endif */
 	echo"</table><br>";

	echo"<p class=\"bignewgray\"><center><b>[?]</b> Shows if the receipient has already seen the card (green = seen / red = not seen)</center></p>";
	echo""
	?>
<b>
<?php 
	if($selection !== "ALL" && $rows > $sel){ ?>
		<br><center><p class="bignewgray">Page</b> 
<?php	
		echo"<a href=\"$PHP_SELF?cpass=$cpass&selection=$sel&show=0\" class=\"bignewgray\">[1]</a>";
	$lx = 1;


for($x=0;$x <= $rows;){
	//the page number
	$x = $lx++;
	//the show value
	$x=$x+$sel;
	$mult = $lx*$sel;
//

//$show = $x-1 ;
$show = $lx*$sel-$sel;
if($mult-$sel < $rows){
	echo "<a href=\"$PHP_SELF?cpass=$cpass&selection=$sel&show=$show\" class=\"bignewgray\">[$lx]</a>";
}
}

?>
</p><br></p></center>
		

<?php } ?>
<center><form name="form" method="post" action="<?php echo"$PHP_SELF"; ?>">
  <div align="center">
    <select name="selection">
      <option value="<?php echo"$stsel"; ?>" selected>Show Cards</option>
      <option value="10">10</option>
      <option value="25">25</option>
      <option value="50">50</option>
      <option value="ALL">ALL</option>
    </select>
   <input type="hidden" name="pass" value="<?php echo"$pass"; ?>">
    <input type="submit" name="GO" value="GO">
  </div>
</form></center></b>
<?php
}/*endif - connection*/

include("banner.inc.php");

//ending mysql content

//chosing content
}elseif($database == "txt"){?>
	<?php /*starting php content */ ?>

<?php
	//opening txt files
$datapre = file($file);
$rows = count($datapre);

//checks how many rows to show

if(!isset($selection)){
	$sel = "$stsel";
}else{
	if($selection == "ALL"){
	$sel = "$rows";
	}else{
	$sel = "$selection";
	}
}
?>
	<br>
<br>
</span>
<table width="95%" border="0" cellspacing="1" cellpadding="1" align="center"> 
<tr> 
    <td width="35" class="bignewgray" bgcolor="<?php echo"$hadcolor";?>">
      <div align="center"><b>[ID]</b></div>
    </td>
    <td class="bignewgray" bgcolor="<?php echo"$hadcolor"; ?>">
      <div align="center"><b>[Sender's name]</b></div>
    </td>
    <td class="bignewgray" bgcolor="<?php echo"$hadcolor"; ?>">
      <div align="center"><b>[Receipient's name]</b></div>
    </td>
    <td class="bignewgray" bgcolor="<?php echo"$hadcolor"; ?>">
      <div align="center"><b>[Comment]</b></div>
    </td>
    <td class="bignewgray" bgcolor="<?php echo"$hadcolor"; ?>">
      <div align="center"><b>[Options]</b></div>
    </td>
  </tr>
<?php
//echo"$rows<br>";
	for($q=$rows-$show-1;$q >= $rows-$sel-$show;$q--){
	//for($q=$rows;$q = $q;$q--){
	$data = explode("��",$datapre[$q]);
	if(empty($data[6])){break;}
	
?>
<tr> 
    <td width="35" class="bignewgray" bgcolor="<?php echo"$adcolor"; ?>"> 
      <div align="center"><?php echo"$q"; ?></div>
    </td>

    <td width="170" class="bignewgray" bgcolor="<?php echo"$adcolor"; ?>"> 
      <div align="center"><?php echo"<a href=\"mailto:$data[1]\" class=\"bignewgray\">$data[3]</a>"; ?></div>
    </td>
    <td width="170" class="bignewgray" bgcolor="<?php echo"$adcolor"; ?>"> 
      <div align="center"><?php echo"<a href=\"mailto:$data[0]\" class=\"bignewgray\">$data[2]</a>"; ?></div>
    </td>
    <td class="bignewgray" bgcolor="<?php echo"$adcolor"; ?>"> 
      <div align="center"><?php echo"$data[5]"; ?></div>
    </td>
    <td  width="130" class="bignewgray" bgcolor="<?php echo"$adcolor"; ?>"> 
      <div align="center"><?php echo"<a href=\"$script_location$q&session=$data[6]\" class=\"bignewgray\"  target=\"_blank\">See this card</a>";?></div>
    </td>
  </tr>

<?php 
}
echo"</table>"; ?>



<br><br><center><form name="form" method="post" action="<?php echo"$PHP_SELF"; ?>">
  <div align="center">
    <select name="selection">
      <option value="<?php echo"$stsel"; ?>" selected>Show Cards</option>
      <option value="10">10</option>
      <option value="25">25</option>
      <option value="50">50</option>
      <option value="ALL">ALL</option>
    </select>
   <input type="hidden" name="pass" value="<?php echo"$pass"; ?>">
    <input type="submit" name="GO" value="GO">
  </div>
</form></center></b><br>
	<?php if($selection !== "ALL" && $rows > $sel){ ?>
	<center><p class="bignewgray"><b>Page</b>

<?php
		echo"<a href=\"$PHP_SELF?cpass=$cpass&selection=$sel&show=0\" class=\"bignewgray\">[1]</a>";

$lx = 1;
for($z=0;$z <= $rows;){	
$z = $lx++;
//the show value
	$z=$z+$sel;
	$mult = $lx*$sel;
	//
$show = $lx*$sel-$sel;
if($mult-$sel < $rows){
	echo "<a href=\"$PHP_SELF?cpass=$cpass&selection=$sel&show=$show\" class=\"bignewgray\">[$lx]</a>";
}
}
}
?>
</p>
<?php
	include("banner.inc.php");
 }//end else for txt content

}//check value to see the include site

?>


