<?php
/*phpPowerCards 1.0 - Postcard Script that uses simple Text
flatfiles (no Database needed) - Easy Installation -
Author: Marc Giombetti <marc@giombetti.com>
Get your copy at www.giombetti.com/?cat=PHP */

//put your banner between here
/*and here*/
 
 ?>
 <!-- please do not remove this comment -->
<center><script language='JavaScript' src='http://www.giombetti.com/dynamic/ads/adjs.php?clientID=11&withText=0'></script>
  <br>
  <br>
</div>
<span class="copyright"><a href="http://www.giombetti.com/?cat=PHP" class="copyright"> phpPowerCards 2.0 - Get your copy at www.giombetti.com</span>
</center>
 <!-- please do not remove this comment -->
 
