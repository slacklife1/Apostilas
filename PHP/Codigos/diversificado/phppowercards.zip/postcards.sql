# phpPowersCards 2.0
# http://www.giombetti.com/?cat=PHP
# Author: Marc Giombetti <marc@giombetti.com>
#
# --------------------------------------------------------


CREATE TABLE powercards (
   ID mediumint(9) NOT NULL auto_increment,
   emailto blob NOT NULL,
   emailfrom blob NOT NULL,
   nameto blob NOT NULL,
   namefrom blob NOT NULL,
   picture blob NOT NULL,
   comment mediumtext NOT NULL,
   sessionID blob NOT NULL,
   seencard blob NOT NULL,
   PRIMARY KEY (ID),
   UNIQUE ID (ID)
);

