<?php
	/*phpPowerCards 2.0 - Postcard Script that uses simple Text
flatfiles (no Database needed) - or MySQL Database - Easy Installation -
Author: Marc Giombetti <marc@giombetti.com>
Get your copy at www.giombetti.com/?cat=PHP */
	
	
	if($sendokcheck == "ok"){ ?>
<center>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="50">&nbsp;</td>
    <td width="415" height="50"> 
      <table width="415" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td bgcolor="#000000" width="1" height="1"></td>
          <td bgcolor="#000000" height="1"></td>
          <td bgcolor="#000000" width="1" height="1"></td>
        </tr>
        <tr> 
          <td bgcolor="#000000" ></td>
          <td width="415" height ="19" class="bignewgray" bgcolor="<?php echo"$tback"; ?>"> 
            <table width="409" border="0" cellspacing="2" cellpadding="0" align="center">
              <tr> 
                <td height="53"><b> 
                  <?php echo"$mailok";?><br>
                  <br>
                  </b> 
                  <?php echo"$mailnumber  $cardnumber";?>

	      </tr>
            </table>
          </td>
          <td bgcolor="#000000"></td>
        </tr>
        <tr> 
          <td bgcolor="#000000" width="1" height="1"></td>
          <td bgcolor="#000000" height="1"></td>
          <td bgcolor="#000000" width="1" height="1"></td>
        </tr>
      </table>
    </td>
    <td height="50">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</center>
<?php } ?>