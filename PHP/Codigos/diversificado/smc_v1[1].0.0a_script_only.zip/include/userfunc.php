<?

/*****************************************************
    Define your custom functions here
    Example:

function flee_on_low_hp($hp) {
    if ($hp < 200) mud_writeln('flee');
}

*****************************************************/

?>