<?php
/*************************************************************************************************

    phpAdManager 1.0
	Configuration Module
	Copyright 2003 Hamilton G Laughland
	
	Author: Hamilton G Laughland
	Website: http://www.laughland.biz
	
	This script is protected by New Zealand copyright law.
	
****************************************************************************************************/ 
$user = "";
$pass = "";
$host = "localhost";
$database = "admanager";

$user = "Hamilto_mysql";
$pass = "Islandphp1";
$host = "mysql2.neosophy.net";
$database = "Hamilto_admanager";

$adpass = "admin";  //Your admin password. 

/***** Do not change anything below this line *****************************************************/
$prefix = "adman_";

$banners = $prefix . "banners";
$stats = $prefix . "stats";

function dbconnect() {
global $host, $user, $pass, $database;
$db_bks = mysql_pconnect($host,$user,$pass);
if (!$db_bks) {
 echo "Login failed."; 
 exit;}
mysql_select_db($database);
}

function doquery($query) {
// $query = "select * from computer";
$result = mysql_query($query) or die(mysql_error());
return $result;
}

 function openfile($path){
  $file = '';
  $fp = fopen($path,'r');
  while(!feof($fp))
  $file .= fgets($fp,4098);
  return $file;
 }
 
 function domessage($message){
  $msg = "<tr><td align='center' class='message' colspan='4'>$message</td></tr></table>";
  echo $msg;
 }
  
$msg = "<table align='center' class='head' width='80%' border='1' cellspacing='0' cellpadding='2'>";
?>
