<?php 
session_start();
/*************************************************************************************************

    phpAdManager 1.0
	Administration Module
	Copyright 2003 Hamilton G Laughland
	
	Author: Hamilton G Laughland
	Website: http://www.laughland.biz
	
	This script is protected by New Zealand copyright law.
	
****************************************************************************************************/
include("templates/header.htm");
include("config.php");

if(!isset($adminuser)){
 if(!isset($action)){
  echo "<tr><td align='center' class='message'>Welcome to Ad Manager 1.0<br>";
  include("templates/login.htm");
  echo "</td></tr></table>";
 }else{
  if($adminpass != $adpass){
   echo "<tr><td align='center' class='message'>Welcome to Ad Manager 1.0<br>";
   include("templates/login.htm");
   echo "Invalid Password</td></tr></table>";
  }else{
   $adminuser = "yes";
   session_register('adminuser');
   $action = "loggedin";
  }
 }
}

if(isset($adminuser)){
 dbconnect();
 include('templates/menu.htm');

 if($action=="loggedin"){
  $message = "<tr><td align='center' class='message' colspan='4'>Welcome to Ad Manager 1.0<br>Use the menus above to navigate.</td></tr></table>";
  $msg = $message;
  echo $msg;
 }

 if($action == "add"){
  echo "</table>";
  $act = "insert";
  $imgrow = "<tr><td align='center' class='list' colspan='2'>add new banner</td></tr>";
  $radio = "&nbsp;off<input name='status' type='radio' value='0'>&nbsp;on<input name='status' type='radio' value='1' checked>";
  $adstyle = "&nbsp;image<input name='adtype' type='radio' value='1' checked>&nbsp;rich text / html <input name='adtype' type='radio' value='0'";
  $targetsel = "<option value=\"0\" selected>New Window</option>
   <option value=\"1\">Main Window</option>";  
  include("templates/add.htm");
 }

 if($action == "insert"){
  if($upimage != ""){
   $imgfile = "images/".$upimage_name;
   if(!move_uploaded_file($upimage, $imgfile)){
    domessage("Upload failed.");
    include("templates/footer.htm");
	end;
   }
   $fp = fopen($imgfile, 'r');
   $temp = fread($fp, filesize($imgfile));
   fclose($fp);
   //$temp = strip_tags($temp);
   $fp = fopen($imgfile, 'w');
   fwrite($fp, $temp);
   fclose($fp);
  }
  if(isset($imgfile)){$image = $imgfile;}
  if(!isset($imgfile)){$image = " ";}
  if(!isset($link)){$link = " ";}
  if(!isset($adtext)){$adtext = " ";}
 
  $query = "insert into adman_banners set id = '$id', adtype = '$adtype', link = '$link', image = '$image', adtext = '$adtext', level = '$level', alt = '$alt', status = '$status', target = '$target', name = '$adname'";
  $result = doquery($query);
  if($result != false)
    domessage("Item added to database");
  else
   domessage("Could not add item to database");
 }

 if($action == "edit"){
  echo "</table><br>";
  $query = "select * from $banners";
  $result = doquery($query);
  if(mysql_num_rows($result) != 0){
   while ($row = mysql_fetch_array($result)){
    $id = $row['id'];
    $image = $row['image'];
    $alt = $row['alt'];
    $adtype = $row['adtype'];
    $adtext = $row['adtext'];
    if($adtype == 1){
     $adimg = "<img src='$image' alt='$image'>";
    }else{
     $adimg = $adtext;
    }
	
    include("templates/list.htm");
   }
   echo "<br>";
  }else{
   $message = "<tr><td align='center' class='message' colspan='2'>No banners found.</td></tr>";
   $msg .= $message . "</table>";
   echo $msg;
  }
 } 

 if($action == "delete"){
  $query = "DELETE FROM $banners WHERE id = $id";
  $result = doquery($query);
  domessage("Item deleted");
 } 

 if($action == "item"){
  echo "</table><br>";
  $query = "select * from $banners WHERE id = $id";
  $result = doquery($query);
  $row = mysql_fetch_array($result);
  $id = $row['id'];
  $adtype = $row['adtype'];
  $image = $row['image'];
  $alt = $row['alt'];
  $link = $row['link'];
  $adtext = $row['adtext'];
  $status = $row['status'];
  $target = $row['target'];
  if(!isset($adtype) || $adtype == 1){
   $adstyle = "&nbsp;image<input name='adtype' type='radio' value='1' checked>&nbsp;text / html<input name='adtype' type='radio' value='0'>";
  }else{
   $adstyle = "&nbsp;image<input name='adtype' type='radio' value='1'>&nbsp;text / html<input name='adtype' type='radio' value='0' checked>";
  }
  if(!isset($status) || $status == 1){
   $radio = "&nbsp;off<input name='status' type='radio' value='0'>&nbsp;on<input name='status' type='radio' value='1' checked>";
  }else{
   $radio = "&nbsp;off<input name='status' type='radio' value='0' checked>&nbsp;on<input name='status' type='radio' value='1'>";
  }
  $act = "update";
  if($adtype == 1){
   $imgrow = "<tr><td align='center' class='list' colspan='2' height='84'><img border='0' src='$image'></td></tr>";
  }else{
   $imgrow = "<tr><td align='center' class='list' colspan='2' height='84'>$adtext</td></tr>";
  }
  if($target == "0"){
    $targetsel = "<option value=\"0\" selected>New Window</option>
	  <option value=\"1\">Main Window</option>";
  }else{
   $targetsel = "<option value=\"0\">New Window</option>
	  <option value=\"1\" selected>Main Window</option>";
  }
  include("templates/add.htm");
 }

 if($action == "update"){
  if($upimage != ""){
   $imgfile = "images/".$upimage_name;
   $image = $imgfile;
   if(!move_uploaded_file($upimage, $imgfile)){echo "Upload failed.";}
   $fp = fopen($imgfile, 'r');
   $temp = fread($fp, filesize($imgfile));
   fclose($fp);
   //$temp = strip_tags($temp);
   $fp = fopen($imgfile, 'w');
   fwrite($fp, $temp);
   fclose($fp);
  }
  if(!isset($image)){$image = " ";}
  if(!isset($link)){$link = " ";}
  if(!isset($adtext)){$adtext = " ";}
  $query = "update adman_banners set adtype = '$adtype', link = '$link', image = '$image', adtext = '$adtext', alt = '$alt', status = '$status', target = '$target', name = '$adname' where id = '$id'";
  $result = doquery($query);
  domessage("Item Updated");
 }

 if($action == "stats"){
  if(isset($adid)){
   $query = "select * from $banners where id = $adid";
   $result = doquery($query);
   $row = mysql_fetch_array($result);
   $image = $row['image'];
   $adtype = $row['adtype'];
   $adtext = $row['adtext'];
   $imgrow ="<table align='center' class='head' width='80%' border='1' cellspacing='0' cellpadding='2'>";
   if($adtype == 1){
    $imgrow .= "<tr><td align='center' class='list' colspan='7' height='84'><img border='0' src='$image'></td></tr></table>";
   }else{
    $imgrow .= "<tr><td align='center' class='list' colspan='7' height='84'>$adtext</td></tr></table>";
   }
  }
  include('stats.php');
 }
}
include("templates/footer.htm");
?>
