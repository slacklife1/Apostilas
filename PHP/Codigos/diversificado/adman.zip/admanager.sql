# phpMyAdmin SQL Dump
# version 2.5.4
# http://www.phpmyadmin.net
#
# Host: localhost:3306
# Generation Time: Nov 23, 2003 at 11:40 AM
# Server version: 4.0.16
# PHP Version: 4.3.4
# 
# Database : `admanager`
# 

# --------------------------------------------------------

#
# Table structure for table `adman_banners`
#

CREATE TABLE `adman_banners` (
  `id` int(11) NOT NULL auto_increment,
  `adtype` int(11) NOT NULL default '1',
  `link` varchar(50) default NULL,
  `image` varchar(50) default NULL,
  `adtext` longtext,
  `level` varchar(10) default NULL,
  `alt` varchar(255) default NULL,
  `status` int(11) NOT NULL default '1',
  `target` varchar(10) default NULL,
  `name` varchar(127) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=30 ;

# --------------------------------------------------------

#
# Table structure for table `adman_stats`
#

CREATE TABLE `adman_stats` (
  `id` int(11) NOT NULL default '0',
  `amdate` date NOT NULL default '0000-00-00',
  `displays` int(11) NOT NULL default '0',
  `clicks` int(11) NOT NULL default '0'
) TYPE=MyISAM;
