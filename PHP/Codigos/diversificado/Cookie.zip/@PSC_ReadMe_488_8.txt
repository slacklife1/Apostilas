Title: TXcounter v4.1
Description: TXcounter is a page counter based on cookies. Output is in the form of total and unique hits (for yesterday, today and overall) as well as graphs showing the relative hits per day. The busiest hour, and average hits are also calculated. Unique hits are tracked via cookies stored on the users computer.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=488&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
