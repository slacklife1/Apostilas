<?
#################################################################
# Cookie Counter v3.0											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################

//Time
$minute=(strftime("%M"));
$hour=(strftime("%H"));

//Date, Month, Year
$date=getdate();
$yday=$date['yday']; 
$mday=$date['mday'];
$mon=$date['mon']; 
$year=$date['year']; 

//Cookie check to determine uniqueness
if(isset($CookieValue)) 
{
 	 $unique=0;
}
else 
{	 
	 $unique=1;
	 $value="arbatrary value";
	 setcookie("CookieValue", "$value");
}

//The string to be appended to the hits.txt file
$hitdata=$hour."|".$minute."|".$yday."|".$mday."|".$mon."|".$year."|".$unique."[~]";

//Append the string
$fp=fopen("hits.txt", "aw");
fputs($fp,$hitdata,strlen($hitdata));
fclose ($fp);
?>


