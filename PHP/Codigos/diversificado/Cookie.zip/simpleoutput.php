<?
#################################################################
# Cookie Counter v3.0											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


//If you want to display the unique or combined hits then change the text between the quote marks in this variable:
$mode="combined";
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////




$fp=fopen("hits.txt","r");
$overallhitdata=fread($fp,filesize("hits.txt"));
fclose($fp);

$overallhitdata=explode("[~]",$overallhitdata);
$totalallhits=count($overallhitdata)-2;

if($mode=="combined")
{
    echo($totalallhits);
}
elseif($mode=="unique")
{
    $totaluniquehits=0;
	$i=1;		
	while($i<=$totalallhits+2)
	{
		$hitdata=explode("|",$overallhitdata[$i]);
		
	    if($hitdata[6]=="1") //If the hit is unique
		{
	        $totaluniquehits=$totaluniquehits+1;
		}
		$i=$i+1;
	}
	echo($totaluniquehits);
}
?>
