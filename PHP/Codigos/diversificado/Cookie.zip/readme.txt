#################################################################
# Cookie Counter v3.0						#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts			#
#################################################################


Installaion:
============

1) Locate the directory containing the page you wish to count the hits from. 

2) Upload all files to this directory.

2) CHMOD hits.txt to 777 (Unix users).

3) Insert this code at the very top of a page you wish to count the hits from:

	<? include "counter.php"; ?>


Upgrading:
==========

Unfortunately this version is NOT compatable with Cookie Counter v1.0.

To upgrade from v2.0 make sure you do not upload the hits.txt file, use your old one.



Useage:
=======

To view the full count statistics open output.php in your browser. 

To view simple statistics open simpleoutput.php in your browser, alternatively you could insert this code: <? include "simpleoutput.php"; ?> in your webpage to display the total hits to the user.

To change the output to unique hits from simpleoutput.php, you need to edit the file and change this code: $mode="combined"; to: $mode="unique";