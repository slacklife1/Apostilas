<html>
<head>
	<title>Cookie Counter v3.0 - Hits Summary</title>
</head>
<body>

<?
#################################################################
# Cookie Counter v3.0											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################

//Data reading
$fp=fopen("hits.txt","r");
$overallhitdata=fread($fp,filesize("hits.txt"));
fclose($fp);



//The year day
$date=getdate();
$yday=$date['yday'];
$mday=$date['mday'];
$mon=$date['mon']; 
$month=$date['month'];
$year=$date['year']; 



//Data processing
$overallhitdata=explode("[~]",$overallhitdata);



//Calculates all hits (unique and total)
$totalallhits=count($overallhitdata)-2;
$todaysdate=$mday." / ".$mon." / ".$year;

$totaluniquehits=0;

$uniquehitstoday=0;
$uniquehitsyesterday=0;

$allhitsyesterday=0;
$allhitstoday=0;

$arrayallhits[0]=0;
$arrayuniquehits[0]=0;

$allhitsforthismonth=0;
$uniquehitsforthismonth=0;

$heightestdayall=0;
$heightestdayunique=0;

$busiesthour[0]=0;

$i=1;
while($i<=$totalallhits+2)
{
    $hitdata=explode("|",$overallhitdata[$i]);
	
	
	//Busiest Hour
	
	if($hitdata[0]!="10" && $hitdata[0]!="20" && $hitdata[0]!="00")
	{
		$thehour=$hitdata[0];
		$thehour = str_replace("0","", $thehour);
	}
	
	if($hitdata[0]=="00")
	{
	    $thehour=$hitdata[0];
		$thehour = str_replace("00","24", $thehour);
	}
	
	if($busiesthour[$thehour]=="")
	{
	    $busiesthour[$thehour]==1;
	}
	else
	{
	    $busiesthour[$thehour]=$busiesthour[$thehour]+1;
	}	  
	 
	$busiesthour[$thehour]=$busiesthour[$thehour]+1;
	
	//Busiest Hour END 	
	
	
	if($hitdata[4]==$mon && $hitdata[5]==$year) //If the hit is on todays month and year
	{
		if($arrayallhits[$hitdata[3]]=="") //If the array position has not been intialized
		{
		    $arrayallhits[$hitdata[3]]=1;
		}
		else //Otherwise add 1
		{
		    $arrayallhits[$hitdata[3]]=$arrayallhits[$hitdata[3]]+1;
		}
		$allhitsforthismonth=$allhitsforthismonth+1;
		
		if($heighestdayall<$arrayallhits[$hitdata[3]])
		{
		    $heighestdayall=$arrayallhits[$hitdata[3]];
		}
	}
	
	if($hitdata[4]==$mon && $hitdata[5]==$year && $hitdata[6]=="1") //If the hit is on todays month and year and is unique
	{
		if($arrayuniquehits[$hitdata[3]]=="") //If the array position has not been intialized
		{
		    $arrayuniquehits[$hitdata[3]]=1;
		}
		else //Otherwise add 1
		{
		    $arrayuniquehits[$hitdata[3]]=$arrayuniquehits[$hitdata[3]]+1;
		}
		$uniquehitsforthismonth=$uniquehitsforthismonth+1;
		
		if($heighestdayunique<$arrayuniquehits[$hitdata[3]])
		{
		    $heighestdayunique=$arrayuniquehits[$hitdata[3]];
		}
	}
	
	
	    
	
	if($i==1)
	{
	    $firstdate=$hitdata[3]." / ".$hitdata[4]." / ".$hitdata[5];
		
		if($hitdata[5]==$year) //In the same year
		{
		    $period=($yday-$hitdata[2])+1;
		}
		elseif($hitdata[5]<$year) //In a year before now
		{
		    $period=($yday+(365-$hitdata[2]))+1;
		}
	}	    
	
	if($hitdata[6]=="1") //If the hit is unique
	{
	    $totaluniquehits=$totaluniquehits+1;
	}
	
	if($hitdata[2]==$yday && $hitdata[5]==$year) //If the hit was today and during this year
	{
	    $allhitstoday=$allhitstoday+1;
	}
	
	if($hitdata[2]==$yday && $hitdata[6]=="1" && $hitdata[5]==$year) //If the hit was today and during the year and unique
	{
	    $uniquehitstoday=$uniquehitstoday+1;
	}
	
	if($hitdata[2]==($yday-1) && $hitdata[5]==$year) //If the hit was yesterday and this year
	{
	    $allhitsyesterday=$allhitsyesterday+1;
	}	    
	
	if($hitdata[2]==($yday-1) && $hitdata[6]=="1" && $hitdata[5]==$year) //If the hit was yesterday and unique and this year
	{
	    $uniquehitsyesterday=$uniquehitsyesterday+1;
	}
	
	if($yday==0) //If the yday today is 0 (the 1st of january) then it means yesterday will not be yday-1, it will be 364
	{
	    if($hitdata[2]==364) //If the yday is 364
		{
	        $allhitsyesterday=$allhitsyesterday+1;
		}	    
	
		if($hitdata[2]==364 && $hitdata[6]=="1") //If the yday is 364 and the hit is unique
		{
	        $uniquehitsyesterday=$uniquehitsyesterday+1;
		}
	}	    
	
	$i=$i+1;
}




/////////////////////
//busiest hour//
////////////////////

$i=1;
$mostbusyhour=1;
while($i<=24)
{
   if($busiesthour[$mostbusyhour]<$busiesthour[$i])
   {
       $mostbusyhour=$i;
   }
   $i=$i+1;
}


$mostbusyhour2=$mostbusyhour.".59";
$mostbusyhour=$mostbusyhour.".00";

////////////////////////////////
//For the final summary table
///////////////////////////

$aveuniquehitsoverall=(integer)($totaluniquehits/$period);
$avetotalhitsoverall=(integer)($totalallhits/$period);


//Output
echo("
<center>

<table border='0' cellspacing='0' cellpadding='12' width='100%'>
<tr valign='top'>
	   <td width='50%'>	  
	   	   <font face='verdana' color='black' size='2'><center><b>Report Details</b></center></font>
		   <br>
	    	   
	   	   <table border='0' cellspacing='1' cellpadding='2' width='100%' bgcolor='#000000'>
		   <tr>
       	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><i>Counting Since: $firstdate</i></center></font></td>
		   </tr>
		   <tr>
	   	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><i>Current Report: $todaysdate</i></center></font></td>
		   </tr>
		   <tr>
	   	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><i>Period: $period days</i></center></font></td>
		   </tr>
		   </table>
		   
		   <br><br>
		   
		   <font face='verdana' color='black' size='2'><center><b>Hit Summaries</b></center></font>
		   
		   <br>
		   
		   <table border='0' cellspacing='1' cellpadding='2' width='100%' bgcolor='#000000'>
		   <tr>
       	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><b>Unique Hits</b></center></font></td>
		   </tr>
		   </table>
		   <table border='0' cellspacing='1' cellpadding='2' width='100%' bgcolor='#000000'>
		   <tr>
	   	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>Today</center></font></td>
			   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>$uniquehitstoday</center></font></td>
		   </tr>
		   <tr>
	   	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>Yesterday</center></font></td>
			   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>$uniquehitsyesterday</center></font></td>
		   </tr>
		   <tr>
	   	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><b>Overall</b></center></font></td>
			   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><b>$totaluniquehits</b></center></font></td>
		   </tr>
		   </table>
		   
		   <br><br>
		   
		   <table border='0' cellspacing='1' cellpadding='2' width='100%' bgcolor='#000000'>
		   <tr>
       	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><b>Total Hits</b></center></font></td>
		   </tr>
		   </table>
		   <table border='0' cellspacing='1' cellpadding='2' width='100%' bgcolor='#000000'>
		   <tr>
	   	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>Today</center></font></td>
			   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>$allhitstoday</center></font></td>
		   </tr>
		   <tr>
	   	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>Yesterday</center></font></td>
			   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>$allhitsyesterday</center></font></td>
		   </tr>
		   <tr>
	   	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><b>Overall</b></center></font></td>
			   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><b>$totalallhits</b></center></font></td>
		   </tr>
		   </table>
		   
		   <br><br>
		   
		   <table border='0' cellspacing='1' cellpadding='2' width='100%' bgcolor='#000000'>
		   <tr>
       	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><b>Overall Summary</b></center></font></td>
		   </tr>
		   </table>
		   <table border='0' cellspacing='1' cellpadding='2' width='100%' bgcolor='#000000'>
		   <tr>
	   	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>Busiest Hour</center></font></td>
			   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>$mostbusyhour - $mostbusyhour2</center></font></td>
		   </tr>
		   <tr>
	   	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>Average Unique Hits (per day)</center></font></td>
			   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>$aveuniquehitsoverall</center></font></td>
		   </tr>
		   <tr>
	   	   	   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>Average Total Hits (per day)</center></font></td>
			   <td width='25%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center>$avetotalhitsoverall</center></font></td>
		   </tr>
		   </table>
		   
		   
		   <br>
		   
		   
		 <font face='verdana' color='black' size='2'><center><i>Busiest hour is based on total hits.</i></center></font>  
		   
		   
	   </td>	   
	   <td width='50%'>
");

/////////////////////////////////////////////////////////
//Data processing for the two graphs/////////////////////
/////////////////////////////////////////////////////////






echo("


<font face='verdana' color='black' size='2'><center><b>Summaries For This Month</b></center></font>

<br>

<table width='100%' border='0' cellspacing='1' cellpadding='2' bgcolor='#000000' height='20'>
<tr>
    <td width='100%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><b>Unique Hits </b><i>vs</i><b> Date</b></center></font></td>
</tr>
</table>

<table width='100%' border='0' cellspacing='1' cellpadding='2' bgcolor='#000000' height='200'><tr valign='bottom'>

");


//Calculates the month length
if($month=="January" || $month=="March" || $month=="May" || $month=="July" || $month=="August" || $month=="October" || $month=="December")
{
    $monthlength="31";
}
elseif($month=="April" || $month=="June" || $month=="September" || $month=="November")
{
    $monthlength="30";
}
else
{
    $monthlength="28";
} 

$i=1;
$daysinmonthpassed=$monthlength;
while($i<=$monthlength)
{
    if($arrayuniquehits[$i]=="")
	{
	    $arrayuniquehits[$i]=0;
		$daysinmonthpassed=$daysinmonthpassed-1;
	}	
	
	$width=100/$monthlength;	
	
	if($heighestdayunique==0)
	{
	    $height=0;
	}
	else
	{
	    $height=($arrayuniquehits[$i]/$heighestdayunique)*180;	
	}
	
	echo("<td width='$width%' bgcolor='#FFFFFF'>
	<table width='100%' height='$height' border='0' cellspacing='0' cellpadding='0' bgcolor='#BBBBBB'>
	<tr valign='bottom'>
	<td>
	</td>
	</tr>
	</table>
	
	</td>");	
	$i=$i+1;
}








if($monthlength=="31")
{
    $lastdayinmonth="31st";
}
elseif($monthlength=="30")
{
    $lastdayinmonth="30th";
}
else
{
    $lastdayinmonth="28th";
}

$aveunique=(integer)($uniquehitsforthismonth/$daysinmonthpassed);

echo("
</tr></table>
<table width='100%' border='0' cellspacing='1' cellpadding='2' bgcolor='#000000' height='20'>
<tr>
    <td width='100%' colspan='1' bgcolor='#B0C0D0' height='20'>
	
		<table border='0' cellspacing='0' cellpadding='0' width='100%' height='100%'>
		<tr>
       <td width='33%'><font face='verdana' color='black' size='1'>1st</font></td>
       <td width='33%'><font face='verdana' color='black' size='2'><center>$month</center></font></td>
       <td width='33%'><font face='verdana' color='black' size='1'><div align='right'>$lastdayinmonth</div></font></td>
	   </tr>
	   </table>

	</td>
</tr>

</table>

<table width='100%' border='0' cellspacing='1' cellpadding='2' bgcolor='#000000' height='20'>
<tr>
    <td width='50%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><i>Highest Day: $heighestdayunique</i></center></font></td>
	<td width='50%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><i>Average Per Day: $aveunique</i></center></font></td>
</tr>
</table>



<br>

");


























echo("

<table width='100%' border='0' cellspacing='1' cellpadding='2' bgcolor='#000000' height='20'>
<tr>
    <td width='100%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><b>Total Hits </b><i>vs</i><b> Date</b></center></font></td>
</tr>
</table>

<table width='100%' border='0' cellspacing='1' cellpadding='2' bgcolor='#000000' height='200'><tr valign='bottom'>

");


//Calculates the month length
if($month=="January" || $month=="March" || $month=="May" || $month=="July" || $month=="August" || $month=="October" || $month=="December")
{
    $monthlength="31";
}
elseif($month=="April" || $month=="June" || $month=="September" || $month=="November")
{
    $monthlength="30";
}
else
{
    $monthlength="28";
} 

$daysinmonthpassed=$monthlength;
$i=1;
while($i<=$monthlength)
{
    if($arrayallhits[$i]=="")
	{
	    $arrayallhits[$i]=0;
		$daysinmonthpassed=$daysinmonthpassed-1;
	}	
	
	$width=100/$monthlength;	
	
	$height=($arrayallhits[$i]/$heighestdayall)*180;	
	
	echo("<td width='$width%' bgcolor='#FFFFFF'>
	<table width='100%' height='$height' border='0' cellspacing='0' cellpadding='0' bgcolor='#BBBBBB'>
	<tr valign='bottom'>
	<td>
	</td>
	</tr>
	</table>
	
	</td>");	
	$i=$i+1;
}



if($monthlength=="31")
{
    $lastdayinmonth="31st";
}
elseif($monthlength=="30")
{
    $lastdayinmonth="30th";
}
else
{
    $lastdayinmonth="28th";
}

$aveall=(integer)($allhitsforthismonth/$daysinmonthpassed);

echo("
</tr></table>
<table width='100%' border='0' cellspacing='1' cellpadding='2' bgcolor='#000000' height='20'>
<tr>
    <td width='100%' colspan='1' bgcolor='#B0C0D0' height='20'>
	
		<table border='0' cellspacing='0' cellpadding='0' width='100%' height='100%'>
		<tr>
       <td width='33%'><font face='verdana' color='black' size='1'>1st</font></td>
       <td width='33%'><font face='verdana' color='black' size='2'><center>$month</center></font></td>
       <td width='33%'><font face='verdana' color='black' size='1'><div align='right'>$lastdayinmonth</div></font></td>
	   </tr>
	   </table>

	</td>
</tr>

</table>

<table width='100%' border='0' cellspacing='1' cellpadding='2' bgcolor='#000000' height='20'>
<tr>
    <td width='50%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><i>Highest Day: $heighestdayall</i></center></font></td>
	<td width='50%' colspan='1' bgcolor='#B0C0D0'><font face='verdana' color='black' size='2'><center><i>Average Per Day: $aveall</i></center></font></td>
</tr>
</table>

");






?>

	   
	   </td>
</tr>
</table>
</center>

</body>
</html>
