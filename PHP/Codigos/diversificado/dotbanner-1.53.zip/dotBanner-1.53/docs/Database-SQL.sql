# phpMyAdmin MySQL-Dump
# http://phpwizard.net/phpMyAdmin/
#
# Host: localhost Database : dotBanner

# --------------------------------------------------------
#
# Table structure for table 'admin_log'
#

DROP TABLE IF EXISTS admin_log;
CREATE TABLE admin_log (
   Date int(10) unsigned NOT NULL,
   Account varchar(255) NOT NULL,
   Memo varchar(255) NOT NULL,
   Time double(16,4) DEFAULT '0.0000',
   IP varchar(255) NOT NULL
);

#
# Dumping data for table 'admin_log'
#


# --------------------------------------------------------
#
# Table structure for table 'advertiser_log'
#

DROP TABLE IF EXISTS advertiser_log;
CREATE TABLE advertiser_log (
   Date int(10) unsigned NOT NULL,
   Account varchar(255) NOT NULL,
   Memo varchar(255) NOT NULL,
   Time double(16,4) DEFAULT '0.0000',
   IP varchar(255) NOT NULL
);

#
# Dumping data for table 'advertiser_log'
#

# --------------------------------------------------------
#
# Table structure for table 'advertiser_stats'
#

DROP TABLE IF EXISTS advertiser_stats;
CREATE TABLE advertiser_stats (
   Date int(10) unsigned NOT NULL,
   Account varchar(255) NOT NULL,
   Memo varchar(255) NOT NULL,
   Count int(10) NOT NULL,
   KEY Account (Account),
   KEY Memo (Memo)
);

#
# Dumping data for table 'advertiser_stats'
#


# --------------------------------------------------------
#
# Table structure for table 'advertisers'
#

DROP TABLE IF EXISTS advertisers;
CREATE TABLE advertisers (
   UserName varchar(255) NOT NULL,
   Email_Address varchar(255) NOT NULL,
   Password varchar(50) NOT NULL,
   Advertiser_Start int(10) unsigned NOT NULL,
   Max_Adverts int(10) unsigned NOT NULL,
   Ad_Type char(1) NOT NULL,
   Image mediumblob,
   URL varchar(255),
   Alt_Text varchar(255),
   Link_Text varchar(255),
   Link_Text_Location char(1),
   Height varchar(4),
   Width varchar(4),
   Shown int(10) unsigned NOT NULL,
   Visits int(10) unsigned NOT NULL,
   Weight int(4),
   Border tinyint(1),
   Target varchar(255),
   Raw_HTML mediumblob,
   Display_Zone varchar(255),
   Start_Second mediumint(9) NOT NULL,
   End_Second mediumint(9) NOT NULL,
   Awaiting_Approval char(1) NOT NULL
);

#
# Dumping data for table 'advertisers'
#

INSERT INTO advertisers VALUES( 'dotBanner', 'webmaster@dot-banner.com', '12345', '980000422', '982592422', 'D', 'http://www.dot-banner.com/images/Ad1.gif', 'http://www.dot-banner.com', '', '', '', '', '', '0', '0', '1', '0', '', '', 'Default', '0', '86400', 'F');

# --------------------------------------------------------
#
# Table structure for table 'general_admin'
#

DROP TABLE IF EXISTS general_admin;
CREATE TABLE general_admin (
   Admin_Option varchar(255) NOT NULL,
   Value varchar(255) NOT NULL
);

#
# Dumping data for table 'general_admin'
#

INSERT INTO general_admin VALUES( 'password', '12345');
INSERT INTO general_admin VALUES( 'Start_Time', '979826333');
