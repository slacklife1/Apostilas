<!-- Comment="dotBanner 1.50 NoPrint PHP Parsed Example File.     " -->
<!-- Comment="----------------------------------------------------" -->
<!-- Comment=" The ads-noprint.php script is included and the next" -->
<!-- Comment=" line tells dotBanner to pick a banner from the     " -->
<!-- Comment=" iconad zone. dotBanner then returns the html code  " -->
<!-- Comment=" to display the banner chosen.                      " -->
<!-- Comment="----------------------------------------------------" -->
<script language="php">
$dotBanner_file_directory = "/www/htdocs/banner/";
include("$dotBanner_file_directory" . "ads-noprint.php");
print dotBanner_PickBanner("iconad", "", "", false);
</script>
<!-- Comment="dotBanner 1.50 NoPrint PHP Parsed Example File.     " -->
<!-- Comment="----------------------------------------------------" -->
<!-- Comment=" If you want to show a second banner on the same    " -->
<!-- Comment=" page, you just need to issue another               " -->
<!-- Comment=" dotBanner_PickBanner call -                        " -->
<!-- Comment=" This will only show the same account (allicons)    " -->
<!-- Comment=" over and over. If there are more than one image url" -->
<!-- Comment=" defined in the account, it will pick a random img. " -->
<!-- Comment="----------------------------------------------------" -->
<script language="php">
print dotBanner_PickBanner("", "allicons", "", false);
</script>
<!-- Comment="dotBanner 1.50 NoPrint PHP Parsed Example File.     " -->
<!-- Comment="----------------------------------------------------" -->
<!-- Comment=" If you want to show a third banner on the same     " -->
<!-- Comment=" page, you just need to issue another               " -->
<!-- Comment=" dotBanner_PickBanner call -                        " -->
<!-- Comment=" This will only show the same account (allicons)    " -->
<!-- Comment=" over and over. It will also show the second banner " -->
<!-- Comment=" if there are more than one. If there is only one,  " -->
<!-- Comment=" the it will show that banner.                      " -->
<!-- Comment="----------------------------------------------------" -->
<script language="php">
print dotBanner_PickBanner("", "allicons", "2", false);
</script>
