<?php
/*
	Script Name:	FuBBonis
	File Name:	reply.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Add a new reply
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt is included.
*/
?>
<html>
	<head>
		<title>
			Reply
		</title>
	</head>
	<body>
		<form action="addreply.php" method="post">
		<center>
			<table border="1" width="90%">
				<tr>
					<td width="25%" valign="top">
						Handle:
					</td>
					<td>
						<input type="text" name="handle" length="20" maxlength="20">
					</td>
				</tr>
				<tr>
					<td width="25%" valign="top">
						Post:
					</td>
					<td>
						<textarea name="post" rows="4" cols="20"></textarea>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="hidden" name="tid" value="<?=$id?>">
						<input type="hidden" name="ip" value="<?=$REMOTE_ADDR?>">
						<input type="submit" value="Submit"> | 
						<input type="reset" value="Clear">
					</td>
				</tr>
			</table>
		</center>
		</form>
	</body>
</html>