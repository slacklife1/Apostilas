<?php
/*
	Script Name:	FuBBonis
	File Name:	addreply.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Actually adds the reply to the database
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don'y pass off as ONLY your own work.  Make sure the original README.txt is included.
*/
require("functions.php");
dbConnect();
addTopic($handle,$headline,$post,$ip);
?>