<?php
/*
	Script Name:	FuBBonis
	File Name:	install.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Creates the MySQL tables need for the software
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt is included.
*/
require("functions.php");
dbConnect();
$topics = "CREATE TABLE fubb_topics(
	id INT NOT NULL AUTO_INCREMENT,
	PRIMARY KEY(id),
	handle VARCHAR(20) NOT NULL,
	headline VARCHAR(50) NOT NULL,
	post VARCHAR(255) NOT NULL,
	datetime VARCHAR(20) NOT NULL,
	ip VARCHAR(15) NOT NULL)";
if(mysql_query($topics)){
	echo "fubb_topics table created successfully.<br><br>";
}
if(!mysql_query($topics)){
	echo mysql_error() . "<br>fubb_topics table could not be created.<br><br>";
}
$replies = "CREATE TABLE fubb_replies(
	id INT NOT NULL AUTO_InCREMENT,
	PRIMARY KEY(id),
	tid INT NOT NULL,
	handle VARCHAR(20) NOT NULL,
	post VARCHAR(255),
	datetime VARCHAR(20) NOT NULL,
	ip VARCHAR(15) NOT NULL)";
if(mysql_query($replies)){
	echo "fubb_replies table created successfully.";
}
if(!mysql_query($replies)){
	echo mysql_error() . "<br>fubb_replies could not be created.";
}
mysql_close();
?>