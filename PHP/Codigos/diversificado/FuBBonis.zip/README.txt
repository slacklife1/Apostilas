FuBBonis
--------
Read Me

I.	Requirements
II.	Pre-Installation
III.	Installation
IV.	Post-Instalation
V.	Credits

I.	Requirements
		PHP 4+
		MySQL 3.23+

II.	Pre-Installation
		Edit config.php to reflect your MySQL settings
		Upload all files included with this file in ASCII mode.
III.	Installation
		Go to http://www.yoursite.ext/fubbonis_directory/install.php, replacing the URL with your URL.
			-or-
		You can use the sqldump.sql, either through shell access or phpMyAdmin (http://phpmyadmin.sourceforge.net)
IV.	Post-Installation
		Go to http://www.yoursite.ext/fubbonis_directory
		At first, it will say no topics and such, create one by click the New Topic link and submitting the forum
V.	Credits
		Kenna for telling me work on FuBBonis.  ;D