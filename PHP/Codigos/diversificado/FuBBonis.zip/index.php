<?php
/*
	Script Name:	FuBBonis
	File Name:	index.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Displays all avaiable topics
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass it off as ONLY your own work.  Make sure the original README.txt is included.
*/
require("functions.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
		<meta http-equiv="Content-type" content="text/html; charset=utf-8">
		<title>
			FuBBonis
		</title>
	</head>
	<body>
		<center>
			<table border="1" width="90%">
				<tr>
					<td colspan="2">
						<a href="download.php">Download FuBBonis</a>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<a href="topic.php">New Topic</a>
					</td>
				</tr>
				<tr>
					<td>
						Headline
					</td>
					<td width="25%">
						Starter
					</td>
				</tr>
<?php
dbConnect();
$sql = "SELECT * FROM fubb_topics ORDER BY datetime DESC";
if($result = mysql_query($sql)){
	while($r = mysql_fetch_array($result)){
		echo "				<tr>
					<td>
						<a href=\"viewthread.php?id=$r[id]\">$r[headline]</a>
					</td>
					<td width=\"25%\">
						$r[handle]
					</td>
				</tr>";
	}
}
else{
	echo mysql_error() . "<br><br>Could not select topics.";
}
?>
				<tr">
					<td colspan="2">
						<center>
							Powered by <a href="http://www.fubonis.com/fubbonis" target="fubbonis">FuBBonis</a>
						</center>
					</td>
				</tr>
			</table>
		</center>
	</body>
</html>