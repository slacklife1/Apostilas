<?php
/*
	Script Name:	FuBBonis
	File Name:	viewthread.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Display replies and stuff
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit us due.  Feel free to edit, modify and learn from my code,
			but don't pass it off as ONLY your own work.  Make sure the original README.txt is included.
*/
?>
<html>
	<head>
		<title>
			Thread
		</title>
	</head>
	<body>
		<center>
			<table border="1" width="90%">
				<tr>
					<td>
						User
					</td>
					<td>
						Post
					</td>
				</tr>
<?php
require("functions.php");
dbConnect();
$sql = "SELECT * FROM fubb_topics WHERE id='$id'";
if($res = mysql_query($sql)){
	while($r = mysql_fetch_array($res)){
		echo "				<tr>
					<td valign=\"top\" width=\"25%\">
						$r[handle]<br>
						Posted at:  $r[datetime]
					</td>
					<td valign=\"top\">
						$r[headline]<hr>
						$r[post]
					</td>
				</tr>";
	}
}
if(!$res = mysql_query($sql)){
	echo mysql_error() . "<br><br>Could not get the topic.";
}
$sql = "SELECT * FROM fubb_replies WHERE tid='$id'";
if($res = mysql_query($sql)){
	while($r = mysql_fetch_array($res)){
		echo "				<tr>
					<td valign=\"top\" width=\"25%\">
						$r[handle]<br>
						Posted at:  $r[datetime]
					</td>
					<td valign=\"top\">
						$r[post]
					</td>
				</tr>";
	}
}
if(!$res = mysql_query($sql)){
	echo mysql_error() . "<br><br>Could not get replies.";
}
?>
				<tr>
					<td colspan="2">
						<a href="reply.php?id=<?=$id?>">Reply</a>
					</td>
				</tr>
			</table>
		</center>
	</body>
</html>