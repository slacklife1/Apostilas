<?php
/*
	Script Name:	FuBBonis
	File Name:	functions.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Basically, the functions of FuBBonis
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass it off as ONLY your own work.  Make sure the original README.txt is included.
*/

# dbConnect()
# Connects the the MySQL database
function dbConnect(){
	require("config.php");
	if(mysql_connect($sqlhost,$sqluser,$sqlpass)){
		if(mysql_select_db($sqldb)){
		}
		else{
			echo mysql_error() . "<br><br>Cannot select the database, $sqldb.";
		}
	}
	else{
		echo mysql_error() . "<br><br>Cannot connect to the database.";
	}
}

# addTopic()
# Adds a new topic to the MySQL database
function addTopic($handle,$headline,$post,$ip){
	$handle = htmlspecialchars($handle,ENT_NOQUOTES);
	$handle = addslashes($handle);
	$headline = htmlspecialchars($headline,ENT_NOQUOTES);
	$headline = addslashes($headline);
	$post = htmlspecialchars($post,ENT_NOQUOTES);
	$post = addslashes($post);
	$datetime = date("m/d/y h:i a");
	dbConnect();
	$sql = "INSERT INTO fubb_topics VALUES(0,'$handle','$headline','$post','$datetime','$ip')";
	if(mysql_query($sql)){
		echo "Topic added.  <a href=\"index.php\">Home</a>";
	}
	else{
		echo mysql_error() . "<br><br>Could not add topic.";
	}
}

# addReply()
# Adds a new reply to the MySQL database
function addReply($tid,$handle,$post,$ip){
	if(!intval($tid)){
		echo "Topic ID is not an integer.";
		exit;
	}
	else{
		$handle = htmlspecialchars($handle,ENT_NOQUOTES);
		$handle = addslashes($handle);
		$post = htmlspecialchars($post,ENT_NOQUOTES);
		$post = addslashes($post);
		$datetime = date("m/d/y h:i a");
		dbConnect();
		$sql = "INSERT INTO fubb_replies VALUES(0,'$tid','$handle','$post','$datetime','$ip')";
		if(mysql_query($sql)){
			echo "Reply added.  <a href=\"index.php\">Home</a>";
		}
		else{
			echo mysql_error() . "<br><br>Could not add reply.";
		}
	}
}
?>