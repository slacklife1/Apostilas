<?php
/*
	Script Name:	FuBBonis
	File Name:	config.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Stores the MySQL login information and stuff, amazing, eh?
	Copyright:	GNU GPL (http://www.gnu.org)
	Requests:	None for this file, geez
*/

$sqlhost = "";		# Set your host/server stuff here
$sqluser = "";	# Set your MySQL username here
$sqlpass = "";		# Set your MySQL password here
$sqldb = "";		# Set your MySQL database name here
?>