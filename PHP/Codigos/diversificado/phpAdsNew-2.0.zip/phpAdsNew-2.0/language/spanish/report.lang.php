<?php // $Revision: 2.0.2.1 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2000-2003 by the phpAdsNew developers                  */
/* For more information visit: http://www.phpadsnew.com                 */
/*                                                                      */
/*                                                                      */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/


$GLOBALS['strPluginAffiliate'] 		= "Generar un resumen del historial del Afiliado seleccionado. El reporte ser&aacute; exportado como CSV.";
$GLOBALS['strPluginCampaign'] 		= "Generar un resumen del historial de la campa&ntilde;a seleccionada. El reporte ser&aacute; exportado como CSV.";
$GLOBALS['strPluginClient'] 		= "Generar un resumen del historial del anunciante seleccionado. El reporte ser&aacute; exportado como CSV.";
$GLOBALS['strPluginGlobal'] 		= "Generar un resumen del historial global. El reporte ser&aacute; exportado como CSV.";
$GLOBALS['strPluginZone'] 		= "Generar un resumen del historial de la zona seleccionada. El reporte ser&aacute; exportado como CSV.";

?>