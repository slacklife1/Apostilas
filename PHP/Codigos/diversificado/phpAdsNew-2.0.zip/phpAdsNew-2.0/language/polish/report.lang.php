<?php // $Revision: 2.0.2.1 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2000-2003 by the phpAdsNew developers                  */
/* For more information visit: http://www.phpadsnew.com                 */
/*                                                                      */
/*                                                                      */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/


$GLOBALS['strPluginAffiliate'] 		= "Utw�rz przegl�d historii dla wybranego wydawcy. Raport jest tworzony w formacie CSV do przegl�dania w arkuszu kalkulacyjnym.";
$GLOBALS['strPluginCampaign'] 		= "Utw�rz przegl�d historii dla wybranej kampanii. Raport jest tworzony w formacie CSV do przegl�dania w arkuszu kalkulacyjnym.";
$GLOBALS['strPluginClient'] 		= "Utw�rz przegl�d historii dla wybranego reklamodawcy. Raport jest tworzony w formacie CSV do przegl�dania w arkuszu kalkulacyjnym.";
$GLOBALS['strPluginGlobal'] 		= "Utw�rz przegl�d globalnej historii. Raport jest tworzony w formacie CSV do przegl�dania w arkuszu kalkulacyjnym.";
$GLOBALS['strPluginZone'] 		= "Utw�rz przegl�d historii dla wybranej strefy. Raport jest tworzony w formacie CSV do przegl�dania w arkuszu kalkulacyjnym.";

?>