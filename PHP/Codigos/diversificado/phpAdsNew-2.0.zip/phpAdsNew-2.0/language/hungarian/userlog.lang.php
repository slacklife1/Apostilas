<?php // $Revision: 1.1.2.2 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2000-2003 by the phpAdsNew developers                  */
/* For more information visit: http://www.phpadsnew.com                 */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/


// Set translation strings

$GLOBALS['strDeliveryEngine']				= "Tov�bb�t�motor";
$GLOBALS['strMaintenance']					= "Karbantart�s";
$GLOBALS['strAdministrator']				= "Adminisztr�tor";


$GLOBALS['strUserlog'] = array (
	phpAds_actionAdvertiserReportMailed 	=> "Jelent�s k�ld�se (id) hirdet� r�sz�re e-mailben",
	phpAds_actionPublisherReportMailed 		=> "Jelent�s k�ld�se (id) kiad� r�sz�re e-mailben",
	phpAds_actionWarningMailed				=> "Figyelmeztet�s k�ld�se e-mailben a(z) (id) kamp�ny deaktiv�l�s�r�l",
	phpAds_actionDeactivationMailed			=> "�rtes�t�s k�ld�se e-mailben a(z) (id) kamp�ny deaktiv�l�s�r�l",
	phpAds_actionPriorityCalculation		=> "Priorit�s �jrasz�molva",
	phpAds_actionPriorityAutoTargeting		=> "Kamp�ny c�lok �jrasz�molva",
	phpAds_actionDeactiveCampaign			=> "A(z) {id} kamp�ny deaktiv�lva",
	phpAds_actionActiveCampaign				=> "A(z) {id} kamp�ny aktiv�lva",
	phpAds_actionAutoClean					=> "Adatb�zis automatikus tiszt�t�sa"
);

?>