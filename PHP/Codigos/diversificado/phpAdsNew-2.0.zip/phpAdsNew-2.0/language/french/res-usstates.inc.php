<?php // $Revision: 1.1.2.2 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2000-2003 by the phpAdsNew developers                  */
/* For more information visit: http://www.phpadsnew.com                 */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/


// This is by no means a complete list of all iso3166 codes, but rather
// an unofficial list used by most browsers. If you have corrections or
// additions to this list, please send them to niels@creatype.nl

$phpAds_USStates['AL'] = "Alabama";
$phpAds_USStates['AK'] = "Alaska";
$phpAds_USStates['AZ'] = "Arizona";
$phpAds_USStates['AR'] = "Arkansas";
$phpAds_USStates['CA'] = "Californie";
$phpAds_USStates['CO'] = "Colorado";
$phpAds_USStates['CT'] = "Connecticut";
$phpAds_USStates['DE'] = "Delaware";
$phpAds_USStates['DC'] = "District de Columbia";
$phpAds_USStates['FL'] = "Floride";
$phpAds_USStates['GA'] = "G�orgie";
$phpAds_USStates['GU'] = "Guam";
$phpAds_USStates['HI'] = "Hawaii";
$phpAds_USStates['ID'] = "Idaho";
$phpAds_USStates['IL'] = "Illinois";
$phpAds_USStates['IN'] = "Indiana";
$phpAds_USStates['IA'] = "Iowa";
$phpAds_USStates['KS'] = "Kansas";
$phpAds_USStates['KY'] = "Kentucky";
$phpAds_USStates['LA'] = "Louisiane";
$phpAds_USStates['ME'] = "Maine";
$phpAds_USStates['MD'] = "Maryland";
$phpAds_USStates['MA'] = "Massachusetts";
$phpAds_USStates['MI'] = "Michigan";
$phpAds_USStates['MN'] = "Minnesota";
$phpAds_USStates['MS'] = "Mississippi";
$phpAds_USStates['MO'] = "Missouri";
$phpAds_USStates['MT'] = "Montana";
$phpAds_USStates['NE'] = "Nebraska";
$phpAds_USStates['NV'] = "Nevada";
$phpAds_USStates['NH'] = "New Hampshire";
$phpAds_USStates['NJ'] = "New Jersey";
$phpAds_USStates['NM'] = "Nouveau Mexique";
$phpAds_USStates['NY'] = "New York";
$phpAds_USStates['NC'] = "Caroline du Nord";
$phpAds_USStates['ND'] = "Dakota du Nord";
$phpAds_USStates['OH'] = "Ohio";
$phpAds_USStates['OK'] = "Oklahoma";
$phpAds_USStates['OR'] = "Or�gon";
$phpAds_USStates['PA'] = "Pennsylvanie";
$phpAds_USStates['PR'] = "Porto Rico";
$phpAds_USStates['RI'] = "Rhode Island";
$phpAds_USStates['SC'] = "Caroline du Sud";
$phpAds_USStates['SD'] = "Dakota du Sud";
$phpAds_USStates['TN'] = "Tennessee";
$phpAds_USStates['TX'] = "Texas";
$phpAds_USStates['UT'] = "Utah";
$phpAds_USStates['VT'] = "Vermont";
$phpAds_USStates['VA'] = "Virginie";
$phpAds_USStates['VI'] = "Iles Vierges";
$phpAds_USStates['WA'] = "Washington";
$phpAds_USStates['WV'] = "Virginie de l'ouest";
$phpAds_USStates['WI'] = "Wisconsin";
$phpAds_USStates['WY'] = "Wyoming";
?>