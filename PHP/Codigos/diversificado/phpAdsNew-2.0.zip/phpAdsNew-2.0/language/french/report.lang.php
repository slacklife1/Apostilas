<?php // $Revision: 2.0.2.3 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2000-2003 by the phpAdsNew developers                  */
/* For more information visit: http://www.phpadsnew.com                 */
/*                                                                      */
/*                                                                      */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/


$GLOBALS['strPluginAffiliate'] 		= 'G�n�re un aper�u de l\'historique de l\'�diteur s�lectionn�. Le rapport est export� au format CSV, afin qu\'il puisse �tre import� dans un tableur.';
$GLOBALS['strPluginCampaign'] 		= 'G�n�re un aper�u de l\'historique de la campagne s�lectionn�e. Le rapport est export� au format CSV, afin qu\'il puisse �tre import� dans un tableur.';
$GLOBALS['strPluginClient'] 		= 'G�n�re un aper�u de l\'historique de l\'annonceur s�lectionn�. Le rapport est export� au format CSV, afin qu\'il puisse �tre import� dans un tableur.';
$GLOBALS['strPluginGlobal'] 		= 'G�n�re un aper�u de l\'historique global. Le rapport est export� au format CSV, afin qu\'il puisse �tre import� dans un tableur.';
$GLOBALS['strPluginZone'] 		= 'G�n�re un aper�u de l\'historique de la zone s�lectionn�e. Le rapport est export� au format CSV, afin qu\'il puisse �tre import� dans un tableur.';

?>