<?php // $Revision: 2.0.2.1 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2000-2003 by the phpAdsNew developers                  */
/* For more information visit: http://www.phpadsnew.com                 */
/*                                                                      */
/*                                                                      */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/


$GLOBALS['strPluginAffiliate'] 		= "Generate an overview of the history of the selected publisher. The report is exported as CSV for use in a spreadsheet.";
$GLOBALS['strPluginCampaign'] 		= "Generate an overview of the history of the selected campaign. The report is exported as CSV for use in a spreadsheet.";
$GLOBALS['strPluginClient'] 		= "Generate an overview of the history of the selected advertiser. The report is exported as CSV for use in a spreadsheet.";
$GLOBALS['strPluginGlobal'] 		= "Generate an overview of the global history. The report is exported as CSV for use in a spreadsheet.";
$GLOBALS['strPluginZone'] 		= "Generate an overview of the history of the selected zone. The report is exported as CSV for use in a spreadsheet.";

?>