<?php // $Revision: 1.1.2.1 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2000-2003 by the phpAdsNew developers                  */
/* For more information visit: http://www.phpadsnew.com                 */
/*                                                                      */
/*                                                                      */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/
// German
// Translation in German
$GLOBALS['strPluginAffiliate'] 		= "Erstellen einer statistischen �bersicht f�r den ausgew�hlten Verleger. Die Ausgabe erfolgt im CSV-Format (f.d. Tabellenverarbeitung z.B. MS-EXCEL). ";
$GLOBALS['strPluginCampaign'] 		= "Erstellen einer statistischen �bersicht f�r die ausgew�hlte Kampagne. Die Ausgabe erfolgt im CSV-Format (f.d. Tabellenverarbeitung z.B. MS-EXCEL). ";
$GLOBALS['strPluginClient'] 		= "Erstellen einer statistischen �bersicht f�r den ausgew�hlten Inserenten. Die Ausgabe erfolgt im CSV-Format (f.d. Tabellenverarbeitung z.B. MS-EXCEL). ";
$GLOBALS['strPluginGlobal'] 		= "Erstellen einer statistischen �bersicht zur Gesamtentwicklung. Die Ausgabe erfolgt im CSV-Format (f.d. Tabellenverarbeitung z.B. MS-EXCEL). ";
$GLOBALS['strPluginZone'] 		= "Erstellen einer statistischen �bersicht f�r die ausgew�hlte Zone. Die Ausgabe erfolgt im CSV-Format (f.d. Tabellenverarbeitung z.B. MS-EXCEL). ";

?>
