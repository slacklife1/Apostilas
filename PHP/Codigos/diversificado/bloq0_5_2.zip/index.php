<?php

///////////// DO NOT EDIT

$page['path'] = "./";

include ($page['path']."files/mainfile.php");

header ("Cache-Control: private, pre-check=0, post-check=0, max-age=0");
header ("Expires: ".gmdate("D, d M Y H:i:s", time())." GMT");
header ("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header ("Content-type: text/html; charset=".$lang['charset']."");

$type = isset($HTTP_GET_VARS['type']) ? $HTTP_GET_VARS['type'] : "";
$post = isset($HTTP_GET_VARS['post']) ? $HTTP_GET_VARS['post'] : "";

if ($type == "") {
	$view = "index";
	$where = "AND post_time <= '".time()."'";
	$order = "time";
	$title_text = $lang['last_ten_posts'];
	$header = $lang['main_page'];
} else {
	if ($type != "" AND $post != "") {
		switch($type) {
			case "archiv":
				$time1 = mktime("0", "0", "0", substr($post, "-2"), "1", substr($post, "0", "4"));
				if ((substr($post, "-2") + "1") > "12") {
					$next_month = "1";
					$next_year = substr($post, "0", "4") + "1";
				} else {
					$next_month = substr($post, "-2") + "1";
					$next_year = substr($post, "0", "4");
				}
				$time2 = mktime("0", "0", "0", $next_month, "0", $next_year);
				$view = "index";
				$where = "AND post_time > '".$time1."' AND post_time < '".$time2."'";
				$order = "time";
				$from_month = (substr($post, "-2") < "10") ? substr($post, "-1") : substr($post, "-2");
				$title_text = strtolower($lang['archive']." ".$lang['of_month']." ".$lang['month'.$from_month].", ".$lang['year']." ".substr($post, "0", "4"));
				$header = strtolower($lang['archive']);
			break;
		
			default: // samostatny prispevek
				$view = "index";
				$where = "AND post_id = '".$post."'";
				$order = "time";
				$title_text = strtolower($lang['comments_to_post']);
				$header = strtolower($lang['comments']);
				$comments = "1";
			break;
		}
	} else {
		switch($type) {
			case "author":
				$view = "author";
				$title_text = $lang['author_about'];
				$header = $lang['author'];
			break;
		
			case "links":
				$view = "links";
				$title_text = $lang['fav_links'];
				$header = $lang['links'];
			break;
		
			case "weblog":
				$view = "weblog";
				$title_text = $lang['what_find'];
				$header = $lang['blog_about'];
			break;
		
			case "archiv":
				$view = "archive";
				$title_text = $lang['archive'];
				$header = $lang['archive'];
			break;
		
			case "comment": // pridat komentar
				$title_text = $lang['comment_add'];
				if (($HTTP_POST_VARS['comment_author'] != "") AND ($HTTP_POST_VARS['comment_content'] != "")) {
					$cookie_val = time() + 3600 * 24 * 365;
					setcookie("bloq_name", $HTTP_POST_VARS['comment_author'], $cookie_val);
					setcookie("bloq_email", $HTTP_POST_VARS['comment_email'], $cookie_val);
					setcookie("bloq_url", $HTTP_POST_VARS['comment_url'], $cookie_val);
					setcookie("bloq_comment", $HTTP_POST_VARS['comment_content'], time()+15);
					$email = "''";
					if ($HTTP_POST_VARS['comment_email'] != "") {
						if (validate_email($HTTP_POST_VARS['comment_email'])) {
							$email = "'".$HTTP_POST_VARS['comment_email']."'";
						} else {
							$message .= $lang['email_notValid'];
						}
					}
					$url = "''";
					if ($HTTP_POST_VARS['comment_url'] != "") {
						if (validate_url($HTTP_POST_VARS['comment_url'])) {
							$url = "'".$HTTP_POST_VARS['comment_url']."'";
						} else {
							
							$message .= (isset($message) ? "<br />" : "").$lang['url_notValid'];
						}
					}
					if (!isset($message)) {
						$sql = "INSERT INTO bloq_comment 
							VALUES ('', '".$HTTP_POST_VARS['post']."', '".$HTTP_POST_VARS['comment_author']."', ".$email.", ".$url.", '".getenv("REMOTE_ADDR")."', '".time()."', '".strip_tags(autobr(addslashes($HTTP_POST_VARS['comment_content'])), $bloq['allowed_tags'])."')";
						$data = mysql_query($sql, $link);
						$sql_num += 1;
						if ($data) {
							$message = $lang['comment_addedOk'];
							$header = $lang['comments'];
						} else {
							$message = $lang['comment_notAdded'];
							$header = $lang['error'];
						}
					} else {
						$message = $message;
						$header = $lang['error'];
					}
				} else {
					$message = $lang['comment_notAllData'];
					$header = $lang['error'];
				}
			break;
		
			case "search": // hledani
				$title_text = $lang['search']." ".$HTTP_POST_VARS['query'];
				$header = $lang['searching'];
				if ($HTTP_POST_VARS['query'] != "") {
					$query = $HTTP_POST_VARS['query'];
					if (strlen($query) > $bloq['query_lenght']) {
						$view = "index";
						$query = addslashes_gpc(htmlspecialchars($query));
						$search = " AND (";
						$query = preg_replace("/, +/", "", $query);
						$query = str_replace(",", " ", $query);
						$query = str_replace("\"", " ", $query);
						$query = trim($query);
						$query_array = explode(" ",$query);
						$n = "%";
						$search .= "(post_title LIKE '".$n.$query_array[0].$n."') OR (post_text LIKE '".$query_array[0]."')";
						for ($i = 1; $i < count($query_array); $i = $i + 1) {
							$search .= " OR (post_title LIKE '".$n.$query_array[$i].$n."') OR (post_text LIKE '".$n.$query_array[$i].$n."')";
						}
						$search .= " OR (post_title LIKE '".$n.$query.$n."') OR (post_text LIKE '".$n.$query.$n."')";
						$search .= ")";
						echo $seach;
						$where = $search;
						$order = "time";
					} else {
						$message = $lang['query_lenght'];
						$title_text = $lang['error'];
					}
				} else {
					$message = $lang['no_query'];
					$title_text = $lang['error'];
				}
			break;
			
			default: // samostatna rubrika
				$sql = "SELECT * 
					FROM bloq_topic 
					WHERE topic_name = '".$type."'";
				$data = mysql_query($sql, $link);
				$sql_num += 1;
				if (mysql_num_rows($data) != "0") { // rubrika nalezena
					$result = mysql_fetch_array($data);
					$view = "index";
					$where = "AND post_topic = '".$result['topic_id']."'";
					$order = "time";
					$title_text = $lang['posts_from_topic']." ".$result['topic_name'];
					$header = $result['topic_name'];
				} else {
					$message = $lang['no_topic'];
					$title_text = $lang['error'];
				}
			break;
		}
	}
}

if (!isset($view) AND !isset($message)) {
	$view = "index";
	$where = "AND post_time <= '".time()."'";
	$order = "time";
	$title_text = $lang['last_ten_posts'];
	$header = $lang['main_page'];
}

$sql_top = "SELECT * 
	FROM bloq_topic 
	ORDER BY topic_id";
$data_top = mysql_query($sql_top, $link);
$sql_num += 1;

$meta = (isset($message)) ? "\t<meta http-equiv=\"refresh\" content=\"3;url=".getenv("HTTP_REFERER")."\">\n" : "";

///////////// YOU CAN EDIT BELLOW THIS LINE
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $bloq['web_lang']; ?>" lang="<?php echo $bloq['web_lang']; ?>">

  <head>
	<title><?php echo $header." - ".$bloq['web_name']; ?></title>
<?php echo $meta; ?>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $lang['charset']; ?>" />
	<meta http-equiv="Content-language" content="<?php echo $bloq['web_lang']; ?>" />
	<meta name="keywords" content="<?php echo $bloq['web_keywords']; ?>" />
	<meta name="description" content="<?php echo $bloq['web_description']; ?>" />
	<meta name="author" content="All: <?php echo $bloq['author_name']; ?> [<?php echo $bloq['author_nick']; ?>]; mailto:<?php echo $bloq['author_email']; ?>" />
	<meta name="author" content="Powered by bloq - keep it simple; http://bloq.bloq.cz/" />
	<meta name="copyright" content="<?php echo $bloq['author_name']; ?> [<?php echo $bloq['author_nick']; ?>]" />
	<meta http-equiv="reply-to" content="<?php echo $bloq['author_email']; ?>" />
	
	<link rel="top" href="<?php echo $bloq['web_url']; ?>index.php" title="<?php lang("main_page"); ?>" />
	<link rel="author" href="<?php echo $bloq['web_url']; ?>index.php?type=author" title="<?php lang("author"); ?>" />

	<style type="text/css" media="screen">
  	  @import url('<?php echo $bloq['web_url']; ?>bloq.css');
	</style>
	
  </head>
  
  <body>
    <div id="page">
	  <div id="bloq">
	  	<div id="menu">
		  <div><h1 class="h1"><span class="b">&gt;</span><a href="<?php echo $bloq['web_url']; ?>" title="<?php echo $bloq['web_name']; ?>"><?php echo $bloq['web_name']; ?></a>: <?php echo $header; ?></h1></div>
		</div>
		<div style="border-right: 1px dotted #6699ff;">
		  <div class="topics">#<?php lang("topics"); ?></div>
		  <div class="menu_line">
		    <div class="second"><?php
while ($result_top = mysql_fetch_array($data_top)) {
	echo "<a href=\"".$bloq['web_url']."index.php?type=".$result_top['topic_name']."\" title=\"".$result_top['topic_name']."\">".$result_top['topic_name']."</a> + ";
}
?></div>
		  </div>
		</div>
		<div style="border-right: 1px dotted #6699ff;">
		  <div class="menu">#<?php lang("menu"); ?></div>
		  <div class="menu_line">
		    <div class="first"><a href="<?php echo $bloq['web_url']; ?>index.php?type=author" title="<?php lang("author_about"); ?>"><?php lang("author_about"); ?></a> + <a href="<?php echo $bloq['web_url']; ?>index.php?type=weblog" title="<?php lang("blog_about"); ?>"><?php lang("blog_about"); ?></a> + <strong><a href="<?php echo $bloq['web_url']; ?>index.php?type=links" title="<?php lang("links"); ?>"><?php lang("links"); ?></a> + <a href="<?php echo $bloq['web_url']; ?>index.php?type=archiv" title="<?php lang("archive"); ?>"><?php lang("archive"); ?></a> + <a href="<?php echo $bloq['web_url']; ?>" title="<?php lang("main_page"); ?>"><?php lang("main_page"); ?></a></strong> +</div>
		  </div>
		</div>
		<div style="margin-bottom: 5px;border-bottom: 1px solid #888888;border-right: 1px dotted #6699ff;">
		  <div class="info">#<?php lang("info"); ?></div>
		  <div class="menu_line">
		    <div class="third"><a href="<?php echo $bloq['web_url']; ?>rss.php" title="RSS 0.9">RSS 0.9</a> + <a href="<?php echo $bloq['web_url']; ?>rss2.php" title="RSS 2.0">RSS 2.0</a> + <a href="<?php echo $bloq['web_url']; ?>rdf.php" title="RDF">RDF</a> + <a href="http://validator.w3.org/check/referer" title="Valid XHTML 1.0">XHTML 1.0</a> + <a href="http://www.w3.org/TR/CSS2/" title="Using CSS 2.0">CSS 2.0</a> + <strong>powered by <a href="http://bloq.bloq.cz/" title="Powered by bloq">bloq</a></strong> +</div>
		  </div>
		</div>
		<form action="<?php echo $bloq['web_url']; ?>index.php?type=search" method="post"><div class="search"><input type="text" name="query" size="15" /><input type="submit" value="<?php lang("search"); ?>" /></div></form>
		<div class="title_text">#<?php echo $title_text; ?></div>

<?php
if (isset($message)) {
?>
		<div class="error"><?php echo $message; ?></div>
<?php 
} else {
	switch($view) {
			
			
		///////////// MAIN PAGE | HL. STRANA - PLEASE BE CAREFULL ABOUT THE PHP CODE WHEN CHANGING THE DESING
		case "index":
			if ($type == "archiv") {
				$limit = "";
			} else {
				$limit = " LIMIT ".($bloq['limit_posts']+11);
				$lim = $bloq['limit_posts'];
			}
			$sql = "SELECT DISTINCT * 
				FROM bloq_post 
				WHERE post_publicated = '1' ".$where." AND post_topic > '0' 
				ORDER BY post_".$order." DESC".$limit."";
			$data = mysql_query($sql, $link);
			$sql_num += 1;
			$count = mysql_num_rows($data);
			if ($type == "archiv") {
				$lim = $count;
			}
			if ($count == "0") {
?>
		<div class="error"><?php lang("nothing_found"); ?></div>
<?php
			} else {
			$i = "1";
			while ($result = mysql_fetch_object($data) AND ($i <= $lim)) {
				$id = $result->post_id;
				$postdata = get_postdata($id);
				$result1 = get_topic($id);
				$comments_num = get_comm($id);
				if ("1" < $comments_num AND $comments_num < "5") {
					$comm = $comments_num." ".$lang['comm24'];
				} elseif ($comments_num > "4" OR $comments_num == "0") {
					$comm = $comments_num." ".$lang['comm5'];
				} else {
					$comm = $comments_num." ".$lang['comm1'];
				}
				$day = date("l, j. F y",$postdata['post_time']);
				$date = the_date();
				if ($date != "" AND $i != "1") {
?>
		</div>
<?php
				}
				if ($date != "") {
?>
		<div class="group">
		  <h2 class="group_title"><?php echo $lang['day'.date("w", $postdata['post_time'])].", ".date("j", $postdata['post_time']).". ".$lang['month'.date("n", $postdata['post_time'])]." ".date("Y", $postdata['post_time']); ?></h2>
<?php
				}
?>
		  <div class="item"><a name="prispevek<?php echo $postdata['post_id']; ?>"></a>
		    <div class="item_time"><a href="<?php echo $bloq['web_url']."index.php?type=".$result1['topic_name']; ?>" title="<?php echo $result1['topic_name']; ?>"><?php echo $result1['topic_name']; ?></a>:<?php echo date("H:i", $postdata['post_time']); ?></div>
		    <div class="item_content"><h3 class="item_title"><?php echo $postdata['post_title']; ?></h3><?php echo format_to_view($postdata['post_text']); ?></div>
			<div class="item_info"><a href="mailto:<?php echo $bloq['author_email']; ?>" title="<?php echo $bloq['author_name']; ?>"><?php echo $bloq['author_name']; ?></a> + <a href="<?php echo $bloq['web_url']."index.php?type=archiv&amp;post=".date("Y", $postdata['post_time']).date("m", $postdata['post_time'])."#prispevek".$postdata['post_id'].""; ?>"><?php lang("perm_link"); ?></a> + <a href="<?php echo $bloq['web_url']."index.php?type=".$result1['topic_name']."&amp;post=".$postdata['post_id']."#komentare"; ?>" title="<?php lang("add_view_comm"); ?>"><?php echo $comm; ?></a> #</div>
		  </div>
<?php
				if ($i == ($count-11) AND !isset($comments)) {
?>
		</div>
<?php
				}
				if (isset($comments)) {
?>
		<div class="group">
		  <h2 class="group_title"><a name="komentare"></a><?php echo strtolower($lang['comments']); ?></h2>
		  <div class="item">
<?php
					if ($postdata['post_comment'] == "1") {
						$sql_comm = "SELECT * 
							FROM bloq_comment 
							WHERE comment_post_id = '".$postdata['post_id']."' 
							ORDER BY comment_time";
						$data_comm = mysql_query($sql_comm, $link);
						$sql_num += 1;
						if (mysql_num_rows($data_comm) != "0") {
							$i = "1";
							$k = "1";
							while ($result_comm = mysql_fetch_array($data_comm)) {
								$email = ($result_comm['comment_email'] != "") ? " - <a href=\"mailto:".htmlspecialchars(stripslashes($result_comm['comment_email']))."\" title=\"".htmlspecialchars(stripslashes($result_comm['comment_email']))."\">".$lang["email"]."</a>" : "";
								$url = ($result_comm['comment_url'] != "") ? " - <a href=\"".htmlspecialchars(stripslashes($result_comm['comment_url']))."\" title=\"".htmlspecialchars(stripslashes($result_comm['comment_url']))."\">".$lang["web"]."</a>" : "";
								$i = ($i == "3") ? "1" : $i;
								$class = ($i == "1") ? "1" : "2";
?>
			<div class="rows<?php echo $class; ?>"><?php echo "<strong>".$k.") ".htmlspecialchars(stripslashes($result_comm['comment_author'])).$email.$url." - </strong>".date("j.n.Y, H:i", $result_comm['comment_time']).""; ?>
			<div><?php echo make_clickable(stripslashes($result_comm['comment_content'])); ?></div></div>
<?php
								$i++;
								$k++;
							}
						} else {
?>
			<div style="padding-top: 10px;"><em><?php lang("no_comment"); ?></em></div>
<?php
						}
					} else {
?>
			<div style="padding-top: 10px;"><em><?php lang("comments_disabled"); ?></em></div>
<?php
					}
?>
		  </div>
		</div>
<?php
					if ($postdata['post_comment'] == "1") {
?>
		<div class="group">
		  <h2 class="group_title"><?php echo strtolower($lang['add']." ".$lang['comment']); ?></h2>
		  <div class="item">
		    <h4>P�idat nov� koment��</h4>
		    <form action="<?php echo $bloq['web_url']; ?>index.php?type=comment" method="post">
		    <fieldset><legend><?php lang("user_info"); ?></legend>
		      <div><label for="comment_author"><span class="b">&gt;</span><strong><?php lang("name"); ?></strong></label> <input type="text" id="comment_author" name="comment_author" value="<?php echo $HTTP_COOKIE_VARS['bloq_name']; ?>" size="30" /></div>
		      <div><label for="comment_email"><span class="b">&gt;</span><?php lang("email"); ?></label> <input type="text" id="comment_email" name="comment_email" value="<?php echo $HTTP_COOKIE_VARS['bloq_email']; ?>" size="30" /></div>
		      <div><label for="comment_url"><span class="b">&gt;</span><?php lang("web"); ?></label> <input type="text" id="comment_url" name="comment_url" value="<?php echo $HTTP_COOKIE_VARS['bloq_url']; ?>" size="30" /></div>
			  <div class="small"><?php lang("note_cookie"); ?></div>
		    </fieldset>
		    <fieldset><legend><?php lang("comment"); ?></legend>
		      <div><textarea name="comment_content" cols="65" rows="10"><?php echo $HTTP_COOKIE_VARS['bloq_comment']; ?></textarea></div>
			  <div class="small"><?php lang("note_comment"); ?></div>
		      <div><input type="submit" value=" <?php lang("comment_leave"); ?> " /> <input type="reset" value=" <?php echo ucfirst($lang['reset']); ?> " /></div>
		    </fieldset>
			<input type="hidden" name="post" value="<?php echo $postdata['post_id']; ?>" />
			</form>
		  </div>
		</div>
<?php
					}
				}
				$i++;
				unset($result, $comments_num, $result1);
			}
			
			if ($type == "" AND $count > "10") {
			?>
		<div class="group">
		  <h2 class="group_title"><?php lang("older_posts"); ?></h2>
		  <div class="item"><ul>
<?php
			while ($result = mysql_fetch_object($data) AND ($i <= ($bloq['limit_posts']+11))) {
				$id = $result->post_id;
				$postdata = get_postdata($id);
?>
		    <li><a href="<?php echo $bloq['web_url']."index.php?type=archiv&amp;type=".date("Ym", $postdata['post_time'])."#prispevek".$postdata['post_id']; ?>" title="<?php echo $postdata['post_title']; ?>"><?php echo $postdata['post_title']; ?></a> (<?php echo date("j.n.Y - H:i", $postdata['post_time']); ?>)</li>
<?php
				$i++;
			}
?>
		  </ul><a href="<?php echo $bloq['web_url']; ?>index.php?type=archiv" title="<?php lang("posts_archive"); ?>"><?php lang("posts_archive"); ?></a></div>
		</div>
<?php
			}
			}
		break;

		break;
		
		
		///////////// ARCHIVE | ARCHIV
		case "archive":
			$sql = "SELECT post_time 
				FROM bloq_post 
				WHERE post_publicated = '1' AND post_time < '".time()."' 
				ORDER BY post_time DESC";
			$data = mysql_query($sql, $link);
			$sql_num += 1;
?>
		<div class="group">
		  <h2 class="group_title"><?php lang("archive_list"); ?></h2>
		  <div class="item">
		    <div class="item_content">
			  <h3 class="item_title"><?php lang("archive_posts"); ?></h3>
			  <ul>
<?php
			while ($result = mysql_fetch_array($data)) {
				$month = date("n", $result['post_time']);
				$the_month = the_month();
				if ($the_month != "") {
?>
			    <li><a href="<?php echo $bloq['web_url']."index.php?type=archiv&amp;post=".date("Ym", $result['post_time']); ?>" title="<?php echo $lang['from_month']." ".$lang['month'.$month].", ".$lang['year']." ".date("Y", $result['post_time']); ?>"><?php echo $lang['from_month']." ".$lang['month'.$month].", ".$lang['year']." ".date("Y", $result['post_time']); ?></a></li>
<?php
				}
			}
?>
			  </ul>
			</div>
		  </div>
		</div>
<?php
		break;
		
		
		///////////// AUTHOR | AUTOR
		case "author":
?>
		<div class="group">
		  <h2 class="group_title"><?php echo $header; ?></h2>
		  <div class="item">
		    <div class="item_content">
			  <p>Autor</p>
			  <p>Author</p>
			</div>
		  </div>
		</div>
<?php
		break;
		
		
		///////////// LINKS | ODKAZY
		case "links":
?>
		<div class="group">
		  <h2 class="group_title"><?php echo $header; ?></h2>
		  <div class="item">
		    <div class="item_content">
			  <p>Odkazy</p>
			  <p>Links</p>
		  </div>
		</div>
<?php
		break;
		
		
		///////////// WEBLOG | WEBLOG
		case "weblog":
?>
		<div class="group">
		  <h2 class="group_title"><?php echo $header; ?></h2>
		  <div class="item">
		    <div class="item_content">
			  <p>O tomto weblogu</p>
			  <p>About this weblog</p>
			</div>
		  </div>
		</div>
<?php
		break;
	}
}

///////////// PLEASE, DO NOT REMOVE THE COPYRIGHT. CHANGE IT WHATEVER YOU WANT, BUT KEEP IT ON THE PAGE;-)
?>
	    <div class="copyright">
	      powered by <span class="b">&gt;</span><a href="http://bloq.bloq.cz/" title="bloq">bloq</a> <?php echo $bloq['bloq_version']; ?> - keep it simple | copyright <span class="b">&gt;</span><a href="http://www.bloq.cz" title="nebko">nebko</a> 2003
	    </div>
	  </div>
    </div>
	<!-- PAGE GENERATED IN <?php timer_stop(1) ?> seconds | NUMBER OF SQL QUERIES <?php echo $sql_num; ?> -->
    <!-- GENERATED BY bloq<?php echo $bloq['bloq_version']; ?> - keep it simple | http://bloq.bloq.cz/ -->
  </body>
</html>