<?php

$page['path'] = "./";

include ($page['path']."files/mainfile.php");

header ("Cache-Control: private, pre-check=0, post-check=0, max-age=0");
header ("Expires: ".gmdate("D, d M Y H:i:s", time())." GMT");
header ("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header ("Content-type: text/html; charset=".$lang['charset']."");

$do = isset($HTTP_POST_VARS['do']) ? $HTTP_POST_VARS['do'] : $HTTP_GET_VARS['do'];
$action = isset($HTTP_POST_VARS['action']) ? $HTTP_POST_VARS['action'] : $HTTP_GET_VARS['action'];

if (isset($HTTP_COOKIE_VARS['bloq_login']) AND ($HTTP_COOKIE_VARS['bloq_login'] != "")) {

	if ($do == "logout") { // odhlasit
		setcookie("bloq_login");
		$message1 = $lang['login_logedOut'];
		$header = $lang['logout'];
	} else { // prodlouzit cookie
		$vars = $HTTP_COOKIE_VARS['bloq_login'];
		if (substr($vars, "0", "32") == $bloq['author_login'] AND substr($vars, "-32", "32") == $bloq['author_pass']) {
			setcookie("bloq_login", $HTTP_COOKIE_VARS['bloq_login'], time()+3600);
		} else {
			die ($lang['err_hacking']);
		}
	}

	if (isset($action)) {
		switch($action) {
			
//////////// RUBRIKY
			
			case "topic":
				if (isset($HTTP_POST_VARS['topic_add'])) { // pridat rubriku
					$topic_new = $HTTP_POST_VARS['topic_new'];
					if ($topic_new != "") {
						$sql = "SELECT * 
							FROM bloq_topic 
							WHERE topic_name = '".addslashes($topic_new)."'";
						$data = mysql_query($sql, $link);
						$sql_num += 1;
						if (mysql_num_rows($data) == "0") { // overeni neduplicity
							$sql = "INSERT INTO bloq_topic 
								VALUES ('', '".addslashes($topic_new)."')";
							$data = mysql_query($sql, $link); // pridani
							$sql_num += 1;
							if ($data) {
								$message1 = $lang['topic_addedOk'];
								$header = $lang['topic'];
							} else {
								$message2 = $lang['topic_notAdded'];
								$header = $lang['error'];
							}
						} else {
							$message2 = $lang['topic_dupl'];
							$header = $lang['error'];
						}
					} else {
						$message2 = $lang['topic_noName'];
						$header = $lang['error'];
					}
				} elseif (isset($HTTP_POST_VARS['topic_del']) AND isset($HTTP_POST_VARS['topic_list']) AND ($HTTP_POST_VARS['topic_list'] != "-1")) { // smazat rubriku
					$topic_list = $HTTP_POST_VARS['topic_list'];
					if ($topic_list != "1") {
						if (isset($HTTP_POST_VARS['topic_del_new']) AND ($HTTP_POST_VARS['topic_del_new'] != "-1")) {
							$sql = "UPDATE bloq_post 
								SET post_topic = '".$HTTP_POST_VARS['topic_del_new']."' 
								WHERE post_topic = '".$topic_list."'";
							$data = mysql_query($sql, $link);
							$sql_num += 1;
							$sql1 = "DELETE FROM bloq_topic 
								WHERE topic_id = '".$topic_list."'";
							$data1 = mysql_query($sql1, $link);
							$sql_num += 1;
							if ($data1  AND $data ) {
								$message1 = $lang['topic_delOk'];
								$header = $lang['topic'];
							} else {
								$message2 = $lang['topic_notDel'];
								$header = $lang['error'];
							}
						} else {
							$view = "submit_box";
							$type['0'] = "topic";
							$type['1'] = "del";
							$header = $lang['del']." ".$lang['topics2'];
						}
					} else {
						$message2 = $lang['topic_main'];
						$header = $lang['error'];
					}
				} elseif (isset($HTTP_POST_VARS['topic_rename']) AND isset($HTTP_POST_VARS['topic_list'])) { // prejmenovat rubriku
					$topic_list = $HTTP_POST_VARS['topic_list'];
					if (isset($HTTP_POST_VARS['topic_rename_new'])) {
						$sql = "SELECT * 
							FROM bloq_topic 
							WHERE topic_name = '".addslashes($HTTP_POST_VARS['topic_rename_new'])."'";
						$data = mysql_query($sql, $link);
						$sql_num += 1;
						if (mysql_num_rows($data) == "0") {
							$sql = "UPDATE bloq_topic 
								SET topic_name = '".addslashes($HTTP_POST_VARS['topic_rename_new'])."' 
								WHERE topic_id = '".$topic_list."'";
							$data = mysql_query($sql, $link);
							$sql_num += 1;
							if ($data) {
								$message1 = $lang['topic_renameOk'];
								$header = $lang['topic'];
							} else {
								$message2 = $lang['topic_notRename'];
								$header = $lang['error'];
							}
						} else {
							$message2 = $lang['topic_dupl'];
							$header = $lang['error'];
						}
					} else {
						$view = "submit_box";
						$type['1'] = "rename";
						$header = $lang['rename']." ".$lang['topics2'];
					}
				} else { // zadna akce
					$message2 = $lang['no_action'];
					$header = $lang['error'];
				}
			break;
			
//////////// PRISPEVKY
			
			case "post":
				if (isset($HTTP_POST_VARS['post_add']) OR isset($HTTP_POST_VARS['post_save'])) { // pridat ci ulozit prispevek
					if (($HTTP_POST_VARS['post_title'] != "") AND ($HTTP_POST_VARS['post_text'] != "") AND ($HTTP_POST_VARS['post_day'] != "") AND ($HTTP_POST_VARS['post_month'] != "") AND ($HTTP_POST_VARS['post_year'] != "") AND ($HTTP_POST_VARS['post_time'] != "")) {
						$time = explode(":", $HTTP_POST_VARS['post_time']);
						$post_time = mktime($time[0], $time[1], $time[2], $HTTP_POST_VARS['post_month'], $HTTP_POST_VARS['post_day'], $HTTP_POST_VARS['post_year']);
						$post_title = addslashes($HTTP_POST_VARS['post_title']);
						$post_text = format_to_post($HTTP_POST_VARS['post_text']);
						$post_topic = ((isset($HTTP_POST_VARS['post_topic'])) AND ($HTTP_POST_VARS['post_topic'] != "-1")) ? $HTTP_POST_VARS['post_topic'] : "1";
						$post_autobr = (isset($HTTP_POST_VARS['post_autobr'])) ? $HTTP_POST_VARS['post_autobr'] : "0";
						$post_macros = (isset($HTTP_POST_VARS['post_macros'])) ? $HTTP_POST_VARS['post_macros'] : "0";
						$post_comment = (isset($HTTP_POST_VARS['post_comment'])) ? $HTTP_POST_VARS['post_comment'] : "0";
						$post_published = (isset($HTTP_POST_VARS['post_save'])) ? "0" : "1";
						$sql = "INSERT INTO bloq_post 
							VALUES ('', '".$post_title."', '".$post_text."', '".$post_time."', '".$post_topic."', '".$post_autobr."', '".$post_comment."', '".$post_macros."', '".$post_published."')";
						$data = mysql_query($sql, $link);
						$sql_num += 1;
						if ($data) {
							$message1 = $lang['post_addedOk'];
							$header = $lang['post'];
						} else {
							$message2 = $lang['post_notAdded'];
							$header = $lang['error'];
						}
					} else {
						$message2 = $lang['post_notAllData'];
						$header = $lang['error'];
					}
				} elseif(isset($HTTP_POST_VARS['post_edi']) OR isset($HTTP_GET_VARS['post_edi'])) { // upravit prispevek
					if (isset($HTTP_GET_VARS['id'])) {
						$id = $HTTP_GET_VARS['id'];
					} elseif (isset($HTTP_POST_VARS['post_saved'])) {
						$id = $HTTP_POST_VARS['post_saved'];
					} elseif (isset($HTTP_POST_VARS['post_select'])) {
						$id = $HTTP_POST_VARS['post_select'];
					}
					if (isset($HTTP_POST_VARS['id'])) {
						if (($HTTP_POST_VARS['post_title'] != "") AND ($HTTP_POST_VARS['post_text'] != "") AND ($HTTP_POST_VARS['post_day'] != "") AND ($HTTP_POST_VARS['post_month'] != "") AND ($HTTP_POST_VARS['post_year'] != "") AND ($HTTP_POST_VARS['post_time'] != "")) {
							$time = explode(":", $HTTP_POST_VARS['post_time']);
							$post_time = mktime($time[0], $time[1], $time[2], $HTTP_POST_VARS['post_month'], $HTTP_POST_VARS['post_day'], $HTTP_POST_VARS['post_year']);
							$post_title = addslashes($HTTP_POST_VARS['post_title']);
							$post_text = format_to_post($HTTP_POST_VARS['post_text']);
							$post_topic = ((isset($HTTP_POST_VARS['post_topic'])) AND ($HTTP_POST_VARS['post_topic'] != "-1")) ? $HTTP_POST_VARS['post_topic'] : "1";
							$post_autobr = (isset($HTTP_POST_VARS['post_autobr'])) ? $HTTP_POST_VARS['post_autobr'] : "0";
							$post_macros = (isset($HTTP_POST_VARS['post_macros'])) ? $HTTP_POST_VARS['post_macros'] : "0";
							$post_comment = (isset($HTTP_POST_VARS['post_comment'])) ? $HTTP_POST_VARS['post_comment'] : "0";
							$post_published = (isset($HTTP_POST_VARS['post_publcated'])) ? $HTTP_POST_VARS['post_publicated'] : "0";
							$sql = "UPDATE bloq_post 
								SET post_time = '".$post_time."', post_title = '".$post_title."', post_text = '".$post_text."', post_topic = '".$post_topic."', post_autobr = '".$post_autobr."', post_macros = '".$post_macros."', post_comment = '".$post_comment."', post_publicated = '".$post_publicated."' 
								WHERE post_id = '".$HTTP_POST_VARS['id']."'";
							$data = mysql_query($sql, $link);
							$sql_num += 1;
							if ($data) {
								$message1 = $lang['post_ediOk'];
								$header = $lang['post'];
							} else {
								$message2 = $lang['post_notEdi'];
								$header = $lang['error'];
							}
						} else {
							$message2 = $lang['post_notAllData'];
							$header = $lang['error'];
						}
					} elseif(isset($id)) {
						$view = "submit_box";
						$type['0'] = "post";
						$type['1'] = "edi";
						$header = $lang['edi']." ".$lang['post'];
					} else {
						$message2 = $lang['post_noId'];
						$header = $lang['error'];
					}
				} elseif(isset($HTTP_POST_VARS['post_publ']) OR isset($HTTP_GET_VARS['post_publ'])) { // publikovat ulozeny prispevek
					$id = (isset($HTTP_GET_VARS['id'])) ? $HTTP_GET_VARS['id'] : $HTTP_POST_VARS['post_saved'];
					if (isset($HTTP_POST_VARS['id']) AND ($HTTP_POST_VARS['post_day'] != "") AND ($HTTP_POST_VARS['post_month'] != "") AND ($HTTP_POST_VARS['post_year'] != "") AND ($HTTP_POST_VARS['post_time'] != "")) {
						$time = explode(":", $HTTP_POST_VARS['post_time']);
						$post_time = mktime($time[0], $time[1], $time[2], $HTTP_POST_VARS['post_month'], $HTTP_POST_VARS['post_day'], $HTTP_POST_VARS['post_year']);
						$sql = "UPDATE bloq_post 
							SET post_time = '".$post_time."', post_publicated = '1' 
							WHERE post_id = '".$HTTP_POST_VARS['id']."'";
						$data = mysql_query($sql, $link);
						$sql_num += 1;
						if ($data) {
							$message1 = $lang['post_publOk'];
							$header = $lang['post'];
						} else {
							$message2 = $lang['post_notPubl'];
							$header = $lang['error'];
						}
					} elseif(isset($id)) {
						$view = "submit_box";
						$type['1'] = "publ";
						$header = $lang['publ']." ".$lang['post'];
					} else {
						$message2 = $lang['post_noId'];
						$header = $lang['error'];
					}
				} elseif(isset($HTTP_GET_VARS['post_del']) OR isset($HTTP_POST_VARS['post_del'])) { // smazat prispevek
					if (isset($HTTP_GET_VARS['id'])) {
						$id = $HTTP_GET_VARS['id'];
					} elseif (isset($HTTP_POST_VARS['post_saved'])) {
						$id = $HTTP_POST_VARS['post_saved'];
					} elseif (isset($HTTP_POST_VARS['post_select'])) {
						$id = $HTTP_POST_VARS['post_select'];
					}
					if (isset($id) AND isset($HTTP_GET_VARS['ok'])) {
						$sql = "DELETE FROM bloq_comment 
							WHERE comment_post_id = '".$HTTP_GET_VARS['id']."'";
						$data = mysql_query($sql, $link);
						$sql_num += 1;
						$sql1 = "DELETE FROM bloq_post 
							WHERE post_id = '".$HTTP_GET_VARS['id']."'";
						$data1 = mysql_query($sql1, $link);
						$sql_num += 1;
						if ($data AND $data1) {
							$message1 = $lang['post_delOk'];
							$header = $lang['post'];
						} else {
							$message2 = $lang['post_notDel'];
							$header = $lang['error'];
						}
					} elseif(isset($id)) {
						$view = "submit_box";
						$type['0'] = "post";
						$type['1'] = "del";
						$header = $lang['del']." ".$lang['post'];
					} else {
						$message2 = $lang['post_noId'];
						$header = $lang['error'];
					}
				} elseif(isset($HTTP_GET_VARS['post_view']) OR isset($HTTP_POST_VARS['post_view'])) { // zobrazit prispevek
					if (isset($HTTP_GET_VARS['id'])) {
						$id = $HTTP_GET_VARS['id'];
					} elseif (isset($HTTP_POST_VARS['post_saved'])) {
						$id = $HTTP_POST_VARS['post_saved'];
					} elseif (isset($HTTP_POST_VARS['post_select'])) {
						$id = $HTTP_POST_VARS['post_select'];
					}
					if (isset($id)) {
						$view = "submit_box";
						$type['1'] = "view";
						$header = $lang['view']." ".$lang['post'];
					} else {
						$message2 = $lang['post_noId'];
						$header = $lang['error'];
					}
				} else { // zadna akce
					$message2 = $lang['no_action'];
					$header = $lang['error'];
				}
			break;
			
//////////// KOMENTARE
			
			case "comment":
				if (isset($HTTP_GET_VARS['comment_del'])) { // smazat komentar
					if (isset($HTTP_GET_VARS['id']) AND isset($HTTP_GET_VARS['ok'])) {
						$sql = "DELETE FROM bloq_comment 
							WHERE comment_id = '".$HTTP_GET_VARS['id']."'";
						$data = mysql_query($sql, $link);
						$sql_num += 1;
						if ($data) {
							$message1 = $lang['comment_delOk'];
							$header = $lang['comments'];
						} else {
							$message2 = $lang['comment_notDel'];
							$header = $lang['error'];
						}
					} elseif(isset($HTTP_GET_VARS['id'])) {
						$view = "submit_box";
						$type['0'] = "comment";
						$type['1'] = "del";
						$header = $lang['del']." ".$lang['comment'];
					} else {
						$message2 = $lang['comment_noId'];
						$header = $lang['error'];
					}
				} elseif (isset($HTTP_POST_VARS['comment_edi']) OR isset($HTTP_GET_VARS['comment_edi'])) { // upravit kometar
					if (isset($HTTP_POST_VARS['id'])) {
						if (($HTTP_POST_VARS['comment_author'] != "") AND ($HTTP_POST_VARS['comment_content'] != "")) {
							if ($HTTP_POST_VARS['comment_email'] != "") {
								if (validate_email($HTTP_POST_VARS['comment_email'])) {
									$email = " , comment_email = '".$HTTP_POST_VARS['comment_email']."'";
								} else {
									$message .= $lang['email_notValid'];
								}
							}
							if ($HTTP_POST_VARS['comment_url'] != "") {
								if (validate_url($HTTP_POST_VARS['comment_url'])) {
									$url = " , comment_url = '".$HTTP_POST_VARS['comment_url']."'";
								} else {
									
									$message .= (isset($message) ? "<br />" : "").$lang['url_notValid'];
								}
							}
							if (!isset($message)) {
								$sql = "UPDATE bloq_comment 
									SET comment_author = '".$HTTP_POST_VARS['comment_author']."', comment_content = '".$HTTP_POST_VARS['comment_content']."'".$email.$url." 
									WHERE comment_id = '".$HTTP_POST_VARS['id']."'";
								$data = mysql_query($sql, $link);
								$sql_num += 1;
								if ($data) {
									$message1 = $lang['comment_ediOk'];
									$header = $lang['comments'];
								} else {
									$message2 = $lang['comment_notEdi'];
									$header = $lang['error'];
								}
							} else {
								$message2 = $message;
								$header = $lang['error'];
							}
						} else {
							$message2 = $lang['comment_notAllData'];
							$header = $lang['error'];
						}
					} elseif (isset($HTTP_GET_VARS['id'])) {
						$view = "submit_box";
						$type['0'] = "comment";
						$type['1'] = "edi";
						$header = $lang['edi']." ".$lang['comment'];
					} else {
						$message2 = $lang['comment_noId'];
						$header = $lang['error'];
					}
				} else { // zadna akce
					$message2 = $lang['no_action'];
					$header = $lang['error'];
				}
			break;
			
//////////// KONFIGURACE
			
			case "config":
				$needed = array(1 => "web_name", "web_url", "web_motto", "web_description", "web_keywords", "limit_posts", "web_lang", "author_name", "author_nick", "author_email", "img_path", "allowed_tags"); // ulozit konfiguraci
				while(list($id, $val) = each($needed)) {
					if (!isset($HTTP_POST_VARS[$val])) {
						$error = "1";
					} else {
						$sql[] = "UPDATE bloq_config 
							SET config_value = '".addslashes($HTTP_POST_VARS[$val])."' 
							WHERE config_name = '".$val."'";
					}
				}
				if (!isset($error)) {
					if (isset($HTTP_POST_VARS['author_password']) AND ($HTTP_POST_VARS['author_password'] != $lang['write_new']) AND ($HTTP_POST_VARS['author_password'] != "")) {
						$sql[] = "DELETE FROM bloq_config WHERE config_name = 'author_pass'";
						$sql[] = "INSERT INTO bloq_config VALUES ('author_pass', '".md5($HTTP_POST_VARS['author_password'])."')";
						$logout = "1";
					}
					if (isset($HTTP_POST_VARS['author_login']) AND ($HTTP_POST_VARS['author_login'] != $lang['write_new']) AND ($HTTP_POST_VARS['author_login'] != "")) {
						$sql[] = "DELETE FROM bloq_config WHERE config_name = 'author_login'";
						$sql[] = "INSERT INTO bloq_config VALUES ('author_login', '".md5($HTTP_POST_VARS['author_login'])."')";
						$logout = "1";
					}
					while(list($id, $val) = each($sql)) {
						$data = mysql_query($val, $link);
						$sql_num += 1;
						if (!$data) {
							$error = "1";
						}
					}
					if (!$error) {
						$message1 = $lang['config_updOk'];
						$header = $lang['config'];
					} else {
						$message2 = $lang['config_notUpd'];
						$header = $lang['error'];
					}
				} else {
					$message2 = $lang['conf_notAllData'];
					$header = $lang['error'];
				}
			break;
			
//////////// MAKRA
			
			case "macro":
				if (isset($HTTP_POST_VARS['macro_add'])) { // pridat makro
					if (($HTTP_POST_VARS['macro_id'] != "") AND ($HTTP_POST_VARS['macro_value'] != "")) {
						$sql = "INSERT INTO bloq_macros 
							VALUES ('".$HTTP_POST_VARS['macro_id']."', '".$HTTP_POST_VARS['macro_value']."')";
						$data = mysql_query($sql, $link);
						$sql_num += 1;
						if ($data) {
							$message1 = $lang['macro_addedOk'];
							$header = $lang['macros'];
						} else {
							$message2 = $lang['macro_notAdded'];
							$header = $lang['error'];
						}
					} else {
						$message2 = $lang['macro_notAllData'];
						$header = $lang['error'];
					}
				} elseif(isset($HTTP_POST_VARS['macro_del']) AND ($HTTP_POST_VARS['macro_list'] != "-1")) { // smazat makro
					if (isset($HTTP_GET_VARS['id'])) {
						$sql = "DELETE FROM bloq_macros 
							WHERE macro_id = '".$HTTP_GET_VARS['id']."'";
						$data = mysql_query($sql, $link);
						$sql_num += 1;
						if ($data) {
							$message1 = $lang['macro_delOk'];
							$header = $lang['macros'];
						} else {
							$message2 = $lang['macro_notDel'];
							$header = $lang['error'];
						}
					} elseif (isset($HTTP_POST_VARS['macro_list'])) {
						$view = "submit_box";
						$type['0'] = "macro";
						$type['1'] = "del";
						$header = $lang['del']." ".$lang['macro'];
					} else {
						$message2 = $lang['macro_noId'];
						$header = $lang['error'];
					}
				} elseif(isset($HTTP_POST_VARS['macro_edi'])) { // upravit makro
					if (isset($HTTP_POST_VARS['macro_id']) AND isset($HTTP_POST_VARS['macro_value']) and isset($HTTP_POST_VARS['id'])) {
						if (($HTTP_POST_VARS['macro_id'] != "") AND ($HTTP_POST_VARS['macro_value'] != "")) {
							$sql = "UPDATE bloq_macros 
								SET macro_id = '".$HTTP_POST_VARS['macro_id']."', macro_value = '".$HTTP_POST_VARS['macro_value']."' 
								WHERE macro_id = '".$HTTP_POST_VARS['id']."'";
							$data = mysql_query($sql, $link);
							$sql_num += "1";
							if ($data) {
								$message1 = $lang['macro_ediOk'];
								$header = $lang['macros'];
							} else {
								$message2 = $lang['macro_notEdi'];
								$header = $lang['error'];
							}
						} else {
							$message2 = $lang['macro_notAllData'];
							$header = $lang['error'];
						}
					} elseif (isset($HTTP_POST_VARS['macro_id'])) {
						$view = "submit_box";
						$type['0'] = "macro";
						$type['1'] = "edi";
						$header = $lang['edi']." ".$lang['macro'];
					} else {
						$message2 = $lang['macro_noId'];
						$header = $lang['error'];
					}
				} else { // zadna akce
					$message2 = $lang['no_action'];
					$header = $lang['error'];
				}
			break;
		}
	}

} else {
	
//////////// LOGIN
	
	if ($do == "login") {
		$nick = $pass = "";
		$nick = (isset($HTTP_POST_VARS['nickname'])) ? $HTTP_POST_VARS['nickname'] : $HTTP_GET_VARS['nickname'];
		$pass = (isset($HTTP_POST_VARS['password'])) ? $HTTP_POST_VARS['password'] : $HTTP_GET_VARS['password'];
		if ($pass != "" OR $nick != "") {
			if ($bloq['author_login'] == md5($nick) AND $bloq['author_pass'] == md5($pass)) { // overeni totoznosti
				setcookie("bloq_login", md5($nick).md5($pass), time()+3600);
				$view = "main";
				$header = $lang['main'];
			} else {
				$message2 = $lang['login_unsuccesful'];
				$header = $lang['error'];
			}
		}
	} else {
		$view = "login";
		$header = $lang['login'];
	}
}

//////////// VYPIS PRISPEVKU

if (!isset($posts)) {
	if ((isset($HTTP_POST_VARS['posts_page']) OR isset($HTTP_GET_VARS['posts_page'])) AND (($HTTP_POST_VARS['posts_page'] != "") OR ($HTTP_GET_VARS['posts_page'] != ""))) {
		$posts = (isset($HTTP_POST_VARS['posts_page'])) ? $HTTP_POST_VARS['posts_page'] : $HTTP_GET_VARS['posts_page'];
	} else {
		$posts = "10";
		$posts_page = $posts;
	}
}

//////////// POSUNOVANI VE VYPISU PRISPEVKU

$posts_from_handle = (isset($HTTP_POST_VARS['posts_from'])) ? $HTTP_POST_VARS['posts_from'] : $HTTP_GET_VARS['posts_from'];
if (isset($HTTP_POST_VARS['posts_prev'])) { // predchozi
	if ($posts_from_handle != "0") {
		$posts_from = $posts_from_handle - $posts;
	} else {
		$posts_from = "0";
	}
} elseif (isset($HTTP_POST_VARS['posts_next'])) { // dalsi
	$posts_from = $posts_from_handle + $posts;
} else {
	$posts_from = "0";
}

//////////// VYPIS KOMETARU

if (!isset($comments)) {
	if ((isset($HTTP_POST_VARS['comments']) OR isset($HTTP_GET_VARS['comments'])) AND (($HTTP_POST_VARS['comments'] != "") OR ($HTTP_GET_VARS['comments'] != ""))) {
		$comments = (isset($HTTP_POST_VARS['comments'])) ? $HTTP_POST_VARS['comments'] : $HTTP_GET_VARS['comments'];
	} else {
		$comments = "20";
	}
}

//////////// POSUNOVANI VE VYPISU KOMETARU

$comments_from_handle = (isset($HTTP_POST_VARS['comments_from'])) ? $HTTP_POST_VARS['comments_from'] : $HTTP_GET_VARS['comments_from'];
if (isset($HTTP_POST_VARS['comments_prev'])) { // predchozi
	if ($comments_from_handle != "0") {
		$comments_from = $comments_from_handle - $comments;
	} else {
		$comments_from = "0";
	}
} elseif (isset($HTTP_POST_VARS['comments_next'])) { // dalsi
	$comments_from = $comments_from_handle + $comments;
} else {
	$comments_from = "0";
}

//////////// POKUD NENI NIC URCENO

if (!isset($view) AND isset($HTTP_COOKIE_VARS['bloq_login']) AND $HTTP_COOKIE_VARS['bloq_login'] != "") {
	$view = "main";
	$header = $lang['main'];
}

//////////// VRACENI ZPET ZE ZPRAV

if (isset($message2)) {
	$back_vars = array("topic_new", "posts", "posts_from", "posts_order", "comments", "comments_from", "comments_post", "macro_id", "macro_value", "comment_author", "comment_email", "comment_url", "comment_content"); // hodnoty, kter� je t�eba vr�tit
	if (!isset($HTTP_POST_VARS['post_edi'])) {
		$back_vars[] = "post_title";
		$back_vars[] = "post_text";
	}
	
	while(list($bv_id, $val) = each($back_vars)) {
		$ins = (isset($HTTP_POST_VARS[$val])) ? $HTTP_POST_VARS[$val] : $HTTP_GET_VARS[$val];
		if ($ins != "") {
			$post_string .= "&amp;".$val."=".urlencode($ins);
		}
	}
}

if (isset($HTTP_GET_VARS['post_del'])) { // specialni pripady
	$url = "admin.php?posts_page=".$HTTP_GET_VARS['posts_page']."&amp;posts_from=".$HTTP_GET_VARS['posts_from']."&amp;posts_order=".$HTTP_GET_VARS['posts_order']."&amp;posts_topic=".$HTTP_GET_VARS['posts_topic'];
} elseif (isset($HTTP_POST_VARS['post_edi'])) {
	$url = "admin.php?posts_page=".$HTTP_POST_VARS['posts_page']."&amp;posts_from=".$HTTP_POST_VARS['posts_from']."&amp;posts_order=".$HTTP_POST_VARS['posts_order']."&amp;posts_topic=".$HTTP_POST_VARS['posts_topic'];
} elseif (isset($HTTP_GET_VARS['comment_del']) AND $HTTP_GET_VARS['comments'] == "") {
	$url = "admin.php?action=post&amp;post_view=1&amp;id=".$HTTP_GET_VARS['post_id']."&amp;posts_page=".$HTTP_GET_VARS['posts_page']."&amp;posts_from=".$HTTP_GET_VARS['posts_from']."&amp;posts_order=".$HTTP_GET_VARS['posts_order']."&amp;posts_topic=".$HTTP_GET_VARS['posts_topic'];
} elseif (isset($HTTP_GET_VARS['comment_del']) AND $HTTP_GET_VARS['comments'] != "") {
	$url = "admin.php?comments=".$HTTP_GET_VARS['comments']."&amp;comments_from=".$HTTP_GET_VARS['comments_from']."&amp;comments_post=".$HTTP_GET_VARS['comments_post'];
} elseif (isset($HTTP_POST_VARS['comment_edi']) AND isset($message1) AND $HTTP_POST_VARS['comments'] == "") {
	$url = "admin.php?action=post&amp;post_view=1&amp;id=".$HTTP_POST_VARS['post_id']."&amp;posts_page=".$HTTP_POST_VARS['posts_page']."&amp;posts_from=".$HTTP_POST_VARS['posts_from']."&amp;posts_order=".$HTTP_POST_VARS['posts_order']."&amp;posts_topic=".$HTTP_POST_VARS['posts_topic'];;
} elseif (isset($HTTP_POST_VARS['comment_edi']) AND isset($message1) AND $HTTP_POST_VARS['comments'] != "") {
	$url = "admin.php?comments=".$HTTP_POST_VARS['comments']."&amp;comments_from=".$HTTP_POST_VARS['comments_from']."&amp;comments_post=".$HTTP_POST_VARS['comments_post'];
} elseif (isset($HTTP_POST_VARS['post_publ'])) {
	$url = "admin.php";
} elseif ($logout != "") {
	$url = "admin.php?do=logout";
} else {
	$url = getenv("HTTP_REFERER");
}

$meta = (isset($message1) OR isset($message2)) ? "\t<meta http-equiv=\"refresh\" content=\"3;url=".$url.$post_string."\">\n" : "";
			
//////////// HLAVICKA
			
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $bloq['web_lang']; ?>" lang="<?php echo $bloq['web_lang']; ?>">

  <head>
	<title><?php echo $header." - "; echo $lang['admin']; ?> - <?php echo $bloq['web_name']; ?></title>
<?php echo $meta; ?>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $lang['charset']; ?>" />
	<meta http-equiv="Content-language" content="<?php echo $bloq['web_lang']; ?>" />
	<meta http-equiv="Cache-control" content="no-cache" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="Expires" content="0" />
	<meta name="robots" content="index, follow" />
	<meta name="author" content="All: <?php echo $bloq['author_name']; ?> [<?php echo $bloq['author_nick']; ?>]; mailto:<?php echo $bloq['author_email']; ?>" />
	<meta name="author" content="Powered by bloq - keep it simple; http://bloq.bloq.cz/" />
	<meta name="copyright" content="<?php echo $bloq['author_name']; ?> [<?php echo $bloq['author_nick']; ?>]" />

	<link rel="top" href="admin.php" title="<?php lang("main_page"); ?>" />
	<link rel="author" href="./author/" title="<?php lang("author"); ?>" />
	
	<style type="text/css" media="screen">
  	  @import url('admin.css');
	</style>
	
  </head>
  
  <body>
<?php
			
//////////// ZOBRAZIT ZPRAVU
			
if (isset($message1) OR isset($message2)) {
?>
	<div id="admin_box"><strong><?php echo $message1; echo $message2; ?></strong></div>
<?php
} else {
			
//////////// ZOBRAZIT MENU
			
	if ($view != "login" AND $view != "") {
?>
    <div id="obsah">
	<div id="menu_img"><a href="http://bloq.bloq.cz/" title="bloq"><img src="<?php image("bloq-logo.gif"); ?>" alt="bloq" /></a></div>
	<div id="motto">keep it simple*</div>
    <div class="line_top"></div>
	<div id="menu">
	  <span class="gt">&gt;</span><a href="admin.php?do=main" title="<?php lang("main"); ?>" class="a_menu"><?php lang("main"); ?></a>
	  <span class="gt">&gt;</span><a href="<?php echo $bloq['web_url']; ?>" title="<?php lang("main_blog"); ?>" class="a_menu"><?php lang("main_blog"); ?></a>
	  <span class="gt">&gt;</span><a href="admin.php?do=logout" title="<?php lang("logout"); ?>" class="a_menu"><?php lang("logout"); ?></a>
	</div>
  	<div class="line_bot"></div>
<?php
	}
	
	switch($view) {
			
//////////// OBSAH ADMINISTRACE
			
		case "main":
		
			$select_topic = select_topics();
		
?>
	<div class="header">::<?php echo $header; ?></div>
	<div class="nav_menu"><span class="b">&gt;</span><a href="admin.php#post_saved" title="<?php lang("post_saved"); ?>"><?php lang("post_saved"); ?></a> <span class="b">&gt;</span><a href="admin.php#post_select" title="<?php lang("post_select"); ?>"><?php lang("post_select"); ?></a> <span class="b">&gt;</span><a href="admin.php#posts" title="<?php echo strtolower($lang['posts']); ?>"><?php echo strtolower($lang['posts']); ?></a> <span class="b">&gt;</span><a href="admin.php#comments" title="<?php echo strtolower($lang['comments']); ?>"><?php echo strtolower($lang['comments']); ?></a> <span class="b">&gt;</span><a href="admin.php#macros" title="<?php echo strtolower($lang['macros']); ?>"><?php echo strtolower($lang['macros']); ?></a></div>
	<div id="box_left">
	  <div class="box_line_top"></div>
	  <div class="box_header"><span class="b">&gt;</span><?php lang("topic"); ?></div>
	  <div class="box_line_bot"></div>
	  <form action="admin.php" method="post">
	    <div class="inside">
	    <div><span class="b">&gt;</span><?php lang("new1"); ?> <input type="text" name="topic_new" value="<?php echo $HTTP_GET_VARS['topic_new']; ?>" size="30" />
		<input type="submit" name="topic_add" value="<?php lang("add"); ?>" />
		<input type="hidden" name="action" value="topic" /></div>		
		<div><span class="b">&gt;</span><?php lang("del"); ?>&amp;<?php lang("rename"); ?> 
		<select name="topic_list">
<?php
			echo $select_topic;
?>
		</select>
		<input type="submit" name="topic_del" value="<?php lang("del"); ?>" />
		<input type="submit" name="topic_rename" value="<?php lang("rename"); ?>" />
		<input type="hidden" name="action" value="topic" /></div>
	    </div>
	  </form>
	  <div class="box_line_top"></div>
	  <div class="box_header"><span class="b">&gt;</span><?php lang("post"); ?></div>
	  <div class="box_line_bot"></div>
	  <form action="admin.php" method="post">
	    <div class="inside">
		  <span class="b">&gt;</span><?php lang("title"); ?> <input type="text" name="post_title" value="<?php echo $HTTP_GET_VARS['post_title']; ?>" size="30" />
		  <span class="b">&gt;</span><?php lang("topic"); ?> 
		  <select name="post_topic">
<?php
			echo $select_topic;
?>
		  </select>
		  <div><span class="b">&gt;</span><?php lang("post"); ?></div>
		  <div><textarea name="post_text" cols="60" style="width:390px" rows="15"><?php echo $HTTP_GET_VARS['post_text']; ?></textarea></div>
		  <div><input type="checkbox" name="post_autobr" value="1" checked="checked" /> <span class="help" title="<?php lang("autobr_help"); ?>"><?php lang("autobr"); ?></span> <input type="checkbox" name="post_macros" value="1" checked="checked" /> <span class="help" title="<?php lang("macros_help"); ?>"><?php lang("macros"); ?></span> <input type="checkbox" name="post_comment" value="1" checked="checked" /> <span class="help" title="<?php lang("comments_help"); ?>"><?php lang("comments"); ?></span></div>
		  <div><span class="b">&gt;</span><span class="help" title="<?php lang("change_publDate_help"); ?>"><?php lang("change_publDate"); ?></span></div>
		  <div>
			<input type="text" name="post_day" value="<?php echo date("d", time()); ?>" size="2" />
			<select name="post_month">
<?php
			for($i = "1" ; $i < "13"; $i++) {
				if (date("n", time()) == $i) {
					$checked = "selected=\"selected\"";
				}
?>
			  <option value="<?php echo $i; ?>"<?php echo $checked; ?>><?php lang("month".$i.""); ?></option>
<?php
				unset($checked);
			}
?>
			</select> <input type="text" name="post_year" value="<?php echo date("Y", time()); ?>" size="4" />
			<input type="text" name="post_time" value="<?php echo date("H:i:s", time()); ?>" size="8" />
		  </div>
		  <div><input type="submit" name="post_add" value=" <?php lang("publ"); ?> " /> <input type="submit" name="post_save" value=" <?php lang("save"); ?> " /> <input type="reset" value=" <?php lang("reset"); ?> " /></div>
		  <input type="hidden" name="action" value="post" />
	    </div>
	  </form>
	</div>
	<div id="box_right">
	  <div class="box_line_top"></div>
	  <div class="box_header"><span class="b">&gt;</span><?php lang("stats"); ?></div>
	  <div class="box_line_bot"></div>
<?php
	$sql_post_all = "SELECT COUNT(post_id) AS sql_post_all FROM bloq_post";
	$data_post_all = mysql_query($sql_post_all, $link);
	$sql_num += 1;
	$num_post_all = mysql_fetch_array($data_post_all);
	$sql_post_publ = "SELECT COUNT(post_id) AS sql_post_publ FROM bloq_post WHERE post_publicated = '1' AND post_time < ".time()."";
	$data_post_publ = mysql_query($sql_post_publ, $link);
	$sql_num += 1;
	$num_post_publ = mysql_fetch_array($data_post_publ);
	$sql_comment = "SELECT COUNT(comment_id) AS sql_comment FROM bloq_comment";
	$data_comment = mysql_query($sql_comment, $link);
	$sql_num += 1;
	$num_comment = mysql_fetch_array($data_comment);
	$sql_topic = "SELECT COUNT(topic_id) AS sql_topic FROM bloq_topic";
	$data_topic = mysql_query($sql_topic, $link);
	$sql_num += 1;
	$num_topic = mysql_fetch_array($data_topic);
?>
	  <div class="inside_small">
	  	<fieldset><legend><?php lang("stats_publ"); ?></legend>
		  <div class="help" title="<?php lang("posts_help"); ?>"><span class="b">&gt;</span><?php lang("posts"); ?>: <strong title="<?php lang("posts_help"); ?>"><?php echo $num_post_all['sql_post_all']." | ".$num_post_publ['sql_post_publ']." | ".($num_post_all['sql_post_all']-$num_post_publ['sql_post_publ']); ?></strong></div>
		  <div><span class="b">&gt;</span><?php lang("comments"); ?>: <strong><?php echo $num_comment['sql_comment']; ?></strong> <span class="b">&gt;</span><?php echo ucfirst($lang['topics']); ?>: <strong><?php echo $num_topic['sql_topic']; ?></strong></div>
		</fieldset>
	  </div>
	  <div class="box_line_top"></div>
	  <div class="box_header"><span class="b">&gt;</span><?php lang("config"); ?></div>
	  <div class="box_line_bot"></div>
	  <form action="admin.php" method="post">
	    <div class="inside_small">
		  <fieldset><legend><?php lang("config_web"); ?></legend>
		    <div><label for="web_name" class="help" title="<?php lang("conf_web_name"); ?>"><span class="b">&gt;</span><?php lang("name"); ?></label> <input type="text" id="web_name" name="web_name" value="<?php echo $bloq['web_name']; ?>" size="15" /></div>
		    <div><label for="web_url" class="help" title="<?php lang("conf_web_url"); ?>"><span class="b">&gt;</span><?php lang("url"); ?></label> <input type="text" id="web_url" name="web_url" value="<?php echo $bloq['web_url']; ?>" size="15" /></div>
		    <div><label for="web_lang" class="help" title="<?php lang("conf_web_lang"); ?>"><span class="b">&gt;</span><?php lang("lang"); ?></label> <input type="text" id="web_lang" name="web_lang" value="<?php echo $bloq['web_lang']; ?>" size="15" /></div>
			<div><label for="web_motto" class="help" title="<?php lang("conf_web_motto"); ?>"><span class="b">&gt;</span><?php lang("motto"); ?></label> <input type="text" id="web_motto" name="web_motto" value="<?php echo $bloq['web_motto']; ?>" size="15" /></div>
			<div><label for="web_description" class="help" title="<?php lang("conf_web_desc"); ?>"><span class="b">&gt;</span><?php lang("description"); ?></label> <input type="text" id="web_description" name="web_description" value="<?php echo $bloq['web_description']; ?>" size="15" /></div>
			<div><label for="web_keywords" class="help" title="<?php lang("conf_web_keys"); ?>"><span class="b">&gt;</span><?php lang("keywords"); ?></label> <input type="text" id="web_keywords" name="web_keywords" value="<?php echo $bloq['web_keywords']; ?>" size="15" /></div>
		  </fieldset>
		  <fieldset><legend><?php lang("config_author"); ?></legend>
		    <div><label for="author_name" class="help" title="<?php lang("conf_author_name"); ?>"><span class="b">&gt;</span><?php lang("name"); ?></label> <input type="text" id="author_name" name="author_name" value="<?php echo $bloq['author_name']; ?>" size="15" /></div>
		    <div><label for="author_nick" class="help" title="<?php lang("conf_author_nick"); ?>"><span class="b">&gt;</span><?php lang("nick"); ?></label> <input type="text" id="author_nick" name="author_nick" value="<?php echo $bloq['author_nick']; ?>" size="15" /></div>
		    <div><label for="author_email" class="help" title="<?php lang("conf_author_email"); ?>"><span class="b">&gt;</span><?php lang("email"); ?></label> <input type="text" id="author_email" name="author_email" value="<?php echo $bloq['author_email']; ?>" size="15" /></div>
		    <div><label for="author_login" class="help" title="<?php lang("conf_author_login"); ?>"><span class="b">&gt;</span><?php lang("login"); ?></label> <input type="text" id="author_login" name="author_login" value="<?php lang("write_new"); ?>" size="15" /></div>
		    <div><label for="author_password" class="help" title="<?php lang("conf_author_pass"); ?>"><span class="b">&gt;</span><?php lang("pass"); ?></label> <input type="text" id="author_password" name="author_password" value="<?php lang("write_new"); ?>" size="15" /></div>
		  </fieldset>
		  <fieldset><legend><?php lang("config_other"); ?></legend>
		  	<div><label for="limit_posts" class="help" title="<?php lang("conf_other_posts"); ?>"><span class="b">&gt;</span><?php lang("limit_posts"); ?></label> <input type="text" id="limit_posts" name="limit_posts" value="<?php echo $bloq['limit_posts']; ?>" size="15" /></div>
		    <div><label for="allowed_tags" class="help" title="<?php lang("conf_other_tags"); ?>"><span class="b">&gt;</span><?php lang("allowed_tags"); ?></label> <input type="text" id="allowed_tags" name="allowed_tags" value="<?php echo $bloq['allowed_tags']; ?>" size="15" /></div>
		    <div><label for="img_path" class="help" title="<?php lang("conf_other_img"); ?>"><span class="b">&gt;</span><?php lang("img_path"); ?></label> <input type="text" id="img_path" name="img_path" value="<?php echo $bloq['img_path']; ?>" size="15" /></div>
		  </fieldset>
		  <div style="text-align:center;"><input type="submit" name="config_change" value="<?php lang("conf_change"); ?>" /></div>
		  <input type="hidden" name="action" value="config" />
		</div>
	  </form>
	</div>
	<div id="box_center">
	  <div class="box_line_top"></div>
	  <div class="box_header"><a name="post_saved"></a><span class="b">&gt;</span><?php lang("post_saved"); ?></div>
	  <div class="box_line_bot"></div>
	  <form action="admin.php" method="post">
	    <div class="inside">
<?php
			$sql = "SELECT * 
				FROM bloq_post 
				WHERE post_publicated = '0'";
			$data = mysql_query($sql, $link);
			$sql_num += 1;
			if (mysql_num_rows($data) != "0") {
?>
		<span class="b">&gt;</span><span class="help" title="<?php lang("saved_help"); ?>"><?php lang("post"); ?></span> 
		<select name="post_saved">
<?php
				while ($result = mysql_fetch_array($data)) {
					$sql1 = "SELECT topic_name 
						FROM bloq_topic 
						WHERE topic_id = '".$result['post_topic']."'";
					$data1 = mysql_query($sql1, $link);
					$sql_num += 1;
					$result1 = mysql_fetch_array($data1);
?>
		   <option value="<?php echo $result['post_id']; ?>"><?php echo $result['post_title']." (".$result1['topic_name'].") ".date("j.n.Y", $result['post_time']); ?></option>
<?php
				}
?>
		</select>
		<input type="submit" name="post_view" value=" <?php lang("view"); ?> " /> <input type="submit" name="post_publ" value=" <?php lang("publ"); ?> " /> <input type="submit" name="post_edi" value=" <?php lang("edi"); ?> " /> <input type="submit" name="post_del" value=" <?php lang("del"); ?> " />
		<input type="hidden" name="action" value="post" />
<?php
			} else {
				lang("no_savedPosts");
			}
?>
		</div>
	  </form>
	  <div class="box_line_top"></div>
	  <div class="box_header"><a name="post_select"></a><span class="b">&gt;</span><?php lang("post_select"); ?></div>
	  <div class="box_line_bot"></div>
	  <form action="admin.php" method="post">
	    <div class="inside">
		  <span class="b">&gt;</span><?php lang("id"); ?>
		  <select name="post_select">
<?php
			$sql = "SELECT * 
				FROM bloq_post 
				ORDER BY post_id";
			$data = mysql_query($sql, $link);
			$sql_num += 1;
			while ($result = mysql_fetch_array($data)) {
?>
			<option value="<?php echo $result['post_id']; ?>"><?php echo $result['post_id']." | ".((strlen($result['post_title']) <= 40) ? $result['post_title'] : substr($result['post_title'], 0, 37)."..."); ?></option>
<?php 
			}
?>
		  </select>
		  <input type="submit" name="post_del" value=" <?php lang("del"); ?> " /> <input type="submit" name="post_edi" value=" <?php lang("edi"); ?> " /> <input type="submit" name="post_view" value=" <?php lang("view"); ?> " />
		  <input type="hidden" name="action" value="post" />
		</div>
	  </form>
	  <div class="box_line_top"></div>
	  <div class="box_header"><a name="posts"></a><span class="b">&gt;</span><?php echo strtolower($lang['posts']); ?></div>
	  <div class="box_line_bot"></div>
	  <form action="admin.php" method="post">
	    <div class="inside">
		  <span class="small"><span class="b">&gt;</span><?php lang("view"); ?> 
		  <input type="text" name="posts" value="<?php echo $posts; ?>" size="2" />
		  <select name="posts_order">
		    <option value="DESC"<?php echo ($HTTP_POST_VARS['posts_order'] == "DESC" OR $HTTP_GET_VARS['posts_order'] == "DESC") ? " selected=\"selected\"" : ""; ?>><?php lang("youngest"); ?></option>
			<option value="ASC"<?php echo ($HTTP_POST_VARS['posts_order'] == "ASC" OR $HTTP_GET_VARS['posts_order'] == "ASC") ? " selected=\"selected\"" : ""; ?>><?php lang("oldest"); ?></option>
		  </select>
		  <?php lang("posts_from"); ?>
		  <select name="posts_topic">
		  	<option value="0"><?php lang("all_topics"); ?></option>
<?php
			$posts_topic = (isset($HTTP_POST_VARS['posts_topic'])) ? $HTTP_POST_VARS['posts_topic'] : $HTTP_GET_VARS['posts_topic'];
			echo $select_topic;
?>
		  </select>
		  <input type="submit" value="<?php lang("ok"); ?>" />
		  <input type="submit" name="posts_prev" value="<?php lang("prev"); echo " ".$posts ?>" />
		  <input type="submit" name="posts_next" value="<?php lang("next"); echo " ".$posts ?>" />
		  <input type="hidden" name="posts_from" value="<?php echo $posts_from; ?>" /></span>
<?php
			$order = (isset($HTTP_POST_VARS['posts_order'])) ? $HTTP_POST_VARS['posts_order'] : $HTTP_GET_VARS['posts_order'];
			$order = ($order != "") ? $order : "DESC";
			if (isset($posts_topic)) {
				$topic = ($posts_topic != "0" AND $posts_topic != "") ? "AND post_topic = '".$posts_topic."' " : "";
			}
			$sql = "SELECT * 
				FROM bloq_post 
				WHERE post_publicated = '1' ".$topic."
				ORDER BY post_time ".$order." 
				LIMIT ".$posts_from.", ".$posts."";
			$data = mysql_query($sql, $link);
			$sql_num += 1;
			$i = "1";
			while ($result = mysql_fetch_array($data)) {
				$sql1 = "SELECT topic_name 
					FROM bloq_topic 
					WHERE topic_id = '".$result['post_topic']."'";
				$data1 = mysql_query($sql1, $link);
				$sql_num += 1;
				$result1 = mysql_fetch_array($data1);
				
				$sql2 = "SELECT comment_id 
					FROM bloq_comment 
					WHERE comment_post_id = '".$result['post_id']."'";
				$data2 = mysql_query($sql2, $link);
				$sql_num += 1;
				$comments_num = mysql_num_rows($data2);
				if ("1" < $comments_num AND $comments_num < "5") {
					$comm = $comments_num." ".$lang['comm24'];
				} elseif ($comments_num > "4" OR $comments_num == "0") {
					$comm = $comments_num." ".$lang['comm5'];
				} else {
					$comm = $comments_num." ".$lang['comm1'];
				}
				$i = ($i == "3") ? "1" : $i;
				$class = ($i == "1") ? "1" : "2";
?>
	      <div class="rows<?php echo $class; ?>"><a href="index.php?type=<?php echo $result1['topic_name']; ?>&amp;post=<?php echo $result['post_id']; ?>" title="<?php echo htmlspecialchars($result['post_title']); ?>"><?php echo htmlspecialchars($result['post_title']); ?></a> <em>(<?php echo htmlspecialchars(stripslashes($result1['topic_name']))." | <span class=\"small\">"; echo date("j.n.Y - H:i:s", $result['post_time']); ?></span>)</em><br /><span class="b">&gt;</span><a href="admin.php?action=post&amp;post_view=1&amp;id=<?php echo $result['post_id']; ?>&amp;posts_page=<?php echo $posts; ?>&amp;posts_from=<?php echo $posts_from; ?>&amp;posts_order=<?php echo $order; ?>&amp;posts_topic=<?php echo $posts_topic; ?>" title="<?php echo $comm ?>"><?php echo $comm; ?></a> <span class="b">&gt;</span><a href="admin.php?action=post&amp;post_edi=1&amp;id=<?php echo $result['post_id']; ?>&amp;posts_page=<?php echo $posts; ?>&amp;posts_from=<?php echo $posts_from; ?>&amp;posts_order=<?php echo $order; ?>&amp;posts_topic=<?php echo $posts_topic; ?>" title="<?php lang("edi"); ?>"><?php lang("edi"); ?></a> <span class="b">&gt;</span><a href="admin.php?action=post&amp;post_del=1&amp;id=<?php echo $result['post_id']; ?>&amp;posts_page=<?php echo $posts; ?>&amp;posts_from=<?php echo $posts_from; ?>&amp;posts_order=<?php echo $order; ?>&amp;posts_topic=<?php echo $posts_topic; ?>" title="<?php lang("del"); ?>"><?php lang("del"); ?></a></div>
<?php
				$i++;
			}
?>
	    </div>
	  </form>
	  <div class="box_line_top"></div>
	  <div class="box_header"><a name="comments"></a><span class="b">&gt;</span><?php echo strtolower($lang['comments']); ?></div>
	  <div class="box_line_bot"></div>
	  <form action="admin.php" method="post">
	  	<div class="inside_small">
		  <span class="b">&gt;</span><?php lang("view"); ?> 
		  <input type="text" name="comments" value="<?php echo $comments; ?>" size="2" />
		  <?php lang("comments_from"); ?>
		  <select name="comments_post">
		    <option value="0"><?php lang("all_posts"); ?></option>
<?php
			$sql = "SELECT post_id, post_title 
				FROM bloq_post 
				WHERE post_comment = '1'";
			$data = mysql_query($sql, $link);
			$sql_num += 1;
			$comments_post = (isset($HTTP_POST_VARS['comments_post'])) ? $HTTP_POST_VARS['comments_post'] : $HTTP_GET_VARS['comments_post'];
			while ($result = mysql_fetch_array($data)) {
?>
			<option value="<?php echo $result['post_id']; ?>"<?php echo ($comments_post == $result['post_id']) ? " selected=\"selected\"" : ""; ?>><?php echo $result['post_id']." | ".((strlen($result['post_title']) <= 25) ? $result['post_title'] : substr($result['post_title'], 0, 22)."..."); ?></option>
<?php
			}
?>
		  </select>
		  <input type="submit" value="<?php lang("ok"); ?>" />
		  <input type="submit" name="comments_prev" value="<?php lang("prev"); echo " ".$comments ?>" />
		  <input type="submit" name="comments_next" value="<?php lang("next"); echo " ".$comments ?>" />
		  <input type="hidden" name="comments_from" value="<?php echo $comments_from; ?>" />
<?php
			if (isset($comments_post)) {
				$post = ($comments_post != "0" AND $comments_post != "") ? "WHERE comment_post_id = '".$comments_post."' " : "";
			}
			$sql = "SELECT * 
				FROM bloq_comment 
				".$post."
				ORDER BY comment_time DESC 
				LIMIT ".$comments_from.", ".$comments."";
			$data = mysql_query($sql, $link);
			$sql_num += 1;
			$i = "1";
			while ($result = mysql_fetch_array($data)) {
				$sql1 = "SELECT post_title, post_id, post_topic 
					FROM bloq_post 
					WHERE post_id = '".$result['comment_post_id']."'";
				$data1 = mysql_query($sql1, $link);
				$sql_num += 1;
				$result1 = mysql_fetch_array($data1);
				$sql2 = "SELECT topic_name 
					FROM bloq_topic 
					WHERE topic_id = '".$result1['post_topic']."'";
				$data2 = mysql_query($sql2, $link);
				$sql_num += 1;
				$result2 = mysql_fetch_array($data2);
				$i = ($i == "3") ? "1" : $i;
				$class = ($i == "1") ? "1" : "2";
				$email = (isset($result['comment_email']) AND $result['comment_email'] != "") ? " [<a href=\"mailto:".$result['comment_email']."\" title=\"".$result['comment_email']."\">email</a>]" : "";
				$web = (isset($result['comment_url']) AND $result['comment_url'] != "") ? " [<a href=\"".$result['comment_url']."\" title=\"".$result['comment_url']."\">web</a>]" : "";
?>
	      <div class="rows<?php echo $class; ?>"><?php echo "<em>".date("j.n.Y-H:i:s", $result['comment_time'])."</em>, <strong>".$result['comment_author']."</strong>".$email.$web." "; lang("to_post"); ?> <a href="index.php?type=<?php echo $result2['topic_name']; ?>&amp;post=<?php echo $result1['post_id']; ?>" title="<?php echo htmlspecialchars($result1['post_title']); ?>"><?php echo htmlspecialchars($result1['post_title']); ?></a> | <span class="b">&gt;</span><a href="admin.php?action=comment&amp;comment_edi=1&amp;id=<?php echo $result['comment_id']; ?>&amp;comments=<?php echo $comments; ?>&amp;comments_from=<?php echo $comments_from; ?>&amp;comments_post=<?php echo $comments_post; ?>" title="<?php lang("edi"); ?>"><?php lang("edi"); ?></a> <span class="b">&gt;</span><a href="admin.php?action=comment&amp;comment_del=1&amp;id=<?php echo $result['comment_id']; ?>&amp;comments=<?php echo $comments; ?>&amp;comments_from=<?php echo $comments_from; ?>&amp;comments_post=<?php echo $comments_post; ?>" title="<?php lang("del"); ?>"><?php lang("del"); ?></a></div>
<?php
				$i++;
			}
?>
		</div>
	  </form>
	  <div class="box_line_top"></div>
	  <div class="box_header"><a name="macros"></a><span class="b">&gt;</span><?php echo strtolower($lang['macros']); ?></div>
	  <div class="box_line_bot"></div>
	  <form action="admin.php" method="post">
	    <div class="inside">
		  <div><span class="b">&gt;</span><?php lang("new3"); ?> - <?php lang("id"); ?>: 
		  <input type="text" name="macro_id" value="<?php echo $HTTP_GET_VARS['macro_id']; ?>" size="15" /> 
		  <?php lang("value"); ?>: 
		  <input type="text" name="macro_value" value="<?php echo $HTTP_GET_VARS['macro_id']; ?>" size="25" /> 
		  <input type="submit" name="macro_add" value=" <?php lang("add"); ?> " />
		  <input type="hidden" name="action" value="macro" /></div>
		  <div><span class="b">&gt;</span><?php lang("macro"); ?> 
		  <select name="macro_list">
<?php
			$sql = "SELECT * 
				FROM bloq_macros 
				ORDER BY macro_id";
			$data = mysql_query($sql, $link);
			$sql_num += 1;
			if (mysql_num_rows($data) != "0") {
				while ($result = mysql_fetch_array($data)) {
?>
			<option value="<?php echo $result['macro_id']; ?>"><?php echo "^".$result['macro_id']."^ = ".$result['macro_value']; ?></option>
<?php
				}
			} else {
?>
			  <option value="-1"><? lang("macro_noInDb"); ?></option>
<?php
			}
?>
		  </select>
		  <input type="submit" name="macro_del" value=" <?php lang("del"); ?> " /> <input type="submit" name="macro_edi" value=" <?php lang("edi"); ?> " /></div>
		</div>
	  </form>
	</div>
	</div>
	<div id="copyright">powered by <span class="b">&gt;</span><a href="http://www.bloq.cz/bloq" title="bloq">bloq</a> <?php echo $bloq['bloq_version']; ?> - keep it simple | copyright <span class="b">&gt;</span><a href="http://www.bloq.cz" title="nebko">nebko</a> 2003</div>
<?php
		break;
	
//////////// SUBMIT BOX
	
		case "submit_box":
?>
	<div class="header">::<?php echo $header; ?></div>
	<div id="box_center">
	  <div class="box_line_top"></div>
	  <div class="box_header"><span class="b">&gt;</span><?php echo $header; ?></div>
	  <div class="box_line_bot"></div>
<?php 
			if ($type['1'] != "view") {
?>
	  <form action="admin.php" method="post">
<?php
			}
?>
	    <div class="inside">
<?php
			if (isset($type)) {
				
//////////// SMAZAT
				
				if ($type['1'] == "del") {
				
//////////////////////// PRISPEVEK
				
					if ($type['0'] == "post") {
						lang("post_del");
						$href_yes = "admin.php?action=post&amp;post_del=1&amp;ok=1&amp;id=".$id."&amp;posts_page=".$HTTP_GET_VARS['posts_page']."&amp;posts_from=".$HTTP_GET_VARS['posts_from']."&amp;posts_order=".$HTTP_GET_VARS['posts_order']."&amp;posts_topic=".$HTTP_GET_VARS['posts_topic'];
						$href_no = $HTTP_REFERER;
?>
		  <span class="b">&gt;</span><a href="<?php echo $href_yes; ?>" title="<?php lang("yes"); ?>"><?php lang("yes"); ?></a> <span class="b">&gt;</span><a href="<?php echo $href_no; ?>" title="<?php lang("no"); ?>"><?php lang("no"); ?></a>
<?php
					
//////////////////////// KOMETAR
					
					} elseif ($type['0'] == "comment") {
						lang("comment_del");
						$href_yes = "admin.php?action=comment&amp;comment_del=1&amp;ok=1&amp;id=".$HTTP_GET_VARS['id']."&amp;post_id=".$HTTP_GET_VARS['post_id']."&amp;comments=".$HTTP_GET_VARS['comments']."&amp;comments_from=".$HTTP_GET_VARS['comments_from']."&amp;comments_post=".$HTTP_GET_VARS['comments_post']."&amp;posts_page=".$HTTP_GET_VARS['posts_page']."&amp;posts_from=".$HTTP_GET_VARS['posts_from']."&amp;posts_order=".$HTTP_GET_VARS['posts_order']."&amp;posts_topic=".$HTTP_GET_VARS['posts_topic'];
						$href_no = $HTTP_REFERER;
?>
		  <span class="b">&gt;</span><a href="<?php echo $href_yes; ?>" title="<?php lang("yes"); ?>"><?php lang("yes"); ?></a> <span class="b">&gt;</span><a href="<?php echo $href_no; ?>" title="<?php lang("no"); ?>"><?php lang("no"); ?></a>
<?php
					
//////////////////////// RUBRIKU
					
					} elseif ($type['0'] == "topic") {
?>
	      <span class="b">&gt;</span><?php lang("topic_move"); ?> 
		  <select name="topic_del_new">
<?php
						$sql = "SELECT * 
							FROM bloq_topic 
							WHERE topic_id != '".$HTTP_POST_VARS['topic_list']."'";
						$data = mysql_query($sql, $link);
						$sql_num += 1;
						if (mysql_num_rows($data) != "0") {
							while ($result = mysql_fetch_array($data)) {
?>
		    <option value="<?php echo $result['topic_id']; ?>"><?php echo htmlspecialchars(stripslashes($result['topic_name'])); ?></option>
<?php
							}
						} else {
?>
  		    <option value="-1"><? lang("topic_noInDb"); ?></option>
<?php
						}
?>
		  </select>
		  <input type="submit" name="topic_del" value="<?php lang("del"); ?>" /> <span class="b">&gt;</span><a href="admin.php" title="<?php lang("back"); ?>"><?php lang("back"); ?></a>
		  <input type="hidden" name="topic_list" value="<?php echo $HTTP_POST_VARS['topic_list']; ?>" />
		  <input type="hidden" name="action" value="topic" />
<?php
					
//////////////////////// MAKRO
					
					} elseif ($type['0'] == "macro") {
						lang("macro_del");
						$href_yes = "admin.php?action=macro&amp;macro_del=1&amp;id=".$HTTP_POST_VARS['macro_list'];
						$href_no = $HTTP_REFERER;
?>
		  <span class="b">&gt;</span><a href="<?php echo $href_yes; ?>" title="<?php lang("yes"); ?>"><?php lang("yes"); ?></a> <span class="b">&gt;</span><a href="<?php echo $href_no; ?>" title="<?php lang("no"); ?>"><?php lang("no"); ?></a>
<?php
					}
				
//////////// PREJMENOVAT
				
				} elseif ($type['1'] == "rename") {
				
?>
		  <span class="b">&gt;</span><?php lang("new_name"); ?> <input type="text" name="topic_rename_new" value="<?php echo $HTTP_GET_VARS['topic_rename_new']; ?>" size="20" />
		  <input type="submit" name="topic_rename" value="<?php lang("rename"); ?>" /> <span class="b">&gt;</span><a href="admin.php" title="<?php lang("back"); ?>"><?php lang("back"); ?></a>
		  <input type="hidden" name="topic_list" value="<?php echo $HTTP_POST_VARS['topic_list']; ?>" />
		  <input type="hidden" name="action" value="topic" />
<?php
				
//////////// ZOBRAZIT
				
				} elseif ($type['1'] == "view") {
				
					$sql = "SELECT * 
						FROM bloq_post 
						WHERE post_id = '".$id."'";
					$data = mysql_query($sql, $link);
					$sql_num += 1;
					$result = mysql_fetch_array($data);
					$sql1 = "SELECT topic_name 
						FROM bloq_topic 
						WHERE topic_id = '".$result['post_topic']."'";
					$data1 = mysql_query($sql1, $link);
					$sql_num += 1;
					$result1 = mysql_fetch_array($data1);
					$publ = ($result['post_publicated'] == "0") ? " <span class=\"b\">&gt;</span><a href=\"admin.php?action=post&amp;post_publ=1&amp;id=".$result['post_id']."\" title=\"".$lang['publ']."\">".$lang['publ']."</a>" : "" ;
?>
		<div><h3><?php echo $result['post_title']." (".htmlspecialchars(stripslashes($result1['topic_name']))." | ".date("j.n.Y - H:i:s", $result['post_time']).")"; ?></h3></div>
		<div><span class="b">&gt;</span><a href="admin.php?action=post&amp;post_edi=1&amp;id=<?php echo $result['post_id']; ?>&amp;post_id=1&amp;posts_page=<?php echo $HTTP_GET_VARS['posts_page']; ?>&amp;posts_from=<?php echo $HTTP_GET_VARS['posts_from']; ?>&amp;posts_order=<?php echo $HTTP_GET_VARS['posts_order']; ?>&amp;posts_topic=<?php echo $HTTP_GET_VARS['posts_topic']; ?>" title="<?php lang("edi"); ?>"><?php lang("edi"); ?></a> <span class="b">&gt;</span><a href="admin.php?action=post&amp;post_del=1&amp;id=<?php echo $result['post_id']; ?>&amp;post_id=1&amp;posts_page=<?php echo $HTTP_GET_VARS['posts_page']; ?>&amp;posts_from=<?php echo $HTTP_GET_VARS['posts_from']; ?>&amp;posts_order=<?php echo $HTTP_GET_VARS['posts_order']; ?>&amp;posts_topic=<?php echo $HTTP_GET_VARS['posts_topic']; ?>" title="<?php lang("del"); ?>"><?php lang("del"); ?></a><?php echo $publ; ?></div>
		<div style="margin-top:20px;text-align:justify;"><?php echo format_to_view($result['post_text']); ?></div>
		<div style="border-top:1px solid #FFA555;"><strong><span class="b">&gt;</span> <?php lang("comments"); ?></strong></div>
<?php
					$sql2 = "SELECT * 
						FROM bloq_comment 
						WHERE comment_post_id = '".$result['post_id']."'
						ORDER BY comment_time";
					$data2 = mysql_query($sql2, $link);
					$sql_num += 1;
					if (mysql_num_rows($data2) != "0") {
						$i = "1";
						$k = "1";
						while ($result2 = mysql_fetch_array($data2)) {
							$email = ($result2['comment_email'] != "") ? "[<a href=\"mailto:".htmlspecialchars(stripslashes($result2['comment_email']))."\" title=\"".htmlspecialchars(stripslashes($result2['comment_email']))."\">".$lang["email"]."</a>]" : "";
							$url = ($result2['comment_url'] != "") ? "[<a href=\"".htmlspecialchars(stripslashes($result2['comment_url']))."\" title=\"".htmlspecialchars(stripslashes($result2['comment_url']))."\">".$lang["web"]."</a>]" : "";
							$i = ($i == "3") ? "1" : $i;
							$class = ($i == "1") ? "1" : "2";
?>
		<div class="rows<?php echo $class; ?>"><?php echo "<strong>".$k.") ".htmlspecialchars(stripslashes($result2['comment_author']))." <span class=\"small\">(".date("j.n.Y - H:i", $result2['comment_time']).")</span></strong> ".$email." ".$url." [IP:".$result2['comment_ip']."]"; ?>
		<div><?php echo make_clickable(stripslashes($result2['comment_content'])); ?></div>
		<div><span class="b">&gt;</span><a href="admin.php?action=comment&amp;comment_edi=1&amp;id=<?php echo $result2['comment_id']; ?>&amp;post_id=<?php echo $result['post_id']; ?>&amp;posts_page=<?php echo $HTTP_GET_VARS['posts_page']; ?>&amp;posts_from=<?php echo $HTTP_GET_VARS['posts_from']; ?>&amp;posts_order=<?php echo $HTTP_GET_VARS['posts_order']; ?>&amp;posts_topic=<?php echo $HTTP_GET_VARS['posts_topic']; ?>" title="<?php lang("edi"); echo " "; lang("comment"); ?>"><?php lang("edi"); echo " "; lang("comment"); ?></a> <span class="b">&gt;</span><a href="admin.php?action=comment&amp;comment_del=1&amp;id=<?php echo $result2['comment_id']; ?>&amp;post_id=<?php echo $result['post_id']; ?>&amp;posts_page=<?php echo $HTTP_GET_VARS['posts_page']; ?>&amp;posts_from=<?php echo $HTTP_GET_VARS['posts_from']; ?>&amp;posts_order=<?php echo $HTTP_GET_VARS['posts_order']; ?>&amp;posts_topic=<?php echo $HTTP_GET_VARS['posts_topic']; ?>" title="<?php lang("del"); echo " "; lang("comment"); ?>"><?php lang("del"); echo " "; lang("comment"); ?></a></div></div>
<?php
							$i++;
							$k++;
						}
					} else {
?>
		<div><em><?php lang("comment_no"); ?></em></div>
<?php
					}
?>
		<form action="index.php?type=comment" method="post">
	    <div style="border-top:1px solid #FFA555;"><strong><span class="b">&gt;</span> <?php lang("comment_leave"); ?></strong></div>
		<fieldset><legend><?php lang("user_info"); ?></legend>
		  <div><label for="comment_author"><span class="b">&gt;</span><strong><?php lang("name"); ?></strong></label> <input type="text" id="comment_author" name="comment_author" value="<?php echo $bloq['author_name']; ?>" size="30" /></div>
		  <div><label for="comment_email"><span class="b">&gt;</span><?php lang("email"); ?></label> <input type="text" id="comment_email" name="comment_email" value="<?php echo $bloq['author_email']; ?>" size="30" /></div>
		  <div><label for="comment_url"><span class="b">&gt;</span><?php lang("web"); ?></label> <input type="text" id="comment_url" name="comment_url" value="<?php echo $bloq['web_url']; ?>" size="30" /></div>
		</fieldset>
		<fieldset><legend><?php lang("comment"); ?></legend>
		  <div><textarea name="comment_content" cols="100" rows="10"></textarea></div>
		  <div><input type="submit" value=" <?php lang("comment_leave"); ?> " /> <input type="reset" value=" <?php lang("reset"); ?> " /></div>
		</fieldset>
		<input type="hidden" name="post" value="<?php echo $result['post_id']; ?>" />
<?php
				
//////////// PUBLIKOVAT
				
				} elseif ($type['1'] == "publ") {
				
?>
		<span class="b">&gt;</span><?php lang("publ_when"); ?>
		<input type="text" name="post_day" value="<?php echo date("d", time()); ?>" size="2" />
		<select name="post_month">
<?php
					for($i = "1" ; $i < "13"; $i++) {
						if (date("n", time()) == $i) {
							$checked = "selected=\"selected\"";
						}
?>
		  <option value="<?php echo $i; ?>"<?php echo $checked; ?>><?php lang("month".$i.""); ?></option>
<?php
						unset($checked);
					}
?>
		</select> <input type="text" name="post_year" value="<?php echo date("Y", time()); ?>" size="4" />
		<input type="text" name="post_time" value="<?php echo date("H:i:s", time()); ?>" size="8" />
		<input type="submit" name="post_publ" value=" <?php lang("publ"); ?> " /> <span class="b">&gt;</span><a href="admin.php" title="<?php lang("back"); ?>"><?php lang("back"); ?></a>
		<input type="hidden" name="id" value="<?php echo $id; ?>" />
		<input type="hidden" name="action" value="post" />
<?php
				
//////////// UPRAVIT
				
				} elseif ($type['1'] == "edi") {
				
//////////////////////// PRISPEVEK
				
					if ($type['0'] == "post") {
						$sql = "SELECT * 
							FROM bloq_post 
							WHERE post_id = '".$id."'";
						$data = mysql_query($sql, $link);
						$sql_num += 1;
						$result = mysql_fetch_array($data);
						if ($HTTP_GET_VARS['post_id'] != "") {
							$back = "admin.php?action=post&amp;post_view=1&amp;id=".$HTTP_GET_VARS['id']."&amp;posts_page=".$HTTP_GET_VARS['posts_page']."&amp;posts_from=".$HTTP_GET_VARS['posts_from']."&amp;posts_order=".$HTTP_GET_VARS['posts_order']."&amp;posts_topic=".$HTTP_GET_VARS['posts_topic'];
						} else {
							$back = "admin.php?&amp;posts_page=".$HTTP_GET_VARS['posts_page']."&amp;posts_from=".$HTTP_GET_VARS['posts_from']."&amp;posts_order=".$HTTP_GET_VARS['posts_order']."&amp;posts_topic=".$HTTP_GET_VARS['posts_topic'];;
						}
?>
		  <span class="b">&gt;</span><?php lang("title"); ?> <input type="text" name="post_title" value="<?php echo $result['post_title']; ?>" size="30" />
		  <span class="b">&gt;</span><?php lang("topic"); ?> 
		  <select name="post_topic">
<?php
						echo select_topics();
?>
		  </select>
		  <div><span class="b">&gt;</span><?php lang("post"); ?></div>
		  <div><textarea name="post_text" cols="100" rows="15"><?php echo format_to_edit($result['post_text']); ?></textarea></div>
		  <div><input type="checkbox" name="post_autobr" value="1"<?php echo ($result['post_autobr'] == "1") ? " checked=\"checked\"" : ""; ?> /> <span class="help" title="<?php lang("autobr_help"); ?>"><?php lang("autobr"); ?></span> <input type="checkbox" name="post_macros" value="1"<?php echo ($result['post_macros'] == "1") ? " checked=\"checked\"" : ""; ?> /> <span class="help" title="<?php lang("macros_help"); ?>"><?php lang("macros"); ?></span> <input type="checkbox" name="post_comment" value="1"<?php echo ($result['post_comment'] == "1") ? " checked=\"checked\"" : ""; ?> /> <span class="help" title="<?php lang("comments_help"); ?>"><?php lang("comments"); ?></span></div>
		  <div><span class="b">&gt;</span><span class="help" title="<?php lang("change_publDate_help"); ?>"><?php lang("change_publDate"); ?></span></div>
		  <div>
			<input type="text" name="post_day" value="<?php echo date("d", $result['post_time']); ?>" size="2" />
			<select name="post_month">
<?php
						for($i = "1" ; $i < "13"; $i++) {
							if (date("n", $result['post_time']) == $i) {
								$checked = " selected=\"selected\"";
							}
?>
			  <option value="<?php echo $i; ?>"<?php echo $checked; ?>><?php lang("month".$i.""); ?></option>
<?php
							unset($checked);
						}
?>
			</select> <input type="text" name="post_year" value="<?php echo date("Y", $result['post_time']); ?>" size="4" />
			<input type="text" name="post_time" value="<?php echo date("H:i:s", $result['post_time']); ?>" size="8" />
		  </div>
		  <div><span class="b">&gt;</span><?php lang("publicated"); ?> <input type="checkbox" name="post_publicated" value="1"<?php echo ($result['post_publicated'] == "1") ? " checked=\"checked\"" : ""; ?> /></div>
		  <div><input type="submit" name="post_edi" value=" <?php lang("edi"); ?> " /> <input type="reset" value=" <?php lang("reset"); ?> " /> <span class="b">&gt;</span><a href="<?php echo $back; ?>" title="<?php lang("back"); ?>"><?php lang("back"); ?></a></div>
		  <input type="hidden" name="posts_page" value="<?php echo $HTTP_GET_VARS['posts_page']; ?>" /><input type="hidden" name="posts_from" value="<?php echo $HTTP_GET_VARS['posts_from']; ?>" /><input type="hidden" name="posts_order" value="<?php echo $HTTP_GET_VARS['posts_order']; ?>" /><input type="hidden" name="posts_topic" value="<?php echo $HTTP_GET_VARS['posts_topic']; ?>" />
		  <input type="hidden" name="action" value="post" />
		  <input type="hidden" name="id" value="<?php echo $id; ?>" />
<?php
				
//////////////////////// MAKRO
				
					} elseif($type['0'] == "macro") {
						$sql = "SELECT * 
							FROM bloq_macros 
							WHERE macro_id = '".$HTTP_POST_VARS['macro_list']."'";
						$data = mysql_query($sql, $link);
						$sql_num += 1;
						$result = mysql_fetch_array($data);
?>
		  <span class="b">&gt;</span><?php lang("edi"); ?> - <?php lang("id"); ?>: 
		  <input type="text" name="macro_id" value="<?php echo $result['macro_id']; ?>" size="15" /> 
		  <?php lang("value"); ?>: 
		  <input type="text" name="macro_value" value="<?php echo $result['macro_value']; ?>" size="25" />
		  <input type="submit" name="macro_edi" value=" <?php lang("edi"); ?>" />
		  <input type="hidden" name="id" value="<?php echo $HTTP_POST_VARS['macro_list']; ?>" />
		  <input type="hidden" name="action" value="macro" />
<?
				
//////////////////////// KOMETAR
				
					} elseif($type['0'] == "comment") {
						$sql = "SELECT * 
							FROM bloq_comment 
							WHERE comment_id = '".$HTTP_GET_VARS['id']."'";
						$data = mysql_query($sql, $link);
						$qsl_num += 1;
						$result = mysql_fetch_array($data);
						if ($HTTP_GET_VARS['post_id'] != "") {
							$back = "admin.php?action=post&amp;post_view=1&amp;post_id=".$HTTP_GET_VARS['post_id']."&amp;posts_page=".$HTTP_GET_VARS['posts_page']."&amp;posts_from=".$HTTP_GET_VARS['posts_from']."&amp;posts_order=".$HTTP_GET_VARS['posts_order']."&amp;posts_topic=".$HTTP_GET_VARS['posts_topic'];
						} elseif ($HTTP_GET_VARS['comments'] != "") {
							$back = "admin.php?comments=".$HTTP_GET_VARS['comments']."&amp;comments_from=".$HTTP_GET_VARS['comments_from']."&amp;comments_post=".$HTTP_GET_VARS['comments_post'];
						} else {
							$back = "admin.php";
						}
?>
		  <fieldset><legend><?php lang("user_info"); ?></legend>
		  	<div><label for="comment_author"><span class="b">&gt;</span><strong><?php lang("name"); ?></strong></label> <input type="text" id="comment_author" name="comment_author" value="<?php echo (isset($HTTP_GET_VARS['comment_author'])) ? $HTTP_GET_VARS['comment_author'] : $result['comment_author']; ?>" size="30" /></div>
		  	<div><label for="comment_email"><span class="b">&gt;</span><?php lang("email"); ?></label> <input type="text" id="comment_email" name="comment_email" value="<?php echo (isset($HTTP_GET_VARS['comment_email'])) ? $HTTP_GET_VARS['comment_email'] : $result['comment_email']; ?>" size="30" /></div>
		  	<div><label for="comment_url"><span class="b">&gt;</span><?php lang("web"); ?></label> <input type="text" id="comment_url" name="comment_url" value="<?php echo (isset($HTTP_GET_VARS['comment_url'])) ? $HTTP_GET_VARS['comment_url'] : $result['comment_url']; ?>" size="30" /></div>
		  </fieldset>
		  <fieldset><legend><?php lang("comment"); ?></legend>
		  	<div><textarea name="comment_content" cols="100" rows="10"><?php echo (isset($HTTP_GET_VARS['comment_content'])) ? $HTTP_GET_VARS['comment_content'] : $result['comment_content']; ?></textarea></div>
		  	<div><input type="submit" name="comment_edi" value=" <?php lang("edi"); ?> " /> <input type="reset" value=" <?php lang("reset"); ?> " /> <span class="b">&gt;</span><a href="<?php echo $back; ?>" title="<?php lang("back"); ?>"><?php lang("back"); ?></a></div>
		  </fieldset>
		  <input type="hidden" name="comments" value="<?php echo $HTTP_GET_VARS['comments']; ?>" /><input type="hidden" name="comments_from" value="<?php echo $HTTP_GET_VARS['comments_from']; ?>" /><input type="hidden" name="comments_post" value="<?php echo $HTTP_GET_VARS['comments_post']; ?>" /><input type="hidden" name="posts_page" value="<?php echo $HTTP_GET_VARS['posts_page']; ?>" /><input type="hidden" name="posts_order" value="<?php echo $HTTP_GET_VARS['posts_order']; ?>" /><input type="hidden" name="posts_topic" value="<?php echo $HTTP_GET_VARS['posts_topic']; ?>" /><input type="hidden" name="posts_from" value="<?php echo $HTTP_GET_VARS['posts_from']; ?>" /><input type="hidden" name="post_id" value="<?php echo $HTTP_GET_VARS['post_id']; ?>" />
		  <input type="hidden" name="action" value="comment" />
		  <input type="hidden" name="id" value="<?php echo $HTTP_GET_VARS['id']; ?>" />
<?php
					}
				}
				
			} else {
				lang("no_type");
			}
?>
	  
	    </div>
	  </form>
	</div>
	</div>
	<div id="copyright">powered by <span class="b">&gt;</span><a href="http://bloq.bloq.cz/" title="bloq">bloq</a> <?php echo $bloq['bloq_version']; ?> - keep it simple | copyright <span class="b">&gt;</span><a href="http://www.bloq.cz" title="nebko">nebko</a> 2003</div>
<?php
		break;
	
//////////// LOGIN
	
		default: // login
?>
	<form action="admin.php" method="post">
	<div id="admin_box">
	  <div><a href="http://www.bloq.cz" title="bloq"><img src="<?php image("bloq-logo.gif"); ?>" alt="bloq" /></a> <strong>Login</strong></div>
	  <div><?php lang("nick"); ?><span class="b">&gt;&gt;</span></div><div><input type="text" name="nickname" size="20" accesskey="n" /></div>
	  <div><?php lang("pass"); ?><span class="b">&gt;&gt;</span></div><div><input type="password" name="password" size="20" accesskey="p" /></div>
	  <div><input type="submit" value="  <?php lang("login"); ?>  " accesskey="l" /> <input type="reset" value="  <?php lang("reset"); ?>  " accesskey="r" /></div>
	  <div><span class="small"><?php lang("note").lang("cookie_on"); ?></span></div>
	  <div id="copyright">powered by <span class="b">&gt;</span><a href="http://bloq.bloq.cz/" title="bloq">bloq</a> <?php echo $bloq['bloq_version']; ?> - keep it simple | copyright <span class="b">&gt;</span><a href="http://www.bloq.cz" title="nebko">nebko</a> 2003</div>
	</div>
	<input type="hidden" name="do" value="login" />
	</form>

<?php
		break;
	}
}

?>
  <!-- PAGE GENERATED IN <?php timer_stop(1) ?> seconds | NUMBER OF SQL QUERIES <?php echo $sql_num; ?> -->
  <!-- GENERATED BY bloq<?php echo $bloq['bloq_version']; ?> - keep it simple | http://bloq.bloq.cz/ -->
  </body>
  
</html>
<?php
			
//////////// FUNCTIONS
			

function select_topics() {
	global $link, $lang, $posts_topic, $result, $sql_num;
	$result_handler = $result;
	echo $result_handler['post_topic'];
	$sql = "SELECT * 
		FROM bloq_topic 
		ORDER BY topic_id";
	$data = mysql_query($sql, $link);
	$sql_num += 1;
	if (mysql_num_rows($data) != "0") {
		while ($select_topics_result = mysql_fetch_array($data)) {
			if (($posts_topic == $select_topics_result['topic_id']) OR ($result_handler['post_topic'] == $select_topics_result['topic_id'])) {
				$selected = "1";
			} else {
				$selected = "0";
			}
			$select_topics .= "\t\t\t<option value=\"".$select_topics_result['topic_id']."\" ".(($selected == "1") ? "selected=\"selected\"" : "").">".htmlspecialchars(stripslashes($select_topics_result['topic_name']))."</option>\n";
		}
	} else {
			$select_topics .= "\t\t\t<option value=\"-1\">".lang("topic_noInDb")."</option>";
	}
	return($select_topics);
}

?>