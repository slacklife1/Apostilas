# phpMyAdmin SQL Dump
# version 2.5.3-rc3
# http://www.phpmyadmin.net
#
# Po��ta�: localhost
# Vygenerov�no: Ned�le 02. listopadu 2003, 12:32
# Verze MySQL: 3.23.33
# Verze PHP: 4.3.0
# 
# Datab�ze : `bloq`
# 

# --------------------------------------------------------

#
# Struktura tabulky `bloq_comment`
#

CREATE TABLE `bloq_comment` (
  `comment_id` int(10) NOT NULL auto_increment,
  `comment_post_id` int(10) NOT NULL default '0',
  `comment_author` varchar(255) NOT NULL default '',
  `comment_email` varchar(255) NOT NULL default '',
  `comment_url` varchar(255) NOT NULL default '',
  `comment_ip` varchar(15) NOT NULL default '',
  `comment_time` varchar(10) NOT NULL default '',
  `comment_content` text NOT NULL,
  PRIMARY KEY (`comment_id`),
  FULLTEXT KEY `comment_content`(`comment_content`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

# --------------------------------------------------------

#
# Struktura tabulky `bloq_config`
#

CREATE TABLE `bloq_config` (
  `config_name` varchar(100) NOT NULL default '',
  `config_value` text NOT NULL
) TYPE=MyISAM;

# --------------------------------------------------------

INSERT INTO `bloq_config` VALUES ('web_name', 'blog');
INSERT INTO `bloq_config` VALUES ('web_url', '');
INSERT INTO `bloq_config` VALUES ('web_lang', 'en');
INSERT INTO `bloq_config` VALUES ('author_name', '');
INSERT INTO `bloq_config` VALUES ('author_nick', '');
INSERT INTO `bloq_config` VALUES ('author_email', '');
INSERT INTO `bloq_config` VALUES ('author_login', '21232f297a57a5a743894a0e4a801fc3');
INSERT INTO `bloq_config` VALUES ('author_pass', '1a1dc91c907325c69271ddf0c944bc72');
INSERT INTO `bloq_config` VALUES ('img_path', 'images/');
INSERT INTO `bloq_config` VALUES ('allowed_tags', '<b><i><u><strong><em><p><br /> <strike><a><hr /><ol><ul><li><sub><sup>');
INSERT INTO `bloq_config` VALUES ('web_motto', '');
INSERT INTO `bloq_config` VALUES ('web_description', '');
INSERT INTO `bloq_config` VALUES ('web_keywords', '');
INSERT INTO `bloq_config` VALUES ('limit_posts', '10');
INSERT INTO `bloq_config` VALUES ('use_cache', '1');
INSERT INTO `bloq_config` VALUES ('query_lenght', '3');

#
# Struktura tabulky `bloq_macros`
#

CREATE TABLE `bloq_macros` (
  `macro_id` varchar(100) NOT NULL default '',
  `macro_value` text NOT NULL
) TYPE=MyISAM;

# --------------------------------------------------------

INSERT INTO `bloq_macros` VALUES ('bloq', 'http://www.bloq.cz/bloq.php');

#
# Struktura tabulky `bloq_post`
#

CREATE TABLE `bloq_post` (
  `post_id` int(10) NOT NULL auto_increment,
  `post_title` varchar(255) NOT NULL default '',
  `post_text` text NOT NULL,
  `post_time` varchar(10) NOT NULL default '',
  `post_topic` smallint(5) NOT NULL default '1',
  `post_autobr` tinyint(1) NOT NULL default '1',
  `post_comment` tinyint(1) NOT NULL default '1',
  `post_macros` tinyint(1) NOT NULL default '1',
  `post_publicated` tinyint(1) NOT NULL default '1',
  PRIMARY KEY (`post_id`),
  FULLTEXT KEY `post_title`(`post_title`,`post_text`)
) TYPE=MyISAM AUTO_INCREMENT=6 ;

# --------------------------------------------------------

#
# Struktura tabulky `bloq_topic`
#

CREATE TABLE `bloq_topic` (
  `topic_id` smallint(5) NOT NULL auto_increment,
  `topic_name` varchar(100) NOT NULL default '',
  PRIMARY KEY (`topic_id`)
) TYPE=MyISAM AUTO_INCREMENT=6 ;

INSERT INTO `bloq_topic` VALUES (1, 'topic');
