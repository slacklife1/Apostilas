<?php

$config_file = $page['path']."files/config.php";

if(file_exists($config_file)) {
	include ($config_file);
} else {
	die("ERROR - Missing config file: ".$config_file."!");
}

setlocale(LC_ALL,'Czech');
//error_reporting(0); // bez chyb
timer_start();

if ($bloq['db_perm'] == "1") {
	if (empty($link)) {
		$link = mysql_pconnect($bloq['db_host'], $bloq['db_user'], $bloq['db_pass']);
	}
} else {
	$link = mysql_connect($bloq['db_host'], $bloq['db_user'], $bloq['db_pass']);
}

if (isset($link)) {
	$sel_db = mysql_query("USE ".$bloq['db_name']."", $link);
	$sql_num += 1;
	if (!isset($sel_db)) {
		die("ERROR - Can't select the database: ".$bloq['db_name']."!");
	}
} else {
	die("ERROR - Can't connect to the database!");
}

$sql_conf = "SELECT * 
	FROM bloq_config";
$data_conf = mysql_query($sql_conf, $link);
$sql_num += 1;
while($result_conf = mysql_fetch_array($data_conf)) {
	$handler .= "\$bloq['".$result_conf['config_name']."'] = \"".stripslashes($result_conf['config_value'])."\";\n";
}
eval($handler);

if (file_exists($page['path']."files/lang_".$bloq['web_lang'].".php")) {
	include ($page['path']."files/lang_".$bloq['web_lang'].".php");
} else {
	include ($page['path']."files/lang_cs.php");
}

// FUNCTIONS //

function image($img) {
	global $bloq;
	
	echo $bloq['web_url'].$bloq['img_path'].$img;
}

function lang($key) {
	global $lang, $bloq;
	
	if (isset($lang[$key])) {
		echo $lang[$key];
	} else {
		$mess .= $lang['err_lang_missingKey']." [".$key."]";
		die($mess);
	}
}

//////////// FORMATOVACI FUNKCE

function autobr($content) { // nahradit \n za <br />
	$content = preg_replace("/<br>\n/", "\n", $content);
	$content = preg_replace("/<br \/>\n/", "\n", $content);
	$content = preg_replace("/(\015\012)|(\015)|(\012)/", "<br />\n", $content);
	return($content);
}

function unautobr($content) { // nahradit <br /> za \n
	$content = preg_replace("/<br>\n/", "\n", $content);
	$content = preg_replace("/<br \/>\n/", "\n", $content);
	return($content);
}

function format_to_edit($content) { // pripravit na editaci
	global $result;
	$content = stripslashes($content);
	if ($result['post_autobr']) {
		$content = unautobr($content);
	}
	$content = htmlspecialchars($content);
	return($content);
}

function format_to_post($content) { // pripravit na odeslani
	global $HTTP_POST_VARS;
	$content = addslashes($content);
	if ($HTTP_POST_VARS['post_autobr']) {
		$content = autobr($content);
	}
	return($content);
}

function format_to_view($content) { // pripravit na zobrazeni
	$content = stripslashes($content);
	$content = replace_macros($content);
	$content = make_clickable($content);
	return($content);
}

function replace_macros($content) { // nahrazovani maker
	global $link, $sql_num, $cache_macros, $bloq;
	if (!isset($cache_macros) OR ($bloq['use_cache'] == "0")) {
		$sql = "SELECT * 
			FROM bloq_macros";
		$data = mysql_query($sql, $link);
		$sql_num += 1;
		if (mysql_num_rows($data) != "0") {
			while ($result = mysql_fetch_array($data)) {
				$macros[$result['macro_id']] = $result['macro_value'];
				$cache_macros[$result['macro_id']] = $result['macro_value'];
			}
		} else {
			return($content);
		}
	} else {
		$macros = $cache_macros;
	}
		$ret = $content;
		$ret = preg_replace("/\^([a-zA-Z0-9]+)\^/e", '$macros["\\1"] ? $macros["\\1"] : "\\1"', $ret);
		return($ret);
}

function make_clickable($content) { // nahrazeni emailu ci webove adresy odkazem
        $ret = " " . $content;

        $ret = preg_replace("#([\n ])([a-z]+?)://([^, \n\r]+)#i", "\\1<a href=\"\\2://\\3\" title=\"\\2://\\3\">\\2://\\3</a>", $ret);
        $ret = preg_replace("#([\n ])www\.([a-z0-9\-]+)\.([a-z0-9\-.\~]+)((?:/[^, \n\r]*)?)#i", "\\1<a href=\"http://www.\\2.\\3\\4\" title=\"http://www.\\2.\\3\\4\">www.\\2.\\3\\4</a>", $ret);
        $ret = preg_replace("#([\n ])([a-z0-9\-_.]+?)@([^, \n\r\<]+)#i", "\\1<a href=\"mailto:\\2@\\3\" title=\"\\2@\\3\">\\2@\\3</a>", $ret);
        $ret = substr($ret, 1);
        return($ret);
}

function the_date() {
	global $result, $day, $previousday;
	$the_date = "";
	if ($day != $previousday) {
		$the_date .= date("l, j. F Y", $result['post_time']);
		$previousday = $day;
	}
	return $the_date;
}

function the_month() {
	global $result, $month, $previousmonth;
	$the_month = "";
	if ($month != $previousmonth) {
		$the_month .= "1";
		$previousmonth = $month;
	}
	return $the_month;
}

function addslashes_gpc($gpc) {
	if (!get_magic_quotes_gpc()) {
		$gpc = addslashes($gpc);
	}
	return($gpc);
}

//////////// DOBA GENEROVANI STRANKY

function timer_start() { // spusteni mereni casu
	global $timestart;
	$mtime = microtime();
	$mtime = explode(" ",$mtime);
	$mtime = $mtime[1] + $mtime[0];
	$timestart = $mtime;
	return(1);;
}

function timer_stop($display=0,$precision=3) { // konec mereni casu
	global $timestart,$timeend;
	$mtime = microtime();
	$mtime = explode(" ",$mtime);
	$mtime = $mtime[1] + $mtime[0];
	$timeend = $mtime;
	$timetotal = $timeend-$timestart;
	if ($display) {
		echo number_format($timetotal,$precision);
	}
	return($timetotal);
}

//////////// VALIDACE INFORMACI ZADAVANYCH UZIVATELEM

function validate_email($email) { // email
	if ($email != "") {
		if (preg_match("/^[a-z0-9\.\-_\+]+@[a-z0-9\-_]+\.([a-z0-9\-_]+\.)*?[a-z]+$/is", $email)) {
			return(1);
		}
	}
	return(0);
}

function validate_url($url) { // url adresa
	if ($url != "") {
		if (preg_match("#([a-z]+?)://([^, \n\r]+)#i", $url) OR preg_match("#www\.([a-z0-9\-]+)\.([a-z0-9\-.\~]+)((?:/[^, \n\r]*)?)#i", $url)) {
			return(1);
		}
	}
	return(0);
}

function get_postdata($id=0) { 
	global $result;
	$postdata = array (
		'post_id' => $result->post_id, 
		'post_time' => $result->post_time,
		'post_text' => $result->post_text,
		'post_title' => $result->post_title,
		'post_topic' => $result->post_topic,
		'post_comment' => $result->post_comment,
		);
	return($postdata);
}

function get_topic() {
	global $bloq, $postdata, $cache_topics, $sql_num, $link;
	$id = $postdata['post_topic'];
	if (!isset($cache_topics[$id]) OR ($bloq['use_cache'] == "0")) {
		$sql1 = "SELECT * 
			FROM bloq_topic 
			WHERE topic_id = '".$postdata['post_topic']."'";
		$data1 = mysql_query($sql1, $link);
		$sql_num += 1;
		$result1 = mysql_fetch_array($data1);
		$cache_topics[$id] = $result1;
	} else {
		$result1 = $cache_topics[$id];
	}
	return($result1);
}

function get_comm($id) {
	global $bloq, $postdata, $cache_topics, $sql_num, $link;
	if (!isset($cache_comments[$id]) OR ($bloq['use_cache'] == "0")) {
		$sql2 = "SELECT comment_id 
			FROM bloq_comment 
			WHERE comment_post_id = '".$postdata['post_id']."'";
		$data2 = mysql_query($sql2, $link);
		$sql_num += 1;
		$comments_num = mysql_num_rows($data2);
		$cache_comments[$id] = $comments_num;
	} else {
		$comments_num = $cache_comments[$id];
	}
	return($comments_num);
}
?>