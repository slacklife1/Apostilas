<?php

$bloq['db_host'] = "localhost";
$bloq['db_name'] = "bloq_public";
$bloq['db_user'] = "";
$bloq['db_pass'] = "";
$bloq['db_perm'] = "0";

// PLEASE DO NOT DELETE | PROSIM NEMAZAT
$bloq['bloq_version'] = "0.5";

?>