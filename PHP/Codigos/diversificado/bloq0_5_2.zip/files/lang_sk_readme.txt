BLOQ - slovak language file

Prelozil som teda lokalizacny subor k CMS systemu BLOQ.

Pouzil som verziu bloq0.5.1 z 9.11.2003

BLOQ si mozete stiahnut z http://bloq.bloq.cz/

Tento lokalizacny subor je poskytovany tak ako je a nie je mozne si
narokovat akykolvek support u autora prekladu alebo autora systemu BLOQ.
Je mozne tento subor pouzivat spolu so systemom BLOQ presne podla licencneho
ujednania tohto systemu. Za tejto podmienky je pouzivanie tohto suboru
pre kazdeho pouzivatela BLOQ bez poplatku a to s povolenim akychkolvek zmien
v lokalizacnom subore pre potreby pouzivatela BLOQu a tejto lokalizacie.

Je mozne sirit upravy tejto lokalizacie za podmienky uvedenia povodneho
autora lokalizacie v tvare ako je uvedene nizsie.

Je zakazane pouzit tento subor ako podklad pre vlastne lokalizovanie
bez uvedenia povodneho autora lokalizacie v tvare ako je uvedene
nizsie. Je zakazane sirit tento lokalizacny subor bez uvedenia povodneho
autora v tvare ako je uvedene nizsie.

Autor lokalizacie neposkytuje ziadnu podporu k systemu BLOQ ani k urovni
lokalizacie. Akekolvek otazky smerujte vyhradne k autorovi systemu BLOQ.

Neprecitanie si tohto suboru a autorskeho zakona nie je ospravedlnenim
vasho konania.

BLOQ (c) 2003 nebko
Slovak language file (c) 2003 Robert Madaj, http://bloq.spravodaj.tk/


