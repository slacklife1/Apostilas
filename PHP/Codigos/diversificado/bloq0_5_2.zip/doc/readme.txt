bloq
------------------------------------------------------------
|||README - in english
This sofware is distributed under GPL.

First, I'll really like, if you can send me your weblog
address on bloq@bloq.cz. I'll add you to my list of bloq
users.

Please, write my about all bugs you'll find, it's the first
public release. bloq@bloq.cz

Main page is index.php. If you want to change desing, find
the line with text Edit bellow this line. Then edit whatever
you want, but be careful about the PHP code. Better way is
to change only CSS files, but it's up to you. And PLEASE,
kepp my copyright somewhere on the page. Thanx

The administration is in admin.php, you can modify the file
name to whatever you want. There is nothing to say about 
administration, everythig is very simple.

There are three files for RSS channels, rdf.php, rss.php and
rss2.php. Nothing to say about them!:o)

If you want to make a new language, just go to the files 
directory, and make new file lang_your_langugage.php and 
translate all the strings. It would be nice, if you'll send
me your translation, I'll add it to the next release of bloq
with copyright of course!:o) 

New languages and skins submit on bloq@bloq.cz

|||README - in czech
Tento software je distibuov�n po GPL.

Na za��tek bych V�s cht�l poprosit, jestli by jste mi mohli
poslat adresu Va�eho weblogu. D�m ji na seznam u�ivatel�
bloqu.

Napi�te mi pros�m o v�ech chyb�ch, kter� najdete, je to 
prvn� ve�ejn� verze. bloq@bloq.cz

Hlavn� strana je index.php. Poku� chcete zm�nit desing,
najd�te v n� ��dek Edti bellow this line. Potom zm��te v�e, 
co chcete, ale pozor na PHP k�d. Lep�� cestou je m�nit jen
CSS soubory, ale je to na V�s. A PROS�M, nechte kdekoliv na
str�nce m�j copyright. D�ky

Administraci najdete v souboru admin.php, jeho� jm�no m��ete
klidn� zm�nit. Nic dal��ho net�eba ��kat, administrace je 
ud�l�na velmi jednodu�e.

Tak� najdete 3 soubory pro RSS kan�ly, rdf.php, rss.php a
rss2.php. K nim op�t nen� co �ict!:o)

Poku� chcete ud�lat nov� jazyk, sta�� j�t do adres��e files
a ud�lat nov� soubor lang_v�_jazyk.php a pak p�elo�it
v�echny �et�zce. bude od V�s hezk�, kdy� mi p�eklad po�lete.
P�id�m ho v p��t� verzi bloqu samoz�ejm� s va��m copyrigh-
tem!:o)

Nov� p�eklady a skiny za�lete na bloq@bloq.cz
------------------------------------------------------------
copyright nebko 2003 | http://bloq.bloq.cz