<?
#################################################
#### ENQUETE CRIADA POR EDGAR FIALHO LOPES   ####
####   VERS�O 1.1 DE 22 DE JULHO DE 2003     ####
####       - DISTRIBUI��O GRATUITA -         ####
####  QUALQUER PROBLEMA NO SCRIPT OU D�VIDA  ####
####     -  POR FAVOR ENTRE EM CONTATO -     ####
####        email: edgar@mybox.it            ####
####  acesse - http://edgarfl.cjb.net        ####
#################################################

require("funcoes.inc");
cabecalho($titulo,"");
conecta("$bd","$usuario","$senha");
if ($c==2){
    // Mostra resultado da enquete
    $resultado=consulta("select sum(campo1),sum(campo2) from $tabela");
    echo ("<BR><centeR><table border='0' width='500'><tr><td width='500' bgcolor='#0879d0'>");
    echo ("<font face='Verdana, Arial' size='2' color='#e2e2e2'><centeR>");
    echo ("<centeR>Resultado da Enquete<BR></td></tr>");
    echo ("<tr><td width='500' heigth='3' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'><center>$titulo</center></td></tr></table><centeR><table border='0' width='500'>");
    while ($linha=mysql_fetch_array($resultado)){
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$c1:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[0] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$c2:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[1] voto(s)</td></tr>");
    }
    echo ("</table>");
}
if ($c==3){
    // Mostra resultado da enquete
    $resultado=consulta("select sum(campo1),sum(campo2),sum(campo3) from $tabela");
    echo ("<BR><centeR><table border='0' width='500'><tr><td width='500' bgcolor='#0879d0'>");
    echo ("<font face='Verdana, Arial' size='2' color='#e2e2e2'><cenneR>");
    echo ("<center>Resultado da Enquete<BR></td></tr><tr><td width='500' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'><center>$titulo</centeR></td></tr></table><centeR><table border='0' width='500'>");
    while ($linha=mysql_fetch_array($resultado)){
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$c1:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[0] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$c2:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[1] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$c3:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[2] voto(s)</td></tr>");
    }
    echo ("</table>");
}
if ($c==4){
    // Mostra resultado da enquete
    $resultado=consulta("select sum(campo1),sum(campo2),sum(campo3),sum(campo4) from $tabela");
    echo ("<BR><centeR><table border='0' width='500'><tr><td width='500' bgcolor='#0879d0'>");
    echo ("<font face='Verdana, Arial' size='2' color='#e2e2e2'><cenneR>");
    echo ("<center>Resultado da Enquete<BR></td></tr><tr><td width='500' bgcolor='#addbfc' heigth='3'><font face='Verdana, Arial' size='2' color='#000000'><center>$titulo</centeR></td></tr></table><centeR><table border='0' width='500'>");
    while ($linha=mysql_fetch_array($resultado)){
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c1:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[0] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c2:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[1] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c3:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[2] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c4:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[3] voto(s)</td></tr>");
    }
    echo ("</table>");
}
if ($c==5){
    // Mostra resultado da enquete
    $resultado=consulta("select sum(campo1),sum(campo2),sum(campo3),sum(campo4),sum(campo5) from $tabela");
    echo ("<BR><centeR><table border='0' width='500'><tr><td width='500' bgcolor='#0879d0'>");
    echo ("<font face='Verdana, Arial' size='2' color='#e2e2e2'><cenneR>");
    echo ("<center>Resultado da Enquete<BR></td></tr><tr><td width='500' bgcolor='#addbfc' heigth='3'><font face='Verdana, Arial' size='2' color='#000000'><center>$titulo</centeR></td></tr></table><centeR><table border='0' width='500'>");
    while ($linha=mysql_fetch_array($resultado)){
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c1:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[0] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c2:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[1] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c3:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[2] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c4:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[3] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c5:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[4] voto(s)</td></tr>");
    }
}
if ($c==6){
    // Mostra resultado da enquete
    $resultado=consulta("select sum(campo1),sum(campo2),sum(campo3),sum(campo4),sum(campo5),sum(campo6) from $tabela");
    echo ("<BR><centeR><table border='0' width='500'><tr><td width='500' bgcolor='#0879d0'>");
    echo ("<font face='Verdana, Arial' size='2' color='#e2e2e2'><cenneR>");
    echo ("<center>Resultado da Enquete<BR></td></tr><tr><td width='500' bgcolor='#addbfc' heigth='3'><font face='Verdana, Arial' size='2' color='#000000'><center>$titulo</centeR></td></tr></table><centeR><table border='0' width='500'>");
    while ($linha=mysql_fetch_array($resultado)){
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c1:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[0] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c2:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[1] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c3:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[2] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c4:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[3] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c5:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[4] voto(s)</td></tr>");
        echo ("<tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'><b>$c6:</b></td><td width='250' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'> $linha[5] voto(s)</td></tr>");
    }
}

?>
</html>
