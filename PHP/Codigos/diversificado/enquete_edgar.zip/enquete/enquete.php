<?
#################################################
#### ENQUETE CRIADA POR EDGAR FIALHO LOPES   ####
####   VERS�O 1.1 DE 22 DE JULHO DE 2003     ####
####       - DISTRIBUI��O GRATUITA -         ####
####  QUALQUER PROBLEMA NO SCRIPT OU D�VIDA  ####
####     -  POR FAVOR ENTRE EM CONTATO -     ####
####        email: edgar@mybox.it            ####
####  acesse - http://edgarfl.cjb.net        ####
#################################################

require("funcoes.inc");
cabecalho("Edgar Fialho Lopes","");
if ($exec== 1){
    echo ("<BR><center><table border='0' width='700'><tr><td width='700' bgcolor='#0879d0'>");
    echo "<font face='Verdana, Arial' size='2' color='#e2e2e2'><center>Enquete criada com sucesso!</td></tr>";
    echo "<tr><td width='700' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'><centeR>Copie e cole o c�digo abaixo em um editor de textos, depois salve com extens�o .html</td></tr>";
    echo "<tr><td width='700' bgcolor='#addbfc'><center><br><pre><textarea cols=80 rows=15 name='edgar'>";
?><html>
<head><title>Enquete virtual - <? echo $titulo; ?></title>
</head>
<body><base target="enquete">
<BR><centeR>
<table border='0' width='500'>
    <tr>
        <td width='500' bgcolor='#0879d0'>
            <font face='Verdana, Arial' size='2' color='#e2e2e2'>
            <center><? echo $titulo; ?></center>
        </td>
    </tr>
</table>
<?
if ($c == 2){
    // pergunta ao usuario qual eh sua preferencia e envia para o result_enquete para computar o resultado.
    ?>
<?echo ("<centeR><table border='0' width='500'><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo1:");?></td><td width='250' bgcolor='#addbfc'><form action='<?echo "result_enquete.php?titulo=$titulo&tabela=$tabela&c1=$campo1&c2=$campo2&c=2";?>' method='post'><input type="radio" name="votar" value="campo1" checked></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo2:");?></td><td width='250' bgcolor='#addbfc'><input type="radio" name="votar" value="campo2"></td></tr></table>
<centeR><table border='0' width='500'><tr><td width='500' bgcolor='#addbfc'><input type="submit" value="Confirmar"></form></td></tr></table>
</html>
</textarea></td></tr></table>  <?
    }
    if ($c == 3){
// pergunta ao usuario qual eh sua preferencia e envia para o result_enquete para computar o resultado.
?>
<?echo ("<centeR><table border='0' width='500'><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo1:");?></td><td width='250' bgcolor='#addbfc'><form action='<?echo "result_enquete.php?titulo=$titulo&tabela=$tabela&c1=$campo1&c2=$campo2&c3=$campo3&c=3";?>' method='post'><input type="radio" name="votar" value="campo1" checked></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo2");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo2'></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo3");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo3'></td></tr>
<centeR><table border='0' width='500'><tr><td width='500' bgcolor='#addbfc'><input type="submit" value="Confirmar"></form></td></tr></table>
</html>
</textarea></td></tr></table>  <?
    }
    if ($c == 4){
    // pergunta ao usuario qual eh sua preferencia e envia para o result_enquete para computar o resultado. ?>
<?echo ("<centeR><table border='0' width='500'><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo1:");?></td><td width='250' bgcolor='#addbfc'><form action='<?echo "result_enquete.php?titulo=$titulo&tabela=$tabela&c1=$campo1&c2=$campo2&c3=$campo3&c4=$campo4&c=4";?>' method='post'><input type="radio" name="votar" value="campo1" checked></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo2");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo2'></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo3");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo3'></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo4");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo4'></td></tr>
<centeR><table border='0' width='500'><tr><td width='500' bgcolor='#addbfc'><input type="submit" value="Confirmar"></form></td></tr></table>
</html>
</textarea></td></tr></table>  <?
    }
    if ($c == 5){
// pergunta ao usuario qual eh sua preferencia e envia para o result_enquete para computar o resultado. ?>
<?echo ("<centeR><table border='0' width='500'><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo1:");?></td><td width='250' bgcolor='#addbfc'><form action='<?echo "result_enquete.php?titulo=$titulo&tabela=$tabela&c1=$campo1&c2=$campo2&c3=$campo3&c4=$campo4&c5=$campo5&c=5";?>' method='post'><input type="radio" name="votar" value="campo1" checked></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo2");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo2'></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo3");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo3'></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo4");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo4'></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo5");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo5'></td></tr>
<centeR><table border='0' width='500'><tr><td width='500' bgcolor='#addbfc'><input type="submit" value="Confirmar"></form></td></tr></table>
</html>
</textarea></td></tr></table>  <?
    }
    if ($c == 6){
// pergunta ao usuario qual eh sua preferencia e envia para o result_enquete para computar o resultado. ?>
<?echo ("<centeR><table border='0' width='500'><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo1:");?></td><td width='250' bgcolor='#addbfc'><form action='<?echo "result_enquete.php?titulo=$titulo&tabela=$tabela&c1=$campo1&c2=$campo2&c3=$campo3&c4=$campo4&c5=$campo5&c6=$campo6&c=6";?>' method='post'><input type="radio" name="votar" value="campo1" checked></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo2");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo2'></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo3");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo3'></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo4");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo4'></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo5");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo5'></td></tr>
<?echo ("<centeR><tr><td width='250' bgcolor='#addbfc'><b><font face='Verdana, Arial' size='2' color='#000000'>$campo6");?></td><td width='250' bgcolor='#addbfc'> <input type='radio' name='votar' value='campo6'></td></tr>
<centeR><table border='0' width='500'><tr><td width='500' bgcolor='#addbfc'><input type="submit" value="Confirmar"></form></td></tr></table>
</html>
</textarea></td></tr></table>  <?
    }
}else{
    echo "Ocorreu um erro na criacao da enquete, tente novamente.";
}
?>
</html>
