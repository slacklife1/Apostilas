<?
#################################################
#### ENQUETE CRIADA POR EDGAR FIALHO LOPES   ####
####   VERS�O 1.1 DE 22 DE JULHO DE 2003     ####
####       - DISTRIBUI��O GRATUITA -         ####
####  QUALQUER PROBLEMA NO SCRIPT OU D�VIDA  ####
####     -  POR FAVOR ENTRE EM CONTATO -     ####
####        email: edgar@mybox.it            ####
####  acesse - http://edgarfl.cjb.net        ####
#################################################
include ("funcoes.inc");
cabecalho("Edgar Fialho Lopes","");

if (!isset ($valor)){
    // primeira pagina da enquete, mostra form para escolher a qtde de campos da enquete
    echo ("<form action='index.php'>");
    echo ("<BR><table border='0' width='280'><tr><td width='280' height='1' bgcolor='#0879d0'>");
    echo ("<font face='Verdana, Arial' size='2' color='#e2e2e2'><center>Escolha a quantidade de campos at� 6.</center></td></tr>");
    echo ("<tr><td width='280' heigth='3' bgcolor='#addbfc'>&nbsp;&nbsp;<input type='text' size='2' name='c'>");
    echo ("<input type='hidden' name='valor' value='1'>");
    echo ("<input type='Submit' value='OK'></form></td></tr></table>");
}else{
    // numero maximo de campos da enquete sao 6, caso coloque um numero maior ele retorna um msg de erro.
    if ($c==1 || $c==0){
        echo ("<BR><BR><center><font face='Verdana, Arial' size='2'>N�o existe enquete com apenas uma op��o, ou sem op��es.");
    }else{
        if ($c>=7){
            echo ("<BR><BR><center><font face='Verdana, Arial' size='2'>A quantidade m�xima de campos para esta enquete s�o de 6 campos, e voc� colocou <b>$c</b>.");
        }else{
            // caso a qtde de campos esteje ok, ele monta um form para escolher os campos
            // e cria a tabela no banco de dados "enquete"
            $campo=1;
            echo ("<form action='enquete.php'>");
            echo ("<BR><table border='0' width='350'><tr><td width='350' bgcolor='#0879d0'>");
            echo ("<font face='Verdana, Arial' size='2' color='#e2e2e2'><centeR>Escolha um t�tulo para sua enquete.</center></td></tr>");
            echo ("<tr><td width='350' heigth='3' bgcolor='#addbfc'><input type='text' name='titulo' size='40' value='Ex. Qual � a sua cor favorita?'> </td></tr>");
            // vai criar uma tabela com as iniciais ed e a data e hora da criacao da tabela
            // assim naum tem como serem criadas tabelas iguais
            $tabela="ed";
            $tabela.=date("dmyhis");
            conecta("$bd","$usuario","$senha");
            $criar= "CREATE TABLE $tabela (";
            $criar.="id int(4) NOT NULL auto_increment,";
            $ex[1]="Azul";
            $ex[2]="Amarelo";
            $ex[3]="Vermelho";
            $ex[4]="Preto";
            $ex[5]="Verde";
            $ex[6]="Laranja";
            while ($valor<=$c){
                echo ("<tr><td width='350' heigth='3' bgcolor='#addbfc'><font face='Verdana, Arial' size='2' color='#000000'>Op��o$campo:<input type='text' name='campo$campo' size='20'> Ex. $ex[$valor]</td></tr>");
                $criar.=" campo$campo varchar(10) default NULL,";
                $valor++;
                $campo++;
            }
            $criar.=" PRIMARY KEY  (id)";
            $criar.=") TYPE=MyISAM;";
            $exec = consulta($criar);
            echo ("<input type='hidden' name='exec' value=$exec>");
            echo ("<input type='hidden' name='c' value=$c>");
            echo ("<input type='hidden' name='tabela' value=$tabela>");
            echo ("<tr><td width='400' heigth='3' bgcolor='#addbfc'><input type='Submit' value='Criar'></form></td></tr></table>");
        }
    }
}
?>
</html>
