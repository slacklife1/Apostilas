<!-- 
* Copyright (C) 2003 
* 
* O script ganha melhorias a cada final de semana.
* Caso tenha interesse em receber as atualiza��es de vers�o via e-mail
* envie uma mensagem para lmaxcar@yahoo.com.br com o assunto ou mensagem 
* "Quero receber atualiza��es de vers�o do Script de Busca de E-mails".
* O script s� muda de vers�o quando a atualiza��o � realmente significativa.
*
* Vers�o 1.1.1
* 29, Novembro, 2003
*
*	CHANGELOG
*
* 1.0.7
* - strip_tags() em prelink;
* - C�lculo tempo demora busca;
* 1.0.8
* - Pr�-resultados;
* 1.1.0
* - Procura somente dentro dom�nio;
* - Melhora testes e la�os salvamento links;
* - Redu��o de 150 linhas Script melhorando la�os;
* - Melhora estat�stica;
* - Recebe resultado via e-mail;
* 1.1.1
* - S� retorna emails que contenham determinada string.
*
*
* DO NOT DELETE COPYRIGHT TEXT BELOW 
* 
* Luiz Miguel Axcar (lmaxcar@yahoo.com.br) 
* http://www.geocities.com/lmaxcar 
* http://www.phpbrasil.com/profile.php/user/lmaxcar
* Campinas, S�o Paulo, Brasil 
* 55 19 9749 6970 
* UIN 96163762 
* The penguin never sleeps. 
* 
* Permission to use and modify this software and its 
* documentation for any purpose other than its incorporation 
* into a commercial product is hereby granted WITHOUT FEE, 
* as long as the AUTHOR IS NOTIFIED that this piece of software 
* is being used in other applications. 
* Permission to copy and distribute this software and its 
* documentation only for non-commercial use is also granted 
* without fee, provided, however, that the ABOVE COPYRIGHT 
* notice and the manual appear in all copies, that both that 
* copyright notice and this permission notice appear in supporting 
* documentation. The author makes NO REPRESENTATIONS about the 
* suitability of this software for any purpose.  It is 
* provided "as is", without express or implied warranty. 
* ALL MODIFICATIONS MUST BE SEND TO THE AUTHOR. 
-->
<?php

$versao = "1.1.1 - 16, Novembro, 2003";

//N�O EXCLUA NADA DAQUI PARA BAIXO

//definindo caracteres para delimitar o e-mail 
$matriz_email[]="'"; 
$matriz_email[]='"'; 
$matriz_email[]="?"; 
$matriz_email[]="<"; 
$matriz_email[]=">"; 
$matriz_email[]=":"; 
$matriz_email[]="/"; 

//definindo caracteres para delimitar o href 
$matriz_href[]="'"; 
$matriz_href[]='"'; 

//definindo caracteres que n�o podem existir em um caminho/arquivo
$matriz_link[]="mailto"; 
$matriz_link[]="@"; 
$matriz_link[]="cript"; //javascript
 
$matriz_link[]=".css"; //principais arquivos
$matriz_link[]=".zip";
$matriz_link[]=".exe";
$matriz_link[]=".doc";
$matriz_link[]=".pdf";
$matriz_link[]=".jpg";
$matriz_link[]=".JPG";
$matriz_link[]=".gif";
$matriz_link[]=".GIF";

$matriz_link[]="microsoft"; //Para n�o perder tempo procurando
$matriz_link[]="uol";
$matriz_link[]="adobe";
$matriz_link[]="macromedia";

$matriz_link[]=" "; 
$matriz_link[]=","; 
$matriz_link[]="{"; 
$matriz_link[]="}"; 
$matriz_link[]="<"; 
$matriz_link[]=">"; 
$matriz_link[]=";";
$matriz_link[]="#"; 
$matriz_link[]="("; 
$matriz_link[]=")"; 



function retorna_emails($arquivo,$string_mail=NULL) 
{ 
	$emails = array();
    global $matriz_email; 

        while (strpos($arquivo,'@')!==false) 
        { 
            $posicao = strpos($arquivo,'@'); 
             
            //definindo a posicao inicial 
            $boo = true; 
            $i = $posicao+2; 
            while ($boo) 
            { 
                if (in_array (substr ($arquivo,$i,1),$matriz_email)) 
                { 
                    $boo = false; 
                    $posicao_final = $i; 
                } 
                else 
                { 
                    $i++; 
                } 
            } 
             
            //definindo a posicao final             
            $boo = true; 
            $i = $posicao-1; 
            while ($boo) 
            { 
                if (in_array (substr ($arquivo,$i,1),$matriz_email)) 
                { 
                    $boo = false; 
                    $posicao_inicial = $i; 
                } 
                else 
                { 
                    $i--; 
                } 
            } 
			
			$boomail = true;	
			$tmp = substr($arquivo,$posicao_inicial+1,($posicao_final-1)-($posicao_inicial)); 				
			
			if ( (! empty ($string_mail)) and (strpos ($tmp,$string_mail) === false) )
			{             
					$boomail = false;
			}
			
			if ( ($boomail) and (eregi ("^[a-z0-9\._-]+@+[a-z0-9\._-]+\.+[a-z]{2,3}$", $tmp)) )
			{
           //validando o e-mail com eregi e teste do dom�nio 

                $pedaco = explode("@",$tmp); 
                if (count ($pedaco) == 2) 
                { 
                    $ip = gethostbyname ($pedaco[1]); 
                    if($ip!=$pedaco[1]) 
                    { 
                        $emails[]=$tmp; 
                    } 
                } 
            }

            $arquivo = str_replace($tmp,'',$arquivo); 
        } 
        return $emails; //retorna matriz com e-mails 
} 

function retorna_links($arquivo,$start) 
{
	$links = array();
	 
    global $nome_host,$matriz_href,$matriz_link,$host_restricao; 
	 
	 $tamanho_start = strlen($start)+1; 
        while (strpos($arquivo,$start)>0) 
        { 
            $posicao = strpos($arquivo,$start); 

            $boo = true; 
            $i = $posicao+$tamanho_start; 
            while ($boo) 
            {  
                if (in_array(substr($arquivo,$i,1),$matriz_href)) 
                { 
                    $boo = false; 
                    $posicao_final = $i; 
                } 
                else 
                { 
                    $i++; 
                } 
            } 
            $posicao_inicial = $posicao + $tamanho_start; 
             
            if (substr($arquivo,$posicao_inicial,1)=='/') 
            { 
                $inicio = $posicao_inicial+1; 
            } 
            else 
            { 
                $inicio = $posicao_inicial; 
            } 
             
            $tmp = strip_tags (substr ($arquivo,$inicio,($posicao_final)-($inicio))); 
	         $tmp2 = substr($arquivo,$posicao_inicial-$tamanho_start,($posicao_final-1)-($posicao_inicial-$tamanho_start)); 
				
				
				
				$booleana = true;
				for ($i=0;$i<count($matriz_link);$i++)
				{
					if (! strpos ($tmp,$matriz_link[$i]) === false)
					{
						$caractere = $matriz_link[$i];
						//echo "<br>n�o vai por causa de [$caractere] em [$tmp],<br>";
						$booleana = false;
					}
				}
				
				$booleana = true;
				for ($i=0;$i<count($matriz_link);$i++)
				{
					if (! strpos ($tmp,$matriz_link[$i]) === false)
					{
						$caractere = $matriz_link[$i];
						//echo "<br>n�o vai por causa de [$caractere] em [$tmp],<br>";
						$booleana = false;
					}
				}
				
				if ($booleana)
				{
					
					if (strpos ($tmp,'http://') === false)
					{
						if ( ($nome_host[strlen($nome_host)-1]=='/') and ($tmp[0]=='/') )
						{
							$prelink = $nome_host.substr($tmp,0,strlen($tmp)-1);
						}
						else
						{
							$prelink = $nome_host.$tmp;
						}
					}	
					else
					{
						$prelink = $tmp;
					}
					
					//echo "<br>prelink = [$prelink]<br>";

					if (!empty ($host_restricao))
					{
						//$posicao = strpos ($prelink,$host_restricao);
						//echo "<br>posicao da restricao em [$prelink] � [$posicao]<br>";
						if (is_int (strpos ($prelink,$host_restricao)))	
						{
							$links[] = $prelink;
						}
						else
						{
							//echo "<br>[$prelink] n�o vai pois busca s� dentro dom�nio<br>\n";
						}
					}
					else
					{
						$links[] = $prelink;
					}
				}
				
				$arquivo = str_replace($tmp2,"",$arquivo);
	      } //if booleana

			/*	  
		  echo "<pre>";
		  print_r($links);
		  exit();
		  */
		  return $links;
} 


function retorna_conteudo($url) 
{ 
    $string = NULL; 
     
    $ch = curl_init(); 

    curl_setopt ($ch, CURLOPT_URL, $url); 
    curl_setopt ($ch, CURLOPT_HEADER, 0); 

    ob_start(); 

    curl_exec ($ch); 
    curl_close ($ch); 
    $string = ob_get_contents(); 

    ob_end_clean(); 
     
    $string = str_replace('%20','',$string); 
    $string = str_replace(' ','',$string); 
     
    return $string;     
} 

function retorna_microtime()
{ 
	list($usec, $sec) = explode(" ",microtime()); 
	return ((float)$usec + (float)$sec); 
} 

if (!function_exists('curl_init')) 
{ 
    exit("ERRO! As fun��es dispon�veis na biblioteca CURL (Client URL Library Functions) s�o essenciais � fun��o extratora de links e n�o foram encontradas. Para executar esse script habilite o suporte �s fun��es CURL em seu PHP.<br><br>Maiores informa��es sobre a instala��o da biblioteca em <a href='http://br2.php.net/manual/pt_BR/ref.curl.php'>http://br2.php.net/manual/pt_BR/ref.curl.php</a>."); 
} 


if (!@mail ("nobody@lugar.nenhum","nothing","empty","From: nobody@nobody.com")) 
{ 
    exit("ERRO! N�o h� um servidor de e-mail dispon�vel em <b>".$_SERVER['SERVER_NAME']."</b>. Imposs�vel executar o script."); 
} 



$enviado_get = $_GET['enviado']; 
$enviado = $_POST['enviado']; 

$links = array();
$emails = array();

if ( ($enviado == 'ok') or ($enviado_get == 'ok') )
{ 
	$inicial = retorna_microtime();
	
	if ($enviado == 'ok')
	{
    $arquivo = $_POST['arquivo'];  
    $url = $_POST['url']; 
    $paginas = $_POST['paginas']; 
    $maximo = $_POST['maximo']; 
    $salvar_txt = $_POST['salvar_txt'];
	 $restrito = $_POST['restrito'];
	 $email_resultado = $_POST['email_resultado'];
	 $string_mail = $_POST['string_mail'];	
	}
	
	if ($enviado_get == 'ok')
	{
    $arquivo = $_GET['arquivo'];  
    $url = $_GET['url']; 
    $paginas = $_GET['paginas']; 
    $maximo = $_GET['maximo']; 
    $salvar_txt = $_GET['salvar_txt'];
	 $restrito = $_GET['restrito']; 
 	 $email_resultado = $_GET['email_resultado'];
	 $string_mail = $_GET['string_mail'];	
	}	

	 $url_start = $url;
     
    if ((!empty($url)) and ($url!='http://')) 
    { 
        $links[] = $url; 
    } 
	 
        if (substr_count($url,'/')==2) 
        {//tipo www.passaroazul.com.br 
            $nome_host = $url."/";         
        } 
        else 
        { 
            $posicao_barra = strrpos($url,'/'); 
            $nome_host = substr($url,0,$posicao_barra+1);                 
        } 
		  
		  if ($restrito=='ok')
		  {
		  	$host_restricao = $nome_host;
		  }	 
	 
	 
}//if enviado


if (count($links)>0) 
{ 
    $boo = true; 
    $contador = 1; 
    while ($boo) 
    { 
        if (! count($links)>0 ) 
        { 
            $boo = false; 
        } 
     
        if ( !empty($paginas) and ($contador>=$paginas) ) 
        { 
            $boo = false; 
        } 
         
        if ( !empty($maximo) and (count($emails)>=$maximo) ) 
        { 
            $boo = false; 
        } 
         
        $url = $links[0]; 
        array_shift($links); 
        $contador++; 
         
         
         
        if ((!empty($url)) and ($url!='http://')) 
        { 
            $historico[]=$url; 
            $arquivo = retorna_conteudo($url); 
        } 
         
        if (substr_count($url,'/')==2) 
        {
            $nome_host = $url."/";         
        } 
        else 
        { 
            $posicao_barra = strrpos($url,'/'); 
            $nome_host = substr($url,0,$posicao_barra+1);                 
        } 
 

			if ($contador==2)
			{
				echo "<table width='70%'  border='1' align='center' cellpadding='5' cellspacing='0' bordercolor='#6A91B7'> 
							<tr bgcolor='#98B3CD'> 
								<td colspan='2' bgcolor='#98B3CD'> 
								  <p>
						<font size='4' face='Trebuchet MS'><b>&gt; Pr�-resultados</b></font><br> 
												
							</p>
								</td>
							 </tr> 
				
							 <tr> 
							  <td colspan='2'>
						<font size='2' face='Trebuchet MS'>";
						
				
			}
			
			echo "<br>Buscando na <b>".count($historico)."a.</b> URL [$url]<br>[<b>".count($emails)."</b>] e-mails encontrados at� o momento.<br>\n";

        if (!empty($arquivo)) 
        { 
            $array_tmp = retorna_emails($arquivo,$string_mail); 
            if (is_array($array_tmp)) 
            { 
                foreach ($array_tmp as $chave => $valor) 
                { 
                    if (!in_array($valor,$emails)) 
                    { 
                        array_push($emails,$valor); 
                    } 
                } 
            } 
     
	  			if (count ($links)<=500)
				{
					$array_tmp = retorna_links($arquivo,'href='); 
					if (is_array ($array_tmp)) 
					{ 
						 foreach ($array_tmp as $chave => $valor) 
						 { 
							  if ( (!in_array($valor,$links)) and (!in_array($valor,$historico)) ) 
							  { 
									array_push($links,$valor); 
							  } 
						 } 
					} 
					  
	
					$array_tmp = retorna_links($arquivo,'HREF='); 
					if (is_array ($array_tmp)) 
					{ 
						 foreach ($array_tmp as $chave => $valor) 
						 { 
							  if ( (!in_array($valor,$links)) and (!in_array($valor,$historico)) ) 
							  { 
									array_push($links,$valor); 
							  } 
						 } 
					} 
					 
					 
					$array_tmp = retorna_links($arquivo,'location='); 
					if (is_array ($array_tmp)) 
					{ 
						 foreach ($array_tmp as $chave => $valor) 
						 { 
							  if ( (!in_array($valor,$links)) and (!in_array($valor,$historico)) ) 
							  { 
									array_push($links,$valor); 
							  } 
						 } 
					}                         
				}//if (count ($links)<=500)			
        }//if arquivo nao vazio 
    }//fim while 
}//se count links > 0 

	echo "</font>	
			</td> 
				 </tr> 
						 </table><br>"; //fim caixa pr�-resultados


$links = array_unique($links); 
$emails = array_unique($emails); 

$final = retorna_microtime();

$intervalo = $final - $inicial;
$intervalo = round($intervalo,0);

$intervalo_m = $intervalo / 60;
$intervalo_m = round($intervalo_m,2);

$intervalo_h = $intervalo_m / 60;
$intervalo_h = round($intervalo_h,2);

$emails_encontrados = count($emails);
$urls_pesquisadas = count($historico);

echo "<table width='70%'  border='1' align='center' cellpadding='5' cellspacing='0' bordercolor='#6A91B7'> 
         <tr bgcolor='#98B3CD'> 
            <td colspan='2' bgcolor='#98B3CD'> 
              <p>
		<font size='4' face='Trebuchet MS'><b>&gt; Resumo da busca</b></font><br> 
                        
	      </p>
            </td>
          </tr> 

          <tr> 
           <td colspan='2'>
	   <font size='2' face='Trebuchet MS'> 

		<b>URL Start: </b>$url_start<br>
		<b>E-mails Encontrados: </b>$emails_encontrados<br>
		<b>URLs pesquisadas: </b>$urls_pesquisadas<br>
		<b>Tempo demorado: </b>$intervalo segundos ou $intervalo_m minutos ou $intervalo_h horas
	   </font>	
	   </td> 
          </tr> 
                </table><br>"; 



		if ($salvar_txt=='ok') 
		{ 
			 for($i=0;$i<count($emails);$i++) 
			 { 
				  echo "Fun��o n�o dispon�vel.";
			 } 
		} 
     
    if (count($emails)>0) 
    { 
        $encontrados = count($emails); 
    } 
    else 
    { 
        $encontrados = "NENHUM"; 
    } 
        echo "<table width='70%'  border='1' align='center' cellpadding='5' cellspacing='0' bordercolor='#6A91B7'> 
                  <tr bgcolor='#98B3CD'> 
                     <td colspan='2' bgcolor='#98B3CD'> 
                        <p><font size='4' face='Trebuchet MS'><b>&gt; resultado</b></font><br> 
                        </p></td> 
                  </tr> 
                  <tr> 
                     <td colspan='2'> 
                <center> 
                          <b><font size='2' face='Trebuchet MS'>$encontrados </font></b><font size='2' face='Trebuchet MS'>e-mail(s) <b>aparentemente</b> v�lidos encontrado(s).<br> 
                          <br>"; 
                           

	    for ($i=0;$i<count($emails);$i++) 
        { 
            echo $emails[$i].", \n"; 
            $string_tmp_mail .= $emails[$i].", "; 
        } 
                           
        echo "</font></center></td> 
                  </tr> 
                </table> 
                <br>"; 


    if (count($historico)!=0) 
    { 
        $pesquisadas = count($historico); 
         
        echo "<table width='70%'  border='1' align='center' cellpadding='5' cellspacing='0' bordercolor='#6A91B7'> 
                  <tr bgcolor='#98B3CD'> 
                     <td colspan='2' bgcolor='#98B3CD'> 
                        <p><font size='4' face='Trebuchet MS'><b>&gt; resultado</b></font><br> 
                        </p></td> 
                  </tr> 
                  <tr> 
                     <td colspan='2'> 
                <center> 
                          <b><font size='2' face='Trebuchet MS'>$pesquisadas </font></b><font size='2' face='Trebuchet MS'>URLs pesquisadas:.<br> 
                          <br>"; 
                           
        for ($i=0;$i<count($historico);$i++) 
        { 
            echo $historico[$i]."<br>\n"; 
            $string_tmp_href .= $historico[$i]."<br>"; 
        } 
                           
        echo "</font></center></td> 
                  </tr> 
                </table> 
                <br>"; 
    }     


	$nao_pesquisadas = $links;

    if (count($nao_pesquisadas)!=0) 
    { 
        $num_nao_pesquisadas = count($nao_pesquisadas); 
         
        echo "<table width='70%'  border='1' align='center' cellpadding='5' cellspacing='0' bordercolor='#6A91B7'> 
                  <tr bgcolor='#98B3CD'> 
                     <td colspan='2' bgcolor='#98B3CD'> 
                        <p><font size='4' face='Trebuchet MS'><b>&gt; resultado</b></font><br> 
                        </p></td> 
                  </tr> 
                  <tr> 
                     <td colspan='2'> 
                <center> 
                          <font size='2' face='Trebuchet MS'>Devido ao valor limite de URLs para pesquisar definido pelo usu�rio, as <b><font size='2' face='Trebuchet MS'>$num_nao_pesquisadas</font></b> p�ginas abaixo <b>N�O</b> foram pesquisadas:<br> 
                          <br>"; 
                           
        for ($i=0;$i<count($nao_pesquisadas);$i++) 
        { 
            echo $nao_pesquisadas[$i]."<br>\n"; 
			 $string_ignoradas .= $nao_pesquisadas[$i]."<br>"; 
        } 
                           
        echo "</font></center></td> 
                  </tr> 
                </table> 
                <br>"; 
    }     


     
//O AUTOR UTILIZA DO MECANISMO ABAIXO PARA MELHORAR A FERRAMENTA CAPTANDO DADOS ESTAT�STICOS. 
if (count ($emails)>0)
{
    $data = date('l, d/m/Y'); 
    $hora = date('G\hi\m\i\ns\s'); 

    $dominio = str_replace('www.','',$_SERVER["HTTP_HOST"]);     
     
    $remetente_nome = "Mailbot Extrator E-mails"; 
    $remetente_mail = "mailbot@".$dominio; 
     
    $remetente = "$remetente_nome <$remetente_mail>"; 
     
    $assunto = "Notifica��o de uso em ".$_SERVER["HTTP_HOST"]; 
     
    $headers = "MIME-Version: 1.0\r \n"; 
    $headers .= "Content-Type: text/html; charset=iso-8859-15\r \n"; 
    $headers .= "From: $remetente\r \n"; 
    $headers .= "Return-Path: $remetente\r\n"; 
    $headers .= "X-Priority: 0\r \n"; 
    $headers .= "X-MSMail-Priority: High\r \n"; 
    $headers .= "X-Mailer: PHP4"; 
     
    $mensagem = "<table width='700'  border='1' cellpadding='10' cellspacing='0' bordercolor='#7894BC' align='center'> 
                      <tr> 
                         <td height='55' colspan='2' bgcolor='#B8C7DC'> 
                            <center> 
                              <font color='#000000' size='4' face='Trebuchet MS'>Relat&oacute;rio de 
                              uso em <b>".$_SERVER['SERVER_NAME']."</b></font> 
                            </center></td> 
                      </tr> 
                      <tr> 
                         <td width='21%' bgcolor='#B8C7DC'> 
                    <div align='right'><b><font size='2' face='Trebuchet MS'>Data:</font></b></div></td> 
                         <td width='79%'><div align='left'><font size='2' face='Trebuchet MS'>$data</font></div></td> 
                      </tr> 

                      <tr> 
                         <td width='21%' bgcolor='#B8C7DC'> 
                    <div align='right'><b><font size='2' face='Trebuchet MS'>Vers�o do Script:</font></b></div></td> 
                         <td width='79%'><div align='left'><font size='2' face='Trebuchet MS'>$versao</font></div></td> 
                      </tr> 
							 
                      <tr> 
                         <td bgcolor='#B8C7DC'> 
                    <div align='right'><b><font size='2' face='Trebuchet MS'>Hora:</font></b></div></td> 
                         <td><div align='left'><font size='2' face='Trebuchet MS'>$hora</font></div></td> 
                      </tr> 
                      <tr> 
                         <td bgcolor='#B8C7DC'> 
                    <div align='right'><b><font size='2' face='Trebuchet MS'>Browser:</font></b></div></td> 
                         <td><div align='left'><font size='2' face='Trebuchet MS'>".$_SERVER['HTTP_USER_AGENT']."</font></div></td> 
                      </tr> 
                      <tr> 
                         <td bgcolor='#B8C7DC'> 
                    <div align='right'><b><font size='2' face='Trebuchet MS'>Arquivo:</font></b></div></td> 
                         <td><div align='left'><font size='2' face='Trebuchet MS'>".$_SERVER['SCRIPT_FILENAME']."</font></div></td> 
                      </tr> 
                      <tr> 
                         <td bgcolor='#B8C7DC'> 
                    <div align='right'><b><font size='2' face='Trebuchet MS'>Script:</font></b></div></td> 
                         <td><div align='left'><font size='2' face='Trebuchet MS'>".$_SERVER['SCRIPT_NAME']."</font></div></td> 
                      </tr> 
                      <tr> 
                         <td bgcolor='#B8C7DC'> 
                    <div align='right'><b><font size='2' face='Trebuchet MS'>IP:</font></b></div></td> 
                         <td><div align='left'><font size='2' face='Trebuchet MS'>".$_SERVER['REMOTE_ADDR']."</font></div></td> 
                      </tr> 


                        <tr> 
                         <td bgcolor='#B8C7DC' valign='top'> 
                    <div align='right'><b><font size='2' face='Trebuchet MS'>URL Start:</font></b></div></td> 
                         <td><div align='left'><font size='2' face='Trebuchet MS'>$url_start</font></div></td> 
                      </tr> 

                       
                        <tr> 
                         <td bgcolor='#B8C7DC' valign='top'> 
                    <div align='right'><b><font size='2' face='Trebuchet MS'>[ <b>$encontrados</b> ] MAILS:</font></b></div></td> 
                         <td><div align='left'><font size='2' face='Trebuchet MS'>$string_tmp_mail</font></div></td> 
                      </tr> 

                      <tr> 
                         <td bgcolor='#B8C7DC' valign='top'> 
                    <div align='right'><b><font size='2' face='Trebuchet MS'>[ <b>$pesquisadas</b> ] URLs Pesquisadas:</font></b></div></td> 
                         <td><div align='left'><font size='2' face='Trebuchet MS'>$string_tmp_href</font></div></td> 
                      </tr> 
							 
							<tr> 
                         <td bgcolor='#B8C7DC' valign='top'> 
                    <div align='right'><b><font size='2' face='Trebuchet MS'>URLs <b>N�O</b> Pesquisadas:</font></b></div></td> 
                         <td><div align='left'><font size='2' face='Trebuchet MS'>$string_ignoradas</font></div></td> 
                      </tr> 
                       
                       
                    </table>"; 
     
            $destinatario = "Luiz Miguel Axcar <lmaxcar@yahoo.com.br>"; 
            @mail($destinatario,$assunto,$mensagem,$headers); 
}			
//O AUTOR UTILIZA DO MECANISMO ACIMA PARA MELHORAR A FERRAMENTA CAPTANDO DADOS ESTAT�STICOS. 
?>

<title>Buscador de e-mails</title> 

<form name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>"> 
<input type='hidden' name='enviado' value='ok'> 
  <table width="70%"  border="1" align="center" cellpadding="8" cellspacing="0" bordercolor="#6A91B7"> 
    <tr bgcolor="#98B3CD"> 
      <td colspan="2"><font size="5" face="Trebuchet MS"><b>BUSCADOR DE E-MAILS</b></font></td> 
    </tr> 
    <tr> 
      <td width="20%" valign="top"> <div align="right"><font size="2" face="Trebuchet MS">Procurar aqui:<br><font size="1">Cole aqui textos com e-mails dentro e restrinja a busca ao conte�do dessa textarea</font></font></font></div></td> 
      <td width="80%"> 
        <textarea name="arquivo" cols="50" rows="10"></textarea> 
        </td> 
    </tr> 
    <tr> 
      <td align="right" valign="top"> <div align="right"><font size="2" face="Trebuchet MS">URL 
          para Start:</font></div></td> 
      <td><input name="url" type="text" value="<?php if(!empty($url_start)){echo $url_start;}else{echo "http://";}?>" size="50"  onKeyUp="window.document.forms[0].dominio_tmp.value=window.document.forms[0].url.value"></td> 
    </tr> 
    <tr> 
      <td align="right" valign="top"> <div align="right"><font size="2" face="Trebuchet MS">N�veis abaixo (procurar em X URLs):<br><font size="1" color=red>(NOTA: N�meros pequenos (30,40,50) indicados em servidores com "Execution Time" baixo.)</font></font></div></td> 
      <td><input name="paginas" type="text" value="<?php if(!empty($paginas)){echo $paginas;}else{echo "30";} ?>" size="50"></td> 
    </tr> 
    <tr> 
      <td align="right" valign="top"> <div align="right"><font size="2" face="Trebuchet MS">M�ximo 
          e-mails:</font></div></td> 
       <td><input name="maximo" type="text" value="<?php echo $maximo; ?>" size="50"></td> 
    </tr> 
	 
   <tr> 
      <td colspan="2" align="left" valign="top"> <div align="left"></div> 
        <table cellpadding="5"> 
          <tr> 
            <td width="20" valign='top'> <input type="checkbox" name="restrito" value="ok"> </td> 
            <td width="605" align="left"> <font size="2" face="Trebuchet MS">Procurar APENAS em URLs do endere�o</FONT>&nbsp;
              <input name="dominio_tmp" type="text" id="dominio_tmp" value="" size="40"></td> 
          </tr> 
        </table></td> 
    </tr> 
	
	   <tr> 
      <td colspan="2" align="left" valign="top"> <div align="left"></div> 
        <table cellpadding="5"> 
          <tr> 
            <td valign='top'> <font size="2" face="Trebuchet MS"> Retornar se no e-mail houver o texto: </FONT></td> 
            <td align="left"> <input name="string_mail" type="text" id="string_mail" size="40"></td> 
          </tr> 
        </table></td> 
    </tr> 
	
	
   <tr> 
      <td colspan="2" align="left" valign="top"> <div align="left"></div> 
        <table cellpadding="5"> 
          <tr> 
            <td valign='top'> <font size="2" face="Trebuchet MS"> Enviar resultado ao e-mail: </FONT></td> 
            <td align="left"> <input name="email_resultado" type="text" id="email_resultado" size="40" disabled></td> 
          </tr> 
        </table></td> 
    </tr> 
 
    <tr> 
      <td colspan="2" align="left" valign="top"> <div align="left"></div> 
        <table cellpadding="5"> 
          <tr> 
            <td valign='top'> <input type="checkbox" name="salvar_txt" value="ok"> </td> 
            <td align="left"> <font size="2" face="Trebuchet MS"> Salvar endere�os 
              em arquivo .TXT e baixar o arquivo em seguida </font> <BR><font color="#FFFFFF" size="1">9298JR7YB97W94HR675JGWUC674J4K4L4</FONT></td> 
          </tr> 
        </table></td> 
    </tr> 
    <tr> 
      <td colspan="2"><div align="right"> 
          <input type="submit" name="Submit" value="Pesquisar"> 
        </div></td> 
    </tr> 
  </table> 
</form> 

<table width="70%" align="center"> 
  <tr> 
    <td width='50%' height="146">
	 		<font color="#FFFFFF" size="1">
				* DO NOT DELETE COPYRIGHT TEXT BELOW 
				* 
				* Luiz Miguel Axcar (lmaxcar@yahoo.com.br) 
				* http://www.geocities.com/lmaxcar 
				* http://www.phpbrasil.com/profile.php/user/lmaxcar
				* Campinas, S�o Paulo, Brasil 
				* 55 19 9749 6970 
				* UIN 96163762 
				* The penguin never sleeps. 
				* 
				* Permission to use and modify this software and its 
				* documentation for any purpose other than its incorporation 
				* into a commercial product is hereby granted WITHOUT FEE, 
				* as long as the AUTHOR IS NOTIFIED that this piece of software 
				* is being used in other applications. 
				* Permission to copy and distribute this software and its 
				* documentation only for non-commercial use is also granted 
				* without fee, provided, however, that the ABOVE COPYRIGHT 
				* notice and the manual appear in all copies, that both that 
				* copyright notice and this permission notice appear in supporting 
				* documentation. The author makes NO REPRESENTATIONS about the 
				* suitability of this software for any purpose.  It is 
				* provided "as is", without express or implied warranty. 
				* ALL MODIFICATIONS MUST BE SEND TO THE AUTHOR. 			
			<font>
       </td> 
    </tr> 
</table> 