<? 
// Variables that are used are the following
// $DB_SERVER : Name of MySql server by default "localhost"
// $DB_USER   : User name taht is used to connect to MySql
// $DB_PASS   : User password for MySQL conenction
// $DB_NAME   : Name of database to use

$DB_SERVER = "localhost";
$DB_USER = "dbusername";
$DB_PASS = "dbpasword"; 
$DB_NAME = "dbname";
$DOWNLOADS_PER_PAGE = 10; // Number of downloads per page

?>