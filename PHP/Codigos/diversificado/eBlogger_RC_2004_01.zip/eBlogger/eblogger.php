
<?php 
require "eblogger_config.php"; 
?>
<html>
<head>
<title><?php echo "$title"; ?></title>
<?php
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"$ebloggerurl/style.css\">";
?>
</head>
<body topmargin="0">

<strong><?php echo $title; ?></strong><br><br>

<?php
@mysql_connect($db_host,$db_user,$db_pass) or die("Couldn't Connect to Database");
@mysql_select_db($db_name) or die("Couldn't Select Database");
$pagelimit = "$newsperpage";
$basikSQL = mysql_query("SELECT * FROM $table");
$totalrows = mysql_num_rows($basikSQL);
$pagenums = ceil ($totalrows/$pagelimit);

    if ($page==''){
        $page='1';
    }

    $start = ($page-1) * $pagelimit;


$starting_no = $start + 1;

if ($totalrows - $start < $pagelimit) {
   $end_count = $totalrows;
} elseif ($totalrows - $start >= $pagelimit) {
   $end_count = $start + $pagelimit;
}

if ($totalrows - $end_count > $pagelimit) {
   $var2 = $pagelimit;
} elseif ($totalrows - $end_count <= $pagelimit) {
   $var2 = $totalrows - $end_count;
}

$space = "&nbsp;";
$basikSQL = mysql_query("SELECT * FROM $table ORDER BY dbdate DESC, id DESC LIMIT $start,$pagelimit");   
$num=mysql_numrows($basikSQL);

mysql_close();

$i=0;
while ($i < $num) {
$newstitle=mysql_result($basikSQL,$i,"newstitle");
$dbdate=mysql_result($basikSQL,$i,"dbdate");
$newsdate=mysql_result($basikSQL,$i,"newsdate"); 
$news=mysql_result($basikSQL,$i,"news");      
echo "<table border=\"1\" bordercolor=\"#FFFFFF\" bordercolorlight=\"#000000\" cellpadding=\"2\" cellspacing=\"0\" width=\"98%\" height=\"32\">
  <tbody> 
  <tr> 
    <td align=\"left\" class='phptitle'><b>$newstitle</b><br>[$newsdate]</td>
  </tr>
  <tr> 
    <td class='phpcontent'>".stripslashes($news)."<br></td>
  </tr>
  </tbody> 
</table>
<br>";
++$i;
}
if(mysql_num_rows($basikSQL) == 0)
{
echo "<strong>There are currently no blogs in the database!</strong>";
}
if ($page>1) {
        echo "� <a href='{$_SERVER['PHP_SELF']}?page=".($page-1)."'>Prev" . $space . $pagelimit . " blogs</a>" . $space . $space . "";
    }


    for ($i=1; $i<=$pagenums; $i++) {
        if ($i!=$page) {
            echo " <a href='{$_SERVER['PHP_SELF']}?page=$i'>$i</a>";
        }
        else {
            echo " <b>$i</b>";
        }
    }


    if ($page<$pagenums) {
        echo "" . $space . $space . $space . $space . " <a href='{$_SERVER['PHP_SELF']}?page=".($page+1)."'>Next " . $var2 . " blogs</a> �";
    }
?>
<hr color="#333333" width="100%" align="left">
<strong><a href="<?php echo $ebloggerurl; ?>/eblogger_admin.php">eBlogger Admin</a>

</div>
</body>
</html>