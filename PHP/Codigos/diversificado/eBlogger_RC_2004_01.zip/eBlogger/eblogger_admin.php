<?php
require "eblogger_config.php";
if (($_SERVER[ 'PHP_AUTH_USER' ] != "$admin") || ($_SERVER[ 'PHP_AUTH_PW' ] != "$pass"))
{
header('WWW-Authenticate: basic realm="eblogger Admin');
header('HTTP/1.0 401 Unauthorized');
echo "Authorization Required.";
exit;
}

require "eblogger_config.php";
$dbdate = gmDate("Ymd");

?>
<html>
<head>
<title>eblogger Admin</title>
<?php
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"$ebloggerurl/style.css\">";
?>
<script language="JavaScript" type="text/javascript">
<!--
function checkform ( form )
{
  if (form.newstitle.value == "") {
    alert( "Please enter the title." );
    form.newstitle.focus();
    return false ;
  }
  if (form.news.value == "") {
    alert( "Please enter the blog." );
    form.news.focus();
    return false ;
  }
  return true ;
}
//-->
<!--
function confirmdelnewz(question, uri) { 
    if(confirm(question)){ 
        document.location=uri + '&confirm=1'; 
    } 
    return false; 
} 
//-->
</script>
</head>
<body>
<?php
function delnewz($id)
{
require "eblogger_config.php";
$link = mysql_connect("$db_host","$db_user","$db_pass");
mysql_select_db("$db_name",$link);
$query="DELETE from $table WHERE id = $id";
mysql_query($query) or print "<b>&gt;&gt;&gt; MySQL-Error: ".mysql_errno()." -&gt; ".mysql_error()."</b><br>\n";;
}
if( isset($delete)) 
{ 
delnewz($delete); 
echo "<strong>The blog was deleted!<br>";
echo "<strong>Click <a href=\"{$_SERVER['PHP_SELF']}\">HERE</a> to return to the admin section";
return $query;
}
?>
<form name="insertnewz" method="post" action="<?php $_SERVER['PHP_SELF']; ?>" onsubmit="return checkform(this);">
<div align="left">
<table width="250" border="0" cellspacing="0" cellpadding="3">
  <tr> 
    <td>
<p align="left"><strong>eBlogger Admin</strong></p>
  </td> 
    </tr>
  <tr> 
    <td>
<p><b>Date:<br>

      <input type="text" name="newsdate" value="<?php echo "$date"; ?>" size="30" readonly="readonly" class="readonly">
    </td>
  </tr>
    <td><p><b>Subject:<br>
      <input type="text" name="newstitle" value="" size="30">
    </td>
  </tr>
  <tr> 
    <td>

    <p><b>Blog:</b><br>
 <textarea rows="8" cols="30" name="news"></textarea>
    </td>
  </tr>
  <tr> 
    <td><input type="hidden" name="dbdate" value="<?php echo $dbdate; ?>">
      <input type="submit" name="submit" value="Add Blog!">
</form>
    </td>
  </tr>
<tr>
<td>
<?php
if ($submit) {
$link = mysql_connect("$db_host","$db_user","$db_pass");
mysql_select_db("$db_name",$link);
$insnewz="INSERT into $table (dbdate,newsdate,newstitle,news) values ('".$dbdate."','".addslashes($newsdate)."','".addslashes($newstitle)."','".addslashes($news)."')";
$result = mysql_query($insnewz);
echo "<strong>The Newz was added!<br>";
}
?>
<hr color="#333333" width="100%" align="left">
<strong>Previous Blogs:</strong><br><br>

<?php
@mysql_connect($db_host,$db_user,$db_pass) or die("Couldn't Connect to Database");
@mysql_select_db($db_name) or die("Couldn't Select Database");
$pagelimit = "$newsperpage";
$basikSQL = mysql_query("SELECT * FROM $table");
$totalrows = mysql_num_rows($basikSQL);
$pagenums = ceil ($totalrows/$pagelimit);

    if ($page==''){
        $page='1';
    }

    $start = ($page-1) * $pagelimit;


$starting_no = $start + 1;

if ($totalrows - $start < $pagelimit) {
   $end_count = $totalrows;
} elseif ($totalrows - $start >= $pagelimit) {
   $end_count = $start + $pagelimit;
}

if ($totalrows - $end_count > $pagelimit) {
   $var2 = $pagelimit;
} elseif ($totalrows - $end_count <= $pagelimit) {
   $var2 = $totalrows - $end_count;
}

$space = "&nbsp;";
$basikSQL = mysql_query("SELECT * FROM $table ORDER BY dbdate DESC, id DESC LIMIT $start,$pagelimit");   
$num=mysql_numrows($basikSQL);

mysql_close();

$i=0;
while ($i < $num) {
$newstitle=mysql_result($basikSQL,$i,"newstitle");
$newsdate=mysql_result($basikSQL,$i,"newsdate");       
$news=mysql_result($basikSQL,$i,"news"); 
 
$id=mysql_result($basikSQL,$i,"id");
$dbdate=mysql_result($basikSQL,$i,"dbdate");
echo "<table border=\"1\" bordercolor=\"#FFFFFF\" bordercolorlight=\"#000000\" cellpadding=\"4\" cellspacing=\"0\" width=\"95%\" height=\"32\">
  <tbody> 
  <tr> 
    <td align=\"left\" class='phptitle'><b>$newstitle</b><br>[$newsdate]</td>
  </tr>
  <tr> 
    <td class='phpcontent'>$news<br></td>
  </tr>
	<tr>
  <td><b><a href=\"{$_SERVER['PHP_SELF']}?delete=$id\" onclick=\"return confirmdelnewz('Are you sure you want to delete this blog?','{$_SERVER['PHP_SELF']}?delete=$id')\"><strong>Delete This Blog</a> 
 </td>
 </tr>
 </tbody> 
</table>
<br>";
++$i;
}
if(mysql_num_rows($basikSQL) == 0)
{
echo "<strong>There are currently no blogs in the database!</strong>";
}
if ($page>1) {
        echo "� <a href='{$_SERVER['PHP_SELF']}?page=".($page-1)."'>Prev" . $space . $pagelimit . " blogs</a>" . $space . $space . "";
    }


    for ($i=1; $i<=$pagenums; $i++) {
        if ($i!=$page) {
            echo " <a href='{$_SERVER['PHP_SELF']}?page=$i'>$i</a>";
        }
        else {
            echo " <b>$i</b>";
        }
    }


    if ($page<$pagenums) {
        echo "" . $space . $space . $space . $space . " <a href='{$_SERVER['PHP_SELF']}?page=".($page+1)."'>Next " . $var2 . " blogs</a> �";
    }
?>
<hr color="#333333" width="100%" align="left">
<strong><a href="<?php echo $ebloggerurl; ?>/eblogger.php">View Blogs</a>
</td>
</tr>
</table>
</div>
</body>
</html>