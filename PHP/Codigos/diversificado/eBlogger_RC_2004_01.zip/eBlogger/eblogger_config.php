<?php
//this is where you make the config changes to eblogger
//to suit your website. i have not included any copyrights
//in this script, as even when i did in the past, people
//just stripped them out. so use this as you want to
//but please email me at jonathen@blueyonder.co.uk
//to let me see my script on your website - that's all
//i ask. you can even claim this to be your own creation
//i don't care - i just like to see variations of it on
//other people's websites.
// www.winterburns.co.uk - more scripts available here.

//CONFIGURATIONS BELOW:
//the title will be displayed above your news module.
$title = "eBlogger: website news log";

//you can keep this as GMT or alter for your needs.
$date = gmDate("d/m/y G:i \G\M\T");

//how many news articles you want displayed per page
$newsperpage="5";
 
//$ebloggerurl is the path to your install directory, 
//i.e: http://www.yourdomain.com/eblogger
//NO TRAILING SLASH!
$ebloggerurl = "http://www.yourdomain.com/eblogger";

//Database Settings:
//Enter your MySQL username, password, database & table below:
$db_host="localhost";
$db_user="your_db_user";
$db_pass="your_db_pass";
$db_name="your_db";
$table="eblogger";

//eBlogger administrator settings:
$admin="choose_a_username";
$pass="choose_a_password";
?>