eBlogger RC 2004/01 README FILE.

To install eBlogger, simply upload the following files to your web directory:
eblogger.php
eblogger_admin.php
eblogger_config.php
style.css (or use your own stylesheet)

Configure eblogger_config.php with your MySQL details and other required info.
Dump eblogger.sql into your eBlogger database.

Include eblogger.php in the page you want it visible on using:
<?php include "eblogger.php"; ?>

If you get errors, trying setting register_globals to ON in php.ini. 
If you get spurious \ notations in your blogs, switch Magic_Quotes to OFF in php.ini

i have not included any copyrights in this script, as even when i did in the past, people
just stripped them out. so use this as you want to but please email me at jonathen@blueyonder.co.uk to let me see my script on your website - that's all
i ask. you can even claim this to be your own creation i don't care - i just like to see variations of it on other people's websites.

http://www.winterburns.co.uk - more scripts available here.