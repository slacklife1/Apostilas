CREATE TABLE eblogger (
  id int(11) NOT NULL auto_increment,
  dbdate varchar(10) NOT NULL default '',
  newsdate varchar(50) NOT NULL default '',
  newstitle varchar(100) NOT NULL default '',
  news text NOT NULL,
  PRIMARY KEY  (id),
  FULLTEXT KEY news (news)
) TYPE=MyISAM COMMENT='eBlogger Table';
