<?
 
   $to = "you@yourdomain.com";
   $msg = "$name\n\n";
   $msg .= "$message\n\n";

  mail($to, $subject, $msg, "From: My web site\nReply-To: $email\n");

?>


