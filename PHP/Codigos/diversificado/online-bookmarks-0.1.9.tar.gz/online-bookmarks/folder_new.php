<?php
include_once ("./config/config.php");
include_once ("./main.php");
include_once ("./messages/$language/msg.php");
$title=$msg_title_folder_new;
include ("./header.php");

$get_active=set_GET_active();
$post_name=set_POST_name();

if ($get_active==""){
  $get_active=0;
}

$folder=mysql_query ("SELECT name FROM folder
                      WHERE id='$get_active'
                      AND user='$_SERVER[PHP_AUTH_USER]'
                      AND deleted!='1';")
        or die ($msg_sql_error);
if (mysql_num_rows($folder)==0){$get_active="0";}
if ($post_name==""){
?>

<form action="<?php echo $_SERVER["SCRIPT_NAME"] . "?active=" . $get_active; ?>" name="folder_new" method="POST">
<p><?php echo $msg_folder_new_name; ?><br>
<input type=text name="name" size="50" value=""></p>
<input type="submit" value="<?php echo $msg_ok; ?>">
<input type="button" value="<?php echo $msg_cancel; ?>" onClick="parent.close()">
</form>
<script>
document.folder_new.name.focus();
</script>

<?php
}
else {
  mysql_query ("INSERT INTO folder (childof, name, user)
    values (
    '$get_active',
    '$post_name',
    '$_SERVER[PHP_AUTH_USER]'
    );") or die ($msg_sql_error);
  echo "<script language=\"JavaScript\">self.close();</script>";
}
include ("./footer.php");
?>
