<?php

# die sprache der online-bookmarks
# bisher verf�gbar: "deutsch" und "english".
$language="english";

# das symbol f�r das geschlossene verzeichnis
$folder_closed="<img src=\"./images/folder.gif\" border=\"0\" alt=\"\" align=\"absmiddle\">";

# das symbol f�r das ge�ffnete verzeichnis
$folder_open="<img src=\"./images/folder_open.gif\" border=\"0\" alt=\"\" align=\"absmiddle\">";

# das symbol f�r das pluszeichen einer zusammengeklappten ordnerstruktur
#$plus="<img src=\"./images/plus.gif\" align=\"bottom\" border=\"0\" alt=\"\"> ";
$plus="<span style=\"font-family:Courier;\">+ </span>";

# das symbol f�r das minuszeichen einer aufgeklappten ordnerstruktur
#$minus="<img src=\"./images/minus.gif\" align=\"bottom\" border=\"0\" alt=\"\"> ";
$minus="<span style=\"font-family:Courier;\">- </span>";

# zwei leere zeichen f�r korrekte abst�nde zwischen den ordnern
$neutral="<span style=\"font-family:Courier;\">&nbsp;&nbsp;</span>";

# das symbol f�r ein bookmark
$file="<img src=\"./images/file.gif\" align=\"middle\" border=\"0\" alt=\"\">";

# die pixelbreite der folder-kolonne
$column_width_folder="280";

# die pixelbreite der bookmarks-kolonne in der tabelle
$column_width_bookmark="350";

# die mindesth�he der ganzen tabelle
$table_hight="250";

# die farbe f�r die markierung des aktiven ordners
$color_active="#d6d6d6";

# soll der "sie befinden sich in..." pfad gelinkt angezeigt werden? 
# "on", "yes" oder "1" um zu aktivieren
$path_linked="on";

# welche kolonnen sollen angezeigt werden?
# die kolonne mit dem bearbeitungs-datum
$show_column_date="off";

# die kolonne um bookmarks zu editieren
$show_column_edit="on";

# die kolonne um bookmarks zu verschieben
$show_column_move="on";

# die kolonne um boomkarks zu l�schen
$show_column_delete="on";

?>
