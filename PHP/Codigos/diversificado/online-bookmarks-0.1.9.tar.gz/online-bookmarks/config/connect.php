<?

if (!isset($_SERVER['PHP_AUTH_USER'])){
  die ("Logon!");
}


function db_connect() {

        $server='localhost';  # this is the place where your MySQL Server is found.
        $user='username';     # the user that connects to it ...
        $pw='password';       # ... and its password.
        $db='bookmarks';      # in this database are the online-bookmarks stored.

        $link = mysql_connect( $server, $user, $pw )
        or die ("no connection to server");
        if ($link && mysql_select_db("$db")) {
                return( $link);
        }
        else {
                return(FALSE);
        }
}

?>
