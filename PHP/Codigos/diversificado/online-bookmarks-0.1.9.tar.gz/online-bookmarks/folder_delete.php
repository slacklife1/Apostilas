<?php
include_once ("./config/config.php");
include_once ("./main.php");
include_once ("./messages/$language/msg.php");
$title=$msg_title_folder_delete;
include ("./header.php");

$get_active=set_GET_active();


if (!isset ($get_active) || $get_active=="" || $get_active=="0"){
  echo $msg_no_folder_selected;	
}
else if (isset ($_GET['noconfirm']) && $_GET['noconfirm']=='1'){
  mysql_query ("UPDATE folder set deleted='1'
                WHERE id='$get_active'  
                AND user='$_SERVER[PHP_AUTH_USER]';") 
                or die ($msg_sql_error);
  echo "<script language=\"JavaScript\">self.close();</script>";
}
else {
  $folder=mysql_query ("SELECT name FROM folder
                        WHERE id='$get_active'
                        AND user='$_SERVER[PHP_AUTH_USER]'
                        AND deleted!='1';")
                        or die ($msg_sql_error);
  if (mysql_num_rows($folder)==0){
    die ($msg_folder_does_not_exist);
  }

  ?>
<table border=0>
  <tr>
    <td><?php echo $msg_folder_delete; ?></td>
  </tr>
  <tr>
    <td>
      <?php echo $folder_closed . " " . mysql_result($folder,""); ?><br>
    </td>
  </tr>
</table>
<form action="<?php echo $_SERVER["SCRIPT_NAME"] . "?active=" . $get_active . "&amp;noconfirm=1";?>" method="post" name="bmdelete"></p>
<input type="submit" value="<?php echo $msg_ok; ?>">
<input type="button" value="<?php echo $msg_cancel; ?>" onClick="parent.close()">
</form>
  <?php
}
include ("./footer.php");
?>
