<?php
include_once ("./config/config.php");
include_once ("./main.php");
include_once ("./messages/$language/msg.php");
$title=$msg_title_bookmark_edit;
include ("./header.php");

$get_active=set_GET_active();
$post_title=set_POST_title();
$post_url=set_POST_url();
$post_description=set_POST_description();
$post_private=set_POST_private();

if ($post_title=="" || $post_url==""){
  $bm_value=mysql_query("SELECT title,url,private,description,unix_timestamp(date)
                         FROM bookmark 
                         WHERE id='$get_active' 
                         AND user='$_SERVER[PHP_AUTH_USER]'") 
                         or die ($msg_sql_error);
?>
<form action="<?php echo $_SERVER["SCRIPT_NAME"] . "?active=" . $get_active; ?>" name=bookmark_new method="post">
<p><?php echo $msg_bookmark_title; ?><br>
<input type=text name="title" size="50" value="<?php echo mysql_result($bm_value, "","title"); ?>"></p>
<p><?php echo $msg_bookmark_url; ?><br>
<input type=text name="url" size="50" value="<?php echo mysql_result($bm_value, "", "url"); ?>"></p>
<!-- <p>Privat<br>
<input type="checkbox" name="private" value="1" checked></p> -->
<p><?php echo $msg_bookmark_description; ?><br>
<textarea name="description" cols="50" rows="8"><?php echo mysql_result($bm_value, "", "description"); ?></textarea></p>
<p><?php echo $msg_last_edited; ?><br>
<?php echo date("d.m.Y", mysql_result($bm_value, "","unix_timestamp(date)"));?></p>
<input type="submit" value="<?php echo $msg_ok; ?>">
<input type="button" value="<?php echo $msg_cancel; ?>" onClick="parent.close()">
</form>
<script>
document.bookmark_new.title.focus();
</script>
<?php
}
else {
  mysql_query ("UPDATE bookmark set
                       title='$post_title',
                       url='$post_url',
                       description='$post_description',
                       private='$post_private'
                WHERE id='$get_active'  
                AND user='$_SERVER[PHP_AUTH_USER]';") 
                or die ($msg_sql_error);
  echo "<script language=\"JavaScript\">self.close();</script>";
}
include ("./footer.php");
?>

