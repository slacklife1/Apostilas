<?php
include_once ("./config/config.php");
include_once ("./main.php");
include_once ("./messages/$language/msg.php");
$title=$msg_title_folder_rename;
include ("./header.php");

$get_active=set_GET_active();
$post_name=set_POST_name();

if ($get_active=="" || $get_active=="0"){
  echo $msg_no_folder_selected;	
}
else if (!isset($post_name) || $post_name==""){
  $name=mysql_query ("SELECT name FROM folder
                      WHERE id='$get_active' 
                      AND user='$_SERVER[PHP_AUTH_USER]'
                      AND deleted!='1';")
                      or die ($msg_sql_error);
  if (mysql_num_rows($name)==0){
    die ($msg_folder_does_not_exist);
  }
?>

<form action="<?php echo $_SERVER["SCRIPT_NAME"] . "?active=" . $get_active; ?>" name="folder_rename" method="POST">
<p><?php echo $msg_folder_rename; ?><br>
<input type=text name="name" size="50" value="<?php echo mysql_result($name, "name"); ?>"></p>
<input type="submit" value="<?php echo $msg_ok; ?>">
<input type="button" value="<?php echo $msg_cancel; ?>" onClick="parent.close()">
</form>
<script>
document.folder_rename.name.focus();
</script>
	
<?php
}
else {
  mysql_query ("UPDATE folder 
                SET name='$post_name'
                WHERE id='$get_active' 
                AND user='$_SERVER[PHP_AUTH_USER]';") 
                or die ($msg_sql_error);
  echo "<script language=\"JavaScript\">self.close();</script>";
}
include ("./footer.php");
?>
