<?php
  include_once ("./config/config.php");
  include_once ("./messages/$language/msg.php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
  <head>
    <title><?php echo $title; ?></title>
    <meta http-equiv="content-type" content="text/html; charset=iso-8859-2">
    <link rel="stylesheet" type="text/css" href="./style.css">
    <script src="functions.php" type="text/javascript"></script>
  </head>


<?php
  if (isset($noreload) && $noreload==1){
    echo "<body bgcolor=\"#ffffff\">\n";
  }
  else {
    echo "<body bgcolor=\"#ffffff\" onUnload=\"window.opener.location.reload();\">\n";
  }
?>
