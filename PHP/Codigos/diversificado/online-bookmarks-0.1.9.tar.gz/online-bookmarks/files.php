<?php
include_once ("./config/config.php");
include_once ("./main.php");
include_once ("./messages/$language/msg.php");

$get_active=set_GET_active();

$files=mysql_query("SELECT id, title, url, unix_timestamp(date) FROM bookmark 
                    WHERE childof='$get_active' 
                    AND user='$_SERVER[PHP_AUTH_USER]' 
                    AND deleted!='1'
                    ORDER by title;")
                    or die ($msg_sql_error);
?>
      <form name="files">
      <table cellpadding="0" style="width:100%">
<?php
while ($file_list = mysql_fetch_row($files)){
  $datum=date("d.m.Y", "$file_list[3]");
?>
        <tr>
          <td valign="top" width="<?php echo $column_width_checkbox; ?>">
            <input type="checkbox" name="<?php echo $file_list[0]; ?>">
          </td>
          <td valign="top"><?php echo $file; ?></td>
          <td valign="top" width="<?php echo $column_width_bookmark;?>">
            <a href="<?php echo $file_list[2];?>" title="<?php echo $file_list[2];?>" target="_blank"><?php echo $file_list[1];?></a>
          </td>
<?php if ($show_column_date=="on" || $show_column_date=="yes" || $show_column_date=="1"){?>
          <td valign="top" width="<?php echo $column_width_date;?>">
            <?php echo "$datum\n";?>
          </td>
<?php }
if ($show_column_edit=="on" || $show_column_edit=="yes" || $show_column_edit=="1"){?>
          <td valign="top">
            <a href="javascript:bookmarkedit('<?php echo $file_list[0];?>')"><img src="./images/edit.gif" align="absmiddle" border="0" alt="<?php echo $msg_edit; ?>"></a>
          </td>
<?php }
if ($show_column_move=="on" || $show_column_move=="yes" || $show_column_move=="1"){?>
          <td valign="top">
            <a href="javascript:bookmarkmove('<?php echo $file_list[0];?>','<?php echo $_SERVER['QUERY_STRING']; ?>')"><img src="./images/move.gif" align="absmiddle" border="0" alt="<?php echo $msg_move; ?>"></a>
          </td>
<?php }
if ($show_column_delete=="on" || $show_column_delete=="yes" || $show_column_delete=="1"){?>
          <td valign="top">
            <a href="javascript:bookmarkdelete('<?php echo $file_list[0];?>')"><img src="./images/delete.gif" align="absmiddle" border="0" alt="<?php echo $msg_delete; ?>"></a>
          </td>
<?php }?>
        </tr>
  <?php
  }
?>
      </table>
      </form>
