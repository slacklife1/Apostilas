<?php

include ("./config/config.php");
include_once ("./main.php");
$counter=0;

if (preg_match("/tree.php/i",$_SERVER['PHP_SELF'])) {
        header("Location: ./index.php");
        die();
}

$active=set_GET_active();
$expand=purge_expand();

// um alles wird eine tabelle gemacht, damit im index.php
// der tree nur noch mit include eingebunden werden kann.
?>
      <table width="100%">
        <tr>
          <td>

<?php
// das ist, damit der root folder angezeigt wird. 
$exploded=RemoveFromExpandList("0");
echo $neutral . "<a href=\"" . $_SERVER["SCRIPT_NAME"] . "?expand=$exploded&amp;active=0\"></a>";
echo "<a href=\"" . $_SERVER["SCRIPT_NAME"] . "?expand=$expand&amp;active=0\">";

if ($active=="0" || $active=="" || !isset ($active)){
  echo $folder_open . " <span class=\"active\">root</a></span><br>\n";
}
else {
  echo $folder_closed . " root</a><br>\n";
}


print_tree("0");


// erst jetzt wird der eigentliche tree gezeichnet.
function print_tree ($showexpand){
  include ("./config/config.php");
  global $expand, $counter, $active;
  $result = mysql_query("SELECT id,childof,name,user FROM folder 
                         WHERE childof='$showexpand'
                         AND deleted!='1'
                         AND user='$_SERVER[PHP_AUTH_USER]'
                         ORDER by 'name';")
                         or die ($msg_sql_error);
  $counter=$counter+1;
  // abh�ngig davon, ob das verzeichnis aktiv ist oder nicht,
  // wird das entsprechende symbol definiert
  // und der ordnername markiert angezeigt.
  while ($tree = mysql_fetch_row($result)){
    if ($tree[0]==$active){
      $folder_image=$folder_open;
      $print_folder_name=" <span class=\"active\">" . $tree[2] . "</span></a><br>\n";
    }
    else {
      $folder_image=$folder_closed;
      $print_folder_name=" " . $tree[2] . "</a><br>\n";
    }
    // der abstand, der den tree bildet.
    echo '<img src="./images/spacer.gif" height="1" width="' . $counter * 20 . '">';

    // nun die links:
    $child=mysql_query("SELECT id FROM folder 
                        WHERE childof='$tree[0]'
                        AND deleted!='1'
                        AND user='$_SERVER[PHP_AUTH_USER]';");

    if (mysql_fetch_row($child)>0){
      // das wird ausgegeben, wenn das verzeichnis nicht expand ist.
      if (! in_array ($tree[0], explode(",",$expand))){
        echo "<a href=\"" . $_SERVER["SCRIPT_NAME"] . "?expand=$expand,$tree[0]&amp;active=$tree[0]\">" . $plus;
        echo $folder_image . $print_folder_name;
      }
      // das wird ausgegeben, wennn das verzeichnis expand ist.
      else if (in_array ($tree[0], explode(",",$expand))){
        $exploded=RemoveFromExpandList($tree[0]);
        echo "<a href=\"" . $_SERVER["SCRIPT_NAME"] . "?expand=$exploded&amp;active=$tree[0]\">" . $minus . "</a>";
        echo "<a href=\"" . $_SERVER["SCRIPT_NAME"] . "?expand=$expand&amp;active=$tree[0]\">";
        echo $folder_image . $print_folder_name;
        print_tree($tree[0]);
      }
    }
    else{
      // und schliesslich wird das ausgegeben, wenn das verzeichnis keine "kinder" hat. 
      echo $neutral . "<a href=\"" . $_SERVER["SCRIPT_NAME"] . "?expand=$expand&amp;active=$tree[0]\">";
      echo $folder_image . $print_folder_name;
    }
  }
  $counter=$counter-1;
}


?>
          </td>
        </tr>
      </table>
