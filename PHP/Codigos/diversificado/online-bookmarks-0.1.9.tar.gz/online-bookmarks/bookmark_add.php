<?php
$noreload=1;
include_once ("./config/config.php");
include_once ("./main.php");
include_once ("./messages/$language/msg.php");
$title=$msg_title_bookmark_new;
include ("./header.php");

$get_active=set_GET_active();
$get_title=set_GET_title();
$get_url=set_GET_url();
$post_title=set_POST_title();
$post_url=set_POST_url();
$post_description=set_POST_description();
$post_private=set_POST_private();

if ($post_title=="" || $post_url==""){
?>
<form action="<?php echo $_SERVER["SCRIPT_NAME"] . "?active=" . $get_active; ?>" name=bookmark_new method="POST">
<p><?php echo $msg_bookmark_title;?><br>
<input type=text name="title" size="50" value="<?php echo $get_title;?>"></p>
<p><?php echo $msg_bookmark_url;?><br>
<input type=text name="url" size="50" value="<?php echo $get_url;?>"></p>
<!-- <p>Privat<br>
<input type="checkbox" name="private" value="1" checked></p> -->
<p><?php echo $msg_bookmark_description;?><br>
<textarea name="description" cols="50" rows="8"></textarea></p>
<input type="submit" value="<?php echo $msg_ok; ?>">
<input type="button" value="<?php echo $msg_cancel; ?>" onClick="parent.close()">
</form>
<script>
document.bookmark_new.title.focus();
</script>

<?php
}
else {
  mysql_query ("INSERT INTO bookmark (user, title, url, description, private, childof)
    values (
    '$_SERVER[PHP_AUTH_USER]',
    '$post_title',
    '$post_url',
    '$post_description',
    '$post_private',
    '$get_active');")
    or die ($msg_sql_error);
    echo "<script language=\"JavaScript\">self.close();</script>";
}
include ("./footer.php");
?>

</body>
</html>

