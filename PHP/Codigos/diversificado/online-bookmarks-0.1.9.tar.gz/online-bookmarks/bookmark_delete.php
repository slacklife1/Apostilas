<?php
include_once ("./config/config.php");
include_once ("./main.php");
include_once ("./messages/$language/msg.php");
$title=$msg_title_bookmark_delete;
include ("./header.php");

$get_bmlist=set_GET_bmlist();
$bmlist=set_bmlist($get_bmlist);

if ($bmlist==""){
  echo $msg_bookmark_not_selected;	
}
else if (isset ($_GET['noconfirm']) && $_GET['noconfirm']=='1'){
  mysql_query ("UPDATE bookmark set deleted='1'
                WHERE id IN ($bmlist)
                AND user='$_SERVER[PHP_AUTH_USER]'
                AND deleted!='1';")
                or die ($msg_sql_error);
  echo "<script language=\"JavaScript\">self.close();</script>";
}
else {
  $files=mysql_query ("SELECT id, title FROM bookmark
                       WHERE id IN ($bmlist)
                       AND user='$_SERVER[PHP_AUTH_USER]'
                       AND deleted!='1';")
                       or die ($msg_sql_error);
  echo "<p>$msg_bookmark_delete</p>\n";
  echo "<table border=0>\n";

  $array=array();
  while ($array = mysql_fetch_row($files)){
    echo "<tr><td>" . $file . " " . $array[1] . "</td></tr>\n";
  }

  ?>
</table>
<form action="<?php echo $_SERVER["SCRIPT_NAME"] . "?bmlist=" . $get_bmlist . "&amp;noconfirm=1";?>" method="post" name="bmdelete">
<input type="submit" value="<?php echo $msg_ok; ?>">
<input type="button" value="<?php echo $msg_cancel; ?>" onClick="parent.close()">
</form>
  <?php
}

include ("./footer.php");
?>
