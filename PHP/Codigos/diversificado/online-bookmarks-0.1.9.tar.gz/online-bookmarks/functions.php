<?php
include_once ("./config/config.php");
include_once ("./messages/$language/msg.php");
?>

function bookmarknew(active) {
    bookmark_new = window.open("./bookmark_new.php?active=" + active, "bookmarknew","toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=450,left=50,top=50");
}

function bookmarkedit(active) {
  if (active==""){
    alert("<?php echo $msg_bookmark_not_selected; ?>");
  }
  else {
    bookmark_edit = window.open("./bookmark_edit.php?active=" + active, "bookmarkedit","toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=450,left=50,top=50");
  }
}

function bookmarkmove(bmlist, url) {
  if (bmlist==""){
    alert("<?php echo $msg_bookmark_not_selected; ?>");
  }
  else {
    bookmark_move= window.open("./bookmark_move.php?" + url, bmlist, "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=450,left=50,top=50");
  }
}

function bookmarkdelete(bmlist) {
  if (bmlist==""){
    alert("<?php echo $msg_bookmark_not_selected; ?>");
  }
  else {
    bookmark_delete= window.open("./bookmark_delete.php?bmlist=" + bmlist, "bookmarkdelete", "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=200,left=50,top=50");
  }
}

function foldernew(active) {
  folder_new = window.open("./folder_new.php?active=" + active, "foldernew", "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=200,left=50,top=50");
}

function folderrename(active) {
  if (active==""){
    alert("<?php echo $msg_no_folder_selected; ?>");
  }
  else {
    folder_rename = window.open("./folder_rename.php?active=" + active, "folderrename", "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=200,left=50,top=50");
  }
}

function foldermove(active, url) {
  if (active==""){
    alert("<?php echo $msg_no_folder_selected; ?>");
  }
  else {
    folder_move = window.open("./folder_move.php?" + url, active, "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=450,left=50,top=50");
  }
}

function folderdelete(active) {
  if (active==""){
    alert("<?php echo $msg_no_folder_selected; ?>");
  }
  else {
    folder_delete= window.open("./folder_delete.php?active=" + active, "folderdelete", "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=200,left=50,top=50");
  }
}

function search() {
  search_item = window.open("./search.php", "search", "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=400,left=50,top=50");
}

function trash() {
  trash = window.open("./trash.php", "trash", "toolbar=no,location=no,status=no,scrollbars=yes,resizable=yes,width=500,height=450,left=50,top=50");
}

function bookmarkeditparams(){
var i;
var param='';
  for ( i = 0; i < window.document.forms['files'].elements.length; i++) {
    if (window.document.forms['files'].elements[i].checked == true) {
      param = param + window.document.forms['files'].elements[i].name + "_";
    }
  }
  result=param.replace(/_$/,"");
  return result
}

