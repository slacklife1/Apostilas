<?php

include_once ("./config/config.php");
include_once ("./main.php");
include_once ("./messages/$language/msg.php");
$title=$msg_title_search;
include ("./header.php");

$post_search=set_POST_search();

if ($post_search==""){
?>

<body>
<form action="./search.php" name="edit_search" method="post">
<p><?php echo $msg_search_string; ?><br>
<input type=text name="search" size="50" value=""></p>
<input type="submit" value="<?php echo $msg_ok; ?>">
<input type="button" value="<?php echo $msg_cancel; ?>" onClick="parent.close()">
</form>

<script>
document.edit_search.search.focus();
</script>

<?php
}
else {
  $search_result=mysql_query("SELECT title,url,description,childof
                              FROM bookmark 
                              WHERE user='$_SERVER[PHP_AUTH_USER]' 
                              AND deleted!='1'
                              AND MATCH (title,url,description) 
                              AGAINST ('$post_search');")
                 or die ($msg_sql_error);

  echo "<p>$msg_search_results</p>\n";
  echo "<table>";
  while ($row=mysql_fetch_row($search_result)){

  ?>

  <tr>
<!--    <td><a href="#" onclick="javascript:opener.location='<?php echo $row[3]; ?>';"><?php echo $folder_open . " " . printpath(getpath($row[3]),"");?></a></td> -->
  </tr>
  <tr>
    <td><?php echo $file;?><a href="<?php echo $row[1];?>" target="_blank"><?php echo $row[0]."&nbsp;(".$row[1].")";?></a></td>
  </tr>
  <?php
  }
  echo "</table><br>\n";
  echo "<input type=\"button\" value=\"" . $msg_search_new . "\" onClick=\"self.location.href='" . $_SERVER["SCRIPT_NAME"] . "'\">\n";
  echo "<input type=\"button\" value=\"" . $msg_cancel . "\" onClick=\"parent.close()\">";
}


include ("./footer.php");
?>
