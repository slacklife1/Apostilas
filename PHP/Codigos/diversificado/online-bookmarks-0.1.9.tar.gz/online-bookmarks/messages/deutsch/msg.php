<?php

$msg_online_bookmarks=		"online-bookmarks";

$msg_title=			"online-bookmarks von " . $_SERVER['PHP_AUTH_USER'];
$msg_path=			"Sie befinden sich in: ";
$msg_search=		 	"Suchen";
$msg_folder=			"Ordner";
$msg_refresh=			"Aktualisieren";
$msg_close_all=			"Alle schliessen";
$msg_bookmarks=			"Lesezeichen";
$msg_rename=			"Umbenennen";
$msg_edit=			"Bearbeiten";
$msg_move=			"Verschieben";
$msg_delete=			"L�schen";
$msg_move_selected=		"Ausgew�hlte verschieben";
$msg_delete_selected=		"Ausgew�hlte l�schen";
$msg_folder_rename=		"Neuer Name";
$msg_folder_new_name=		"Name";
$msg_folder_move_to=		"Ordner verschieben nach...";
$msg_folder_delete=		"Diesen Ordner l�schen?";
$msg_no_destination_folder=	"Keinen Zielordner angegeben";
$msg_no_folder_selected=	"Keinen Ordner ausgew�hlt";
$msg_folder_does_not_exist=	"Ordner existiert nicht";
$msg_cannot_move_folder=	"Ein Ordner kann nicht in einen seiner Unterordner verschoben werden";
$msg_bookmark_new=		"Neues Lesezeichen";
$msg_bookmark_title=		"Titel";
$msg_bookmark_url=		"Internet Seite";
$msg_bookmark_description=	"Beschreibung";
$msg_bookmark_move_to=		"Lesezeichen verschieben nach:";
$msg_bookmark_delete=		"Diese Lesezeichen l�schen?";
$msg_bookmark_not_selected=	"Kein Bookmark ausgew�hlt";
$msg_sql_error=			"SQL Fehler";
$msg_ok=			" OK ";
$msg_cancel=			" Abbrechen ";
$msg_last_edited=		"Zuletzt ge�ndert";

$msg_title_bookmark_delete=	"Lesezeichen l�schen";
$msg_title_bookmark_edit=	"Lesezeichen bearbeiten";
$msg_title_bookmark_move=	"Lesezeichen verschieben";
$msg_title_bookmark_new=	"Neues Lesezeichen";
$msg_title_folder_delete=	"Ordner l�schen";
$msg_title_folder_move=		"Ordner verschieben";
$msg_title_folder_new=		"Neuer Ordner";
$msg_title_folder_rename=	"Ordner umbenennen";

$msg_title_search=		"Suchen";
$msg_search_string=		"Suchbegriff";
$msg_search_results=            "Suchresutlat";
$msg_search_new=                "Neue Suche";

?>
