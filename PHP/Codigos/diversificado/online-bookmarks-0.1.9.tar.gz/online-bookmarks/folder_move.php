<?php
include_once ("./config/config.php");
include_once ("./main.php");
include_once ("./messages/$language/msg.php");
$title=$msg_title_folder_move;
include ("./header.php");

$get_active=set_GET_active();
$post_sourcefolder=set_POST_sourcefolder();
$path=getpath($get_active);

if ($get_active==""){
  $get_active=0;
}


if ($post_sourcefolder==""){
?>

<form action="<?php echo $_SERVER["SCRIPT_NAME"] . "?active=" . $get_active;?>" method="POST" name="movefolder">
<p><?php echo $msg_folder_move_to; ?></p>
<?php require_once ("./tree.php");?>
<br>
<input type="hidden" name="sourcefolder">
<input type="submit" value="<?php echo $msg_ok; ?>">
<input type="button" value="<?php echo $msg_cancel; ?>" onClick="parent.close()">
</form>

<script type="text/javascript">
  document.movefolder.sourcefolder.value = self.name;
</script>

<?php
}
else if ($post_sourcefolder==$get_active) {
  echo "<script language=\"JavaScript\">self.close();</script>";
}
else if (in_array ($post_sourcefolder, $path[1])){
  echo $msg_cannot_move_folder;
}
else if ($post_sourcefolder!="" && $post_sourcefolder!=$get_active){
  mysql_query ("UPDATE folder SET childof='$get_active'
                WHERE id='$post_sourcefolder'
                AND user='$_SERVER[PHP_AUTH_USER]';") 
                or die ($msg_sql_error);
    echo "<script language=\"JavaScript\">self.close();</script>";
}
include ("./footer.php");
?>
