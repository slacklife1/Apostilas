<?php
include_once ("./config/config.php");
include_once ("./main.php");
include_once ("./messages/$language/msg.php");
$title=$msg_title_bookmark_move;
include ("./header.php");

$get_active=set_GET_active();
$post_bookmarks=set_POST_bookmarks();

if ($post_bookmarks==""){
?>

<form action="<?php echo $_SERVER["SCRIPT_NAME"] . "?active=" . $get_active;?>" method="POST" name="bookmarksmove">
<p><?php echo $msg_bookmark_move_to; ?></p>
<?php require_once ("./tree.php");?>
<br>
<input type="hidden" name="bookmarks">
<input type="submit" value="<?php echo $msg_ok; ?>">
<input type="button" value="<?php echo $msg_cancel; ?>" onClick="parent.close()">
</form>

<script type="text/javascript">
  document.bookmarksmove.bookmarks.value = self.name;
</script>

<?php
}
else if ($get_active==""){
  echo $msg_no_destination_folder;
}
else {
  $bmlist=set_bmlist($post_bookmarks);
  mysql_query ("UPDATE bookmark 
                SET childof='$get_active'
                WHERE id IN ($bmlist)
                AND user='$_SERVER[PHP_AUTH_USER]';") 
                or die ($msg_sql_error);
  echo "<script language=\"JavaScript\">self.close();</script>";
}

include ("./footer.php");
?>
