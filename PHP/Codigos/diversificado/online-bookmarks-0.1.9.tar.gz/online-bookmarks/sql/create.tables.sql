CREATE TABLE bookmark (
  user char(20) NOT NULL default '',
  title char(70) NOT NULL default '',
  url char(200) NOT NULL default '',
  description char(200) default NULL,
  private enum('0','1') NOT NULL default '0',
  date timestamp(14) NOT NULL,
  childof int(11) NOT NULL default '0',
  id int(11) NOT NULL auto_increment,
  deleted enum('0','1') NOT NULL default '0',
  FULLTEXT (title,url,description),
  PRIMARY KEY  (id)
) TYPE=MyISAM;


CREATE TABLE folder (
  id int(11) NOT NULL auto_increment,
  childof int(11) NOT NULL default '0',
  name char(70) NOT NULL default '',
  user char(20) NOT NULL default '',
  deleted enum('0','1') NOT NULL default '0',
  UNIQUE KEY id (id)
) TYPE=MyISAM;


