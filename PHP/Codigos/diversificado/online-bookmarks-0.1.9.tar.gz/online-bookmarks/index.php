<?php
  $noreload=1;
  include_once ("./config/config.php");
  include_once ("./main.php");
  include_once ("./messages/$language/msg.php");
  $title=$msg_online_bookmarks;
  include ("./header.php");

  $get_active=set_GET_active();
?>

<h1><?php echo $msg_title;?></h1>

<div><?php echo $msg_path . printpath(getpath($get_active),"$path_linked");?> </div><br>

<div>
  [<a href="javascript:search()"><img src="./images/search.gif" align="absmiddle" border="0" alt=""> <?php echo $msg_search;?></a>]
  [<a href="<?php echo $_SERVER['REQUEST_URI'];?>"><img src="./images/refresh.gif" align="absmiddle" border="0" alt=""> <?php echo $msg_refresh;?></a>]
  [<a href="./"><img src="./images/close.gif" align="absmiddle" border="0" alt=""> <?php echo $msg_close_all;?></a>]
</div><br>

<table class="main">

  <tr>
    <td style="border-bottom:1px solid black;background-color:#E0E0E0">
      <table width="100%">
        <tr>
          <td>
            <img src="./images/spacer.gif" width="<?php echo $column_width_folder;?>" height="0"><br>
            <?php echo $msg_folder; ?>
            <a href="javascript:foldernew('<?php echo $get_active; ?>')"><?php echo $folder_closed ;?></a>
            <a href="javascript:folderrename('<?php echo $get_active; ?>')"><img src="./images/edit.gif" align="absmiddle" border="0" alt="<?php echo $msg_rename; ?>"></a>
            <a href="javascript:foldermove('<?php echo $get_active; ?>','<?php echo $_SERVER['QUERY_STRING']; ?>')"><img src="./images/move.gif" align="absmiddle" border="0" alt="<?php echo $msg_move; ?>"></a>
            <a href="javascript:folderdelete('<?php echo $get_active; ?>')"><img src="./images/delete.gif" align="absmiddle" border="0" alt="<?php echo $msg_delete; ?>"></a>
          </td>
        </tr>
      </table>
    </td>
    <td style="border-bottom:1px solid black; background-color:#E0E0E0">
      <table width="100%">
        <tr>
          <td>
            <img src="./images/spacer.gif" width="<?php echo $column_width_folder;?>" height="0"><br>
            <?php echo $msg_bookmarks; ?>
            <a href="javascript:bookmarknew('<?php echo $get_active; ?>')"><?php echo $file; ?></a>
            <a href="javascript:bookmarkmove(bookmarkeditparams(),'<?php echo $_SERVER['QUERY_STRING']; ?>')"><img src="./images/move.gif" align="absmiddle" border="0" alt="<?php echo $msg_move_selected; ?>"></a>
            <a href="javascript:bookmarkdelete(bookmarkeditparams())"><img src="./images/delete.gif" align="absmiddle" border="0" alt="<?php echo $msg_delete_selected; ?>"></a>
          </td>
        </tr>
      </table>
    </td>
    <td style="border-bottom:1px solid black; background-color:#E0E0E0"></td>
  </tr>
    <td valign="top" width="<?php echo $column_width_folder?>"><?php require_once ("./tree.php");?></td>
    <td valign="top" width="<?php echo $column_width_bookmark;?>"><?php require_once ("./files.php");?></td>
    <td><img src="./images/spacer.gif" height="<?php echo $table_hight;?>" width="0" alt=""></td>
  </tr>

</table>

<?php
  include ("./footer.php");
?>
