<?php

include_once ("./config/connect.php");
db_connect();

##
## defines the $_GET['active'] variable
##
function set_GET_active(){
  if (!isset($_GET['active']) || $_GET['active']==""){
    $_GET['active']="";
  }
  else {
    $_GET['active']=$_GET['active'];
  }
  return trim ($_GET['active']);
}
##
## defines the $_GET['title'] variable
##
function set_GET_title(){
  if (!isset ($_GET['title']) || $_GET['title']==""){
    $_GET['title']="";
  }
  else {
    $_GET['title']=$_GET['title'];
  }
  return trim ($_GET['title']);
}

##
## defines the $_GET['url'] variable
##
function set_GET_url(){
  if (!isset ($_GET['url']) || $_GET['url']==""){
    $_GET['url']="";
  }
  else {
    $_GET['url']=$_GET['url'];
  }
  return trim ($_GET['url']);
}

##
## defines the $_POST['sourcefolder'] variable
##
function set_POST_sourcefolder(){
  if (!isset ($_POST['sourcefolder']) || $_POST['sourcefolder']==""){
    $_POST['sourcefolder']="";
  }
  else {
    $_POST['sourcefolder']=$_POST['sourcefolder'];
  }
  return trim ($_POST['sourcefolder']);
}

##
## defines the $_POST['title'] variable
##
function set_POST_title(){
  if (!isset ($_POST['title']) || $_POST['title']==""){
    $_POST['title']="";
  }
  else {
    $_POST['title']=$_POST['title'];
  }
  return trim ($_POST['title']);
}

##
## defines the $_POST['url'] variable
##
function set_POST_url(){
  if (!isset ($_POST['url']) || $_POST['url']==""){
    $_POST['url']="";
  }
  else {
    $_POST['url']=$_POST['url'];
  }
  return trim ($_POST['url']);
}

##
## defines the $_POST['description'] variable
##
function set_POST_description(){
  if (!isset ($_POST['description']) || $_POST['description']==""){
    $_POST['description']="";
  }
  else {
    $_POST['description']=$_POST['description'];
  }
  return trim ($_POST['description']);
}

##
## defines the $_POST['private'] variable
##
function set_POST_private(){
  if (!isset ($_POST['private']) || $_POST['private']==""){
    $_POST['private']="";
  }
  else {
    $_POST['private']=$_POST['private'];
  }
  return trim ($_POST['private']);
}

##
## defines the $_POST['bookmarks'] variable
##
function set_POST_bookmarks(){
  if (!isset ($_POST['bookmarks']) || $_POST['bookmarks']==""){
    $_POST['bookmarks']="";
  }
  else {
    $_POST['bookmarks']=$_POST['bookmarks'];
  }
  return trim ($_POST['bookmarks']);
}

##
## defines the $_POST['name'] variable
##
function set_POST_name(){
  if (!isset ($_POST['name']) || $_POST['name']==""){
    $_POST['name']="";
  }
  else {
    $_POST['name']=$_POST['name'];
  }
  return trim ($_POST['name']);
}

##
## defines the $_POST['search'] variable
##
function set_POST_search(){
  if (!isset ($_POST['search']) || $_POST['search']==""){
    $_POST['search']="";
  }
  else {
    $_POST['search']=$_POST['search'];
  }
  return trim ($_POST['search']);
}

##
## defines the $_GET['bmlist'] variable
##
function set_GET_bmlist(){
  if (!isset ($_GET['bmlist']) || $_GET['bmlist']==""){
    return "";
  }
  else {
    $_GET['bmlist']=$_GET['bmlist'];
  }
  return trim ($_GET['bmlist']);
}

##
## sets the bookmark-list for sql queries
##
function set_bmlist($bmlist){
  $expand = array_unique(explode("_",$bmlist));
  foreach ($expand as $key => $value) {
    if ($value=="" || !is_numeric($value)) {
      unset($expand[$key]);
    }
  }
  return implode (", ",$expand);
}

##
## purges and defines the $_GET['expand'] variable
##
function purge_expand(){
  if (!isset ($_GET['expand']) || $_GET['expand']==""){
    return "";
  }
  else {
    $expand = array_unique(explode(",",$_GET['expand']));
    foreach ($expand as $key => $value) {
      if ($value=="" || !is_numeric($value)) {
        unset($expand[$key]);
      }
    }
    return implode (",",$expand);
  }
}

##
## removes $value from the $expand list
##
function RemoveFromExpandList($remove){
  global $expand;
  $exp = explode(",",$expand);
  foreach ($exp as $key => $value) {
    if ($value==$remove) {
      unset($exp[$key]);
    }
  }
  return implode (",",$exp);
}

##
## returns the path to the root folder with or
## without links
##
function printpath($path_reverse, $link){
  $get_expand=purge_expand();
  $path=array();
  $root=array(0=>0, 1=>"", 2=>"root");
  array_push ($path_reverse, $root);
  foreach(array_reverse($path_reverse) as $path_value){
    if ($link=="1" || $link=="on" || $link=="yes"){
      array_push ($path, "<a href=\"./index.php?expand=$get_expand&amp;active=$path_value[0]\">" . $path_value[2] . "</a>");
    }
    else {
      array_push ($path, $path_value[2]);
    }
  }
  return implode (" >> ", $path);
}

##
## returns an array containing the id's, childofs and names of the folders
## to the root folder
##
function getpath($current_folder){
  $path=array();
  while ($current_folder>0){
    $pwd = mysql_query("SELECT id,childof,name
                        FROM folder
                        WHERE id='$current_folder'
                        AND user='$_SERVER[PHP_AUTH_USER]';");
    $folder_value=mysql_fetch_row($pwd);
    array_push ($path, $folder_value);
    $current_folder=$folder_value[1];
  }
  return $path;
}

?>
