<?php
###############
# Procedure: Control Panel for OSF mailing List
# File: cp.php
# Author: Kumar Chetan
# Date & Time: 6/23/02 11:36:14 PM
###############

include('common.php');

if($Submit_update){
for ($i = 0; $i < sizeof($approved); $i++) 
	{
	mysql_query("UPDATE members SET ok=1 WHERE (id=$approved[$i])",$db) or 
	die("<H1>Error Updating</H1>");
	$datasql=mysql_query("SELECT * FROM members WHERE (id=$approved[$i])",$db)or 
	die("<H1>Error </H1>");
	$data=mysql_fetch_array($datasql);
	$welcomemessage='
	Hi pal,
	your account has been activated and your password is'.$data[pwd].'. Use it to 
	remove yourself from List any time.
	
	From,
	Kumar
	';
	mail("$data[user]","Your account info", $message, "From: $from \r\n");
	$j=intval($approved[$i])-1;
	}
}

if($Submit_send)
{
$sql4mails=mysql_query("SELECT * FROM members WHERE (ok=1)",$db);
if(mysql_num_rows($sql4mails)<0)	
	{
	echo"<H1>Database needs to be updated.</H1>No mail could be sent";
	exit;
	}else{
	while($rs=mysql_fetch_array($sql4mails))
		{
		echo"<H1>Sending mail to $rs[user]</H1>";
		mail("$rs[user]",$subj,$msg,"From: Troy<death@osfhome.com>\r\n") or 
		die("<H1>Error sending mail.</H1>Try again.");
		echo "Mail sent to $rs[user]";
		}
	}
}

?>
<html>
<head>
<title>Control Panel</title>
<style type="text/css">
<!--
body          {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt}
th            {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt; font-weight: bold; background-color: #D3DCE3}
td            {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt}
form          {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt}
h1            {font-family: helvetica, arial, geneva, sans-serif; font-size: 16pt; font-weight: bold}
A:link        {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt; text-decoration: none; color: #0000ff}
A:visited     {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt; text-decoration: none; color: #0000ff}
A:hover       {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt; text-decoration: underline; color: #FF0000}
A:link.nav    {font-family: helvetica, arial, geneva, sans-serif; color: #000000}
A:visited.nav {font-family: helvetica, arial, geneva, sans-serif; color: #000000}
A:hover.nav   {font-family: helvetica, arial, geneva, sans-serif; color: #FF0000}
.nav          {font-family: helvetica, arial, geneva, sans-serif; color: #000000}
//-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF">
<p align="center"><a href="<?echo $PHP_SELF.'?show=unapproved';?>"><b>Emails waiting 
  for approval</b></a><b> || <a href="<?echo $PHP_SELF.'?show=mailform';?>">Send 
  Emails to members</a> || <a href="<?echo $PHP_SELF.'?show=members';?>">Members</a> 
  </b></p>
<?
if($show=="mailform")
{
?>
<form method="post" action="<?echo $PHP_SELF;?>" name="mailform">
  <div align="center"><font face="Arial, Helvetica, sans-serif" size="3"><b>Send 
    Email to members </b></font> 
    <table border="0" cellspacing="1" cellpadding="2" bgcolor="#000000">
      <tr bgcolor="#CCCCCC"> 
        <td bgcolor="#CCCCCC" align="right" valign="top"><b>Subject</b></td>
        <td align="left" valign="top"> 
          <input type="text" name="subj">
        </td>
      </tr>
      <tr bgcolor="#CCCCCC"> 
        <td bgcolor="#CCCCCC" align="right" valign="top"><b>Message</b></td>
        <td align="left" valign="top"> 
          <textarea name="msg" cols="50" rows="10"></textarea>
        </td>
      </tr>
    </table>
    <p>
      <input type="submit" name="Submit_send" value="Send mail">
    </p>
    <p><a href="<?echo $PHP_SELF.'?show=unapproved';?>"><b>Emails waiting for 
      approval</b></a><b> || <a href="<?echo $PHP_SELF.'?show=mailform';?>">Send 
      Emails to members</a> || <a href="<?echo $PHP_SELF.'?show=members';?>">Members</a> 
      </b></p>
  </div>
</form>
<?
}

if($show=="unapproved")
{
?>
<form method="post" action="<?echo$PHP_SELF;?>" name="unapproved">
  <div align="center"><font face="Arial, Helvetica, sans-serif" size="3"><b>List 
    of un approved emails </b></font> 
    <table border="0" cellspacing="1" cellpadding="2" bgcolor="#000000">
      <tr bgcolor="#CCCCCC"> 
        <td><b>Email Id</b></td>
        <td><b>Password</b></td>
        <td><b>Approve</b></td>
      </tr>
      <?
      $notapproved=mysql_query("SELECT * FROM members where (ok=0)",$db);
      while($r=mysql_fetch_array($notapproved))
      {
      ?> 
      <tr bgcolor="#CCCCCC"> 
        <td><?echo $r[user];?></td>
        <td><?echo $r[pwd];?></td>
        <td> 
          <input type="checkbox" name="approved[]" value="<?echo $r[id];?>">
        </td>
      </tr>
      <?
      }
      ?> 
    </table>
    <p>
      <input type="submit" name="Submit_update" value="Update database">
    </p>
    <p><a href="<?echo $PHP_SELF.'?show=unapproved';?>"><b>Emails waiting for 
      approval</b></a><b> || <a href="<?echo $PHP_SELF.'?show=mailform';?>">Send 
      Emails to members</a> || <a href="<?echo $PHP_SELF.'?show=members';?>">Members</a> 
      </b></p>
  </div>
</form>
<?
}

if($show=="members")
{
?>
<div align="center"><font face="Arial, Helvetica, sans-serif" size="3"><b>List 
    of approved emails </b></font> 
    
  <table border="0" cellspacing="1" cellpadding="2" bgcolor="#000000">
    <tr bgcolor="#CCCCCC"> 
      <td><b>Email Id</b></td>
      <td><b>Password</b></td>
    </tr>
    <?
      $approved=mysql_query("SELECT * FROM members where (ok=1)",$db);
      while($ra=mysql_fetch_array($approved))
      {
      ?> 
    <tr bgcolor="#CCCCCC"> 
      <td><?echo $ra[user];?></td>
      <td><?echo $ra[pwd];?></td>
    </tr>
    <?
      }
      ?> 
  </table>
  <p><a href="<?echo $PHP_SELF.'?show=unapproved';?>"><b>Emails waiting for approval</b></a><b> 
    || <a href="<?echo $PHP_SELF.'?show=mailform';?>">Send Emails to members</a> 
    || <a href="<?echo $PHP_SELF.'?show=members';?>">Members</a> </b></p>
</div>
<?
}

?>
<div align="center">
<a href="http://www.kinfosys.com" target="_blank" title="KInfotechIndia.com...where technology ticks faster than time.">
<font face="Verdana, Arial, Helvetica, sans-serif" size="1">
Powered by KI
</font>
</a>
</div> 
</body>
</html>
