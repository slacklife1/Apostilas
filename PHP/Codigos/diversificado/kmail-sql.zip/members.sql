#
# Table structure for table 'members'
#

CREATE TABLE `members` (
  `id` int(5) NOT NULL default '0',
  `user` varchar(50) NOT NULL default '',
  `time` varchar(50) NOT NULL default '',
  `pwd` varchar(16) NOT NULL default '',
  `ok` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id_2` (`id`)
) TYPE=MyISAM;