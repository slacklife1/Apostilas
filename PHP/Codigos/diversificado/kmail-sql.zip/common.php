<?php
//Change this var to reflect the name of database you created.
$dbname='memberlist';

//Change it to your email
$from='Kumar<kumar@kinfosys.com>';

$db=mysql_connect('localhost','nobody','') 
	or die('Unable to connect to databse.Following error occured<br>'.mysql_error());

mysql_select_db($dbname) 
	or die('Unable to select databse.Following error occured<br>'.mysql_error());

//The following function is from PHP Manual.
//Don't ask me what it does and how it does.
function check_email_id($Email) {
	if (ereg('^[-!#$%&\'*+\\./0-9=?A-Z^_`a-z{|}~]+'. '@'.'[-!#$%&\'*+\\/0-9=?A-Z^_`a-z{|}~]+\.'.'[-!#$%&\'*+\\./0-9=?A-Z^_`a-z{|}~]+$', $Email)) {
		return 1;//OK
	}else{
		return 0;//Naaaaaaa
	}
}

//My version to make date from the NOW() generated time stamp.
function str2date($in)
{
  $t = explode(" ",$in);
  $d = explode("-", $t[0]);
  $tim = explode(":", $t[1]);
  $d[0]= intval($d[0]);
  $d[1]= intval($d[1]);
  $d[2]= intval($d[2]);
  return date("F j, Y, g:i a",mktime ($tim[0],$tim[1],$tim[2],$d[1],$d[2],$d[0]));
}
?>