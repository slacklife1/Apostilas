<?php
###############
# Procedure: Add emails to mailing List
# File: addtolist.php
# Author: Kumar Chetan
# Date & Time: 6/23/02 9:16:34 PM
###############

include('common.php');

if($Submit)
{
//Check if the email is valid one 
if(!check_email_id($email))
{
	echo'<H1>Wrong Email!</H1>';
	exit;
}
//check if the email sent is in database or not if it is in database the password is correct or not
$result1 = mysql_query("SELECT user FROM members WHERE (user = '$email') ", $db);
if (!$result1) {
echo mysql_error() . "<br>";
die("<H1>Error </H1>");
}

if(mysql_num_rows($result1)>0)
{$isuser=1;}else{$isuser=0;}

$result2 = mysql_query("SELECT user FROM members WHERE (user = '$email') AND (pwd='$pwd')", $db);
if (!$result2) {
echo mysql_error() . "<br>";
die("<H1>Error </H1>");
}
if(mysql_num_rows($result2)>0)
{$isvaliduser=1;}else{$isvaliduser=0;}


//If add then do add
if($action=="add" && $isuser==1)
{
echo'<H1>Duplicate Email!</H1>Email already in database.';
exit; 
}elseif($action=="add" && $isuser==0){
if(!$r = mysql_query("SELECT max(id) AS total FROM members", $db))
die("Error connecting to the database.");
list($total) = mysql_fetch_array($r);
$total += 1;
echo"<H1>Adding Email $email to database.</H1>";
mysql_query("INSERT INTO members (id, user, time, pwd, ok) VALUES ('$total', '$email', NOW(''), '$pwd', '0')",$db) or 
die("Error Adding Email $email to database.");
echo"Email added. You will be shortly notified about your account status by email.";
$message='
Hi admin,
A email '.$email.' has been added to database.
This email requires your attention.
from,
Mailing List Manager
';
$welcomemessage='
Hello,
Hi and welcome to OSFhome.com. we will shortly inform you about your account status.
From,
Kumar
';
mail("$from", "$email added to database", $message,
     "From: $from \r\n");
mail("$email", "Welcome ", $welcomemessage,
     "From: $from \r\n");
}


//if remove then remove
if($action=="remove" && $isvaliduser==1)
{
echo"<H1>Removing Email $email!</H1>";
mysql_query("DELETE FROM members where (email='$email')",$db) or 
die ("<H1>Error Occured!</H1>Email could not be removed from database.");
echo "<br>Email removed from database.";
exit; 
}elseif($action=="remove" && $isvaliduser==0)
{
echo"<H1>Wrong Password!</H1>Try Again.";
}

}else{

?>
<html>
<head>
<title>Add to members</title>
<style type="text/css">
<!--
body          {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt}
th            {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt; font-weight: bold; background-color: #D3DCE3}
td            {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt}
form          {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt}
h1            {font-family: helvetica, arial, geneva, sans-serif; font-size: 16pt; font-weight: bold}
A:link        {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt; text-decoration: none; color: #0000ff}
A:visited     {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt; text-decoration: none; color: #0000ff}
A:hover       {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt; text-decoration: underline; color: #FF0000}
A:link.nav    {font-family: helvetica, arial, geneva, sans-serif; color: #000000}
A:visited.nav {font-family: helvetica, arial, geneva, sans-serif; color: #000000}
A:hover.nav   {font-family: helvetica, arial, geneva, sans-serif; color: #FF0000}
.nav          {font-family: helvetica, arial, geneva, sans-serif; color: #000000}
//-->
</style>
<script language="JavaScript">
<!--
/*
When I found this piece of code in a file made with Dreamweaver I found some wow things.
I use when it when I want quick form validation.
*/
function MM_findObj(n, d) { //v3.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document); return x;
}

function MM_validateForm() { //v3.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (val!=''+num) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>
</head>

<body bgcolor="#FFFFFF" text="#000000">
<form method="post" action="<?echo$PHP_SELF;?>" onSubmit="MM_validateForm('email','','RisEmail','pwd','','R');return document.MM_returnValue" name="addremove">
  <div align="center"><font face="Arial, Helvetica, sans-serif" size="3"><b>Add 
    to members</b></font> 
    <table border="0" bgcolor="#000000" cellpadding="2" cellspacing="1">
      <tr bgcolor=#CCCCCC> 
        <td align="right" valign="top">Email</td>
        <td align="left" valign="top"> 
          <input type=text name=email 
	 value="" maxlength="50" size="40">
        </td>
      </tr>
      <tr bgcolor=#CCCCCC> 
        <td align="right" valign="top">Password</td>
        <td align="left" valign="top"> 
          <input type=password name=pwd 
	 value="" maxlength="16" size="16">
        </td>
      </tr>
      <tr bgcolor=#CCCCCC align="left"> 
        <td valign="top" colspan="2"> 
          <input type="radio" name="action" value="add" checked>
          Add to list<br>
          <input type="radio" name="action" value="remove">
          Remove from list</td>
      </tr>
    </table>
    <input type="submit" name="Submit" value="Submit">
  </div>

   
</form>
<div align="center">
<a href="http://www.kinfosys.com" target="_blank" title="KInfotechIndia.com...where technology ticks faster than time.">
<font face="Verdana, Arial, Helvetica, sans-serif" size="1">
Powered by KI
</font>
</a>
</div>
</body>
</html>
<?}
?>