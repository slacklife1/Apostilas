<center>
  <table cellspacing="2" class="tableGalleryMain">
    <tr> 
      <td colspan="3" class="tdFormMain"> 

        <form name="form1" method="post" enctype="multipart/form-data" accept="image/jpg, image/jpeg"
              action="<?php echo($PHP_SELF); ?>">
          <INPUT TYPE="hidden" name="MAX_FILE_SIZE" value="1024000">
          <table cellspacing="0" class="tableFormMain">
            <tr> 
              <td colspan="2" class="tdFormHeadline" >User Gallery</td>
            </tr>
            <tr> 
              <td class="tdFormLeft">Uploader:</td>
              <td class="tdFormRight"><input type="text" name="uploader" class="formInput"></td>
            </tr>
            <tr> 
              <td class="tdFormLeft">&nbsp;</td>
              <td class="tdFormRight"> 
                <input type="file" name="image" size="30" class="formInput">
                <input type="submit" name="Abschicken" value="Send" class="formButton">
              </td>
            </tr>
          </table>
        </form>

      </td>
    </tr>
    <tr> 
      <td colspan="3" class="tdLink"><?php echo($links['forward']."  ".$links['rewind']); ?></td>
    </tr>
    <tr> 
      <td class="tdImage"><?php echo($display["thumbnail_code"][0]); ?></td>
      <td class="tdImage"><?php echo($display["thumbnail_code"][1]); ?></td>
      <td class="tdImage"><?php echo($display["thumbnail_code"][2]); ?></td>
    </tr>
    <tr> 
      <td class="tdInfo"> 
        <?php

            if (($index = $file_index + 1) > 0) {
              echo("<b>$index</b> ".$display['image_name'][0]."<br>\n");
              echo($display['image_size'][0]." Kb <i>by ".$display['uploader'][0]."</i>");
            }
            else echo("&nbsp;");

        ?>
      </td>
      <td class="tdInfo"> 
        <?php

            if (($index = $file_index) > 0) {
              echo("<b>$index</b> ".$display['image_name'][1]."<br>\n");
              echo($display['image_size'][1]." Kb <i>by ".$display['uploader'][1]."</i>");
            }
            else echo("&nbsp;");

        ?>
      </td>
      <td class="tdInfo"> 
        <?php

            if (($index = $file_index - 1) > 0) {
              echo("<b>$index</b> ".$display['image_name'][2]."<br>\n");
              echo($display['image_size'][2]." Kb <i>by ".$display['uploader'][2]."</i>");
            }
            else echo("&nbsp;");

        ?>
      </td>
    </tr>
    <tr> 
      <td class="tdImage"><?php echo($display["thumbnail_code"][3]); ?></td>
      <td class="tdImage"><?php echo($display["thumbnail_code"][4]); ?></td>
      <td class="tdImage"><?php echo($display["thumbnail_code"][5]); ?></td>
    </tr>
    <tr> 
      <td class="tdInfo"> 
        <?php

            if (($index = $file_index - 2) > 0) {
              echo("<b>$index</b> ".$display['image_name'][3]."<br>\n");
              echo($display['image_size'][3]." Kb <i>by ".$display['uploader'][3]."</i>");
            }
            else echo("&nbsp;");

        ?>
      </td>
      <td class="tdInfo"> 
        <?php

            if (($index = $file_index - 3) > 0) {
              echo("<b>$index</b> ".$display['image_name'][4]."<br>\n");
              echo($display['image_size'][4]." Kb <i>by ".$display['uploader'][4]."</i>");
            }
            else echo("&nbsp;");

        ?>
      </td>
      <td class="tdInfo"> 
        <?php

            if (($index = $file_index - 4) > 0) {
              echo("<b>$index</b> ".$display['image_name'][5]."<br>\n");
              echo($display['image_size'][5]." Kb <i>by ".$display['uploader'][5]."</i>");
            }
            else echo("&nbsp;");

        ?>
      </td>
    </tr>
    <tr> 
      <td class="tdImage"><?php echo($display["thumbnail_code"][6]); ?></td>
      <td class="tdImage"><?php echo($display["thumbnail_code"][7]); ?></td>
      <td class="tdImage"><?php echo($display["thumbnail_code"][8]); ?></td>
    </tr>
    <tr> 
      <td class="tdInfo"> 
        <?php


            if (($index = $file_index - 5) > 0) {
              echo("<b>$index</b> ".$display['image_name'][6]."<br>\n");
              echo($display['image_size'][6]." Kb <i>by ".$display['uploader'][6]."</i>");
            }
            else echo("&nbsp;");

        ?>
      </td>
      <td class="tdInfo"> 
        <?php

            if (($index = $file_index - 6) > 0) {
              echo("<b>$index</b> ".$display['image_name'][7]."<br>\n");
              echo($display['image_size'][7]." Kb <i>by ".$display['uploader'][7]."</i>");
            }
            else echo("&nbsp;");

        ?>
      </td>
      <td class="tdInfo"> 
        <?php

            if (($index = $file_index - 7) > 0) {
              echo("<b>$index</b> ".$display['image_name'][8]."<br>\n");
              echo($display['image_size'][8]." Kb <i>by ".$display['uploader'][8]."</i>");
            }
            else echo("&nbsp;");

        ?>
      </td>
    </tr>
    <tr>
      <td colspan="3" class="tdGalleryInfo">
        <table cellspacing="0" class="tableGalleryInfo">
          <tr>
            <td class="tdGallerySize"> Actual size of database: 
              <?php echo("$gallerySize Kb"); ?>
            </td>
            <td class="tdGalleryUpdate"> Last update: 
              <?php echo("$lastUpdate"); ?>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td class="tdCopyright" colspan="3">
        <a href="http://www.tsinter.net/source/gallery/version_2/index.php" target="_self">TS<i>gallery</i></a>� 
         �2001 <a href="http://www.TSinter.net" target="_blank">TSinter.net</a>
      </td>
    </tr>
  </table>
</center>