<?php

/************************************************
*                                               *
*  This class contains some functions, which    *
*  provide basic operationality.                *
*                                               *
************************************************/



class SupportFunctions {


  function _writeLine($file, $line, $mode) {
    
    # Write a string to a file. The mode is
    # specified like in the fopen function.

    $fp = @fopen($file, $mode) or die("Error while _writeLine to $file");
    if (flock($fp, LOCK_EX + LOCK_NB)) {
      fputs($fp, $line);
      # Take notice of successful execution.
      $logged = 1;
    } else echo("flock failure on $file");
    if (flock($fp, LOCK_UN))
      fclose($fp);
    else echo("flock failure on $file");
    return $logged;
  }


  function _writeArray($file, $array, $mode) {
    
    # Write an array to a file. The mode is
    # specified like in the fopen function.

    $fp = @fopen($file, $mode) or die("Error while _writeArray to $file");
    if (flock($fp, LOCK_EX + LOCK_NB)) {
      for ($i = 0; $i < sizeof($array); $i++) {
        fputs($fp, $array[$i]);
        # Take notice of successful execution.
        $logged = 1;
      }
    } else echo("flock failure on $file");
    if (flock($fp, LOCK_UN))
      fclose($fp);
    else echo("flock failure on $file");
    return $logged;
  }


  function _incrementIfEqual($string, &$array, $index_equal, $index_increment) {
    
    # This function will increment a specified array variable,
    # if two strings are equal.

    for ($i = 0; $i < sizeof($array); $i++) {
      $line = explode("|", $array[$i]);
      if (!strcmp($string, $line[$index_equal])) {
        $changed = 1;
        $line[$index_increment] = $line[$index_increment] + 1;
      }
      $array[$i] = implode("|", $line);
    }
    return $changed;
  }


  function _replace_nl($string) { 
    $lines = explode ("\n", $string); 
    $return_result = "";
    # while there are strings with \n at the end
    for ( $i = 0; $i < count($lines); $i++) {
      # delete unneccessary characters
      $lines[$i] = trim($lines[$i]);

      # add <br> if there is no <br>, some people with html-skills already
      # add a <br> and press the enter key

      if(substr($lines[$i], -4) != '<br>') 
        $lines[$i] .= '<br>'; 
      $return_result .= $lines[$i]; 
    }
    return $return_result; 
  }
 
 
  function _getDirArray($path) { 
    # Load directory into an array.
    $handle = opendir($path); 
    while ($file = readdir($handle)) 
      $dir_array[sizeof($dir_array)] = $file; 
    # Clean up and sort.
    closedir($handle); 
    return $dir_array; 
  }


}


?>