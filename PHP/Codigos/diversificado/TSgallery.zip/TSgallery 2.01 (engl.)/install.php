<?php

include("class_support.php");
include("class_gallery.php");

if (!isset($verarbeitet))
  $verarbeitet = 0;

$gallery = new TSgallery();

if ($image) {
  $gallery->_setUploadInfo($image, $image_name, $image_size, $image_type, $uploader);
  $gallery->_uploadImage();
}

?>


<link rel="stylesheet" href="gallery.css" type="text/css">

<?php $gallery->_definePopUpWindow(); ?>