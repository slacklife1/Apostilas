<?php


/**************************************
*                                     *
* TSgallery 2.0                       *
*                                     *
* by Thomas Schuster                  *
* http://www.TSinter.net              *
*                                     *
* This gallery script gives everybody *
* the possibility to upload her/his   *
* own images on the website. At this  *
* time only JPEG's are allowed.       *
*                                     *
**************************************/




class TSgallery extends SupportFunctions {


  var $gallery_data = "gallery.dat";
  var $gallery_template = "gallery_template.php";
  var $MAX_WIDTH = 205;
  var $MAX_HEIGHT = 175;
  var $image;
  var $image_name;
  var $image_size;
  var $image_type;
  var $image_dir = "gallery_img/";
  var $uploader;
  var $timestamp;
  var $destination_img;
  var $thumbnail;
  




  function _setUploadInfo($image, $image_name, $image_size, $image_type, $uploader) {

    # In PHP, the following variables will be defined within
    # the destination script upon a successful upload, assuming
    # that register_globals is turned on in php.ini. If 
    # track_vars is turned on, they will also be available in
    # PHP within the global array $HTTP_POST_VARS. Note that
    # the following variable names assume the use of the file
    # upload name 'image'.

    # $image - The temporary filename in which the uploaded
    # file was stored on the server machine.

    # $image_name - The original name or path of the file on the sender's system.

    # $image_size - The size of the uploaded file in bytes.

    # $image_type - The mime type of the file if the browser
    # provided this information. An example would be "image/jpeg".

    $this->image = $image;
    $this->image_name = $image_name;
    $this->image_size = $image_size;
    $this->image_type = $image_type;
    $this->uploader = $uploader;
    $this->timestamp = date('d.m.Y \u\m H:i');
    $this->destination_img = $this->image_dir."$image_name";
    $this->thumbnail = $this->image_dir."thumb_".$image_name;

    return 0;

  }


  function _definePopUpWindow() {

    echo("<script Language=\"JavaScript\">\n");
    echo("<!--\n");
    echo("function popup(url, name, width, height)\n");
    echo("{\n");
    echo("settings=\n");
    echo("\"toolbar=no,location=no,directories=no,\"+\n");
    echo("\"status=no,menubar=no,scrollbars=yes,\"+\n");
    echo("\"resizable=yes,width=\"+width+\",height=\"+height;\n");
    echo("MyNewWindow=window.open(url,name,settings);\n");
    echo("}\n");
    echo("//-->\n");
    echo("</script>\n");

    return 0;

  }



  function _uploadImage() {

    if (move_uploaded_file ($this->image, $this->destination_img) == TRUE) {
      $this->_makeThumbnail();
      $this->_setImageData();
    }

    return 0;

  }



  function _makeThumbnail() {

    # The GetImageSize() function returns an array with 4 elements.
    # Index 0 contains the width of the image in pixels.
    # Index 1 contains the height.
    # Index 2 a flag indicating the type of the image. 1 = GIF,
    # 2 = JPG, 3 = PNG, 4 = SWF, 5 = PSD, 6 = BMP.
    # Index 3 is a text string with the correct "height=xxx width=xxx"
    # string that can be used directly in an IMG tag.

    $size = GetImageSize($this->destination_img);

    # Modify the thumbnail without changing the proportion
    # in such a way, that it fits in a gallery cell.

    if (($size[0] / $size[1]) > ($this->MAX_WIDTH / $this->MAX_HEIGHT))
        $modifier = $this->MAX_WIDTH / $size[0];
    else $modifier = $this->MAX_HEIGHT / $size[1];
    
    # Make a copy of the uploaded image, then allocate memory
    # for the thumbnail. The next step is to resize the copied
    # image and store it in the allocated memory. The last step
    # is to store the thumbnail on the file system of the webserver.
    
    $image_copy = @imagecreatefromjpeg ($this->destination_img);
    $thumbnail_memory = @ImageCreate ($size[0] * $modifier, $size[1] * $modifier);
    imagecopyresized ($thumbnail_memory, $image_copy, 0, 0, 0, 0, $size[0] * $modifier,
                      $size[1] * $modifier, $size[0], $size[1]);
    imagejpeg($thumbnail_memory, $this->thumbnail);

    return 0;

  }



  function _getGallerySize() {

    $dir_array = $this->_getDirArray($this->image_dir);

    # Change working directory to get the filesizes.
    $cwd = chdir($this->image_dir);

    for ($i = 0; $i < (sizeof($dir_array) + 2); $i++)
      $dir_size += filesize($dir_array[$i]);

    $dir_size_kb = round($dir_size / 1024, 2);
    $cwd = chdir("..");

    return $dir_size_kb;

  }



  function _getLastUpdate($gallery_file) {
    
    $gallery_line = explode("|", $gallery_file[(sizeof($gallery_file) - 1)]);
    $lastUpdate = $gallery_line[5];

    return $lastUpdate;

  }



  function _setImageData() {

    $img_info = "$this->destination_img|$this->thumbnail|$this->uploader|$this->image_name|$this->image_size|$this->timestamp|\r\n";
    $this->_writeLine($this->gallery_data, $img_info, "a");

    return 0;

  }



  function _getImageData($gallery_file, $file_index, $MAX_PER_PAGE) {

    for ($i = $file_index, $j = 0; ($i > $file_index - $MAX_PER_PAGE) && ($j < $MAX_PER_PAGE); $i--, $j++) {
      
      # Store the relevant information about the
      # images which should be displayed in a two
      # dimensional array.

      $display_info = explode("|", $gallery_file[$i]);

      $display["original"][$j] = $display_info[0];
      $display["thumbnail"][$j] = $display_info[1];
      $display["uploader"][$j] = $display_info[2];
      $display["image_name"][$j] = $display_info[3];
      $display["image_size"][$j] = round (($display_info[4] / 1024), 2);
    }

    return $display;

  }



  function _displayGallery($verarbeitet) {

    $MAX_PER_PAGE = 9;
    $gallery_file = file($this->gallery_data);
    $lastUpdate = $this->_getLastUpdate($gallery_file);
    $gallerySize = $this->_getGallerySize();

    $links = $this->_getLinks($verarbeitet, $gallery_file);

    $image_number = sizeof($gallery_file);
    $file_index = ($image_number - 1) - $verarbeitet;
    
    $display = $this->_getImageData($gallery_file, $file_index, $MAX_PER_PAGE);

    for ($i = 0; $i < $MAX_PER_PAGE; $i++) {
      if ($display["thumbnail"][$i] != "") {
        $size_thumbnail = GetImageSize($display["thumbnail"][$i]);
        $size_original = GetImageSize($display["original"][$i]);
        if ($size_original[1] > 600)
          $size_original[1] = 600;
        $path_original = "'".$this->image_dir.$display["image_name"][$i]."'";
        $display["thumbnail_code"][$i] = "<a href=\"#\" ";
        $display["thumbnail_code"][$i] .= "onClick=\"popup($path_original, 'TSgallery', ";
        $display["thumbnail_code"][$i] .= ($size_original[0] + 45).", ".($size_original[1] + 30).")";
        $display["thumbnail_code"][$i] .= ";return false\">";
        $display["thumbnail_code"][$i] .= "<img src=\"".$display['thumbnail'][$i]."\"$size_thumbnail[3]";
        $display["thumbnail_code"][$i] .= "border=\"0\"></a>";
      } else $display["thumbnail_code"][$i] = ' ';
    }

    include($this->gallery_template);

    return 0;
  
  }


  function _getLinks($verarbeitet_2, $gallery_file) {

    if ((($verarbeitet_2 += 9) <= sizeof($gallery_file)) && (sizeof($gallery_file) > 9)) {
  
      $links["forward"] = "<a href=\"$PHP_SELF?verarbeitet=".($verarbeitet_2)."\">browse</a>";
      if ($verarbeitet_2 != 9)
        $links["rewind"] = "<a href=\"$PHP_SELF?verarbeitet=".($verarbeitet_2 - 18)."\">back</a>";
    } else if (($verarbeitet_2 - 18) >= 0)
      $links["rewind"] = "<a href=\"$PHP_SELF?verarbeitet=".($verarbeitet_2 - 18)."\">back</a>";

    return $links;

  }


}

?>