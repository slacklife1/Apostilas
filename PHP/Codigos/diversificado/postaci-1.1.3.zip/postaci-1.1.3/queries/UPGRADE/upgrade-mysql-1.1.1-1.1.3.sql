
alter table tblUserDomains change column username username varchar(100);
alter table tblMailBoxes change column mboxname mboxname varchar(100);
