INSERT INTO tblDomains VALUES (1,'trlinux.com');
