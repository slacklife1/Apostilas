<?
// +----------------------------------------------------------------------+
// | PHP version 4.1           Rousse, Bulgaria       08-05-2002          |
// +----------------------------------------------------------------------+
// | Copyright (c) 1997, 1998, 1999, 2000, 2001,2002 The PHP Group        |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the PHP license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available at through the world-wide-web at                           |
// | http://www.php.net/license/2_02.txt.                                 |
// | If you did not receive a copy of the PHP license and are unable to   |
// | obtain it through the world-wide-web, please send a note to          |
// | license@php.net so we can mail you a copy immediately.               |
// +----------------------------------------------------------------------+
// | Authors: Original Author <admin@purplerain.org>                      |
// |  Bogomil Shopov                                                      |
// +----------------------------------------------------------------------+
//              <<<  http://purplerain.org >>>>
// if you have any questions feel free to contact me :admin@purplerain.org
// icq 113035194
// $ID EUBGRSMAL1806016
//Note:Working only in windows(R)



$mess="Received from:$ip: $message";
exec("net send $receiver $mess ", $output);

while (list(,$val) = each($output)) :
print "<pre>$val</pre>";
endwhile;
echo"<a href=javascript:history.go(-1)><font color=\"#000000\" size=\"1\" face=\"Verdana\">Go Back</font></a>";



//If you have any ideas about this code improving, please let me know
//Regards
//Bogomil Shopov
//http://purplerain.org
?>
