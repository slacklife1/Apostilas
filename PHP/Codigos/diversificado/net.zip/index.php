<html>
<head>
<title>Send a Network message</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!--For updates and new scripts, please visit 
http://purplerain.org 
Best Regards
Bogomil Shopov 
-->
</head>

<body bgcolor="#FFFFFF" text="#000000">
<form name="form1" method="post" action="netsend.php">
  <table width="49%" border="0" height="129" align=center background="back_small.gif">
    <tr> 
      <td width="19%"><b><font face="Verdana" size="2" color="#FFFFFF">Send to:</font></b></td>
      <td width="81%"> 
        <input type="text" name="receiver" size="34">
		<?PHP $ip = getenv("REMOTE_ADDR")?>
		<input type=hidden name=ip value=<?PHP echo $ip;?>>
      </td>
    </tr>
    <tr> 
      <td width="19%"><b><font face="Verdana" size="2" color="#FFFFFF">Message 
        :</font></b></td>
      <td width="81%"> 
        <textarea name="message" cols="30" rows="11" wrap="VIRTUAL"></textarea>
      </td>
    </tr>
    <tr> 
      <td width="19%">&nbsp;</td>
      <td width="81%"> 
        <input type="submit" name="Submit" value="Send">
        <input type="reset" name="Submit2" value="Clear">
		<br>
        <a href=http://purplerain.org><font color="#FFFFFF" size="1" face="Verdana">Original 
        source by: http://purplerain.org</font></a> </td>
    </tr>
  </table>
</form>
</body>
</html>
