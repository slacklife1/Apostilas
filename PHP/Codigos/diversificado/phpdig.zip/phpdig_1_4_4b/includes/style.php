<style type="text/css">
<!--
body {  font-family: Verdana, Arial, Helvetica, sans-serif; color: #000000; font-size: 10pt}
table {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
tr {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
a {  font-family: Verdana, Arial, Helvetica, sans-serif; color: #003366; text-decoration: none; font-size: 10pt}
a:hover {  font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF; background-color: #003366; font-size: 10pt}
a.high {  font-family: Verdana, Arial, Helvetica, sans-serif; color: #000000; background-color: #FFCC55; text-decoration: none; font-size: 10pt; font-weight: bold;}
a.high:hover {  font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFDD; background-color: #003060; font-size: 10pt;}
div {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
p {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
i {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
input {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
textarea {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
select {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
h1 {  font-family: Verdana, Arial, Helvetica, sans-serif; color: #006699; font-size: 18pt; font-weight: normal}
h2 {  font-family: Verdana, Arial, Helvetica, sans-serif; color: #006699; font-size: 14pt; font-weight: normal}
h3 {  font-family: Verdana, Arial, Helvetica, sans-serif; color: #006699; font-size: 10pt}
-->
</style>