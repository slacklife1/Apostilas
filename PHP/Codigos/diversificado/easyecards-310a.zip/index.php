<?
/********************************************************************************/
/*                                                                              */
/* Copyright (c) 2003 by Angel Stoitsov and Mario Stoitsov                      */
/*    http://software.stoitsov.com                                              */
/*                                                                              */
/* This file is part of EasyCards v3.10a.                                       */
/* EasyCards is free software; you can redistribute it and/or modify            */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation; either version 2 of the License, or         */
/*    (at your option) any later version.                                       */
/* EasyCards is distributed in the hope that it will be useful,                 */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/* You should have received a copy of the GNU General Public License            */
/*    along with EasyCards; if not, write to the Free Software                  */
/*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */
/********************************************************************************/

// Unzip the zip file in some subdirectory (e.g. EasyCards) under the root
// directory on your server. Then follow the three easy steps below


// STEP ONE: Create the tables below under your desired DataBase
//           using phpMyAdmin for example

// ********************************************************************
// *********************** Database Tables
// ********************************************************************
/*

DROP TABLE IF EXISTS `caCards`;
CREATE TABLE caCards (
  ID int(11) NOT NULL auto_increment,
  SenderName varchar(255) NOT NULL default '',
  RecipientName varchar(255) NOT NULL default '',
  FirstLine varchar(255) NOT NULL default '',
  MText text NOT NULL,
  LastLine varchar(255) NOT NULL default '',
  Music varchar(255) NOT NULL default '',
  TextFont varchar(100) NOT NULL default '',
  TextColor varchar(100) NOT NULL default '',
  BackColor varchar(100) NOT NULL default '',
  sid varchar(200) NOT NULL default '',
  Date date NOT NULL default '0000-00-00',
  Picture varchar(255) NOT NULL default '',
  PType smallint(6) NOT NULL default '0',
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `caTop`;
CREATE TABLE caTop (
  ID int(11) NOT NULL auto_increment,
  Dir varchar(255) NOT NULL default '',
  PType tinyint(4) NOT NULL default '0',
  Picture varchar(255) NOT NULL default '',
  Hits bigint(20) NOT NULL default '0',
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

*/

// STEP TWO: Edit your preferences below

// ********************************************************************
// *********************** Config options
// ********************************************************************
$EasyCards["mysql_host"]="localhost";       // change to your MySQL Host
$EasyCards["mysql_user"]="dbuser";      // change to your MySQL Username
$EasyCards["mysql_pass"]="dbpass"; // change to your MySQL Password
$EasyCards["mysql_base"]="dbname";       // Database name, to contain EasyClassifields tables
$EasyCards["page_width"]="770"; // Page width in pixels defaults to 770px (800x600 screen resolution)
$EasyCards["gd_version"]="2";  // Set to 2 if you have GD 2 or higher and set to 1 if you have older
$EasyCards["pics_per_page"]=10;
$EasyCards["DarkColor"]="#000000"; // Color of the headings, tables, links
$EasyCards["Background"]="#FFFFFF"; // Page Background color
$EasyCards["LightColor1"]="#CACACA"; // Table Highlight type 1
$EasyCards["LightColor2"]="#F5F5F5"; // Table Highlight type 2



// LAST STEP THREE: POINT TO INDEX.PHP and ENJOY !!!



// ********************************************************************
// You do not need to edit below this line
// ********************************************************************

// ********************************************************************
// ********************* Initialization & Constants
// ********************************************************************
error_reporting(0);

$EasyCards["version"]="3.10a";
$Num_Steps=5;

function caMakeThumb($original_file,$new_file) {
global $EasyCards;
	$W=$H=100;
	$im = @imagecreatefromjpeg ($original_file);
	$size = GetImageSize ($original_file);
	$H1=$size[1]/($size[0]/$W);
	$W1=$size[0]/($size[1]/$H);
	if ($H1<$W1) { $H1=$H; $dH=0; $dW=($W1-$W)/2; }
	if ($H1>$W1) { $W1=$W; $dW=0; $dH=($H1-$H)/2; }
	if ($EasyCards["gd_version"]==2) {
		$im2 = @ImageCreateTrueColor ($W,$H); // GD 2
		imagecopyresampled ($im2, $im, 0-$dW, 0-$dH, 0, 0, $W1, $H1,$size[0],$size[1]); // GD 2
	} else {
		$im2 = @ImageCreate ($W,$H); // GD < 2
		imagecopyresized ($im2, $im, 0-$dW, 0-$dH, 0, 0, $W1, $H1,$size[0],$size[1]); // GD < 2
	}
	$black = ImageColorAllocate ($im2, 0, 0, 0);
	imagerectangle($im2,0,0,$W-1,$H-1,$black);
	ImageJpeg($im2,$new_file);
} // MakeThumb

function caShowPicture($pic) {
global $EasyCards;
	// Is there thumb ?
	$tmbl=split("/",$pic);
	if (!file_exists("./".$tmbl[1]."/".$tmbl[2]."/thumb_".$tmbl[3])) {
		caMakeThumb($pic,"./".$tmbl[1]."/".$tmbl[2]."/thumb_".$tmbl[3]);
	} // No thumb?
	return "<img src='./".$tmbl[1]."/".$tmbl[2]."/thumb_".$tmbl[3]."' width='100' height='100' alt='Choose picture' border='0'>";
}

function cagetFileCount ($dirName) {
	$d = dir($dirName);
	$ret=0;
	while($entry = $d->read()) {
		if ($entry != "." && $entry != "..") {
			if (!is_dir($dirName."/".$entry)) {
				if (substr($entry,0,6)!="thumb_") $ret++;
			} // if
		} // if
	} // while
	$d->close();
	return $ret;
}

function cagetDirList ($dirName) {
	$d = dir($dirName);
	while($entry = $d->read()) {
		if ($entry != "." && $entry != "..") {
			if (is_dir($dirName."/".$entry)) {
				$ret[$entry]=ucwords($entry)." (".cagetFileCount($dirName."/".$entry).")";
			} // if
		} // if
	} // while
	$d->close();
	asort($ret);
	return $ret;
}

function cagetFileList ($dirName) {
	$d = dir($dirName);
	$i=-1;
	while($entry = $d->read()) {
		if ($entry != "." && $entry != "..") {
			if (!is_dir($dirName."/".$entry)) {
				if (substr($entry,0,6)!="thumb_") { $i++; $ret[$i]=$dirName."/".$entry; }
			} // if
		} // if
	} // while
	$d->close();
	return $ret;
}

function caError($Heading="Error!",$Error="",$Solution="") {
return "<br><table border=0 cellspacing=0 cellpadding=0 align=center><tr><td><div style='background-color:#FFD8D8; border: 2px solid red; padding:10 10 10 10; font: 11px Verdana;'>
		<font color=red><b>$Heading</b></font><br><P>".mysql_error()."<b>$Error</b></P><i>$Solution</i></div></td></tr></table><br>";
} // function Error

function caTr($width=1,$height=1) {
	return "<img src='tr.gif' width='$width' height='$height' alt='' border='0'>";
}

function caElement($Element="default",$Arg1="default",$Arg2="default",$Arg3="default",$Arg4="default",$Arg5="default",$Arg6="default") {
	switch ($Element) {
		case "form" : // Element, Action, Name, Method, Aditional
			$Action=$Arg1; $Name=$Arg2; $Method=$Arg3; $Aditional=$Arg4;
			if ($Name=="default") $Name="my";
			if ($Method=="default") $Method="POST";
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			return "<form action='$Action' name='$Name' method='$Method'".$Aditional.">\n";
		break;
		case "hidden" : // Element, Name, Value
			$Name=$Arg1; $Value=$Arg2;
			if ($Value=="default") $Value="";
			return "<input type='hidden' name='".$Name."' value='".$Value."'>\n";
		break;
		case "text" : // Element, Name, Value, Width, Aditional, Class
			$Name=$Arg1; $Value=$Arg2; $Width=$Arg3; $Aditional=$Arg4; $Class=$Arg5;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("\[",$Name);
				$TmpID=split("\]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Value=="default") $Value="";
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Class=="default") { $Class=" class='f_text'"; } else { $Class=" class='".$Class."'"; }
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			return "<input type='text'".$Class.$ID." name='".$Name."' value='".$Value."'".$Width.$Aditional.">\n";
		break;
		case "file" : // Element, Name, Value, Width, Aditional, Class
			$Name=$Arg1; $Value=$Arg2; $Width=$Arg3; $Aditional=$Arg4; $Class=$Arg5;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("\[",$Name);
				$TmpID=split("\]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Value=="default") $Value="";
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Class=="default") { $Class=" class='f_text'"; } else { $Class=" class='".$Class."'"; }
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			return "<input type='file'".$Class.$ID." name='".$Name."' value='".$Value."'".$Width.$Aditional.">\n";
		break;
		case "textarea" : // Element, Name, Value, Width, Height
			$Name=$Arg1; $Value=$Arg2; $Width=$Arg3; $Height=$Arg4;
			if ($Value=="default") $Value="";
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Height=="default") { $Height=""; } else { $Height=" Rows='$Height' "; }
			return "<textarea class='f_text' name='".$Name."'".$Width.$Height.">".$Value."</textarea>\n";
		break;
		case "password" : // Element, Name, Value, Width, Aditional
			$Name=$Arg1; $Value=$Arg2; $Width=$Arg3; $Aditional=$Arg4;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("[",$Name);
				$TmpID=split("]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Value=="default") $Value="";
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			return "<input type='password' class='f_text'".$ID." name='".$Name."' value='".$Value."'".$Width.$Aditional.">\n";
		break;
		case "radio" : // Element, Name, Value, Selected, Aditional
			$Name=$Arg1; $Value=$Arg2; $Selected=$Arg3; $Aditional=$Arg4;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("[",$Name);
				$TmpID=split("]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			if ($Selected=="default") { $Selected=""; } else { $Selected=" checked"; }
			return "<input type='radio'".$ID." name='".$Name."' value='".$Value."'".$Selected.$Aditional.">"; break;
		break;
		case "checkbox" : // Element, Name, Value, Selected, Aditional
			$Name=$Arg1; $Value=$Arg2; $Selected=$Arg3; $Aditional=$Arg4;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("[",$Name);
				$TmpID=split("]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			if ($Selected=="default") { $Selected=""; } else { $Selected=" checked"; }
			return "<input type='checkbox'".$ID." name='".$Name."' value='".$Value."'".$Selected.$Aditional.">";
		break;
		case "submit" : // Element, Heading, Class
			$Value=$Arg1;
			$Class=$Arg2;
			if ($Class=="default") { $Class="f_text"; }
			return "<input type='submit' name='$Value' value='$Value'>";
		break;
		case "button" : // Element, Name, Heading, OnClick
			$Name=$Arg1; $Value=$Arg2; $OnClick=$Arg3;
			if ($OnClick=="default") { $OnClick=""; } else { $OnClick=" OnClick='".$OnClick."'"; }
			return "<input type='button' class='f_text' name='".$Name."' value='".$Value."'".$OnClick.">";
		break;
		case "select" : // Element, Name, Values, Selected, Width, Labels, Aditional
			$Name=$Arg1; $Values=$Arg2; $Selected=$Arg3; $Width=$Arg4; $Labels=$Arg5; $Aditional=$Arg6;
			if (!is_array($Values)) $Values=Array("!!!���� �������� ���������!!!");
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("\[",$Name);
				$TmpID=split("\]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			$ret="<select class='f_text' name='".$Name."'".$ID.$Width.$Aditional.">";
			while(list($key,$val)=each($Values)) {
				$CurrentLabel="";
				if (isset($Labels[$key])) $CurrentLabel=" Label='".$Labels[$key]."'";
				$ret.="<option value='".$key."'".$CurrentLabel.($Selected==$key ? " selected" : "" ).">".$val."</option>\n";
			} // while
			$ret.="</select>";
			return $ret;
		break;
		case "reset" : // Element, Heading
			$Value=$Arg1;
			if ($Value=="default") $Value="��������";
			return "<input type='reset' class='f_text' name='reset' value='".$Value."'>";
		break;
		default : // (ANY)
			return "</form>";
		break;
	} // switch
} // function Element

function caHeading($Heading,$BR=1) {
	$ret="";
	$ret.="<span class='h1s'>".$Heading."</span>";
	for ($t=0; $t<$BR; $t++) $ret.="<BR>";
	return $ret."\n";
} // heading

function caMyQuery($Query) {
Global $sql;
	$Res=mysql_query($Query) or Die (caError("Error!","<br>Invalid DataBase Query.","<PRE>The query is:<br>$Query</PRE>If the problem persists, contact the system administrator."));
	return $Res;
} // function MyQuery

function caMyFetch($Query) {
Global $sql;
	$Res=mysql_fetch_array(mysql_query($Query)) or Die (caError("Error!","<br>Invalid DataBase Query.","<PRE>The query is:<br>$Query</PRE>If the problem persists, contact the system administrator."));
	return $Res;
} // function MyFetch

// ********************************************************************
// ************************ Actions
// ********************************************************************

if (isset($setPreview)) {
	$step=4;
}

if ($step==5) { // Save & Send E-Card
	$sql=mysql_connect($EasyCards["mysql_host"],$EasyCards["mysql_user"],$EasyCards["mysql_pass"]) or
			Die (caError("Problem!","<br>The database server is offline. Try again shortly.","If the problem persists, contact the system administrator."));
	mysql_select_db($EasyCards["mysql_base"]) or
			Die (caError("Problem!","<br>The database is down for maintenance. It takes about 2 minutes to complete.","If the problem persists, contact the system administrator."));
	$sid=md5(uniqid (rand()));
	$addr="http://".$HTTP_HOST.$PHP_SELF."?show=pickup&sid=".$sid;
	$message="\nDear $RecipientName,\n\n$SenderName ($SenderMail) has sent you a Greeting card!\nYou may pick it up here:\n\n$addr\n\nYou can also send greetings from our site! Check it out - it is free.\n\n------------------------------------\nDate: ".date("d.m.Y")."\n\n";
	mail($RecipientMail, $RecipientName.", ".$SenderName." has sent you a greeting card!", $message,"From: ".$SenderName."\nReply-To: ".$SenderMail."\nX-Mailer: Easy E-Cards (software.stoitsov.com)");
	caMyQuery("INSERT INTO caCards VALUES(null,'$RecipientName','$SenderName','$FirstLine','$Text','$LastLine','$Music','$TextFont','$TextColor','$BackColor','$sid','".date("Y-m-d")."','".$dir."/".$pic.".jpg','$type');");
	$isExist=caMyQuery("SELECT ID FROM caTop WHERE Picture='".$dir."/".$pic.".jpg' LIMIT 1;");
	if (mysql_num_rows($isExist)!=0) {
		caMyQuery("UPDATE caTop SET Hits=Hits+1 WHERE Picture='".$dir."/".$pic.".jpg';");
	} else {
		caMyQuery("INSERT INTO caTop VALUES (null,'".$dir."','$type','".$dir."/".$pic.".jpg',1);");
	}
}

// ********************************************************************
// **************   EasyCards Screen Creation
// ********************************************************************

// Wizard Heading (Same for all pages)
if (isset($step) && $step>0 && $step<=$Num_Steps) {
	$Steps=Array('','Select a picture for your greeting card','Greeting card sender & recipient','Greeting`s text','Decorate your Greeting card','Send confirmation');
	$ResultHtml=caHeading("E-card creation wizard",1)."
	Step $step of ".$Num_Steps.": ".$Steps[$step]."<br><br>";
} // if

// Wizard Step 1: Choose picture
if (isset($step) && $step==1) {
	$SiteNavigation="<a href='$PHP_SELF' class=normal>Home</a>
	<img src='bullet.gif' width='9' height='8' alt='' border='0'><b>Step 1</b>";
	if (!isset($from)) $from=0;
	$Pictures=cagetFileList(($type==1 ? "./horiz/" : "./vert/" ).$dir);
	if (($from+$EasyCards["pics_per_page"])>count($Pictures)) { $to=count($Pictures); } else { $to=$from+$EasyCards["pics_per_page"]; }
	$ResultHtml.="<div align=center>";
	for ($t=$from; $t<$to; $t++) {
		$Temp=split("/",$Pictures[$t]);
		$Pic=substr($Temp[3],0,strlen($Temp[3])-4);
		$ResultHtml.="<a href='$PHP_SELF?step=2&dir=$dir&type=$type&pic=".$Pic."'>".caShowPicture($Pictures[$t])."</a> ";
	} // for
	$ResultHtml.="<br><br>
	".($from!=0 ? "<a href='$PHP_SELF?step=1&dir=$dir&type=$type&from=".($from-$EasyCards["pics_per_page"])."'><img src='prev.gif' width='89' height='14' alt='Jump backward' border='0'></a> " : "" )."
	".($to<count($Pictures) ? "<a href='$PHP_SELF?step=1&dir=$dir&type=$type&from=".($from+$EasyCards["pics_per_page"])."'><img src='next.gif' width='68' height='14' alt='Jump forward' border='0'></a>" : "" )."
	</div>";
}

// Wizard Step 2: Sender & recipient
if (isset($step) && $step==2) {
	$SiteNavigation="<a href='$PHP_SELF' class=normal>Home</a>
	<img src='bullet.gif' width='9' height='8' alt='' border='0'><a href='$PHP_SELF?step=1&dir=$dir&type=$type' class=normal>Step 1</a>
	<img src='bullet.gif' width='9' height='8' alt='' border='0'><b>Step 2</b>";
	$ResultHtml.="<table border=0>".caElement("form",$PHP_SELF)."
	<tr>
		<td><b>Your name:</b><br>".caElement("text","SenderName",$SenderName,200)."</td>
		<td><b>Your e-mail:</b><br>".caElement("text","SenderMail",$SenderMail,200)."</td>
	</tr>
	<tr>
		<td><b>Recipient`s name:</b><br>".caElement("text","RecipientName",$RecipientName,200)."</td>
		<td><b>Recipient`s e-mail:</b><br>".caElement("text","RecipientMail",$RecipientMail,200)."</td>
	</tr>
	<tr>
		<td colspan=2 align=right>".caElement("submit","Next")."</td>
	</tr>".
	caElement("hidden","dir",$dir).caElement("hidden","type",$type).caElement("hidden","step",3).caElement("hidden","pic",$pic).caElement()
	."</table>";
}

// Wizard Step 3: The Text
if (isset($step) && $step==3) {
	$SiteNavigation="<a href='$PHP_SELF' class=normal>Home</a>
	<img src='bullet.gif' width='9' height='8' alt='' border='0'><a href='$PHP_SELF?step=1&dir=$dir&type=$type' class=normal>Step 1</a>
	<img src='bullet.gif' width='9' height='8' alt='' border='0'><a href='$PHP_SELF?step=2&dir=$dir&type=$type&pic=$pic&SenderName=$SenderName&SenderMail=$SenderMail&RecipientName=$RecipientName&RecipientMail=$RecipientMail' class=normal>Step 2</a>
	<img src='bullet.gif' width='9' height='8' alt='' border='0'><b>Step 3</b>";
	$size = GetImageSize ("./".($type==1 ? "./horiz/" : "./vert/" ).$dir."/".$pic.".jpg");
	$ResultHtml.="<table border=0 cellspacing=0 cellpadding=2 width=97% bgcolor='".$EasyCards["LightColor1"]."'>".caElement("form",$PHP_SELF)."
	<tr bgcolor='".$EasyCards["DarkColor"]."'>
		<td>&nbsp;&nbsp;".caHeading("<font color='".$EasyCards["LightColor2"]."'>Greeting card</font>",1)."&nbsp;&nbsp;<font color='".$EasyCards["LightColor2"]."'>From <b>$SenderName</b></font></td>
		<td align=right><a href='http://software.stoitsov.com' target=_stoitsov><img src='stoitsov2.gif' width='150' height='27' alt='Delivered by Stoitsov.com' border='0'></a></td>
	</tr>";
	if ($type==1) { // Horizontal
		$ResultHtml.="<tr>
			<td align=center colspan=2><img src='".($type==1 ? "./horiz/" : "./vert/" ).$dir."/".$pic.".jpg' width='".$size[0]."' height='".$size[1]."' alt='' border='0'><br></td>
		</tr>
		<tr>
			<td colspan=2 align=center><br><b>First Line:</b> (ex. Dear John Doe,)<br>".caElement("text","FirstLine",$FirstLine,400)."</td>
		</tr>
		<tr>
			<td colspan=2 align=center><br><b>Greeting text:</b> (Hit enter for a new line)<br>".caElement("textarea","Text",$Text,400,5)."</td>
		</tr>
		<tr>
			<td colspan=2 align=center><br><b>Last Line:</b> (ex. Best Wishes,)<br>".caElement("text","LastLine",$LastLine,400)."<br><br></td>
		</tr>";
	} else { // Vertical
		$ResultHtml.="<tr>
			<td align=center><img src='".($type==1 ? "./horiz/" : "./vert/" ).$dir."/".$pic.".jpg' width='".$size[0]."' height='".$size[1]."' alt='' border='0'><br></td>
			<td align=center><br><b>First Line:</b> (ex. Dear John Doe,)<br>".caElement("text","FirstLine",$FirstLine,250)."<br>
			<br><b>Greeting text:</b> (Hit enter for a new line)<br>".caElement("textarea","Text",$Text,250,15)."<br>
			<br><b>Last Line:</b> (ex. Best Wishes,)<br>".caElement("text","LastLine",$LastLine,250)."<br><br></td>
		</tr>";
	}
	$ResultHtml.="<tr>
		<td align=right colspan=2  bgcolor='".$EasyCards["DarkColor"]."'>".caElement("submit","Next")."</td>
	</tr>".
	caElement("hidden","dir",$dir).caElement("hidden","type",$type).caElement("hidden","step",4).caElement("hidden","pic",$pic).
	caElement("hidden","SenderName",$SenderName).caElement("hidden","SenderMail",$SenderMail).caElement("hidden","RecipientName",$RecipientName).caElement("hidden","RecipientMail",$RecipientMail).caElement()
	."</table>";
}

// Wizard Step 4: Decoration
if (isset($step) && $step==4) {
	$SiteNavigation="<a href='$PHP_SELF' class=normal>Home</a>
	<img src='bullet.gif' width='9' height='8' alt='' border='0'><a href='$PHP_SELF?step=1&dir=$dir&type=$type' class=normal>Step 1</a>
	<img src='bullet.gif' width='9' height='8' alt='' border='0'><a href='$PHP_SELF?step=2&dir=$dir&type=$type&pic=$pic&SenderName=$SenderName&SenderMail=$SenderMail&RecipientName=$RecipientName&RecipientMail=$RecipientMail' class=normal>Step 2</a>
	<img src='bullet.gif' width='9' height='8' alt='' border='0'><a href='$PHP_SELF?step=3&dir=$dir&type=$type&pic=$pic&SenderName=$SenderName&SenderMail=$SenderMail&RecipientName=$RecipientName&RecipientMail=$RecipientMail&FirstLine=$FirstLine&Text=$Text&LastLine=$LastLine' class=normal>Step 3</a>
	<img src='bullet.gif' width='9' height='8' alt='' border='0'><b>Step 4</b>";
	$size = GetImageSize ("./".($type==1 ? "./horiz/" : "./vert/" ).$dir."/".$pic.".jpg");
	$ResultHtml.="<table border=0 cellspacing=0 cellpadding=2 width=97% bgcolor='$BackColor'>
	<tr bgcolor='".$EasyCards["DarkColor"]."'>
		<td>&nbsp;&nbsp;".caHeading("<font color='".$EasyCards["LightColor2"]."'>Greeting card</font>",1)."&nbsp;&nbsp;<font color='".$EasyCards["LightColor2"]."'>From <b>$SenderName</b></font></td>
		<td align=right><a href='http://software.stoitsov.com' target=_stoitsov><img src='stoitsov2.gif' width='150' height='27' alt='Delivered by Stoitsov.com' border='0'></a></td>
	</tr>";
	if ($type==1) { // Horizontal
	$ResultHtml.="<tr>
			<td align=center colspan=2><img src='".($type==1 ? "./horiz/" : "./vert/" ).$dir."/".$pic.".jpg' width='".$size[0]."' height='".$size[1]."' alt='' border='0'><br></td>
		</tr>
		<tr>
			<td colspan=2><br><UL><b><i><font face='$TextFont' color='$TextColor'>$FirstLine</font></i></b>
			<p><font face='$TextFont' color='$TextColor'>".nl2br($Text)."</font></p>
			<i><font face='$TextFont' color='$TextColor'>$LastLine</i></font><br><br>
			<b><font face='$TextFont' color='$TextColor'>$RecipientName</b></font></UL></td>
		</tr>";
	} else { // Vertical
		$ResultHtml.="<tr>
			<td align=center><img src='".($type==1 ? "./horiz/" : "./vert/" ).$dir."/".$pic.".jpg' width='".$size[0]."' height='".$size[1]."' alt='' border='0'><br></td>
			<td><UL><b><i><font face='$TextFont' color='$TextColor'>$FirstLine</font></i></b>
			<p><font face='$TextFont' color='$TextColor'>".nl2br($Text)."</font></p>
			<i><font face='$TextFont' color='$TextColor'>$LastLine</i></font><br><br>
			<b><font face='$TextFont' color='$TextColor'>$RecipientName</b></font></UL></td>
		</tr>";
	}
	$ResultHtml.="<tr>
		<td align=right colspan=2  bgcolor='".$EasyCards["DarkColor"]."'>".caElement("submit","Send card")."</td>
	</tr>".
	caElement("hidden","dir",$dir).caElement("hidden","type",$type).caElement("hidden","step",5).caElement("hidden","pic",$pic).
	caElement("hidden","SenderName",$SenderName).caElement("hidden","SenderMail",$SenderMail).caElement("hidden","RecipientName",$RecipientName).caElement("hidden","RecipientMail",$RecipientMail).
	caElement("hidden","FirstLine",$FirstLine).caElement("hidden","Text",$Text).caElement("hidden","LastLine",$LastLine)
	."</table><EMBED SRC='$Music' HEIGHT='0' WIDTH='0' AUTOSTART='true' LOOP='true'><BGSOUND SRC='$Music' LOOP='INFINITE'>";
}

// Wizard Step 5: Send confirmation
if (isset($step) && $step==5) {
	$SiteNavigation="<a href='$PHP_SELF' class=normal>Home</a>
	<img src='bullet.gif' width='9' height='8' alt='' border='0'>Step 1
	<img src='bullet.gif' width='9' height='8' alt='' border='0'>Step 2
	<img src='bullet.gif' width='9' height='8' alt='' border='0'>Step 3
	<img src='bullet.gif' width='9' height='8' alt='' border='0'>Step 4
	<img src='bullet.gif' width='9' height='8' alt='' border='0'><b>Step 5</b>";
	$ResultHtml.="<b>Congratulations!</b>
	<p>Greeting card from you (<b>$SenderName</b>) has been sent successfully to your friend (<b>$RecipientName</b>).</p>
	<p>Thanks for using <b><i>Easy E-Cards v.".$EasyCards["version"]." system</i></b>!</p>
	<p>If you wish to send another Greeting card - <a href='$PHP_SELF' class=normal>click here</a>.</p>";
}

// Pick up card
if (isset($sid) && $show=="pickup") {
	$SiteNavigation="<a href='$PHP_SELF' class=normal>Home</a>
	<img src='bullet.gif' width='9' height='8' alt='' border='0'><b>Greeting Card</b>";
	$sql=mysql_connect($EasyCards["mysql_host"],$EasyCards["mysql_user"],$EasyCards["mysql_pass"]) or
			Die (caError("Problem!","<br>The database server is offline. Try again shortly.","If the problem persists, contact the system administrator."));
	mysql_select_db($EasyCards["mysql_base"]) or
			Die (caError("Problem!","<br>The database is down for maintenance. It takes about 2 minutes to complete.","If the problem persists, contact the system administrator."));
	$Cards=caMyQuery("SELECT * FROM caCards WHERE sid='$sid';");
	if (mysql_num_rows($Cards)!=0) {
		$Card=caMyFetch("SELECT * FROM caCards WHERE sid='$sid';");
		$size = GetImageSize ("./".($Card["PType"]==1 ? "./horiz/" : "./vert/" ).$Card["Picture"]);
		$ResultHtml.="<table border=0 cellspacing=0 cellpadding=2 width=97% bgcolor='$BackColor'>
		<tr bgcolor='".$EasyCards["DarkColor"]."'>
			<td>&nbsp;&nbsp;".caHeading("<font color='".$EasyCards["LightColor2"]."'>Greeting card</font>",1)."&nbsp;&nbsp;<font color='".$EasyCards["LightColor2"]."'>From <b>".$Card["SenderName"]."</b></font></td>
			<td align=right><a href='http://software.stoitsov.com' target=_stoitsov><img src='stoitsov2.gif' width='150' height='27' alt='Delivered by Stoitsov.com' border='0'></a></td>
		</tr>";
		if ($Card["PType"]==1) { // Horizontal
			$ResultHtml.="<tr>
				<td align=center colspan=2><img src='".($Card["PType"]==1 ? "./horiz/" : "./vert/" ).$Card["Picture"]."' width='".$size[0]."' height='".$size[1]."' alt='' border='0'><br></td>
			</tr>
			<tr>
				<td colspan=2><br><UL><b><i><font face='".$Card["TextFont"]."' color='".$Card["TextColor"]."'>".$Card["FirstLine"]."</font></i></b>
				<p><font face='".$Card["TextFont"]."' color='".$Card["TextColor"]."'>".nl2br($Card["MText"])."</font></p>
				<i><font face='".$Card["TextFont"]."' color='".$Card["TextColor"]."'>".$Card["LastLine"]."</i></font><br><br>
				<b><font face='".$Card["TextFont"]."' color='".$Card["TextColor"]."'>".$Card["RecipientName"]."</b></font></UL></td>
			</tr>";
		} else { // Vertical
			$ResultHtml.="<tr>
				<td align=center><img src='".($Card["PType"]==1 ? "./horiz/" : "./vert/" ).$Card["Picture"]."' width='".$size[0]."' height='".$size[1]."' alt='' border='0'><br></td>
				<td><br><UL><b><i><font face='".$Card["TextFont"]."' color='".$Card["TextColor"]."'>".$Card["FirstLine"]."</font></i></b>
				<p><font face='".$Card["TextFont"]."' color='".$Card["TextColor"]."'>".nl2br($Card["MText"])."</font></p>
				<i><font face='".$Card["TextFont"]."' color='".$Card["TextColor"]."'>".$Card["LastLine"]."</i></font><br><br>
				<b><font face='".$Card["TextFont"]."' color='".$Card["TextColor"]."'>".$Card["RecipientName"]."</b></font></UL></td>
			</tr>";
		}
		$ResultHtml.="<tr>
			<td align=right colspan=2  bgcolor='".$EasyCards["DarkColor"]."'><font color='".$EasyCards["LightColor2"]."'><b>Date: ".$Card["Date"]."</b></font>&nbsp;</td>
		</tr>
		</table><EMBED SRC='".$Card["Music"]."' HEIGHT='0' WIDTH='0' AUTOSTART='true' LOOP='true'><BGSOUND SRC='".$Card["Music"]."' LOOP='INFINITE'>";
	} // if
}

// Start: Main Page
if (strlen($ResultHtml)==0) {
	$SiteNavigation="<b>Home</b>";
	$sql=mysql_connect($EasyCards["mysql_host"],$EasyCards["mysql_user"],$EasyCards["mysql_pass"]) or
			Die (caError("Problem!","<br>The database server is offline. Try again shortly.","If the problem persists, contact the system administrator."));
	mysql_select_db($EasyCards["mysql_base"]) or
			Die (caError("Problem!","<br>The database is down for maintenance. It takes about 2 minutes to complete.","If the problem persists, contact the system administrator."));
	$ResultHtml=caHeading("Welcome",1)."
	Easy E-Cards v.".$EasyCards["version"]."<br><br>
	<p>You may start creating your greeting card by selecting a card type and picture category from the menu at your left. Or you may choose from the top-sent pictures from below.</p>";
	$TopPics=caMyQuery("SELECT * FROM caTop ORDER BY Hits Desc LIMIT ".$EasyCards["pics_per_page"].";");
	while ($TopPic=mysql_fetch_array($TopPics)) {
		$Temp=split("/","//".$TopPic["Picture"]);
		$Pic=substr($Temp[3],0,strlen($Temp[3])-4);
		$ResultHtml.="<a href='$PHP_SELF?step=2&dir=".$TopPic["Dir"]."&type=".$TopPic["PType"]."&pic=".$Pic."'>".caShowPicture(($TopPic["PType"]==1 ? "./horiz/" : "./vert/" ).$TopPic["Picture"])."</a> ";
	} // while
}
// End: Main Page

// ********************************************************************
// ********************** BuildMenu
// ********************************************************************

// Card pickup
if (isset($sid)) {
	$caMenu="&nbsp;&nbsp;&nbsp;<span class=menu>Information</span><br>
	<font color=".$EasyCards["Background"].">&nbsp;&nbsp;&nbsp;You may send your<br>&nbsp;&nbsp;&nbsp;own Greeting card by<br>&nbsp;&nbsp;&nbsp;<a href='$PHP_SELF' class=menu>clicking here</a>!<br>&nbsp;&nbsp;&nbsp;It is free.</font>";
}


// Main page, Step 1 menu
if ($step<2 && !isset($sid)) {
	$caMenu="&nbsp;&nbsp;&nbsp;<span class=menu>Horizontal images</span><br>";
	$HorDir=cagetDirList("./horiz");
	while (list($dirc,$Head)=each($HorDir)) {
		$caMenu.="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src='menu_item.gif' width='9' height='8' alt='' border='0'><a href='$PHP_SELF?step=1&dir=$dirc&type=1' class=menu>".($dir==$dirc && $type==1 ? "<b>$Head</b>" : $Head )."</a><br>";
	} // while
	$caMenu.="<br>&nbsp;&nbsp;&nbsp;<span class=menu>Vertical images</span><br>";
	$VerDir=cagetDirList("./vert");
	while (list($dirc,$Head)=each($VerDir)) {
		$caMenu.="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src='menu_item.gif' width='9' height='8' alt='' border='0'><a href='$PHP_SELF?step=1&dir=$dirc&type=2' class=menu>".($dir==$dirc && $type==2 ? "<b>$Head</b>" : $Head )."</a><br>";
	} // while
} // if

// Step 2 menu
if ($step==2) {
	$caMenu="&nbsp;&nbsp;&nbsp;<span class=menu>Information</span><br>
	<font color=".$EasyCards["Background"].">&nbsp;&nbsp;&nbsp;Please fill in the correct e-mail<br>&nbsp;&nbsp;&nbsp;addresses or your card will<br>&nbsp;&nbsp;&nbsp;never reach the recipient<br>&nbsp;&nbsp;&nbsp;it is directed to.</font>";
}

// Step 3 menu
if ($step==3) {
	$caMenu="&nbsp;&nbsp;&nbsp;<span class=menu>Information</span><br>
	<font color=".$EasyCards["Background"].">&nbsp;&nbsp;&nbsp;Please try to avoid typing text<br>&nbsp;&nbsp;&nbsp;larger than the text box or your<br>&nbsp;&nbsp;&nbsp;greeting card may become ugly<br>&nbsp;&nbsp;&nbsp;as it`s layout changes.</font>";
}

// Step 4 menu
if ($step==4) {
	$caMenu="&nbsp;&nbsp;&nbsp;<span class=menu>Decorate options</span>".caElement("form",$PHP_SELF,"thisform")."
	<font color=".$EasyCards["Background"].">
	&nbsp;&nbsp;&nbsp;Greeting text color:<br>
	&nbsp;&nbsp;&nbsp;<select name=\"TextColor\" class=f_text style='width:170;'>
								<option style=\"color:black; background-color: #DEE3E7\" value=\"black\" ".($TextColor=="black" ? "selected" : "" ).">Black</option>\n<option style=\"color:darkred; background-color: #DEE3E7\" value=\"darkred\" ".($TextColor=="darkred" ? "selected" : "" ).">Dark Red</option>\n<option style=\"color:red; background-color: #DEE3E7\" value=\"red\" ".($TextColor=="red" ? "selected" : "" ).">Red</option>
								<option style=\"color:orange; background-color: #DEE3E7\" value=\"orange\" ".($TextColor=="orange" ? "selected" : "" ).">Orange</option>\n<option style=\"color:brown; background-color: #DEE3E7\" value=\"brown\" ".($TextColor=="brown" ? "selected" : "" ).">Brown</option>\n<option style=\"color:yellow; background-color: #DEE3E7\" value=\"yellow\" ".($TextColor=="yellow" ? "selected" : "" ).">Yellow</option>
								<option style=\"color:green; background-color: #DEE3E7\" value=\"green\" ".($TextColor=="green" ? "selected" : "" ).">Green</option>\n<option style=\"color:olive; background-color: #DEE3E7\" value=\"olive\" ".($TextColor=="olive" ? "selected" : "" ).">Olive</option>\n<option style=\"color:cyan; background-color: #DEE3E7\" value=\"cyan\" ".($TextColor=="cyan" ? "selected" : "" ).">Cyan</option>
								<option style=\"color:blue; background-color: #DEE3E7\" value=\"blue\" ".($TextColor=="blue" ? "selected" : "" ).">Blue</option>\n<option style=\"color:darkblue; background-color: #DEE3E7\" value=\"darkblue\" ".($TextColor=="darkblue" ? "selected" : "" ).">Dark Blue</option>\n<option style=\"color:indigo; background-color: #DEE3E7\" value=\"indigo\" ".($TextColor=="indigo" ? "selected" : "" ).">Indigo</option>
								<option style=\"color:violet; background-color: #DEE3E7\" value=\"violet\" ".($TextColor=="violet" ? "selected" : "" ).">Violet</option>\n<option style=\"color:white; background-color: #DEE3E7\" value=\"white\" ".($TextColor=="white" ? "selected" : "" ).">White</option>
								</select><br>
	&nbsp;&nbsp;&nbsp;Greeting text font:<br>
	&nbsp;&nbsp;&nbsp;<select name=\"TextFont\" class=f_text style='width:170;'>
                <OPTION VALUE=\"Arial\" ".($TextFont=="Arial" ? "selected" : "" )."> Arial</OPTION>
                <OPTION VALUE=\"Arial Black\" ".($TextFont=="Arial Black" ? "selected" : "" )."> Arial Black</OPTION>
                <OPTION VALUE=\"Brush Script MT\" ".($TextFont=="BrushScript MT" ? "selected" : "" )."> Brush Script MT</OPTION>
				<OPTION VALUE=\"Comic Sans MS\" ".($TextFont=="Comic Sans MS" ? "selected" : "" ).">Comic Sans</OPTION>
                <OPTION VALUE=\"Comic Sans MS\" ".($TextFont=="Comic Sans MS" ? "selected" : "" )."> Comic Sans MS</OPTION>
                <OPTION VALUE=\"Courier\" ".($TextFont=="Courier" ? "selected" : "" )."> Courier</OPTION>
                <OPTION VALUE=\"Courier New\" ".($TextFont=="Courier New" ? "selected" : "" )."> Courier New</OPTION>
                <OPTION VALUE=\"Garamond\" ".($TextFont=="Garamond" ? "selected" : "" )."> Garamond</OPTION>
                <OPTION VALUE=\"Georgia\" ".($TextFont=="Georgia" ? "selected" : "" )."> Georgia</OPTION>
                <OPTION VALUE=\"Impact\" ".($TextFont=="Impact" ? "selected" : "" )."> Impact</OPTION>
                <OPTION VALUE=\"Lucida Handwriting\" ".($TextFont=="Lucida Handwriting" ? "selected" : "" )."> Lucida Handwriting</OPTION>
                <OPTION VALUE=\"MS Sans Serif\" ".($TextFont=="MS Sans Serif" ? "selected" : "" )."> MS Sans Serif</OPTION>
                <OPTION VALUE=\"MS Serif\" ".($TextFont=="MS Serif" ? "selected" : "" )."> MS Serif</OPTION>
                <OPTION VALUE=\"News Gothic MT\" ".($TextFont=="News Gothic MT" ? "selected" : "" )."> News Gothic MT</OPTION>
                <OPTION VALUE=\"Palatino\" ".($TextFont=="Palatino" ? "selected" : "" )."> Palatino</OPTION>
                <OPTION VALUE=\"Times New Roman\" ".($TextFont=="Times New Roman" ? "selected" : "" )."> Times New Roman</OPTION>
                <OPTION VALUE=\"Verdana\" ".($TextFont=="Verdana" ? "selected" : "" )."> Verdana</OPTION></SELECT><br>
	&nbsp;&nbsp;&nbsp;Background color<br>
	&nbsp;&nbsp;&nbsp;<select name=\"BackColor\" class=f_text style='width:170;'>
								<option style=\"color:white; background-color: #DEE3E7\" value=\"white\" ".($BackColor=="white" ? "selected" : "" ).">White</option>\n
								<option style=\"color:black; background-color: #DEE3E7\" value=\"black\" ".($BackColor=="black" ? "selected" : "" ).">Black</option>\n<option style=\"color:darkred; background-color: #DEE3E7\" value=\"darkred\" ".($BackColor=="darkred" ? "selected" : "" ).">Dark Red</option>\n<option style=\"color:red; background-color: #DEE3E7\" value=\"red\" ".($BackColor=="red" ? "selected" : "" ).">Red</option>
								<option style=\"color:orange; background-color: #DEE3E7\" value=\"orange\" ".($BackColor=="orange" ? "selected" : "" ).">Orange</option>\n<option style=\"color:brown; background-color: #DEE3E7\" value=\"brown\" ".($BackColor=="brown" ? "selected" : "" ).">Brown</option>\n<option style=\"color:yellow; background-color: #DEE3E7\" value=\"yellow\" ".($BackColor=="yellow" ? "selected" : "" ).">Yellow</option>
								<option style=\"color:green; background-color: #DEE3E7\" value=\"green\" ".($BackColor=="green" ? "selected" : "" ).">Green</option>\n<option style=\"color:olive; background-color: #DEE3E7\" value=\"olive\" ".($BackColor=="olive" ? "selected" : "" ).">Olive</option>\n<option style=\"color:cyan; background-color: #DEE3E7\" value=\"cyan\" ".($BackColor=="cyan" ? "selected" : "" ).">Cyan</option>
								<option style=\"color:blue; background-color: #DEE3E7\" value=\"blue\" ".($BackColor=="blue" ? "selected" : "" ).">Blue</option>\n<option style=\"color:darkblue; background-color: #DEE3E7\" value=\"darkblue\" ".($BackColor=="darkblue" ? "selected" : "" ).">Dark Blue</option>\n<option style=\"color:indigo; background-color: #DEE3E7\" value=\"indigo\" ".($BackColor=="indigo" ? "selected" : "" ).">Indigo</option>
								<option style=\"color:violet; background-color: #DEE3E7\" value=\"violet\" ".($BackColor=="violet" ? "selected" : "" ).">Violet</option>
								</select><br>
	&nbsp;&nbsp;&nbsp;Music<br>
	&nbsp;&nbsp;&nbsp;<SELECT NAME=\"Music\" class=f_text style='width:170;'>";
	$MusicFiles=cagetFileList("./music");
	while (list($dirc,$Head)=each($MusicFiles)) {
		$caMenu.="<option value='$Head' ".($Music==$Head ? "selected" : "" ).">".ucwords(str_replace("_"," ",str_replace(".mid","",str_replace("./music/","",$Head))))."</option>";
	} // while
	$caMenu.="</select><br>
	<br><div align=center><INPUT TYPE=\"submit\" name=setPreview VALUE=\"Preview\"></div>
	</font>";
}

$caMenu.="<br><br>";
// ********************************************************************
// ********************** HTML Output
// ********************************************************************
//                                You may edit to suit your site design
//   but *please* leave the donation button, link to us  & author names

// Start HTML HEADER
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>
<head>
<title>.: Easy E-Cards - v".$EasyCards["version"]." :.</title>
<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=windows-1251\">
<META NAME=\"description\" CONTENT=\"EasyBookmarker Software - by http://software.stoitsov.com\">
<META NAME=\"author\" CONTENT=\"Idea&minor development - Mario Stoitsov, Script by Cyber/SAS\">
";

// CSS Style - Edit to fit your site design
echo "<style type=\"text/css\">
body {
	font: 11px Arial, Helvetica; color:black;
	background-color: ".$EasyCards["DarkColor"]."; scrollbar-DarkShadow-Color: ".$EasyCards["DarkColor"].";
	scrollbar-Track-Color: ".$EasyCards["DarkColor"]."; scrollbar-Face-Color:	".$EasyCards["DarkColor"].";
	scrollbar-Shadow-Color:	".$EasyCards["Background"]."; scrollbar-Highlight-Color: ".$EasyCards["Background"].";
	scrollbar-3dLight-Color: ".$EasyCards["DarkColor"]."; scrollbar-Arrow-Color: ".$EasyCards["Background"].";
}
td {
	font: 11px Arial, Helvetica; color: black;
}
.h1s {
	font: 18px Verdana; font-weight:bold; color: ".$EasyCards["DarkColor"].";
}
.f_text {
	font: 11px Arial, Helvetica;
	color: black;
	background-color: ".$EasyCards["Background"].";
	border: 1px dotted ".$EasyCards["DarkColor"].";
}
.menu {	font: 12px Arial, Helvetica; color: white; font-weight:bold;}
a:link.normal, a:visited.normal {
	font: 11px Arial, Helvetica; color: blue; text-decoration:none;
}
a:hover.normal {
	font: 11px Arial, Helvetica; color: red; text-decoration:none;
}
a:link.menu, a:visited.menu {
	font: 11px Arial, Helvetica; color: yellow; text-decoration:none;
}
a:hover.menu {
	font: 11px Arial, Helvetica; color: red; text-decoration:none;
}

</style>
</head>
";

// Start HTML BODY
echo "<body>
<div align='center'>
<table border=0 width='".$EasyCards["page_width"]."' cellspacing=0 cellpadding=0 bgcolor=".$EasyCards["Background"].">
	<tr>
		<td><a href='$PHP_SELF'><img src='top1.jpg' width='209' height='69' alt='Easy E-Cards!' border='0'></a><br></td>
		<td><a href='$PHP_SELF'><img src='top2.gif' width='122' height='69' alt='Easy E-Cards!' border='0'></a><br></td>
		<td width=100% background='top3.gif' valign=top align=right><a href='http://software.stoitsov.com' target=_stoitsov><img src='stoitsov.gif' width='174' height='51' alt='Get more free software from Stoitsov.com' border='0'></a><br><font color='".$EasyCards["LightColor1"]."'><b><i>Navigation: </i></b></font>".$SiteNavigation."&nbsp;&nbsp;</td>
	</tr>
</table>
<table border=0 width='".$EasyCards["page_width"]."' cellspacing=0 cellpadding=0 bgcolor=".$EasyCards["Background"].">
	<tr>
		<td valign=top background='left2.gif'><a href='$PHP_SELF'><img src='left1.jpg' width='209' height='107' alt='Easy E-Cards!' border='0'></a><br>".$caMenu."</td>
		<td valign=top>".caTR(561,8)."<br>
";

// Output current screen
echo $ResultHtml;

// HTML FOOTER START
echo "
		</td>
	</tr>
	<tr>
                <td background='left2.gif'><a href='http://software.stoitsov.com/free/easye-cards/' target=_stoitsov><img src='e-cards90x30.gif' width='90' height='30' alt='Offer e-cards on-line for free!' border='0' hspace=50></a></td>
		<td align=right><br>
		<table border='0' cellspacing='0' cellpadding='0' width='50%'>
			<tr>
				<td width='100%' bgcolor='".$EasyCards["DarkColor"]."'>".caTr(1,1)."<br></td>
			</tr>
			<tr>
				<td width='100%' align=right><font color='".$EasyCards["DarkColor"]."'><b>EasyCards</b> v".$EasyCards["version"]." is a free software by </font><a href='http://software.stoitsov.com' class=normal target=_stoitsov.com>Stoitsov.com</a>&nbsp;&nbsp;<br><a href='https://www.paypal.com/affil/pal=mario%40stoitsov.com' target=_donate><img src='donate.gif' width='110' height='23' alt='Support us!' border='0' hspace=4 align=right></a>To keep it free & developing:</td>
			</tr>
		</table>
		</td>
	</tr>
</table></div>
";
// End HTML Output
echo "</body>\n</html>";

/*	******************************************************************
        ********************** EasyCards v3.10a ***************************
	******************************************** software.stoitsov.com  */
