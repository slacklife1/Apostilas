<?

// Here is a example that shows how I would include phpuserlogin, make the options and start the script.
// It also shows how to use extra tables.
// Now I would just include access_control.php in the files where I would need phpuserlogin.

// First we include phpuserlogin.php
// It would be best to do that using the direct path to the file, that way you dont need
// to include this file in another file that is in the same folder as phpuserlogin.php all the time
include'/home/path_to/phpuserlogin.php';

// Secound we make the options array, as I call it. The reason for that name is simple.
// Its a array with a lot of options in it.
// You will find info about every option in the comment next to it.
// All options you dont include (aint having the option in the options array -> deleting the line
// or commeting it away) in the options array will just use default then.
$new_phpuserlogin_options = array(
	'var_name'			=> 'login', // This name will be used to make the $vars phpuserlogin makes in forms and places in urls unigue. For eks. the $var that stores the username when you login would be called login[L][username] if you had used login as the var_name
	'page'				=> 'http://www.myserver.com/index.php', // If you enter a url for a page here, then people will only be able to login from that page, if the login form is showed on other pages it will print a link to this page. If you leave this empty or dont include this option then the users can login from all pages that has the login form on them.
	'page_afterlogin'	=>'http://www.myserver.com/members.php', // This is the url for the page the user will be send to right after login. If you dont want to use this option, simple dont write anything or dont include it.
	'hidden_key'		=> 0, // PLEASE REMEMBER TO CHANGE THIS. This one is importent. This number you write there will be used to make the script secure on  your server
	'mysql_table'		=> 'users', // This is the name of the table where usernames and passwords are stored
//	'mysql_serv'		=> 'localhost', // This is the ip/host name for your MySQL server, this is almost always localhost. 
	'mysql_user'		=> 'draxker', // This is the username for your MySQL server 
	'mysql_pass'		=> '******', // This is the password for your MySQL server
	'mysql_data'		=> 'myserver_members', // This is the name of the database where the table is stored.
//	'mysql_pcon'		=> FALSE, // Set this to true if you want to use a persistent connection to the MySQL server
/*	'mysql_fields'		=> array(
									'_main'	=> array( // This is for extra fields in the main table.
										'fields'		=> array(
															1	=> 'nickname||Enter you nickname||MAX(20)',
															'b'	=> 'website||Your website (if any)',
															4	=> 'level||User level||AUTO[1]',
															'c'	=> 'show_email||May people see your email||ON_OFF[1,0]',
															'b'	=> 'website||Write alittle about your self||TEXT[10,5]'
														)
										),
									'other'	=> array(
										'table_name'	=> 'member_info',
										'id_field'		=> 'member_id',
										'fields'		=> array(
															1	=> 'motto||Enter your motto||MAX[100]',
															'j'	=> 'lover||Enter the name of your lover (if any :)||MAX[30]',
															3	=> 'food||what food do you like?||DROP_DOWN[Ice=ice,Danish=dan,Fast Food=ff]',
															5	=> 'milk||You you like milk||ON_OFF[yes,no]',
															6	=> 'other||What do you like the most:||RADIO[Cats=1,Dogs=2,Birds=3]'  
														)

										)
								), */
//	'mysql_id'			=> 'id', // This is the name of the id field in the main user table. If you really must use another name for the field then id, then you can write the name here.
//	'cookie_life'		=> '', // This is how long the cookies, which store info about a logged in users (that info that keeps him or her logged in), live on the host pc's in secounds. If empty or not included then they will live untill the session ends (browser is closed)
//	'cookie_path'		=> '', // Advanced: Here you can change the path options for the cookies
//	'cookie_domain'		=> , // Advanced: Here you can change the domain options for the cookies
	'register'			=> TRUE, // If you want to use the register function then you must set this to true, other wise set to false or dont include it.
	'register_page'		=> 'http://www.myserver.com/register.php' // This is the path for the page where the register form is being printed (printRegForm). The register form will only work on that page.
	'lostpass'			=> TRUE, // If you want people to be able to use the "I lost my password, make me a new one" feature, then set this to TRUE (which is default). Set to false to turn off.
	'users_online'		=> FALSE // Set this to true if the script should track when a user is active. This also has to be set to true for the show online users list to work. If you dont wanna use it, set to false or dont include it.  
	'temp_folder'		=> '', // The direct path to the folder where the templates files are.
	'temp_prefix'		=> 'phpuserlogin', // This is the prefix that is in front of the register templates. eg: phpuserlogin_login_top.tpl
	'anti_spam'			=> 3, // This is the amount of times a user may try to use any of the forms that phpuserlogin has. For eks. If the user keeps trying to login with a wrong username and password then, after 3 tries the user will be stopped for 5 mins. Default is 6, Set to 0 to not use this feature.
	'email_reply'		=> 'reply@myserver.com', // This is the email adress that will be printed on any emails the scripts sends.
	'admins'			=> 'drakxter', // This is the usernames of the admins, some servers are case sensetiv so remember to type the usernames right. To enter more usernames simple spilt them with a , eg: drakxter,bob,tim,cap_zedo
	'logFile'			=> 'home/path_to/login_log.log' // This is the direct path to the file that logs should be written to. Leave this empty or dont include it to turn off. Remember that is MUST be a direct path or else it cant write into the file.
);

// This line starts the script.
// It is done by making a "new" object of the class phpuserlogin (which is in phpuserlogin.php)
// You place this object into a $variabal, in this case $login, but it could have been give any name.
// We also make the object here using the options array above.
$login = new phpuserlogin($new_phpuserlogin_options);

?>