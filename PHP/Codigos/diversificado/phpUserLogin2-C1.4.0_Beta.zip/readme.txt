phpUserLogin2
Version 1.4.0

----------------------

License Stuff:

 * phpUserLogin is made by Tanny 'Drakxter' Lund
 *
 * OxyScripts.com proudly presents phpUserLogin
 * Copyright (C) 2002 Drakxter
 *
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of the GNU General Public License as published by 
 * the Free Software Foundation; either version 2 of the License, or 
 * (at your option) any later version. 
 * This program is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
 * GNU General Public License for more details. 
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software 
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

------------------------
First of all:

Thank you for downloading phpuserlogin2.

AND

Please note: The readme is not complete but it got all the basic stuff you need to use the new features.
Also a html readme will be made again soon.

Also here is a quick list of new stuff in phpuserlogin2.

Show a list of users online the last 15 mins.
New Admin, looks better and is more advanced.
The "extra table" feature has been upgraded. You will now be able to tell the script
what kind of form fields should be used in the register form and admin. Also you will
be able to have the script manage extra fields in the main user table (where usersnames are stored.)
Template system added. You will now be able to alter how all the forms look.

--
---

1: Upgrading from phpuserlogin1
2: Upgrading from other versions of phpuserlogin2
3: New install
4: The options + How to protect pages and start the script and how to use some of the other features.


------------------------
1: -------
If your upgrading from phpuserlogin(1) then all you need to do is run this little query on your database.
It will update the old user table so it will work with phpuserlogin2

##
ALTER TABLE `TABLE_NAME` DROP `lost`;
ALTER TABLE `TABLE_NAME` ADD `lost_key` VARCHAR(60) DEFAULT '0' NOT NULL,
ADD `lost_date` DATETIME NOT NULL;
##

REMEMBER TO CHANGE TABLE_NAME to what ever you called the user table.

------------------------
2: -------
If your upgrading from phpuserlogin2 1.2.6 or older then all you need to do is run this query on your database.

##
ALTER TABLE `TABLE_NAME` ADD `user_status` ENUM('1','0') DEFAULT '1' NOT NULL;
ALTER TABLE `TABLE_NAME` ADD `last_active` TIMESTAMP NOT NULL;
ALTER TABLE `TABLE_NAME` CHANGE `lost_date` `lost_date` TIMESTAMP NOT NULL;
##

Remember to change TABLE_NAME to the name of the main user table.

------------------------
3: -------
If this is the first time using phpuserlogin2 or you want to reinstall it then you need to run this guery on your database.
Just change the phpuserlogin_users to what ever you would like to call the user table.

##
CREATE TABLE phpuserlogin_users (
  id int(11) NOT NULL auto_increment,
  username varchar(20) NOT NULL default '',
  password varchar(100) NOT NULL default '',
  email varchar(100) default NULL,
  lost_key varchar(60) NOT NULL default '0',
  lost_date timestamp(14) NOT NULL,
  user_status enum('1','0') NOT NULL default '1',
  last_active timestamp(14) NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY username (username)
) TYPE=MyISAM;
##

To make your first user run this query, remember to change the table name.

##
INSERT INTO phpuserlogin_users (`username`, `password`, `email`) VALUES (
'new_username',
MD5('new_password'),
'new_email'
)
##

new_username: Here you write your username
new_password: Here you write your password, remember that is must be run though MD5() or else your wont be able to login.
new_email: Here you write your email address.
phpuserlogin_users: This you just change to what ever you named the table you just made! 

------------------------
4: -------

To use this script follow these steps and rules.

Rules:
1: Dont alter ANYTHING inside phpuserlogin.php unless the readme tells you to.

Steps:
1: Make the table in your mysql database. Look at section 1 to 3 for help on that.

2: At the page you want to protect or protect something in you write this at the top.

<?
include'phpuserlogin.php';


?>

There must not be any lines or text before you include the script.
Also if you placed phpuserlogin.php in another folder then you need to write the path to it (NOT the url for it).

3: Make the options array.

Here is a very simple options array with the basic options you need to get the script to run.

<?
include'phpuserlogin.php'; // The include from step 2.

$new_phpuserlogin_options = array( // Here is the option array.
	'var_name'			=> 'login', // This name will be used to make the $vars phpuserlogin makes in forms and places in urls unigue. For eks. the $var that stores the username when you login would be called login[L][username] if you had used login as the var_name
	'page'				=> 'http://www.myserver.com/index.php', // If you enter a url for a page here, then people will only be able to login from that page, if the login form is showed on other pages it will print a link to this page. If you leave this empty or dont include this option then the users can login from all pages that has the login form on them.
	'hidden_key'		=> 0, // PLEASE REMEMBER TO CHANGE THIS. This one is importent. This number you write there will be used to make the script secure on  your server
	'mysql_table'		=> 'users', // This is the name of the table where usernames and passwords are stored
	'mysql_serv'		=> 'localhost', // This is the ip/host name for your MySQL server, this is almost always localhost. 
	'mysql_user'		=> 'draxker', // This is the username for your MySQL server 
	'mysql_pass'		=> '******', // This is the password for your MySQL server
	'mysql_data'		=> 'myserver_members', // This is the name of the database where the table is stored.
	'admins'			=> 'drakxter' // This is the usernames of the admins, some servers are case sensetiv so remember to type the usernames right. To enter more usernames simple spilt them with a , eg: drakxter,bob,tim,cap_zedo
);

?>

Note: All the old options from the last version are still there.

These are the only options you need to get the script to run right away, there are more though, but dont mind that for now.

4: Start the script.

You do this by adding some more code after the options array.
What you do is make a new object which you place in a $var (which you can give what ever name you want.).
You also supplie the options array to phpuserlogin while starting the script.

<?
include'phpuserlogin.php'; // The include from step 2.

$new_phpuserlogin_options = array( // Here is the option array from step 3.
	'var_name'	=> 'login', // This name will be used to make the $vars phpuserlogin makes in forms and places in urls unigue. For eks. the $var that stores the username when you login would be called login[L][username] if you had used login as the var_name
	'page'		=> 'http://www.myserver.com/index.php', // If you enter a url for a page here, then people will only be able to login from that page, if the login form is showed on other pages it will print a link to this page. If you leave this empty or dont include this option then the users can login from all pages that has the login form on them.
	'hidden_key'	=> 0, // PLEASE REMEMBER TO CHANGE THIS. This one is importent. This number you write there will be used to make the script secure on  your server
	'mysql_table'	=> 'users', // This is the name of the table where usernames and passwords are stored
	'mysql_serv'	=> 'localhost', // This is the ip/host name for your MySQL server, this is almost always localhost. 
	'mysql_user'	=> 'draxker', // This is the username for your MySQL server 
	'mysql_pass'	=> '******', // This is the password for your MySQL server
	'mysql_data'	=> 'myserver_members', // This is the name of the database where the table is stored.
	'admins'	=> 'drakxter' // This is the usernames of the admins, some servers are case sensetiv so remember to type the usernames right. To enter more usernames simple spilt them with a , eg: drakxter,bob,tim,cap_zedo
);

$login = new phpuserlogin($new_phpuserlogin_options);

?>

5: Protect something and print a login form somewhere.

Let's say you have the text "Chick" somewhere in your page. To protect it so only logged in users could see it you would have to do this.

<?
if ($login->loginstatus == TRUE) {
?>
Chick
<?
}
?>

What you do is place a statement around the thing you want to protect. $login->loginstatus is only TRUE when a user is logged in.

Now to print a login form somewhere you do this.

<?
$login->printForm();
?>

It will now print the login form (or a link to it if the page option was set and the user is on another page).

--

There, thats how you do it.

A even better way to do this would be to make a new file, and place this code into it.
Then you could just include that file in every page where you wanted to use phpuserlogin
This way you would only have one options array in one file.

Take a look at access_control.php which came with this file.
It contains the code that includes and starts phpuserlogin2.
It also has a complete options array. Every option in the file has a comment next to it to tell you what it does.
So look in the access_control.php for help on the options.

---

Show online users feature:
To use it you need to: Set the option 'users_online' to TRUE
Ones that is done the script will start tracking users (will save the last time and date they did something after being logged in.)

Now to show the list of users you do this.

<?
$login->printOnlineUsersList();
?>

---

Extra tables and fields:

I wont go into detail here about how the new stuff where you can select what kind of form field is used in the reg form works. Sorry.
But it should be easy to understand how the system works if you take a look in access_control.php and look at the 'mysql_fields' option
and the array's in it.
There are some new options but I will only list the two you need. The two that handels the templates.

---

Register Feature:

To use it you need to: Set the option 'register' to TRUE 'register_page' to the url of the page where people will find the register form.

Now to show the form you do this.

<?
$login->printRegForm();
?>

---

Template System:

The scripts comes with the default templates inside it but also in files outside the script (You can find the templates in the 'phpuserlogin_templates' folder in the zip)

If you want to use the outside templates you need to edit at least one option. Thats 'temp_folder': It is the direct path for the template files.

'temp_folder'	=> '', // The direct path to the folder where the templates files are. (/home/bla/bla/bla/phpuserlogin_templates)
'temp_prefix'	=> 'phpuserlogin', // This is the prefix that is in front of the register templates. Eg phpuserlogin_reg_field_text. Default is the prefix the templates files is used right now.

If you open up the templates files you will find some html kind of tags that start and end with { } instead of < >
These tags are special, they will be removed with url, text or other templates. You must keep ALL these tags in the template files (also dont mix them together.)
If a tag is inside a link (as the url) then it needs to stay that way.

All the files name _login_ has something to do with printForm.
All the files name _reg_ has something to do with printRegForm.
All the files name _oul_ has something to do with printOnlineUsersList.

---

Admin:

To use it simple make your own user a admin and login. Then a Admin link should appere under the logout link.
Just click on it and the admin will start (Your browser must support java.)

------------

Last note, this was written in a hurry so sorry for spelling errors and anything I wrote in a nonunderstanderbal way.

If you need help then go to our forums.

http://forums.oxyscripts.com/