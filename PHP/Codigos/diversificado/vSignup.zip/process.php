<? require ("signupconfig.php"); ?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">

<?
	include ("auth.php");
	$connection = mysql_connect($dbhost, $dbusername, $dbpassword);
	$db = mysql_select_db($dbname);
	$EmailQuery = mysql_query("SELECT * FROM signup WHERE email='$email'");
	$email = strtolower($email);
	$EmailExist = mysql_num_rows($EmailQuery);	// Returns 0 if not yet existing
	$username = strtolower($username);
	$UsernameQuery = mysql_query ("SELECT * FROM signup WHERE uname='$username'");
	$UsernameExist = mysql_num_rows($UsernameQuery);
	
	if (trim($ValidEmailDomains)=="")
	{
		$EmailArray = "";
	}
	else
	{
		$EmailArray = split (" ", $ValidEmailDomains);
	}
	
	$confirmkey =  md5(uniqid(rand())); 
	
	// CHECK FOR REQUIRED FIELDS
	if (!trim($username))
	{
		print "<p><font size=\"3\" face=\"Verdana, Arial\" color=\"#FF0000\"><b>Username field cannot be left blank!</b></font></p>";
		exit;
	}
	if (!trim($password))
	{
		print "<p><font size=\"3\" face=\"Verdana, Arial\" color=\"#FF0000\"><b>Password field cannot be left blank!</b></font></p>";
		exit;
	}
	if (!trim($fname))
	{
		print "<p><font size=\"3\" face=\"Verdana, Arial\" color=\"#FF0000\"><b>First Name field cannot be left blank!</b></font></p>";
		exit;
	}
	if (!trim($lname))
	{
		print "<p><font size=\"3\" face=\"Verdana, Arial\" color=\"#FF0000\"><b>Last Name field cannot be left blank!</b></font></p>";
		exit;
	}
	if (!trim($email))
	{
		print "<p><font size=\"3\" face=\"Verdana, Arial\" color=\"#FF0000\"><b>Email field cannot be left blank!</b></font></p>";
		exit;
	}
	
	// Validate Email Address String
  	$good = ereg('^[-!#$%&\'*+\\./0-9=?A-Z^_`a-z{|}~]+'.
               '@'.
               '[-!#$%&\'*+\\/0-9=?A-Z^_`a-z{|}~]+\.'.
               '[-!#$%&\'*+\\./0-9=?A-Z^_`a-z{|}~]+$',
               $email);	
	if (!$good)
	{
		print "<p><font size=\"3\" face=\"Verdana, Arial\" color=\"#FF0000\"><b>Email field has invalid characters!</b></font></p>";
		exit;
	}
	
	// Validate Email Address String - FOR VALID EMAIL DOMAINS
	$found=false;
	if ($EmailArray!="")
	{
		for ($ct=0;$ct<=sizeof($EmailArray)-1;$ct++)
		{

			if (ereg($EmailArray[$ct], $email))
			{
				$ct=sizeof($EmailArray);
				$found=true;
			}
			else
			{
				$found=false;
			}
		}
	}
	else
	{
		$found = true;
	}
	if (!$found)
	{
		print "<p><font size=\"3\" face=\"Verdana, Arial\" color=\"#FF0000\"><b>Email address does not belong to the list of allowable email domains!</b></font></p>";
		exit;
	}

	// Make sure username does not yet exist in the db
	if ($UsernameExist>0)
	{
		print "<p><font size=\"3\" face=\"Verdana, Arial\" color=\"#FF0000\"><b>Username already exists in the database!</b></font></p>";
		exit;
	}
	
	// Make sure email address does not yet exist in the db
	if ($EmailExist>0)
	{
		print "<p><font size=\"3\" face=\"Verdana, Arial\" color=\"#FF0000\"><b>Email address already exists in the database!</b></font></p>";
		exit;
	}
	
	// Add new member to table signup
	$addmember = mysql_query("INSERT INTO signup VALUES ('','$username','$fname','$lname','$email','$country','$zipcode',NOW(),'$confirmkey')");
	
	// If SUCCESSFUL, add to vAuthenticate tables too
	if ($addmember)
	{
		$AddToAuth = new auth();
		$add = $AddToAuth->add_user($username,$password,"Ungrouped","999","inactive", '', 0);
	}
	
	// if successful in adding to vAuthenticate, send confirmation email
	if ($add==1)
	{
		$emailerMessage .= "\n\n";	// 2 Line Breaks
		$emailerMessage .= $confirm;	// URL to confirm.php -> see signupconfig.php
		$emailerMessage .= "?confirmkey=" . $confirmkey;	// add confirm key to message
		$emailerMessage .= "\n\n";	// 2 Line Breaks
		
		$sent = @mail($email, $emailerSubject, $emailerMessage, "From:$emailerName<$emailerEmail>\nReply-to:$emailerEmail"); 
	}
	
?>

<p><font size="3" face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000"><b>Thank 
  you for signing up!</b></font></p>
<p><font size="2" face="Verdana, Arial, Helvetica, sans-serif">A confirmation 
  email was sent to the email address you specified. Please confirm your membership 
  as soon as you receive the email.</font></p>
<p><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Click <a href="login.php">here</a> 
  to login after you've confirmed your membership.</font></p>
</body>
</html>
