<?
/*
File: signupconfig.php
Script Name: vSignup 1.0
Author: Vincent Ryan Ong
Email: support@beanbug.net

Description:
vSignup is a member registration script which utilizes vAuthenticate
for its security handling. This handy script features email verification,
sending confirmation email message, restricting email domains that are 
allowed for membership, and much more.

This script is a freeware but if you want to give donations,
please send your checks (coz cash will probably be stolen in the
post office) them to:

Vincent Ryan Ong
Rm. 440 Wellington Bldg.
655 Condesa St. Binondo, Manila
Philippines, 1006
*/

$dbhost = "localhost";	// change this to reflect your db host name
$dbusername = "root";	// change this to reflect your db username
$dbpassword = "";	// change this to reflect your db password
$dbport = "3306";	// default is 3306; change this if different

$dbname = ""; 	// change this to the name of your 

$confirm = "http://localhost/Scripts/Signup/confirm.php";	// change this to reflect the URL location of confirm.php 

// Change this to reflect the email domains that you want to allow signup with.
// Leave blank to allow any email address
// Separate email domains with a space
// Include the @ in front of the email domain to ensure proper pocessing
$ValidEmailDomains = "@email1.com @email2.com @email3.com";	

// change this to refect the email address that will be used on 
// the confirmation email
$emailerEmail = "support@beanbug.net";	

// change this to refect the email name that will be used on 
// the confirmation email
$emailerName = "Member Services";	

// change this to refect the subject that will be used on the
// confirmation email
$emailerSubject = "Membership Confirmation";	

// change this to refect the email message that will be used on 
// the confirmation email. Make sure that you use a "\n"  without
// the quotes to denote a line break
$emailerMessage = "Hi there!\n\nPlease click on the link at the bottom of this message to confirm your membership.\n";	

?>