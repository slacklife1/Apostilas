# File: createdb.sql
# Script Name: vAuthenticate 2.0
# Author: Vincent Ryan Ong
# Email: support@beanbug.net
#
# Description:
# vAuthenticate is a revolutionary authentication script which uses
# PHP and MySQL for lightning fast processing. vAuthenticate comes 
# with an admin interface where webmasters and administrators can
# create new user accounts, new user groups, activate/inactivate 
# groups or individual accounts, set user level, etc. This may be
# used to protect files for member-only areas. vAuthenticate 
# uses a custom class to handle the bulk of insertion, updates, and
# deletion of data. This class can also be used for other applications
# which needs user authentication.
#
# This script is a freeware but if you want to give donations,
# please send your checks (coz cash will probably be stolen in the
# post office) them to:
#
# Vincent Ryan Ong
# Rm. 440 Wellington Bldg.
# 655 Condesa St. Binondo, Manila
# Philippines, 1006

#
# AUTHUSER
#

CREATE TABLE authuser (
  id int(11) NOT NULL auto_increment,
  uname varchar(25) NOT NULL default '',
  passwd varchar(25) NOT NULL default '',
  team varchar(25) NOT NULL default '',
  level int(4) NOT NULL default '0',
  status varchar(10) NOT NULL default '',
  lastlogin datetime default NULL,
  logincount int(11) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Dumping data for table 'authuser'
#

INSERT INTO authuser VALUES ( '1', 'sa', '', 'Admin', '1', 'active', '', 0);
INSERT INTO authuser VALUES ( '2', 'admin', '', 'Admin', '1', 'active', '', 0);
INSERT INTO authuser VALUES ( '3', 'test', 'test', 'Temporary', '999', 'active', '', 0);


#
# AUTHTEAM
#

CREATE TABLE authteam (
   id int(4) NOT NULL auto_increment,
   teamname varchar(25) NOT NULL,
   teamlead varchar(25) NOT NULL,
   status varchar(10) NOT NULL,
   PRIMARY KEY (id),
   KEY teamname (teamname, teamlead)
);

#
# Dumping data for table 'authteam'
#

INSERT INTO authteam VALUES ( '1', 'Ungrouped', 'sa', 'active');
INSERT INTO authteam VALUES ( '2', 'Admin', 'sa', 'active');
INSERT INTO authteam VALUES ( '3', 'Temporary', 'sa', 'active');

