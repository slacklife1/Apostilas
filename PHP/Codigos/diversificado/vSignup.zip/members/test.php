<?
	include ("../auth.php");
	include ("../authconfig.php");
	include ("../check.php");	
?>

<html>
<head>
<title>Members Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<font size="2" color="#FF0000" face="Verdana, Arial, Helvetica, sans-serif"><b>This 
is a protected area. If you can see this, you have logged in successfully a while 
ago (on this same session). </b></font> 
</body>
</html>
