# File: readme.txt
# Script Name: vSignup 1.0
# Author: Vincent Ryan Ong
# Email: support@beanbug.net
# 
# Description:
# vSignup is a member registration script which utilizes vAuthenticate
# for its security handling. This handy script features email verification,
# sending confirmation email message, restricting email domains that are 
# allowed for membership, and much more.
#
# This script is a freeware but if you want to give donations,
# please send your checks (coz cash will probably be stolen in the
# post office) them to:
#
# Vincent Ryan Ong
# Rm. 440 Wellington Bldg.
# 655 Condesa St. Binondo, Manila
# Philippines, 1006

#
# Table structure for table `signup`
#

CREATE TABLE signup (
  id int(11) NOT NULL auto_increment,
  uname varchar(25) NOT NULL default '',
  fname varchar(30) NOT NULL default '',
  lname varchar(20) NOT NULL default '',
  email varchar(45) NOT NULL default '',
  country varchar(20) default NULL,
  zipcode bigint(20) default NULL,
  datejoined datetime NOT NULL default '0000-00-00 00:00:00',
  confirmkey varchar(32) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;
