<?php
echo "</body>\n";
echo "</html>\n";
?>
