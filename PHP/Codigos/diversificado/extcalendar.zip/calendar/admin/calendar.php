<?
include ("versioncheck.inc.php");
include ('cal_header.inc.php');

// navbar at the top
$m = date("n");
$y = date("Y");
$d = date("j");


if ($op == "outof") { echo "<b>";}
echo "<a href=calendar.php?op=outof>".translate("outof")."</a>";
if ($op == "outof") { echo "</b>"; }
if ($op == "eventform"){echo "<b>";}
echo " - <a href=calendar.php?op=eventform>".translate("addevent")."</a>";
if ($op == "eventform"){echo "</b>";}
if ($op == "cats"){ echo "<b>"; }
echo " - <a href=calendar.php?op=cats>".translate("cate")."</a>";
if ($op == "cats"){ echo "</b>"; }
if ($op == "day"){ echo "<b>"; }
echo " - <a href=calendar.php?op=day>".translate("day")."</a>";
if ($op == "day"){ echo "</b>"; }
if ($op == "week"){ echo "<b>"; }
echo " - <a href=calendar.php?op=week>".translate("week")."</a>";
if ($op == "week"){ echo "</b>"; }
if ($op == "cal"){ echo "<b>"; }
echo " - <a href=calendar.php?op=cal&month=$m&year=$y>".translate("cal")."</a>";
if ($op == "cal"){ echo "</b>"; }
echo " - <a href=calendar.php>Index</a>";
echo " - <a href=calendar.php?op=users>".translate("users")."</a>";
echo " - <a href=cal_login.php?op=logout>".translate("logout")."</a>";
echo "<hr>\n";

#today's date
$weekday = date ("w", mktime(12,0,0,$m,$d,$y));
$weekday++;
echo $week[$weekday]." ".$d." ".strtolower($maand[$m])." ".$y;
echo "<br><br>";

/**********************************/
/* show nonapproved on index-page */
/**********************************/

function nonapproved(){
global $language,$maand;

$query = "select id,title,cat_name,day,month,year from events left join calendar_cat on events.cat=calendar_cat.cat_id where approved='0' order by day,month,year ASC";
$result = mysql_query($query);
$rows = mysql_num_rows($result);
if (!$rows){

echo "<h3>".translate("nononapproved")."</h3>\n";

}

else {

echo "<h3>".translate("nonapproved").$rows."</h3>\n";
$foo = '';
while ($row = mysql_fetch_object($result)){

$foo++ % 2 ? $color="BBBBBB" : $color="EEEEEE";

echo "<table border=1 bgcolor=$color cellspacing=0 cellpadding=4 width=\"100%\">\n";
echo "<tr><td>\n<li><b>".stripslashes($row->title)."</b> ".translate("op")." ".$row->day." ".$maand[$row->month]." ".$row->year."\n";
echo " - ".translate("cat")." : ".$row->cat_name."\n";
echo " - <a href=calendar.php?op=view&id=".$row->id.">".translate("view")."</a>\n";
echo " - <a href=calendar.php?op=edit&id=".$row->id.">".translate("edit")."</a>\n";
echo " - <a href=calendar.php?op=approve&id=".$row->id.">".translate("approve")."</a>\n";
echo "</td></tr>\n";
echo "</table>\n";

}

}

}

/**********************************/
/* show out-of-date on index-page */
/**********************************/

function outof(){
global $language,$maand;

$day = date("d");
if (substr($day,0,1) == "0")
$day = substr_replace ($day,'', 0, 1);
$month = date("n");
$year = date("Y");

$query = "select id,title,cat_name,day,month,year from events left join calendar_cat on events.cat=calendar_cat.cat_id ";
$query .= "where ((month='$month' and year<='$year') || (month<'$month' and year<='$year')) order by day,month,year ASC";

$result = mysql_query($query);

$rows = mysql_num_rows($result);

echo "<a href=calendar.php?op=delalloodev>".translate("delalloodev")." !</a><br><br>\n";
$foo = '';
while ($row = mysql_fetch_object($result)){

$foo++ % 2 ? $color="BBBBBB" : $color="EEEEEE";
if ((($row->day<$day) && ($row->month=$month) && ($row->year=$year)) || ($row->month<$month)){ 
echo "<table border=1 bgcolor=$color cellspacing=0 cellpadding=4 width=\"100%\">\n";
echo "<tr><td>\n<li><b>".stripslashes($row->title)."</b> ".translate("op")." ".$row->day." ".$maand[$row->month]." ".$row->year."\n";
echo " - ".translate("cat")." : ".$row->cat_name."\n";
echo " - <a href=calendar.php?op=view&id=".$row->id.">".translate("view")."</a>\n";
echo " - <a href=calendar.php?op=edit&id=".$row->id.">".translate("edit")."</a>\n";
echo " - <a href=calendar.php?op=delev&id=".$row->id.">".translate("delev")."</a>\n";
echo "</td></tr>\n";
echo "</table>\n";
}
}

}


/*****************/
/* approve event */
/*****************/

function approve($id){

$result = mysql_query("update events set approved='1' where id='$id'");
echo "<meta http-equiv=\"refresh\" content=\"0; url=calendar.php\">";
}

/**************/
/* view event */
/**************/

function view($id){
global $language,$maand;

$query = "select id,title,cat_name,description,day,month,year,approved,url,email from events left join calendar_cat on events.cat=calendar_cat.cat_id where id='$id'";
$result = mysql_query($query);
$row = mysql_fetch_object($result);
echo "<a href=calendar.php?op=edit&id=".$row->id.">".translate("edit")."</a>\n";
echo " - <a href=calendar.php?op=delev&id=".$row->id.">".translate("delev")."</a>\n";
if ($row->approved != 1){
echo " - <a href=calendar.php?op=approve&id=".$row->id.">".translate("approve")."</a>\n"; }
echo "<h3>".stripslashes($row->title)."</h3>\n";
echo "<li>".translate("bdate")." : ".$row->day ." ".$maand[$row->month]." ".$row->year."\n";
echo "<li>".translate("cat")." : ".$row->cat_name."\n";
echo "<li>".translate("description")."<br>\n";
echo stripslashes($row->description);
echo "<br><br>";
if ($row->email)
        echo "<li>".translate("email")." : <a href=mailto:".$row->email.">".$row->email."</a>\n";
if ($row->url){
echo "<li>".translate("moreinfo")." : <a href=http://".$row->url." target=_blank>".$row->url."</a>\n";
}
}

/*****************/
/* back function */
/*****************/

function back(){
echo "<br><a href=javascript:history.back()>".translate("back")."</a>\n";
}


/*************************/
/* overview of categorys */
/*************************/

function cats(){

$query = "select cat_id,cat_name from calendar_cat";
$result = mysql_query($query);
$rows = mysql_num_rows($result);

    // if no rows
    if ($rows == "0"){
        echo "<h3>".translate("nocats")."</h3>\n";
    }
    // show categorys
    else {
        echo "<h3>".translate("cats")."</h3>\n";
        echo "<table border=0 cellspacing=0 cellpadding=4>\n";
        echo "<tr><td align=center><b>".translate("name")."</b></td>";
        echo "<td align=center><b>".translate("edit")."</b></td>";
        echo "<td align=center><b>".translate("del")."</b></td></tr>";
        $foo = '';
	while ($row = mysql_fetch_object($result)){
            $foo++ % 2 ? $color="BBBBBB" : $color="DDDDDD";
            echo "<tr bgcolor=$color><td><li><a href=calendar.php?op=cat&id=".$row->cat_id.">".stripslashes($row->cat_name)."</a></tD>\n";
            echo " <td><a href=calendar.php?op=editcat&id=".$row->cat_id.">".translate("editcat")."</a></tD>\n";
            echo " <td><a href=calendar.php?op=delcat&id=".$row->cat_id.">".translate("delcat")."</a></tD></tr>\n";
        }
        echo "</table>\n";
    }

echo "<hr>\n";
echo "<h3>\n".translate("addcat")."\n</h3>\n";
echo "<form action=calendar.php?op=addcat method=post>\n";
echo "<input type=text name=cat size=30><br>\n";
echo "<input type=submit value=\"".translate("addcat")."\">\n";
echo "</form>\n";
}

/*******************************/
/* view events of one category */
/*******************************/

function cat($id){
global $language,$maand;

$query = "select id,title,cat_name,day,month,year from events left join calendar_cat on events.cat=calendar_cat.cat_id where approved='1' and events.cat='$id' order by day,month,year ASC";
$result = mysql_query($query);
$rowname = mysql_fetch_object($result);
$rows = mysql_num_rows($result);
if (!$rows){

echo "<br><h3>".translate("noevents")."</h3>\n";

}

else {

echo "<h3>".translate("numbevents")." ".$rowname->cat_name."</h3>\n";

$result = mysql_query($query);
$foo = '';
while ($row = mysql_fetch_object($result)){

$foo++ % 2 ? $color="BBBBBB" : $color="EEEEEE";

echo "<table border=1 bgcolor=$color cellspacing=0 cellpadding=4 width=\"100%\">\n";
echo "<tr><td>\n<li><b>".stripslashes($row->title)."</b> ".translate("op")." ".$row->day." ".$maand[$row->month]." ".$row->year."\n";
echo " - <a href=calendar.php?op=view&id=".$row->id.">".translate("view")."</a>\n";
echo " - <a href=calendar.php?op=edit&id=".$row->id.">".translate("edit")."</a>\n";
echo "</td></tr>\n";
echo "</table>\n";

}

}

}


/****************/
/* add category */
/****************/

if ($op == "addcat" || $op == "updatecat"){
   $cat = $_POST['cat'];
}

function addcat($cat){

$cat = trim($cat);
$query = "insert into calendar_cat values('','".addslashes($cat)."')";
$result = mysql_query($query);
echo "<meta http-equiv=\"refresh\" content=\"0; url=calendar.php?op=cats\">";

}

/*****************/
/* edit category */
/*****************/

function editcat ($id){

 $query = "select cat_name from calendar_cat where cat_id='$id'";
 $result = mysql_query($query);
 $row = mysql_fetch_object($result);
 echo "<form action=calendar.php?op=updatecat&id=$id method=post>\n";
 echo "<input type=text name=cat value=\"".stripslashes($row->cat_name)."\"><br>\n";
 echo "<input type=submit value=\"".translate("update")."\">\n";
 echo "</form>\n";

}

/*******************/
/* update category */
/*******************/

function updatecat($cat,$id){

  $query = "update calendar_cat set cat_name='".addslashes(trim($cat))."' where cat_id='$id'";
  mysql_query($query);
  echo "<meta http-equiv=\"refresh\" content=\"0; url=calendar.php?op=cats\">";

}

/***************************/
/* delete category question*/
/***************************/

function delcat($id){

echo translate("reallydelcat")."<br><br>\n";
echo "<a href=javascript:history.back()>".translate("noback")."</a><br><br>\n";
echo "<a href=calendar.php?op=delcatok&id=$id>".translate("surecat")."</a>\n";

}

/*******************************/
/* delete category confirmation*/
/*******************************/

function delcatok($id){

// del from cat
$res = mysql_query("delete from calendar_cat where cat_id='$id'");

// del events with cat = $id
$querysel = "select id from events where cat='$id'";
$resultsel = mysql_query($querysel);
while ($rowsel = mysql_fetch_object($resultsel)){
$querydel = "delete from events where id='".$rowsel->id."'";
$resultdel = mysql_query($querydel);

}
echo "<meta http-equiv=\"refresh\" content=\"0; url=calendar.php?op=cats\">";

}

/**********************/
/* add event: the form */
/**********************/

function eventform(){
global $language,$maand;
echo "<h3>".translate("addevent")."</h3>";
echo "<form action=calendar.php?op=addevent method=post>\n";
echo translate("eventitle")."<br>\n";
echo "<input type=text name=title><br>\n";
echo translate("description")."<br>\n";
echo "<textarea name=description cols=50 rows=7></textarea><br>\n";
echo translate("email")."<br>\n";
echo "<input type=text name=email><br>\n";
echo "URL<br>\n";
echo "<input type=text name=url><br>\n";
// get the categorys
echo "<select name=cat>\n\t<option value=0>".translate("choosecat")."\n";
$query = "select cat_id,cat_name from calendar_cat";
$result = mysql_query($query);
    while ($row = mysql_fetch_object($result)){
        echo "\t<option value=".$row->cat_id.">".$row->cat_name."\n";
    }

echo "</select>\n<br>\n";

// checkbutton for one date or more dates !
echo "<input type=radio value=one name=dates checked> ".translate("onedate")."<input type=radio value=more name=dates>".translate("moredates")."<br>\n";
// get days
echo translate("bdate")."<br>\n";
echo "<select name=bday>\n\t<option value=0>".translate("selectday")."\n";
for ($i = 1;$i<=31;$i++){
echo "\t<option>$i\n";
}
echo "</select>&nbsp;&nbsp;\n";

// get months
echo "<select name=bmonth>\n\t<option value=0>".translate("selectmonth")."\n";
for($i=1;$i<13;$i++){
  echo "\t<option value=".$i.">".ucfirst($maand[$i])."\n";
}
echo "</select>&nbsp;&nbsp;\n";

// get year and give 3 years more to select
echo "<select name=byear>\n\t<option value=0>".translate("selectyear")."\n";
$year = date("Y");
for ($i=0;$i<=4;$i++){
echo "\t<option>$year\n";
$year += 1;
}
echo "</select><br>\n";
//echo "meerdere datums : (in te vullen zo: dd-mm-yyyy;dd-mm-yyyy; - ook bvb, 1 dag = 01 ingeven ! EN eind-';' niet doen !) <br>\n";
echo translate("moredatesexplain")."<br>\n";
echo "<input type=text name=mdata size=50><br>\n";
echo "<input type=submit value=\"".translate("addevent")."\">\n<br>\n";

echo "<form>\n";

}

/*************/
/* add event */
/*************/

if ($op == "addevent" || $op == "upevent"){

  if ($op == "addevent"){
    $dates = $_POST['dates'];
    $mdata = $_POST['mdata'];
  }

  $title = $_POST['title'];
  $description = $_POST['description'];
  $email = $_POST['email'];
  $url = $_POST['url'];
  $cat = $_POST['cat'];
  $bday = $_POST['bday'];
  $bmonth = $_POST['bmonth'];
  $byear = $_POST['byear'];

}

function addevent($title,$description,$url,$email,$cat,$dates,$bday,$bmonth,$byear,$mdata){
global $caleventadminapprove;

$title = addslashes($title);
$description = addslashes(nl2br($description));
$url = str_replace("http://","",$url);
$approve = $caleventadminapprove;
// als datum een is ...  
if ($dates == "one"){
  $query = "insert into events values('','$title','$description','$url','$email','$cat','$bday','$bmonth','$byear','$approve')";
  //echo $query;
  $result = mysql_query($query);
  echo "<meta http-equiv=\"refresh\" content=\"0; url=calendar.php\">";
 }
 if ($dates == "more"){
  $data = explode(";",$mdata);
    for($i=0;$i<count($data);$i++){
      $bday = substr("$data[$i]",0,2);
        if (substr("$bday",0,1) == "0"){
           $bday = str_replace("0","",$bday);
        }
      $bmonth = substr("$data[$i]",3,2);
        if (substr("$bmonth",0,1) == "0"){
           $bmonth = str_replace("0","",$bmonth);
        }
      $byear = substr("$data[$i]",6,4);
      $query = "insert into events values('','$title','$description','$url','$email','$cat','$bday','$bmonth','$byear','1')";
      //echo $query."<br>";
      $result = mysql_query($query);
      echo "<meta http-equiv=\"refresh\" content=\"0; url=calendar.php\">";
    }
 }
}

/**********************/
/* update event: form */
/**********************/

function edit($id){
global $language,$maand;

$query = "select id,title,description,url,email,cat,cat_name,day,month,year from events left join calendar_cat on events.cat=calendar_cat.cat_id where events.id='$id'";
$result = mysql_query($query);
$rowe = mysql_fetch_object($result);

echo "<h3>".translate("upevent")."</h3>\n";
echo "<form action=calendar.php?op=upevent&id=$id method=post>\n";
echo translate("eventitle")."<br>\n";
echo "<input type=text name=title value=\"".stripslashes($rowe->title)."\"><br>\n";
echo translate("description")."<br>\n";
echo "<textarea name=description cols=50 rows=7>".stripslashes(strip_tags($rowe->description))."</textarea><br>\n";
echo translate("email")."<br>\n";
echo "<input type=text name=email value=\"".$rowe->email."\"><br>\n";
echo "URL<br>\n";
echo "<input type=text name=url value=\"".$rowe->url."\"><br>\n";
// get the categories
echo "<select name=cat>\n\t";
$query = "select cat_id,cat_name from calendar_cat";
$result = mysql_query($query);
    while ($row = mysql_fetch_object($result)){
        echo "\t<option value=".$row->cat_id;
        if ($rowe->cat == $row->cat_id){
            echo " selected";
        }
        echo ">".$row->cat_name."\n";
    }

echo "</select>\n<br>\n";

// get days
echo translate("bdate")."<br>\n";
echo "<select name=bday>\n\t";
for ($i = 1;$i<=31;$i++){
echo "\t<option";
if ($rowe->day == $i){
echo " selected";
}
echo ">$i\n";
}
echo "</select>&nbsp;&nbsp;\n";

// get months
echo "<select name=bmonth>\n\t<option value=0>".translate("selectmonth")."\n";
for($i=1;$i<13;$i++){ 
  echo "\t<option";
  if ($rowe->month == $i){
    echo " selected";
  }
  echo " value=".$i.">".ucfirst($maand[$i])."\n"; 
} 
echo "</select>&nbsp;&nbsp;\n";

// get year and give 3 years more to select
echo "<select name=byear>\n\t";
$year = date("Y");
for ($i=0;$i<=4;$i++){
echo "\t<option";
if ($rowe->year == $year){
echo " selected";
}
echo ">$year\n";
$year += 1;
}
echo "</select><br>\n";

echo "<input type=submit value=\"".translate("upevent")."\">\n<br>\n";

echo "<form>\n";


}

/****************/
/* update event */
/****************/

function upevent($id,$title,$description,$url,$email,$cat,$bday,$bmonth,$byear){

$title = addslashes($title);
$description = addslashes(nl2br($description));
$url = str_replace("http://","",$url);

$query = "update events set title='$title',description='$description',url='$url',email='$email',cat='$cat',day='$bday',month='$bmonth',year='$byear' where id='$id'";
$result = mysql_query($query);
echo "<meta http-equiv=\"refresh\" content=\"0; url=calendar.php?op=view&id=$id\">";

}

/**************************/
/* delete event: question */
/**************************/

function delev($id){
echo "<h3>".translate("delev")." ?</h3>";
echo "<h3>";
back();
echo "</h3>";
echo "<h3><a href=calendar.php?op=delevok&id=$id>".translate("delevok")."</a></h3>";
}

/********************/
/* delete event: ok */
/*******************/

function delevok($id){

  $query = "delete from events where id='$id'";
  mysql_query($query);
  echo "<meta http-equiv=\"refresh\" content=\"0; url=calendar.php\">";

}

/*******************************************/
/* delete all out-of-date events: question */
/*******************************************/

function delalloodev(){
global $language,$m,$d,$y;

$day = $d;
$month = $m;
$year = $y;
$id = '';
$query = "select id,day,month,year from events left join calendar_cat on events.cat=calendar_cat.cat_id where month<='$month' and year<='$year' order by day,month,year ASC";
$result = mysql_query($query);
while ($row = mysql_fetch_object($result)){
    if ((($row->day<$day) && ($row->month=$month) && ($row->year=$year)) || ($row->month<$month)){
        $id .= $row->id."|";
    }
}

echo "<h3>".translate("delalloodev")." ?</h3>";
echo "<h3>";
back();
echo "</h3>";
echo "<h3><a href=calendar.php?op=delalloodevok&id=$id>".translate("delalloodevok")."</a></h3>";

}

/*************************************/
/* delete all out-of-date events: ok */
/*************************************/

function delalloodevok($id){

$id = explode("|",$id);

for ($i=0;$i<count($id);$i++){

mysql_query("delete from events where id='".$id[$i]."'");
}

  echo "<meta http-equiv=\"refresh\" content=\"0; url=calendar.php\">";
}

/***********************/
/* view events per day */
/***********************/

function day($ask,$da,$mo,$ye,$next,$prev){
global $maand,$week,$language,$m,$d,$y;

// als er geen dag is, dan is het vandaag
if (!$da){
    $da = $d;
    $mo = $m;
    $ye = $y;
}

$we = mktime(0,0,0,$mo,$da,$ye);
$we = strftime("%w",$we);
$we++;
echo "<h3>".translate("askedday").": ".$week[$we]." ".$da." ".$maand[$mo]." ".$ye."</h3>";

// eerst alle items zoeken (anders serieuze mix-up van vars)
$query = "select id,title,description,url,cat_name,day,month,year from events left join calendar_cat on events.cat=calendar_cat.cat_id where day='$da' and month='$mo' and year='$ye' order by title ASC";
$result = mysql_query($query);
if (!isset($yda))
   $yda = '';
// als ask = volgende dag...
if (!$ask || $ask == "nd"){
    // bepaal maand en jaar  voor previous (moet nu al, anders mix up !)
    $ymo = $mo;
    $yy = $ye;
    // als next is, optellen
    if ($next){
        $ok = 86400*$next;
        $da = date("j",time()+ $ok);
        $next++;
    }
    // geen next, dag is vandag, dus maar 1 keer vermenigvuldigen
    else {
        $da = date("j",time()+86400);
        $next = '2';
    }

    // vars voor volgende dag
    // nieuwe dag = 1, maand stijgt
    if ($da == "1")
        $mo++;
    // nieuwe maand = dertien, jaar stijgt
    if ($mo == "13"){
        $mo = '1';
        $ye += 1;
    }
    // vars voor vorige dag (als die er is natuurlijk)
    // dag
    if ($prev){
        if ($prev != "O"){
            $ok = 86400*$prev;
            $yda = date("j",time()+$ok);
            $prev++;
        }
        else {
            $yda = date("j");
            $prev = '1';
        }
    }
    else {
        $prev = 'O';
    }
    // nieuwe dag = 2, maand stijgt
    if ($da == "2")
        $ymo--;
    if ($ymo == "0")
        $ymo = '12';
    //als nieuwe dag gelijk aan 2 en nieuwe maand gelijk aan 1: jaar +1 pd-vars +1
    if ($da == "2" &&  $ymo == "1"){
        $yy -= 1;
    }
    // dag 31 & maand 12 = jaar beneden
    if ($yda == "31" && $ymo == "12")
        $yy -= 1;

    // vorige dag link, als next 2 is = vandaag op scherm, dus geen vorige dag (what's the use eh :)
    if ($next != "2")
        echo "<a href=\"calendar.php?op=day&ask=pd&da=$yda&mo=$ymo&ye=$yy&next=$next&prev=$prev\"><== ".translate("prevday")."</a> - ";
    // link naar volgende dag
    echo "<a href=\"calendar.php?op=day&ask=nd&da=$da&mo=$mo&ye=$ye&next=$next&prev=$prev\">".translate("nextday")." ==></a><br><br>";

}

// als ask = vorige dag ...
if ($ask == "pd"){

    // bepaal maand en jaar  voor previous (moet nu al, anders mix up !)
    $ymo = $mo;
    $yy = $ye;
    // next -> optellen
    $next -= 2;
    $ok = 86400*$next;
    $da = date("j",time()+ $ok);
    $next++;
    // vars voor volgende dag
    // nieuwe dag = 1, maand daalt
    if ($da == "2")
        $mo--;
    // nieuwe maand = dertien, jaar daalt
    if ($mo == "0"){
        $mo = '12';
        $ye -= 1;
    }
    if ($da == "2" && $mo == "13")
        $mo = "1";
    // vars voor vorige dag (als die er is natuurlijk)
    // dag
    $prev -=2;
    if ($prev == "0")
        $prev == "1";
    $ok = 86400*$prev;
    $yda = date("j",time()+$ok);
    $prev++;
    // nieuwe dag = 2, maand daalt
    if ($da == "2"){
        $ymo--;
        $mo++;
    }
    if ($da == "1")
        $mo++;
    if ($ymo == "13"){
        $ymo = '1';
        $yy -= 1;
    }
    if ($ymo == "0")
        $ymo = '12';
    // nieuwe maand = twaalf, jaar daalt
    if ($yda == "31" && $ymo == "12"){
        $yy -= 1;
        $mo = '1';
        $ye += 1;
    }
    if ($yda == "30" && $ymo == "12"){
        $mo = '1';
        $ye += 1;
    }
    // als next gelijk is aan twee, dan is prev = O
    if ($next == "2")
        $prev ='O';

    // vorige dag link, als next 2 is = vandaag op scherm, dus geen vorige dag (what's the use eh :)
    if ($next != "2")
        echo "<a href=\"calendar.php?op=day&ask=pd&da=$yda&mo=$ymo&ye=$yy&next=$next&prev=$prev\"><== ".translate("prevday")."</a> - ";
    // link naar volgende dag
    echo "<a href=\"calendar.php?op=day&ask=nd&da=$da&mo=$mo&ye=$ye&next=$next&prev=$prev\">".translate("nextday")." ==></a><br><br>";

}
// beeld de zaken af van de gevraagde dag
  while ($row = mysql_fetch_object($result)){
    echo "<li><b><U>".$row->title."</u></b><br>";
    echo "Categorie : ".$row->cat_name."<br>";
    $de = str_replace("<br>","",$row->description);
    $de = str_replace("<br />","",$row->description);
    echo substr(stripslashes($de),0,100)." ...";
    echo "<br><a href=calendar.php?op=view&id=".$row->id.">".translate("readmore")."</a>";
    echo "<br><br>";
  }
}

/************************/
/* view events per week */
/************************/

function week($week,$date){
global $maand,$week,$language,$m,$d,$y,$ld,$fd;

if (!$date){
$year = $y;
$month = $m;
$day = $d;
}
else{
$year = substr($date,0,4);
$month = substr($date,5,2);
$day = substr($date,8,2);
}

// weeknummer
function weekNumber($dag,$maand,$jaar)
{
    $a = (14-$maand)/12;
    settype($a,"integer");
    $y = $jaar+4800-$a;
    settype($y,"integer");
    $m = $maand + 12*$a - 3;
    settype($m,"integer");
    $J = $dag + (153*$m+2)/5 + $y*365 + $y/4 - $y/100 + $y/400 - 32045;
    $d4 = ($J+31741 - ($J % 7)) % 146097 % 36524 % 1461;
    $L = $d4/1460;
    $d1 = (($d4-$L) % 365) + $L;
    $WeekNumber = ($d1/7)+1;
    settype($WeekNumber,"integer");
    return $WeekNumber;
}

$deesweek = mktime(0,0,0,date("d"), date("m"), date("Y"));
$weeknummer = weekNumber($day,$month,$year);
$laatsteweek = ($weeknummer + 10);
if ($laatsteweek > 52){
 $laatsteweek = $laatsteweek - 52;
}

// eerste dag van de week
function firstDayOfWeek($year,$month,$day){
 global $fd;
 $dayOfWeek=date("w");
 $sunday_offset=$dayOfWeek * 60 * 60 * 24;
 $fd = date("Y-m-d", mktime(0,0,0,$month,$day+1,$year) - $sunday_offset);
 return $fd;
}
firstDayOfWeek($year,$month,$day);

// laatste dag van de week
function lastDayOfWeek($year,$month,$day){
 global $ld;
 $dayOfWeek=date("w");
 $saturday_offset=(6-$dayOfWeek) * 60 * 60 * 24 ;
 $ld  = date("Y-m-d", mktime(0,0,0,$month,$day+1,$year) + $saturday_offset);
 return $ld;
}
lastDayOfWeek($year,$month,$day);

if (($date) && ($date != date("Y-m-d"))){
echo "<a href=calendar.php?op=week&date=".date("Y-m-d", mktime(0,0,0,$month,$day-7,$year))."><== ".translate("prevweek")."</a> - ";
}
echo "<a href=calendar.php?op=week&date=".date("Y-m-d", mktime(0,0,0,$month,$day+7,$year)).">".translate("nextweek")." ==> </a>";

// zin met datum begin van weeknummer en datum eind weeknummer
echo "<br>".translate("eventsthisweek");
$fdy = substr($fd,0,4);
$fdm = substr($fd,5,2);
if (substr($fdm,0,1) == "0"){
 $fdm = str_replace("0","",$fdm);}
$fdd = substr($fd,8,2);
echo $fdd." ".$maand[$fdm]." ".$fdy;
echo " ".translate("till");
$ldy = substr($ld,0,4);
$ldm = substr($ld,5,2);
if (substr($ldm,0,1) == "0"){
 $ldm = str_replace("0","",$ldm);}
$ldd = substr($ld,8,2);
echo " ".$ldd." ".$maand[$ldm]." ".$ldy;
echo " (".translate("weeknr")." : ".$weeknummer.")";

// en nu de evenementen eruit halen :)
$ld = date("Y-m-d", mktime(0,0,0,$ldm,$ldd+1,$ldy));
echo "<br><br>";
while ($fd != $ld){
$fdy = substr($fd,0,4);
$fdm = substr($fd,5,2);
if (substr($fdm,0,1) == "0"){
 $fdm = str_replace("0","",$fdm);}
$fdd = substr($fd,8,2);
$query = "select id,title,description,url,cat_name,day,month,year from events left join calendar_cat on events.cat=calendar_cat.cat_id where day='$fdd' and month='$fdm' and year='$fdy' order by title ASC";
//echo $query."<br>";
$result = mysql_query($query);
   while ($row = mysql_fetch_object($result)){
    echo "<li><b><U>".$row->title."</u></b><font size=-1> (".$row->day." ".$row->month." ".$row->year.")</font><br>";
    echo "Categorie : ".$row->cat_name."<br>";
    $de = str_replace("<br>","",$row->description);
    $de = str_replace("<br />","",$row->description);
    echo substr(stripslashes($de),0,100)." ...";
    echo "<br><a href=calendar.php?op=view&id=".$row->id.">".translate("readmore")."</a>";
    echo "<br><br>";
   }
$fd = date("Y-m-d", mktime(0,0,0,$fdm,$fdd+1,$fdy));
}

}

/*****************/
/* view calender */
/*****************/

function cal($month,$year){
global $maand,$week,$language,$m,$d,$y;
// previous month
$pm = $month;
if ($month == "1")
    $pm = "12";
else
    $pm--;
// previous year
$py = $year;
if ($pm == "12")
    $py--;

// next month
$nm = $month;
if ($month == "12")
    $nm = "1";
else
    $nm++;
// next year
$ny = $year;
if ($nm == 1)
    $ny++;    

// get month we want to see
$askedmonth = $maand[$month];
$askedyear = $year;
$firstday = strftime ("%w", mktime(12,0,0,$month,1,$year));
$firstday++;
// nr of days in askedmonth
$nr = date("t",mktime(12,0,0,$month,1,$year));
echo "<table border=1 cellspacing=0 cellpadding=4 width=100%>";
    echo "<tr>";
        echo "<td align=center colspan=7>";
        if ($month != date("n") || $year != date("Y")){
        echo "<font size=+1><a href=calendar.php?op=cal&month=".$pm."&year=".$py.">  <= ".$maand[$pm]." - ".$py."</a></font>"; }
        echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size=+3>".$askedmonth." ".$askedyear."</font>";
        echo "&nbsp;&nbsp;&nbsp;<font size=+1><a href=calendar.php?op=cal&month=".$nm."&year=".$ny.">".$maand[$nm]." - ".$ny." => </a></font></td>";
    echo "</tr>";
    echo "<tr>";
        // make the days of week, consisting of seven <td>'s (=days)
        for ($i=1;$i<=7;$i++){
            echo "<td align=center ";
            if ($i == 1)
                echo "bgcolor=#BBBBBB>".$week[$i]."</td>"; // sunday
            else    
                echo "bgcolor=#DDDDDD>".$week[$i]."</td>"; // rest of week
        }
    echo "</tr>";
        // begin the days
        for ($i=1;$i<$firstday;$i++){
            echo "<td>&nbsp;</td>";
        }
        $a=0;
        for ($i=1;$i<=$nr;$i++){
            echo "<td ";
            if ($i == $d && $month == $m && $year == $y){ // higlight today's day
                echo "bgcolor=yellow ";
            }
            else{
            echo "bgcolor=#EEEEEE ";
            }
            echo " valign=top><b>".$i."</b>";
            // now get eventual events on $i 
                $query = "select id,title from events left join calendar_cat on events.cat=calendar_cat.cat_id where day='$i' and month='$month' and year='$year' order by day,month,year ASC";
                $result = mysql_query($query);
                    while ($row = mysql_fetch_object($result)){

                        echo "<li><a href=calendar.php?op=view&id=".$row->id.">".$row->title."</a>";

                    }

            echo "</td>";
            // closing <tr> voor end of week
            $a++;
            if (($i == (8-$firstday)) or ($i == (15-$firstday)) or ($i == (22-$firstday)) or ($i == (29-$firstday)) or ($i == (36 - $firstday))){
            echo "</tr><tr>";
            $a = 0;
            }
        }
        // ending stuff (making 'white' td's to fill table
        if ($a != 0){
        $last = 7-$a;
            for ($i=1;$i<=$last;$i++){
                echo "<td>&nbsp;</td>";
            }
        }
    echo "</tr>";
echo "</table>";
echo "<table>";
echo "<tr><td bgcolor=yellow width=5 height=5>&nbsp;</td><td> = ".translate("todaysdate")."</td></tr>";
echo "</table>";
}


# userman
function users(){

   $query = "select * from calendar_admins";
   $result = mysql_query($query);
   echo "<h3>".translate("userman")."</h3>";
   echo "<table border=0>";
   $i = 1;
   while ($row = mysql_fetch_object($result)){
	echo "<tr><td><li>$i)</td><td>".$row->login."</td><td> - <a onclick=\"return confirmdelete()\" href=calendar.php?op=userdel&userid=".$row->admin_id.">".translate("deluser")."</A></td></tr>";
   $i++;
   }
   echo "</table><br>";
   echo "<h3>".translate("addnewuser")."</h3>";
   echo "<b>".translate("userwarning")."</b>";
   echo "<form action=calendar.php?op=adduser method=post>";
   echo translate("login")." <br><input type=text name=login><br>"; 
   echo translate("password")." <br><input type=password name=password><br>";
   echo "<input type=submit value=\"".translate("addnewuser")."\">";
   echo "</form>";
}

if ($op == "adduser"){

  $login = $_POST['login'];
  $password = $_POST['password'];

}

function adduser($login,$password){

  $crypt = "3xt-ca73ndar";
  $cryptpas = crypt($crypt,$password);
  $query = "insert into calendar_admins values ('','".$login."','".$cryptpas."')";
  mysql_query($query);
  echo "<meta http-equiv=\"refresh\" content=\"0; url=calendar.php?op=users\">";

}

function deluser($userid){

  $query = "delete from calendar_admins where admin_id='".$userid."'";
  mysql_query($query);
  echo "<meta http-equiv=\"refresh\" content=\"0; url=calendar.php?op=users\">";

}

switch ($op){
    
    // overview of category
    case"cats":{
       cats();
    break;
    }

    // overview of one cat
    case"cat":{
        cat($id);
    break;
    }

    // add new category
    case"addcat":{
       addcat($cat);
    break;
    }

    // edit category
    case "editcat":{
        editcat ($id);
    break;
    }

    // update category
    case"updatecat":{
        updatecat($cat,$id);
    break;
    }    
    
    // delete cat: question
    case"delcat":{
        delcat($id);
    break;
    }    

    // confirmation of delete cat
    case "delcatok":{
        delcatok($id);
    break;
    }

    // add event form
    case"eventform":{
       eventform();
    break;
    }

    // add event
    case "addevent":{
        addevent($title,$description,$url,$email,$cat,$dates,$bday,$bmonth,$byear,$mdata);
    break;
    }

    // approve event
    case "approve":{
        approve($id);
    break;
    }
    
    // view details of event    
    case "view":{
        view($id);
    break;
    }
    
    // edit event form
    case"edit":{
        edit($id);
    break;
    }
    
    // update event
    case"upevent":{
        upevent($id,$title,$description,$url,$email,$cat,$bday,$bmonth,$byear);
    break;
    }

    // delete event: question
    case"delev":{
        delev($id);
    break;
    }
    
    // delete event: ok
    case"delevok":{
        delevok($id);
    break;
    }

    // delete all out of date events: question
    case"delalloodev":{
        delalloodev();
    break;
    }
    
    // delete all out of date events: ok
    case"delalloodevok":{
        delalloodevok($id);
    break;
    }
    
    // view per day 
    case"day":{
        day($ask,$da,$mo,$ye,$next,$prev);
    break;
    }

    // view per week 
    case"week":{
        week($week,$date);
    break;
    }

    // view cal per month
    case"cal":{
        cal($month,$year);
    break;
    }
    
    // out-of-date events
    case"outof":{
        outof();
    break;
    }
 
    // overview of admin-users
    case"users":{
	users();
    break;
    }

    // add new user
    case"adduser":{
	adduser($login,$password);
    break;
    }

    //
    case"userdel":{
	deluser($userid);
    break;
    }

    // default: bar, and show new submissions
    default:{
        nonapproved();
    break;
    }
}

include ('cal_footer.inc.php');
?>
