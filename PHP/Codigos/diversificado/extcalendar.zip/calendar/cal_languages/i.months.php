<?
######################################################################
#Tradotto da by Fabio Mascio
#Translated by Fabio mascio
#http://www.italywebspa.com
#fmascio@cercaziende.it
#######################################################################
$maand[1]="Gennaio";
$maand[2]="Febbraio";
$maand[3]="Marzo";
$maand[4]="Aprile";
$maand[5]="Maggio";
$maand[6]="Giugno";
$maand[7]="Luglio";
$maand[8]="Agosto";
$maand[9]="Settembre";
$maand[10]="Ottobre";
$maand[11]="Novembre";
$maand[12]="Dicembre";
?>
