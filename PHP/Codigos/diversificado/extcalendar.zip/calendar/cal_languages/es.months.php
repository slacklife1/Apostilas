<?
/*
Traducido al espa�ol por Hern�n Ram�rez (hernanr@mipunto.com)
http://www.cida.ve/~hernanr
*/


$maand[1]="Enero";
$maand[2]="Febrero";
$maand[3]="Marzo";
$maand[4]="Abril";
$maand[5]="Mayo";
$maand[6]="Junio";
$maand[7]="Julio";
$maand[8]="Agosto";
$maand[9]="Septiembre";
$maand[10]="Octubre";
$maand[11]="Noviembre";
$maand[12]="Diciembre";
?>