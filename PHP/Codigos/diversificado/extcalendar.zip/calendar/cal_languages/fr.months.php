<?
$maand[1]="Janvier";
$maand[2]="Fevrier";
$maand[3]="Mars";
$maand[4]="Avril";
$maand[5]="Mai";
$maand[6]="Juin";
$maand[7]="Juillet";
$maand[8]="Ao�t";
$maand[9]="Septembre";
$maand[10]="Octobre";
$maand[11]="Novembre";
$maand[12]="D�cembre";
?>

