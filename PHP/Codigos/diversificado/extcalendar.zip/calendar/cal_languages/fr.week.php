<?
$week[1]="Dimanche";
$week[2]="Lundi";
$week[3]="Mardi";
$week[4]="Mercredi";
$week[5]="Jeudi";
$week[6]="Vendredi";
$week[7]="Samedi";
?>

