<?
/*
Traducido al espa�ol por Hern�n Ram�rez (hernanr@mipunto.com)
http://www.cida.ve/~hernanr
*/

$week[1]="Domingo";
$week[2]="Lunes";
$week[3]="Martes";
$week[4]="Mi�rcoles";
$week[5]="Jueves";
$week[6]="Viernes";
$week[7]="S�bado";
?>