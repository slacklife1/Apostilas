<?
######################################################################
#Tradotto da by Fabio Mascio
#Translated by Fabio mascio
#http://www.italywebspa.com
#fmascio@cercaziende.it
#######################################################################
$week[1]="Domenica";
$week[2]="Lunedi";
$week[3]="Martedi";
$week[4]="Mercoledi";
$week[5]="Giovedi";
$week[6]="Venerdi";
$week[7]="Sabato";
?>
