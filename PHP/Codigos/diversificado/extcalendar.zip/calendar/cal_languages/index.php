<?
# redirect to lower directory, nobobdy should be here ..
header("location: ../index.php");
?>
