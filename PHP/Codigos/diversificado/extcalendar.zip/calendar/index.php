<?
// locate to calendar.php
// you can delete this file if you want
header("location: calendar.php");
?>
