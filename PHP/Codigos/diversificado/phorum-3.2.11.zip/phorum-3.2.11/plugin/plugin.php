<?PHP
// Plugin system, made by Morgan Christiansson <mog@linux.nu>
$plugins = Array(
 "read_body"   => array(),
 "read_header" => array(),
 "post_fields" => array()
);

include("./plugin/replace/plugin.php");
#userinfo plugin, incomplete, needs database fields
?>