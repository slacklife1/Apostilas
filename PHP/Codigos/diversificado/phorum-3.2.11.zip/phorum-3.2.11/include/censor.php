<?PHP
  // to use this file add a line like this:
  // $profan[]="badword";
  $profan[]="fuck";
  $profan[]="shit";
  $profan[]="motherfucker";
  $profan[]="asshole";
  $profan[]="son of a bitch";
?>