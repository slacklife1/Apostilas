<?PHP
  // to use this file add a line like this:
  // $emails[]="bad@email.address";

  // You can disallow entire domains like hotmail:
  // $emails[]="hotmail.com";
  // would disallow anyone with a hotmail email address.

  // $emails[]="";
  
?>