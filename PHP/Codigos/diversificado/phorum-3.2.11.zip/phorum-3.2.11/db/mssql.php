<?PHP 
  include "./db/sybase.php";
?>