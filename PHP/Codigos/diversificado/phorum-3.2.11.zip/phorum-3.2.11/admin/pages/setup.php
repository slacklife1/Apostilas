<?PHP /* Phorum Setup */ ?>
<table border="1" cellspacing="0" cellpadding="3">
<tr>
<td align="center" valign="middle" bgcolor="#000080"><font face="Arial,Helvetica" color="#FFFFFF"><b>Phorum Setup</b></td>
</tr>
<tr>
<td align="left" valign="middle" bgcolor="#FFFFFF">
<font face="Arial,Helvetica">
<a href="<?PHP echo $myname; ?>?page=db">Database Settings</a><br>
<a href="<?PHP echo $myname; ?>?page=files">Files/Paths</a><br>
<a href="<?PHP echo $myname; ?>?page=html">HTML Settings</a><br>
<a href="<?PHP echo $myname; ?>?page=global">Global Options</a><br>
</td>
</tr>
</table>
