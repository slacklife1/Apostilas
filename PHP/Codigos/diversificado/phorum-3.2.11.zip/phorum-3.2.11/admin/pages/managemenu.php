<?PHP /* Forum/Folder Menu */ ?>
<script language="JavaScript" type="text/javascript">
  function dropforum(url, folder){
    if(folder){
      ans=window.confirm("You are about to drop this folder.  All sub folders and sub forums of this folder will be dropped also.  Do you want to continue?");
    }
    else{
      ans=window.confirm("You are about to drop this forum.  Do you want to continue?");
    }
    if(ans){
      window.location.replace(url);
    }
  }
</script>
<table cellspacing="0" cellpadding="3" border="1">
<tr>
    <td align="center" bgcolor="#000080"><font face="Arial,Helvetica" color="#FFFFFF"><?PHP echo $ForumName; ?></font></td>
</tr>
<?PHP
  if($ForumFolder==1){
    $uword="Folder";
    $lword="folder";
  }
  else{
    $uword="Forum";
    $lword="forum";
  }
?>
<tr>
<td bgcolor="#FFFFFF">
<font face="Arial,Helvetica">
<?PHP if($ForumFolder!="1"){ ?>
<a href="<?PHP echo $myname; ?>?page=easyadmin&num=<?PHP echo $num; ?>">Easy Admin</a><br>
<a href="<?PHP echo $myname; ?>?page=recentadmin&num=<?PHP echo $num; ?>">Recent Admin</a><br>
<a href="<?PHP echo $myname; ?>?page=quickedit&num=<?PHP echo $num; ?>">Quick Edit</a><br>
<a href="<?PHP echo $myname; ?>?page=quickdel&num=<?PHP echo $num; ?>">Quick Delete</a><br>
<a href="<?PHP echo $myname; ?>?page=quickapp&num=<?PHP echo $num; ?>">Quick Approve</a><br>
<a href="<?PHP echo $myname; ?>?page=datedel&num=<?PHP echo $num; ?>">Delete By Date</a><br>
<a href="<?PHP echo $myname; ?>?action=seq&page=managemenu&num=<?PHP echo $num; ?>">Reset Sequence</a><br>
<?PHP } ?>
<?PHP if($ForumActive){ ?>
<a href="<?PHP echo $myname; ?>?action=deactivate&page=managemenu&num=<?PHP echo $num; ?>">Hide</a><br>
<?PHP }else{ ?>
<a href="<?PHP echo $myname; ?>?action=activate&page=managemenu&num=<?PHP echo $num; ?>">Make Visible</a><br>
<?PHP } ?>
<a href="<?PHP echo $myname; ?>?page=props&num=<?PHP echo $num; ?>">Edit Properties</a><br>
<?PHP
if($loginnum==0) {
  if($ForumFolder!="1"){
?>
<a href="javascript:dropforum('<?PHP echo $myname; ?>?action=drop&page=main&num=<?PHP echo $num; ?>', 0);">Drop This <?PHP echo $uword; ?></a><br>
<?PHP
}else{
?>
<a href="javascript:dropforum('<?PHP echo $myname; ?>?action=drop&page=main&num=<?PHP echo $num; ?>', 1);">Drop This <?PHP echo $uword; ?></a><br>
<?PHP
  }
}
?>
</font>
</td>
</tr>
</table>
