<?PHP
// +----------------------------------------------------------------------+
// | PHP version 4.0                                                      |
// +----------------------------------------------------------------------+
// | Copyright (c) 1997, 1998, 1999, 2000, 2001,2002 The PHP Group        |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the PHP license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available at through the world-wide-web at                           |
// | http://www.php.net/license/2_02.txt.                                 |
// | If you did not receive a copy of the PHP license and are unable to   |
// | obtain it through the world-wide-web, please send a note to          |
// | license@php.net so we can mail you a copy immediately.               |
// +----------------------------------------------------------------------+
// | Authors: Original Author <admin@purplerain.org>                      |
// |          GPL:Eurosoft Ltd <eurosoft@xi-tec.com>                      |
// +----------------------------------------------------------------------+
// For best understanding my ideas and COM functionality please read my articles
//about COM  objects in:PHPweblog.org ,VisualBuilder.org, Developer.be 1PHPstreet.com
// if you have any questions feel free to contact me :admin@purplerain.org
// icq 113035194
// $ID EUBGRSMAL180601$


// starting word
$word = new COM("word.application") or die("Unable to instanciate Word");

// if you want see thw World interface the value must be '1' else '0'
$word->Visible = 1;

//doc file location
$word->Documents->Open("E:\\first.doc");


//html file location  '8' mean HTML format
$word->Documents[1]->SaveAs("E:\\test_doc.html",8);

//closing word
$word->Quit();


//free the object from the memory
$word->Release();
$word = null;
?>


