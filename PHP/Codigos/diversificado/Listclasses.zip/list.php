<HTML>
<HEAD>
<SCRIPT language=javascript src="lib/list.js" type=text/javascript></SCRIPT>
<STYLE TYPE="text/css">
<!--
SPAN.list {color: black; text-decoration: none}
// -->
</STYLE>
</HEAD>
<BODY ONLOAD="
LoadListImage(3, 'images/navyblue.gif', 'images/blue.gif', 11, 11)
LoadListImage(4, 'images/red.gif', 'images/transparent.gif', 11, 11)"
>
<?PHP
Require "lib/list.inc";
$lst = New mList;
// 1st example
Echo "<B>1st example - simple list without links and java script</B><BR>\n";
$lst->idList = 1;
$lst->ImageName = "images/yellow.gif";
$lst->arrayValue = Array("Blue", "Red", "White", "Green");
Echo $lst->Show();
// 2nd example
Echo "<B>2nd example - list with links (without java script)</B><BR>\n";
$lst->mList(); // reset previous settings
$lst->idList = 2;
$lst->ImageName = "images/green.gif";
$lst->arrayValue = Array("Blue", "Red", "White", "Green");
$lst->arrayHref = Array($PHP_SELF, $PHP_SELF, $PHP_SELF, $PHP_SELF);
Echo $lst->Show();
// 3th example
Echo "<B>3th example - list with links and java script (when you move your mouse pointer into link, image will change to dark blue color)</B><BR>\n";
$lst->mList(); // reset previous settings
$lst->idList = 3;
$lst->ImageName = "images/blue.gif";
$lst->onMouseOver = True;
$lst->onMouseOut = True;
$lst->arrayValue = Array("Blue", "Red", "White", "Green");
$lst->arrayHref = Array($PHP_SELF, $PHP_SELF, $PHP_SELF, $PHP_SELF);
Echo $lst->Show();
// 4th example
$lst->mList(); // reset previous settings
Echo "<B>4th example - list with links and java script (when you move your mouse pointer into link, you will see red arrow)";
$lst->idList = 4;
$lst->ImageName = "images/transparent.gif";
$lst->onMouseOver = True;
$lst->onMouseOut = True;
$lst->arrayValue = Array("Blue", "Red", "White", "Green");
$lst->arrayHref = Array($PHP_SELF, $PHP_SELF, $PHP_SELF, $PHP_SELF);
Echo $lst->Show();
?>
</BODY>
</HTML>
