<html>
<head>
<meta http-equiv="Content-Type"
content="text/html; charset=iso-8859-1">
<meta http-equiv="Expires" content="3000">
<meta name="keywords"
content="">
<meta name="description"
content="">
<title>Classifiedz</title>
<link rel="stylesheet" href="classifad.css">
<base target="_top">
</head>

<body topmargin="0" leftmargin="0">

<table width="100%" border="0" cellpadding="0" cellspacing="0" class="header"><tr><td width="5%"><br></td><td valign="top" width="74%">

<img src="logo.jpg" width="100%" height="70">

<table cellpadding="8" cellspacing="0" width="100%" class="butre"><tr><td><table cellpadding="0" cellspacing="0" width="100%" bgcolor="white"><tr><td><table cellpadding="4" cellspacing="0" width="100%" bgcolor="white"><tr><td>