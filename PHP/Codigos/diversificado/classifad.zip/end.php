</td></tr></table></td></tr></table></td></tr></table>

</td>
<td class="purple" valign="top" align="center" width="20%"><u>SECTIONS</u><br>
<p><a href="index.php?cat=personal">Personal</a></p>
<p><a href="index.php?cat=Business">Business</a></p>
<p><a href="index.php?cat=For Sale">For Sale</a></p>
<p><a href="index.php?cat=Wanted">Wanted</a></p>
<p><a href="index.php?cat=Employment">Employment</a></p>
<p><a href="index.php?cat=Holidays and Travel">Holidays and Travel</a></p>
<p><a href="index.php?cat=Property">Property</a></p>
<p><a href="index.php?cat=General">General</a></p>
</td>

</tr></table>      

</body>
</html>