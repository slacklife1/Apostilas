
<?php 
error_reporting(0);
require("config.php");

mysql_connect("$dbHOST", "$dbUSER", "$dbPASSWORD");
mysql_select_db("$dbNAME"); 

include("top.php");
?>
<center><select onChange="window.open(this.options[this.selectedIndex].value,'_top'); " name="cat"><option value="">View Categories</option>
<? printcat($categs); ?>
</select></center>

<? 
$time = time();
$expires = $time + (3600 * 24 * 7 * $weeks);

function serverr($explan) { 
echo "<p>$explan</p>"; 
require("end.php");
die(); }

function check($title,$description) {
$check = array();
if(empty($title)) { $check[0] = "<li>title</li>"; }
if(empty($description)) { $check[1] = "<li>description</li>"; }
if(is_array($check)) { $check = implode(" ", $check); }
if(empty($title) || empty($description)) { serverr("Please go back and enter a: <ul>$check</ul>"); } }

if(isset($modify)) {
check($title,$description);
if($url == "") { $url = "no site"; }
if($email ==  "") { $email = "no email"; }

mysql_query("update classifad set poster = '$poster', title = '$title', description = '$description', url = '$url', email = '$email', expires = '$expires', category = '$category' where(adv_id = $id)") or serverr("The database is overloaded, please keep this window alive and resend in a few minutes.");

echo "<p>You updated the following in the $category Section:</p>
<blockquote><b>$title</b> - $poster<br> $description<br> $url, $email</blockquote><br>It will expire in $weeks weeks.";
}


elseif(isset($delete)) {
mysql_query("delete from classifad where adv_id = '$id'") or serverr("The database is overloaded, or some other problem and we failed to delete your entry");
echo "<br>Your ad has been deleted"; }


elseif(isset($newadd)) {
check($title,$description);
if($url == "") { $url = "no site"; }
if($email ==  "") { $email = "no email"; }

mysql_query("insert into classifad values(' ', '$poster', '$title', '$description', '$url', '$email', '$time', '$expires', '$remote_ip', '$category')") or serverr("The database is overloaded, please keep this window alive and resend in a few minutes."); 

mysql_query("delete low_priority from classifad where(expires < '$time')");

echo "<p>You posted the following in the $category Section:</p>
<blockquote><b>$title</b> - $poster<br> $description<br> $url, $email</blockquote>It expires in $weeks weeks.";
}

elseif(isset($alterf)) {

echo "<h3 class=\"butre\">Alter it</h3><form action=\"updata.php\" method=\"post\">
<center><table border=\"0\"><tr><td>Name:</td><td><input type=\"text\" name=\"poster\" size=\"35\" value=\"" . "$nm" . "\"></td></tr>
<tr><td><font color=\"red\">Title:</font></td><td><input type=\"text\" name=\"title\" size=\"35\" value=\"$ti\"></td></tr>
<tr><td><font color=\"red\">Description:</font></td><td><textarea rows=\"4\" cols=\"35\" name=\"description\">$de</textarea></td></tr>
<tr><td>Email:</td><td><input type=\"text\" name=\"email\" size=\"35\" value=\"$em\"></td></tr>
<tr><td>Web Site:</td><td><input type=\"text\" name=\"url\" size=\"35\" value=\"$ur\"></td></tr>
<tr><td><font color=\"red\">Category:</font></td><td><select name=\"category\">";

catselect($categs);

echo "</select></td></tr>
<tr><td><font color=\"red\">#Weeks to Display:</font></td><td><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr><td><select name=\"weeks\">
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
</select></td><td align=\"right\"><input type=\"hidden\" name=\"remote_ip\" value=\"$ip\"><input type=\"hidden\" name=\"id\" value=\"$id\">
<input type=\"submit\" name=\"modify\" value=\"Alter It\"></td></tr></table></td></tr></table>
</center>
</form>";
 } 


include("end.php"); ?>


