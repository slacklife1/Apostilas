<?php 

error_reporting(0);
require("config.php");

mysql_connect("$dbHOST", "$dbUSER", "$dbPASSWORD");
mysql_select_db("$dbNAME"); 

include("top.php");

$rip = getenv('REMOTE_ADDR');
$time = time();
$newtime = $time - 3600 * 24 * $newdays;

?>
<center><select onChange="javascript:window.open(this.options[this.selectedIndex].value, '_top')";list.options[0].selected=true" name="cat">
<option value="">View Categories</option>
<? printcat($categs); ?>

</select><a href="#post"> Post your ad here.</a></center>


<?
if(isset($cat)) {
echo "<h2 class=\"hedder\">$cat Section</h2>";
$query = mysql_query("select posted_time from classifad where (category = '$cat') and (expires > '$time')"); }

else{
echo "<h2 class=\"hedder\">New Listings</h2>"; 
$query = mysql_query("select posted_time from classifad where (expires > '$time') and (posted_time > '$newtime')"); }

$i = "0";
while($ad = mysql_fetch_assoc($query)) {

$i++;
$posti[$i] = $ad['posted_time']; }

function cmp ($a, $b) {   
    if ($a == $b) { return "0"; }
    elseif($a > $b) { return "1"; }
else{ return "-1"; } }


usort ($posti, "cmp");
$posti = array_reverse($posti);

foreach($posti as $v) { 
$query = mysql_query("select adv_id, poster, title, description, url, email, remote_ip from classifad where posted_time = '$v'");

$row = mysql_fetch_array($query);

echo "<p><blockquote><b>$row[title]</b> - $row[poster]<br>$row[description]<br>";
if($row[email] != 'no email') {
echo "<a href=\"mailto:$row[email]\">Email </a>"; }
if($row[url] != "no site") {
echo " - <a href=\"$row[url]\">Site</a>"; }

if($rip == $row[remote_ip]) { echo "<table border=0><tr><td><form action=\"updata.php\" method=\"post\"><input type=\"hidden\" name=\"id\" value=\"$row[adv_id]\"><input type=\"hidden\" name=\"nm\" value=\"$row[poster]\"><input type=\"hidden\" name=\"ti\" value=\"$row[title]\"><input type=\"hidden\" name=\"de\" value=\"$row[description]\"><input type=\"hidden\" name=\"ur\" value=\"$row[url]\"><input type=\"hidden\" name=\"em\" value=\"$row[email]\"><input type=\"hidden\" name=\"ip\" value=\"$row[remote_ip]\"> -- <input type=\"submit\" name=\"alterf\" value=\"Alter it \"> --</form></td><td><form action=\"updata.php\" method=\"post\"><input type=\"hidden\" name=\"id\" value=\"$row[adv_id]\"> -- <input type=\"submit\" name=\"delete\" value=\"Delete it\"> --</form></td></tr></table>"; }

echo "</blockquote></p>";

} ?>
<a name="post"></a>
<h3 class="hedder">Submit an Ad:</h3>
<center><form action="updata.php" method="post">
<table border="0"><tr><td>Name:</td><td><input type="text" name="poster" size="35"></td></tr>
<tr><td><font color="red">Title:</font></td><td><input type="text" name="title" size="35"></td></tr>
<tr><td><font color="red">Description:</font></td><td><textarea rows="4" cols="35" name="description"></textarea></td></tr>
<tr><td>Email:</td><td><input type="text" name="email" size="35"></td></tr>
<tr><td>Web Site:</td><td><input type="text" name="url" size="35"></td></tr>
<tr><td><font color="red">Category:</font></td><td><select name="category">

<? catselect($categs); ?>

</select></td></tr>
<tr><td><font color="red">#Weeks to Display:</font></td><td><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td><select name="weeks">
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
</select></td><td align="right"><input type="hidden" name="remote_ip" value="<? echo "$rip" ?>">
<input type="submit" name="newadd" value="Submit"> </td></tr></table> </td></tr></table>
</center>
</form>     

<? require("end.php");
?>

</body>
</html>

