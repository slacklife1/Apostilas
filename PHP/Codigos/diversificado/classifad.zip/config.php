
<?php 

// MySQL database info:

$dbHOST="localhost";   // "localhost" should be what you want.
$dbUSER="meagain";
$dbPASSWORD="xxxxxx";
$dbNAME="database";



// number of days an ad is New:

$newdays="7";



// your categories:

$categs = array("Personal", "Business", "For Sale", "Wanted", "Employment", "Holidays and Travel", "Property", "General", "add", "some", "more", "or", "change", "them");




// Do not alter below this line

function printcat($categs) {
foreach ($categs as $v) { echo "<option value=\"index.php?cat=$v\">$v</option>"; } }

function catselect($categs) {
foreach ($categs as $v) { echo "<option>$v</option>"; } }

?>