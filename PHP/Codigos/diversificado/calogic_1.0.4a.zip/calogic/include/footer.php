<?php
// Please do not remove this information
// I worked a lot of long hard hours on this program
// give credit where credit is due.
echo "<center>";
echo "<table border=\"0\" width=\"50%\">\n";
echo "<tr>\n";
echo "<td width=\"33%\" align=\"center\">";
echo "<A class=\"gcprevlink\" target=\"_blank\" href=\"http://sourceforge.net \">
<IMG src=\"./img/sf_logo.bmp\" width=\"125\" height=\"37\" border=\"0\" alt=\"SourceForge Logo\"></A>";
echo "<td width=\"33%\" align=\"center\" nowrap>
<a title=\"Visit the Home of CaLogic!\" target=\"_blank\" class=\"gcprevlink\" href=\"http://www.calogic.de \">
<font size=\"-1\">CaLogic Calendars V1.0.4a</font></a><br>
<a title=\"EMail the author!\" target=\"_blank\" class=\"gcprevlink\" href=\"mailto:philip@calogic.de\">
<font size=\"-1\">&#xA9; Philip Boone</font></a></td>\n";
echo "<td width=\"34%\" align=\"center\">
<a target=\"_blank\" class=\"gcprevlink\" href=\"http://www.mysql.com \">
<img border=\"1\" width=\"125\" height=\"37\" src=\"./img/mysql_logo.png\" alt=\"MySQL Logo\"></a></td>\n";
echo "</tr>\n";
echo "</table>\n";
echo "<a target=\"_blank\" class=\"gcprevlink\" href=\"http://www.php.net \">
<img border=\"1\" src=\"./img/php_logo2.gif\" alt=\"PHP Logo\"></a></td>\n";
echo "</center></body>\n";
echo "</html>\n";
?>    