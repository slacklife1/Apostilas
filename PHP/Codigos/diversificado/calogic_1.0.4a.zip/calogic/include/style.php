<STYLE type="text/css">
<!--

.newlink {
  color: ;
  background-color: ;
  text-decoration: none;
  cursor: hand;
}

.gcprevlink {
  color: <?php echo $curcalcfg["gcprevcolor"]; ?>;
  background-color: <?php echo $curcalcfg["gcprevbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["gcprevstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
}

.gcprevfont {
  color: <?php echo $curcalcfg["gcprevcolor"]; ?>;
  background-color: <?php echo $curcalcfg["gcprevbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["gcprevstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
  
}

.gcnextlink {
  color: <?php echo $curcalcfg["gcnextcolor"]; ?>;
  background-color: <?php echo $curcalcfg["gcnextbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["gcnextstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
}

.gcpreflink {
  color: <?php echo $curcalcfg["gcprefcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["gcprefstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
}

.gccssc {
  background-color: <?php echo $curcalcfg["gccssc"]; ?>;
}

.mcdivider {
  background-color: <?php echo $curcalcfg["mcdividerlinecolor"]; ?>;
}

.mcmlink {
  color: <?php echo $curcalcfg["mcttcolor"]; ?>;
  background-color: <?php echo $curcalcfg["mcttbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["mcttstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
  FONT-WEIGHT: bold;
}

.mcmcell {
  background-color: <?php echo $curcalcfg["mcttcellcolor"]; ?>;
}

.mchwd {
  color: <?php echo $curcalcfg["mcheaderwdcolor"]; ?>;
  font-size: 9pt;
}

.mchwdcell {
  background-color: <?php echo $curcalcfg["mcheaderwdbgcolor"]; ?>;
}

.mchwe {
  color: <?php echo $curcalcfg["mcheaderwecolor"]; ?>;
  font-size: 9pt;
}

.mchwecell {
  background-color: <?php echo $curcalcfg["mcheaderwebgcolor"]; ?>;
}

.mcwdlink {
  color: <?php echo $curcalcfg["mcwdcolor"]; ?>;
  background-color: <?php echo $curcalcfg["mcwdbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["mcwdstyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.mcwdcell {
  background-color: <?php echo $curcalcfg["mcwdcellcolor"]; ?>;
}

.mcwelink {
  color: <?php echo $curcalcfg["mcwecolor"]; ?>;
  background-color: <?php echo $curcalcfg["mcwebgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["mcwestyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.mcwecell {
  background-color: <?php echo $curcalcfg["mcwecellcolor"]; ?>;
}

.mccdlink {
  color: <?php echo $curcalcfg["mccdcolor"]; ?>;
  background-color: <?php echo $curcalcfg["mccdbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["mccdstyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.mccdcell {
  background-color: <?php echo $curcalcfg["mccdcellcolor"]; ?>;
}

.mcnclink {
  color: <?php echo $curcalcfg["mcnccolor"]; ?>;
  background-color: <?php echo $curcalcfg["mcncbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["mcncstyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.mcnccell {
  background-color: <?php echo $curcalcfg["mcnccellcolor"]; ?>;
}

.mcdwecell {
  background-color: <?php echo $curcalcfg["mcdwecellcolor"]; ?>;
}

.mcwdwelink {
  background-color: <?php echo $curcalcfg["mcdwecellcolor"]; ?>;
  color: <?php echo $curcalcfg["mcwdcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["mcwdstyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.mcwewelink {
  background-color: <?php echo $curcalcfg["mcdwecellcolor"]; ?>;
  color: <?php echo $curcalcfg["mcwecolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["mcwestyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.mcncdwelink {
  background-color: <?php echo $curcalcfg["mcdwecellcolor"]; ?>;
  color: <?php echo $curcalcfg["mcnccolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["mcncstyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.yvdivider {
  background-color: <?php echo $curcalcfg["yvdividerlinecolor"]; ?>;
}

.yvhead {
  color: <?php echo $curcalcfg["yvheadercolor"]; ?>;
}

.yvmlink {
  color: <?php echo $curcalcfg["yvttcolor"]; ?>;
  background-color: <?php echo $curcalcfg["yvttbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["yvttstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.yvmcell {
  background-color: <?php echo $curcalcfg["yvttcellcolor"]; ?>;
}

.yvhwd {
  color: <?php echo $curcalcfg["yvheaderwdcolor"]; ?>;
  font-size: 9pt;
}

.yvhwdcell {
  background-color: <?php echo $curcalcfg["yvheaderwdbgcolor"]; ?>;
}

.yvhwe {
  color: <?php echo $curcalcfg["yvheaderwecolor"]; ?>;
  font-size: 9pt;
}

.yvhwecell {
  background-color: <?php echo $curcalcfg["yvheaderwebgcolor"]; ?>;
}

.yvwdlink {
  color: <?php echo $curcalcfg["yvwdcolor"]; ?>;
  background-color: <?php echo $curcalcfg["yvwdbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["yvwdstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.yvwdcell {
  background-color: <?php echo $curcalcfg["yvwdcellcolor"]; ?>;
}

.yvwelink {
  color: <?php echo $curcalcfg["yvwecolor"]; ?>;
  background-color: <?php echo $curcalcfg["yvwebgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["yvwestyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.yvwecell {
  background-color: <?php echo $curcalcfg["yvwecellcolor"]; ?>;
}

.yvcdlink {
  color: <?php echo $curcalcfg["yvcdcolor"]; ?>;
  background-color: <?php echo $curcalcfg["yvcdbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["yvcdstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.yvcdcell {
  background-color: <?php echo $curcalcfg["yvcdcellcolor"]; ?>;
}

.yvnccell {
  background-color: <?php echo $curcalcfg["yvnccellcolor"]; ?>;
}

.yvdwecell {
  background-color: <?php echo $curcalcfg["yvdwecellcolor"]; ?>;
}

.yvwdwelink {
  color: <?php echo $curcalcfg["yvwdcolor"]; ?>;
  background-color: <?php echo $curcalcfg["yvdwecellcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["yvwdstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.yvwewelink {
  color: <?php echo $curcalcfg["yvwecolor"]; ?>;
  background-color: <?php echo $curcalcfg["yvdwecellcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["yvwestyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.mvdivider {
  background-color: <?php echo $curcalcfg["mvdividerlinecolor"]; ?>;
}

.mvhead {
  color: <?php echo $curcalcfg["mvheadercolor"]; ?>;
}

.mvhwd {
  color: <?php echo $curcalcfg["mvheaderwdcolor"]; ?>;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.mvhwdcell {
  background-color: <?php echo $curcalcfg["mvheaderwdbgcolor"]; ?>;
}

.mvhwe {
  color: <?php echo $curcalcfg["mvheaderwecolor"]; ?>;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.mvhwecell {
  background-color: <?php echo $curcalcfg["mvheaderwebgcolor"]; ?>;
}

.mvwdlink {
  color: <?php echo $curcalcfg["mvwdcolor"]; ?>;
  background-color: <?php echo $curcalcfg["mvwdbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["mvwdstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.mvwdcell {
  background-color: <?php echo $curcalcfg["mvwdcellcolor"]; ?>;
  OVERFLOW: auto;
}

.mvwelink {
  color: <?php echo $curcalcfg["mvwecolor"]; ?>;
  background-color: <?php echo $curcalcfg["mvwebgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["mvwestyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.mvwecell {
  background-color: <?php echo $curcalcfg["mvwecellcolor"]; ?>;
  OVERFLOW: auto;
}

.mvcdlink {
  color: <?php echo $curcalcfg["mvcdcolor"]; ?>;
  background-color: <?php echo $curcalcfg["mvcdbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["mvcdstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.mvcdcell {
  background-color: <?php echo $curcalcfg["mvcdcellcolor"]; ?>;
  OVERFLOW: auto;
}

.mvnclink {
  color: <?php echo $curcalcfg["mvnccolor"]; ?>;
  background-color: <?php echo $curcalcfg["mvncbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["mvncstyle"]; ?>;
  cursor: hand;
  font-size: 9pt;
}

.mvnccell {
  background-color: <?php echo $curcalcfg["mvnccellcolor"]; ?>;
  OVERFLOW: auto;
}

.mvkwlink {
  color: <?php echo $curcalcfg["mvwlcolor"]; ?>;
  background-color: <?php echo $curcalcfg["mvwlbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["mvwlstyle"]; ?>;
  cursor: hand;
  font-size: 7pt;
}

.wvdivider {
  background-color: <?php echo $curcalcfg["wvdividerlinecolor"]; ?>;
}

.wvhead {
  color: <?php echo $curcalcfg["wvheadercolor"]; ?>;
}

.wvhwdlink {
  color: <?php echo $curcalcfg["wvheaderwdcolor"]; ?>;
  background-color: <?php echo $curcalcfg["wvheaderwdbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["wvheaderwdstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.wvhwdcell {
  background-color: <?php echo $curcalcfg["wvheaderwdcellcolor"]; ?>;
}

.wvhwelink {
  color: <?php echo $curcalcfg["wvheaderwecolor"]; ?>;
  background-color: <?php echo $curcalcfg["wvheaderwebgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["wvheaderwestyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.wvhwecell {
  background-color: <?php echo $curcalcfg["wvheaderwecellcolor"]; ?>;
}

.wvhcdlink {
  color: <?php echo $curcalcfg["wvheadercdcolor"]; ?>;
  background-color: <?php echo $curcalcfg["wvheadercdbgcolor"]; ?>;
  text-decoration: <?php echo $curcalcfg["wvheadercdstyle"]; ?>;
  cursor: hand;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.wvhcdcell {
  background-color: <?php echo $curcalcfg["wvheadercdcellcolor"]; ?>;
}

.wvhadtext {
  color: <?php echo $curcalcfg["wvheaderadcolor"]; ?>;
  background-color: <?php echo $curcalcfg["wvheaderadbgcolor"]; ?>;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.wvhadcell {
  background-color: <?php echo $curcalcfg["wvheaderadcellcolor"]; ?>;
}

.wvawdcell {
  background-color: <?php echo $curcalcfg["wvawdcellcolor"]; ?>;
}

.wvawecell {
  background-color: <?php echo $curcalcfg["wvawecellcolor"]; ?>;
}

.wvacdcell {
  background-color: <?php echo $curcalcfg["wvacdcellcolor"]; ?>;
}

.wvwdcell {
  background-color: <?php echo $curcalcfg["wvwdcellcolor"]; ?>;
}

.wvwecell {
  background-color: <?php echo $curcalcfg["wvwecellcolor"]; ?>;
}

.wvcdcell {
  background-color: <?php echo $curcalcfg["wvcdcellcolor"]; ?>;
}

.wvtctext {
  color: <?php echo $curcalcfg["wvtccolor"]; ?>;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.wvtccell {
  background-color: <?php echo $curcalcfg["wvtccellcolor"]; ?>;
}

.dvdivider {
  background-color: <?php echo $curcalcfg["dvdividerlinecolor"]; ?>;
}

.dvhead {
  color: <?php echo $curcalcfg["dvheadercolor"]; ?>;
}

.dvadtext {
  color: <?php echo $curcalcfg["dvadcolor"]; ?>;
  background-color: <?php echo $curcalcfg["dvadbgcolor"]; ?>;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.dvadcell {
  background-color: <?php echo $curcalcfg["dvadcellcolor"]; ?>;
}

.dvawdcell {
  background-color: <?php echo $curcalcfg["dvawdcellcolor"]; ?>;
}

.dvawecell {
  background-color: <?php echo $curcalcfg["dvawecellcolor"]; ?>;
}

.dvacdcell {
  background-color: <?php echo $curcalcfg["dvacdcellcolor"]; ?>;
}

.dvwdcell {
  background-color: <?php echo $curcalcfg["dvwdcellcolor"]; ?>;
}

.dvwecell {
  background-color: <?php echo $curcalcfg["dvwecellcolor"]; ?>;
}

.dvcdcell {
  background-color: <?php echo $curcalcfg["dvcdcellcolor"]; ?>;
}

.dvtctext {
  color: <?php echo $curcalcfg["dvtccolor"]; ?>;
  font-size: 11pt;
  FONT-WEIGHT: bold;
}

.dvtccell {
  background-color: <?php echo $curcalcfg["dvtccellcolor"]; ?>;
}

-->
</STYLE>
