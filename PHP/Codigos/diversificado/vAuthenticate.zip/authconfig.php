<?
/*
# File: authconfig.php
# Script Name: vAuthenticate 2.0
# Author: Vincent Ryan Ong
# Email: support@beanbug.net
#
# Description:
# vAuthenticate is a revolutionary authentication script which uses
# PHP and MySQL for lightning fast processing. vAuthenticate comes 
# with an admin interface where webmasters and administrators can
# create new user accounts, new user groups, activate/inactivate 
# groups or individual accounts, set user level, etc. This may be
# used to protect files for member-only areas. vAuthenticate 
# uses a custom class to handle the bulk of insertion, updates, and
# deletion of data. This class can also be used for other applications
# which needs user authentication.
#
# This script is a freeware but if you want to give donations,
# please send your checks (coz cash will probably be stolen in the
# post office) them to:
#
# Vincent Ryan Ong
# Rm. 440 Wellington Bldg.
# 655 Condesa St. Binondo, Manila
# Philippines, 1006
*/
?>

<?

$resultpage = "vAuthenticate.php";	// THIS IS THE PAGE THAT WOULD CHECK FOR AUTHENTICITY

$admin = "admin/index.php";	// THIS IS THE PATH TO THE ADMIN INTERFACE
$success = "success.php";	// THIS IS THE PAGE TO BE SHOWN IF USER IS AUTHENTICATED
$inactive = "inactive.php";	// THIS IS THE PAGE TO BE SHOWN IF USER'S STATUS IS SET TO INACTIVE
$failure = "failed.php";	// THIS IS THE PAGE TO BE SHOWN IF USERNAME-PASSWORD COMBINATION DOES NOT MATCH
						
// DB SETTINGS
$dbhost = "localhost";	// DB Host name
$dbusername = "root"; 	// DB User
$dbpass = "";	// DB User password
$dbname	= "TestDB1"; 	// DB Name

?>