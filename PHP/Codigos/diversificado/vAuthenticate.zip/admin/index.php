<?
/*
# File: admin/index.php
# Script Name: vAuthenticate 2.0
# Author: Vincent Ryan Ong
# Email: support@beanbug.net
#
# Description:
# vAuthenticate is a revolutionary authentication script which uses
# PHP and MySQL for lightning fast processing. vAuthenticate comes 
# with an admin interface where webmasters and administrators can
# create new user accounts, new user groups, activate/inactivate 
# groups or individual accounts, set user level, etc. This may be
# used to protect files for member-only areas. vAuthenticate 
# uses a custom class to handle the bulk of insertion, updates, and
# deletion of data. This class can also be used for other applications
# which needs user authentication.
#
# This script is a freeware but if you want to give donations,
# please send your checks (coz cash will probably be stolen in the
# post office) them to:
#
# Vincent Ryan Ong
# Rm. 440 Wellington Bldg.
# 655 Condesa St. Binondo, Manila
# Philippines, 1006
*/
?>

<html>
<head>
<title>vAuthenticate Administrative Interface</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<p><font face="Arial, Helvetica, sans-serif" size="5"><b>vAuthenticate Administration</b></font></p>
<table width="50%" border="1" cellspacing="0" cellpadding="0" bordercolor="#000000">
  <tr> 
    <td width="50%" bgcolor="#0099CC" height="16"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFCC">Administer</font></b></td>
    <td width="25%" bgcolor="#FFFFCC" height="16"> 
      <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="admin/authuser.php">Users</a></font></div>
    </td>
    <td width="25%" bgcolor="#FFFFCC" height="16"> 
      <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="admin/authgroup.php">Groups</a></font></div>
    </td>
  </tr>
</table>
<table width="70%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td valign="middle">
      <p>&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td valign="middle"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Welcome 
      to the administration panel of vAuthenticate! Please click on any of the 
      two (2) administrative functions above. Below is a description of each function:</font> 
      <p><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Users</b> 
        - Allows you to add, modify, activate/inactivate, delete, and group users.</font></p>
      <p><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Groups</b> 
        - Allows you to create, modify, activate/inactivate, and delete groups.</font></p>
    </td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
