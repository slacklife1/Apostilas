<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link href="phpcounter.css" rel="stylesheet">
<title>PHPCounter Version 4.1 - Records Index</title>
</head>
<body>
<p>Welcome to PHPCounter 4.1 Output. To view stats for a page, click on its link. The template.html and index.php files
are pages to make ths script run and are not statistics pages!</p>
<?php
/*INSTALLATION: EDIT BELOW*/
$basedir = "/users/pdf24/public_html/counters/";  // Base directory

function GetFileSizeProperly($filename){
$j = 0;
$ext = array("B","KB","MB","GB","TB");
$file_size = filesize($filename);
while ($file_size >= pow(1024,$j)) ++$j;
$file_size = round($file_size / pow(1024,$j-1) * 100) / 100 . $ext[$j-1];
return $file_size;
}


function listall($dir)
{
    // Initialize temporary arrays for sorting
    $dir_files = $dir_subdirs = array();


    // Print current directory and other data
    print("<p>Data stored in: <i>$dir</i><br>\n");
    echo "Current server date and time:". strftime("%d %b %Y %H:%M")."</p><hr>";
    print("<table>");

    // Change to directory
    chdir($dir);

    // Open directory;
    $handle = @opendir($dir) or die("Directory \"$dir\"not found.");

    // Loop through all directory entries, construct
    // two temporary arrays containing files and sub directories
    while($entry = readdir($handle))
    {
        if(is_dir($entry) && $entry != ".." && $entry != ".")
        {
            $dir_subdirs[] = $entry;
        }
        elseif($entry != ".." && $entry != ".")
        {
            $dir_files[] = $entry;
        }
    }

    // Sort files and sub directories
    sort($dir_files);
    sort($dir_subdirs);

    // Print all files in the curent directory
    for($i=0; $i<count($dir_files); $i++)
    {
        echo "<tr><td class=\"indexlist\"><a href=\"$dir_files[$i]\">$dir_files[$i]</a>&nbsp;</td><td class=\"indexlist\">" . GetFileSizeProperly($dir_files[$i]) ."</td></tr>\n";
    }

    // Traverse sub directories
    for($i=0; $i<count($dir_subdirs); $i++)
    {
        listall("$dir$dir_subdirs[$i]/");
    }
    print("</table>");

    // Close directory
    closedir($handle);
}

listall($basedir);
?>
<hr>
<p>PHPCounter 4.1. &copy;2002 <a href="mailto:scripts@ekstrememail.cjb.net">Pierre Far</a>. This script is provided as is without any warrantees. This script is free
for personal and non-commercial use. You may distribute this script as long as the copyright messages (this message
and the message inside the script) are left intact. If you need help, see the readme file, which also contains contact
information. Thank you!</p>
</body>
</html>
