<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link href="phpcounter.css" rel="stylesheet">
<title>PHPCounter Version 4.1</title>
</head>
<body>
<a href="index.php">Return to the Index</a><br>
<h1>Hits Report</h1>
<?php
$CountingFor = getenv("SCRIPT_NAME");
$CountingFor = substr($CountingFor, 18); //18 = strlen("/counters/counter_"), which is the directory that the records are stored in.
$CountingFor = preg_replace("/_/", ".", $CountingFor);
$StrAt = strstr($CountingFor, ".php");
$CountingFor = substr($CountingFor, 0, (strlen($CountingFor)-$StrAt));
echo "<p>Counting for: <i>" . $CountingFor . "</i></p>";
?>
<p>Total number of hits for this page: 0 hits.</p>
<hr>
<table width="100%" cellspacing="0" cellpadding="3" border="0" class="recordtbl">
<tr><td class="tblHeading">Page</td><td class="tblHeading">HTTP Referer</td><td class="tblHeading">User Agent</td><td class="tblHeading">Remote Site</td><td class="tblHeading">Date &amp; Time</td></tr>
<!--InsertCounterDataHere-->
</table>
</body>
</html>
