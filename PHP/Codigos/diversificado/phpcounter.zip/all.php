<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link href="phpcounter.css" rel="stylesheet">
<title>PHPCounter Version 4.1</title>
</head>
<body>
<a href="index.php">Return to the Index</a><hr>
<h1>All Hit Counted by PHPCounter 4.1</h1>
<p>Total Number of Hits: 0 hits.</p>
<hr>
<table width="100%" cellspacing="0" cellpadding="3" border="0" class="recordtbl">
<tr><td class="tblHeading">Page</td><td class="tblHeading">HTTP Referer</td><td class="tblHeading">User Agent</td><td class="tblHeading">Remote Site</td><td class="tblHeading">Date &amp; Time</td></tr>
<!--InsertCounterDataHere-->
</table>
</body>
</html>
