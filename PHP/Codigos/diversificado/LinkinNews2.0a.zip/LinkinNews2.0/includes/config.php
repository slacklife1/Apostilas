<?
###########################################
#       Sistema Criado e Desenvolvido     #
#          Igor Carvalho de Escobar       #
#                LK Design�               #
#  http://igorescobar.webtutoriais.com.br #
#      Suporte em:                        #
#      http://forum.webtutoriais.com.br   #
#      Por favor, Mantenham os Cr�ditos   #
###########################################
?>
<?
#- Coloque abaixo os seus dados de conexao com o Banco de dados -#

$host_db      = "localhost";
$usuario_db   = "MeuUsuario"; // Usuario de conexao com o banco de dados
$senha_db     = "Minhasenha"; // Senha de conexao com o banco de dados
$BancoDeDados = "MeuBanco";  // DB no qual deseja instalar o sistema

#----------------------------------------------------#
?>
