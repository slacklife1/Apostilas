<?
###########################################
#       Sistema Criado e Desenvolvido     #
#          Igor Carvalho de Escobar       #
#                LK Design�               #
#  http://igorescobar.webtutoriais.com.br #
#      Suporte em:                        #
#      http://forum.webtutoriais.com.br   #
#      Por favor, Mantenham os Cr�ditos   #
###########################################
?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="css/login.css" rel="stylesheet" type="text/css">
<link href="css/css.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center"><br>
  <img src="images/top_logo.gif" width="200" height="50"><br>
</div>
<form name="form1" method="post" action="loga.php">
  <table width="167" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr bgcolor="#F4F4F4"> 
      <td colspan="2"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Tela de login</strong></font></td>
    </tr>
    <tr> 
      <td width="47"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Login: 
        </font></td>
      <td width="120"> 
        <input name="login" type="text" class="botoes" id="login"></td>
    </tr>
    <tr> 
      <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Senha:</font></td>
      <td><input name="senha" type="password" class="botoes" id="senha"></td>
    </tr>
    <tr> 
      <td colspan="2" bgcolor="#FCFCFC"><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp; 
          <input name="Submit" type="submit" class="botoes" value="Logar">
          </font></div></td>
    </tr>
  </table>
</form>
</body>
</html>
