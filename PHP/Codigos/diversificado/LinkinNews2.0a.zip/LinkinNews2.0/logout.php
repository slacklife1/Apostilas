<?
###########################################
#       Sistema Criado e Desenvolvido     #
#          Igor Carvalho de Escobar       #
#                LK Design�               #
#  http://igorescobar.webtutoriais.com.br #
#      Suporte em:                        #
#      http://forum.webtutoriais.com.br   #
#      Por favor, Mantenham os Cr�ditos   #
###########################################
?>
<?

setcookie("usuario");
setcookie("senha");
echo "<meta http-equiv='refresh' content='0;URL=login.php'>";

?>
