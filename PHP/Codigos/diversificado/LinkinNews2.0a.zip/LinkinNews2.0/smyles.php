<?
###########################################
#       Sistema Criado e Desenvolvido     #
#          Igor Carvalho de Escobar       #
#                LK Design�               #
#  http://igorescobar.webtutoriais.com.br #
#      Suporte em:                        #
#      http://forum.webtutoriais.com.br   #
#      Por favor, Mantenham os Cr�ditos   #
###########################################
?>
<? include "valida_login.php"; ?>
<html>
<head>
<title>LinkinNews 2.0 [ Comentarios] </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="css/css.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><img src="images/top_logo.gif" width="200" height="50"></td>
  </tr>
  <tr>
    <td height="10%" bgcolor="#D64B10"></td>
  </tr>
</table>
<div align="center">
  <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Para adicionar 
    smyles ao sistema, Ap&eacute;nas jogue(copie) o arquivo correspondente ao 
    smyles (ex: smyles.gif) dentro da pasta 'Smyles' do sistema LinkinNews2.0 
    e pronto, O Smyles aparece dinamicamente ao seu formul&aacute;rio de postagem 
    de noticia pronto para o uso.</font></p>
  <p><a href="javascript:window.close();"><img src="images/bt_close_window.gif" width="100" height="15" border="0"></a> 
  </p>
</div>
</body>
</html>
