Title: PHP Image Gallery
Description: This is simply a script to dynamically build thumbnail image gallerys. The thumbs can be opened in either a new window or the same browser. There is also a simple CSS Class for defining the font and size. "Next", "Back" links are added, along with page numbers. 
All that needs to be done is to edit the variables $thumbDir and $imageDir to point towards your respective directories. At this time, the large images and thumbnail images MUST BE NAMED THE SAME.
After configuring the script, just upload it to your server, along with the images. That's it. 

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=492&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
