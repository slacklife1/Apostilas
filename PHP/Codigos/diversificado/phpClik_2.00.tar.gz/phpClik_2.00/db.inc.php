<?
$dbhost = "localhost";      //dein datenbank server, hostname oder ip

$dbuser = "login";           //dein login

$dbpasswd = "password";             //dein passwort

$db = "deinedb";            //datenbank in der sich die tabelle phpClik befindet

$table = "clik";            //tabelle f�r die daten
?>