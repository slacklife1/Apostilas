<?
function HEAD(){
	include('config.php');
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$s=$_SERVER["REMOTE_ADDR"];
	$ipbancheck="SELECT * from $banprefix where ipaddress='$s'"; 
	if(mysql_num_rows(mysql_query($ipbancheck)) > 0) { 
	print "</head><body>You are not allowed to view this site.</body></html>"; exit(); }
?>
	<!-- BEGIN HEAD -->
	<script language="JavaScript" type="text/JavaScript">
	<!--
	function MM_jumpMenu(targ,selObj,restore){ //v3.0
	  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
	  if (restore) selObj.selectedIndex=0;
	}
	//-->
	</script>
	<!-- END HEAD -->
<?
}
	function NEWSGET($comments){
	if(empty($comments)){
	include('config.php');
	include('language.php');
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$newsget = mysql_query("select * from $newsprefix order by id desc limit $displaylimit");
    while($r=mysql_fetch_array($newsget))
    {        
    $id=$r["id"];
    $articlename=$r["articlename"];
	$name=$r["name"];
    $message=$r["message"];
    $time=$r["time"];
	$emailaddress=$r["emailaddress"];
	$keywords=$r["keywords"];
	DISPLAYTEMPLATE($id,$articlename,$name,$message,$time,$emailaddress,$keywords);
	} }
}
function COMMENTSGET($comments,$id){
	if(!empty($comments)){
	include('config.php');
	include('language.php');
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$result1 = mysql_query("select * from $newsprefix where id=$comments limit 1");
    while($r=mysql_fetch_array($result1))
    {        
    	$id=$r["id"];
		$articlename=$r["articlename"];
		$name=$r["name"];
		$message=$r["message"];
		$time=$r["time"];
		$emailaddress=$r["emailaddress"];
		$keywords=$r["keywords"];
		DISPLAYTEMPLATE($id,$articlename,$name,$message,$time,$emailaddress,$keywords);
	}
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$result2 = mysql_query("select * from $commentsprefix where id=$comments order by id_c desc");
    while($r=mysql_fetch_array($result2))
    {   
    	$id_c=$r["id_c"];     
    	$id=$r["id"];
    	$name=$r["name"];
    	$email=$r["email"];
    	$website=$r["website"];
    	$comment=$r["comment"];
		COMMENTTEMPLATE($id_c,$id,$name,$email,$website,$comment);
	} }
}
function FORM($comments,$id,$articlename){
	if(!empty($comments)) {
	include('config.php');
	include('language.php');
?>
	<!-- BEGIN COMMENT FORM -->
	<form action="addcomment.php" method="post" name="comment form"> 
	<input type="hidden" name="id_c" value="" />
	<input type="hidden" name="id" value="<? echo $comments ?>" />
	<p><input type="text" name="name" size="20" maxlength="40" /> <? echo $languagecommentname ?></p>
	<p><input type="text" name="email" size="20" maxlength="40" /> <? echo $languagecommentemail ?></p>
	<p><input type="text" name="website" size="20" maxlength="50" /> <? echo $languagecommentwebsite ?></p>
	<p><textarea name="comment" cols="25" rows="4"></textarea></p>
	<p><input type="submit" name="submit" value="<? echo $languagecommentbutton ?>" /></p>
	</form>
	<!-- END COMMENT FORM -->
<?
} }
function COMMENTFIND($id){
	include('config.php');
	include('language.php');
?>
	<!-- BEGIN COMMENT FIND -->
	<a href="?comments=<? echo $id ?>"><? echo $languagecommentlink ?> (<? include('config.php'); $link = mysql_connect($host, $username, $userpass); mysql_select_db("$userdatabase", $link); $cmd = "SELECT count(*) as fcnt FROM $commentsprefix where id=$id"; $resultnum = mysql_query($cmd) or die (mysql_error()); while($row = mysql_fetch_array($resultnum)) { echo $row["fcnt"]; } ?>)</a>
	<!-- END COMMENT FIND -->
<?
}
function DROPDOWNARCHIVE(){
	include('config.php');
	include('language.php');
?>
	<!-- BEGIN DROP DOWN ARCHIVE -->
	<form name="form" action="<? echo $PHP_SELF ?>" method="post">
	<select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
	<option value="?"><? echo $languagedropdowntitle ?></option>
	<option value="?">Main Page</option>
	<? include('config.php');
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$resultdrop = mysql_query("select * from $newsprefix order by id desc limit 45");
    while($r=mysql_fetch_array($resultdrop))
    {        
    $time=$r["time"];
    $id=$r["id"];
	?>
	<option value="?comments=<? echo $id ?>"><? echo $time ?></option>
	<? } ?>
	</select>
	</form>
	<!-- END DROP DOWN ARCHIVE -->
	<!-- KEEP THE LINK BELOW ON YOUR SITE PLEASE. IT IS ALL WE 
	ASK FOR ALL OF THE HARD WORK WE PUT IN TO THIS PROGRAM -->
	<p>Powered by <a href="http://twoblog.com">Bit 5 Blog</a></p>
<?
}
function PLUGINS(){
	include('config.php');
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$pluginssql = mysql_query("select * from $bit5pluginsdisplay");
    while($r=mysql_fetch_array($pluginssql))
	{
		$include1=$r["1"];
		$include2=$r["2"];
		$include3=$r["3"];
		$include4=$r["4"];
		$include5=$r["5"];	
		include("$include1");
		include("$include2");
		include("$include3");	
		include("$include4");
		include("$include5");
	}
}
function FORMFORCOMMENTS($comments,$id,$articlename) {
	if(!empty($comments)) {
	COMMENTADDFORM($comments,$id,$articlename);
} }
?>