<? 
header("Content-type: text/xml");
include('config.php');
include('language.php');
echo '<?xml version="1.0"?>'; 
?>
<rss version="2.0">
	<channel>
		<title><? echo $title ?></title>
		<link><? echo $fullurl ?></link>
		<description><? echo $blogdescription ?></description>
		<language><? echo $rsssyndlanguage ?></language
		><copyright>Copyright <? echo date("Y"); echo " $title" ?></copyright>
		<docs>http://blogs.law.harvard.edu/tech/rss</docs>
		<generator>TwoBlog.com</generator>
		<ttl>60</ttl>
<?
include('config.php');
mysql_pconnect("$host","$username","$userpass");
mysql_select_db("$userdatabase");
$result = mysql_query("select * from $newsprefix order by id desc limit $displaylimit");
while($r=mysql_fetch_array($result))
{        
    $id=$r["id"];
    $articlename=$r["articlename"];
	$name=$r["name"];
    $message=htmlentities($r["message"]);
    $time=$r["time"];
	$emailaddress=$r["emailaddress"];
?>
		<item>
			<title><? echo $articlename ?></title>
			<description><? echo $message ?></description>
			<pubDate><? echo $time ?></pubDate>
			<guid><? echo $fullurl ?>?comments=<? echo $id ?></guid>
			<link><? echo $fullurl ?>?comments=<? echo $id ?></link>
			<author><? echo $emailaddress ?></author>
			</item>

<? } ?>
	</channel>
</rss>

