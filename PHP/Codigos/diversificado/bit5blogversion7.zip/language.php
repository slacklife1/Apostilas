<?
//** Language File ENGLISH **//
//** Comment Form Text **//
$languagecommentname    = "Name";
$languagecommentemail   = "Email";
$languagecommentwebsite = "Website";
$languagecommentbutton  = "Post Comment";


//** Comment Link Text **//
$languagecommentlink    = "Comments";


//** Dropdown Archive Text **//
$languagedropdowntitle  = "Archive";
$languagedropdownbutton = "View";


	include('config.php');
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$result = mysql_query("select * from $optionsprefix limit 1");
    while($r=mysql_fetch_array($result))
  {        
	$dateformat          = $r["dateformat"];
	$displaylimit        = $r["displaylimit"];
	$fullurl             = $r["fullurl"];
	$title               = $r["title"];
	$blogdescription     = $r["blogdescription"];
	$rsssyndlanguage     = $r["rsssyndlanguage"];
  }
?>
