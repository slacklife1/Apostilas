<? if($step1) {
include('config.php');
mysql_pconnect("$host","$username","$userpass");
mysql_select_db("$userdatabase");
$banip = "CREATE TABLE `$banprefix` (`id` int(15) NOT NULL auto_increment,`ipaddress` text NOT NULL,`description` text NOT NULL,PRIMARY KEY  (`id`)) TYPE=MyISAM;";
$go01 = mysql_query($banip) or die("Ban IP table creation failed.");
$tablecomments = "CREATE TABLE $commentsprefix ( `id_c` int(11) NOT NULL auto_increment, `id` text NOT NULL,`name` text NOT NULL,`email` text NOT NULL,`website` text NOT NULL,`comment` text NOT NULL,PRIMARY KEY  (`id_c`)) TYPE=MyISAM;";
$go1 = mysql_query($tablecomments) or die("Comment table creation failed.");
$tablenews = "CREATE TABLE $newsprefix (`id` int(11) NOT NULL auto_increment,`articlename` text NOT NULL,`name` text NOT NULL,`emailaddress` text NOT NULL,`message` longtext NOT NULL,`time` text NOT NULL,`keywords` text NOT NULL,PRIMARY KEY  (`id`)) TYPE=MyISAM;";
$go2 = mysql_query($tablenews) or die("Entry table creation failed.");
$tableoptions = "CREATE TABLE $optionsprefix (`dateformat` text NOT NULL,`displaylimit` text NOT NULL,`fullurl` text NOT NULL,`title` text NOT NULL,`blogdescription` text NOT NULL,`rsssyndlanguage` text NOT NULL) TYPE=MyISAM;";
$go3 = mysql_query($tableoptions) or die("Options table creation failed.");
$tableplugins = "CREATE TABLE $pluginsprefix (`pluginid` int(15) NOT NULL auto_increment,`pluginname` text NOT NULL,`plugindescription` text NOT NULL,`pluginfile` text NOT NULL,PRIMARY KEY  (`pluginid`)) TYPE=MyISAM;";
$go4 = mysql_query($tableplugins) or die("Plugin table creation failed.");
$tablepluginsdisplay = "CREATE TABLE $bit5pluginsdisplay (`id` int(5) NOT NULL default '0',`1` text NOT NULL,`2` text NOT NULL,`3` text NOT NULL,`4` text NOT NULL,`5` text NOT NULL) TYPE=MyISAM;";
$go5 = mysql_query($tablepluginsdisplay) or die("Plugin display table creation failed.");
$tableusers = "CREATE TABLE $userprefix (id int(11) NOT NULL auto_increment,userid varchar(100) NOT NULL default '',password varchar(100) NOT NULL default '',fullname varchar(100) NOT NULL default '',emailaddress text NOT NULL,add2 text NOT NULL,edit2 text NOT NULL,delete2 text NOT NULL,create2 text NOT NULL,comments2 text NOT NULL,ban2 text NOT NULL,compile2 text NOT NULL,upload2 text NOT NULL,plugins2 text NOT NULL,PRIMARY KEY  (id), UNIQUE KEY userid (userid)) TYPE=MyISAM;";
$go6 = mysql_query($tableusers) or die("User table creation failed.");

$datacomments = "INSERT INTO $commentsprefix VALUES (1, '1', 'Daniel ', '', '', 'Comments are fun!');";
$go7 = mysql_query($datacomments) or die("Comment table insertion failed.");
$datanews = "INSERT INTO $newsprefix VALUES ('1', 'Welcome To Your New Blog!', 'Daniel McCoy', 'demo@demo.com', 'Congratulations, you now have a blog! You can delete this entry in the <a href=\"admin/\">admin panel</a>.', 'Friday, August 22, 2003 @ 3:00 pm', 'post 1 congratulations install');";
$go8 = mysql_query($datanews) or die("Entry table insertion failed.");
$dataoptions = "INSERT INTO $optionsprefix VALUES (\"$dateformat\",\"$hg\",\"$fullsiteurl\",\"$blogtitle\",\"$descriptionofblog\",\"$bloglanguage\");";
$go9 = mysql_query($dataoptions) or die("Options table insertion failed.");
$datausers = "INSERT INTO $userprefix VALUES (\"1\",\"$adminusername\",\"$adminpassword\",\"$adminname\",\"$adminaddress\", 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true', 'true');";
$go10 = mysql_query($datausers) or die("User table insertion failed.");
$dataplugins = "INSERT INTO $pluginsprefix VALUES (1, 'Recent Comments', 'Display links to the last 5 posts with new comments.', 'recentcomments.php'),(2, 'Users Online', 'Display the number of users online', 'usersonline.php'),(3, 'RSS Feed Link', 'This plugin displays a link to the RSS version of your blog.', 'rssplugin.php');";
$go11 = mysql_query($dataplugins) or die("Plugin table insertion failed.");
$datapluginsdisplay ="INSERT INTO $bit5pluginsdisplay VALUES (0, 'plugins/recentcomments.php', 'plugins/usersonline.php', 'plugins/rssplugin.php', 'plugins/default.php', 'plugins/default.php');";
$go12 = mysql_query($datapluginsdisplay) or die("Plugin table insertion failed.");

$usersonlinetable ="CREATE TABLE $onlineprefix (timestamp int(15) NOT NULL default '0',ip varchar(40) NOT NULL default '',file varchar(100) NOT NULL default '',PRIMARY KEY  (timestamp),KEY ip (ip),KEY file (file)) TYPE=MyISAM;";
$go13 = mysql_query($usersonlinetable) or die("User online table creation failed.");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Install Bit 5 Blog</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="admin/stylesheet.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="border"> 
  <div class="content"> <img src="admin/logo.gif" alt="Bit 5 Blog" />  
  <p><? echo $messagesay ?></p>
  <p>If you do not see any errors, all you need to do is go to the <a href="admin/">admin panel</a> and post!</p>
  </div>
</div>
</body>
</html>
<? }else{ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Install Bit 5 Blog</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="admin/stylesheet.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="border"> 
  <div class="content"> <img src="admin/logo.gif" alt="Bit 5 Blog" />
	<p>Welcome to the Bit 5 Blog install script. If you have not done so already, please edit the variables in config.php, and CHMOD your templates/template.txt, and wep/index.wml files to 777. Also, if you want to be able to upload files to your server via the control panel, you will need to CHMOD your images/ directory to 777. If you are unsure how to CHMOD files, please consult your FTP program's manual.</p>
    <br />
	 <form action="<? echo $PHP_SELF ?>" method="post">
	 <p><b>Blog Information</b></p>
	<p><input name="blogtitle" type="text" value="" size="40" /> Title of Blog</p>
	<p><input name="descriptionofblog" type="text" value="" size="40" /> Description of Blog</p>
	<p><input name="fullsiteurl" type="text" value="<? $url ="http://" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI']; $url = str_replace("install.php", "", $url); echo $url; ?>" size="40" /> Full URL to Blog Directory With Trailing Slash</p>
	<br />
	 <p><b>Blog Options</b></p>
	<p><input name="bloglanguage" type="text" value="en-us" size="40" /> Language of Blog <a href="http://my.netscape.com/publish/formats/rss-spec-0.91.html#langcodes" target="_blank">[ ? ]</a></p>	
	<p><input name="dateformat" type="text" value="l, F j, Y @ g:i a" size="40" /> Format For Date <a href="http://us4.php.net/date" target="_blank">[ ? ]</a></p>
	<p><input name="hg" type="text" value="8" size="40" /> Number of Posts to Display</p>	
	<br />
	 <p><b>Admin Panel Information</b></p>
	<p><input name="adminusername" type="text" value="" size="40" /> Admin Panel Username</p>	
	<p><input name="adminpassword" type="text" value="" size="40" /> Admin Panel Password</p>
	<p><input name="adminname" type="text" value="" size="40" /> Your Name</p>
	<p><input name="adminaddress" type="text" value="" size="40" /> Your Email Address</p>
	 <br />
	<p><input name="step1" type="submit" value="Install Bit 5 Blog" /></p>
    </form>
  </div>
</div>
</body>
</html>
<? } ?>