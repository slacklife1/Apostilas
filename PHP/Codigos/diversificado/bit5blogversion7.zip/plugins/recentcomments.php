<?
	PLUGINTOP();
	//**       Recent Comments Plugin by Daniel McCoy           **//
	echo "<strong>Recent Comments</strong>";
	include('config.php');
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$lastcomments = mysql_query("select * from $commentsprefix order by id_c desc limit 5");
	while($r=mysql_fetch_array($lastcomments))
	{   
	$id_c=$r["id_c"];     
	$id=$r["id"];
	$name=$r["name"];	
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$result4 = mysql_query("select * from $newsprefix where id=$id");
	while($r=mysql_fetch_array($result4))
	{
	$articlename=$r["articlename"];
	echo "<br /><a href=\"?comments=$id\">$articlename</a>";	
	}   
	}
	PLUGINBOTTOM();
?>
