<?
PLUGINTOP();
include('config.php');
$timeoutseconds = "300"; 
$timestamp = time(); 
$timeout = $timestamp-$timeoutseconds; 
mysql_connect($host, $username, $userpass); 
$insert = mysql_db_query($userdatabase, "INSERT INTO $onlineprefix VALUES('$timestamp','$REMOTE_ADDR','$PHP_SELF')"); 
$delete = mysql_db_query($userdatabase, "DELETE FROM $onlineprefix WHERE timestamp<$timeout"); 
$result = mysql_db_query($userdatabase, "SELECT DISTINCT ip FROM $onlineprefix WHERE file='$PHP_SELF'"); 
$user = mysql_num_rows($result); 
mysql_close(); 
if($user == "1") { 
print("<b>$user User Online</b>"); 
} else { 
print("<b>$user Users Online</b>"); 
} 
PLUGINBOTTOM();
?> 