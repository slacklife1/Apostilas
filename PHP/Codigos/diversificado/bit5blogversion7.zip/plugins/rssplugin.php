<? 
PLUGINTOP();
echo "<strong>Syndication</strong><br />";
echo "<a href=\"rss.php\">RSS 2.0 Feed</a>"; 
PLUGINBOTTOM();
?>