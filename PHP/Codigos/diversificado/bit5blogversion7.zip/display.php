<?
include('config.php');
include('language.php');
include('functions.php');
include("templates/$templatename");
LAYOUT($comments,$id,$pageshow);
?>
