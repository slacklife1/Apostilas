<?
include("accesscontrol.php");
include('../config.php');
include('header.php');
if($createpermission !="true") { echo "You do not have permission to create users.</div></div></body></html>"; }else{
if(!isset($ends_design_add_go)) {
?>
<b>Manage Users</b><br /><br />
<?
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$result1 = mysql_query("select * from $userprefix order by id desc");
    while($r=mysql_fetch_array($result1))
    {        
    	$id=$r["id"];
		$fullname=$r["fullname"];
		echo "<i>$fullname</i> <a href=\"deleteuser.php?id=$id\">[ Delete This User ]</a><br /><br />";
	}
?>

<form method="post" action="adduser.php" name="addForm">
  <input type="hidden" name="ID"  size="45" value="id" />
  <input type="text" name="userid"  size="45" value="" />
  Username<br />
  <br />
  <input type="password" name="password"  size="45" value="" />
  Password<br />
  <br />
  <input type="text" name="fullname"  size="45" value="" />
  Full Name<br />
  <br />
  <input type="text" name="emailaddress"  size="45" value="" />
  Email Address<br />
  <br />
  <input name="add2" type="checkbox" value="true" />
  Post Entry Permission<br />
  <br />
  <input name="edit2" type="checkbox" value="true" />
  Edit Entry Permission<br />
  <br />
  <input name="delete2" type="checkbox" value="true" />
  Delete Entry Permission<br />
  <br />
  <input name="comments2" type="checkbox" value="true" />
  Delete Comments Permission<br />
  <br />
  <input name="create2" type="checkbox" value="true" />
  Create User Permission<br />
  <br />
  <input name="ban2" type="checkbox" value="true" />
  Ban IP Permission<br />
  <br />
  <input name="compile2" type="checkbox" value="true" />
  WEP Compile Permission<br />
  <br />
  <input name="upload2" type="checkbox" value="true" />
  Upload File Permission<br />
  <br />
  <input name="plugins2" type="checkbox" value="true" />
  Plugin Layout Permission<br />
  <br />
  <input type="hidden" name="ends_design_add_go" value="TRUE" />
  <input name="submit" type="submit" value="Create User" />
</form>
</div>
</div>
</body>
</html>
<?
} else {
$MYSQLCONN = mysql_connect("$host","$username","$userpass") or die("Error connecting to database.");
mysql_select_db("$userdatabase",$MYSQLCONN) or die("The database could not be found.");
$query = "INSERT INTO $userprefix (`id`,`userid`,`password`,`fullname`,`emailaddress`,`add2`,`edit2`,`delete2`,`create2`,`comments2`,`ban2`,`compile2`,`upload2`,`plugins2`) VALUES ('null','$userid','$password','$fullname','$emailaddress','$add2','$edit2','$delete2','$create2','$comments2','$ban2','$compile2','$upload2','$plugins2')";
if(!mysql_query($query)) { echo "Error: must be a unique admin user name and id"; } else { echo "User Created </div></div></body></html>"; }
} }
?>
