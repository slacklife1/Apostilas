<?
include("accesscontrol.php");
include('../config.php');
include('header.php');
	$deleteuser = "DELETE FROM $userprefix WHERE id=$id";        
	$result1 = mysql_query($deleteuser);
	echo "User Deleted.";
?>
</div></div></body></html>