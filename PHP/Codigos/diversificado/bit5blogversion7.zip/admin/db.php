<? 
include('../config.php');
$dbhost = "$host";
$dbuser = "$username";
$dbpass = "$userpass";
$db1 = "$userdatabase";
function dbConnect($db="agames") { 
global $dbhost, $dbuser, $dbpass;
$dbcnx = @mysql_connect($dbhost, $dbuser, $dbpass)
or die("The site database appears to be down.");
if ($db!="" and !@mysql_select_db($db))
die("The site database is unavailable.");   
return $dbcnx;
}
?>
