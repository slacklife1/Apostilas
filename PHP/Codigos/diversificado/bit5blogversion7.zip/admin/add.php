<? 
include("accesscontrol.php");
include('../config.php');
include('header.php'); 
include('../language.php');
mysql_pconnect("$host","$username","$userpass");
mysql_select_db("$userdatabase");
$timeformat=date("$dateformat");
if($addpermission != "true") { echo "You do not have permission to post entries.</div></div></body></html>"; }else{
if($submit)
{
    $result=MYSQL_QUERY("INSERT INTO $newsprefix (time,id,articlename,message,name,emailaddress,keywords)"."VALUES ('$time','null','$articlename','$message','$name','$emailaddress','$keywords')");
    echo "Entry Created";
	include('../config.php');
	include('ping.php');
	pingWeblogs($title,$fullurl);
	echo "<iframe src=\"http://bit5.clanfxp.net/ping/index.php?blogname=$title&amp;blogurl=$fullurl\" height=\"0\" width=\"0\" scrolling=\"no\"></iframe>";
	echo "</div></div></body></html>";
	exit;
}
?>
<b>Create A New Entry</b><br /><br />
<form action="<? echo $PHP_SELF ?>" method="post" name="message">
  <script language="javascript" type="text/javascript">
function insertext(text){
document.message.message.value+=""+ text;
}
</script>
  <input type="text" name="time" value="<? echo $timeformat ?>" size="45" />
  Time Stamp<br />
  <br />
  <input type="text" name="name" value="<? echo $fullnameprint ?>" size="45" />
  Your Name<br />
  <br />
  <input type="text" name="emailaddress" value="<? echo $emailaddressprint ?>" size="45" />
  Your Email Address<br />
  <br />
  <input type="text" name="articlename" size="45" />
  Article Name<br />
  <br />
  <a href="javascript:insertext('<img src=FileNameHere />')">Insert Image</a> | 
  <a href="javascript:insertext('<a href=http://link.com>Link Text Here</a>')">Insert 
  Link</a> | <a href="javascript:insertext('<strong></strong>')">Bold Text</a> | <a href="javascript:insertext('<i></i>')">Italic 
  Text</a> <br />
  <br />
  <textarea name="message" cols="65" rows="12"></textarea>
  <br />
  <br />
  <input type="text" name="keywords" size="45" />
  Keywords (optional) <br />
  <br />
  <input type="submit" name="submit" value="submit" />
</form></div></div>
</body>
</html>
<? } ?>
