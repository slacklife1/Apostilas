<?
include("../config.php");
include("db.php");
session_start();
if(!isset($uid)) {
include("../config.php");
echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?".">"; 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Admin Panel</title>
<link href="stylesheet.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<div class="border">
<div class="content">
<img src="logo.gif" alt="Two Blog Logo" /><br />
Please Log In.<br /><br /> 
<form method="post" action="<?=$PHP_SELF?>">
<input type="text" name="uid" size="15"> Username<br /><br />
<input type="password" name="pwd" SIZE="15"> Password<br /><br />
<input type="submit" value="Log in">
</form>
</div>
</div>
</body></html>
<?
exit;
}
include("../config.php");
session_register("uid");
session_register("pwd");
dbConnect("$db1");
$sql = "SELECT * FROM $userprefix WHERE userid = '$uid' AND password = '$pwd'";
$result = mysql_query($sql);
if (!$result) {
echo "error";
exit;
}
if (mysql_num_rows($result) == 0){
session_unregister("uid");
session_unregister("pwd"); 
include("../config.php");
include("header.php");
echo "Access Denied";  
exit; }
$fullnameprint = mysql_result($result,0,"fullname");
$emailaddressprint = mysql_result($result,0,"emailaddress");
$addpermission = mysql_result($result,0,"add2");
$editpermission = mysql_result($result,0,"edit2");
$deletepermission = mysql_result($result,0,"delete2");
$createpermission = mysql_result($result,0,"create2");
$banpermission = mysql_result($result,0,"ban2");
$compilepermission = mysql_result($result,0,"compile2");
$commentspermission = mysql_result($result,0,"comments2");
$uploadpermission = mysql_result($result,0,"upload2");
$pluginspermission = mysql_result($result,0,"plugins2");
?>
