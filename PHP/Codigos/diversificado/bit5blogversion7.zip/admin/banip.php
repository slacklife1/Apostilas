<?
	include("accesscontrol.php");
	include('header.php');
	include('../config.php');	
	if($banpermission !="true") { echo "You do not have permission to update WEP information.</div></div></body></html>"; exit; }
	if($bango == "do"){
	
	$result=MYSQL_QUERY("INSERT INTO $banprefix (id,ipaddress,description)"."VALUES ('null','$ipaddress','$description')");
	echo "The IP address <b>$ipaddress</b> is no longer allowed to access your blog.";
	
	}else if($deletego){
	
	$deleteip = "DELETE FROM $banprefix WHERE id=$deletego";        
	$result1 = mysql_query($deleteip);
	echo "The IP address <b>$address</b> can now access your blog.";
		
	}else{
	?>
	<b>Ban An IP Address</b><br /><br />
	
	<form method="post" action="<? echo $PHP_SELF ?>">
	<input type="hidden" name="bango" value="do" />
	<input type="text" name="ipaddress" size="25" /> IP Address<br /><br />
	<input type="text" name="description" size="25" /> Description (optional)<br /><br />
	<input type="submit" value="Ban IP" /><br />
	</form><br />
	<?
	include('../config.php');	
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$banget = mysql_query("select * from $banprefix order by id desc");
    while($r=mysql_fetch_array($banget))
    {        
    $id=$r["id"];
    $ipaddress=$r["ipaddress"];
	$description=$r["description"];
	echo "<b>$ipaddress</b> <a href=\"banip.php?deletego=$id&amp;address=$ipaddress\">[ Allow This Address ]</a> <br /> $description <br />";
	} 
	
	}
?>
</div></div>
