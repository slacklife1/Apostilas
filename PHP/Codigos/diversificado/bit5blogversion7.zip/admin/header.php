<? echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?".">"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Admin Panel</title>
<link href="stylesheet.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<div class="border">
<div class="content"> 
<img src="logo.gif" border="0" alt="Two Blog" /> <br />
<a href="add.php">Post Entry</a> |  
<a href="editdelete.php">Edit / Delete</a> | 
<a href="wep.php">Compile WEP</a> |
<a href="upload.php">Upload</a> | 
<a href="comments.php">Mod Comments</a> |
<a href="adduser.php">Mod Users</a> |
<a href="plugins.php">Plugins</a> |
<a href="editor.php">Templates</a> |
<a href="banip.php">Ban IP</a> | 
<a href="../index.php">Preview</a>
<br /><br />
<? 
// The trim function - out of the way
function shorten_string($text,$length,$symbol = "[...]") {
$length_text = strlen($text);
$length_symbol = strlen($symbol);
if($length_text <= $length || $length_text <= $length_symbol || $length <= $length_symbol)
return($text);
else
return(substr($text, 0, $length - $length_symbol) . $symbol);
}
// End trim function
?>