<?

include('header.php'); 

	ob_start();
	if(empty($file)){
	$file = "template.txt";
	}
	$file = str_replace("..", "", $file);  
if ($dir) 
{ 
	$mydir = "../templates";
} else $mydir = "../templates";

$curdir=dir($mydir);

if($writefile) 
{
	$fd=fopen($mydir."/".$file, "w");
	fwrite($fd, stripslashes($text));
	fclose($fd);
	echo "File Updated";
} 
elseif($file) 
{
	$fp=fopen($mydir."/".$file, "r");
	while(!feof($fp)) {
		$con .= fgets($fp, 4096);
		}
	fclose($fp);
	
	echo "<b>Now Editing template.txt</b><br /><br />
		<form action='$PHP_SELF' method='post'>\n
		<input type=hidden name=writefile value=$file>\n
		<input type=hidden name=file value=$file>\n
		<input type=hidden name=dir value=$mydir>\n
		<textarea rows='20' cols='100' name='text'>\n";
	echo $con;
	echo "	</textarea><br /><br />\n
		<input type='submit' value='Save'>\n</form>\n";
} 
else 
{
	while($file = $curdir->read()) { 	
		echo "<a href=\"$PHP_SELF?file=$file\">$file</a><br />\n";
		}	
} 

ob_end_flush(); 
?>