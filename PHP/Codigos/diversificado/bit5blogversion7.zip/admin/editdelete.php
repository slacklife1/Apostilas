<?
include("accesscontrol.php");
include('../config.php');
include('header.php');
if(empty($id)) {
?>
<b>Edit Or Delete Entries</b><br /><br />

<form action="<? echo $PHP_SELF ?>" method="post">
  <input type="hidden" name="searchthis" value="searchthis">
  <input name="searchword" type="text" size="25" /> Search Term<br /><br />
  <select name="columnselect" size="1">
    <option value="articlename">Entry Title</option>
    <option value="message">Entry Body</option>
    <option value="keywords">Entry Keywords</option>
  </select>
  <input name="searchsubmit" type="submit" value="Search" /><br />
</form>
<br />
<? 
mysql_pconnect("$host","$username","$userpass");
mysql_select_db("$userdatabase");
if($searchthis =="searchthis") { $result = mysql_query("SELECT * FROM $newsprefix WHERE $columnselect LIKE '%$searchword%' order by id desc"); }else{
$result = mysql_query("select * from $newsprefix order by id desc limit 20"); }
    while($r=mysql_fetch_array($result))
    {        
    $time=$r["time"];
    $id=$r["id"];
    $articlename=$r["articlename"];
    $message=$r["message"];
    $name=$r["name"];
?>
<b><? echo $articlename ?></b> <? if($deletepermission != "true") { echo " [ Delete Entry ] ";}else{ echo " [ <a href=\"editdelete.php?id=$id\">Delete Entry</a> ] "; } if($editpermission != "true") { echo " [ Edit Entry ] ";}else{ echo " [ <a href=\"edit.php?id=$id&amp;cmd=Edit\">Edit Entry</a> ]"; } ?>
<br />
<? echo shorten_string($message,"220","......"); ?><br />
<br /><a href="#"></a>
<? } 
echo"</div></div></body></html>";
}else{
mysql_pconnect("$host","$username","$userpass");
mysql_select_db("$userdatabase");
$news = "DELETE FROM $newsprefix WHERE id=$id";        
$result1 = mysql_query($news);
$comments = "DELETE FROM $commentsprefix WHERE id=$id";        
$result2 = mysql_query($comments);
$optimize = "OPTIMIZE TABLE $commentsprefix";        
$result3 = mysql_query($optimize);
echo "Entry Deleted </div></div></body></html>";
}
?>
