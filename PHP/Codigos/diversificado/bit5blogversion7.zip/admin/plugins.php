<? 
   	include("accesscontrol.php");
   	include('../config.php');
   	include('header.php'); 
	if($pluginspermission !="true") { echo "You do not have permission to modify the plugin layout.</div></div></body></html>"; exit; }
   	if($submit)
  {
   	mysql_pconnect("$host","$username","$userpass");
   	mysql_select_db("$userdatabase");
	$deleteall = mysql_query("DELETE FROM $bit5pluginsdisplay where id=0");
	$plugingo= "insert INTO $bit5pluginsdisplay(`id`,`1`,`2`,`3`,`4`,`5`)VALUES('$id','$form1','$form2','$form3','$form4','$form5')";
	mysql_query($plugingo);
    echo "Plugin Data Updated </div></div></body></html>";
	exit;
  }
?><b>Plugin Display Information</b><br /><br />
<form name="plugins" action="plugins.php" method="post">
  <input type="hidden" name="id" value="0" />
  <select name="form1">
    <option value="plugins/default.php">None</option>
<?
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$pluginlist = mysql_query("select * from $pluginsprefix");
	while($r=mysql_fetch_array($pluginlist))
  {
	$pluginfile=$r["pluginfile"];
	$pluginname=$r["pluginname"];
?>
    <option value="plugins/<? echo $pluginfile ?>"><? echo $pluginname ?></option>
<? 
  }
?>
  </select>
  Plugin Slot 1 <br />
  <br />
  <select name="form2">
    <option value="plugins/default.php">None</option>
<?
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$pluginlist = mysql_query("select * from $pluginsprefix");
	while($r=mysql_fetch_array($pluginlist))
  {
	$pluginfile=$r["pluginfile"];
	$pluginname=$r["pluginname"];
?>
    <option value="plugins/<? echo $pluginfile ?>"><? echo $pluginname ?></option>
<? 
  }
?>
  </select>
  Plugin Slot 2<br />
  <br />
  <select name="form3">
    <option value="plugins/default.php">None</option>
<?
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$pluginlist = mysql_query("select * from $pluginsprefix");
	while($r=mysql_fetch_array($pluginlist))
  {
	$pluginfile=$r["pluginfile"];
	$pluginname=$r["pluginname"];
?>
    <option value="plugins/<? echo $pluginfile ?>"><? echo $pluginname ?></option>
<? 
  }
?>
  </select>
  Plugin Slot 3<br />
  <br />
  <select name="form4">
    <option value="plugins/default.php">None</option>
<?
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$pluginlist = mysql_query("select * from $pluginsprefix");
	while($r=mysql_fetch_array($pluginlist))
  {
	$pluginfile=$r["pluginfile"];
	$pluginname=$r["pluginname"];
?>
    <option value="plugins/<? echo $pluginfile ?>"><? echo $pluginname ?></option>
<? 
  }
?>
  </select>
  Plugin Slot 4<br />
  <br />
  <select name="form5">
    <option value="plugins/default.php">None</option>
<?
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	$pluginlist = mysql_query("select * from $pluginsprefix");
	while($r=mysql_fetch_array($pluginlist))
  {
	$pluginfile=$r["pluginfile"];
	$pluginname=$r["pluginname"];
?>
    <option value="plugins/<? echo $pluginfile ?>"><? echo $pluginname ?></option>
<? 
  }
?>
  </select>
  Plugin Slot 5<br />
  <br />
  <input type="submit" name="submit" value="submit" />
</form></div></div>
</body>
</html>
