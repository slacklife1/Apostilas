<?
	include("accesscontrol.php");
	include('header.php');
	include('../language.php');
	if($uploadpermission !="true") { echo "You do not have permission to upload files.</div></div></body></html>"; exit; }
	if(!isset($upload)) 
  {
	$upload = "";
  }
	switch($upload) 
  {
	default:
	$size_limit = "yes";
	$limit_size = "100000";
	$limit_ext = "yes";
	$ext_count = "5";
	$extensions = array(".gif", ".jpg", ".jpeg", ".png", ".html");
	echo "<b>Upload A File</b><br /><br />
<form method=\"POST\" action=\"upload.php?upload=doupload\" enctype=\"multipart/form-data\">
<input type=\"file\" name=\"file\" size=\"20\" class=\"inputbutton\"><br /><br />
<input name=\"submit\" type=\"submit\" value=\"Upload\">";

break;
case "doupload":
	$size_limit = "yes";
	$limit_size = "100000";
	$limit_ext = "yes";
	$ext_count = "5";
	$extensions = array(".gif", ".jpg", ".jpeg", ".png", ".html");
include "../config.php";
include('../language.php');
$endresult = "<b>Upload A File</b><br /><br /><b>$file_name</b> was uploaded. The full url to the file is:<br /><a href=\"$fullurl"."images/$file_name\">$fullurl"."images/$file_name</a>";
if ($file_name == "") {
$endresult = "Please select a file.";
}else{
if(file_exists("$fullurl/images/$file_name")) {
$endresult = "The file already existed, and was not uploaded.";
} else {
if (($size_limit == "yes") && ($limit_size < $file_size)) {
$endresult = "The file was too big, and was not uploaded.";
} else {
$ext = strrchr($file_name,'.');
if (($limit_ext == "yes") && (!in_array($ext,$extensions))) {
$endresult = "The file was of an unallowed type, and was not uploaded.";
}else{
@copy($file, "../images/$file_name") or $endresult = "The server did not allow the upload. Please set the proper permissions and try again.";
}
}
}
}
echo "$endresult";
break;
}
?>
</div></div>
