<?
include("accesscontrol.php");
include('../config.php');
include('header.php');
if($editpermission != "true"){ echo "You do not have permission to edit entries.</div></div></body></html>"; }else{
 ?>
<form action="<? echo $PHP_SELF ?>" method="get">
  <?
mysql_pconnect("$host","$username","$userpass");
mysql_select_db("$userdatabase");
if(!$cmd)
{
    $result = mysql_query("select * from $newsprefix order by id desc");
    while($r=mysql_fetch_array($result))
    {    
    $time=$r["time"];
    $id=$r["id"];
    $articlename=$r["articlename"];
    $message=$r["message"];
    $name=$r["name"];
?>
  <INPUT TYPE="RADIO" NAME="id" VALUE="<? echo $id;?>" />
  <? echo $articlename ?> <br />
  <br />
  <? } ?>
  <input type="submit" name="cmd" value="Edit" />
</form>
<? } ?>
<?
if($cmd=="Edit")
{
    if (!$submit)
    {
        $sql = "SELECT * FROM $newsprefix WHERE id=$id";
        $result = mysql_query($sql);        
        $myrow = mysql_fetch_array($result);
?></form>
<b>Edit An Entry</b><br /><br />

<form action="<? echo $PHP_SELF ?>" method="post" name="message">
  <script language="javascript">
function insertext(text){
document.message.message.value+=""+ text;
}
</script>
  <input type="hidden" name="id" value="<? echo $myrow["id"] ?>" />
  <input type="text" name="time" value="<? echo $myrow["time"] ?>" size="45" />
  Time Stamp<br />
  <br />
  <input type="text" name="name" value="<? echo $myrow["name"] ?>" size="45" />
  Your Name<br />
  <br />
  <input type="text" name="emailaddress" value="<? echo $myrow["emailaddress"] ?>" size="45" />
  Your Email Address<br />
  <br />
  <input type="text" name="articlename" size="45" value="<? echo $myrow["articlename"] ?>" />
  Article Name<br />
  <br />
  <a href="javascript:insertext('<img src=FileNameHere />')">Insert Image</a> | 
  <a href="javascript:insertext('<a href=http://link.com>Link Text Here</a>')">Insert 
  Link</a> | <a href="javascript:insertext('<strong></strong>')">Bold Text</a> | <a href="javascript:insertext('<i></i>')">Italic 
  Text</a> <br />
  <br />
  <textarea name="message" cols="65" rows="12"><? echo $myrow["message"] ?></textarea>
  <br />
  <br />
  <input type="text" name="keywords" size="45" value="<? echo $myrow["keywords"] ?>" /> Keywords (optional)
  <br />
  <br />
  <input type="hidden" name="cmd" value="Edit" />
  <input type="Submit" name="submit" value="submit" />
</form></form>
</div>
</div> 
</body></html>
<? }
    if($submit)
    {
        $sql = "UPDATE $newsprefix SET time='$time',id='$id',articlename='$articlename',message='$message',name='$name',emailaddress='$emailaddress',keywords='$keywords' WHERE id=$id";
        $result = mysql_query($sql);
        echo "Entry Updated </div></div></body></html>";
		exit;
    }
} }
?>
