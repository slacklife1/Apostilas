<?
	include('../config.php');
	include("accesscontrol.php");
	include('header.php');
   include('../language.php');
	mysql_pconnect("$host","$username","$userpass");
	mysql_select_db("$userdatabase");
	if($compilepermission !="true") { echo "You do not have permission to update WEP information.</div></div></body></html>"; exit; }
	?>
	<b>Update WEP Blog</b><br /><br />
	<?
	$result = mysql_query("select * from $newsprefix order by id desc limit 1");
    while($r=mysql_fetch_array($result))
  {        
    $id=$r["id"];
    $articlename=$r["articlename"];
	$name=$r["name"];
    $message=$r["message"];
    $time=$r["time"];
	$message = strip_tags($message, '<a><b><strong><i><u>');
	$writeline = "<?xml version=\"1.0\"?><!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml><card id=\"index\" title=\"Latest Post\" newcontext=\"true\"><p><strong>$articlename</strong></p><p>$message</p><p><strong>$time</strong></p></card></wml>";
$fileecho = "wep/index.wml";
$filename = '../wep/index.wml';
if (is_writable($filename)) {
    if (!$handle = fopen($filename, 'w+')) {
         print "The file $fullurl$fileecho does not exist. File write aborted.";
         exit;
    }
    if (!fwrite($handle, $writeline)) {
        print "The file $fullurl$fileecho does not have the proper permissions.";
        exit;
    }
    print "Your WEP blog has been updated. If you have a web enabled phone you can access it at: <a href=\"$fullurl$fileecho\">$fullurl$fileecho</a>";
    fclose($handle);
} else {
    print "The file $fullurl$fileecho is not writable";
} }
?>