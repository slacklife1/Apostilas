<? include("accesscontrol.php"); 
include('../config.php');
include('header.php') ?>
Welcome to the admin panel. You are logged in as <strong><? echo $uid ?></strong>. </div></div> 
</body>
</html>
