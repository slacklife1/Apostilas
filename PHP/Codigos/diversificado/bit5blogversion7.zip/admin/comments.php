<?
	include("accesscontrol.php");
	include('../config.php');
	include('header.php');
	if($commentspermission !="true") { echo "You do not have permission to delete comments.</div></div></body></html>"; exit; }
if(!empty($id_c)){
mysql_pconnect("$host","$username","$userpass");
mysql_select_db("$userdatabase");
$deletecomment = "DELETE FROM $commentsprefix WHERE id_c=$id_c";        
$result1 = mysql_query($deletecomment);
echo "Comment deleted";
}else{
?>
<b>Manage Comments</b><br /><br />

<form action="<? echo $PHP_SELF ?>" method="post">
  <input type="hidden" name="searchthis" value="searchthis">
  <input name="searchword" type="text" size="25" /> Search Term <br /><br />
  <input name="searchsubmit" type="submit" value="Search" />
</form>
<br />
<? 
mysql_pconnect("$host","$username","$userpass");
mysql_select_db("$userdatabase");
if($searchthis =="searchthis") { $result = mysql_query("SELECT * FROM $commentsprefix WHERE comment LIKE '%$searchword%' order by id desc"); }else{
$result = mysql_query("select * from $commentsprefix order by id desc limit 20"); }
    while($r=mysql_fetch_array($result))
    {        
    $id_c=$r["id_c"];
    $id=$r["id"];
    $name=$r["name"];
    $email=$r["email"];
    $website=$r["website"];
    $comment=$r["comment"];
	
?>
<p><strong><? echo $name ?></strong> [ <a href="comments.php?id_c=<? echo $id_c ?>">Delete This Comment</a> ]<br />
<? echo shorten_string($comment,"220","......"); ?></p>

<? 
	} }
?>
</div></div>