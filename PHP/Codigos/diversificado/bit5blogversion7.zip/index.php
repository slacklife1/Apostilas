<?php echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?".">"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Bit 5 Blog - blog publishing program</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="stylesheet.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="border"> 
  <img src="logo.gif" width="250" height="65" alt="Logo: Bit 5 Blog" /> 
  <br />

<div class="dividertop"> </div>

<table width="600" border="0" cellspacing="0" cellpadding="0">
<tr> 
  <td valign="top" class="twoblogdescription">
	
<?php include('links.php'); ?> 

<?php include('display.php'); ?>

<?php include('footer.php'); ?> 

  </td>
  <td valign="top" class="twobloglogin"> 

<? PLUGINS(); ?>
<?php include('description.php'); ?> 

  </td>
</tr>
</table>
  
</div>

</body>
</html>
