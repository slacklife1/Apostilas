<? 

 $host ="localhost"; // MYSQL Hostname
 $username = "your_info"; // MYSQL Username
 $userpass = "your_info"; // MYSQL Password
 $userdatabase = "your_info"; // MYSQL Database

//* MYSQL Table Information *//
 $onlineprefix = "blog5_online"; // Table for "Users Online" script
 $banprefix = "blog5_ban"; // Table for banned ip addresses
 $newsprefix = "blog5_entries"; // Table for blog entries
 $commentsprefix = "blog5_comments"; // Table for comments
 $userprefix = "blog5_users"; // Table for admin users
 $optionsprefix = "blog5_options"; // Table for blog options
 $pluginsprefix = "blog5_plugins"; // Table for plugin information
 $bit5pluginsdisplay = "blog5_plugindisplay"; // Table for plugin display order
 
//* Template Configuration *//
 $templatename = "template.txt"; // Name of template file

?>