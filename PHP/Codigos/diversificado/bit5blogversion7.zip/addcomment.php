<script language="JavaScript">
document.location.href="<? echo $HTTP_REFERER ?>"
</script>
<?
$name = strip_tags($name, '');
$email = strip_tags($email, '');
$website = strip_tags($website, '');
$comment = strip_tags($comment, '<a><b><i><u>');
include('config.php');
if(empty($comment)) {
?>
<script language="JavaScript">
document.location.href="<? echo $HTTP_REFERER ?>"
</script>
<?
 exit; }else if(empty($name)) {
?>
<script language="JavaScript">
document.location.href="<? echo $HTTP_REFERER ?>"
</script>
<? 
 exit; }else{								
$MYSQLCONN = mysql_connect("$host","$username","$userpass") or die("<b>Error connecting to mySQL database.</b>");
mysql_select_db("$userdatabase",$MYSQLCONN) or die("<b>Database could not be found.</b>");
$query = "INSERT INTO `$commentsprefix` (`id_c`,`id`,`name`,`email`,`website`,`comment`) VALUES ('$id_c','$id','$name','$email','$website','$comment')";
if(!mysql_query($query)) { echo "failed!"; } else {}
}
?>
