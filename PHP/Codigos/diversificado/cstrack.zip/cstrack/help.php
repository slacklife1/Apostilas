<?php
require("shared.inc.php");
//////////////////////////////////////////////////////////// 
//  CS OutClick Tracker v1.0.0                             /
//  Copyright (c)2001 Codesmokers                          /
//  URL: http://www.codesmokers.com/                       /
////////////////////////////////////////////////////////////
// A return link to codesmokers.com would be appreciated:  /
// http://www.codesmokers.com/                             /
////////////////////////////////////////////////////////////
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF  /
// ANY KIND, EXPRESS OR IMPLIED. IN NO EVENT SHALL THE     /
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,   /
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF     /
// CONTRACT OR OTHERWISE, ARISING FROM, OUT OF OR IN       /
// CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER        /
// DEALINGS IN THE SOFTWARE.                               /
////////////////////////////////////////////////////////////

head();
?>

<table border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#06044D" width="80%" align="center">
  <tr>
    <td>
      <table border="0" align="center" bgcolor="#FFFFFF" cellspacing="0" cellpadding="5" width="100%">
        <tr bgcolor="#06044D"> 
          <td><font face="verdana, arial" size="+2" color="#ffffff"><b>CS Outclick Tracker - Documentation</b></font></td>
        </tr>
 <tr>
  <td bgcolor="#EFEFEF"><font face="verdana, arial" size="2"><a href="<?php echo $track_url; ?>/admin.php?f=main">Home</a> <img src=img/arrow.gif width=8 height=7> Documentation</font></td>
 </tr>
        <tr> 
          <td bgcolor="#EFEFEF"> 
           <font face="verdana, arial" size="2"><b>General Information</b></font>
            <font face="verdana, arial" size="2">
            <p>For Installation or Upgrading Instructions, Please read the INSTALL file<br>
               that was included with the script archive that you downloaded.</p>
            <p>Outclick Tracker Quick Overview</p>
            <ol>
              <li>Allows you to keep track of the number of clicks (raw & unique) on links you specify.</li>
              <li>An admin interface that allows you to view and delete stats.</li>
              <li>A mysql backend that stores all data and capable of handling large volumes of clicks. </li>
            </ol>
            <p>Outclick Linking Syntax Example:</p>
            <ul>
              <li>&lt;a href="<font color="#FF0000"><?php echo $track_url; ?>/out.php?http://www.excite.com/</font>"&gt;Excite&lt;/a&gt;</li>
            </ul>
            <BR>
            <font face="verdana, arial" size="2"><b>Administration Area</b></font>
            <p>The administration area is accessible via: <font color="#FF0000"><?php echo $track_url; ?>/admin.php</font></p>
            <p>Viewing Statictics</p>
            <ol>
              <li>Select a day from the pull down menu on the main administration page.</li>
              <li>Click the submit button and your statistics for that day will be displayed.</li>
              <li>Statistics information displayed will be tracked url, raw clicks & unique clicks.</li>
            </ol>
            <p>Deleting Statistics</p>
            <ol>
              <li>Select a day from the pull down menu on the main administration page.</li>
              <li>Click the submit button and your statistics for that day will be deleted.</li>
              <li>A confirmation will be displayed telling you whether or not the deletion was successful.</li>
            </ol>
          </font>
          </td>
         </tr>  
 <tr>
  <td bgcolor="#EFEFEF"><font face="verdana, arial" size="2"><a href="<?php echo $track_url; ?>/admin.php?f=main">Home</a> <img src=img/arrow.gif width=8 height=7> Documentation</font></td>
 </tr>
      </table>
    </td>
  </tr>
</table>
<?php foot(); ?>
 
