<?php
//////////////////////////////////////////////////////////// 
//  CS OutClick Tracker v1.0.0                             /
//  Copyright (c)2001 Codesmokers                          /
//  URL: http://www.codesmokers.com/                       /
////////////////////////////////////////////////////////////
// A return link to codesmokers.com would be appreciated:  /
// http://www.codesmokers.com/                             /
////////////////////////////////////////////////////////////
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF  /
// ANY KIND, EXPRESS OR IMPLIED. IN NO EVENT SHALL THE     /
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,   /
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF     /
// CONTRACT OR OTHERWISE, ARISING FROM, OUT OF OR IN       /
// CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER        /
// DEALINGS IN THE SOFTWARE.                               /
////////////////////////////////////////////////////////////

// EDIT THE FOLLOWING VARIABLES
#######################################

// set your desired administrative password
$admin_pass = "demo";

// url to click counter directory w/o the trailing slash - ex: http://www.yoursite.com/cstrack
$track_url = "http://www.yoursite.com/cstrack";

// your site title - ex: Your Site
$site_name = "Your Site";

// your mysql server - ex: localhost
$dbhost	= "localhost";

// your mysql username - ex: root
$dbuser	= "username";

// your mysql password
$dbpasswd = "password";

// outclick tracker database name
$dbname = "outclicks";


#######################################
// DO NOT EDIT ANYTHING BELOW THIS LINE 
#######################################

$db=mysql_connect("$dbhost","$dbuser","$dbpasswd");
mysql_select_db("$dbname",$db) or die ("Unable to select database");

$version = "v1.0.0";

// header function
 function head() {
print "<html>\n";
print "<head>\n";
print "<meta http-equiv=\"Content-Language\" content=\"en-us\">\n";
print "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">\n";
print "<title>CS OUTCLICK TRACKER v1.0.0</title>\n";
print "</head>\n";
print "<BODY BGCOLOR=\"#FFFFFF\" TEXT=\"#000000\" LINK=\"#003366\" VLINK=\"#003366\" ALINK=\"#ff0000\" TOPMARGIN=\"8\">\n";
print "<style type=\"text/css\">\n";
print "<!--\n";
print "a:hover   {text-decoration: underline; color: #31639C}\n";
print "a:active  {text-decoration: underline; color: #ff0000}\n";
print " //-->\n";
print "</style>\n";
}

// footer function
 function foot() {

print "<BR><CENTER>\n";
print "<FONT FACE=\"Verdana\" SIZE=\"-2\">CS OutClick Tracker v1.0.0  by <A HREF=\"http://www.codesmokers.com/\">Codesmokers</A>&copy</FONT>\n";
print "</CENTER>\n";
print "</BODY></HTML>\n";
}

?>