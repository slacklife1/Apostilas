<?php
require("shared.inc.php");
//////////////////////////////////////////////////////////// 
//  CS OutClick Tracker v1.0.0                             /
//  Copyright (c)2001 Codesmokers                          /
//  URL: http://www.codesmokers.com/                       /
////////////////////////////////////////////////////////////
// A return link to codesmokers.com would be appreciated:  /
// http://www.codesmokers.com/                             /
//---------------------------------------------------------/
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF  /
// ANY KIND, EXPRESS OR IMPLIED. IN NO EVENT SHALL THE     /
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,   /
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF     /
// CONTRACT OR OTHERWISE, ARISING FROM, OUT OF OR IN       /
// CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER        /
// DEALINGS IN THE SOFTWARE.                               /
////////////////////////////////////////////////////////////

           if ($f == "login") {
           if ($admin == "$admin_pass") {
               Setcookie("admin",$admin_pass);
               Header ("Location: admin.php?f=main");
                } 
           else {
               echo "<center><font size=2 face=verdana color=#ff0000>Invalid password. Please try again.</font></center>";
     }
}
         if ($HTTP_COOKIE_VARS["admin"] == $admin_pass) { 
             echo "<font face=Verdana Arial size=1><a href=admin.php?f=main>main admin page</a></font>";

         if ($f == "main") { 
 
        // make connection to database
        $connection = mysql_connect("$dbhost","$dbuser","$dbpasswd")
              or die("Couldn't make connection to database.");

    	$sql = "SELECT DISTINCT day FROM clicks ORDER BY day DESC";

       // execute SQL query and get result
        $sql_result = mysql_query($sql,$connection)
              or die("Couldn't execute database query.");

        while ($row = mysql_fetch_array($sql_result)) {

       // fetch row and assign variables
        $day  = $row["day"];

       // structure by date form value field
        $stat_dates .= "<OPTION value=\"$day\">--  $day  --</OPTION>\n";

}
head();
?>
<BR>
<CENTER>
<img src="img/header.jpg" height="43" width="398" border="0" ALIGN="CENTER" ALT="CS OUTCLICK TRACKER">
<TABLE WIDTH="400" ALIGN="CENTER" BORDER="0">
<TR><TD ALIGN="center" VALIGN="top">
<font face="Verdana, Arial, Helvetica, sans-serif" size="2">Current Date: <?php echo date ("F jS Y"); ?> &nbsp; &nbsp; Server Time: <?php echo date ("h:ia"); ?></font>
</TD></TR>
</TABLE>
<BR>
<table border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#06044D">
  <tr>
    <td>
      <table border="0" align="center" bgcolor="#FFFFFF" cellspacing="0" cellpadding="5">
        <tr bgcolor="#06044D"> 
          <td align="center"><font size="2" face="verdana, arial" color="#FFFFFF"><b>CS OUTCLICK TRACKER ADMINISTRATION</b></font></td>
        </tr>
 <tr>
  <td bgcolor="#EFEFEF"><font face="verdana, arial" size="2">Home <img src=img/arrow.gif width=8 height=7> <a href="<?php echo $track_url; ?>/help.php">Documentation</a></font></td>
 </tr>
 <tr>
  <td>
<script language="JavaScript">
<!--
function confirm_delete()
{
    if(confirm('Do you really want to delete statistics for this day?'))
    {
        document.stats_delete.submit();
    }
}
//-->
</script>
<form method="get" action="<?php echo $PHP_SELF; ?>">
<input type="hidden" name="f" value="stats">
<table width="450" align="center">
<tr>
<td width="150" align="right"><font face="verdana, arial" size="2"> View Statistics:</font></td>
<td width="250" align="center">
<select name="byday">
<OPTION value="null" selected><-- Choose a Date --></OPTION>
<?php echo "$stat_dates"; ?>
</select>
</td>
<td width="50" align="left">
<input type=submit value="submit">
</td>
</tr>
</form>
</table>

<form method="get" action="<?php echo $PHP_SELF; ?>">
<input type="hidden" name="f" value="delete">
<table width="450" align="center">
<tr>
<td width="150" align="right"><font face="verdana, arial" size="2"> Delete Statistics:</font></td>
<td width="250" align="center">
<select name="byday">
<OPTION value="null" selected><-- Choose a Date --></OPTION>
<?php echo "$stat_dates"; ?>
</select>
</td>
<td width="50" align="left">
<input type=submit value="submit" onClick="confirm_delete(); return false;">
</td>
</tr>
</form>
</table>
</td></tr>

</table>
    </td>
  </tr>
</table>
<BR>
<table border="0" cellpadding="0" cellspacing="0" width="450" align="center">
<tr bgcolor="#06044D"><td align="center">
<table cellspacing="1" cellpadding="3" border="0" width="450" align="center">
<tr><td bgcolor="#06044D" align="center" colspan="2">
<font face="Verdana, Arial" size="2" color="#FFFFFF">CS OUTCLICK TRACKER INFORMATION</font></td>
</tr>
<tr bgcolor="#EFEFEF" width="400" align="left"><td>
<font face="Verdana, arial" size="2">Your Installed Version of CS Outclick Tracker</font>
</td>
<td bgcolor="#ffffff" width="50" align="center">
<font face="Arial" size="2"><?php echo $version; ?></font></td>
</tr>
<tr bgcolor="#EFEFEF" width="400" align="left"><td>
<font face="Verdana, arial" size="2">Latest Available Version of CS Outclick Tracker</font></td>
<td bgcolor="#ffffff" width="50" align="center">
<font face="Arial" size="2">v<img src="http://www.codesmokers.com/scripts/outclick/version/avail_1.gif" width="6" height="10" border="0">.<img src="http://www.codesmokers.com/scripts/outclick/version/avail_2.gif" width="6" height="10" border="0">.<img src="http://www.codesmokers.com/scripts/outclick/version/avail_3.gif" width="6" height="10" alt="" border="0"></font></td>
</tr>
</table>
</TD></TR></TABLE>
</CENTER>

<?php 

mysql_free_result($sql_result);
mysql_close($connection);
foot();
echo "<BR><BR>
<center><a href=\"http://www.codesmokers.com/\"><img src=\"http://www.codesmokers.com/scripts/outclick/msg.gif\" border=\"0\"></a></center>";
 } ?>
<?php
           if ($f == "stats") { 
        $byday = urlencode($byday); 

       // make connection to database
        $connection = mysql_connect("$dbhost","$dbuser","$dbpasswd")
              or die("Couldn't make connection to database.");

        $sql = "SELECT * FROM clicks WHERE day='$byday' GROUP by url";

       // execute query and get result
        $sql_result = mysql_query($sql,$connection)
              or die("Couldn't execute query.");

        while ($row = mysql_fetch_array($sql_result)) {

       // fetch row and assign variables
        $day  = $row["day"];
        $url  = $row["url"];
        $raw  = $row["raw"];
        $uni  = $row["uni"];

       // structure stats by day into stats table
        $option_stats_table .= "<tr>\n 
     <td align=\"left\" width=\"500\" bgcolor=\"#EFEFEF\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\"><a href=\"$url\">$url</a></font></td>\n
     <td align=\"center\" width=\"60\" bgcolor=\"#EFEFEF\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\">$raw</font></td>\n
     <td align=\"center\" width=\"60\" bgcolor=\"#EFEFEF\"><font face=\"Verdana, Arial, Helvetica\" size=\"1\">$uni</font></td>\n
    </tr>\n";
}
head(); ?>
<BR>
<center>
<img src="img/header.jpg" height="43" width="398" border="0" ALIGN="CENTER" ALT="CS OUTCLICK TRACKER">
<TABLE WIDTH="400" ALIGN="CENTER" BORDER="0">
<TR><TD ALIGN="center" VALIGN="top">
<font face="Verdana, Arial, Helvetica, sans-serif" size="2">Current Date: <?php echo date ("F jS Y"); ?> &nbsp; &nbsp; Server Time: <?php echo date ("h:ia"); ?></font>
</TD></TR>
</TABLE>
<BR>
<table border="0" cellpadding="0" cellspacing="0" width="620">
 <tr>
  <td bgcolor="#FFFFFF" align="left" colspan="3"><font face="verdana, arial" size="2"><a href="<?php echo $track_url; ?>/admin.php?f=main">Home</a> <img src=img/arrow.gif width=8 height=7> Statistics</font></td>
 </tr>
 <tr bgcolor="#06044D">
    <td align="center">
<table cellspacing="1" cellpadding="3" border="0" width="100%">
  <tr> 
    <td align="left" width="500" bgcolor="#06044D"><font face="Verdana, Arial, Helvetica" size="2" color="#FFFFFF">TRACKED URLS - <?php echo $byday; ?></font></td>
    <td align="center" width="60" bgcolor="#06044D"><font face="Verdana, Arial, Helvetica" size="2" color="#FFFFFF">RAW</font></td>
    <td align="center" width="60" bgcolor="#06044D"><font face="Verdana, Arial, Helvetica" size="2" color="#FFFFFF">UNIQUE</font></td>
  </tr>

<?php
           if ($byday != "null") { 
              echo "$option_stats_table";
           } 
           else { 
              echo "<tr><td align=\"center\" width=\"620\" colspan=\"3\" bgcolor=\"#EFEFEF\"><center><font size=\"2\" face=\"verdana\"><font color=\"#ff0000\">Invalid Date.</font> Please select a valid date above.</font></center></td></tr>"; 
}
?>
</TABLE>
  </TD>
 </TR>
</TABLE>
</center>

<?php 
mysql_free_result($sql_result);
mysql_close($connection);
foot(); } ?>



<?php 

           if ($f == "delete") { 
        $byday = urlencode($byday);

           if ($byday == "null") {
                     head();
               echo "<font face=\"verdana\" size=\"2\"><font color=\"#FF0000\"><b>ERROR:</b></font> You Must Choose A Valid Date Inorder To Delete Statistics.</font><br><br>";
               echo "<font face=\"verdana\" size=\"1\"><- <a href=\"admin.php?f=main\">Back To The Main Admin Area</a></font>";
               echo "</body></html>";
               }
           else {

       // make connection to database
        $connection = mysql_connect("$dbhost","$dbuser","$dbpasswd")
              or die("Couldn't make connection to database.");

        $sql = "DELETE FROM ip WHERE day='$byday'";
       // execute query and get result

        $sql_result = mysql_query($sql,$connection)
              or die("Couldn't execute query.");


        $sql = "DELETE FROM clicks WHERE day='$byday'";
       // execute query and get result

        $sql_result = mysql_query($sql,$connection)
              or die("Couldn't execute query.");

          if(!$sql_result) {
                     head();
               echo "<font face=\"verdana\" size=\"2\"><font color=\"#FF0000\"><b>ERROR:</b></font> The Selected Statistics Couldn't Be Deleted From The Database.</font><br><br>";
               echo "<font face=\"verdana\" size=\"1\"><- <a href=\"admin.php?f=main\">Back To The Main Admin Area</a></font>";
               echo "</body></html>";
               }
          else {
                     head();
               echo "<font face=\"verdana\" size=\"2\">The Selected Statistics Have Been Deleted From The Database.</font><br><br>";
               echo "<font face=\"verdana\" size=\"1\"><- <a href=\"admin.php?f=main\">Back To The Main Admin Area</a></font>";
               echo "</body></html>";

        }
   }
} 
?>

<BR>


<?php } else { head(); ?>
<BR>
<form method="post" action="<?php echo $PHP_SELF; ?>?f=login">
<p align="center"><img src="img/header.jpg" height="43" width="398" border="0" ALIGN="CENTER" ALT="CS OUTCLICK TRACKER"></p>
<br>
<table border="0" cellpadding="1" cellspacing="0" width="275" align="center">
 <tr bgcolor="#06044D">
  <td align="center">
   <table border="0" cellspacing="0" cellpadding="5" align="center" width="275">
     <tr bgcolor="#06044D"> 
       <td align="center"><font face="verdana, arial" size="2" color="#ffffff"><b>ADMINISTRATIVE LOGIN</b></font></td>
     </tr>
     <tr>
       <td align="center" bgcolor="#EFEFEF"><input type="password" name="admin" size="20"><input type="submit" value="Login"></td>
     </tr>
     <tr>
       <td align="center" bgcolor="#EFEFEF"><font face="Verdana, Arial" size="2">Enter your administrative password</font></td>
     </tr>
   </table>
 </td></tr>
</table>
</form>
<?php foot(); } ?>
