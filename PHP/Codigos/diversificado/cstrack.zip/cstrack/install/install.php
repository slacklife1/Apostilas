<?php
require("../shared.inc.php");
//////////////////////////////////////////////////////////// 
//  CS OutClick Tracker v1.0.0                             /
//  Copyright (c)2001 Codesmokers                          /
//  URL: http://www.codesmokers.com/                       /
////////////////////////////////////////////////////////////
// A return link to codesmokers.com would be appreciated:  /
// http://www.codesmokers.com/                             /
//---------------------------------------------------------/
// THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF  /
// ANY KIND, EXPRESS OR IMPLIED. IN NO EVENT SHALL THE     /
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,   /
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF     /
// CONTRACT OR OTHERWISE, ARISING FROM, OUT OF OR IN       /
// CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER        /
// DEALINGS IN THE SOFTWARE.                               /
////////////////////////////////////////////////////////////

head();
        if($f == "install") {

        // make connection to database
        $connection = mysql_connect("$dbhost","$dbuser","$dbpasswd")
              or die("Couldn't make connection to database.");

        @mysql_select_db( "$dbname") or die( "Unable to select database");
          $create = "CREATE TABLE clicks (day date DEFAULT '0000-00-00' NOT NULL , url varchar(120) NOT NULL , raw int(11) NOT NULL , uni int(11) NOT NULL )";
          $sql_result = mysql_query($create);

          $create = "CREATE TABLE ip (day date DEFAULT '0000-00-00' NOT NULL , url varchar(120) NOT NULL , time timestamp(14) , ipnum varchar(15) NOT NULL )";
          $sql_result = mysql_query($create);

        if(!$sql_result) {
          echo "Something went wrong! The table probably already exists.";
          } 
        else {
          echo "CS Outclick Tracker tables were created and your ready to use the program.<br><br>";
          echo "<a href=\"$track_url/admin.php\" target=\"_top\">Click Here</a> to login to the administration area.<br><br>";
  }
mysql_close($connection);
}
 
        else {
         echo "<center>";
         echo "<a href=\"$PHP_SELF?f=install\">Click Here To Install The Database Tables</a><br><br>";
         echo "</center>";
         foot();
}
?>