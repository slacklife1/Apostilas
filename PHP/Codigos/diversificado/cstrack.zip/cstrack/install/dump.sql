# Host: localhost Database : outclicks
# --------------------------------------------------------
#
# Table structure for table 'clicks'
#
CREATE TABLE clicks (
   day date DEFAULT '0000-00-00' NOT NULL,
   url varchar(120) NOT NULL,
   raw int(11) NOT NULL,
   uni int(11) NOT NULL
);


# --------------------------------------------------------
#
# Table structure for table 'ip'
#
CREATE TABLE ip (
   day date DEFAULT '0000-00-00' NOT NULL,
   url varchar(120) NOT NULL,
   time timestamp(14),
   ipnum varchar(15) NOT NULL
);

