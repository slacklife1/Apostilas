CS Outclick Tracker - Installation

  Quick Install:
    [1] Unzip the archive (be sure to include subdirectories) but you've already
        done this.

    [2] Open the file shared.inc.php in your favorite editor and define
        the variables as explained by the comments.

    [3] Create a directory on your webserver called "cstrack" and upload 
        all .php files in ASCII mode and all image files in BINARY mode.


    [6] Create the mysql database you'll use for CS outclick tracker 
        (default name: "outclicks"). Next you will need to create 2 tables within
        the database you just created, there are a couple of different ways to do this.
          1. you can run the install file from your browser http://yoursite.com/cstrack/install/install.php
          2. we have included a dump.sql file within the install directory for more experienced mysql users.
          3. you can also find database tools to make working with mysql much easier and less time consuming
             at: http://www.hotscripts.com/PHP/Scripts_and_Programs/Database_Tools/

    [7] Once you've completed the above steps point your browser to: 
        http://www.yoursite.com/cstrack/admin.php  to login to the administration area.
 

  Installation notes:

        If you have problems installing CS outclick tracker you can contact us for help
        at: help@codesmokers.com  

        If you experience any bugs with CS outclick tracker please report them to:
            bugs@codesmokers.com