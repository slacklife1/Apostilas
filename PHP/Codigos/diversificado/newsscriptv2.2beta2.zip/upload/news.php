<?
include("db.php");
include("functions.php");
include("settings.php");
       // Verbindung aufbauen, ausw�hlen einer Datenbank
       $link = mysql_connect($DB[sqlhost], $DB[sqluser], $DB[sqlpass])
       or die("Keine Verbindung m�glich!");
       mysql_select_db($DB[sqldb])
       or die("Auswahl der Datenbank fehlgeschlagen");

       // ausf�hren der SQL Anfrage
       $query = "SELECT * FROM news order by zeit DESC";
       $result = mysql_query($query)
       or die("Keine News Vorhanden!");
       $kquery = "SELECT * FROM komentare";
       $kresult = mysql_query($kquery)
       or die("Keine News Vorhanden!");
       // Ausgabe der Ergebnisse in HTML
       $count=1;
       while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
       if($count <= $settings[max]){
$line[news]=parse($line[news]);
echo"<table style='BORDER-COLLAPSE: collapse' borderColor='#000000'"; echo"cellSpacing='0' cellPadding='5' width='500' border='1'><tr>";
echo"<td vAlign='top' width='43%' style='background-color: $settings[thead]'>";
echo" <font face='Verdana' size='1' color='$settings[thfont]'><b>";
echo"<p><b>$line[title]</b><br></font>";
echo"</td></tr><tr>";
echo"<td width='15%' bgcolor='$settings[tbody]'><font color='$settings[tbfont]'>$line[news]</font><BR><BR><BR></br>";
echo"</td></tr></font>";
echo"<tr>";
echo"<td vAlign='top' width='43%' style='background-color: $settings[thead]'>";
echo"<a href='writekomentar.php?news=$line[title]'target=_blank>Komentar schreiben</a>";
echo"<a href='komentar.php?news=$line[title]'target=_blank>  Komentare lesen</a><br></td></tr></table>";
}
$count+=1;
echo"<br>";
}
// schliessen der Verbinung
mysql_close($link);
if($settings[archiv]==1)
{
echo"<center><a href='archiv.php'target=_blank>Newsarchiv</a></center><br>";
}
echo"
Powerd by Dragoransnews v2.2 Beta 1<br>
� 2002 <a href='http://dratini.computerz-place.de/page/'>Dragoranspage</a><br>";
?>
