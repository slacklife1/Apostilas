<?
include("db.php");
include("functions.js");
$x="SELECT * FROM news where title='$news'";
$x=str_replace("'", '"', $x);
// Verbindung aufbauen, ausw�hlen einer Datenbank
       $link = mysql_connect($DB[sqlhost], $DB[sqluser], $DB[sqlpass])
       or die("Keine Verbindung m�glich!");
       mysql_select_db($DB[sqldb])
       or die("Auswahl der Datenbank fehlgeschlagen");
       
       // ausf�hren der SQL Anfrage
       $query = $x;
       $result = mysql_query($query)
       or die("Keine Komentare Vorhanden!");
echo"<form name='send' action='sendeditnews.php?news=$news' method=post>";
while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
echo"<b>$line[title]></b><br>";
include("panel.html");
echo"<table><tr><td>";
include("smilies.php");
echo"</td><td>";
echo"<textarea name=coment cols=60 rows=10>$line[news]</textarea>";
echo"</td></tr></table><br>";
echo"Gib dein Passwort ein: <input type=password name=pass><br>";
echo"<input type=submit value=�ndern>";
echo"</form>";
}
// schliessen der Verbinung
mysql_close($link);
?>