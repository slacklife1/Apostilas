<?
switch($action)
{
        case '2':
                edit();
                break;

        default:
                start();
                break;
}
function start(){
include("settings.php");
echo"
<h3>Einstellungen</h3><br>
<form action=editsettings.php method=post>
<input type=hidden name=action value=2>
<br>News Anzeige:<br>
E-Mail bei neuen Komentaren:<br>
<input type=radio name=mail><br>
Maximale News pro Seite:<br>
<input type=text name=max value='$settings[max]'><br>
News archiv anzeigen:<br>
<input type=radio name=archiv>
<hr><br>";
echo"
<b>Design:</b><br>
Farbe des Tabellenkopfes: <input type=text name=thead value='$settings[thead]'><br>
Hintergrundfarbe der News: <input type=text name=tbody value='$settings[tbody]'><br>
Schriftfarbe des Titels: <input type=text name=thfont value='$settings[thfont]'><br>
Schriftfarbe der News: <input type=text name=tbfont value='$settings[tbfont]'><br>
Dein Passwort: <input type=password name=p><br>
<input type=submit value=Einstellungen �bernehmen></form>";
}
function edit() {
global $mail,$max,$archiv,$thead,$tbody,$thfont,$tbfont,$p;
include("db.php");
if($p!=$db[normalpass])
{
die("VERSCHWINDE!!");
}
if ($mail="on"){
$mail=1;
}
if ($archiv="on"){
$archiv=1;
}
$settings= compact('mail','max','archiv','thead','tbody','thfont','tbfont');
$f=fopen('settings.php','w');
fputs($f,"<?\n");
fputs($f,"$");
fputs($f,"settings");
fputs($f,"=");
fputs($f,"array(\n");
foreach ($settings as $key => $value) {
fputs($f,$key);
fputs($f,"=>");
fputs($f,"'");
fputs($f,$value);
fputs($f,"'");
fputs($f,",\n");
}
fputs($f,")");
fputs($f,";\n");
fputs($f,"?>");
fclose($f);
echo"�nderungen erfolgreich";
}
?>