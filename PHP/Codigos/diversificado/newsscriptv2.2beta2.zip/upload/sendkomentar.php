<?php  
include("settings.php");
       include("db.php");
// Verbindung aufbauen, ausw�hlen einer Datenbank
       $link = mysql_connect($DB[sqlhost], $DB[sqluser], $DB[sqlpass])
       or die("Keine Verbindung m�glich!");
       mysql_select_db($DB[sqldb])
       or die("Auswahl der Datenbank fehlgeschlagen");

       // ausf�hren der SQL Anfrage
 $query = "INSERT INTO `komentare` (`news`, `name`,`text`, `zeit`) VALUES ('$news', '$name','$coment', NOW('')) ";
       $result = mysql_query($query);
       

  
       // schliessen der Verbinung
       mysql_close($link);
if($settings[mail]==1)
{
$mailtext="Neuer Komentar zu $news von $name";
mail($DB[mail], "Neuer Komentar", $mailtext,
"From:$DB[mail]");
}
echo"Dein Komentar wurde eingetragen!";
echo"<br><a href='news.php'>Klicke hier um zu den News zur�ckzukehren</a>";
?>
