<?
include("settings.php");
include("db.php");
include("functions.php");
$y="SELECT * FROM news where title='$news' order by zeit DESC";
$y=str_replace("'", '"', $y);
// Verbindung aufbauen, ausw�hlen einer Datenbank
       $link = mysql_connect($DB[sqlhost], $DB[sqluser], $DB[sqlpass])
       or die("Keine Verbindung m�glich!");
       mysql_select_db($DB[sqldb])
       or die("Auswahl der Datenbank fehlgeschlagen");
       
       // ausf�hren der SQL Anfrage
       $query = $y;
       $result = mysql_query($query)
       or die("Keine Komentare Vorhanden!");

       // Ausgabe der Ergebnisse in HTML
  
       while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
       
$line[news]=parse($line[news]);
echo"<table style='BORDER-COLLAPSE: collapse' borderColor='#000000'"; 
echo"cellSpacing='0' cellPadding='5' width='500' border='1'><tr>";
echo"<td vAlign='top' width='43%' style='background-color: $settings[thead]'>";
echo" <font face='Verdana' size='1' color='$settings[thfont]'><b>";
echo"<p><b>$line[title]</b><br></font>";
echo"</td></tr><tr>";
echo"<td width='15%' bgcolor='$settings[tbody]'><font color='$settings[tbfont]'>$line[news]</font><BR><BR><BR></br>";
echo"</td></tr></font></table>";

}
// schliessen der Verbinung
mysql_close($link);
//end news
echo"<br><hr><br>";

       $x="SELECT * FROM komentare where news='$news' order by zeit DESC";
       $x=str_replace("'", '"', $x);
       // Verbindung aufbauen, ausw�hlen einer Datenbank
       $link = mysql_connect($DB[sqlhost], $DB[sqluser], $DB[sqlpass])
       or die("Keine Verbindung m�glich!");
       mysql_select_db($DB[sqldb])
       or die("Auswahl der Datenbank fehlgeschlagen");
       
       // ausf�hren der SQL Anfrage
       $query = $x;
       $result = mysql_query($query)
       or die("Keine Komentare Vorhanden!");

       // Ausgabe der Ergebnisse in HTML
  
       while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
       
$line[text]=parse($line[text]);
echo"<table style='BORDER-COLLAPSE: collapse' borderColor='#000000'"; echo"cellSpacing='0' 

cellPadding='5' width='500' border='1'><tr>";
echo"<td vAlign='top' width='43%' style='background-color: $settings[thead]'>";
echo" <font face='Verdana' size='1' color='$settings[thfont]'><b>";
echo"<p><b>$line[name]</b><br></font>";
echo"</td></tr><tr>";
echo"<td width='15%' bgcolor='$settings[tbody]'><font color='$settings[tbfont]'>]$line[text]</font><BR><BR><BR></br>";
echo"</td></tr></font></table>";

}
// schliessen der Verbinung
mysql_close($link);
?>
