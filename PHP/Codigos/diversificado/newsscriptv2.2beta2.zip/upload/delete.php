<?
echo"<form action='senddelete.php?news=$news' method=post>";
echo"Passwort eingeben:<input type=password name=pass>";
echo"<input type=submit value=L�schen>";
echo"</form>";
?>