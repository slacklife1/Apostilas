<head>
<script language="JavaScript">
<!-- Hiding

function weiter() {
var Seite = document.edit.news.options.value
document.location.href = Seite
}
//-->
</script>
</head>
<?
include("db.php");
echo"<b>News l�schen:</b>";
echo"<form name='edit'>";
echo"<select name='news' onchange='weiter()'>";
echo"<option value='0'>News ausw�hlen";
// Verbindung aufbauen, ausw�hlen einer Datenbank
       $link = mysql_connect($DB[sqlhost], $DB[sqluser], $DB[sqlpass])
       or die("Keine Verbindung m�glich!");
       mysql_select_db($DB[sqldb])
       or die("Auswahl der Datenbank fehlgeschlagen");

       // ausf�hren der SQL Anfrage
       $query = "SELECT * FROM news order by zeit DESC";
       $result = mysql_query($query)
       or die("Keine News Vorhanden!");
while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
echo"<option value='delete.php?news=$line[title]'>";
echo"$line[title]";
}
// schliessen der Verbinung
mysql_close($link);
echo"</select>";
echo"</form>";
?>

