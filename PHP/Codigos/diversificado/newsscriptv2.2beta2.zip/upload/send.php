<?php
include("db.php");
       //Passwort check
       if($pass!=$DB[normalpass]){
       die("Du hast hier nichts zu suchen");
       }
       
// Verbindung aufbauen, ausw�hlen einer Datenbank
       $link = mysql_connect($DB[sqlhost], $DB[sqluser], $DB[sqlpass])
       or die("Keine Verbindung m�glich!");
       mysql_select_db($DB[sqldb])
       or die("Auswahl der Datenbank fehlgeschlagen");

       // ausf�hren der SQL Anfrage
 $query = "INSERT INTO `news` (`title`, `news`, `zeit`) VALUES ('$title', '$coment', NOW('')) ";
       $result = mysql_query($query);
       

  
       // schliessen der Verbinung
       mysql_close($link);
echo"News erfolgreich eingetragen";

?>