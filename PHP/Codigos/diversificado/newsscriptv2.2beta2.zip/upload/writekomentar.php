<?
include("functions.js");
echo"<form name='send' action='sendkomentar.php?news=$news' method=POST>"; 
echo"Name: <input type=text name=name><br>";
echo"Komentar:<br>";
include("panel.html");
echo"<table><tr><td>";
include("smilies.php");
echo"</td><td>";
echo"<textarea name=coment cols=60 rows=10></textarea></td></tr></table><br>";
echo"<input type=submit value=Eintragen></form>";
?>