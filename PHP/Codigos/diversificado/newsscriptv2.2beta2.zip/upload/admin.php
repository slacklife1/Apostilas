<head>
<?
include("functions.js");
?>
</head>
<form name="send" action=send.php method=post>
Passwort:<input type=password name=pass><br>
Titel:<input type=text name=title><br><br>
News:<br><br>
<input type=button value="Fett" onClick="bbcode('[b][/b]')">
<input type=button value="Kursiv" onClick="bbcode('[k][/k]')">
<input type=button value="Unterstrichen" onClick="bbcode('[u][/u]')">
<input type=button value="Durchgestrichen" onClick="bbcode('[s][/s]')">
<input type=button value="Link" onClick="url()">
<input type=button value="Bild" onClick="img()"><br>
<select name='fcolor'  onchange="alterfont(this.options[this.selectedIndex].value, 'COLOR')">
 <option value='0'>Farbe</option>
 <option value='blue' style='color:blue'>Blau</option>
 <option value='red' style='color:red'>Rot</option>
 <option value='purple' style='color:purple'>Lila</option>
 <option value='orange' style='color:orange'>Orange</option>
 <option value='yellow' style='color:yellow'>Gelb</option>
 <option value='gray' style='color:gray'>Grau</option>
 <option value='green' style='color:green'>Gr�n</option>
 </select>
<input type=button value="Farbtag schliessen" onClick="bbcode('[/color]')">
<br><br>
<table>
<tr>
<td><? include("smilies.php") ?></td><td><textarea name=coment cols=60 rows=10></textarea></td></tr></table>
<br>
<br><input type=submit value=Eintragen><br>
</form>