<script language="JavaScript">
<!-- Hiding

function bbcode(code)
 {
   window.document.send.coment.value =
   window.document.send.coment.value + code;
 }
function url()
 {
   name=window.prompt ("Gib hier den Linknamen ein:","Meine Seite")
   url=window.prompt ("Gib die Adresse ein:","http://")
   code="[url="+url+"]"+name+"[/url]"
   window.document.send.coment.value =
   window.document.send.coment.value + code;
 }

function img()
{
img= window.prompt ("Gib die Adresse vom Bild ein:","http://")
code="[img]"+img+"[/img]"
window.document.send.coment.value =
window.document.send.coment.value + code;
}

bbtags   = new Array();

function stacksize(thearray)
{
        for (i = 0 ; i < thearray.length; i++ )
        {
                if ( (thearray[i] == "") || (thearray[i] == null) || (thearray == 'undefined') )
                {
                        return i;
                }
        }

        return thearray.length;
}

function pushstack(thearray, newval)
{
        arraysize = stacksize(thearray);
        thearray[arraysize] = newval;
}

------------------------------------------

function alterfont(theval, thetag)
{
    if (theval == 0)
    {
            return;
    }
    else
    {
             window.document.send.coment.value += "[" + thetag + "=" + theval + "]";
             pushstack(bbtags, thetag);
    }
    window.document.send.fcolor.selectedIndex = 0;

    window.document.send.focus();
}



//-->
</script>