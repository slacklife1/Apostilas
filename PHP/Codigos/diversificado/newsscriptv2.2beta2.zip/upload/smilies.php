<table border=1 bgcolor=ffffff>
<tr><td>
<a href="javascript:bbcode(':angry')"><img src='img/angry.gif' border="0"></a><br>
</td></tr>
<tr><td><a href="javascript:bbcode(':happy')"><img src='img/happy.gif'border="0"></a><br>
<tr><td><a href="javascript:bbcode(':roll')"><img src='img/rolleyes.gif' border="0"></a><br></td></tr>
<tr><td><a href="javascript:bbcode(':wink')"><img src='img/wink.gif' border="0"></a><br></td></tr>
<tr><td><a href="javascript:bbcode(':flubber')"><img src='img/icon_flubber.gif' border="0"></a><br></td></tr>
<tr><td><a href="javascript:bbcode(':sad')"><img src='img/sad.gif' border="0"></a><br></td></tr>
</td></tr></table>