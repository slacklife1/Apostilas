<?
function parse($coment){
   //zeilen umbruch
$coment= str_replace("\n", "<br>" , $coment);
//Die variable coment auswerten und und bbcodes und smiles einsetzen
//Definiren der bbcodes und Smiles:
//bbcodes
$coment= str_replace("[b]", "<b>", $coment);
$coment= str_replace("[/b]", "</b>", $coment);
$coment= str_replace("[u]", "<u>", $coment);
$coment= str_replace("[/u]", "</u>", $coment);
$coment= str_replace("[k]", "<i>", $coment);
$coment= str_replace("[/k]", "</i>", $coment);
$coment= str_replace("[s]", "<s>", $coment);
$coment= str_replace("[/s]", "</s>", $coment);
$coment= str_replace("[img]", "<img src='", $coment);
$coment= str_replace("[/img]", "'>", $coment);
$coment= str_replace("[COLOR=", "<font color='", $coment);
$coment= str_replace("[/color]", "</font>", $coment);
$coment= str_replace("[url=", "'<a href='", $coment);
$coment= str_replace("[/url]", "'</a>", $coment);
$coment= str_replace("]", "''>", $coment);

//Smilies 
$coment= str_replace(":angry", "<img src='img/angry.gif'>", $coment);
$coment= str_replace(":)", "<img src='img/biggrin.gif'>", $coment);
$coment= str_replace(":happy", "<img src='img/happy.gif'>", $coment);
$coment= str_replace(":roll", "<img src='img/rolleyes.gif'>", $coment);
$coment= str_replace(":wink","<img src='img/wink.gif'>",$coment);
$coment= str_replace(":wub", "<img src='img/wub.gif'>", $coment);
$coment= str_replace(":flubber", "<img src='img/icon_flubber.gif'>", $coment);
$coment= str_replace(":sad", "<img src='img/sad.gif'>", $coment);
return $coment;
}
?>