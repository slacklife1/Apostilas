<?
include("db.php");
//Passwort check
       if($pass!=$DB[normalpass]){
       die("Du hast hier nichts zu suchen");
       }
$y="UPDATE `news` SET news='$coment' where title='$news'";
$y=str_replace("'", '"', $y);
// Verbindung aufbauen, ausw�hlen einer Datenbank
       $link = mysql_connect($DB[sqlhost], $DB[sqluser], $DB[sqlpass])
       or die("Keine Verbindung m�glich!");
       mysql_select_db($DB[sqldb])
       or die("Auswahl der Datenbank fehlgeschlagen");
       
       // ausf�hren der SQL Anfrage
       $query = $y;
       $result = mysql_query($query)
       or die("Daten konnten nicht ge�ndert werden!!!!");
// schliessen der Verbinung
       mysql_close($link);
echo"News erfolgreich editiert";
?>