<?
//Html head
echo"<html>";
echo"<head>";
echo"<title>Dragorans News Installer</title>";
echo"</head>";
//body
echo"<body>";
switch($step)
{
        case '1':
                do_setup_form();
                break;

        case '2':
                do_install();
                break;

        case '3':
                do_finish();
                break;

        default:
                do_intro();
                break;
}
//Willkommens Intro!!
function do_intro(){
echo"<h3><font color='red'>Willkommen dieses Script Installiert Dragorans News v2.2 Beta 1 </font></h3>";
echo"<a href='install.php?step=1'>Weiter zum 1 Schritt</a>";
}
//Installationsformular
function do_setup_form(){
global $sqlhost,$sqluser,$sqlpass,$sqldb,$normalpass,$mail;
echo"
<h4><font color='red'>Schritt 2 von 3</font></h4>
<b>F�lle dieses Formular bitte VOLLST�NDIG aus!</b><br>
<form action=install.php method=post>
<input type='hidden' name='step' value='2'>
Gib dein Mysql host ein:<br>
<input type=text name=sqlhost value=''><br>
Gib dein Mysql Benutzernamen ein:<br>
<input type=text name=sqluser value=''><br>
Gib dein Mysql Passwort ein:<br>
<input type=password name=sqlpass value=''><br>
Gib den Namen der Datenbank ein:<br>
<input type=text name=sqldb value=''><br>
<hr><br>
Passwort f�r News=<br>
<input type=password name=normalpass value=''><br>
Passwort wiederholen:<br>
<input type=password name=checkpass value=''><br>
<hr><br>
Deine Emailadresse:<br>
<input type=text name=mail value=''><br>
<input type=submit value=Installieren><br>
</form>";
}
//Installation Ausf�hren
function do_install() {
global $sqlhost,$sqluser,$sqlpass,$sqldb,$normalpass,$checkpass,$mail;
if($normalpass!=$checkpass)
{
die("Die Passw�rter stimmen nicht �berein. <a href='javascript:history.go(-1)'>Gehe zur�ck</a> um das auszubessern!");
}
//in datei schreiben
$mail="!$mail!";
$mail=str_replace("!", "'", $mail);
$DB=compact('sqlhost','sqluser','sqlpass','sqldb','normalpass','mail');
$f=fopen('db.php','w');
fputs($f,"<?\n");
fputs($f,"$");
fputs($f,"DB");
fputs($f,"=");
fputs($f,"array(\n");
foreach ($DB as $key => $value) {
fputs($f,$key);
fputs($f,"=>");
fputs($f,$value);
fputs($f,",\n");
}
fputs($f,")");
fputs($f,";\n");
fputs($f,"?>");
fclose($f);
// Verbindung aufbauen, ausw�hlen einer Datenbank
       $link = mysql_connect($sqlhost, $sqluser, $sqlpass)
       or die("Keine Verbindung m�glich!");
       mysql_select_db($sqldb)
       or die("Auswahl der Datenbank fehlgeschlagen");
//tabellen erstellen
$query = "CREATE TABLE news (title varchar(100) default NULL, news mediumtext, zeit timestamp(14) NOT NULL)";
$queryb="CREATE TABLE komentare (news varchar(100) default NULL,name varchar(60) default NULL,text text,zeit timestamp(14) NOT NULL)";
$result = mysql_query($query,$link);
if (!$result)
{ die ("Sorry, die Tabelle konnte nicht angelegt werden."); }
echo "Es wurde alles angelegt.";
$resultb = mysql_query($queryb,$link);
if (!$resultb)
{ die ("Sorry, die Tabelle konnte nicht angelegt werden."); }
echo "!!"; 
 mysql_close($link);
echo "<meta http-equiv=\"refresh\" content=\"0;URL=install.php?step=3\">";
}
function do_finish()
{
echo"Die Installation ist abgeschlossen<b> BITTE L�SCHE die Datei install.php!!!</b>";
}
?>