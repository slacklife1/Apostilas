<?php
  include "aclconfig.php";
  if ($HTTP_COOKIE_VARS["ACLADMIN"] == md5($adminuser.$adminpass)) {
	include "acl-connect.php";
	$sql = "INSERT INTO acl_category (CAT_DESC) VALUES ('$cat_desc')";
	$result = mysql_query($sql, $db);
	header("Location: acladmin.php?v=3");
  }
?>
