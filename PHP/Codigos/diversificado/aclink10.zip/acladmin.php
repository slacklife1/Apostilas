<?php
      include "acl-connect.php";

      $pgtitle[0] = "Reports - Overview";
      $pgtitle[1] = "Reports - Top Categories";
      $pgtitle[2] = "Reports - Top Links";
      $pgtitle[3] = "Administration - Categories";
      $pgtitle[4] = "Administration - Links";

      $ClRowEven  = "#EEEEBB";
      $ClRowOdd   = "#DDDDAA";
?>
<html>
<head>
<title> ACLink - Link Click Counter </title>
<style>
   TD.LISTODD		{ font-family : Tahoma,Verdana,Arial,Helvetica,sans-serif; font-size: 9pt; background: #EEEEBB;border-style:solid; border-width:1; border-color:black}
   TD.LISTEVEN		{ font-family : Tahoma,Verdana,Arial,Helvetica,sans-serif; font-size: 9pt; background: #CCCC99;border-style:solid; border-width:1; border-color:black}
   TD.ACL_TITLE		{ font-family : Tahoma,Verdana,Arial,Helvetica,sans-serif; font-size: 10pt; font-weight: bold; background: #8888BB;border-style:solid; border-width:1; border-color:black}
   TD.ACL_MENU		{ font-family : Tahoma,Verdana,Arial,Helvetica,sans-serif; font-size: 9pt; background: #8888BB;border-style:solid; border-width:1; border-color:black}
   TD.ACL_MAIN		{ font-family : Tahoma,Verdana,Arial,Helvetica,sans-serif; font-size: 9pt; background: #FFFFFF; }
   INPUT		{ font-family : Tahoma,Verdana,Arial,Helvetica,sans-serif; font-size: 9pt; }
   SELECT		{ font-family : Tahoma,Verdana,Arial,Helvetica,sans-serif; font-size: 9pt; }
</style>
</head>
<body>

<table width="100%" border=0 cellspacing=0 cellpadding=2>
<tr>
<td colspan=2 class="ACL_TITLE">ACLink - <?php echo $pgtitle[$v] ?></td>
</tr>
<tr>
<!-- Navigation Section -->
<td width=120 class="ACL_MENU" valign="top">
<b>Reports</b><br>
<a href="acladmin.php?v=1">Top Categories</a><br>
<a href="acladmin.php?v=2">Top Links</a><br>
<br>
<b>Administration</b><br>
<a href="acladmin.php?v=3">Categories</a><br>
<a href="acladmin.php?v=4">Links</a><br>
<br>
<a href="acllogout.php">Logout</a><br>
</td>

<!-- Main Section -->
<td width="100%" valign="top" class="ACL_MAIN">
<?php
  if ($HTTP_COOKIE_VARS["ACLADMIN"] != md5($adminuser.$adminpass)) {
	include "acllogin.php";
  } else {
	switch($v) {
		case 1: include "admtopcat.php"; break;
		case 2: include "admtoplink.php"; break;
		case 3: include "admcat.php"; break;
		case 4: if (isset($lnk_url)) include "acladdlink.php";
			include "admlnk.php"; break;
		default: include "acllogin.php"; break;
	}
   }
?>
</td>
</tr>
</table>
</body>
</html>