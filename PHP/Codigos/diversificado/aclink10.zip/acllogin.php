<table width="400" border=0 cellspacing=0 cellpadding=2>
<form action="acldologin.php" method="post">
<tr><td class="ACL_TITLE">Login</td></tr>
<tr><td class="LISTODD">Name <input name="loginuser"> Pass <input type=password name="loginpass"> <input type=submit value="Login"></td></tr>
</form>
</table>
