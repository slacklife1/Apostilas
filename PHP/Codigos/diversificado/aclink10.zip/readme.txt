ACLink 1.0
----------

Requirements:
 - webserver with PHP and MySQL

Setup
----------
 - edit aclconfig.php to the correct values for you.
 - upload all files to your webspace
 - access setup.php
 - if everything went well (no warnings and errors)
   the database and tables are created.
 - delete setup.php from your webspace.
 - access acladmin.php to add your links


Using
----------
 After logging in to the admin script, you can access the various options
 from the menu.
 Currently there are two reports available. The first one, Top Categories,
 shows a list of all categories ordered by the number of clicks in each
 category.
 The other one lists all links ordered by clicks. The most popular links will
 be shown at the top.

 Under Administration there are two options that manage your links and categories.
 With 'Categories' you can add and delete new link categories.
 Note that deleting a category doesn't delete all links that belong to that category,
 you need to do that seperately.
 With 'Links' you can add and delete links.

