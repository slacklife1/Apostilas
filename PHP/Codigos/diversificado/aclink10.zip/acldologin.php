<?php
include "aclconfig.php";

if ( ($loginuser == $adminuser) && ($loginpass == $adminpass) ) {
	$exp  = gmdate ("M d Y H:i:s", time()+24*3600);
	setcookie("ACLADMIN",md5($loginuser.$loginpass),$exp." GMT");
}
header("Location: acladmin.php?v=1");
?>