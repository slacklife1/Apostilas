<table width="400" border=0 cellspacing=0 cellpadding=2>
<form action="acladdcat.php" method="post">
<tr><td class="ACL_TITLE">New Category</td></tr>
<tr><td class="LISTODD">Name <input name="cat_desc"> <input type=submit value="Add"></td></tr>
</form>
</table>
<br>
<table width="400" border=0 cellspacing=0 cellpadding=2>
<tr><td width=50 class="ACL_TITLE">Cat. ID</td><td width=300 class="ACL_TITLE">Category Description</td><td width=50 class="ACL_TITLE">Action</td></tr>
<?php
  $sql = "SELECT * FROM acl_category ORDER BY CAT_ID";
  $result = mysql_query($sql,$db);

  $rowodd = 0;
  while ($row = mysql_fetch_row($result)) {
	if ($rowodd==0) 
		$rowclass = "LISTODD";
	else
		$rowclass = "LISTEVEN";

        echo "<tr><td width=50 class=\"$rowclass\">$row[0]</td><td width=350 class=\"$rowclass\">$row[1]</td><td width=50 class=\"$rowclass\"><a href=\"acldelcat.php?cid=$row[0]\">Del</a></td></tr>"; 
	$rowodd = 1 - $rowodd;
  }
  mysql_free_result($result);
?>

</table>