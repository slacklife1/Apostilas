<table width="400" border=0 cellspacing=0 cellpadding=2>
<tr><td width=350 class="ACL_TITLE">Category Description</td><td width=50 class="ACL_TITLE">Count</td></tr>
<?php
  $sql = "SELECT c.cat_desc, SUM(l.LNK_COUNT) FROM acl_links AS l, acl_category AS c  WHERE l.CAT_ID = c.CAT_ID GROUP BY l.CAT_ID ORDER BY l.LNK_COUNT DESC";
  $result = mysql_query($sql,$db);

  $rowodd = 0;
  while ($row = mysql_fetch_row($result)) {
	if ($rowodd==0) 
		$rowclass = "LISTODD";
	else
		$rowclass = "LISTEVEN";

        echo "<tr><td width=350 class=\"$rowclass\">$row[0]</td><td width=50 class=\"$rowclass\">$row[1]</td></tr>"; 
	$rowodd = 1 - $rowodd;
  }
  mysql_free_result($result);
?>

</table>