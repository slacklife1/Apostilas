<?php
  include "aclconfig.php";
  if ($HTTP_COOKIE_VARS["ACLADMIN"] == md5($adminuser.$adminpass)) {
	include "acl-connect.php";
	$sql = "DELETE FROM acl_links WHERE LNK_ID='$lid'";
	$result = mysql_query($sql, $db);
	header("Location: acladmin.php?v=4");
  }
?>
