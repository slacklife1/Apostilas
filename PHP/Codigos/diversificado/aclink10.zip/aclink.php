<?php
	include "acl-connect.php";

	if (isset($id)) {
		$sql = "SELECT LNK_URL FROM acl_links WHERE LNK_ID='$id'";
		$result = mysql_query($sql,$db);
		if ($row = mysql_fetch_row($result)) {
			$url = $row[0];
			$sql = "UPDATE acl_links SET LNK_COUNT = LNK_COUNT+1 WHERE LNK_ID='$id'";
			$result = mysql_query($sql,$db);
			header("Location: $url");
		} else {
?>
<h3>Invalid link ID</h3>
<hr>
<i><a href="http://apollo.spaceports.com/~refcentr/aclink/index.html">ACLink - Link Click Counter &copy; 2001 BD</a></i>
<?php		
		}
	} else {
?>
<h3>Invalid link ID</h3>
<hr>
<i><a href="http://apollo.spaceports.com/~refcentr/aclink/index.html">ACLink - Link Click Counter &copy; 2001 BD</a></i>
<?php		
	}
?>