<table width="400" border=0 cellspacing=0 cellpadding=2>
<tr><td width=50 class="ACL_TITLE">ID</td><td width=350 class="ACL_TITLE">Link Description</td><td width=50 class="ACL_TITLE">Count</td></tr>
<?php
  $sql = "SELECT * FROM acl_links ORDER BY LNK_COUNT DESC";
  $result = mysql_query($sql,$db);

  $rowodd = 0;
  while ($row = mysql_fetch_row($result)) {
	if ($rowodd==0) 
		$rowclass = "LISTODD";
	else
		$rowclass = "LISTEVEN";

        echo "<tr><td width=50 class=\"$rowclass\">$row[0]</td><td width=350 class=\"$rowclass\">$row[3]</td><td width=50 class=\"$rowclass\">$row[4]</td></tr>"; 
	$rowodd = 1 - $rowodd;
  }
  mysql_free_result($result);
?>

</table>