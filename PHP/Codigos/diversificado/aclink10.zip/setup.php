Creating tables...
<?php
	include "aclconfig.php";

	$db = mysql_connect($mysqlserver,$mysqluser,$mysqlpass);
	if ($db==false) die("<b>setup.php : </b>Failed to connect to MySQL server $mysqlserver<br>\n");
	
	$sql = "CREATE DATABASE $mysqldbname";
	mysql_query($sql,$db);

	if (mysql_select_db($mysqldbname, $db )==false) {
		mysql_close($db);  
		die("<b>setup.php : </b>Failed to select database $mysqldbname on $mysqlserver<br>\n");
	}

	$sql = "CREATE TABLE acl_category (CAT_ID int(11) NOT NULL auto_increment, CAT_DESC tinytext NOT NULL, PRIMARY KEY (CAT_ID), KEY CAT_ID (CAT_ID))";
	mysql_query($sql,$db);

	$sql = "CREATE TABLE acl_links (LNK_ID int(11) NOT NULL auto_increment, CAT_ID int(11) DEFAULT '0' NOT NULL, LNK_URL varchar(128) NOT NULL, LNK_DESC tinytext NOT NULL, LNK_COUNT int(11) DEFAULT '0' NOT NULL, PRIMARY KEY (LNK_ID), KEY LNK_ID (LNK_ID, CAT_ID))";
	mysql_query($sql,$db);
?>
Done.