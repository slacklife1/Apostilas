<?php
 include "aclconfig.php";

 $db = mysql_connect($mysqlserver,$mysqluser,$mysqlpass);

 if ($db==false) 
     die("<b>db-connect.php : </b>Failed to connect to MySQL server $mysqlserver<br>\n");

 if (mysql_select_db($mysqldbname, $db )==false) {
     mysql_close($db);  
     die("<b>db-connect.php : </b>Failed to select database $mysqldbname on $mysqlserver<br>\n");
 }
?>