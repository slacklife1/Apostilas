<?php
  include "aclconfig.php";
  if ($HTTP_COOKIE_VARS["ACLADMIN"] == md5($adminuser.$adminpass)) {
	include "acl-connect.php";
	$sql = "INSERT INTO acl_links (CAT_ID,LNK_URL,LNK_DESC) VALUES ($lnk_cat,'$lnk_url','$lnk_desc')";
	$result = mysql_query($sql, $db);
	header("Location: acladmin.php?v=4");
  }
?>
