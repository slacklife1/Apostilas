<?php
	setcookie("ACLADMIN");
	header("Location: acladmin.php");
?>