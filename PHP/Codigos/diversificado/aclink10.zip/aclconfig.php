<?php 

 $mysqlserver = "localhost";
 $mysqluser = "root";
 $mysqlpass = "";
 $mysqldbname = "aclink";

 $adminuser = "admin";
 $adminpass = "theone";

?>