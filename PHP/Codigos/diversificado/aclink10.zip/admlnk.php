<table width="400" border=0 cellspacing=0 cellpadding=2>
<form action="acladdlink.php" method="post">
<tr><td class="ACL_TITLE">New Link</td></tr>
<tr><td class="LISTODD">Cat:<select name="lnk_cat">
<?php
	$sql = "SELECT * FROM acl_category ORDER BY CAT_DESC";
	$result = mysql_query($sql,$db);
	while ($row = mysql_fetch_row($result)) {
		echo "<option value=$row[0]>$row[1]</option>";
	}
?>
</select>
Desc:<input name="lnk_desc"><br>
URL:<input name="lnk_url" size=40 value="http://"> <input type=submit value="Add">
</td></tr>
</form>
</table>
<br>
<table width="400" border=0 cellspacing=0 cellpadding=2>
<tr><td width=50 class="ACL_TITLE">Link ID</td><td width=300 class="ACL_TITLE">Link</td><td width=50 class="ACL_TITLE">Action</td></tr>
<?php
  $sql = "SELECT * FROM acl_links ORDER BY LNK_ID";
  $result = mysql_query($sql,$db);

  $rowodd = 0;
  while ($row = mysql_fetch_row($result)) {
	if ($rowodd==0) 
		$rowclass = "LISTODD";
	else
		$rowclass = "LISTEVEN";

        echo "<tr><td width=50 class=\"$rowclass\">$row[0]</td><td width=350 class=\"$rowclass\"><a href=\"$row[2]\">$row[3]</a></td><td width=50 class=\"$rowclass\"><a href=\"acldellink.php?lid=$row[0]\">Del</a></td></tr>"; 
	$rowodd = 1 - $rowodd;
  }
  mysql_free_result($result);
?>

</table>