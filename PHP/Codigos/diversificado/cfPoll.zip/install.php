<?

$font = "<font face=Tahoma size=2>";

if (file("poll_ips.dat") && file("poll.dat")) {

$a = `chmod 666 poll_ips.dat`;
$b = `chmod 666 poll.dat`;

system($a);
system($b);

echo "$font<font size=6>cfPoll Setup Complete!";

}

else {

echo "$font FATAL ERROR! One or both of your data files don't exist. Make sure they're there and try again!";

}

?>
