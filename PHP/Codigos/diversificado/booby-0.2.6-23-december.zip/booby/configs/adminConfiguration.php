<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */

/*
 * The email address of the administrator of the site (you? :-)
 */
$adminEmail = 'barry@nauta.be';

/*
 * Set this value to true if users are allowed to sign in, false otherwise
 */
$allowAnonymousSignon = true;

/*
 * Host + path to installation. Must end with a slash
 */
$installationPath = "http://localhost/booby/";

/*
 * The quickmark definition. This is temporary placed here but will be moved to
 * a more decent location in the future...
 */
$quickmark = "javascript:void(open('" . $installationPath . "BookmarkController.php?action=quickmark&locator='+escape(document.location)+'&name='+escape(document.title),'Booby','width=600,height=400,scrollbars=1,resizable=1'));";

/*
 * Defaults. These will be used when a user first signs in
 */
$defaultLanguage = "EN";
$defaultTemplate = "mylook";

/*
 * The render engine to use
 */
$renderEngineName='phpSavant';
//$renderEngineName='Smarty';

?>
