<?php

/**
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */

include_once ('PreferenceOperations.php');


if (!isset ($_SESSION['template']))
{
	$preferenceOperations = new PreferenceOperations ();
	$preferences=$preferenceOperations->getPreferences($_SESSION['username']);
//	print_r ($_SESSION);
	// shortcut only for test user
	// somehow this doesn't work....
//	if ($_SESSION['username'] == 'test')
//	{
//		$_SESSION['template'] = 'mylook';
//		$_SESSION['language'] = 'EN';
//	}
//	else
//	{
		$_SESSION['template'] = $preferences->template;
		$_SESSION['language'] = $preferences->language;
	session_register ();
//	print_r ($_SESSION);
//	}
}
?>
