<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
/*
 * You might want to edit this!!!!
 */
include ("./Smarty-2.5.0/libs/Smarty.class.php");
/**
 * Smarty will sometimes not function correctly when your server is running
 * in safe mode. More info:
 *
 * <code>http://www.php.net/manual/en/features.safe-mode.php</code>
 *
 * Smarty will work in safe mode (usually) if the <code>$use_sub_dirs=false</code>.<br />
 * <code>http://smarty.php.net/manual/en/variable.use.sub.dirs.php</code>
 * 
 * @author Barry Nauta
 * @date April 2003
 * @package be.nauta.booby.view
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <code>http://www.gnu.org</code> 
 * and look for licenses
 */
class MySmarty extends Smarty
{
	/**
	 * Parameterize Smarty by setting your own settings. 
	 */
	function MySmarty ()
	{
		// constructor call
		$this->Smarty();
	
		// The location where Smarty places its compiled files
		// This directory MUST be writeable by Smarty
		//
		// Defaults to <current_dir>/templates_c
		$this->compile_dir='./templates_c';
	
		// Caching option true/false
		// Defaults to true
		$this->caching=true;
	
		//  This is the length of time in seconds that a template cache is
		//  valid. Once this time has expired, the cache will be
		//  regenerated.
		$this->cache_lifetime=1000;
	
		//  This is the name of the directory where template caches are
		//  stored. By default this is "./cache", meaning that it will look
		//  for the cache directory in the same directory as the executing
		//  php script.
		$this->cache_dir='./templates_c';
	
		// Tell smarty whether it should create subdirectories
		// for the templates file.
		//
		// For windows systems: it is better to set this value to true!
		//
		// Defaults to true
		$this->use_sub_dirs=false;
	
		//  Upon each invocation of the PHP application, Smarty tests to see
		//  if the current template has changed (different time stamp) since
		//  the last time it was compiled. If it has changed, it recompiles
		//  that template. If the template has not been compiled, it will
		//  compile regardless of this setting. By default this variable is
		//  set to true. Once an application is put into production
		//  (templates won't be changing), the compile_check step is no
		//  longer needed. Be sure to set $compile_check to "false" for
		//  maximal performance.
		$this->compile_check=true;
	
		//  This forces Smarty to (re)compile templates on every invocation.
		//  This setting overrides $compile_check. By default this is
		//  disabled.
		// 
		//  WARNING!!!!!!
		//
		//  I have had some strange things however (pages not showing) when
		//  this option was set to false
		$this->force_compile=true;
	
		//  This enables the debugging console. The console is a javascript
		//  window that informs you of the included templates and assigned
		//  variables for the current template page.
		//
		//  You probably do not want to change this :-)
		$this->debugging=false;
	}
}
?>
