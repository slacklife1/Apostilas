<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
$languages = array ();
// start the array with English
$languages[] = "EN";
// end the rest in alphabetic order
$languages[] = "DE";
$languages[] = "ES";
$languages[] = "FR";
$languages[] = "NL";
$languages[] = "PL";
$languages[] = "RU";
$languages[] = "TC";
?>
