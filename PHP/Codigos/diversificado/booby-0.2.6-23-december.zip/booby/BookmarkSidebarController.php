<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once ('Controller.php');
require_once ('util/BookmarkUtils.php');
require_once ('model/BookmarkServices.php');
require_once ('model/BookmarkFactory.php');
// only used for the renderEngine setting
include ('configs/adminConfiguration.php');
/**
 * The BookmarkSideBar Controller
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.controller
 * @copyright
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a>
 * and look for licenses
 */
class BookmarkSidebarController extends Controller
{
	/**
	 * Constructor. Makes sure that the appropriate operations are instantiated.
	 */
	function BookmarkSidebarController ($renderEngineName)
	{
		parent::Controller ($renderEngineName);
		$this->operations = new BookmarkServices ();
		$this->itemFactory = new BookmarkFactory ();
	}

	/**
	 * Returns the title of this Controller
	 *
	 * @return string the title of this controller
	 */
	function getTitle ()
	{
		return "Booby - Bookmarks";
	}

	/**
	 * Returns the name of the item that is controller by this controller
	 *
	 * @return string the name of the item that is controlled by this controller
	 */
	function getItemName ()
	{
		return "Bookmark";
	}

	/**
 	 * Returns the actions defined for this item only
 	 *
 	 * @return array an array of item specific actions (like search, import etc.)
 	 */
	function getActions ()
	{
		global $dictionary;
		$actions=array(
			array (
				'name'=> $dictionary['actions'],
				'contents'=>
				array (
					array('href' =>
						'BookmarkController.php',
						'img' =>
						'<img 
						src="templates/sidebar/pics/home.gif"
						border="0">',
						'name' =>
						$dictionary['home']),
					array('href' => 'BookmarkSidebarController.php?action=add&parentId='.$this->getParentId (),
						'img' =>
						'<img 
						src="templates/sidebar/pics/add.gif"
						border="0">',
						'name' =>
						$dictionary['add']),
					array('href' =>
					'BookmarkSidebarController.php',
						'img' =>
						'<img
						src="templates/sidebar/pics/refresh.gif"
						border="0">',
						'name' =>
						$dictionary['refresh'])
					)
				),
			array (
				'name'=> $dictionary['view'],
				'contents' =>
				array (
					array('href' => 'BookmarkSidebarController.php?expand=*',
						'img' =>
						'<img
						src="templates/sidebar/pics/expand.gif"
						border="0">',
						'name' => $dictionary['expand']),
					array('href' => 'BookmarkSidebarController.php?expand=0',
						'img' =>
						'<img
						src="templates/sidebar/pics/collapse.gif"
						border="0">',
						'name' => $dictionary['collapse'])
				)
			)
		);
		return $actions;
	}

	/**
	 * Activate. Basically this means that the appropriate actions are executed and an optional result is returned
	 * to be processed/displayed
	 */
	function activate ()
	{
		switch ($this->getAction ())
		{
			case "add":
				$this->addAction ();
				break;
			case "addBookmark":
				$this->addItemAction ();
				break;
			case "modify":
				$this->modifyAction ();
				break;
			case "modifyBookmark":
				$this->modifyItemAction ();
				$this->getShowItemsParameters ();
				break;
			case "move":
				$this->moveAction ();
				break;
			case "moveItem":
				$this->moveItemAction ();
				$this->getShowItemsParameters ();
				break;
			case "searchBookmarks":
				$this->searchItemAction ();
				break;
			case "deleteBookmark":
				$this->deleteItemAction ();
				$this->getShowItemsParameters ();
				break;
			case "showBookmark":
				$this->operations->updateVisiteCount ($_SESSION['username'], $this->itemId);
				$bookmark = $this->operations->getItem
					($_SESSION['username'], $this->itemId);
				header ("Location: " . $bookmark->locator);
   				exit;
				break;
			case "sort":
				$field = $_GET['field'];
				$this->sortAction ($field);
				$this->getShowItemsParameters ();
				break;
			default:
				$this->getShowItemsParameters ();
				break;
		}
	}

	/**
	 * Returns the list of current expanded items for the controller
	 *
	 * @return string list of commanseperated item numbers
	 */
	function getExpanded ()
	{
		$expand=0;
		if (isset ($_GET['expand']))
		{
			$expand = $_GET['expand'];
			$_SESSION['bookmarkExpand']=$expand;
		}
		else if (isset ($_SESSION['bookmarkExpand']))
		{
			$expand = $_SESSION['bookmarkExpand'];
		}
		return $expand;
	}

	function getTemplate ()
	{
		$template = "sidebar";
		return $template;
	}
}
error_reporting(E_ERROR);
$controller = new BookmarkSidebarController ($renderEngineName);
$controller -> activate ();
$controller -> display ();
?>
