<?php
/**
* 
* Tests the default and example filters for Savant.
* 
* @version $Id: filters.tpl.php,v 1.3 2003/11/11 16:37:49 pmjones Exp $
*
*/
?>


<h1>Filters</h1>





<p>This and that</p>






<p>And the other</p>


<?php
// finally, check the map, we should only have one instance of a filter
?>

_filter_obj: <pre><?php print_r($this->_filter_obj) ?></pre>



<pre><code>
<php>
	// this is a test of PHP colorizing
	echo "some text";
	highlight_string("something");
	$variable = 'value';
	
	function fester()
	{
		// does nothing
	}
</php>
</code></pre>


<!-- end -->