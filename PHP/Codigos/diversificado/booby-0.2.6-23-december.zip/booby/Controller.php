<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include ('util/checkLogin.php');
include_once ('configs/preferenceConfiguration.php');
include ('menuItems.php');
include ('lang/dictionary_' . $_SESSION['language'] . '.php');
// Savant or Smarty includes in the constructor
/**
 * The Controller (abstract base class)
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.controller
 * @copyright
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <code>http://www.gnu.org</code>
 * and look for licenses
 */
class Controller
{
	/**
	 * The template engine
	 * @private
	 * @variable object renderEngine
	 */
	var $renderEngine;

	/**
	 * The name of template engine (either Smarty or phpSavant)
	 * @private
	 * @variable string renderEngineName
	 */
	var $renderEngineName;

	/**
	 * The current action that is being processed
	 * @variable string action
	 */
	var $action;

	/**
	 * The identifier of the current item
	 * @variable integer itemId
	 */
	var $itemId;

	/**
	 * The identifier of the current item's parent
	 * @variable integer parentId
	 */
	var $parentId;

	/**
	 * Parameters, placeholder for almost anything
	 * @variable hashtable parameters
	 */
	var $parameters;

	/**
	 * The operations class
	 * @see Operations
	 * @variable object operations
	 */
	var $operations;

	/**
	 * The name of the renderer that will be used for processing
	 * @variable string renderer
	 */
	var $renderer;

	/**
	 * The objects that are the result of the action. The renderer typically
	 * renders these objects
	 * @variable array renderObjects
	 */
	var $renderObjects;

	/**
	 * The factory used to construct dedicated items
	 * @variable object itemFactory
	 */
	var $itemFactory;

	/**
	 * Constructor. Fetches the action, the itemId and the parentId from 
	 * the request and assigns these parameters to the controller
	 * @param string theRenderEngine the renderEngine to use 
	 * (currently Smarty and phpSavant are supported)
	 */
	function Controller ($theRenderEngine)
	{
		$this->renderEngineName = $theRenderEngine;
		$this->itemId = 0;
		$this->parentId = 0;
		$this->parameters = array ();
 		// Fetch the action parameter from the request
		if (isset ($_GET['action']))
		{
			$this->action = $_GET['action'];
		}
		else if (isset ($_POST['action']))
		{
			$this->action = $_POST['action'];
		}
 		// Fetch the itemId parameter
		if (isset ($_GET['itemId']))
		{
			$this->itemId = $_GET['itemId'];
		}
		else if (isset ($_POST['itemId']))
		{
			$this->itemId = $_POST['itemId'];
		}
 		// Fetch the parentId parameter
		if (isset ($_GET['parentId']))
		{
			$this->parentId = $_GET['parentId'];
		}
		else if (isset ($_POST['parentId']))
		{
			$this->parentId = $_POST['parentId'];
		}
		// Instantiate the appropriate engine based on the declared name
		if ($this->renderEngineName == 'phpSavant')
		{
			include ('Savant-1.2/Savant.php');
			$this->renderEngine =& new Savant ();
		}
		else
		{
			include ('configs/MySmarty.php');
			$this->renderEngine = new MySmarty ();
		}
	}

	/**
	 * Returns the specific title for this Controller
	 * Abstract function.
	 *
	 * @return string title of this controller
	 */
	function getTitle ()
	{
		return null;
	}

	/**
	 * Returns the specific URL for this Controller
	 *
	 * @return string URL of this controller
	 */
	function getURL ()
	{
		return $this->getItemName () . "Controller.php";
	}

	/**
	 * Returns the name of the item that is controller by this controller
	 * Abstract function.
	 *
	 * @return string the name of the item that is controlled by this 
	 * controller
	 */
	function getItemName ()
	{
		return null;
	}

	/**
	 * Returns the template that is currently in use
	 *
	 * @return string the template that is currently in use
	 */
	function getTemplate ()
	{
		return $_SESSION['template'];
	}

	/**
	 * Returns the name of the renderer that will be used
	 * for further processing
	 *
	 * @return string the renderer
	 */
	function getRenderer ()
	{
		if ($this->renderEngineName == 'Smarty')
		{
			return $this->renderer.'.tpl';
		}
		else
		{
			return $this->renderer.'.tpl.php';
		}
	}

	/**
	 * Returns the renderobjects that will be displayed
	 *
	 * @return array the render objects
	 */
	function getRenderObjects ()
	{
		return $this->renderObjects;
	}

	/**
	 * Sets the action that is requested by the user
	 *
	 * @param string theAction the requested action
	 */
	function setAction ($theAction)
	{
		$this->action = $theAction;
	}

	/**
	 * Returns the action that is requested by the user
	 *
	 * @return string theAction the requested action
	 */
	function getAction ()
	{
		return $this->action;
	}

	/**
	 * Retrieves the parentId of the item that is currently in use
	 *
	 * @return integer the parentId that is currently in use
	 */
	function getParentId ()
	{
		return $this->parentId;
	}

	/**
	 * Retrieves the itemId that is currently in use
	 *
	 * @return integer the itemId that is currently in use
	 */
	function getItemId ()
	{
		return $this->itemId;
	}

	/**
  	 * Returns the actions defined for this item only
	 * Abstract function.
 	 *
 	 * @return array an array of item specific actions (like search, 
	 * import etc.)
 	 */
	function getActions ()
	{
		return null;
	}

	/**
	 * Add a parameter to the existing parameter hashTable
	 *
	 * @param string key the key for the parameter
	 * @param string value the value of the parameter
	 */
	function addParameter ($key, $value)
	{
		$this->parameters [$key] = $value;
	}

	/**
	 * Display which basically means that the template will be invoked
	 */
	function display ()
	{
		global $menuItems, $menu, $dictionary;

		$this->renderEngine->assign('title', $this->getTitle ());
		$this->renderEngine->assign('menuItems', $menuItems);
		$this->renderEngine->assign('menu', $menu);
		$this->renderEngine->assign('dictionary', $dictionary);

		$this->renderEngine->assign('itemId', $this->getItemId ());
		$this->renderEngine->assign('parentId', $this->getParentId ());
		$this->renderEngine->assign('item',
			$this->getItem ($_SESSION['username'], 
			$this->getItemId ()));
		$this->renderEngine->assign('parent',
			$this->getItem ($_SESSION['username'], 
			$this->getParentId ()));
		$this->renderEngine->assign('parameters', 
			$this->getParameters ());
		$this->renderEngine->assign('action', 
			$this->getAction ());

		$this->renderEngine->assign('renderObjects', 
			$this->getRenderObjects ());
		$this->renderEngine->assign('renderActions', 
			$this->getActions ());
		$this->renderEngine->assign('template', 
			$this->getTemplate ());

		if ($this->renderEngineName == 'phpSavant')
		{
			if (file_exists ('templates/'.
				$this->getTemplate () . '/' . 
				$this->getRenderer ()))
			{
				$this->renderEngine->assign('renderer', 
				$this->getRenderer ());
			}	
			else
			{
				$this->renderEngine->assign('renderer', 
				'templates/common/' . $this->getRenderer ());
			}
			$this->renderEngine->display('templates/'.$this->getTemplate().'/template.tpl.php');
		}
		else
		{
			if ($this->renderEngine->template_exists (
				$this->getTemplate () . '/' . 
				$this->getRenderer ()))
			{
				$this->renderEngine->assign('renderer', 
				$this->getTemplate () . '/' . 
				$this->getRenderer ());
			}
			else
			{
				// default to common if the template does not exist
				$this->renderEngine->assign('renderer', 'common/' . $this->getRenderer ());
			}
			if (isset ($_GET['debug']))
			{
				$this->renderEngine->debugging=true;
				$this->renderEngine->debug_tpl='debug.tpl';
				$this->renderEngine->_renderEngine_debug_id='SMARTY_DEBUG';
				$this->renderEngine->_renderEngine_debug_info=array();
				$this->renderEngine->display($this->getTemplate () . '/' . 'template.tpl');
			}
			else
			{
				@$this->renderEngine->display(
					$this->getTemplate (). '/template.tpl');
			}
		}
	}


	/**
	 * Returns this controllers parameters
	 *
	 * @return hashtable the parameters (key/value based)
	 */
	function getParameters ()
	{
		return $this->parameters;
	}

	/**
	 * Returns the factory that knows how to create dedicated items
	 *
	 * @return object the item factory
	 */
	function getItemFactory ()
	{
		return $this->itemFactory;
	}

	/**
	 * Gets a specific item for a user (request is forwarded to the 
	 * operations class)
	 *
	 * @param string userId the identifier for the user
	 * @param string itemId the identifier for the item
	 * @return object the item for specified user with specified itemId
	 */
	function getItem ($userId, $itemId)
	{
		return $this->operations->getItem ($userId, $itemId);
	}

	/**
	 * Adds an item for a user (request is forwarded to the operations
	 * class)
	 *
	 * @param integer userId the identifier for the user
	 * @param object item the item to be added
	 */
	function addItem ($userId, $item)
	{
		return $this->operations->addItem ($userId, $item);
	}

	/**
	 * Retrieves the children of a specified item (request is forwarded 
	 * to the operations class)
	 *
	 * @param string userId the identifier of the user that issues the
	 * request
	 * @param integer itemId the identifier of the item for which we would
	 * like to have its children
	 * @return array all children for specified user and itemId
	 */
	function getChildren ($userId, $itemId)
	{
		return $this->operations->getChildren ($userId, $itemId);
	}

	/**
	 * Default action to add an item
	 */
	function addAction ()
	{
		$this->renderer = 'add'.$this->getItemName();
		$this->renderObjects = $this->operations->getItem
			($_SESSION['username'], $this->getParentId ());
	}

	/**
	 * Items parameters has been provided, now really add it
	 * #protected
	 */
	function addItemAction ()
	{
		$item = $this->itemFactory->requestToItem ();
		// in fact, the controller should not check for validity
		if ($item->isValid ())
		{
			$this->operations->addItem ($_SESSION['username'], 
				$item);
		}
		else
		{
			die ("Not valid");
		}
		$this->getShowItemsParameters ();
	}

	/**
	 * Default modify Action
	 */
	function modifyAction ()
	{
		$this->renderer = 'modify'.$this->getItemName ();
		$this->renderObjects =	$this->operations->
			getItem ($_SESSION['username'],	$this->itemId);
	}

	/**
	 * Items parameters has been provided, no really modify it
	 * #protected
	 */
	function modifyItemAction ()
	{
		$item=$this->itemFactory->requestToItem ();
	   	$this->operations->modifyItem($_SESSION['username'], $item);
	}


	/**
	 * Search for items
	 * #protected
	 */
	function searchItemAction ()
	{
	    $this->renderObjects = $this->operations->searchItems
   				($_SESSION['username'], 
				$_POST['field'], $_POST['value']);
		$this->renderer = 'show'.$this->getItemName ().'s';
	}

	/**
	 * Default move action
	 * #protected
	 */
	function moveAction ()
	{
		// this is a shortcut. Give the first descendants of the root
		// as renderObjects. These will be evaluated afterwards...
		// Of course, the tree needs to be totally expanded
		$root = $this->getItem ($_SESSION['username'], 0);
		$rootItems = $this->operations->getChildrenThatAreParent
			($_SESSION['username'], $root->itemId);

		for ($i=0; $i<count($rootItems); $i++)
		{
			$this->addChildrenThatAreParent ($rootItems[$i]);
		}
		$this->renderObjects = $rootItems;
		$this->item = $this->operations->getItem ($_SESSION['username'],
				$this->itemId);
		$this->renderer = 'move'.$this->getItemName ();
	}

	/**
	 * Items parameters have been provided, now really move it
	 * #protected
	 */
	function moveItemAction ()
	{
		$this->operations->moveItem ($_SESSION['username'],
			$this->itemId,	$this->parentId);
	}

	/**
	 * Items parameters has been provided, no really delete
	 * #protected
	 */
	function deleteItemAction ()
	{
		$this->operations->deleteItem ($_SESSION['username'], 
			$this->itemId);
	}

	/**
	 * Retrieves the parameters for a normal 'show' action which is
	 * often requested after another action (like delete/modify)
	 */
	function getShowItemsParameters ()
	{
		$this->renderer = 'show'.$this->getItemName().'s';
		$rootItems = $this->operations->getChildren
			($_SESSION['username'], $this->getParentId ());

		$expand = $this->getExpanded ();
		if ($expand != null)
		{
			$this->addParameter ("expand", $expand);
		}

		for ($i=0; $i<count($rootItems); $i++)
		{
			$this->addExpandedChildren ($rootItems[$i]);
		}
		$this->renderObjects = $rootItems;
	}

	/**
	 * Sorts the items based on specified criteria
	 * @param string field the field on which we would like to sort
	 * @param sortOrder either <code>ASC</code> or <code>DESC</code>
	 */
	function sortAction ($field, $sortOrder)
	{
		$this->renderer = 'show'.$this->getItemName().'s';
		$this->renderObjects = $this->operations->getSortedItems (
				$_SESSION['username'], $field, $sortOrder);		
	}
	
	/**
	 * Adds the children of this item in the array, but only if this item
	 * is expanded itself
	 * @private
	 *
	 * @param object item the item
	 */
	function addExpandedChildren (&$item)
	{
		if ($item->isParent () && $this->isExpanded ($item->itemId))
		{
			$items = $this->operations->getChildren
				($_SESSION['username'],$item->itemId);
			for ($i=0; $i<count($items); $i++)
			{
				$this->addExpandedChildren ($items[$i]);
				$item->addChild ($items[$i]);
			}
		}
	}

	/**
	 * Adds the children of this item in the array
	 * @private
	 *
	 * @param object item the item
	 */
	function addChildrenThatAreParent (&$item)
	{
		if ($item->isParent ())
		{
			$items = $this->operations->getChildrenThatAreParent
				($_SESSION['username'],$item->itemId);
			for ($i=0; $i<count($items); $i++)
			{
				$this->addChildrenThatAreParent ($items[$i]);
				$item->addChild ($items[$i]);
			}
		}
	}

	/**
	 * returns whether the specified itemId is expanded
	 * @private
	 *
	 * @param integer itemId the identifier which needs to be checked
	 * @return boolean <code>true</code> if this id is in the expanded 
	 * list, <code>false</code> otherwise
	 */
	function isExpanded ($itemId)
	{
		$expanded = explode (",", $this->getExpanded ());
		if ($this->getExpanded () == null)
		{
			return false;
		}
		// wildcard implementation
		if (count ($expanded == 1) && $expanded[0] == "*")
		{
			return true;
		}
		while (list ($key, $val) = each($expanded))
		{
			// yep, in the expanded list
			if ($val == $itemId)
			{
				// we might want to remove it from
				// the expanded list and put it in
				// the parsedExpanded list
				return true;
			}
		}
        	return false;
	}

}
?>
