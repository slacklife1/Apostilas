<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
session_start();

/*
 * Clean up the session...
 */
unset($_SESSION['username']);
session_destroy();

/*
 * Clear the Cookie information by setting its expiration date in the past
 */
setCookie ("Booby", "", time () -3600);

/*
 * Forward to login page
 */
header('Location: login.php');
exit;
?>
