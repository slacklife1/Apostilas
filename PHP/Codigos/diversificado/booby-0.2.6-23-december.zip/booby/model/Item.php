<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
/**
 * Abstract base class Item.
 *
 * @author Barry Nauta
 * @date July 2003 
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class Item
{
	/**
	 * The type of the item 
	 * #protected
	 * @variable string type
	 */
	var $type;
	
	/**
	 * The owner of the item
	 * #protected
	 * @variable string owner
	 */
	var $owner;

	/**
	 * The id of the item
	 * #protected
	 * @variable integer itemId
	 */
	var $itemId;

	/**
	 * The identifier of the item's parent
	 * #protected
	 * @variable integer parentId
	 */
	var $parentId;

	/**
	 * The identifier that indicated whether the item is a parent itself
	 * #protected
	 * @variable boolean isParent
	 */
	var $isParent;

	/**
	 * The name of the item
	 * #protected
	 * @variable string name
	 */
	var $name;

	/**
	 * The description of the item
	 * #protected
	 * @variable string description
	 */
	var $description;

	/**
	 * The date when the item was created
	 * #protected
	 * @variable string when_created
	 */
	var $when_created;

	/**
	 * The date when the item was last modified
	 * #protected
	 * @variable string when_modified
	 */
	var $when_modified;

	/**
	 * The visibility of the item
	 * #protected
	 * @variable string visibility 
	 */
	var $visibility;

	/**
	 * The category of the item
	 * #protected
	 * @variable string category
	 */
	var $category;

	/**
	 * The children of this item
	 * @private
	 * @variable array children
	 */
	var $children;
	
	/**
	 * Default constructor, sets the creation date
	 */
	function Item ()
	{
		$now = date ("Y-m-d H:i:s");
		$this->creation = $now;
		$this->children = array ();
	}

	/**
	 * Checks whether the constructed item is a valid item (has all the
	 * required fields)
	 *
	 * @return boolean true if the item is valid, false otherwise
	 */	
	function isValid ()
	{
		// cannot be root and must have a name
		if ($this->itemId == null)
		{
			return $this->name != null;
		}
		else
		{
			return $this->itemId != 0 && $this->name != null;
		}
	}
	
	/**
	 * Returns a human readable representation of this object
	 * @return string a human readable representation of this object
	 */
	function toString ()
	{
		return null;
	}
	
	/**
	 * Returns the children of this item
	 *
	 * @return array children the children (which are items!) of this item
	 */
	function getChildren ()
	{
		return $this->children;
	}
	
	/**
	 * Adds a child (which is an item!) to the list of children of this item
	 * 
	 * @param object child the child to be added
	 */
	function addChild (&$child)
	{
		$this->children [] = $child;
	}
	
	/**
	 * Returns whether this item is a parent
	 *
	 * @return boolean true if this item is a parent, false otherwise
	 */
	function isParent ()
	{
		return $this->isParent;
	}

	/**
	 * Returns a HTML table representation of this object
	 * by creating a table which lists the item's vars and
	 * resp. values
	 * @return string an HTML representation of this object
	 */
	function toHTML ()
	{
		$result  = ('<table border="0">\n');
		$result .= ('<tr>\n');

		//array $vars=get_class_vars($this);
		//$class_vars = get_class_vars(get_class($my_class));
		$vars = get_object_vars ($this);
		foreach ($vars as $name => $value)      
		{
			echo ('<td>'.$name.'</td>');
			if ($name == 'url')
			{
				echo ('<td><a href="'.$value.'">'.$value.'"</a></td>');
			}
			else
			{
				echo ('<td>'.$value.'</td>');
			}
		}
		$result .= ('</tr>\n');
		$result .= ('</table>\n');
		return $result;
	}
}
?>
