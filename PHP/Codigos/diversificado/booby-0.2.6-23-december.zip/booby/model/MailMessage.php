<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once ('Item.php');
/**
 * A mailmessage item
 * 
 * @author Barry Nauta
 * @date October 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class MailMessage extends Item
{
	/**
	 * The from address
	 * @private
	 * @variable string from
	 */
	var $from;

	/**
	 * The To: list
	 * @private
	 * @variable array 
	 */
	var $to;

	/**
	 * The Cc: list
	 * @private
	 * @variable array 
	 */
	var $cc;

	/**
	 * The Bcc: list
	 * @private
	 * @variable array 
	 */
	var $bcc;

	/**
	 * The reply-to address
	 * @private
	 * @varaible string reply-to the reply-to address
	 */
	var $replyTo; 

	/**
	 * The date (timestamp) of this message
	 * @private
	 * @variable date date
	 */
	var $date;

	/**
	 * TBD X-mail of zoiets
	 */
	var $xMailer = "[Booby - mail (http://www.nauta.be/booby)]";

	/**
	 * The subject
	 * @private
	 * @variable string subject the Subject
	 */
	var $subject;

	/**
	 * The email body (the text)
	 * @private
	 * @variable string body
	 */
	var $body;

	/**
	 * Attachments
	 * @private
	 * @variable array attachments
	 */
	var $attachments;

	/**
	 * Constructor
	 */
	function MailMessage ($theFrom, $theTo, $theCC, $theBcc, 
		$theReplyTo, $theDate, $theSubject, $theBody,
		$theAttachments)
	{
		parent :: Item ();

		$this->from = $theFrom;
		$this->to = $theTo;
		$this->cc = $theCC;
		$this->bcc = $theBcc;
		$this->replyTo = $theReplyTo;
		$this->date = $theDate;
		$this->subject = $theSubject;
		$this->body = $theBody;
		$this->attachments = $theAttachments;
	}

	/**
	 * Returns a human readable representation of this object
	 * @return string a human readable representation of this object
	 */
	function toString ()
	{
		$result  = "[MailMessage]";
		$result .= " isParent: " . $this->isParent;
		$result .= " parentId: " . $this->parentId;
		$result .= " Name: " . $this->name;
		return $result;
	}
}
?>
