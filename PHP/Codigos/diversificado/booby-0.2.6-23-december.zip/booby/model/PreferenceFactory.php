<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
//require_once ('ItemFactory.php'); 
/**
 * PreferencesFactory
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class PreferenceFactory // extends ItemFactory
{
		/**
		 * Default constructor
		 */
	function PreferenceFactory ()
	{
		//parent::ItemFactory();
	}
	
		/**
		 * Factory method. Return an HTTP request into an item by fecthing
		 * the appropriate parameters from the POST request
		 *
		 * @return object the item constructed from the POST request
		 */
	function requestToPreferences ()
	{
		if (isset ($_POST['owner']))
		{
			$owner = $_POST['owner'];
		}
		else
		{
			$owner = null;
		}
			$item=new Preference (
					$owner,
					$_POST['language'],
					$_POST['template']);
			return $item;
	}
	
		/**
		 * Factory method: Returns a database result into an item
		 *
		 * @param object result the result retrieved from the database
		 * @return array the items constructed from the database resultset
		 */
	function resultsetToPreferences ($result)
	{
		$item = new Preference(
	            $result->fields[0], 
	            $result->fields[1], 
	            $result->fields[2]
	    );      
	    return $item;
	}
		
}
?>