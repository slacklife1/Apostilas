<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once ('Item.php');
/**
 * A contact item
 * 
 * @author Barry Nauta
 * @date March 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class Contact extends Item
{
	/**
	 * The alias for the contact
	 * @private
	 * @variable string alias 
	 */
	var $alias;
	
	/**
	 * The address of the contact
	 * @private
	 * @variable string address 
	 */
	var $address;
	
	/**
	 * The birthday of the contact (not used yet)
	 * @private
	 * @variable string birthday
	 */
	var $birthday;
	
	/**
	 * The mobile telephone number (GSM) of the contact
	 * @private
	 * @variable string mobile
	 */
	var $mobile;
	
	/**
	 * The fax number of the contact
	 * @private
	 * @variable string faximile
	 */
	var $faximile;
	
	/**
	 * Telephone number at work of the contact
	 * @private
	 * @variable string telephoneWork
	 */
	var $telephoneWork;

	/**
	 * Telephone number at home of the contact
	 * @private
	 * @variable string telephoneHome
	 */
	var $telephoneHome;
	
	/**
	 * The organization for which the contacts works
	 * @private
	 * @variable string organization
	 */
	var $organization;
	
	/**
	 * The address of the organization for which the contact works
	 * @private
	 * @variable string organizationAddress
	 */
	var $organizationAddress;
	
	/**
	 * The contacts jobtitle
	 * @private
	 * @variable string jobTitle
	 */
	var $job;

	/**
	 * The first email address of the contact
	 * @private
	 * @variable string email1
	 */
	var $email1;
	
	/**
	 * The second email address of the contact
	 * @private
	 * @variable string email2
	 */
	var $email2;
	
	/**
	 * The third email address of the contact
	 * @private
	 * @variable string email3
	 */
	var $email3;
	
	/**
	 * Full blown constructor with all parameters
	 *
	 * @param integer theItemId the id of the item
	 * @param string theOwner who owns this item?
	 * @param integer theParentId what is the id of the parent of this item?
	 * @param boolean parent is this a parent (true) or child (false)
	 * @param string theName the name of this item
	 * @param string theDescription the description of this item
	 * @param string theVisibility the visibility (private or public)
	 * @param string theCategory what is the category of this item?
	 * @param string created When was this item created?
	 * @param string modified When was this item modified?
	 * @param string theAlias the alias of this contact
	 * @param string theAddress The address of the contact
	 * @param string theBirthday The birthday of the contact
	 * @param string theMobile mobile telephone number (GSM) of the contact
	 * @param string theFax the fax number of the contact
	 * @param string theTelHome Telephone number at home of the contact
	 * @param string theTelWork Telephone number at work of the contact
	 * @param string theOrganization organization for which the contacts works
	 * @param string theOrganizationalAddress address of the organization for 
	 *			which the contact works
	 * @param string theJobTitle The contacts jobtitle
	 * @param string theEmail1 first email address of the contact
	 * @param string theEmail2 second email address of the contact
	 * @param string theEmail3 third email address of the contact
	 * @param string theWebAddress1 first webaddress
	 * @param string theWebAddress2 second webaddress
	 * @param string theWebAddress3 third webaddress
	 */
	function Contact ($theItemId, $theOwner, $theParentId,
		$parent, $theName, $theDescription, $theVisibility,
		$theCategory, $theCreation, $theModified, 
		$theAlias,
		$theAddress, $theBirthday, $theMobile, $theFax, 
		$theTelHome, $theTelWork, 
		$theOrganization, $theOrganizationalAddress,
		$theJobTitle, 
		$theEmail1, $theEmail2, $theEmail3,
		$theWebaddress1, $theWebaddress2, $theWebaddress3)
	{
		parent :: Item ();
		
		$this->type="Contact";
		$this->itemId=$theItemId;
		$this->parentId=$theParentId;
		$this->isParent=$parent;
		$this->owner=$theOwner;
		$this->name=$theName;
		$this->job=$theJobTitle;
		$this->telephoneHome=$theTelHome;
		$this->telephoneWork=$theTelWork;
		$this->mobile=$theMobile;
		$this->faximile=$theFax;
		$this->address=$theAddress;
		$this->organization=$theOrganization;
		$this->organizationAddress=$theOrganizationalAddress;
		$this->birthday=$theBirthday;
		$this->alias=$theAlias;
		$this->creation=$theCreation;
		$this->visibility=$theVisibility;
		$this->description=$theDescription;
		$this->email1=$theEmail1;
		$this->email2=$theEmail2;
		$this->email3=$theEmail3;
		$this->webaddress1=$theWebaddress1;
		$this->webaddress2=$theWebaddress2;
		$this->webaddress3=$theWebaddress3;
	}

	/**
	 * Returns a human readable representation of this object
	 * @return string a human readable representation of this object
	 */
	function toString ()
	{
		$result  = "[Contact]";
		$result .= " isParent: " . $this->isParent;
		$result .= " parentId: " . $this->parentId;
		$result .= " Name: " . $this->name;
		$result .= " Address: " . $this->address;
		$result .= " BirthDay: " . $this->birthday;
		$result .= " Mobile: " . $this->mobile;
		$result .= " Fax.: " . $this->faximile;
		$result .= " Tel_work: " . $this->telephoneWork;
		$result .= " Tel_home: " . $this->telephoneHome;
		$result .= " Organization: " . $this->organization;
		$result .= " Job: " . $this->job;
	 	$result .= ' #children: ' . count($this->children);
		return $result;
	}
}
?>
