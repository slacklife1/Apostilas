<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
/**
 * User preferences.
 * 
 * @author Barry Nauta
 * @date March 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class Preference
{
	/**
	 * The language that the owner (user) preferes
	 * @private
	 * @variable string language
	 */
	var $language;
	
	/**
	 * The template that the owner (user) preferes
	 * @private
	 * @variable string template
	 */
	var $template;
	
	/**
	 * The owner to which these preferences 'belong'
	 * @private
	 * @variable string owner
	 */
	var $owner;

	/**
	 * Full-blown constructor
     * 
	 * @param string theOwner the 'owner' of these preferences
	 * @param string theLanguage the language embedded in these preferences
	 * @param string theTemplate the template embedded in these preferences
 	 */
	function Preference ($theOwner, $theLanguage, $theTemplate)
	{
		$this->owner=$theOwner;
		$this->language=$theLanguage;
		$this->template=$theTemplate;
	}

	/**
  	 * Returns a human readable presentation of this item
  	 * @return string a human readable presentation of this item
     */
	function toString ()
	{
		$result  = "[Preferences]";
		$result .= " Owner: " . $this->owner;
		$result .= " Language: " . $this->language;
		$result .= " Template: " . $this->template;
		return $result;
	}
	
	/**
	 * Checks whether the constructed item is a valid item (has all the
	 * required fields)
	 *
	 * @return boolean true if the item is valid, false otherwise
	 */	
	function isValid ()
	{
		return $this->owner != null && $this->language != null 
			&& $this->template != null;
	}
}
?>
