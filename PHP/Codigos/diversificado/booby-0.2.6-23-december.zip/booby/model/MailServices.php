<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
//include ('sql/mailQueries.php');
require_once ('model/MailAccount.php');
require_once ('model/MailMessage.php');
require_once ('model/MailFactory.php');
require_once ('Services.php');
/**
 * Services for mail sending/receiving etc.
 *
 * @author Barry Nauta
 * @date October 2003
 * @package be.nauta.booby.model
 * @copyright
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a>
 * and look for licenses
 */
class MailServices extends Services
{

	/**
	 * Default constructor
	 */
	function MailServices ()
	{
		parent::Services();
		$this->itemFactory = new MailFactory ();
	}

	/**
	 * Adds a item (mailaccount) for a user
	 *
	 * @param integer userId the identifier for the user
	 * @param object item the item (mailaccount) to be added
	 *
     	* @return integer last know id. This is the id of the contact
	 * that was newly inserted and for which an id has automatically
	 * been assigned.
	 */
	function addItem ($userId, $item)
	{
		if ($_SESSION['username'] != $userId) { return null; }

		global $db, $queries;
		$now = date ("Y-m-d H:i:s");

		// execute the query
	}

	/**
	 * Modifies an item.
	 *
 	 * @param integer userId the identifier for the user who modifies a contact
	 * @param object item the modified contact
	 */
	function modifyItem ($userId, $item)
	{
	}

	function retrieveMessages ($mailAccount)
	{
	}

	function sendMessage ($mailAccount, $mailMessage)
	{
	}
}
?>
