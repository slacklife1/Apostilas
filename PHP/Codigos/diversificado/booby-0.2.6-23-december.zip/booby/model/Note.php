<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include ('util/StringUtils.php');
require_once ('Item.php');
/**
 * A note item
 *
 * @author Barry Nauta
 * @date March 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class Note extends Item
{

	/**
 	 * Full blown constructor
	 *
	 * @param integer theItemId the itemId
	 * @param string theOwner the owner
	 * @param integer theParentId the identifier of the parent
	 * @param boolean parent is this a parent yes or no?
	 * @param string theName the name of this item
	 * @param string theDescription the decription
	 * @param string theVisibility private or public
	 * @param string theCategory the category
	 * @param string theCreation when was this item created?
	 * @param string theModified when was this item last modified?
	 */
	function Note ($theItemId, $theOwner, $theParentId, $parent,
		$theName, $theDescription,
		$theVisibility, $theCategory, $theCreation, $theModified)
	{
		parent :: Item ();
		
		$this->type="Note";
		$this->itemId = $theItemId;
		$this->owner = $theOwner;
		$this->parentId = $theParentId;
		$this->isParent = $parent;
		$this->name = $theName;
		$this->description = $theDescription;
		$this->visibility = $theVisibility;
		$this->category = $theCategory;
		$this->when_created=$theCreation;
		$this->when_modified=$theModified;
	}

	/**
	 * Returns a human readable presentation of this item
	 * @return string a human readable presentation of this item
	 */
	function toString ()
	{
		$result  = "[Note] ";
		$result .= " name=" . $this->name;
		$result .= " description=" . $this->description;
		$result .= " isParent: " . $this->isParent;
	 	$result .= ' #children: ' . count($this->children);
		return $result;
	}
}
?>
