<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
/**
 * A user
 *
 * Considering a users' parameters, the following should be considered:
 * <ul>
 * <li>userId is the identifier (autoincrement integer) in the database
 * <li>user will be used for the username (to avoid conflicts/confusion with
 *		the session parameter username
 * <li>name will be used for the real name of the user
 * </ul>
 *
 * @author Barry Nauta
 * @date March 2003
 * @package be.nauta.booby.model
 */
class User
{
	/**
	 * The identifier for the user
	 * @private
	 * @variable string userId
	 */
	var $userId;
	
	/**
	 * The email address of the user
	 * @private 
	 * @variable string email
	 */
	var $email;
	
	/**
	 * The password of the user (MD5)
	 * @private
	 * @variable string password
	 */
	var $password;
	
	/**
	 * The username
	 * @private
	 * @variable string username
	 */
	var $username;
	
	/**
	 * The description for this user
	 * @private
	 * @variable string description
	 */
	var $description;
	
	/**
	 * The user's name
	 * @private
	 * @variable string name
	 */
	var $name;
	
	/**
	 * When is this user created?
	 * @private
	 * @variable string when_created
	 */
	var $when_created;

	/**
 	 * Full blown constructor with all parameters
 	 *
 	 * @param string theUserId the user's identifier
 	 * @param string theUserName the username
 	 * @param string thePassword the password
 	 * @param string theName the name of the user
 	 * @param string theEmail the users email address
 	 * @param string theDescription a description
 	 * @param string theCreation when this user was created
 	 */
	function User ($theUserId, 
		$theUsername, $thePassword, $theName, $theEmail,
		$theDescription, $theCreation)
	{
		$this->userId = $theUserId;
		$this->username = $theUsername;
		$this->password = $thePassword;
		$this->name = $theName;
		$this->email = $theEmail;
		$this->description = $theDescription;
		$this->when_created=$theCreation;
	}

	/**
	 * Presents a human readable presentation of this class
	 * @return  a human readable presentation of this class
	 */
	function toString ()
	{
		$result  = "[User]: ";
		$result .= "UserId: " . $this->userId . " ";
		$result .= "Username: " . $this->username . " ";
		$result .= "Name: " . $this->name . " ";
		$result .= "Description: " . $this->description . " ";
		$result .= "Email: " . $this->email;
		return $result;
	}
	
	/**
	 * Checks whether the constructed item is a valid item (has all the
	 * required fields)
	 *
	 * @return boolean true if the item is valid, false otherwise
	 */	
	function isValid ()
	{
		return $this->userId != null && $this->password != null
			&& $this->email != null;
	}
}
?>
