<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include ('sql/todoQueries.php');
require_once ('model/Todo.php');
require_once ('model/TodoFactory.php');
require_once ('Services.php');
/**
 * Operations on todos
 *
 * @author Barry Nauta
 * @date March 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class TodoServices extends Services
{
	/**
 	 * Default constructor
	 */
	function TodoServices ()
	{
		parent::Services();
		$this->itemFactory = new TodoFactory ();
	}
 
	/**
	 * Adds a todo item for a specific user
	 *
	 * @param string userId the identifier for the user
	 * @param object item the todo item to be added
	 */
	function addItem ($userId, $item)
	{
        if ($_SESSION['username'] != $userId) { return null; }
		if (!$item->isValid ()){ return null; }
		global $db, $queries;
		$now = date ("Y-m-d H:i:s");

		$query = sprintf ($queries['addItem'],
			$userId, $item->parentId, $item->isParent,
			addslashes($item->name), addslashes($item->description),
			'private', $now, $item->priority, $item->startDate, $item->endDate,
			$item->status, $item->percentCompleted, 'false');

		$result = $db->Execute($query) 
			or die("Add todo: " . $db->ErrorMsg() . " " . $query);
		
	}

	/**
	 * Modifies a todo item
	 *
 	 * @param string userId the identifier for the user
	 * @param object item the modified item
	 */
	function modifyItem ($userId, $item)
	{
        if ($_SESSION['username'] != $userId) { return null; }
        $this->checkOwner ($userId, $item->itemId);

		global $db, $queries;
		$now = date ("Y-m-d H:i:s");

		$query = sprintf ($queries['modifyItem'],
			$now, addslashes($item->name), addslashes($item->description),
			$item->priority, $item->status, $item->startDate,
			$item->endDate, $item->percentCompleted, $item->parentId, $item->itemId);
		$result = $db->Execute($query) 
			or die("ModifyTodo: " . $db->ErrorMsg() . " " . $query);
	}
}
?>
