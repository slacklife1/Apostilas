<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
 
include ('sql/newsQueries.php');
require_once ('model/News.php');
require_once ('model/NewsFactory.php');
require_once ('Services.php');
/**
 * News operations (RSS/RDF). The BusinessLogic operations that can be
 * performed on News
 *
 * @author Barry Nauta
 * @date February 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class NewsServices extends Services
{

	/**
	 * Default constructor
	 */
	function NewsServices ()
	{
		parent :: Services ();
		$this->itemFactory = new NewsFactory ();
	}

	/**
	 * Adds a bookmark for a user
	 *
	 * @param integer userId the identifier for the user
	 * @param object item the bookmark to be added
	 */
	function addItem ($userId, $item)
	{
		if ($_SESSION['username'] != $userId) { return null; }

		global $db, $queries;
		$now = date ("Y-m-d H:i:s");

		$query = sprintf ($queries['addItem'],
			$userId, $item->parentId, $item->isParent,
			addslashes ($item->name), addslashes($item->description),
			$item->visibility, $item->category, $now, addslashes($item->locator));
		$db->Execute ($query) or die ('AddNews: not able to add
			bookmark ' . $query . " " . $db->ErrorMsg());

		$query = $queries['lastItemInsertId'];
		$result=$db->Execute($query)
			or die ("addNews: " .
				$db->ErrorMsg () . " " . $query);
		return $result->fields[0];
	}


	/**
	 * Modifies an item
	 * @param integer userId the identifier of the user who modifies
	 * a bookmark
	 * @param object item the modified item
	 */
	function modifyItem ($userId, $item)
	{
		if ($_SESSION['username'] != $userId) { return null; }
		$this->checkOwner ($userId, $item->itemId);

		global $db, $queries;
		$now = date ("Y-m-d H:s");

		$query = sprintf ($queries['modifyItem'],
			$now, addslashes($item->name), $item->parentId,
			addslashes(trim($item->description)), $item->locator, $item->itemId);
		$result = $db->Execute ($query) or die
			("ModifyItem Error: " .
				$db->ErrorMsg () . " " . $query);
	}

}
?>
