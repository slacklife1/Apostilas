<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include ('sql/noteQueries.php');
require_once ('model/Note.php');
require_once ('model/NoteFactory.php');
require_once ('Services.php');
/**
 * Operations on contacts
 *
 * @author Barry Nauta
 * @date March 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class NoteServices extends Services
{
	/**
 	 * Default constructor
	 */
	function NoteServices ()
	{
		parent::Services();
		$this->itemFactory = new NoteFactory ();
	}

	/**
	 * Adds a note for a user
	 * 
	 * @param integer userId the identifier for the user
	 * @param object item the item to be added
	 *
     * @return integer last know id. This is the id of the contact
	 * that was newly inserted and for which an id has automatically
	 * been assigned.
	 */
	function addItem ($userId, $item)
	{
//die ($item->description);
        if ($_SESSION['username'] != $userId) { return null; }

        global $db, $queries;

		$now = date ("Y-m-d H:i:s");
		$query  = sprintf ($queries['addItem'],
			$userId, $item->parentId, $item->isParent, 
			addslashes ($item->name), addslashes ($item->description),
			$item->visibility, $item->category, $now);
		$result = $db->Execute($query) 
			or die("AddNote: " . $db->ErrorMsg() . " " . $query);
	}

	/**
	 * Modifies a note.
	 *
 	 * @param integer userId the identifier for the user who modifies a note
	 * @param object item the modified note
	 */
	function modifyItem ($userId, $item)
	{
        if ($_SESSION['username'] != $userId) { return null; }
		$this->checkOwner ($userId, $item->itemId);
//die ($item->toString ());
        global $db, $queries;
		$now = date ("Y-m-d H:i:s");

//die ($item->description);
		$query  = sprintf ($queries['modifyItem'], 
			$now, addslashes ($item->name), addslashes
			($item->description), $item->parentId, $item->itemId) ;
//die ($query);
		$result = $db->Execute($query) 
			or die("ModifyNote: " . $db->ErrorMsg() . " " . $query);
	}
}
?>
