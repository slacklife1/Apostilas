<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once ('ItemFactory.php');
/**
 * TodoFactory
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class TodoFactory extends ItemFactory
{
		/**
		 * Default constructor
		 */
		function TodoFactory ()
		{
			parent::ItemFactory ();
		}
		/**
		 * Factory method. Return an HTTP request into an item by fecthing
		 * the appropriate parameters from the POST request
		 *
		 * @return object the item constructed from the POST request
		 * @uses the POST request
		 */
		function requestToItem ()
		{
			$visibility = null;
			$parentId = 0;
			$isParent = null;
			$when_created = null;
			$when_modified = null;
			$itemId = 0;
			$category = null;
			$isFinished = 'false';
			if (isset ($_POST['isFinished']))
			{
				$isFinsihed = $_POST['isFinsihed'];
			}
			if (isset ($_POST['isParent']))
			{
				$isParent = $_POST['isParent'];
			}
			if (isset ($_POST['when_created']))
			{
				$when_created = $_POST['when_created'];
			}
			if (isset ($_POST['when_modified']))
			{
				$when_modified = $_POST['when_modifed'];
			}
			
			if (isset ($_POST['parentId']))
			{
				$parentId = $_POST['parentId'];
			}
			if (isset ($_POST['visibility']))
			{
				$visibility = $_POST['visibility'];
			}
		    $percComplete = $_POST['perComplete'];
			if ($visibility == null)
			{
				$visibility='private';
			}
			if (isset ($_POST['itemId']))
			{
				$itemId = $_POST['itemId'];
			}
			if (isset ($_POST['category']))
			{
				$category = $_POST['category'];
			}
		
			$startyear = $_POST['StartDate_Year'];
			$startmonth = $_POST['StartDate_Month'];
			$startday = $_POST['StartDate_Day'];
			$startDate = $startyear . '-' . $startmonth . '-' . $startday;
		
			$endyear = $_POST['DueDate_Year'];
			$endmonth = $_POST['DueDate_Month'];
			$endday = $_POST['DueDate_Day'];
			$endDate = $endyear . '-' . $endmonth . '-' . $endday;
		
			$todo = new Todo (
				$itemId,
				$_SESSION['username'],
				$parentId,
				$isParent,
		        $_POST['name'],
		        $_POST['description'],
				$visibility,
				$category,
				$when_created,
				$when_modified,
		        $_POST['priority'],
				$startDate,
				$endDate,
		    	$_POST['status'],
				$percComplete,
				$isFinished
			);
			return $todo;
		}
		
		
		/**
		 * Factory method: Returns a database result into an item
		 *
		 * @param object result the result retrieved from the database
		 * @return array the items constructed from the database resultset
		 */
		function resultsetToItems ($result)
		{
		    $todos=array();
		    while (!$result -> EOF) 
		    {
		        $todo = new Todo (
		            $result->fields[0],
		            $result->fields[1],
		            $result->fields[2],   
		            $result->fields[3],  
		            stripslashes ($result->fields[4]), 
		            stripslashes ($result->fields[5]),   
		            $result->fields[6],  
		            $result->fields[7], 
		            $result->fields[8],    
		            $result->fields[9], 
		            $result->fields[10],
		            $result->fields[11], 
		            $result->fields[12], 
		            stripslashes ($result->fields[13]),
		            $result->fields[14], 
		            $result->fields[15]); 
		        $result->MoveNext();
		        $todos[]=$todo; 
		    }
			return $todos;
		}
		
		
}
?>