<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once ('ItemFactory.php');
/**
 * NoteFactory
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class NoteFactory  extends ItemFactory
{
		/**
		 * Default constructor
		 */
		function NoteFactory ()
		{
			parent::ItemFactory ();
		}
	
				
		/**
		 * Factory method: Returns a database result into an item
		 *
		 * @param object result the result retrieved from the database
		 * @return array the items constructed from the database resultset
		 */
		function resultsetToItems ($result)
		{
			$notes = array ();
			while (!$result -> EOF)
			{
				$note = new Note (
					$result->fields[0],
					$result->fields[1],
					$result->fields[2],
					$result->fields[3], 
					$result->fields[4],
					$result->fields[5],
					$result->fields[6],
					$result->fields[7],
					$result->fields[8],
					$result->fields[9]);
				$notes [] = $note;
				$result->MoveNext ();
			}
			return $notes;
		}
		
		/**
		 * Factory method. Return an HTTP request into an item by fecthing
		 * the appropriate parameters from the POST request
		 *
		 * @return object the item constructed from the POST request
		 * @uses the POST request
		 */
		function requestToItem ()
		{
			$visibility = null;
			$parentId = 0;
			$isParent = null;
			$when_created = null;
			$when_modified = null;
			$itemId = 0;
			$category = null;
			if (isset ($_POST['itemId']))
			{
				$itemId = $_POST['itemId'];
			}
			if (isset ($_POST['isParent']))
			{
				$isParent = $_POST['isParent'];
			}
			if (isset ($_POST['when_created']))
			{
				$when_created = $_POST['when_created'];
			}
			if (isset ($_POST['when_modified']))
			{
				$when_modified = $_POST['when_modifed'];
			}
			if (isset ($_POST['category']))
			{
				$category = $_POST['category'];
			}
			if (isset ($_POST['parentId']))
			{
				$parentId = $_POST['parentId'];
			}
			if (isset ($_POST['visibility']))
			{
				$visibility = $_POST['visibility'];
			}
			if ($parentId == null)
			{
				$parentId = 0;
			}
			$note = new Note (
				$itemId,
				$_SESSION['username'],
				$parentId,
				$isParent,
				stripslashes ($_POST['name']),
				stripslashes ($_POST['description']),
				$visibility,
				$category,
				$when_created,
				$when_modified
			);
			return $note;
		}
				
}
?>
