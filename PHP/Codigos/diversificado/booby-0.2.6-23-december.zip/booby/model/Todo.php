<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once ('Item.php');
/**
 * A Todo item.
 * 
 * @author Barry Nauta
 * @date March 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class Todo extends Item 
{
	/**
	 * The priority of this item
	 * @private
	 * @variable integer priority
	 */
	var $priority;
	
	/**
	 * The startdate of this item
	 * @private
	 * @variable string startDate
	 */
	var $startDate;

	/**
	 * The enddate of this item
	 * @private
	 * @variable string endDate
	 */
	var $endDate;
	
	/**
	 * The status of this item
	 * @private
	 * @variable string status
	 */
	var $status;

	/**
	 * The percentage completed of this item
	 * @private
	 * @variable integer percentCompleted
	 */
	var $percentCompleted;
	
	/**
	 * Indicator whether this todo item is finished
	 * @private
	 * @variable boolean isFinished
	 */
	var $isFinished;

	/**
	 * Full blown constructor with all parameters
	 *
	 * @param integer theItemId the id of the item
	 * @param string theOwner who owns this item?
	 * @param integer theParentId what is the id of the parent of this item?
	 * @param boolean parent is this a parent (true) or child (false)
	 * @param string theName the name of this item
	 * @param string theDescription the description of this item
	 * @param string theVisibility the visibility (private or public)
	 * @param string theCategory what is the category of this item?
	 * @param string theCreation When was this item created?
	 * @param string theModified When was this item modified?
	 * @param integer thePriority The priority of this item
	 * @param string theStartDate the start date of this todo item
	 * @param string theEndDate the end date of this todo item
	 * @param string theStatus the status of this item
	 * @param integer percCompleted percentage completed
	 * @param boolean finished is this todo item finished yet?
  	 */
	function Todo ($theID, $theOwner, $theParentId, $parent, $theName, 
		$theDescription, $theVisibility, $theCategory, 
		$theCreation, $theModified,
		$thePriority, $theStartDate,$theEndDate,
		$theStatus, $percCompleted, $finished)
	{
		parent :: Item ();
		
		$this->type="Todo"; 
		$this->itemId = $theID;
		$this->owner = $theOwner;
		$this->parentId = $theParentId;
		$this->isParent = $parent;
		$this->name = $theName;
		$this->description = $theDescription;
		$this->visibility = $theVisibility;
		$this->category = $theCategory;
		$this->when_created = $theCreation;
		$this->when_modified = $theModified;
		$this->priority = $thePriority;
		$this->startDate = $theStartDate;
		$this->endDate = $theEndDate;
		$this->status=$theStatus;
		$this->percentCompleted=$percCompleted;
		$this->isFinished = $finished;
	}

	/**
	 * Returns a human readable presentation of this item
	 * @return string a human readable presentation of this item
	 */
	function toString ()
	{
		$result  = "[Todo] ";
		$result .= " owner: " . $this->owner;
		$result .= " name: " . $this->name;
		$result .= " description: " . $this->description;
		$result .= " priority: " . $this->priority;
		$result .= " perc complete: " . $this->percentCompleted;
		$result .= " status: " . $this->status;
		$result .= " start: " . $this->startDate;
		$result .= " end: " . $this->endDate;
	 	$result .= ' #children: ' . count($this->children);
		return $result;
	}
}
?>
