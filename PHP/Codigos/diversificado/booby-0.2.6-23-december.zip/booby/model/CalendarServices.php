<?
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */

/**
 * Calendar class, display only! (perhaps this should not be in the model
 * directory?)
 *
 * @author Barry Nauta
 * @date November 2003
 * @package be.nauta.booby.model
 * @copyright
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a>
 * and look for licenses
 */
class CalendarServices //extends Services
{

    function CalendarServices()
    {
    }


	/**
	 * Get the days for the requested month in an array
	 * @param integer month the requested month, 1 for Jan.
	 * @param integer year the requested year
	 * @return integer 0 (for Sunday) through 6 (for Saturday)
	 */
	function getFirstDayInMonth ($month, $year)
	{
    	$date = getdate(mktime(12, 0, 0, $month, 1, $year));
    	$first = $date["wday"];
    	return $first;
	}

	/**
	 * Returns the number of days in the specified month/year
	 * combination. The year parameter is used for leap-year
	 * calculation
	 *
	 * @param integer month the requested month, 1 for Jan.
	 * @param integer year the requested year
	 * @return integer the number of days in the requested month
	 */
	function getNumberOfDaysInMonth ($month, $year)
	{
		if ($this->isLeapYear ($year))
		{
			$numberOfDaysPerMonth =
				array(31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
		}
		else
		{
			$numberOfDaysPerMonth =
				array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
		}
		return $numberOfDaysPerMonth [$month-1];
	}

	/**
	 * Is the specified year a leap year?
	 * @param integer the year for which we would like to know whether
	 * it is a leap-year
	 * @return boolean <code>true</code> if the year is a leap-year,
	 * <code>false</code> otherwise.
	 */
	function isLeapYear ($year)
	{
		$result = false;
		if ($year %4 == 0)
		{
			if ($year %100 == 0)
			{
				if ($year %400 == 0)
				{
					$result = true;
				}
			}
			else
			{
				$result = true;
			}
		}
		return $result;
	}

	function getDaysInMonthAsArrayPerWeek ($month, $year)
	{
		$debugString = '';
		$firstDay = $this->getFirstDayInMonth ($month, $year);
		$numberOfDaysInMonth = $this->getNumberOfDaysInMonth ($month, $year);

		// max. 6 weeks in one month
		$weeks = array ();

		$debugString = 'Firstday: '.$firstday.'<br />';
		$debugString = 'NumberOfDAysInMonth: '.$numberOfDaysInMonth.'<br />';

		for ($currentWeekDay=$firstDay, $dayCount=1, $weekCount=0;
			$dayCount<=$numberOfDaysInMonth;
			$currentWeekDay++, $dayCount++)
		{
			$debugString .= 'loop: CurrentWeekDay '.$currentWeekDay.'<br />';
			$debugString .= 'loop: DayCount '.$dayCount.'<br />';
			$debugString .= 'loop: WeekCount '.$weekCount.'<br />';

			if ($currentWeekDay > 0 && $currentWeekDay < 7)
			{
				$weeks[$weekCount][] = $dayCount;
				$debugString .= 'CurrentDay < 7 ';
			}
			else
			{
				$weeks[$weekCount][] = $dayCount;
				$weekCount++;
				$currentWeekDay = 0;
				$debugString .= 'CurrentDay >= 7 WRAP';
			}
    	}
		$weeks[] = $debugString;
    	return $weeks;
	}

	function getPreviousMonth ($month, $year)
	{
			$result = array ();
			if ($month > 1)
			{
					$month--;
			}
			else
			{
					$month=12;
					$year--;
			}
			$result['month']=$month;
			$result['year']=$year;
			return $result;
	}

	function getNextMonth ($month, $year)
	{
			$result = array ();
			if ($month < 12)
			{
					$month++;
			}
			else
			{
					$month=1;
					$year++;
			}
			$result['month']=$month;
			$result['year']=$year;
			return $result;
	}

}
$calendar = new CalendarServices ();

/*
if ($calendar->isLeapYear (1999)) { echo ("true"); } else { echo ("false"); }
if ($calendar->isLeapYear (2000)) { echo ("true"); } else { echo ("false"); }
if ($calendar->isLeapYear (2001)) { echo ("true"); } else { echo ("false"); }
if ($calendar->isLeapYear (2002)) { echo ("true"); } else { echo ("false"); }
if ($calendar->isLeapYear (2003)) { echo ("true"); } else { echo ("false"); }
if ($calendar->isLeapYear (2004)) { echo ("true"); } else { echo ("false"); }
*/
echo ("<pre>");
$month=$_GET['month'];
$year=$_GET['year'];
print_r ($calendar->getDaysInMonthAsArrayPerWeek ($month,$year));
echo ("</pre>");

?>
