<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
/**
 * UserFactory
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class UserFactory
{
	/**
	 * Factory method: Returns a database result into an item
	 *
	 * @param object result the result retrieved from the database
	 * @return array the items constructed from the database resultset
	 */
	function resultsetToUsers ($result)
	{
		$users = array ();
		while (!$result->EOF)
		{
			$aUser = new User (
				$result -> fields [0],
				$result -> fields [1],
				$result -> fields [2],
				$result -> fields [3],
				$result -> fields [4],
				stripslashes ($result -> fields [5]),
				$result -> fields [6]
			);
			$users [] = $aUser;
			$result->MoveNext ();
		}
		return $users;
	}	

	/**
	 * Factory method. Return an HTTP request into a user by fecthing
	 * the appropriate parameters from the POST request
	 *
	 * @return object the user constructed from the POST request
	 */
	function requestToUser ()
	{
		if (isset ($_POST['userId']))
		{
			$userId = $_POST['userId'];
		}
		else
		{
			$userId = null;
		}
		if (isset ($_POST['when_created']))
		{
			$when_created=$_POST['when_created'];
		}
		else
		{
			$when_created=null;
		}
	    $userSettings = new User 
	    (
	        $userId,
	        $_POST['user'],
	        $_POST['password'],
	        $_POST['name'],
	        $_POST['email'],
	        $_POST['description'],
			$when_created
	    );
		return $userSettings;
	}
}
?>
