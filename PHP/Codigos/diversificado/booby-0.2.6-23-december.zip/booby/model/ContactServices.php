<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include ('sql/contactQueries.php');
require_once ('model/Contact.php');
require_once ('model/ContactFactory.php');
require_once ('Services.php');
/**
 * Services for contacts
 *
 * @author Barry Nauta
 * @date March 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class ContactServices extends Services
{

	/**
	 * Default constructor
	 */
	function ContactServices ()
	{
		parent::Services();
		$this->itemFactory = new ContactFactory ();
	}

	/**
	 * Adds a contact for a user
	 *
	 * @param integer userId the identifier for the user
	 * @param object item the contact to be added
	 *
     * @return integer last know id. This is the id of the contact
	 * that was newly inserted and for which an id has automatically
	 * been assigned.
	 */
	function addItem ($userId, $item)
	{
		if ($_SESSION['username'] != $userId) { return null; }

		global $db, $queries;
		$now = date ("Y-m-d H:i:s");

		// execute the query
		$query = sprintf ($queries['addItem'],
			$userId, $item->parentId, $item->isParent,
			$item->name, $item->description, $item->visibility,
			$item->category, $item->when_created, $item->when_modified,
			$item->alias, $item->address, $item->birthday,
			$item->mobile, $item->faximile, $item->telephoneHome,
			$item->telephoneWork, $item->organization, $item->organizationAddress,
			$item->job, $item->email1, $item->email2, $item->email3,
			$item->webaddress1, $item->webaddress2, $item->webaddress3);
		$db->Execute($query) or 
			die ("Could not add contact.".
			$db->ErrorMsg () . " " . $query);

		// fetch the last known id
		$query = $queries['lastItemInsertId'];
		$result = $db->Execute ($query) or
			die ("Could not retrieve last insert id for contact. ".
			$db->ErrorMsg () . " " . $query);

        return $result->fields[0];
	}

	/**
	 * Modifies a contact.
	 *
 	 * @param integer userId the identifier for the user who modifies a contact
	 * @param object item the modified contact
	 */
	function modifyItem ($userId, $item)
	{
		if ($_SESSION['username'] != $userId) { return null; }
		$this->checkOwner ($userId, $item->itemId);

		global $db, $queries;
		$now = date ("Y-m-d H:i:s");

		$query = sprintf ($queries['modifyItem'],
			$now, $item->name, $item->parentId, 
			$item->job, $item->alias, $item->organization,
			$item->organizationAddress, $item->telephoneHome, 
			$item->telephoneWork, $item->faximile, $item->mobile, 
			$item->address, $item->birthday, 
			addslashes ($item->description), 
			$item->email1, $item->email2, $item->email3,
			$item->webaddress1, $item->webaddress2, $item->webaddress3, 
			$item->itemId
		);
		$db->Execute($query) 
			or die ("Error modifying item: " .  
	 		$db->ErrorMsg() . " " . $query);
	}

}
?>
