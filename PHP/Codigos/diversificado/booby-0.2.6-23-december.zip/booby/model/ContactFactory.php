<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once ('ItemFactory.php');
/**
 * ContactFactory
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class ContactFactory extends ItemFactory
{
		/**
		 * Default constructor
		 */
		function ContactFactory ()
		{
			parent::ItemFactory ();
		}
			
				
		/**
		 * Removes some characters from the input string
		 * These characters are: ';' and ','
		 * @private 
		 *
		 * @param string input the input string
		 * @return string the modified string
		 */
		function removeSpecialChars ($input)
		{
			$result = str_replace(';', '', $input);
			$result = str_replace(',', '', $result);
			$result = str_replace("'", '', $result);
			$result = str_replace('"', '', $result);
			return $result;
		}
		
		/**
		 * Factory method. Takes the input received from the vCard parsing 
		 * class and returns an array of contacts
		 *
		 * @param object vcards an array containing vCard information (more 
		 * information: <a href=http://ciaweb.net/free/contact_vcard_parse/"
		 * >ciaweb.net/free/contact_vcard_parse/</a> )
		 * @return array an array of contacts
		 */
		function vcardsToContacts ($vcards)
		{
			// the resulting contacts
			$result = array ();
			// seperator used in the address
			$sep = " ";
		
			// loop over the input array
			for ($i=0; $i<count($vcards); $i++)
			{
			       $currentContact = new Contact (
					null, null, null, null,
					null, null, null, null,
					null, null, null, null,
					null, null, null, null,
					null, null, null, null,
					null, null, null, null,
					null, null);
		
				$currentArray = $vcards[$i];
				//die (print_r($currentArray));
				$currentContact->name =
					$this->removeSpecialChars ($currentArray['FN'][0]['value'][0]);
				$currentContact->email1 = 
					$currentArray['EMAIL'][0]['value'][0];
				$currentContact->email2 = 
					$currentArray['EMAIL'][1]['value'][0];
				$currentContact->email3 = 
					$currentArray['EMAIL'][2]['value'][0];
				$addresses = $currentArray['ADR'];
				//die ($currentContact->toString());
				if ($addresses != null && count($addresses) > 0)
				{
					for ($j=0; $j<count($addresses); $j++)
					{
						$addr = $addresses[$j];
						$values = $addr['value'];
						if ($addr['params']['TYPE'][0] == 'WORK')
						{
							//die (print_r($values));
							$theAddress = $values['pob'][0] . $sep .
								$values['extended'][0] . $sep .
								$values['street'][0] . $sep .
								$values['locality'][0] . $sep .
								$values['region'][0] . $sep .
								$values['postcode'][0] . $sep .
								$values['country'][0] . $sep;
							//die ($theAddress);
							$currentContact->organizationAddress=
								$this->removeSpecialChars ($theAddress); 
								//$theAddress;
							//die ($currentContact->toString ());
						}
						else if ($addr['params']['TYPE'][0] == 'HOME')
						{
							$currentContact->homeAddress=
							$this->removeSpecialChars (
								$values['pob'][0] . $sep .
								$values['extended'][0] . $sep .
								$values['street'][0] . $sep .
								$values['locality'][0] . $sep .
								$values['region'][0] . $sep .
								$values['postcode'][0] . $sep .
								$values['country'][0] . $sep
							);
						}
					}
				}
				//die ($currentContact->toString());
				$currentContact->organization =
					$this->removeSpecialChars ($currentArray['ORG'][0]['value'][0]);
				$currentContact->jobTitle =
					$this->removeSpecialChars ($currentArray['TITLE'][0]['value'][0]);
				$currentContact->alias =
					$this->removeSpecialChars
						($currentArray['NICKNAME'][0]['value'][0]);
				$tel = $currentArray['TEL'];
				for ($k=0; $k<count($tel); $k++)
				{
					$currentTel = $tel[$k];
		
					if ($currentTel['params']['TYPE'][0] == 'WORK' )
					{
						if ($currentTel['params']['TYPE'][1] 
							== 'VOICE')
						{
							$currentContact->telephoneWork 
								=$currentTel['value'][0];
						}
						else if ($currentTel['params']['TYPE'][1] == 'FAX')
						{
							$currentContact->faximile 
								=$currentTel['value'][0];
						}
					}
					else if ($currentTel['params']['TYPE'][0] ==
						'HOME')
					{
						$currentContact->telephoneHome 
							=$currentTel['value'][0];
					}
					else if ($currentTel['params']['TYPE'][0] ==
						'CELL')
					{
						$currentContact->mobile 
							=$currentTel['value'][0];
					}
				}
				$currentContact->webaddress1 = 
					$currentArray['URL'][0]['value'][0];
				$currentContact->webaddress2 = 
					$currentArray['URL'][1]['value'][0];
				$currentContact->webaddress3 = 
					$currentArray['URL'][2]['value'][0];
				
				$currentContact->description =
					$currentArray['NOTE'][0]['value'][0];
		
		
				//$currentContact->
				$result [] = $currentContact;
			}
			return $result;
		}
		
		
		/**
		 * Factory method. Return an HTTP request into an item by fecthing
		 * the appropriate parameters from the POST request
		 *
		 * @return object the item constructed from the POST request
		 * @uses the POST request
		 */
		function requestToItem ()
		{
			$birthday = null;
			$parentId = null;
			$isParent = null;
			$visibility = 'private';
			$category = null;
			$when_created = null;
			$when_modified = null;
			if (isset ($_POST['Date_Year']))
			{
				$birthday = 
						$_POST['Date_Year'].'-'.
						$_POST['Date_Month'].'-'.
						$_POST['Date_Day'];
			}
			if (isset ($_POST['parentId']))
			{
				$parentId = $_POST['parentId'];
			}
			if (isset ($_POST['isParent']))
			{
				$isParent = $_POST['isParent'];
			}
			if (isset ($_POST['visibility']))
			{
				$visibility = $_POST['visibility'];
			}
			if (isset ($_POST['category']))
			{
				$category = $_POST['category'];
			}
			if (isset ($_POST['when_created']))
			{
				$when_created = $_POST['when_created'];
			}
			if (isset ($_POST['when_modified']))
			{
				$when_modified = $_POST['when_modifed'];
			}
		    $contact = new Contact (
		        $_POST['itemId'],
		        $_SESSION['username'],
				$parentId,
		        $isParent,   
		        $_POST['name'],
		        addslashes ($_POST['description']),
		        $visibility,
				$category,
				$when_created,
				$when_modified,
		        $_POST['alias'],
		        $_POST['address'],
		        $birthday,
		        $_POST['mobile'],
		        $_POST['faximile'],
		        $_POST['telephoneHome'],
		        $_POST['telephoneWork'],
		        $_POST['organization'],
		        $_POST['organizationAddress'],
		        $_POST['job'],
		        $_POST['email1'],
		        $_POST['email2'],
		        $_POST['email3'],
		        $_POST['webaddress1'],
		        $_POST['webaddress2'],
		        $_POST['webaddress3']
		    );
		    return $contact;
		}
		 
		
		/**
		 * Factory method: Returns a database result into an item
		 * @public
		 *
		 * @param object result the result retrieved from the database
		 * @return array the items constructed from the database resultset
		 */
		function resultsetToItems ($result)
		{
			$contacts = array ();
			while (!$result->EOF)
			{
		        $item = new Contact (
		            $result->fields[0],
		            $result->fields[1],
		            $result->fields[2],
		            $result->fields[3],
		            $result->fields[4],
		            stripslashes ($result->fields[5]),
		            $result->fields[6],
		            $result->fields[7],  
		            $result->fields[8], 
		            $result->fields[9],
		            $result->fields[10],
		            $result->fields[11],  
		            $result->fields[12],   
		            $result->fields[13],  
		            $result->fields[14], 
		            $result->fields[15], 
		            $result->fields[16], 
		            $result->fields[17],   
		            $result->fields[18],  
		            $result->fields[19], 
		            $result->fields[20], 
		            $result->fields[21], 
		            $result->fields[22], 
		            $result->fields[23], 
		           	$result->fields[24],
		           	$result->fields[25]
		        );
				$contacts [] = $item;
				$result->MoveNext();
			}
			return $contacts; 
		}
				
}
?>
