<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once ('Item.php');
/**
 * A mailaccount item
 * 
 * @author Barry Nauta
 * @date October 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class MailAccount extends Item
{
	/**
	 * The username to login into the mailserver (if applicable)
	 * @private
	 * @variable string the username
	 */
	var $username;

	/**
	 * The password to login into the mailserver (if applicable)
	 * @private
	 * @variable string the password
	 */
	var $password;

	/**
	 * The from email
	 * @private
	 * @variable string the from email address
	 */
	var $fromEmail;

	/**
	 * The from-name
	 * @private
	 * @variable string the name 
	 */
	var $fromName;

	/**
	 * The reply to name
	 * @private
	 * @variable string the reply to address
	 */
	var $defaultReplyTo;

	var $sendMail;

	var $readMail;

	var $smtpAuthenticationRequired;

	var $smtpKeepAlive;

	var $signature;
	/**
	 * Constructor
	 */
	function MailAccount ($theUsername, $thePassword,
		$theFromEmail, $theFromName, $theReplyTo,
		$theReadMail, $theSendMail)
	{
		parent :: Item ();

		$this->username = $theUsername;
		$this->password = $thePassword;
		$this->fromEmail = $theFromEmail;
		$this->fromName = $theFromName;
		$this->defaultReplyTo = $theReplyTo;

		$this->readMail = $theReadMail;
		$this->sendMail = $theSendMail;
	}

	/**
	 * Returns a human readable representation of this object
	 * @return string a human readable representation of this object
	 */
	function toString ()
	{
		$result  = "[MailAccount]";
		$result .= " isParent: " . $this->isParent;
		$result .= " parentId: " . $this->parentId;
		$result .= " Name: " . $this->name;
		return $result;
	}
}
?>
