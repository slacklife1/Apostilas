<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once ('ItemFactory.php');
/**
 * MailFactory
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class MailFactory extends ItemFactory
{
		/**
		 * Default constructor
		 */
		function MailFactory ()
		{
			parent::ItemFactory ();
		}
		
		/**
		 * Factory method: Returns a database result into an item
		 *
		 * @param object result the result retrieved from the database
		 * @return array the items constructed from the database resultset
		 */
		function resultsetToItems ($result)
		{
			$items = array ();
			while (!$result->EOF)
			{
				$item = new MailMessage (
					$result->fields[0],
					$result->fields[1],
					$result->fields[2],
					$result->fields[3],
					stripslashes ($result->fields[4]),
					stripslashes ($result->fields[5]),
					$result->fields[6],
					$result->fields[7],
					$result->fields[8],
					$result->fields[9],
					$result->fields[10],
					stripslashes ($result->fields[11]),
					$result->fields[12]);
				$items [] = $item;
				$result->MoveNext();
			}
			return $items;
		}
		
		/**
		 * Factory method. Return an HTTP request into an item by fecthing
		 * the appropriate parameters from the POST request
		 *
		 * @return object the item constructed from the POST request
		 * @uses the POST request
		 */
		function requestToItem ()
		{
			$itemId = null;
			$when_created = null;
			$when_modified = null;
			$when_visited = null;
			$visibility='private';
			$category = null;
			$visitCount = 0;
			if (isset ($_POST['itemId']))
			{
				$itemId = $_POST['itemId'];
			}
			if (isset ($_POST['when_created']))
			{
				$when_created = $_POST['when_created'];
			}
			if (isset ($_POST['when_modified']))
			{
				$when_modified = $_POST['when_modified'];
			}
			if (isset ($_POST['when_visited']))
			{
				$when_visited = $_POST['when_visited'];
			}
			if (isset ($_POST['visibility']))
			{
				$visibility = $_POST['visibility'];
			}
			if (isset ($_POST['category']))
			{
				$category = $_POST['category'];
			}
			if (isset ($_POST['visitCount']))
			{
				$visitCount = $_POST['visitCount'];
			}
		    $item = new News (
		        $itemId,
		        $_SESSION['username'],
		        $_POST['parentId'],
		        $_POST['isParent'],
		        $_POST['name'],
		        $_POST['description'],
		        $visibility,
				$category,
				$when_created,
				$when_modified,
				$when_visited,
		        $_POST['locator'],
				$visitCount
		    );
		    return $item;
		}
}
?>
