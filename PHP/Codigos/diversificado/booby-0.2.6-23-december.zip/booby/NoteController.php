<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
// only used for the renderEngine setting
include ('configs/adminConfiguration.php');
require_once ('Controller.php');
require_once ('model/NoteServices.php');
/**
 * The Note Controller
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.controller
 * @copyright
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <code>http://www.gnu.org</code>
 * and look for licenses
 */
class NoteController extends Controller
{
	/**
	 * Constructor. 
	 * Makes sure that the appropriate operations are instantiated.
	 * @param string renderEngineName the renderEngine to be used
	 * (either Smarty or phpSavant)
	 */
	function NoteController ($renderEngineName)
	{
		parent::Controller ($renderEngineName);
		$this->operations = new NoteServices ();
		$this->itemFactory = new NoteFactory ();
	}

	/**
	 * Returns the title of this Controller
	 *
	 * @return string the title of this controller
	 */
	function getTitle ()
	{
		return "Booby - Notes";
	}

	/**
	 * Returns the name of the item that is controller by this controller
	 *
	 * @return string the name of the item that is controlled by this controller
	 */
	function getItemName ()
	{
		return "Note";
	}

	/**
 	 * Returns the actions defined for this item only
 	 *
 	 * @return array an array of item specific actions (like search, import etc.)
 	 */
	function getActions ()
	{
		global $dictionary;
		$actions=array(
			array (
				'name'=> $dictionary['actions'],
				'contents'=>
				array (
					array('href' => 'NoteController.php?action=add&parentId='.$this->getParentId ()
						, 'name' => $dictionary['add']),
					//array('href' => '', 'name' => $dictionary['import']),
					//array('href' => '', 'name' => $dictionary['export']),
					array('href' => 'NoteController.php?action=search',
						'name' => $dictionary['search'])
					)
				),
			array (
				'name'=> $dictionary['view'],
				'contents'=>
				array (
					array('href' => 'NoteController.php?expand=*',
						'name' => $dictionary['expand']),
					array('href' => 'NoteController.php?expand=0',
						'name' => $dictionary['collapse']),
					array('href' => 'NoteController.php?action=setYahooTree&parentId='.$this->getParentId (),
						'name' => $dictionary['yahooTree']),
					array('href' => 'NoteController.php?action=setExplorerTree&parentId='.$this->getParentId (),
						'name' => $dictionary['explorerTree'])
				)
			)
		);
		return $actions;
	}

	/**
	 * Activate. Basically this means that the appropriate actions are executed and an optional result is returned
	 * to be processed/displayed
	 */
	function activate ()
	{
		switch ($this->getAction ())
		{
			case "add":
				$this->renderer = 'addNote';
				break;
			case "modify":
				$this->renderer = 'modifyNote';
				$this->renderObjects =
					$this->operations->getItem ($_SESSION['username'], $this->itemId);
				break;
			case "delete":
				$this->operations->deleteItem ($_SESSION['username'], $this->itemId);
				// and show all items
//				$this->renderer = 'showNotes';
//				$this->renderObjects = $this->operations->getItems
//					($_SESSION['username']);
				$this->getShowItemsParameters ();
				break;
			case "move":
				$this->moveAction ();
				break;
			case "moveItem":
				$this->moveItemAction ();
				$this->getShowItemsParameters ();
				break;
			case "searchNotes":
				    $this->renderObjects = $this->operations->searchItems
         				($_SESSION['username'], $_POST['field'], $_POST['value']);
					$this->renderer = 'showNotes';
				break;
			case "search":
				$this->renderer = $this->getAction().'Notes';
				break;
			case "addNote":
				$this->operations->addItem($_SESSION['username'],
					$this->itemFactory->requestToItem ());
				$this->getShowItemsParameters ();
				break;
			case "modifyNote":
				$this->operations->modifyItem($_SESSION['username'],
					$this->itemFactory->requestToItem());
				$this->getShowItemsParameters ();
				break;
			case "setYahooTree":
				$_SESSION['noteTree']='Yahoo';
				$this->getShowItemsParameters ();
				break;
			case "setExplorerTree":
				$_SESSION['noteTree']='Explorer';
				$this->getShowItemsParameters ();
				break;
			default:
				$this->getShowItemsParameters ();
				break;
			}
	}

		/**
	 * Returns the list of current expanded items for the controller
	 *
	 * @return string list of commanseperated item numbers
	 */
	function getExpanded ()
	{
			if (isset ($_GET['expand']))
			{
				$expand = $_GET['expand'];
				$_SESSION['noteExpand']=$expand;
			}
			else if (isset ($_SESSION['noteExpand']))
			{
				$expand = $_SESSION['noteExpand'];
			}
			else
			{
				$expand = 0;
			}
			return $expand;
	}

}
error_reporting(E_ERROR);
$controller = new NoteController ($renderEngineName);
$controller -> activate ();
$controller -> display ();
?>
