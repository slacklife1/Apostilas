<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include ('util/checkLogin.php');
include ('util/preferenceConfiguration.php');
include ('MySmarty.php');
include ('menuItems.php');

$renderer = 'showHelp.tpl';
$renderObjects = $dictionary['help_page'];

$smarty=new MySmarty;
$smarty->assign('title', 'Booby - Help');
$smarty->assign('menuItems', $menuItems);
$smarty->assign('menu', $menu);
$smarty->assign('renderer', $template . '/' . $renderer);
$smarty->assign('renderObjects', $renderObjects);
$smarty->assign('renderActions', $actions);
$smarty->assign('template',$template);
$smarty->assign('dictionary', $dictionary);

if ($debug == true)
{
	include ('util/debug.php');
	$smarty->display($template . '/' . 'template.tpl');
}
else
{
	@$smarty->display($template . '/' . 'template.tpl');
}
?>
