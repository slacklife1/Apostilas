<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */

$status  = "<html>";
$status .= "<head><title>Booby - installation test</title></head>";
$status .= "<link rel='stylesheet' href='doc/css/booby.css'";
$status .= " type='text/css' />";

$status .= "<body>";


// Check database status
// Try to include adodb and perform a query
$adodbExists = @include('adodb/adodb.inc.php');
if (!$adodbExists)
{
	$status .= "<h1>Adodb not found</h1>";
}
else
{
	$status .= "<h1>Adodb found</h1>";
	include ('configs/databaseConfiguration.php');
	$db = NewADOConnection ($engine);
	$db->Connect($host, $user, $password, $database)
		or die ($db->ErrorMsg());

	$query = "SELECT COUNT(userId) FROM booby_users";

	$result = $db->Execute ($query);
	if ($result == null)
	{
		$status .= "<h3>Database connection error</h3>";
		$status .= "Could not execute statement: ";
		$status .= "<code>".$query."</code>";
		$status .= "<br />";
		$status .= "The db returned the following message:";
		$status .= "<br />";
		$status .= "<code>".$db->ErrorMsg ()."</code>";
		$status .= "<br/>";
		$status .= "This probably means that your database ";
		$status .= " config file is not correct";
	}
	else
	{
		$status .= "<h3>Database connection succes!</h3>";
		$status .= "Could succesfully query the database ";
		$status .= "for number of users";
	}
}

$status .= "<h1>PHP environment check</h1>";

// Check PHP basedir restrictions and safe mode
// Check several parameters and display these in a table
$safemode = ini_get("safe_mode");
if ($safemode == null)
{
	$safemode="false";
	$safemode_include_dir=null;
}
else
{
	$safemode = "true";
	$safemode_include_dir=ini_get("safe_mode_include_dir");
}

// Check open basedir settings
$open_basedir = ini_get("open_basedir");
if ($open_basedir == null)
{
	$open_basedir = "undefined";
}

// check disabled functions
$disabled_functions = ini_get ("disabled_functions");
if ($disabled_functions == null)
{
	$disabled_functions = "undefined";
}

$xmlEnabled = false;
if (function_exists('xml_parser_create')) 
{
	$xmlEnabled = true;
}


$status .= "<table cellpadding=3 cellspacing=3 border=1>";

// Safe mode
$status .= "<tr>";
$status .= "<td>Safe mode</td><td>".$safemode."</td>";
$status .= "</tr>";
$status .= "<tr>";
if ($safemode_include_dir != null)
{
	$status .= "<td>Safemode include dir</td><td>".$safemode_include_dir."</td>";
	$status .= "</tr>";
}

// open base dir
$status .= "<tr>";
$status .= "<td>Open basedir</td><td>".$open_basedir."</td>";
$status .= "</tr><tr>";
$status .= "<td>Disabled functions</td><td>".$disabled_functions."</td>";
$status .= "</tr>";

// xml
$status .= "<tr>";
$status .= "<td>XML parsing embedded in PHP</td>";
$status .= "<td>";
if ($xmlEnabled)
{
	$status .= "Yes. This is good. RSS/RDF feeds will appear under the section 'News'";
		 
}
else
{
	$status .= "No. TOO BAD. The news section will be disabled, since RSS/RDF feeds rely on XML parsing";
}
$status .= "</td>";
$status .= "</tr>";

$status .= "</table>";
$status .= "
<p>
	If the safemode is enabled and/or the open_basedir is defined,
	you might experience some problems running the Smarty template
	engine. Please consult and edit the 'MySmarty.php' class in the
	application directory. It is fully self-explanatory.
</p>
<p>
	If safe_mode is enable, the execution time of a script is limited by the 'php.ini'
	file only. This implies that you might encounter difficulties when importing
	huge files (bookmarks etc)
</p>

";




// Check password settings
$status .= "<h1>Admin password</h1>";
if (isset ($_POST['action']) && $_POST['action']=="checkCredentials")
{
	$result .= "<h2>Checking credentials</h2>";
	$password = md5($_POST['password']);
	$query  = "SELECT password FROM booby_users WHERE ";
	$query .= "userId='".$_POST['username']."'";
	$result = $db->Execute ($query);
	if ($result == null)
	{
		$status .= "<h3>Error fetching admin password</h3>";
		$status .= "<code>".$query."</code><br />";
		$status .= $db->ErrorMsg ();
	}
	else
	{
		$dbPassword = $result->fields [0];
		if ($dbPassword != $password)
		{
			$status .= "<h3>Password mismatch!!</h3>";
		}
		else
		{
			$status .= "<h3>Password check ok</h3>";
		}
	}
}
else
{
	$status .= "<h2>Fill in admin pwd to check credentials</h2>";
	$status .= "<form method='POST' action='test.php'>";
	$status .= "Username: ";
	$status .= "<input type='text' name='username' value='admin'>";
	$status .= "<br />";
	$status .= "Password: ";
	$status .= "<input type='password' name='password'>";
	$status .= "<input type='hidden' name='action' value='checkCredentials'>";
	$status .= "<br />";
	$status .= "<input type='submit' value='Submit'
		name='checkCredentials'>";
	$status .= "</form>";
}




// Check whether Smarty is available
$result .= "<h2>Smarty</h2>";
if (isset ($_POST['action']) && $_POST['action']=="checkSmarty")
{
	include ("configs/MySmarty.php");
	$smarty = new MySmarty;
	$smarty->assign ('Status', 'Ok');
	$smarty->template_dir='doc';
	$smarty->display ('SmartyTest.tpl');
	exit;
}
else
{
	$smartyAvailable = @include ("configs/MySmarty.php");
	if (!$smartyAvailable)
	{
		$status .= "<h1>Smarty not available!</h1>";
		$status .= "Either Smarty is not available, or you did not edit the file 'MySmarty.php' yet?";
	}
	else
	{
		$status .= "<h1>Smarty available!</h1>";
		$status .= "(this does not mean that smarty is ";
		$status .= "completely functioning!)<br /><br />";
		$status .= "Press the button to check the Smarty installation";
		$status .= "If all goes well, you will see a message indicating a proper Smarty installation.";
		$status .= "If this is not the case, you need to examine the Smarty errors and take appropriate actions";
		$status .= "<form method='POST' action='test.php'>";
		$status .= "<input type='hidden' name='action' value='checkSmarty'>";
		$status .= "<input type='submit' value='Submit'
			name='checkSmarty'>";
		$status .= "</form>";
	}
}
$status .= "</body></html>";

echo ($status);

exit ();
?>
