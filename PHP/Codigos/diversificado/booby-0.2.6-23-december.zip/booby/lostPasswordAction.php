<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once ('util/databaseConnection.php');
include_once ('sql/authQueries.php');
include_once ('sql/userQueries.php');
include_once ('configs/adminConfiguration.php');
require_once ('model/User.php');
require_once ('model/UserFactory.php');
require_once ('model/Preference.php');
require_once ('UserOperations.php');
require_once ('PreferenceOperations.php');

function randomstring($len)
{
	srand(date("s"));
	while($i<$len)
	{
		$str.=chr((rand()%26)+97);
		$i++;
	}

	$str=$str.substr(uniqid (""),0,22);
	return $str;
}

$rand_value=randomstring(10);
$userFactory = new UserFactory ();
if (isset($_POST['submit']))
{
	if ($_POST['user'] == 'test')
	{
		$message='notAllowedForTestUser';

		Header ("Location: lostPassword.php?message=".$message);
		exit;
	}
	/*
	 * Check for username and email on POST.
	 */
	if (!(isset ($_POST['user'])) && !(isset($_POST['password'])))
	{
		$message='provideEmailAndPassword';
		Header ("Location: lostPassword.php?message=".$message);
		exit;
	}
	/*
	 * Now retrieve the email adres for the user and see 
	 * whether they match
	 */
	$query = sprintf ($queries['getEmail'], $_POST['user']);
	$result = $db->Execute($query) or die ($db->ErrorMsg ());
	$dbEmail = $result->fields[0];


	if ($dbEmail == $_POST['email'])
	{
		// Ok, credentials appear to be correct
		// Generate a (pseudo) random
		$random =  randomstring (10);
		$randomPassword = MD5($random);

		$query = sprintf ($queries ['setPassword'], 
			$randomPassword, $_POST['user']);
		$db -> Execute ($query) or die ($db->ErrorMsg ());
		// Set the users password

		// And send the user a mail
		$message = "Hello ".$_POST['user'].",";
		$message .= "\r\n";
		$message .= "\r\n";
		$message .= "You (or someone pretending to be you) ";
		$message .= "requested a new password. ";

		$message .= "\r\n";
		
		$message .= "Server name: [".$_SERVER['SERVER_NAME']"] ";
		$message .= "Remote address: [".$_SERVER['REMOTE_ADDR']"] ";
		$message .= "Remote host: [".$_SERVER['REMOTE_HOST']"] ";
		
		$message .= "\r\n";

		$message .= "Please go to your Booby bookmarks site and login ";
		$message .= "(username: ".$_POST['user'].") ";
		$message .= "using the following password: ".$random." .";

		$message .= "\r\n";
		$message .= "\r\n";

		$message .= "You can change your temporary password to a simpler one through the ";
		$message .= "Preferences once you log in.";

		$message .= "\r\n";
		$message .= "\r\n";
		$message .= "Sincerely,";
		$message .= "\r\n";
		$message .= "Booby administrator";
		$subject = "Lost Booby password";

		$headers = "MIME-Version: 1.0\r\n";
    	$headers .= "Content-type: text/plain; charset=iso-8859-1\r\n";
		$headers .= "From: Booby administrator <".$adminEmail.">\r\n";
		$headers .= "To: Booby user <".$_POST['email'].">\r\n";
		$headers .= "X-Mailer: Booby";

		mail($adminEmail, $subject, $message, $headers);

		$message = 'tempPasswordSent';
		Header ("Location: login.php?message=".$message);
		exit;
	}
	else
	{
		$message = "Username/email combination does not match";
		Header ("Location: lostPassword.php?message=".$message);
		exit;
	}
}
?>
