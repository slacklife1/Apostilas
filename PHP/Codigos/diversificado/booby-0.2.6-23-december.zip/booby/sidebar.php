<?php
	//include 'util/checkLogin.php';
	include 'configs/adminConfiguration.php';

	global $installationPath;
?>
<html>
<head>
	<title>
		Booby Mozilla/Netscape SideBar
	</title>
	<script language="JavaScript">
        function addBookmarksNetscapePanel() 
        {       
                if ((typeof window.sidebar == "object") && 
                        (typeof window.sidebar.addPanel == "function")) 
                {       
                        window.sidebar.addPanel 
                        ("Booby Bookmarks",
                                "<?php echo ($installationPath); ?>BookmarkSidebarController.php", "");
                }       
        }       
	</script>
 	<link rel="stylesheet" href="doc/css/booby.css" 
		type="text/css" />

</head>

<body>
	<h1>Bookmarks</h1>
	<h2>sidebars</h2>
	<table border="0">
	<tr bgcolor="#ffffff">
		<td>
			<a 
			href="javascript:addBookmarksNetscapePanel();"
			><img src="doc/pics/addnetscapepanel.gif"
			border="0"></a>
		</td>
		<td>
			<a 
			href="javascript:addBookmarksNetscapePanel();"
			><img src="doc/pics/addmozillapanel.gif"
			border="0"></a>
		</td>
		<td>
			<a href="<?php echo ($installationPath);
			?>BookmarkSidebarController.php" 
			rel="sidebar" title="Booby
			Bookmarks"><img src="doc/pics/opera.png"
			border="0"></a> 
		</td>
	</tr>
</body>
</html>
