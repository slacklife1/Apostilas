<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
if (isset ($_SESSION['language']))
{
	include  ('lang/dictionary_' . $_SESSION['language'] . '.php');
}
else
{
	include  ('lang/dictionary_EN.php');
}
/*
 * The current defined items
 */
$menuItems = array();
$menuItems [] =	
		array('href' => 'BookmarkController.php',
			'name' => $dictionary['bookmarks'],
			'icon' => 'Bookmarks');
$menuItems [] =	
		array('href' => 'ContactController.php',
			'name' => $dictionary['contacts'],
			'icon' => 'Contacts');
$menuItems [] =	
		array('href' => 'TodoController.php',
			'name' => $dictionary['todos'],
			'icon' => 'Todos');
$menuItems [] =	
		array('href' => 'NoteController.php',
			'name' => $dictionary['notes'],
			'icon' => 'Notes');
// only include the news section if we have XML parsing enabled
// in PHP
if (function_exists('xml_parser_create'))
{ 
	$menuItems [] =	
		array('href' => 'NewsController.php',
			'name' => $dictionary['news'],
			'icon' => 'News');
}		



/*
 * The application specific breadcrumbs
 */
$menu = array();
$menu [] =
	array('href' => 'PreferenceController.php',
			'name' => $dictionary['preferences'],
			'icon' => 'Preferences');
$menu [] =
	array('href' => 'about.php',
			'name' => $dictionary['about'],
			'icon' => 'Info');
$menu [] =
	array('href' => 'logout.php',
			'name' => $dictionary['logout'],
			'icon' => 'Logout');
// only provide the admin page if we are the admin user
if ($_SESSION['username'] == 'admin')
{
	$menu [] = array('href' => 'admin.php',
			'name' => $dictionary['admin'],
			'icon' => 'Admin');
}
		//array('href' => 'help.php',
			//'name' => $dictionary['help'],
			//'icon' => 'Help'),
?>
