<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */

$tableName = "booby_users"; 
/*
 * LOGIN
 */
$queries['getUsernamePassword']=
		"SELECT username, password FROM ".$tableName.
		" WHERE username='%s'";
$queries['getPassword']=
		"SELECT password FROM ".$tableName.
		" WHERE username='%s'";
// Not yet implemented (field missing in usertable)
$queries['updateLogin']=
		"UPDATE ".$tableName." SET lastLogin='%s' ".
		"WHERE username='%s'";
 ?>