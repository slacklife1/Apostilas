# TODO add modified to each table, and to the operations
#
# Database initialisation for application 'booby'
#
# All tables have a prefix to avoid conflicts with possible
# other applications if no dedicated database exists for application
#
# author: Barry Nauta
#
# If the TEXT field is not recognized by your database, check the following file for the appropriate
# definition: http://www.solarmetric.com/Software/Documentation/latest/docs/sql_types.html

#drop table if exists booby_users;
#drop table if exists booby_permissions;
#drop table if exists booby_preferences;
#drop table if exists booby_bookmarks;
#drop table if exists booby_news;
#drop table if exists booby_contacts;
#drop table if exists booby_notes;
#drop table if exists booby_todos;

######################################################################
# Table definitions
######################################################################


###
# BOOBY_USERS. Field lengths are arbitrary
###
create table booby_users
(
	userId			integer auto_increment not null primary key,
	username 		char(15) not null,
	password 		char(50),
	name			char(50),
	email			char(30), 
	description		text,
	when_created	DATETIME,
	key(userId)
);


###
# BOOBY_PREFERENCES.  This table must directly be created when a user 
# is created and its ID must be the users ID
###
create table booby_preferences
(
	owner			char (50) not null,	#whos preferences?
	language		char(2),
	template		char(50),
	key(owner)
);

###
# BOOBY_TRASH.  
#
# a trash(item) is an item
#
###
create table booby_trash
(
	itemId			integer auto_increment not null primary key,
	owner			char (70) not null,
	parentId		integer not null,
	isParent		BOOL,
	name			char (70),
	description		text,
	visibility		char (10),	# private or public
	category		char (50),
	when_created		DATETIME,
	when_modified		DATETIME,
	when_visited		DATETIME,
	locator			char (255), 
	visitCount		int,
	trashedItemType char(70),
	additionalParameters TEXT,
	key (itemId)
);

###
# BOOBY_BOOKMARKS.  
#
# a bookmark is an item
#
# These should be able to contain all fields of 
# XBEL, opera etc.  sort by parentid. Root has id 0?
###
create table booby_bookmarks 
(
	itemId			integer auto_increment not null primary key,
	owner			char (70) not null,
	parentId		integer not null,
	isParent		BOOL,
	name			char (70),
	description		text,
	visibility		char (10),	# private or public
	category		char (50),
	when_created		DATETIME,
	when_modified		DATETIME,
	when_visited		DATETIME,
	locator			char (255), 
	visitCount		int,
	key (itemId)
);

###
# BOOBY_NEWS.  
#
# a newsitem is an item.
#
# RSS/RDF feed based on URLs
###
create table booby_news
(
	itemId			integer auto_increment not null primary key,
	owner			char (70) not null,
	parentId		integer not null,
	isParent		BOOL,
	name			char (70),
	description		text,
	visibility		char (10),	# private or public
	category		char (50),
	when_created		DATETIME,
	when_modified		DATETIME,
	when_visited		DATETIME,
	locator			char (255), 
	visitCount		int,
	key (itemId)
);

###
# BOOBY_CONTACTS. Create dedicated tables for email/contact links and
# email/webaddresses links
#
# a contact is an item
###
create table booby_contacts
(
	itemId			integer auto_increment not null primary key,
	owner			char (70) not null,
	parentId		integer not null,
	isParent		BOOL,
	name			char (70) not null,
	description		text,
	visibility		char (25),
	category		char (50),
	when_created	DATETIME,
	when_modified	DATETIME,
	alias			char (70),
	address			char (255),
	birthday		DATETIME,
	mobile			char (25),
	faximile		char (25),
	tel_home		char (25),
	tel_work		char (25),
	organization	char (70),
	org_address		char (255),
	job				char (70),
	email1			char (70),
	email2			char (70),
	email3			char (70),
	webaddress1		char (70),
	webaddress2		char (70),
	webaddress3		char (70),
	key (itemId)
);

###
# BOOBY_NOTES. 
#
# a note is an item
###
create table booby_notes
(
	itemId			integer auto_increment not null primary key,
	owner			char (70) not null,
	parentId		integer not null,
	isParent		BOOL,
	name			char (70) not null,
	description 		text,
	visibility		char (15),
	category		char (50),
	when_created	DATETIME,
	when_modified	DATETIME,
	key (itemId)
);

###
# BOOBY_TODOS.
#
# a todo is an item
###
create table booby_todos
(
	itemId			integer auto_increment not null primary key,
	owner			char (70) not null,
	parentId		integer not null,
	isParent		BOOL,
	name			char (70) not null,
	description 		text,
	visibility		char (15),
	category		char (50),
	when_created		DATETIME,
	when_modified		DATETIME,
	priority		integer not null,
	startDate		DATETIME,
	endDate			DATETIME,
	status			char (70),
	percentComplete		integer,
	isFinished		BOOL,
	key (itemId)
);


##########################################################################
# Create minimal info to start the application (you need at least a admin 
# user with preferences)
##########################################################################
insert into booby_users set
        username='admin',
        password=MD5('admin'),
        name='Booby administrator',
        email='barry@nauta.be',
        description='Administrator',
        when_created=NOW();
update booby_users set userId=0 where username='admin';

insert into booby_preferences set
        owner='admin',
        language="EN",
        template="mylook";

insert into booby_bookmarks set
	owner = 'admin',
	isParent=0,
	name='[Booby]',
	description='Booby - Bookmarks, Contacts and more',
	visibility='private',
	category='',
	when_created=NOW(),
	when_modified=null,
	when_visited=null,
	locator='http://www.nauta.be/booby/', 
	visitCount=0,
	parentId=0;
