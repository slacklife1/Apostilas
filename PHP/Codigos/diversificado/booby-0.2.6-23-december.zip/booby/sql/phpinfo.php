<?php
	phpinfo ();
?>