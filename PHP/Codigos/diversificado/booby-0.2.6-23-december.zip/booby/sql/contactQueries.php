<?php

/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */

$tableName="booby_contacts";
include ("itemQueries.php");


/*
 * Contact specific
 */
$queries['addItem']=
		"INSERT INTO ".$tableName." VALUES (".
		"'', '%s', %d, '%s', '%s', '%s', '%s', '%s', '%s', ".
		"'%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', ".
		"'%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')";
$queries['modifyItem']=
		"UPDATE ".$tableName." SET ".
		"when_modified='%s', ".
		"name='%s', ".
		"parentId=%d, ".
		"job='%s', ".
		"alias='%s', ".
		"organization='%s', ".
		"org_address='%s', ".
		"tel_home='%s', ".
		"tel_work='%s', ".
		"faximile='%s', ".
		"mobile='%s', ".
		"address='%s', ".
		"birthday='%s', ".
		"description='%s', ".
		"email1='%s', ".
		"email2='%s', ".
		"email3='%s', ".
		"webaddress1='%s', ".
		"webaddress2='%s', ".
		"webaddress3='%s' ".
		"WHERE itemId=%d";
?>