<?php

/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */

$tableName = "booby_preferences";

/*
 * PREFERENCES
 */
$queries['getPreferences']=
		"SELECT * from ".$tableName." WHERE owner='%s'";
$queries['modifyPreferences']=
		"UPDATE ".$tableName." SET ".
		"language='%s', template='%s' WHERE owner='%s'";
$queries['addPreferences']=
		"INSERT INTO ".$tableName." VALUES ('%s', '%s', '%s')";
$queries['deletePreferences']=
		"DELETE FROM ".$tableName." WHERE owner='%s'";
?>