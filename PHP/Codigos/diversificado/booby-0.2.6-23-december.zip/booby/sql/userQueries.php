<?php

/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */

$tableName = "booby_users";

/*
 * USER
 */
$queries['modifyUser']=
		"UPDATE ".$tableName." SET ".
		"name='%s', password='%s', description='%s', email='%s' ".
		"WHERE username='%s'";
$queries['getUser']=
		"SELECT * from ".$tableName." WHERE username='%s'";
$queries['getAllUsers']=
		"SELECT * from ".$tableName;
$queries['getUserForId']=
		"SELECT * from ".$tableName." WHERE userId='%s'";
$queries['addUser']=
		"INSERT INTO ".$tableName." VALUES (".
		"'', '%s', '%s', '%s', '%s', '%s', '%s')";
$queries['lastUserInsertId']=
		"SELECT last_insert_id() FROM ".$tableName;
$queries['deleteUser']=
		"DELETE FROM ".$tableName." WHERE userId='%s'";
$queries['getEmail']=
		"SELECT email FROM ".$tableName." WHERE username='%s'";
$queries['setPassword']=
		"UPDATE ".$tableName." SET ".
		"password='%s' WHERE username='%s'";
?>
