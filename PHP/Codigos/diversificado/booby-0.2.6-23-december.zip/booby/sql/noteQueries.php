<?php

/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */

$tableName="booby_notes";
include ("itemQueries.php");


/*
 * Note specific
 */
$queries['addItem']=
		"INSERT INTO ".$tableName." VALUES (".
		"'', '%s', %d, %d, '%s', '%s', ".
		"'%s', '%s', '%s', null)";
$queries['modifyItem']=
		"UPDATE ".$tableName." SET ".
		"when_modified='%s', ".
		"name='%s', ".
		"description='%s', ".
		"parentId=%d ".
		"WHERE itemId=%d";
 ?>