<?php

/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
$queries=array ();
/*
 * These are 'abstract' queries. Tablename need to be specified by the file
 * that includes these queries
 */
$queries['getItem']=
		"SELECT * from " . $tableName . " WHERE owner='%s' AND itemId=%d";
		
$queries['getItems']=
		"SELECT * from " . $tableName . " WHERE owner='%s' ".
		"ORDER BY 'isParent' DESC, 'name' ASC";
		
$queries['getSortedItems']=
		"SELECT * FROM " . $tableName . " WHERE owner='%s' ".
		"ORDER BY '%s' '%s'";

$queries['getItemOwner']=
		"SELECT owner from " . $tableName . " WHERE itemId=%d";
		
$queries['lastItemInsertId']=
		"SELECT last_insert_id() FROM " . $tableName;
		
$queries['getItemChildren']=
		"SELECT * from ". $tableName .
		" WHERE parentId=%d AND owner='%s' ".
		"ORDER BY 'isParent' DESC, 'name' ASC";

$queries['getItemChildrenThatAreParent']=
		"SELECT * from ". $tableName .
		" WHERE parentId=%d AND owner='%s' AND isParent=1 ".
		"ORDER BY 'isParent' DESC, 'name' ASC";
		
$queries['deleteItem']=
		"DELETE from " . $tableName . " WHERE itemId=%d";
		
$queries['searchItems']=
		"SELECT * from ".$tableName . 
		" WHERE %s LIKE '%%%s%%' and owner='%s' ".
		"ORDER BY 'isParent' DESC, 'name' ASC";
		
$queries['updateItemVisitCount']=
		"UPDATE ".$tableName .
		" SET visitCount=visitCount+1 ".
		"WHERE itemId=%d";
				
