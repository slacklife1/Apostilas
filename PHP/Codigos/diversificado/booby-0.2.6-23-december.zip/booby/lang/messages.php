<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
$messages=array();
$messages['notAllowedForTestUser']='This operation is not allowed for the test user';
$messages['provideEmailAndPassword']='Please provide both email and password';
$messages['provideUsernameAndPassword']='Please provide both username and password';
$messages['tempPasswordSent']='Your temporary password has been
sent by e-mail.<br />Please use this password to login';
$messages['usernamePasswordMismatch']='Username/email combination
does not match';
$messages['illegalAccess']='Illegal access';
$messages['unknownError']='Unknown error';
$messages['unknownUser']='Unknown user';
$messages['incorrectPassword']='Incorrect password';
$messages['passwordMismatch']='Password mismatch';
$messages['userAlreadyExists']='User already exists';
?>
