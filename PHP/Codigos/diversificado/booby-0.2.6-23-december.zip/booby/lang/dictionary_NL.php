<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
$dictionary=array();
$dictionary['version']='0.2.5';
$dictionary['charset']='iso-8859-1';

$dictionary['home']='Home';
$dictionary['actions']="Acties";
$dictionary['view']="Zicht";
$dictionary['refresh']='Verfris';
$dictionary['sort']='Sorteer';

$dictionary['last_visited']='Laatst bezocht';
$dictionary['most_visited']='Meest bezocht';
$dictionary['last_created']='Laatst aangemaakt';
$dictionary['last_modified']='Laatst gewijzigd';

$dictionary['month01']='Januari';
$dictionary['month02']='Februari';
$dictionary['month03']='Maart';
$dictionary['month04']='April';
$dictionary['month05']='Mei';
$dictionary['month06']='Juni';
$dictionary['month07']='Juli';
$dictionary['month08']='Augustus';
$dictionary['month09']='September';
$dictionary['month10']='Oktober';
$dictionary['month11']='November';
$dictionary['month12']='December';


$dictionary['add']='Voeg toe';
$dictionary['modify']='Wijzig';
$dictionary['delete']='Verwijder';
$dictionary['show']='Toon';
$dictionary['import']='Importeer';
$dictionary['export']='Exporteer';
$dictionary['search']='Zoeken';
$dictionary['move']='Verplaats';
$dictionary['expand']='Uitklappen';
$dictionary['collapse']='Inklappen';
$dictionary['up']='Omhoog';
$dictionary['yahooTree']='Yahoo tree';
$dictionary['explorerTree']='Explorer tree';

$dictionary['bookmarks']='Bladwijzers';
$dictionary['bookmark']='Bladwijzer';
$dictionary['notes']='Notities';
$dictionary['note']='Notitie';
$dictionary['contacts']='Contacten';
$dictionary['contact']='Contact';
$dictionary['todos']='Te doen';
$dictionary['todo']='Te doen';
$dictionary['admin']='Administratie';

$dictionary['root']='Root';
$dictionary['preferences']='Voorkeuren';
$dictionary['help']='Help';
$dictionary['about']='Info';
$dictionary['logout']='Loguit';
$dictionary['loginName']='Login naam';

$dictionary['title']='Titel';
$dictionary['contents']='Inhoud';
$dictionary['folder']='Map';
$dictionary['link']='link';
$dictionary['url']='URL';
$dictionary['description']='Beschrijving';


$dictionary['name']='Naam';
$dictionary['tel_home']='Tel.thuis';
$dictionary['tel_work']='Tel.werk';
$dictionary['mobile']='GSM';
$dictionary['faximile']='Fax.';
$dictionary['email']='Email';
$dictionary['webaddress']='Web&nbsp;address';
$dictionary['birthday']='Geboortedag';
$dictionary['jobTitle']='Functie omschrijving';
$dictionary['alias']='Alias';
$dictionary['organization']='Organisatie';
$dictionary['address']='Adres';
$dictionary['org_address']='Org. Adres';


$dictionary['priority']='Prioriteit';
$dictionary['complete']='Compleet';
$dictionary['status']='Status';
$dictionary['start_date']='Start datum';
$dictionary['due_date']='Eind datum';

$dictionary['file']='Bestand';
$dictionary['submit']='Verstuur';

$dictionary['language']='Taal';
$dictionary['theme']='Thema';
$dictionary['password']='Passwoord';
$dictionary['user']='Gebruiker';
$dictionary['confirm']='Bevestig';
$dictionary['news']='Nieuws';
$dictionary['adduser']='Gebruiker toevoegen';
$dictionary['importusers']='Importeer gebruikers';
$dictionary['exportusers']='Exporteer gebruikers';



$dictionary['help_page']='
<h1>Help</h1>
<p>
	Deze pagina geeft een beknopte uitleg van de applicatie
</p>
<h2>Bladwijzers</h2>
<p>
	Om een bladwijzer toe te voegen, te importeren, te exporteren
	of te zoeken, klik op de juiste link.
</p>
<h2>Contacten</h2>
<h2>Te doen\'s</h2>
<h2>Notities</h2>
';
$dictionary['about_page']='
<h2>Info</h2>
<p><b>Booby '.$dictionary['version'].'</b>
    Deze applicatie (Booby) is geschreven door Barry Nauta
    (email: <a href="mailto:barry@nauta.be">barry@nauta.be</a>)
	Copyright (c) 2003
</p>
<p>
	Het doel van de applicatie is een open-source single login
	applicatie aan te bieden die het mogelijk maakt om online
	items te beheren zoals bladwijzers, notities, contacts etc.
</p>
<p>
	Deze applicatie (Booby) is uitgegeven onder de GNU General Public
	License. Een (engelstalige) volledige versie van deze overeenkomst
	kan <a href="doc/gpl.html">hier</a> gevonden worden.
	De homepage van de applicatie is te vinden op het volgende
	adres: <a
	href="http://www.nauta.be/booby/">http://www.nauta.be/booby/</a>
</p>

';
$dictionary['welcome_page']='<h1>Welkom %s</h1>'.
'<h2>Booby - een veelzijdige dinges.</h2>
Blue Footed Boobies, Red Footed Boobies and masked Boobies.
'.$dictionary['about_page'];
$dictionary['license_disclaimer']='
	De homepage van Booby kan op het volgende adres gevonden worden:
	<a href="http://www.nauta.be/booby">http://www.nauta.be/booby</a>
<br />
    Copyright (c) 2003 Barry Nauta (<a href="http://www.nauta.be/"
    >http://www.nauta.be/</a> of <a
    href="http://www.barrel.net/">http://www.barrel.net/</a>).
	Je kan op hetvolgende adres contact met
	me opnemen:
    <a href="mailto:barry@nauta.be">barry@nauta.be</a>.
<br />
	Deze applicatie (Booby) is uitgegeven onder de GNU General Public
	License. Een (engelstalige) volledige versie van deze overeenkomst
	kan <a href="doc/gpl.html">hier</a> gevonden worden.
';
$dictionary['contact_help']='';
$dictionary['news_help']='Een news-link is een speciale URL (rssFeed/syndicate feed)<br /> en een web-site geeft vaak met behulp van het <br />volgende icoon aan dat het nieuws-feeds heeft: <img src="templates/common/pics/xml.gif">';
$dictionary['todo_help']='';
$dictionary['note_help']='';
$dictionary['bookmark_help']='Klik op het icoon voor <br> de
bladwijzer om deze te kunnen <br>veranderen/verwijderen/verplaatsen.';
$dictionary['quickmark']='Voeg de volgende link toe als bladwijzer in je <b>browser</b>. Het aanroepen van deze link bij het bezoeken van een pagina zorgt ervoor dat de betreffence pagina automatisch wordt toegevoegd als bladwijzer in Booby<br>';

?>
