﻿<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include_once ("configs/adminConfiguration.php");
include ('lang/messages.php');
?>

<html>
<head>
	<title>登入Booby</title>
	<link rel="stylesheet" href="doc/css/booby.css"
	         type="text/css" />
</head>
<body>

	<center>
	<h1>登入Booby</h1>
  	<img src="doc/pics/question_booby.jpg">

	<?php
               if (isset ($_GET['message']))
                {       
                        $messageId = $_GET['message'];
                        $message = $messages[$messageId];

                        if ($message != null)
                        {       
                                echo ("<br><b>".$message."</b>");
                        }       
                        else    
                        {       
                                echo    
                                ('<br><b>'.$messages['unknownError'].'</b>');
                        }
                }               
                else    
                {       
                        echo
                        ("<br><b>".$messages['provideUsernameAndPassword']."</b>");
                }

	?>
	
	<form action="loginAction.php" method="post">
	<?
		if ($allowAnonymousSignon)
		{
	?>
		<br>
                                <table>
		<tr>
			<td>
				帳號:
			</td>
			<td>
				<input type="text" name="username" />
			</td>
			<td>
				<input type="Checkbox" name="signUp" />
			</td>
			<td>
				我要註冊
			</td>
		</tr>
		<tr>
			<td>
				密碼:
			</td>
			<td>
				<input type="password" name="password" />
			</td>
			<td>
				<input type="Checkbox" name="rememberMe" />
			</td>
			<td>
				記住我的資料
			</td>
		</tr>
		<tr>
			<td>
				&nbsp;
			</td>
			<td colspan="2">
				<input type="submit" value="登入" name="submit" />
			</td>
			<td>
				<a href="lostPassword.php">忘記密碼?</a>
			</td>
		</tr>
		</table>
	<?
		}
		else
		{
	?>
			Name: <input type="text" name="username" />
			Password: <input type="password" name="password" />
			<br />
			<br />
			記住我的資料 <input type="Checkbox" name="rememberMe" />
	  		<input type="submit" value="登入" name="submit" />
			<br />
			<a href="lostPassword.php">忘記密碼?</a>
	<?
		}
	?>
	</form>
	<hr />
		<font size="-2">
	<p>
		Copyright (c) 2003 by Barry Nauta (barry@nauta.be,
		<a href="http://www.barrel.net">http://www.barrel.net</a> or
		<a href="http://www.nauta.be">http://www.nauta.be</a>)
	</p>
			</font>
	</center>
</body>
</html>
