<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include_once ("configs/adminConfiguration.php");
include ('lang/messages.php');
?>

<html>
<head>
	<title>�n�JBooby</title>
	<link rel="stylesheet" href="doc/css/booby.css"
	         type="text/css" />
</head>
<body>

	<center>
	<h1>�n�JBooby</h1>
  	<img src="doc/pics/question_booby.jpg">

	<?php
               if (isset ($_GET['message']))
                {       
                        $messageId = $_GET['message'];
                        $message = $messages[$messageId];

                        if ($message != null)
                        {       
                                echo ("<br><b>".$message."</b>");
                        }       
                        else    
                        {       
                                echo    
                                ('<br><b>'.$messages['unknownError'].'</b>');
                        }
                }               
                else    
                {       
                        echo
                        ("<br><b>".$messages['provideUsernameAndPassword']."</b>");
                }

	?>
	
	<form action="loginAction.php" method="post">
	<?
		if ($allowAnonymousSignon)
		{
	?>
		<br>
                                <table>
		<tr>
			<td>
				�b��:
			</td>
			<td>
				<input type="text" name="username" />
			</td>
			<td>
				<input type="Checkbox" name="signUp" />
			</td>
			<td>
				�ڭn���U
			</td>
		</tr>
		<tr>
			<td>
				�K�X:
			</td>
			<td>
				<input type="password" name="password" />
			</td>
			<td>
				<input type="Checkbox" name="rememberMe" />
			</td>
			<td>
				�O���ڪ����
			</td>
		</tr>
		<tr>
			<td>
				&nbsp;
			</td>
			<td colspan="2">
				<input type="submit" value="�n�J" name="submit" />
			</td>
			<td>
				<a href="lostPassword.php">�ѰO�K�X?</a>
			</td>
		</tr>
		</table>
	<?
		}
		else
		{
	?>
			Name: <input type="text" name="username" />
			Password: <input type="password" name="password" />
			<br />
			<br />
			�O���ڪ���� <input type="Checkbox" name="rememberMe" />
	  		<input type="submit" value="�n�J" name="submit" />
			<br />
			<a href="lostPassword.php">�ѰO�K�X?</a>
	<?
		}
	?>
	</form>
	<hr />
		<font size="-2">
	<p>
		Copyright (c) 2003 by Barry Nauta (barry@nauta.be,
		<a href="http://www.barrel.net">http://www.barrel.net</a> or
		<a href="http://www.nauta.be">http://www.nauta.be</a>)
	</p>
			</font>
	</center>
</body>
</html>
