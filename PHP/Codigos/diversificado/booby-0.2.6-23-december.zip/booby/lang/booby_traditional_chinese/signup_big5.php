<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */

include_once ("configs/adminConfiguration.php"); 

session_start();

?>

<html>
<head>
	<title>Booby - ���U</title>
	<link rel="stylesheet" href="css/booby.css"
	         type="text/css" />
</head>
<body>

	<center>
  	<h1>�Τ���U</h1>
  	<p>
  		�ж�J�z���ӤH���
  	</p>
  	<form method="post" action="signupAction.php"> 
  	<table>
  	<tr>
  		<td>�b��:</td>
  		<td><input type="text" name="user" 
  			value="<?php echo ($_SESSION['signupUsername']); ?>" readonly="true"></td>
  	</tr>
  	<tr>
  		<td>�K�X:</td>
  		<td><input type="password" name="password" 
  			value="<?php echo ($_SESSION['signupPassword']); ?>" readonly="true"/></td>
  	</tr>
  	<tr>
  		<td>�T�{�K�X:</td>
  		<td><input type="password" name="password2"/></td>
  	</tr>
  	<tr>
  		<td>�m�W:</td>
  		<td><input type="text" name="name"></td>
  	</tr>
  	<tr>
  		<td>�q�l�l��:</td>
  		<td><input type="text" name="email"/></td>
  	</tr>
  	<tr>
  		<td>�ۧڤ���:</td>
  		<td><textarea name="description"></textarea></td>
  	</tr>
  	<tr>
  		<td>&nbsp;</td>
  		<td><input type="submit" value="�e�X" name="submit" /></td>
  	</tr>
   	</table>
  	</form>

	<hr />
		<font size="-2">
	<p>
		Copyright (c) 2003 by Barry Nauta (barry@nauta.be,
		<a href="http://www.barrel.net">http://www.barrel.net</a> or
		<a href="http://www.nauta.be">http://www.nauta.be</a>).
	</p>
	
		</font>
	</center>
</body>
</html>
