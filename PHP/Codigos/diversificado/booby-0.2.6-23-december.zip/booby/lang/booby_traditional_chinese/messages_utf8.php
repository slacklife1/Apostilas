﻿<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
$messages=array();
$messages['notAllowedForTestUser']='test 帳號無法進行該動作';
$messages['provideEmailAndPassword']='請輸入 電子郵件 和 密碼';
$messages['provideUsernameAndPassword']='請輸入 帳號 和 密碼';
$messages['tempPasswordSent']='你的暫時密碼已經寄出.<br />請用該密碼登入';
$messages['usernamePasswordMismatch']='帳號和所登記之電子郵件地址不相符';
$messages['illegalAccess']='違法的連入';
$messages['unknownError']='錯誤！';
$messages['unknownUser']='沒見過這位使用者哦';
$messages['incorrectPassword']='密碼錯了';
$messages['passwordMismatch']='密碼與帳號不符';
$messages['userAlreadyExists']='該帳號已經有人註冊了';
?>
