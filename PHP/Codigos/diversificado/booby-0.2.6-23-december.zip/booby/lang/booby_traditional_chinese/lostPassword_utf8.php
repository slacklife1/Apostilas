﻿<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */

include_once ("configs/adminConfiguration.php"); 
include ('lang/messages.php');
session_start();

?>
<html>
<head>
	<title>Booby - 密碼遺失</title>
	<link rel="stylesheet" href="doc/css/booby.css" type="text/css" />
</head>
<body>
 <center>
<?php
		if (isset ($_GET['message']))
		{
			$messageId = $_GET['message'];
			$message = $messages[$messageId];

			if ($message != null)
			{
				echo ("<br><h2>".$message."</h2>");
			}
			else
			{
				echo
				('<br><h2>'.$messages['unknownError'].'</h2>');
			}
		}
		else
		{
			echo
			("<br><h2>".$messages['provideEmailAndPassword']."</h2>");
		}
	?>
	<form method="POST" action="lostPasswordAction.php">
	
  <table align="center">
    <tr>
			<td>帳號:</td>
			<td><input type="text" name="user"></td>
		</tr>
		<tr>
			<td>電子郵件:</td>
			<td><input type="text" name="email"></td>
		</tr>
		
    <tr bgcolor="#a9938b"> 
<td>&nbsp;</td>
			
      <td> 
<input type="submit" value="送出"
				name="submit" />
			</td>
		</tr>
	</table>
	</form>
	<font size="-2" color="#857770">
	<p>
		Copyright (c) 2003 by Barry Nauta (barry@nauta.be, or
		<a href="http://www.nauta.be">http://www.nauta.be</a>).
	</p>
	</font>
	</center>
</body>
</html>
