<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
$dictionary=array();
$dictionary['version']='0.2.5';
$dictionary['charset']='iso-8859-1';
$dictionary['home']='Home';
$dictionary['actions']="Aktionen";
$dictionary['view']="Ansicht";
$dictionary['refresh']='Refresh';
$dictionary['sort']='Sort';

$dictionary['last_visited']='Last visited';
$dictionary['most_visited']='Most visited';
$dictionary['last_created']='Last created';
$dictionary['last_modified']='Last modified';

$dictionary['month01']='Januar';
$dictionary['month02']='Februar';
$dictionary['month03']='M�rz';
$dictionary['month04']='April';
$dictionary['month05']='Mai';
$dictionary['month06']='Juni';
$dictionary['month07']='Juli';
$dictionary['month08']='August';
$dictionary['month09']='September';
$dictionary['month10']='Oktober';
$dictionary['month11']='November';
$dictionary['month12']='Dezember';


$dictionary['add']='Hinzuf&uuml;gen';
$dictionary['modify']='Bearbeiten';
$dictionary['show']='Anzeigen';
$dictionary['delete']='L&ouml;schen';
$dictionary['import']='Import';
$dictionary['export']='Export';
$dictionary['search']='Suchen';
$dictionary['move']='Verschieben';
$dictionary['expand']='Erweitern';
$dictionary['collapse']='Verbergen';
$dictionary['up']='Auf';
$dictionary['yahooTree']='Yahoo Struktur';
$dictionary['explorerTree']='Explorer Struktur';

$dictionary['bookmarks']='Lesezeichen';
$dictionary['bookmark']='Lesezeichen';
$dictionary['notes']='Notizen';
$dictionary['note']='Notiz';
$dictionary['contacts']='Kontakte';
$dictionary['contact']='Kontakt';
$dictionary['todos']='Aufgaben';
$dictionary['todo']='Aufgabe';
$dictionary['admin']='Admin';

$dictionary['root']='Root';
$dictionary['preferences']='Einstellungen';
$dictionary['help']='Hilfe';
$dictionary['about']='&Uuml;ber';
$dictionary['logout']='Abmelden';
$dictionary['loginName']='Login Name';

$dictionary['title']='Titel';
$dictionary['contents']='Inhalte';
$dictionary['folder']='Ordner';
$dictionary['link']='Link';
$dictionary['url']='URL';
$dictionary['description']='Beschreibung';


$dictionary['name']='Name';
$dictionary['tel_home']='Tel. Privat';
$dictionary['tel_work']='Tel. Gesch&auml;ft';
$dictionary['mobile']='Mobiltelefon';
$dictionary['faximile']='Fax.';
$dictionary['email']='E-Mail';
$dictionary['webaddress']='Internetadresse';
$dictionary['birthday']='Geburtstag';
$dictionary['jobTitle']='Titel';
$dictionary['alias']='Alias';
$dictionary['organization']='Firma';
$dictionary['address']='Adresse';
$dictionary['org_address']='Gesch&auml;ftsadresse';


$dictionary['priority']='Priorit&auml;t';
$dictionary['complete']='Vollst&auml;ndig';
$dictionary['status']='Status';
$dictionary['start_date']='Start&nbsp;Datum';
$dictionary['due_date']='End&nbsp;Datum';

$dictionary['file']='Datei';
$dictionary['submit']='Absenden';

$dictionary['language']='Sprache';
$dictionary['theme']='Schema';
$dictionary['password']='Passwort';
$dictionary['user']='Benutzer';
$dictionary['confirm']='Best&auml;tigen';

$dictionary['news']='News';
$dictionary['adduser']='Benutzer hinzuf&uuml;gen';
$dictionary['importusers']='Import Benutzer';
$dictionary['exportusers']='Export Benutzer';

$dictionary['help_page']='
<h1>Hilfe</h1>
<p>
	Diese Seite gibt eine kleine Hilfestellung zur Applikation.
</p>
<h2>Lesezeichen</h2>
<p>
	Um Lesezeichen zu importieren, exportieren, suchen oder hinzuzuf&uuml;gen,
	klicken Sie bitte auf den entsprechenden Link.
</p>
<h2>Kontakte</h2>
<h2>Aufgaben</h2>
<h2>Notizen</h2>
';
$dictionary['about_page']='
<h2>�ber</h2>
<p><b>Booby '.$dictionary['version'].'</b>
    Diese Applikation wurde von Barry Nauta geschrieben.<br>
    (email: <a href="mailto:barry@nauta.be">barry@nauta.be</a>)
	Copyright (c) 2003
</p>
<p>
    Beabsichtigt ist das Anbieten einer Open-Source Single Login Remote<br>
    Desktop Applikation (z.B: Ihre Mails, Lesezeichen, Aufgaben usw. in<br>
    einer einheitlichen Umgebung).<br>
</p>
<p>
	Dieses Programm (Booby) wird unter der GNU General Public License<br>
	ver&ouml;ffentlicht. Klicken Sie <a href="doc/gpl.html">hier</a> f&uuml;r die GNU Lizenzbestimmungen.<br>
	Die Internetseite der Applikation kann unter der folgenden Adresse<br>
	abgerufen werden:<a href="http://www.nauta.be/booby/">http://www.nauta.be/booby</a>
</p>

';
$dictionary['welcome_page']='<h1>Herzlich Willkommen %s
</h1><h2>Booby - ein vielseitiges Irgendetwas </h2>
Blue Footed Boobies, Red Footed Boobies und masked Boobies.
'.$dictionary['about_page'];
$dictionary['license_disclaimer']='
	Copyright (c) 2003 Barry Nauta (<a href="http://www.nauta.be/"
	>http://www.nauta.be/</a> or <a
	href="http://www.barrel.net/">http://www.barrel.net/</a>).
	Sie k&ouml;nnen mich erreichen unter:
	<a href="mailto:barry@nauta.be">barry@nauta.be</a>.
<br />
	Dieses Programm (Booby) ist freie Software; Sie k&ouml;nnen die Software
	weiterverbreiten und/oder sie ver&auml;ndern, solange Sie die Bedingungen
	der GNU General Public License, welche von der Free Software Foundation
	ver&ouml;ffentlicht wurde, einhalten; entweder die Lizenzversion 2 oder
	eine sp&auml;tere Version.
	Klicken Sie <a href="doc/gpl.html">hier</a> f&uuml;r die GNU Lizenzbestimmungen.
';
$dictionary['contact_help']='';
$dictionary['news_help']='';
$dictionary['todo_help']='';
$dictionary['note_help']='';
$dictionary['bookmark_help']='Klicken Sie auf das Icon <br>vor dem
Lesezeichen, um das <br>Element zu editieren/l&ouml;schen/verschieben';
$dictionary['quickmark']='Diesen Link zu den <b>Browser-Lesezeichen</b> hinzuf&uuml;gen. Jedes Mal, wenn Sie eine Seite aufrufen und dieses Lesezeichen anklicken, wird die besuchte Seite automatisch zu den Booby-Lesezeichen hinzugef&uuml;gt.<br>';
?>
