<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
$dictionary=array();
$dictionary['version']='0.2.5';
$dictionary['charset']='iso-8859-1';

$dictionary['home']='Home';
$dictionary['actions']="Acciones";
$dictionary['view']="Ver";
$dictionary['refresh']='Refresh';
$dictionary['sort']='Sort';

$dictionary['month01']='Enero';
$dictionary['month02']='Febrero';
$dictionary['month03']='Marzo';
$dictionary['month04']='Abril';
$dictionary['month05']='Mayo';
$dictionary['month06']='Junio';
$dictionary['month07']='Julio';
$dictionary['month08']='Agosto';
$dictionary['month09']='Septiembre';
$dictionary['month10']='Octubre';
$dictionary['month11']='Noviembre';
$dictionary['month12']='Diciembre';


$dictionary['last_visited']='Last visited';
$dictionary['most_visited']='Most visited';
$dictionary['last_created']='Last created';
$dictionary['last_modified']='Last modified';

$dictionary['add']='A�adir';
$dictionary['modify']='Modificar';
$dictionary['show']='Mostrar';
$dictionary['delete']='Borrar';
$dictionary['import']='Importar';
$dictionary['export']='Exportar';
$dictionary['search']='Buscar';
$dictionary['move']='Mover';
$dictionary['expand']='Expandir';
$dictionary['collapse']='Colapsar';
$dictionary['up']='Arriba';
$dictionary['yahooTree']='Arbol de Yahoo';
$dictionary['explorerTree']='Arbol de Explorer';

$dictionary['bookmarks']='Enlaces';
$dictionary['bookmark']='Enlace';
$dictionary['notes']='Notas';
$dictionary['note']='Nota';
$dictionary['contacts']='Direcciones';
$dictionary['contact']='Direccione';
$dictionary['todos']='Tareas';
$dictionary['todo']='Tareas';
$dictionary['admin']='Administracion';

$dictionary['root']='Raiz';
$dictionary['preferences']='Preferencias';
$dictionary['help']='Ayuda';
$dictionary['about']='Acerca de';
$dictionary['logout']='Salir';
$dictionary['loginName']='Login';

$dictionary['title']='Titulo';
$dictionary['contents']='Contenidos';
$dictionary['folder']='Carpeta';
$dictionary['link']='vinculo';
$dictionary['url']='URL';
$dictionary['description']='Descripcion';


$dictionary['name']='Nombre';
$dictionary['tel_home']='Telefono&nbsp;particular';
$dictionary['tel_work']='Telefono&nbsp;del&nbsp;trabajo';
$dictionary['mobile']='Movil';
$dictionary['faximile']='Fax.';
$dictionary['email']='Correo electronico';
$dictionary['webaddress']='Direccion&nbsp;web';
$dictionary['birthday']='Cumplea�os';
$dictionary['jobTitle']='Titulo de trabajo';
$dictionary['alias']='Alias';
$dictionary['organization']='Agrupacion';
$dictionary['address']='Direccion';
$dictionary['org_address']='Direccion&nbsp;de la&nbsp;Agrupacion';


$dictionary['priority']='Prioridad';
$dictionary['complete']='Completado';
$dictionary['status']='Status';
$dictionary['start_date']='Fecha de comienzo';
$dictionary['due_date']='Fecha limite';

$dictionary['file']='Fichero';
$dictionary['submit']='Entregar/Someter';

$dictionary['language']='Lengua';
$dictionary['theme']='Tema';
$dictionary['password']='Contrase�a';
$dictionary['user']='Usuario';
$dictionary['confirm']='Confirmar';

$dictionary['news']='Noticias';
$dictionary['adduser']='A�adir Usuario';
$dictionary['importusers']='Importar Usuarios';
$dictionary['exportusers']='Exportar Usuarios';

$dictionary['help_page']='
<h1>Help</h1>
<p>
	Esta pagina provee un poco de ayuda para la aplicacion.
</p>
<h2>Registros</h2>
<p>
	Para a�adir, importar, exportar o buscar un vinculo, hacer clic sobre el control apropiado.
</p>
<h2>Contactos</h2>
<h2>Por hacer</h2>
<h2>Notas</h2>
';
$dictionary['about_page']='
<h2>Acerca de</h2>
<p><b>Booby '.$dictionary['version'].'</b>
    Esta aplicacion ha sido escrita por Barry Nauta.
    (email: <a href="mailto:barry@nauta.be">barry@nauta.be</a>)
	Copyright (c) 2003
</p>
<p>
    El proposito es proveer una aplicacion de codigo libre con una unica entrada a un tablero de escritorio
    (por ejemplo, su correo electronico, vinculos, cosas por hacer, etc, integrado en un solo medio ambiente)
</p>
<p>
	Este programa (Booby) ha sido publicado bajo la Licencia Publica General (GNU en ingles).
	Haga un clic  <a href="doc/gpl.html">aqui</a> para ver la version completa de la licencia.
	La pagina de inicio de la aplicacion la puede encontrar en la siguiente direccion
	href="http://www.nauta.be/booby/">http://www.nauta.be/booby</a>
</p>

';
$dictionary['welcome_page']='<h1>Welcome %s
</h1><h2>Booby - a multithingy something </h2>
Blue Footed Boobies, Red Footed Boobies and masked Boobies.
'.$dictionary['about_page'];
$dictionary['license_disclaimer']='
	Copyright (c) 2003 Barry Nauta (<a href="http://www.nauta.be/"
	>http://www.nauta.be/</a> or <a
	href="http://www.barrel.net/">http://www.barrel.net/</a>).
	Puede contactarme en
	<a href="mailto:barry@nauta.be">barry@nauta.be</a>.
<br />
	Este programa (Booby) es software libre; usted puede redistribuirlo y/o modificarlo
	bajo los terminos de la GNU Licencia Publica General
	y publicado por "Free Software Foundation"; o version 2 de la licencia, o
	(segun su criterio) cualquier version posterior.
	Haga clic <a href="doc/gpl.html">para</a> ver la licencia completa.
';
$dictionary['contact_help']='';
$dictionary['news_help']='';
$dictionary['todo_help']='';
$dictionary['note_help']='';
$dictionary['bookmark_help']='Haga clic en el icono en frente del vinculo para editar/borrar/mover el objeto.';
$dictionary['quickmark']='A�ada el vinculo siguiente a sus registros en su browser. Cada vez que visite una pagina y llame este vinculo especifico, la pagina visitada sera automaticamente a�adida a su Booby-registros.<br>';
?>
