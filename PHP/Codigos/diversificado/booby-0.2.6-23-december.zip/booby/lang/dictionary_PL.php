<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
$dictionary=array();
$dictionary['version']='0.2.5';
$dictionary['charset']='iso-8859-2';

$dictionary['home']='Home';
$dictionary['actions']="Akcje";
$dictionary['view']="Widoki";
$dictionary['news']='Aktualnosci';
$dictionary['refresh']='Refresh';
$dictionary['sort']='Sort';

$dictionary['last_visited']='Last visited';
$dictionary['most_visited']='Most visited';
$dictionary['last_created']='Last created';
$dictionary['last_modified']='Last modified';

$dictionary['month01']='January';
$dictionary['month02']='February';
$dictionary['month03']='March';
$dictionary['month04']='April';
$dictionary['month05']='May';
$dictionary['month06']='June';
$dictionary['month07']='July';
$dictionary['month08']='August';
$dictionary['month09']='September';
$dictionary['month10']='October';
$dictionary['month11']='November';
$dictionary['month12']='December';


$dictionary['quickmark']='Dodaj ponizszy link do swoich zakladek w <b>przegladarce</b>. Za kazdym razyem gdy odwiedzisz jakas strone i wywolasz ta wlasnie zakladke, ogladana strona automatycznie zostanie dodana do Twoich zakladek w Booby.<br>';
$dictionary['expand']='Rozwin';
$dictionary['collapse']='Zwin';
$dictionary['up']='Do g�ry';
$dictionary['yahooTree']='Drzewo Yahoo';
$dictionary['explorerTree']='Drzewo Explorera';
$dictionary['loginName']='Login';

$dictionary['add']='Dodaj';
$dictionary['modify']='Zmie�';
$dictionary['show']='Poka�';
$dictionary['delete']='Skasuj';
$dictionary['import']='Importuj';
$dictionary['export']='Eksportuj';
$dictionary['search']='Szukaj';
$dictionary['move']='Przenie�';

$dictionary['bookmarks']='Zak�adki';
$dictionary['bookmark']='Zak�adka';
$dictionary['notes']='Notatki';
$dictionary['note']='Notatka';
$dictionary['contacts']='Kontakty';
$dictionary['contact']='Kontakt';
$dictionary['todos']='Zadania';
$dictionary['todo']='Zadanie';
$dictionary['admin']='Administracja';

$dictionary['root']='G��wny';
$dictionary['preferences']='Ustawienia';
$dictionary['help']='Pomoc';
$dictionary['about']='O programie';
$dictionary['logout']='Wyloguj';

$dictionary['title']='Tytu�';
$dictionary['contents']='Zawarto��';
$dictionary['folder']='Katalog';
$dictionary['link']='link';
$dictionary['url']='URL';
$dictionary['description']='Opis';


$dictionary['name']='Imi�';
$dictionary['tel_home']='Tel. dom.';
$dictionary['tel_work']='Tel. prac.';
$dictionary['mobile']='Tel. kom.';
$dictionary['faximile']='Fax.';
$dictionary['email']='Email';
$dictionary['webaddress']='Adres&nbsp;strony';
$dictionary['birthday']='Urodziny';
$dictionary['jobTitle']='Stanowisko';
$dictionary['alias']='Alias/Nick';
$dictionary['organization']='Firma';
$dictionary['address']='Adres';
$dictionary['org_address']='Adres firmy';


$dictionary['priority']='Priorytet';
$dictionary['complete']='Za�atwione';
$dictionary['status']='Status';
$dictionary['start_date']='Data rozpocz�cia';
$dictionary['due_date']='Data zako�czenia';

$dictionary['file']='Plik';
$dictionary['submit']='Wy�lij';

$dictionary['language']='J�zyk';
$dictionary['theme']='Temat';
$dictionary['password']='Has�o';
$dictionary['user']='U�ytkownik';
$dictionary['confirm']='Potwierd�';

$dictionary['adduser']='Dodaj u�ytkownika';
$dictionary['importusers']='Importuj u�ytkownik�w';
$dictionary['exportusers']='Eksportuj u�ytkownik�w';

$dictionary['help_page']='
<h1>Pomoc</h1>
<p>
	Ta strona dostarcza kilku informacji o aplikacji
</p>
<h2>Zak�adki</h2>
<p>
	Aby dodawa�, importowa�, eksportowa� lub przeszukiwa� zak�adki
	wybierz odpowiedni� akcj�.
</p>
<h2>Kontakty</h2>
<h2>Zadania</h2>
<h2>Notatki</h2>
';
$dictionary['about_page']='
<h2>O programie</h2>
<p><b>Booby '.$dictionary['version'].'</b>
	Aplikacja zosta�a napisana przez Barry\'ego Nauta
    (email: <a href="mailto:barry@nauta.be">barry@nauta.be</a>)
	Copyright (c) 2003
</p>
<p>
	G��wnym jej zadaniem jest dostarczy� u�yteczno�� prostej aplikacji
	biurowej opartej na zasadach prostego logowania i utrzymanej w duchu open-source.
    (np. Twoje maile, zak�adki, zadania itp. zintegrowane w jednym �rodowisku)</p>
<p>
	Ten program (Booby) jest udost�pniony na zasadach GNU General Public
	License. Kliknij <a href="doc/gpl.html">tutaj</a> aby zobaczy� pe�n� tre�� licencji
	Strona domowa projektu to:  <a
	href="http://www.nauta.be/booby/">http://www.nauta.be/booby</a>
</p>

';
$dictionary['welcome_page']='<h1>Witaj %s
</h1><h2>Booby - a multithingy something </h2>
Blue Footed Boobies, Red Footed Boobies and masked Boobies.
'.$dictionary['about_page'];
$dictionary['license_disclaimer']='
	Copyright (c) 2003 Barry Nauta (<a href="http://www.nauta.be/"
	>http://www.nauta.be/</a> or <a
	href="http://www.barrel.net/">http://www.barrel.net/</a>).
	Mo�esz si� ze mn� skontaktowa� pisz� na adres :
	<a href="mailto:barry@nauta.be">barry@nauta.be</a>.
<br />
	Ten program (Booby) jest wolnym oprogramowaniem; mo�esz go redystrybuowa� i/lub
	modyfikowa� w granicach licencji GNU General Public License opublikowanej przez
	Free Software Foundation; w wersji 2 Licencji, lub (wg. uznania) ka�dej p�niejszej wersji.
	Kliknij <a href="doc/gpl.html">tutaj</a> aby zobaczy� pe�n� tre�� licencji.

';
$dictionary['contact_help']='';
$dictionary['news_help']='';
$dictionary['todo_help']='';
$dictionary['note_help']='';
$dictionary['bookmark_help']='Kliknij na ikon� przy <br>nazwie zak�adki
aby m�c edytowa�/usuwa�/przenosi� elementy';

?>
