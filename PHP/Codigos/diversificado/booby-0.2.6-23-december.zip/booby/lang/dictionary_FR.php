<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
$dictionary=array();
$dictionary['version']='0.2.5';
$dictionary['charset']='iso-8859-1';

$dictionary['home']='Home';
$dictionary['actions']="Actions";
$dictionary['view']="Vue";
$dictionary['refresh']='Refresh';
$dictionary['sort']='Tri';

$dictionary['last_visited']='Dernier visit�';
$dictionary['most_visited']='Le plus visit�';
$dictionary['last_created']='Dernier cr��';
$dictionary['last_modified']='Dernier modifi�';

$dictionary['month01']='Janvier';
$dictionary['month02']='F�vrier';
$dictionary['month03']='Mars';
$dictionary['month04']='Avril';
$dictionary['month05']='Mai';
$dictionary['month06']='Juin';
$dictionary['month07']='Juillet';
$dictionary['month08']='Ao�t';
$dictionary['month09']='Septembre';
$dictionary['month10']='Octobre';
$dictionary['month11']='Novembre';
$dictionary['month12']='D�cembre';


$dictionary['add']='Ajouter';
$dictionary['modify']='Modifier';
$dictionary['delete']='Effacer';
$dictionary['show']='Montrer';
$dictionary['import']='Importer';
$dictionary['export']='Exporter';
$dictionary['search']='Chercher';
$dictionary['move']='D�placer';
$dictionary['expand']='D�velopper';
$dictionary['collapse']='R�duire';
$dictionary['up']='En haut';
$dictionary['yahooTree']='Arborescence Yahoo';
$dictionary['explorerTree']='Arborescence Explorer';

$dictionary['bookmarks']='Signets';
$dictionary['bookmark']='Signet';
$dictionary['notes']='Notes';
$dictionary['note']='Note';
$dictionary['contacts']='Contacts';
$dictionary['contact']='Contact';
$dictionary['todos']='T�ches';
$dictionary['todo']='T�che';
$dictionary['admin']='Administration';

$dictionary['root']='Racine';
$dictionary['preferences']='Pr�f�rences';
$dictionary['help']='Aide';
$dictionary['about']='Info';
$dictionary['logout']='D�sengager';
$dictionary['loginName']='Nom de login';

$dictionary['title']='Titre';
$dictionary['contents']='Contenu';
$dictionary['folder']='R�pertoire';
$dictionary['link']='lien';
$dictionary['url']='URL';
$dictionary['description']='Description';


$dictionary['name']='Nom';
$dictionary['tel_home']='Tel.priv�';
$dictionary['tel_work']='Tel.bureau';
$dictionary['mobile']='GSM';
$dictionary['faximile']='Fax.';
$dictionary['email']='Email';
$dictionary['webaddress']='Web&nbsp;address';
$dictionary['birthday']='Date de naissance';
$dictionary['jobTitle']='Fonction';
$dictionary['alias']='Alias';
$dictionary['organization']='Organisation';
$dictionary['address']='Adresse';
$dictionary['org_address']="Adresse de l'org.";


$dictionary['priority']='Priorit�';
$dictionary['complete']='% Complet';
$dictionary['status']='Statut';
$dictionary['start_date']='Date de d�but';
$dictionary['due_date']='Date de fin';

$dictionary['file']='Fichier';
$dictionary['submit']='Envoyer';

$dictionary['language']='Langue';
$dictionary['theme']='Th�me';
$dictionary['password']='Mot de passe';
$dictionary['user']='Utilisateur';
$dictionary['confirm']='Confirmer';
$dictionary['news']='Nouvelles';
$dictionary['adduser']='Ajouter utilisateur';
$dictionary['importusers']='Importer utilisateurs';
$dictionary['exportusers']='Exporter utilisateurs';



$dictionary['help_page']="
<h1>Help</h1>
<p>
	Cette page donne une explication sommaire de l'application
</p>
<h2>Bladwijzers</h2>
<p>
Cliquer sur le lien correspondant pour ajouter, importer, exporter
ou chercher un signet
</p>
<h2>Contacts</h2>
<h2>T�che(s)</h2>
<h2>Notes</h2>
";
$dictionary['about_page']='
<h2>Info</h2>
<p><b>Booby '.$dictionary['version'].'</b>
	Cette application (Booby) a �t� �crite par Barry Nauta
	(email: <a href="mailto:barry@nauta.be">barry@nauta.be</a>)
	Copyright (c) 2003

</p>
<p>
	Le but des cette application est d\'offrir une application
open-source avec	login unique donnant la possibilit� de g�rer en
ligne des signets,
des notes, des contacts, etc.
</p>
<p>
	Cette application (Booby) est publi�e sous la license \'GNU
General
Public
	License\'. Une version compl�te (en anglais) de ce contrat peut
�tre
trouv�e <a href="doc/gpl.html">ici</a>.
La page web de cette application se trouve � l\'adresse suivante:<a
href="http://www.nauta.be/booby/">http://www.nauta.be/booby/</a>
</p>

';
$dictionary['welcome_page']='<h1>Bienvenue %s</h1>'.
'<h2>Booby - un truc polyvalent.</h2>
Blue Footed Boobies, Red Footed Boobies and masked Boobies.
'.$dictionary['about_page'];
$dictionary['license_disclaimer']='
    Copyright (c) 2003 Barry Nauta (<a href="http://www.nauta.be/"
    >http://www.nauta.be/</a> of <a
    href="http://www.barrel.net/">http://www.barrel.net/</a>).
	Tu peux me contacter � l\'adresse suivante:
    <a href="mailto:barry@nauta.be">barry@nauta.be</a>.
<br />
Cette application (Booby) est publi�e sous la license \'GNU General
Public
	License\'. Une version compl�te (en anglais) de ce contrat peut
�tre
trouv�e <a href="doc/gpl.html">ici</a>.
';
$dictionary['contact_help']='';
$dictionary['news_help']='';
$dictionary['todo_help']='';
$dictionary['note_help']='';
$dictionary['bookmark_help']="Cliquez sur l'ic�ne se trouvant <br />
devant le signet afin de <br />modifier, d'effacer ou de d�placer l'�l�ment.
";
$dictionary['quickmark']='Ajouter le lien suivant � tes signets dans ton <b>navigateur</b>. Chaque fois que tu visites une page et appelle ce lien sp�cifique, la page visit�e sera automatiquement ajout�e � tes signets dans Booby.';

?>
