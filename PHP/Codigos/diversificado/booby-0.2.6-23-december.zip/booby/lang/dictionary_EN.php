<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
$dictionary=array();
$dictionary['version']='0.2.5';
$dictionary['charset']='iso-8859-1';

$dictionary['home']='Home';
$dictionary['actions']="Actions";
$dictionary['view']="View";
$dictionary['refresh']='Refresh';
$dictionary['sort']='Sort';

$dictionary['last_visited']='Last visited';
$dictionary['most_visited']='Most visited';
$dictionary['last_created']='Last created';
$dictionary['last_modified']='Last modified';

$dictionary['month01']='January';
$dictionary['month02']='February';
$dictionary['month03']='March';
$dictionary['month04']='April';
$dictionary['month05']='May';
$dictionary['month06']='June';
$dictionary['month07']='July';
$dictionary['month08']='August';
$dictionary['month09']='September';
$dictionary['month10']='October';
$dictionary['month11']='November';
$dictionary['month12']='December';

$dictionary['add']='Add';
$dictionary['modify']='Modify';
$dictionary['show']='Show';
$dictionary['delete']='Delete';
$dictionary['import']='Import';
$dictionary['export']='Export';
$dictionary['search']='Search';
$dictionary['move']='Move';
$dictionary['expand']='Expand';
$dictionary['collapse']='Collapse';
$dictionary['up']='Up';
$dictionary['yahooTree']='Directory structure';
$dictionary['explorerTree']='Tree structure';

$dictionary['bookmarks']='Bookmarks';
$dictionary['bookmark']='Bookmark';
$dictionary['notes']='Notes';
$dictionary['note']='Note';
$dictionary['contacts']='Contacts';
$dictionary['contact']='Contact';
$dictionary['todos']='Todos';
$dictionary['todo']='Todo';
$dictionary['admin']='Admin';

$dictionary['root']='Root';
$dictionary['preferences']='Preferences';
$dictionary['help']='Help';
$dictionary['about']='About';
$dictionary['logout']='Logout';
$dictionary['loginName']='Login name';

$dictionary['title']='Title';
$dictionary['contents']='Contents';
$dictionary['folder']='Folder';
$dictionary['link']='link';
$dictionary['url']='URL';
$dictionary['description']='Description';


$dictionary['name']='Name';
$dictionary['tel_home']='Tel.home';
$dictionary['tel_work']='Tel.work';
$dictionary['mobile']='Mobile';
$dictionary['faximile']='Fax.';
$dictionary['email']='Email';
$dictionary['webaddress']='Web&nbsp;address';
$dictionary['birthday']='Birthday';
$dictionary['jobTitle']='Job title';
$dictionary['alias']='Alias';
$dictionary['organization']='Organization';
$dictionary['address']='Address';
$dictionary['org_address']='Org. Address';


$dictionary['priority']='Priority';
$dictionary['complete']='Complete';
$dictionary['status']='Status';
$dictionary['start_date']='Start date';
$dictionary['due_date']='Due date';

$dictionary['file']='File';
$dictionary['submit']='Submit';

$dictionary['language']='Language';
$dictionary['theme']='Theme';
$dictionary['password']='Password';
$dictionary['user']='User';
$dictionary['confirm']='Confirm';

$dictionary['news']='News';
$dictionary['adduser']='Add user';
$dictionary['importusers']='Import users';
$dictionary['exportusers']='Export users';

$dictionary['help_page']='
<h1>Help</h1>
<p>
	This page provides a little bit of help on the application
</p>
<h2>Bookmarks</h2>
<p>
	To add, import, export or search a bookmark, click on the
	appropriate control.
</p>
<h2>Contacts</h2>
<h2>Todos</h2>
<h2>Notes</h2>
';
$dictionary['about_page']='
<h2>About</h2>
<p><b>Booby '.$dictionary['version'].'</b>
    This application is written by Barry Nauta
    (email: <a href="mailto:barry@nauta.be">barry@nauta.be</a>)
	Copyright (c) 2003
</p>
<p>
    The purpose is to provide an open-source single login remote
    desktop
    application (i.e. your mail, bookmarks, todos etc integrated in
    one environment)
</p>
<p>
	This program (Booby) is release under the GNU General Public
	License. Click <a href="gpl.html">here</a> for the full version of
	the license.
	The homepage of the application can be found at the following
	address: <a
	href="http://www.nauta.be/booby/">http://www.nauta.be/booby</a>
</p>

';
$dictionary['welcome_page']='<h1>Welcome %s
</h1><h2>Booby - a multithingy something </h2>
Blue Footed Boobies, Red Footed Boobies and masked Boobies.
'.$dictionary['about_page'];
$dictionary['license_disclaimer']='
	The homepage of the Booby application can be found at the following address:
	<a href="http://www.nauta.be/booby">http://www.nauta.be/booby</a>
<br />
	Copyright (c) 2003 Barry Nauta (<a href="http://www.nauta.be/"
	>http://www.nauta.be/</a> or <a
	href="http://www.barrel.net/">http://www.barrel.net/</a>).
	You can contact me at
	<a href="mailto:barry@nauta.be">barry@nauta.be</a>.
<br />
	This program (Booby) is free software; you can redistribute it
	and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	Click <a href="gpl.html">here</a> for the full version of the
	license.
';
$dictionary['contact_help']='';
$dictionary['news_help']='Use EDIT icon to move/delete/edit a link.<br />A news-link is a special URL (rssFeed/syndicate feed) and a site typically indicates that has <br />news feeds by showing this icon: <img src="templates/common/pics/xml.gif"><br><br>To move a link to another folder or Root, <br>click on Edit  => Move => click on the folder you want to move the link to.';
$dictionary['todo_help']='';
$dictionary['note_help']='';
$dictionary['bookmark_help']='Use EDIT icon to move/delete/edit a link.<br><br>To move a link to another folder or Root, <br>click on Edit  => Move => click on the folder you want to move the link to.';
$dictionary['quickmark']='RIGHT-CLICK on the following link to add it to Bookmarks/Favorites in your <b>browser</b>. <br>Each time you use this bookmark from your browser\'s bookmarks, the page you are on will be automatically added to your Booby bookmarks.<br><br><font size="-2">Please click "OK" if asked about adding the bookmark - code that "picks up" the address of the page you want to bookmark makes some browsers nervous.</font><br>';

$dictionary['Sort']='Sort';
$dictionary['last_visited']='Last visited';
$dictionary['last_modified']='Last modified';
$dictionary['last_created']='Last created';
$dictionary['most_visited']='Most visited';

?>
