<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once 'util/databaseConnection.php';
include ('sql/authQueries.php');
if (isset($_POST['submit']))
{
	/*
	 * Check for username and password on POST
	 */
	if(!$_POST['username'] | !$_POST['password'])
	{
		$message='provideUsernameAndPassword';
		Header ("Location: login.php?message=".$message);
		exit;
	}

	/*
	 * Check whether we would like to signup 
	 */
	if (isset ($_POST['signUp']))
	{
		global $db, $queries;
		
		session_start ();
		$_SESSION['signupUsername'] = $_POST['username'];
		$_SESSION['signupPassword'] = $_POST['password'];
		header ("Location: signup.php");
		exit;
	}

	/*
	 * Query the database
	 */
	$query = sprintf ($queries ['getUsernamePassword'], $_POST['username']);
	
	$result = $db->Execute($query);

	$dbUsername = $result->fields[0];
	$dbPassword = $result->fields[1];

	/*
	 * Check username
	 */
	if ($result == null || $dbUsername == null || $dbUsername == "" 
		|| $dbUsername != $_POST['username'])
	{
		$message='unknownUser';
		Header ("Location: login.php?message=".$message);
		exit;
	}

	/*
	 * Check password
	 */
	$_POST['password'] = md5($_POST['password']);

	if ($_POST['password'] != $dbPassword)
	{
		$message='incorrectPassword';
		Header ("Location: login.php?message=".$message);
		exit;
	}

	/*
	 * Update last login
	 *
	 * Not yet implemented (field missing in usertable)
	 */
	// $date = date('m d, Y');
	// $query = $queries['updateLogin'];
	// $result = $db->Execute($query);

	$db->Close ();


	/*
	 * Start the session
	 */
	session_start ();
	$_SESSION['username'] = $_POST['username'];


	/*
	 * Only set a cookie if the user has requested it
	 */
	if (isset ($_POST['rememberMe']))
	{
		/*
		 * Build up cookie information
		 */
		$cookieId = 'Booby';
		$cookieValue = "username=".$_SESSION['username']."&password=".$_POST['password'];
		$cookieExpire = time() + 365*24*3600; //365 days
		$cookiePath = "";
		$cookieDomain = "";
		$cookieSecure = 0;

		/*
		 * And actually set the cookie
		 */
		if (!setCookie ($cookieId, $cookieValue, $cookieExpire, $cookiePath, $cookieDomain, $cookieSecure))
		{
			die ("Problem setting cookie");
		}
	}

	/*
	 * Forward to the index page
	 */
	header ('Location: index.php');
	exit;
}

?>
