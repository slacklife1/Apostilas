<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include ('util/checkLogin.php');
include ('configs/preferenceConfiguration.php');
include ('configs/adminConfiguration.php');
include ('menuItems.php');


if ($renderEngineName == 'phpSavant')
{
	include ('Savant-1.2/Savant.php');
	$renderer = 'showAbout.tpl.php';
	$renderEngine =& new Savant ();
}
else
{
	include ('configs/MySmarty.php');
	$renderer = 'showAbout.tpl';
	$renderEngine = new MySmarty ();
}

$renderEngine->assign('renderObjects', $dictionary['about_page']);
$renderEngine->assign('renderer', $renderer);
$renderEngine->assign('dictionary', $dictionary);
$renderEngine->assign('title', 'Booby - About');
$renderEngine->assign('menuItems', $menuItems);
$renderEngine->assign('menu', $menu);

if ($renderEngineName == 'phpSavant')
{
	if (file_exists ('templates/'.$_SESSION['template'].'/'.$renderer))
	{
		$renderEngine->assign('renderer', 'templates/'.$_SESSION['template'] . '/' . $renderer);
	}
	else
	{
		$renderEngine->assign('renderer', 'templates/common/' . $renderer);
	}
	$renderEngine->display('templates/'.$_SESSION['template'].'/'.'template.tpl.php');
}
else
{
	if ($renderEngine->template_exists ($_SESSION['template'] . '/' . $renderer))
	{
		$renderEngine->assign('renderer', 'templates/'.$_SESSION['template'] . '/' . $renderer);
	}
	else
	{
		// default to common if the template does not exist
		$renderEngine->assign('renderer', 'templates/common/' . $renderer);
	}
	if (isset ($_GET['debug']))
	{
		include ('util/debug.php');
	}
	$renderEngine->display($_SESSION['template'].'/'.'template'.$templateExtension);
}
//error_reporting(E_ERROR);
?>

