<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include ('util/checkLogin.php');
include ('configs/preferenceConfiguration.php');
include ('menuItems.php');
include ('configs/adminConfiguration.php');
include ('configs/languages.php');
if ($renderEngineName == 'Smarty')
{
	include ('configs/MySmarty.php');
	$rendererEngine=new MySmarty;
}
else
{
	include ('Savant-1.2/Savant.php');
	$renderEngine =& new Savant ();
}
$renderObjects = sprintf ($dictionary['welcome_page'], $_SESSION['username']);


$renderEngine->assign('title', 'Booby');
$renderEngine->assign('menuItems', $menuItems);
$renderEngine->assign('menu', $menu);
$renderEngine->assign('renderObjects', $renderObjects);
$renderEngine->assign('dictionary', $dictionary);
$renderEngine->assign('languages', $languages);

if ($renderEngineName == 'Smarty')
{
	$renderer='index.tpl';
	if ($renderEngine->template_exists 
		($_SESSION['template'] . '/' . $renderer))
	{
		$renderEngine->assign('renderer', 
			$_SESSION['template'] . '/' . $renderer);
	}
	else
	{
		// default to common if the template does not exist
		$renderEngine->assign('renderer', 'common/' . $renderer);
	}
	if (isset($_GET['debug']))
	{
		$renderEngine->debug=true;
		$renderEngine->debug_tpl='debug.tpl';
		$renderEngine->_smarty_debug_id='SMARTY_DEBUG';	
		$renderEngine->_smarty_debug_info=array();
		$renderEngine->display($_SESSION['template'] . '/template.tpl');
	}
}
else
{
	$renderer='index.tpl.php';
	if (file_exists ('templates/'.
        	$_SESSION['template'] . '/' .
		$renderer))
	{
		$renderEngine->assign('renderer', 
			'templates'.$_SESSION['template'].'/'.$renderer);
	}
	else
	{
		$renderEngine->assign('renderer', 
			'templates/common/'.$renderer);
	}
	if (isset($_GET['debug']))
	{
		$renderResult = $renderEngine->display($_SESSION['template'] . '/template.tpl.php');
	}
	else
	{
		//error_reporting(E_ERROR);
		$renderResult = $renderEngine->display('templates/'.$_SESSION['template'] . '/template.tpl.php');
	}
		if (PEAR::isError($renderResult)) 
		{
			echo ("Oops: ".$renderResult);
		}
}

?>
