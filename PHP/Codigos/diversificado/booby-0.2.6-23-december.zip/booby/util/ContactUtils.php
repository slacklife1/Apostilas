<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once ('util/StringUtils.php');
require_once ('util/ItemUtils.php');
/**
 * Contact utilities
 * This file allows import and export from and to opera contacts
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.util
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class ContactUtils extends ItemUtils
{
	/**
	 * Empty default constructor
	 */
	function ContactUtils ()
	{
		parent::ItemUtils();
	}

	/**
	 * import a opera contact file into user's DB
	 * 
	 * @param string userId the identifier for the user
	 * @param string userFile the file that contains the opera bookmarks
	 */
	function importOperaContacts ($userId, $userfile, $callback) 
	{
		$stringUtils = new StringUtils ();
		
		$contactOperations = $callback; 
	
		$id   = "ID="; // not used
		$icon = "ICON="; // not used
		$created = "CREATED="; //not used
	  	$name = "NAME=";
	  	$mail = "MAIL=";
	  	$description = "DESCRIPTION=";
		$phone= "PHONE=";
		$fax  = "FAX=";
		$addr = "POSTALADDRESS=";
		$url  = "URL=";
	  	$typeIndicator = "Opera Hotlist";
	
		// start at the root
		$parentId=0;
		$top=0;
		$stack = array ();
		$stack[$top++]=$parentId;
	
	  	$fp = fopen($userfile, "r");
		if ($fp == null)
		{
			die ("Failed to open " . $userfile);
		}
	  	# compare the first line. It should indicate that we are
	  	# processing a bookmark file of the Opera browser
	  	$firstLine = fgets($fp, 4096);
	  	if (!$stringUtils->startsWith ($firstLine, $typeIndicator)) 
			die ("Not a valid Opera file");
	  	$processing = false;
	
	  	# process the file
	  	while (!feof($fp)) 
		{
	    	$currentLine = trim (fgets($fp, 4096));
	
	    	# #FOLDER starts a (sub)folder
	    	if ($currentLine == "#FOLDER") 
		{
			$currentContact = new Contact 
				(null,null,null,null, 
				null,null,null,null, 
				null,null,null,null,null);
			$currentContact->isParent=1;	
	      		$processing = true;
	    	}
	    	# #URL starts a bookmark
	    	else if ($currentLine == "#CONTACT") 
		{
			$currentContact = new Contact 
				(null,null,null,null,
				null,null,null,null, 
				null,null,null,null,null);
			$currentContact->isParent=0;	
	      		$processing = true;
	    	}
	    	# - ends a folder
	    	else if ($currentLine == "-") 
		{
			# pop current folder from stack
	      		$parentId = $stack[--$top]; 
	      		$processing = false;
		}
	    	else if ($currentLine == "" && $processing) 
		{
	      	# Ok, we found an empty line, this means that we have 
	      	# either found a folder or bookmark
	      	#
	      	# Attention! We will find an empty line just before a
	      	# folder seperator and just after! Make sure that we
	      	# are not processing the same bookmark twice (this is
	      	# why the boolean 'processing' is used.
	      		if ($currentContact->isParent == 1) 
			{
	        		# place the current folder on the stack
	        		$stack [$top++] = $parentId;
				$currentContact->parentId=$parentId;
				$parentId=$contactOperations->
					addItem($userId, $currentContact);
	      		}
	      		else 
			{
				$currentContact->parentId=$parentId;
				$contactOperations->addItem
					($userId, $currentContact);
	      		}
	      		$processing = false;
	    	}
	    	# Parse the actual bookmark content. Note that the 'processing'
	    	# boolean is not needed here, but hey.... it cannot hurt
	    	else if ($currentLine != "" && $processing) 
		{
	      		# Parse for the string 'NAME='
	      		if ($stringUtils->startsWith ($currentLine, $name)) 
			{
	        		$currentName= $stringUtils->getProperty ($currentLine, $name);
	        		$currentContact->name=$currentName;
	      		}
	      		# Parse for the string 'DESCRIPTION='
	      		else if ($stringUtils->startsWith ($currentLine, $description)) 
			{
	        		$currentDescription = $stringUtils->getProperty 
					($currentLine, $description);
	        		$currentContact->description=$currentDescription;
	      		}
	      		# Parse for the string 'URL='
	      		else if ($stringUtils->startsWith ($currentLine, $url)) 
			{
	        		$currentURL = $stringUtils->getProperty ($currentLine, $url);
	        		$currentContact->locator=$currentURL;
	      		}
	      		# Parse for the string 'MAIL='
	      		else if ($stringUtils->startsWith ($currentLine, $mail)) 
			{
	        		$currentMail = $stringUtils->getProperty ($currentLine, $mail);
				// This line might actually contain
				// multuple email addresses...
				// Additional parsing is needed
	        		$currentContact->email1=$currentMail;
	      		}
	      		# Parse for the string 'PHONE='
	      		else if ($stringUtils->startsWith ($currentLine, $phone)) 
			{
	        		$currentPhone = $stringUtils->getProperty ($currentLine, $phone);
				// This might also be telephone work,
				// but there is no way to determine the
				// difference
	        		$currentContact->telephoneHome=$currentPhone;
	      		}
	      		# Parse for the string 'FAX='
	      		else if ($stringUtils->startsWith ($currentLine, $fax)) 
			{
	        		$currentFax = $stringUtils->getProperty ($currentLine, $fax);
	        		$currentContact->faximile=$currentFax;
	      		}
	      		# Parse for the string 'ADDR='
	      		else if ($stringUtils->startsWith ($currentLine, $addr)) 
			{
	        		$currentAddress = $stringUtils->getProperty ($currentLine, $addr);
	        		$currentContact->address=$currentAddress;
	      		}
	      		else 
			{
	        		# Ignore the rest.
	      		}
	    	}
	  	}
	  	fclose($fp);
	}
	
	
	/**
	 * Export users contacts in Opera format (starting from a certain Id)
	 * 
	 * @param string id the identifier for the user
	 * @param integer parent the identifier for the parent id of the bookmarks
	 * (to enable recursive functioncall)
	 */
	function exportOperaContacts ($id, $parent, $callback) {
		$itemServices = $callback; 
	  	$items = $itemServices->getChildren ($id, $parent);
	
		$newline="\n";
		$cnt_c = 0;
		$cnt_b = 0;
		//echo ("Opera Hotlist version 2.0$newline$newline");
	  for ($i=0;$i<count($items); $i++)
	  {
		$currentItem = $items[$i];
	
	    if ($currentItem->isParent == '1') { # folder
	      $cnt_c++;
	      echo("#FOLDER$newline");
	      echo("\tNAME=" . $currentItem->name . "$newline");
	      echo("\tCREATED=$newline");
	      echo("\tVISITED=0$newline");
	      echo("\tORDER=$cnt_c$newline");
	      echo("\tEXPANDED=YES$newline");
	      echo("\tDESCRIPTION=".$currentItem->description.$newline.$newline);
	

	      $this->exportOperaContacts($id, $currentItem->itemId, $callback);
	
	      echo("$newline-$newline");
	    } 
	    else
	    {
	      $cnt_b++;
	      echo("#CONTACT$newline");
	      echo("\tNAME=" . $currentItem->name . "$newline");
	      echo("\tURL=" . $currentItem->locator . "$newline");
	      echo("\tCREATED=$newline");
		  echo("\tACTIVE=YES$newline");
		  echo("\tPHONE=".$currentItem->telephoneHome.$newline);
		  echo("\tFAX=".$currentItem->faximile.$newline);
		  echo("\tPOSTALADDRESS=".$currentItem->address.$newline);
		  echo("\tICON=Contact0$newline");
		  echo("\tMAIL=".$currentItem->email1.$newline);
		  // try to add things that are not understood by the 
		  // opera format in the description.
	      echo("\tDESCRIPTION=". $currentItem->description);
		  if ($currentItem -> email2 != null)
		  {
		  	echo(" email2:".$currentItem->email2);
		  }
		  if ($currentItem -> email3 != null)
		  {
		  	echo(" email3:".$currentItem->email3);
		  }
		  if ($currentItem -> alias != null)
		  {
		  	echo(" alias:".$currentItem->alias);
		  }
		  if ($currentItem -> job != null)
		  {
		  	echo(" job:".$currentItem->job);
		  }
		  if ($currentItem -> mobile != null)
		  {
		  	echo(" mobile:".$currentItem->mobile);
		  }
		  if ($currentItem -> telephoneWork != null)
		  {
		  	echo(" telephoneWork:".$currentItem->telephoneWork);
		  }
		  if ($currentItem -> organization != null)
		  {
		  	echo(" organization:".$currentItem->organization);
		  }
		  echo($newline.$newline);
	    }
	  }
	}
	
	function exportVCards ($id, $parent, $callback) 
	{
		$itemServices = $callback; 
		$items = $itemServices->getChildren ($id, $parent);
	
		$newline="\n";
  		for ($i=0;$i<count($items); $i++)
  		{
			$currentItem = $items[$i];

    		if ($currentItem->isParent == '1') 
			{ 
				// folders are ignored in vcards.
				// process children anyway
      			$this->exportVCards
					($id, $currentItem->itemId, $callback);
			}
			else
			{
				echo ("BEGIN:VCARD".$newline);
				echo ("VERSION:2.1".$newline);
				echo ("FN:".$currentItem->name.$newline);
				if ($currentItem->email1 != null)
				{
					echo ("EMAIL;INTERNET:".$currentItem->email1.$newline);
				}
				if ($currentItem->email2 != null)
				{
					echo ("EMAIL;INTERNET:".$currentItem->email2.$newline);
				}
				if ($currentItem->email3 != null)
				{
					echo ("EMAIL;INTERNET:".$currentItem->email3.$newline);
				}
				if ($currentItem->job != null)
				{
					echo ("TITLE:".$currentItem->job.$newline);
				}
				if ($currentItem->orgranization != null)
				{
					echo ("ORG:".$currentItem->organization.$newline);
				}
				if ($currentItem->organizationalAddress != null)
				{
					echo ("ADR;WORK;PREF:".$currentItem->organizationalAddress.$newline);
				}
				if ($currentItem ->alias != null)
				{
					echo ("NICKNAME:".$currentItem->alias.$newline);
				}
				/*
				if ($currentItem->birthday != null)
				{
					echo ("BDAY:".$currentItem->birthday.$newline);
				}
				*/
				if ($currentItem->description != null)
				{
						echo ("NOTE:".$currentItem->description.$newline);
				}
				echo ("END:VCARD".$newline.$newline);
			}
		}
	}
}
?>
