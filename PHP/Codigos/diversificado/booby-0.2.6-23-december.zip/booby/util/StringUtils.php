<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
/**
 * String utilities
 * @package be.nauta.booby.util
 * @author Barry Nauta
 * @date July 2003
 *
 * @copyright
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a>
 * and look for licenses
 */
class StringUtils
{
	/**
	 * Empty constructor
	 */
	function StringUtils ()
	{
	}

	/**
	 * Replaces quotes by the tag &amp;quote
	 * @param string string the input string
	 * @return string the url encoded string
	 */
	function urlEncodeQuotes ($string)
	{
		$s1 = ereg_replace ("\"", "&quot;", $string);
		$s2 = ereg_replace ("\'", "&#39;", $s1);
		return $s2;
	}

	/**
	 * Replaces quotes by the tag &amp;quote
	 * and newlines by the br tag
	 * @param string string the input string
	 * @return string the url encoded string
	 */
	function urlEncode ($string)
	{
		$s1 = $this->urlEncodeQuotes ($string);
		$s2 = ereg_replace ("\n", "<br />", $s1);
		$s3 = ereg_replace ("\r", " ", $s2);
		return $s3;
	}

	/**
	 * Checks whether the input starts with a given string
	 *
	 * @param string inputString the total String
	 * @param string startsWith a partial String
	 * @return true if 'inputString' starts with 'startsWith', false
	 * otherwise
	 */
	function startsWith ($inputString, $startsWith)
	{
	  return (substr ($inputString, 0, strlen($startsWith)) == $startsWith);
	}

	/**
	 * Replaces quotes by escape versions of the quotes
	 * @param string string the input string
	 * @return string the string with the replaced quotes
	 */
	function replaceQuotes ($string)
	{
		$s1 = ereg_replace("\"", "\"", $string);
		$s2 = ereg_replace("\'", "\'", $s1);
		return $s2;
	}


	/**
	 * Removes newlines characters from the input string
	 * @param string string the input string
	 * @return string the input string without the newlines
	 */
	function stripNewlines ($string)
	{
		$s1 = ereg_replace ("\n", "", $string);
		$s2 = ereg_replace ("\r", "", $s1);
		return $s2;
	}


	/**
	 * Replaces newline characters by br tages
	 * @param string string the input string
	 * @return string the input string without the replaced newlines
	 */
	function newlinesToHtml ($string)
	{
		$s1 = ereg_replace ("\n", "<br />", $string);
		$s2 = ereg_replace ("\r", "", $s1);
		return $s2;
	}

	/**
	 * Returns the property of the inputString. This assumes that the
	 * inputString is in the format of property=value.
	 *
	 * The function will take the length of the property + 1 (for the '='
	 * sign) and returns the inputString without the first characters,
	 * found by the length
	 *
	 * Calling the function getProperty ("property=value", "property") will
	 * return "value"
	 */
	function getProperty ($inputString, $property)
	{
	  return (substr ($inputString, strlen($property), strlen($inputString)));
	}

	/**
	 * Truncates the inputstring at the given length and appands the optional
	 * string.
	 *
	 * @param string inputString the inputstring
	 * @param integer length
	 * @param string append optional append characters, default to '...'
	 */
	function truncate ($inputString, $length, $append="...")
	{
		if (strlen ($inputString) > $length)
		{
			return substr ($inputString, 0, $length).$append;
		}
		else
		{
			return $inputString;
		}
	}
}
?>
