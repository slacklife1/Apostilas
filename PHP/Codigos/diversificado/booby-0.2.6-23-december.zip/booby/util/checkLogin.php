<?php

/**
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */

require_once 'util/databaseConnection.php';
include ('sql/authQueries.php');
session_start();


/*
 * Do not let an illegal user continue. This is a very basic check...
 */
if (isset ($_GET['username']) || isset ($_POST['username']))
{
	die ("Illegal access. This seems like a hacking attempt!");
}

/*
 * Check for username in either session or cookie. Exit if not found
 */
if (!isset($_SESSION['username']) && !isset ($_COOKIE['Booby']))
{
	Header ('Location: logout.php');
	exit;
}

/*
 * So we have a username in cookie
 */
if (!isset ($_SESSION['username']))
{
	/*
	 * Information is stored in the following way:
	 * username=<username>&password=MD5(<password>)
	 */
	$credentials = $_COOKIE['Booby'];
	$temp = explode ('&', $credentials);

	$u = split ('=', $temp[0]);
	$p = split ('=', $temp[1]);
	$username = $u[1];
	$password = $p[1];

	/*
	 * Check the credentials with the database.
	 * NOTE: this functionality is also provided in the loginAction class and
	 * is thus a bit redundant. Perhaps the code should move?
	 */
	$query = sprintf($queries['getPassword'], $username);

	$result = $db->Execute ($query);
	$dbPassword = $result->fields [0];

	/*
	 * Go to the logout page to make sure that the session (which contained false
	 * information) is destroyed
	 */
	if ($dbPassword != $password)
	{
		$errorMessage = 'Cookie validation failed!';
		Header ('Location: login.php?errorMessage='.$errorMessage);
		exit;
	}
	/*
	 * Now set the username on the session, so we do not need to check these
	 * credentials each time
	 */
	$_SESSION['username'] = $username;

}

// we might want to recheck the credentials here....
?>
