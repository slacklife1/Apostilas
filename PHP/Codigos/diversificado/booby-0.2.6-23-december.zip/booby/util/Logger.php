<?php

/**
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
/**
 * This class provides BASIC logging functionalities
 *
 * @package be.nauta.booby.util
 * @author Barry Nauta
 * @date March 2003
 *
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class Logger
{

	var $file;
	var $timeFormat = "%H:%M:%S";

	/**
 	 * Constructor with a filename
 	 * @param string aFilename the filename to which we want to log
	 */
	function Logger ($aFileName)
	{
		$this->file = $aFileName;
	}

	/**
 	 * Log the message (timestamp will be prepended)
	 *
	 * @param string message the message to log
 	 */
	function log ($message)
	{
		$fd = fopen ($this->file, "a");
		if ((!$fd))
		{
			die ("Could not open: " + $file);
		}
		if (empty($fd))
		{
			die ("Empty");
		}
		$msg = $message . "\n";

		$timeStamp = strftime($this->timeFormat, time());
		fwrite ($fd, $timeStamp . " " . $msg);
		fclose ($fd);
	}
}
?>
