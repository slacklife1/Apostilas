<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
/**
 * Date utilities
 * Generic date utilities.
 *
 * @author Barry Nauta
 * @date December 2003
 * @package be.nauta.booby.util
 * @copyright
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a>
 * and look for licenses
 *
 * @todo NONE OF THESE FUNCTIONS IS TESTED!!!!
 */
class DateUtils
{
	/**
	 * Default empty constructor
	 */
	function DateUtils ()
	{
	}

	/**
	 * This function calculates the difference between two dates in seconds
	 *
	 * @param string firstDate the first date used for comparision
	 * @param string secondDate the second date used for comparision
	 * @return int the difference between the two dates in seconds
	 */
	function diffInSeconds ($firstDate, $secondDate)
	{
		$diff = $firstDate  - $secondDate;
		return $diff;
	}

	/**
	 * This function calculates the difference between two dates in minutes
	 *
	 * @param string firstDate the first date used for comparision
	 * @param string secondDate the second date used for comparision
	 * @return int the difference between the two dates in minutes
	 */
	function diffInMinutes ($firstDate, $secondDate)
	{
		$diff = $firstDate  - $secondDate;
		$minuteInSecs = 60;
		return ($diff / $minuteInSecs);
	}

	/**
	 * This function calculates the difference between two dates in hours
	 *
	 * @param string firstDate the first date used for comparision
	 * @param string secondDate the second date used for comparision
	 * @return int the difference between the two dates in hours
	 */
	function diffInHours ($firstDate, $secondDate)
	{
		$diff = $firstDate  - $secondDate;
		$hoursInSecs = 60 * 60;
		return ($diff / $hoursInSecs);
	}

	/**
	 * This function calculates the difference between two dates in days
	 *
	 * @param string firstDate the first date used for comparision
	 * @param string secondDate the second date used for comparision
	 * @return int the difference between the two dates in days
	 */
	function diffInDays ($firstDate, $secondDate)
	{
		$diff = $firstDate  - $secondDate;
		$dayInSecs = 60 * 60 * 24;
		return ($diff/$dayInSecs);
	}

	/**
	 * This function calculates the difference between two dates in weeks
	 *
	 * @param string firstDate the first date used for comparision
	 * @param string secondDate the second date used for comparision
	 * @return int the difference between the two dates in weeks
	 */
	function diffInWeeks ($firstDate, $secondDate)
	{
		$diff = $firstDate  - $secondDate;
		$weekInSecs = 60 * 60 * 24 * 7;
		return ($diff/$weekInSecs);
	}

	/**
	 * Returns the number of the current month; i.e.: january ->1
	 * and april -> 4
	 * @return int the number of the current month
	 */
	function getCurrentMonthNumber ()
	{
		return date('m');
	}

	/**
	 * Gets the number of the current day in the month (without leading zero's).
	 * @return int a number between 1 and 31
	 */
	function getCurrentDayInMonthNumber ()
	{
		return date ('j');
	}

	/**
	 * Returns the current year
	 * @return int the current year
	 */
	function getCurrentYear ()
	{
		return date ('Y');
	}

	/**
	 * Returns the day as a number between 1 and 31 from the given
	 * date
	 * @param string $theDate the input date in string format
	 * @return int the day in the month
	 */
	function getDayInMonthFromDate ($theDate)
	{
		$date = strtotime ($theDate);
		$dateArray = getdate ($date);
		return $dateArray ['mday'];
	}

	/**
	 * Returns the year of the specified date
	 * @param string $theDate the input date in string format
	 * @return int the year of the specified input date
	 */
	function getYearFromDate ($theDate)
	{
		$date = strtotime ($theDate);
		$dateArray = getdate ($date);
		return $dateArray ['year'];
	}

	/**
	 * Returns the month (as a number between 1 and 12)
	 * of the current date
	 * @param string $theDate the input date in string format
	 * @return int the month as number between 1 and 12 of
	 * the specified input date
	 */
	function getMonthFromDate ($theDate)
	{
		$date = strtotime ($theDate);
		$dateArray = getdate ($date);
		return $dateArray ['mon'];
	}
}
?>