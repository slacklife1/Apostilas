<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003  Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
/**
 * Browser utilities.
 *
 * Based on an article by Tim Perdue, located at
 * http://www.phpbuilder.com/columns/tim20000821.php3
 * Copyright 1999-2000 (c) The SourceForge Crew
 *
 * Modified version is embedded in a class and adapted to reflect the new PHP
 * standards.
 * 
 * @package be.nauta.booby.util
 * @author Barry Nauta
 * @date July 2003
 *
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class BrowserUtils
{
	/**
	 * Which browser are we dealing with?
	 * @private
	 * @variable string agent
	 */
	var $agent;
	
	/**
	 * What is the browser version
	 * @private
	 * @variable string version
	 */
	var $version;
	
	/**
	 * What is the browsers platform
	 * @private
	 * @variable string platform
	 */
	var $platform;
	
	/**
	 * Constructor.
	 */
	function BrowserUtils ()
	{	
	    //Determine browser and version
		if (ereg ('MSIE ([0-9].[0-9]{1,2})',$_SERVER['HTTP_USER_AGENT'],
			$log_version)) 
		{
		    $this->version=$log_version[1];
	    	$this->agent='IE';
		} 
		elseif (ereg ('Opera ([0-9].[0-9]{1,2})',$_SERVER['HTTP_USER_AGENT'],
			$log_version)) 
		{
		    $this->version=$log_version[1];
		    $this->agent='Opera';
		} 
		elseif (ereg ('Mozilla/([0-9].[0-9]{1,2})',$_SERVER['HTTP_USER_AGENT'],
			$log_version)) 
		{
		    $this->version=$log_version[1];
		    $this->agent='Mozilla';
		} 
		else 
		{
		    $this->version=0;
		    $this->agent='Unknown '.$HTTP_USER_AGENT;
		}
	
	    // Determine platform
		if (strstr($_SERVER['HTTP_USER_AGENT'],'Win')) 
		{
		    $this->platform='Win';
		} 
		else if (strstr($_SERVER['HTTP_USER_AGENT'],'Mac')) 
		{
		    $this->platform='Mac';
		} 
		else if (strstr($_SERVER['HTTP_USER_AGENT'],'Linux')) 
		{
		    $this->platform='Linux';
		} 
		else if (strstr($_SERVER['HTTP_USER_AGENT'],'Unix')) 
		{
		    $this->platform='Unix';
		} 
		else 
		{
		    $this->platform='Unknown';
		}
	}
	
	/**
	 * Returns the current used browser
	 * @return string the browser that is used
	 */
	function getBrowserAgent () 
	{
	    return $this->agent;
	}
	
	/**
	 * Returns the version of the browser
	 * @return string the version
	 */ 
	function getBrowserVersion () 
	{
	    return $this->version;
	}
	
	/**
	 * Returns the browsers platform
	 * @return string the platform
	 */
	function getBrowserPlatform ()
	{
	    return $this->platform;
	}
	
	
	/**
	 * Is the browser Internet Explorer?
	 * @return boolean true if the platform is IE, false otherwise
	 */
	function browserIsExplorer ()
	{
		return ($this->getBrowserAgent () == 'IE');
	}
	
	/**
	 * Is the browser Mozilla/Netscape?
	 * @return boolean true if the platform is Mozilla/Netscape, false otherwise
	 */
	function browserIsMozilla () 
	{
		return ($this->getBrowserAgent () == 'Mozilla');
	}
	
	/**
	 * Is the browser Mozilla/Netscape?
	 * @return boolean true if the platform is Mozilla/Netscape, false otherwise
	 */
	function browserIsNetscape () 
	{
		return $this->browserIsMozilla ();
	}
	
	/**
	 * Is the browser Mozilla/Netscape?
	 * @return boolean true if the platform is Mozilla/Netscape, false otherwise
	 */
	function browserIsOpera () 
	{
		return $this->getBrowserAgent () == 'Opera';
	}
	
}
?>