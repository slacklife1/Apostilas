<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
/**
 * A generic tree that knows (using a callback and a delegate) how to render 
 * a yahoo-tree-based layout. This tree is generic in the way that it knows 
 * how to display items, which is not that generic :-)
 *
 * The delegate must implement the following functions:
 * <ul>
 * <li>~Constructor~ (array icons)</li> 
 * <li>showRoot (object item, object tree)
 * <li>drawFolder (object item, boolean isExpanded, object tree, integer indent)</li>
 * <li>drawNode (object item, boolean isLastNode, object tree, integer indent)</li>
 * </ul>
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.util
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class YahooTree
{
	/**
	 * The root item
	 * @private
	 * @variable object root
	 */
	var $root;
	
	/**
	 * The delegate that knows how to render folders and nodes
	 * @private
	 * @variable object delegate
	 */
	var $delegate;
	
	/**
	 * The string that will contain the fully rendered tree as HTML
	 * @private
	 * @variable string resultString
	 */
	var $resultString;

	/**
	 * Default constructor. The callback object must implement the
	 * function 'getChildren (userId, itemId)', 'getItem (userId, itemId)'
	 *
	 * @param object theCallback 
	 * @param object theDelegate
	 */
	function YahooTree ($theDelegate)
	{
		$this->delegate=$theDelegate;
		$this->resultString = "<!-- Booby - YahooTree -->";
	}
	
	/**
	 * Generates the HTML code to display the tree
	 *
	 * @param string userId the user id
	 * @param object root the item that is the root
	 * @param array items the items to display
	 *
	 * @return string the tree rendered as html code
	 */
	function toHtml ($root, $items)
	{
		$this->root = $root;
		
		$this->resultString .= $this->delegate->showRoot ($root, $this);
		
		$this->resultString .= '<table cellpadding="0" valign="top" cellspacing="3" width="100%" border="0">';
		$this->showItems ($items);
		$this->resultString .= '</table>';
		
		return $this->resultString;
	}
	
	
	/**
	 * Builds up html code to display the specified items
	 * @private
	 * @uses indent
	 * 
	 * @param array items the items to show
	 */
	function showItems ($items)
	{
		$previousIsFolder=true;
		$seperatorIsDrawn = false;

		$parents = array ();
		$children = array ();
		
		// copy the array containing items in two seperate arrays.
		// One for the children and one for the parents. Treat them 
		// seperately
		for ($i=0; $i<count($items); $i++)
		{
			if ($items[$i]->isParent ())
			{
				$parents[] = $items[$i]; 
			} 
			else
			{
				$children[] = $items[$i]; 
			}
		}
		for ($j=0; $j<count($parents); $j++)
		{
			if ($j % 2 == 0)
			{
				$this->resultString .= '<tr valign="top">';
			}
			$this->resultString .= "<td>";
			$this->resultString .= $this->delegate->drawFolder 
				($parents[$j], false, $this, 0, $this->resultString);
			$this->resultString .= "</td>";
			if ($j % 2 != 0)
			{
				$this->resultString .= '</tr>';
			}
		}
		// and fill up empty cell if 
		if ($j % 2 == 0)
		{
			$this->resultString .= '<td></td></tr>';
		}
		// draw a seperator
		$this->resultString .= '<tr valign="top"><td colspan="2"><hr /></td></tr>';
		
		// draw the children
		for ($k=0; $k<count($children); $k++)
		{
			if ($k % 2 == 0)
			{
				$this->resultString .= '<tr valign="top">';
			}
			$this->resultString .= "<td>";
			$this->resultString .= $this->delegate->drawNode 
				($children[$k], false, $this, 0, $this->resultString);
			$this->resultString .= "</td>";
			if ($k % 2 != 0)
			{
				$this->resultString .= '</tr>';
			}
		}
		// and fill up empty cell if 
		if ($k % 2 == 0)
		{
			$this->resultString .= '<td></td></tr>';
		}
			/*
			// start a new row displaying two items per row
			if ($i % 2 == 0)
			{
				$this->resultString .= '<tr valign="top">';
			}
			$this->resultString .= "<td>";
			
			// drawing a folder
			if ($items[$i]->isParent ())
			{
				$this->resultString .= $this->delegate->drawFolder 
					($items[$i], false, $this, 0, $this->resultString);
			}
			// drawing a node
			else
			{
				// start writing nodes, but only write them in a new row
				if ($i % 2 != 0 && !$seperatorIsDrawn)
				{
					$this->resultString .= "&nbsp;</td>";
				}
				if (!$seperatorIsDrawn && $previousIsFolder)
				{
					$this->resultString .= '</tr><tr valign="top"><td colspan="2"><hr /></td></tr><tr valing="top"><td>';
					$seperatorIsDrawn = true;
					$previousIsFolder = false;
				}
				$this->resultString .= $this->delegate->drawNode 
					($items[$i], false, $this, 0);
			}
			$this->resultString .= "</td>";
			if ($i % 2 != 0)
			{
				$this->resultString .= "</tr>";
			}
			*/
		
	}

	/**
	 * Sets the icons that will be used to display the tree.
	 * The icons must have the following keys:
	 * 'bar', 'up', 'minus', 'folder_open', 'corner', 'plus', 'tee',
	 * 'folder_closed', 'node', 'before_display', 'after_display'.
	 * If the icons are images, the html code for the images must be provided
	 * as well...
	 *
	 * @param hashtable theIcons 
	 */
	 function setIcons ($theIcons)
	 {
	 	$this->delegate->setIcons ($theIcons);
	 }
	 
	/**
	 * Sets the items that are currently expanded.
	 * The string contains a comma seperated value list of ID's
	 * @param string expandedString
	 */
	function setExpanded ($expandedString)
	{
	}
	 
}
?>