<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include ('util/checkLogin.php');
include ('menuItems.php');
include ('configs/languages.php');
include ('configs/templates.php');
include ('configs/adminConfiguration.php');
include ('configs/preferenceConfiguration.php');
if ($renderEngine == 'Smarty')
{
	include ('configs/MySmarty.php');
}
else
{
	include ('Savant-1.2/Savant.php');
}
require_once ('PreferenceOperations.php');
require_once ('UserOperations.php');
require_once ('model/Preference.php');
require_once ('model/PreferenceFactory.php');
require_once ('model/User.php');

session_register ();

$preferenceOperations = new PreferenceOperations ();
$userOperations = new UserOperations ();
$prefFactory = new PreferenceFactory ();

if (!isset ($_POST['action']))
{
	if ($renderEngine == 'Smarty')
	{
		$renderer = 'modifyPreferences.tpl';
	}
	else
	{
		$renderer = 'modifyPreferences.tpl.php';
	}
	$renderObjects = $preferenceOperations->getPreferences
		($_SESSION['username']);
	$userSettings= $userOperations->getUser
		($_SESSION['username'],$_SESSION['username']);
}
else if ($_POST['action'] == 'modifyPreferences')
{
	$item = $prefFactory -> requestToPreferences ();
	//die ($item->toString());
	// Shortcut. Preferences will not actually be written to the database
	// but only put on the session for the user test. This avoids people
	// changing the language and others will no longer be able to use the 
	// application
	if ($_SESSION['username'] == 'test')
	{
		$_SESSION['template']=$item->template;
		$_SESSION['language']=$item->language;
	}
	else
	{
    	$preferenceOperations->modifyPreferences($_SESSION['username'], $item);
		// Hmmm.. unset does not do what I would expect. RTFM?
		$_SESSION['template']=null;
		$_SESSION['language']=null;
	    unset ($_SESSION['template']);
	    unset ($_SESSION['language']);
	}
	header ("Location: index.php");
}

$actions = null;
error_reporting(E_ERROR);
if ($renderEngineName == 'Smarty')
{
	$renderEngine=new MySmarty;
}
else
{
	$renderEngine=& new Savant ();
}
$renderEngine->assign('title', 'Booby - Preferences');
$renderEngine->assign('languages', $languages);
$renderEngine->assign('templates', $templates);
$renderEngine->assign('userSettings', $userSettings);
$renderEngine->assign('menuItems', $menuItems);
$renderEngine->assign('menu', $menu);


$renderEngine->assign('renderObjects', $renderObjects);
$renderEngine->assign('renderActions', $actions);
$renderEngine->assign('preferences', $renderObjects);
$renderEngine->assign('dictionary', $dictionary);
$renderEngine->assign('quickmark', $quickmark);


if ($renderEngineName == 'Smarty')
{
	if ($renderEngine->template_exists ($_SESSION['template'] . '/' . $renderer))
	{
		$renderEngine->assign('renderer', $_SESSION['template'] . '/' . $renderer);
	}
	else
	{
		// default to common if the template does not exist
		$renderEngine->assign('renderer', 'common/' . $renderer);
	}
	if (isset ($_GET['debug']))
	{
		$renderEngine->debugging=true;
		$renderEngine->debug_tpl='debug.tpl';
		$renderEngine->_smarty_debug_id='SMARTY_DEBUG';
		$renderEngine->_smarty_debug_info=array();
		$renderEngine->display($_SESSION['template'] . '/' . 'template.tpl');
	}
	else
	{
		@$renderEngine->display($_SESSION['template'] . '/' . 'template.tpl');
	}
}
else
{
	if (file_exists ('templates/'. $_SESSION['template'].'/' .
		$renderer))
	{
		$renderEngine->assign('renderer', $renderer);
	}
	else
	{
		$renderEngine->assign('renderer',
			'templates/common/' . $renderer);
	}
	$renderEngine->display('templates/'.$_SESSION['template'].'/template.tpl.php');
	//@$renderEngine->display($_SESSION['template'] . '/' . 'template.tpl');
}
?>
