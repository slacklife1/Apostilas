<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include_once ('util/databaseConnection.php');
require_once ('model/Preference.php');
require_once ('model/PreferenceFactory.php');
include ('sql/preferenceQueries.php');
/**
 * Preference Operations. Operations related to user preferences
 * like language, theme etc.
 *
 * @author Barry Nauta
 * @date March 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class PreferenceOperations
{
	/**
	 * The factory that constructs preference objects
	 * @private
	 * @variable object itemFactory
	 */
	var $itemFactory;
	
	/**
	 * Default constructor
	 */
	function PreferenceOperations ()
	{
		$this->itemFactory = new PreferenceFactory ();
	}

	/**
	 * Retrieves the preferences from a user
	 * @param string username the identifier for the user
	 */
	function getPreferences ($username)
	{
		global $db, $queries;

		$query = sprintf ($queries['getPreferences'], $username);
		$result=$db->Execute ($query) or die ($db->ErrorMsg());
		$prefs = $this->itemFactory->resultsetToPreferences ($result);
		return $prefs;
	}

	/**
	 * Adds preferences to the system
	 *
	 * @param string userId the identifier for the user who issues the request
	 * @param object item the preferences to be added
	 */
	function addPreferences ($userId, $item)
	{
		global $db, $queries;

		$query = sprintf ($queries['addPreferences'], 
			$item->owner, $item->language, $item->template);
		$result=$db->Execute ($query) or die
			("Unable to add preferences " .
			$db->ErrorMsg () . " " . $query);
	}

	/**
	 * Modifies the indicates preferences
	 *
	 * @param string userId the identifier for the user of whom its
	 * 	preferences will be modified
	 * @param object item the modifed preferences
	 */
	function modifyPreferences ($userId, $item)
	{
		global $db, $queries;

		$query = sprintf ($queries['modifyPreferences'], 
			$item->language, $item->template, $item->owner);
		$result=$db->Execute ($query) or die
			("Unable to modify preferences " .
			$db->ErrorMsg () . " " . $query);
	}

	/**
	 * Deletes preferences
	 * @param string userId the identification of the user that requests 
	 * the deletion
	 * @param object item the item (preferences) to be deleted
	 */
	function deletePreferences ($userId, $item)
	{
		global $db, $queries;

		$query = sprintf ($queries['deletePreferences'], $item->owner);
		$result=$db->Execute ($query) or die
			("Unable to delete preferences " .
			$db->ErrorMsg () . " " . $query);
	}
}
?>
