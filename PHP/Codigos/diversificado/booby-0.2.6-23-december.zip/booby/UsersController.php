<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include ('util/checkLogin.php');
include ('menuItems.php');
include ('configs/preferenceConfiguration.php');
include_once ('UserOperations.php');
include_once ('model/User.php');
include_once ('model/UserFactory.php');

session_register ();
$userOperations = new UserOperations ();
$userFactory = new UserFactory ();
$renderObjects = null;
$action = null;
$body = null;
$users = null;

if (isset ($_GET['action']))
{
	$action = $_GET['action'];
}
else if (isset ($_POST['action']))
{
	$action = $_POST['action'];
}
if ($action == 'modifyUser')
{
	if ($_SESSION['username'] == 'test')
	{
		die ("Not allowed for test user");
	}
	if ($_POST['password'] == null
		|| $_POST['password'] != $_POST['password2'])
	{
		die ("Invalid password or password mismatch");
	}
	$userSettings = $userFactory -> requestToUser ();
	$userOperations->modifyUser ($_SESSION['username'], $userSettings);

	Header("Location: index.php");
	exit;
}
else if ($action == 'showUser')
{
	// only admin should be able to see other users
	$users = $userOperations->getUser ($_SESSION['username'], $userId);
}
error_reporting(E_ERROR);
if ($renderEngineName == 'Smarty')
{
	include ('configs/MySmarty.php');
	$renderEngine=new MySmarty;
	if (isset ($_GET['debug']))
	{
		include ('util/debug.php');
	}
}
else
{
	include ('Savant-1.2/Savant.php');
	$renderEngine =& new Savant ();
}
$renderEngine->assign('title', 'Booby - User administration');
$renderEngine->assign('menuItems', $menuItems);
$renderEngine->assign('menu', $menu);
$renderEngine->assign('body', $body);
$renderEngine->assign('renderObjects', $users);
@$renderEngine->display($_SESSION['template'] . '/' . 'template.tpl');
?>
