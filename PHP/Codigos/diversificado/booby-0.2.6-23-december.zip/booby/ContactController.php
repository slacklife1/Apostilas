<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
// only used for the renderEngine parameter
include ('configs/adminConfiguration.php');
require_once ('Controller.php');
require_once ('model/ContactServices.php');
include ('util/Contact_Vcard_Parse.php');
include ('util/ContactUtils.php');
/**
 * The Contact Controller
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.controller
 * @copyright
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a>
 * and look for licenses
 */
class ContactController extends Controller
{
	/**
	 * Constructor. 
	 * Makes sure that the appropriate operations are instantiated.
	 * @param string renderEngineName the render engine that is used
	 * (either Smarty or phpSavant)
	 */
	function ContactController ($renderEngineName)
	{
		parent::Controller ($renderEngineName);
		$this->operations = new ContactServices ();
		$this->itemFactory = new ContactFactory ();
	}

	/**
	 * Returns the title of this Controller
	 *
	 * @return string the title of this controller
	 */
	function getTitle ()
	{
		return "Booby - Contacts";
	}

	/**
	 * Returns the name of the item that is controller by this controller
	 *
	 * @return string the name of the item that is controlled by this 
	 * controller
	 */
	function getItemName ()
	{
		return "Contact";
	}

	/**
 	 * Returns the actions defined for this item only
 	 *
 	 * @return array an array of item specific actions 
	 * (like search, import etc.)
 	 */
	function getActions ()
	{
		global $dictionary;
		$actions=array(
			array (
				'name'=> $dictionary['actions'],
				'contents'=>
				array (
					array('href' => 'ContactController.php?action=add&parentId='.
						$this->parentId,
						'name' => $dictionary['add']),
					array('href' => 'ContactController.php?action=import',
						'name' => $dictionary['import']),
					array('href' => 'ContactController.php?action=export',
						'name' => $dictionary['export']),
	    			array('href' => 'ContactController.php?action=search',
	        			'name' => $dictionary['search'])
	        		)
        		),
			array (
				'name'=>$dictionary['view'],
				'contents'=>
				array (
					array('href' => 'ContactController.php?expand=*',
						'name' => $dictionary['expand']),
					array('href' => 'ContactController.php?expand=0',
						'name' => $dictionary['collapse']),
					array('href' => 'ContactController.php?action=setYahooTree&parentId='.$this->getParentId (),
						'name' => $dictionary['yahooTree']),
					array('href' => 'ContactController.php?action=setExplorerTree&parentId='.$this->getParentId (),
						'name' => $dictionary['explorerTree'])
				),
			array (
				'name'=>$dictionary['sort'],
				'contents'=>
				array (
					array('href'=>'ContactController.php?sort=email1',
						'name='=> $dictionary['email'].' 1')

						)
				)
			)
		);
		return $actions;
	}

	/**
	 * Activate. Basically this means that the appropriate actions are executed and an optional result is returned
	 * to be processed/displayed
	 */
	function activate ()
	{
		switch ($this->getAction ())
		{
			case "add":
				$this->addAction ();
				break;
			case "modify":
				$this->modifyAction ();
				break;
			case "deleteContact":
				$this->deleteItemAction ();
				$this->getShowItemsParameters ();
				break;
			case "searchContacts":
				$this->searchItemAction ();
				break;
			case "search":
			case "export":
			case "import":
				$this->renderer = $this->getAction().'Contacts';
				break;
			case "addContact":
				$this->addItemAction ();
				break;
			case "modifyContact":
				$this->modifyItemAction ();
				$this->getShowItemsParameters ();
				break;
			case "move":
				$this->moveAction ();
				break;
			case "moveItem":
				$this->moveItemAction ();
				$this->getShowItemsParameters ();
				break;
			case "importContacts":
				$importType = $_POST['importType'];
				$importFile = $_FILES['importFile'];
				error_reporting (0);
				if ($importType == 'VCard')
				{
					$parser = new Contact_Vcard_Parse ();
					$result = $parser->fromFile ($importFile['tmp_name']);
					$contacts = $this->itemFactory->vcardsToContacts ($result);
					for ($i=0; $i<count($contacts); $i++)
					{
						$this->operations->addItem
							($_SESSION['username'], $contacts[$i]);
					}
				}
				else if ($importType == 'Opera')
				{
					$contactUtils->importOperaContacts ($_SESSION['username'], $importFile ['tmp_name'], $this);
				}
//				else if ($importType == 'CSV')
//				{
//					importCSV ($_SESSION['username'], $importFile['tmp_name']);
//				}
				else
				{
					die ('Unsupported contact import type:-'.$importType.'-');
				}
		        $this->getShowItemsParameters ();
				// We need to force a redirection to this page, otherwise a reload means
		        // resending the POST data and your items will be imported twice
		        //
		        // TBD BARRY
				break;
			case "exportContacts":
					$contactUtils = new ContactUtils ();
					$exportType = $_POST['exportType'];
					if ($exportType == 'Opera')
					{
						Header ("Content-type: text/plain");
						echo ("Opera Hotlist version 2.0\n\n");

						//$contactUtils = new ContactUtils ();
							$contactUtils ->exportOperaContacts
								($_SESSION['username'], 0, $this);
					}
					else if ($exportType == 'VCard')
					{
						Header ("Content-type: text/plain");
						//$contactUtils = new ContactUtils ();
						$contactUtils -> exportVCards 
								($_SESSION['username'], 0, $this);
					}
					else 
					{
							die ('Unsupported type: '.$exportType);
					}
					exit ();
			case "setYahooTree":
				$_SESSION['contactTree']='Yahoo';
				$this->getShowItemsParameters ();
				break;
			case "setExplorerTree":
				$_SESSION['contactTree']='Explorer';
				$this->getShowItemsParameters ();
				break;
			default:
				$this->getShowItemsParameters ();
				break;
			}
	}

		/**
	 * Returns the list of current expanded items for the controller
	 *
	 * @return string list of commanseperated item numbers
	 */
	function getExpanded ()
	{
			if (isset ($_GET['expand']))
			{
				$expand = $_GET['expand'];
				$_SESSION['contactExpand']=$expand;
			}
			else if (isset ($_SESSION['contactExpand']))
			{
				$expand = $_SESSION['contactExpand'];
			}
			else
			{
				$expand = 0;
			}
			return $expand;
	}

}
error_reporting(E_ERROR);
$controller = new ContactController ($renderEngineName);
$controller -> activate ();
$controller -> display ();
?>
