<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include_once ("configs/adminConfiguration.php");
include ('lang/messages.php');
?>

<html>
<head>
	<title>Booby - Login</title>
	<link rel="stylesheet" href="doc/css/booby.css"
	         type="text/css" />
</head>
<body>

	<center>
	<h1>Booby - Login</h1>
  	<img src="doc/pics/question_booby.jpg">

	<?php
               if (isset ($_GET['message']))
                {       
                        $messageId = $_GET['message'];
                        $message = $messages[$messageId];

                        if ($message != null)
                        {       
                                echo ("<br><h2>".$message."</h2>");
                        }       
                        else    
                        {       
                                echo    
                                ('<br><h2>'.$messages['unknownError'].'</h2>');
                        }
                }               
                else    
                {       
                        echo
                        ("<br><h2>".$messages['provideUsernameAndPassword']."</h2>");
                }

	?>
	<!--
	<p>
		Welcome to the demo site of Booby. You can login using username and password 'test'
		(without the quotes). Note that you can change theme and language (using the preferences)
		but these will not be saved in the database and reset to default on next login.
		As test-user, you <b>cannot</b> change the password.
	</p>
	-->
	<form action="loginAction.php" method="post">
	<?php
		if ($allowAnonymousSignon)
		{
	?>
		<table>
		<tr>
			<td>
				Name:
			</td>
			<td>
				<input type="text" name="username" 
					tabindex="1" />
			</td>
			<td>
				<input type="Checkbox" name="signUp" />
			</td>
			<td>
				Sign up:
			</td>
		</tr>
		<tr>
			<td>
				Password:
			</td>
			<td>
				<input type="password" name="password" 
					tabindex="2" />
			</td>
			<td>
				<input type="Checkbox" name="rememberMe" />
			</td>
			<td>
				Remember me:
			</td>
		</tr>
		<tr>
			<td>
				&nbsp;
			</td>
			<td colspan="2">
				<input type="submit" value="Submit" name="submit" />
			</td>
			<td>
				<a href="lostPassword.php">Lost your
				password?</a>
			</td>
		</tr>
		</table>
	<?php
		}
		else
		{
	?>
			Name: <input type="text" name="username"
				tabindex="1" />
			Password: <input type="password" name="password"
tabindex="2" />
			<br />
			<br />
			Remember me: <input type="Checkbox" name="rememberMe" />
	  		<input type="submit" value="Submit" name="submit" />
			<br />
			<a href="lostPassword.php">Lost your
			password?</a>
	<?php
		}
	?>
	</form>
	<hr />
		<font size="-2">
	<p>
		The homepage of the Booby application can be found at the following address:
		<a href="http://www.nauta.be/booby">http://www.nauta.be/booby</a>
	<br />
		Copyright (c) 2003 by Barry Nauta (barry at nauta dot be,
		<a href="http://www.barrel.net">http://www.barrel.net</a> or
		<a href="http://www.nauta.be">http://www.nauta.be</a>).
	</p>
	<p>
	    This program (Booby) is free software; you can redistribute it
		and/or
		modify it under the terms of the GNU General Public License as
		published by the Free Software Foundation; either version 2 of
		the License, or (at your option) any later version.
		This program is distributed in the hope that it will be useful,
    	but WITHOUT ANY WARRANTY; without even the implied warranty of
    	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    	GNU General Public License for more details.
		A copy of the license is included
		<a href="gpl.html">here</a>
	</p>
		</font>
	</center>
</body>
</html>
