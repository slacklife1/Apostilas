<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include ('util/checkLogin.php');
require_once ('util/databaseConnection.php');
/**
 * Services abstract base class
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class Services
{
	/**
	 * The factory used to construct dedicated items
	 * @variable object itemFactory
	 */
	var $itemFactory;
		
	/**
	 * Default constructor
	 */
 	function Services ()
 	{
 	}
 	
	/**
	 * Retrieves all items for a user
	 * @param integer userId the identifier for the user
	 * @return array an array of the items for this user
	 */
	function getItems ($userId)
	{
		if ($_SESSION['username'] != $userId) { return null; }

		global $db, $queries;
		$query = sprintf ($queries['getItems'], $userId);
		$result = $db->Execute($query) or
			die("GetItems: " . $db->ErrorMsg());
		return $this->itemFactory->resultsetToItems ($result);
	}

	/**
	 * Retrieves all items for a user, sorted by the indicated value
	 * @param integer userId the identifier for the user
	 * @param string field the field on which we would like to sort
	 * @return array an array of the sorted items
	 */
	function getSortedItems ($userId, $field, $sortOrder)
	{
		if ($_SESSION['username'] != $userId) { return null; }

		global $db, $queries;
		$query = sprintf ($queries['getSortedItems'], $userId, $field, $sortOrder);
		//die ($query);
		$result = $db->Execute($query) or
			die("GetSortedItems: " . $db->ErrorMsg());
		$result =  $this->itemFactory->resultsetToItems ($result);
		return $result;
	}
	
	/**
	 * Returns the owner of the item
	 *
	 * @param integer itemId the identifier of the item for which
	 *	we would like to know the owner
	 * @return string the owner of the item
	 * @todo make sure that not everyone can simply execute this
	 *	function.
	 */
	function getItemOwner ($itemId)
	{
		global $db, $queries;
		$query = sprintf ($queries['getItemOwner'], $itemId);
		$result = $db->Execute($query) or
			die("GetItemOwner: " .
			$db->ErrorMsg() . "query: -" .
			$query . "-");
		return $result[0];
	}

	/**
	 * Delete a item (with a specified ID) for a specific
	 * user. This function will recurively delete all children
	 * of this item if this item is a parent/folder!
	 *
	 * @param string userId the identifier for the user
	 * @param string itemId the identifier for the item that will
	 *        be deleted
	 */
	function deleteItem ($userId, $itemId)
	{
		if ($_SESSION['username'] != $userId) { return null; }
		$this->checkOwner ($userId, $itemId);

		global $db, $queries;
		$item = $this->getItem ($userId, $itemId);
		// if we are a parent, delete the children as well....
		if ($item->isParent==1)
		{
			$children = $this->getChildren ($userId, $itemId);
			for ($i=0; $i<count($children); $i++)
			{
				$this->deleteItem ($userId, $children[$i]->itemId);
			}
		}
		// now delete the specific item (children are already
		// deleted if this is a parent item)
		$query = sprintf ($queries['deleteItem'], $itemId);
		$result = $db->Execute($query) or
			die("DeleteItem: " .
			$db->ErrorMsg() . " " . $query);
	}

	/**
	 * Adds an item for a user.
	 * Abstract function
	 *
	 * @param integer userId the identifier for the user
	 * @param object item the item to be added
	 */
	function addItem ($userId, $item)
	{
	}
	
	
	/**
	 * Gets a specific item for a user
	 *
	 * @param string userId the identifier for the user
	 * @param string itemId the identifier for the item
	 * @return object the item for specified user with specified itemId  
	 */
	function getItem ($userId, $itemId)
	{
		if ($_SESSION['username'] != $userId) { return null; }

		global $db, $queries;
		$query = sprintf ($queries['getItem'], $userId, $itemId);

		$result = $db->Execute($query) or
			die("GetItem: " .
			$db->ErrorMsg() . " query: -" .
			$query . "-");

		$items = $this->itemFactory->resultsetToItems ($result);
		if (count ($items) == 0)
		{
			return null;
		}
		else
		{
			if ($items[0]->owner == $userId)
			{
				return $items[0];
			}
			die ("Not owner?");	
		}
	}

	
	/**
 	 * Checks the owner of the Item
	 *
	 * @param string userId the identifier of the user
	 * @param string itemId the identifier of the item
     */
	function checkOwner ($userId, $itemId)
	{
		if ($userId == null || $userId = 0)
		{
			return;
		}
		if ($this->getItemOwner ($itemId) != $userId)
		{
			die ("Not owner -" . $itemId . "- -" . $userId .  "-");
		}
	}
	
	/**
	 * Retrieves the children of a specified item
	 *
	 * @param string userId the identifier of the user that issues the
	 * request
	 * @param integer itemId the identifier of the item for which we would
	 * like to have its children
	 * @return array all children for specified user and itemId
	 */
	function getChildren ($userId, $itemId)
	{
		if ($_SESSION['username'] != $userId) { return null; }
		global $db, $queries;

		$query = sprintf ($queries ['getItemChildren'], $itemId, $userId);
		$result = $db->Execute ($query) or die
			("Operations. GetChildren " . $db->ErrorMsg () .
				" Error getting children: " . $query);
		$items = $this->itemFactory->resultsetToItems($result);
		if ($items == null)
		{
			return null;
		}
		else if ($items[0]->owner == $userId)
		{
			return $items;
		}
		else
		{
			die ("Not owner?");
		}
	}
	
	/**
	 * Retrieves the children of a specified item, but only the children that are parents themselves
	 *
	 * @param string userId the identifier of the user that issues the
	 * request
	 * @param integer itemId the identifier of the item for which we would
	 * like to have its children
	 * @return array all children for specified user and itemId
	 */
	function getChildrenThatAreParent ($userId, $itemId)
	{
		if ($_SESSION['username'] != $userId) { return null; }
		global $db, $queries;

		$query = sprintf ($queries ['getItemChildrenThatAreParent'], $itemId, $userId);
		$result = $db->Execute ($query) or die
			("Operations. GetChildrenThatAreParent " . $db->ErrorMsg () .
				" Error getting children: " . $query);
		$items = $this->itemFactory->resultsetToItems($result);
		if ($items == null)
		{
			return null;
		}
		else if ($items[0]->owner == $userId)
		{
			return $items;
		}
		else
		{
			die ("Not owner?");
		}
	}


	/**
	 * Modifies an item.
	 * Abstract function
	 *
	 * @param string userId the identifier for the user
	 * @param object item the (modified) item (which will still be identified
	 * by its original itemId)
	 */
	function modifyItem ($userId, $item)
	{
	}
	
	/**
	 * Moves an item for a user to a new parent
	 *
	 * @param string userId the identifier for the user who issues
	 *	the request
	 * @param integer itemId the identifier for the item that is going to
	 * 	be moved
	 * @param integer parentId the new parentId for the item
	 */
	function moveItem ($userId, $itemId, $parentId)
	{
		if ($_SESSION['username'] != $userId) { return null; }
		$item = $this->getItem ($userId, $itemId);
		$item->parentId = $parentId;
		$this->modifyItem ($userId, $item);
	}
	
	/**
     * Search for items for a user
     *
     * @param string userId the identifier for the user for which we
     *  would like to search for items
     * @param string field the field on which we would like to search
     * @param string value the value for which we would like to search
     *
     * @return array all items that match the given search criteria
     */
	function searchItems ($userId, $field, $value)
	{
		if ($_SESSION['username'] != $userId) { return null; }

		global $db, $queries;
		$query = sprintf ($queries ['searchItems'], $field, $value, $userId);
		$result = $db->Execute ($query) or die
				("Operations. Search " . $db->ErrorMsg () .
					" " . $query);
		$items = $this->itemFactory->resultsetToItems($result);
		return $items;
	}
	
	/**
	 * Updates the count of the number of times this item
	 * has been visited
	 * 
	 * @param string userId the user that requests the update
	 * @param integer itemId the item for which the count needs to be
	 * increased
	 */
	function updateVisiteCount ($userId, $itemId)
	{
		if ($_SESSION['username'] != $userId) { return null; }
		$this->checkOwner ($userId, $itemId);

		global $db, $queries;

		$query = sprintf ($queries['updateItemVisitCount'], $itemId);
		$result = $db->Execute($query)
			or die ("Update visit count failed ".
				$db->ErrorMsg () . " " . $query);
			
	}
}
?>
