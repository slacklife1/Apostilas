<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include ('util/databaseConnection.php');
include ('sql/userQueries.php');
include_once ('model/User.php');
include_once ('model/UserFactory.php');
/**
 * Operations class for users
 *
 * @author Barry Nauta
 * @date March 2003
 * @package be.nauta.booby.model
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class UserOperations
{
	/**
	 * The factory for user objects
	 * @private
	 * @variable object factory
	 */
	var $factory;
	
	/**
	 * Default constructor
	 */
	function UserOperations ()
	{
		$this->factory = new UserFactory ();
	}

	/**
	 * Adds a user to the system
	 *
	 * @param string userId the identifier fr the user who issues the request
	 * (should be admin, I guess???)
	 * @param object aUser the user to be added
	 */
	function addUser ($userId, $aUser)
	{
		if ($_SESSION['username'] != $userId) { return null; }

		global $db, $queries;
		$now = date ("Y-m-d H:i:s");

		$query = sprintf ($queries['addUser'],
			$aUser->username, MD5($aUser->password), $aUser->name, $aUser->email,
			addslashes ($aUser->description), $now);
		$result = $db->Execute ($query)
			or die ("Add user: " . $db->ErrorMsg () . " " . $query);

		$query = $queries['lastUserInsertId'];
		$result = $db->Execute ($query)
			or die ("Add user: " . $db->ErrorMsg () . " " . $query);

		return $result->fields[0];
	}

	/**
 	 * Modifies a users parameters
	 *
	 * @param string userId the requestor
	 * @param object theUser the modified user
	 */
	function modifyUser ($userId, $theUser)
	{
		if ($_SESSION['username'] != $userId) { return null; }

		global $db, $queries;

		$query = sprintf ($queries['modifyUser'],
			$theUser->name, MD5($theUser->password),
			addslashes ($theUser->description), $theUser->email, $theUser->username);
		$db->Execute ($query)
			or die ("Error updating user: " .
			$db->ErrorMsg () . " " . $query);
	}

	/**
	 * Deletes a user from the system
	 *
	 * @param string userId the identifier fr the user who issues the request
	 * (should be admin, I guess???)
	 * @param object aUser the user to be deleted
	 */
	function deleteUser ($userId, $theUserId)
	{
		if ($_SESSION['username'] != $userId) { return null; }

		global $db, $queries;
		$query = sprintf ($queries['deleteUser'], $theUserId);
		$db->Execute ($query)
			or die ("Error deleteing  user: " .
			$db->ErrorMsg () . " " . $query);
	}

	/**
	 * Retrieves all users
	 *
	 * @param string userId the identifier of the user who issues the request
	 * @return array all users known to the system
	 */
	function getAllUsers ($userId)
	{
		if ($userId != 'admin')
		{
			return;
		}
		global $db, $queries;
		$query  = $queries['getAllUsers'];
		$result = $db->Execute ($query)
			or die ($db->ErrorMsg (). "GetAllUsers. " . $query);
		return $this->factory->resultsetToUsers ($result);
	}

	/**
	 * Gets a user
	 *
	 * @param string userId the identifier for the user who issues the request
	 * @param string requestedUser the identification of the user for which
	 * we would like to know the parameters
	 *
	 * @return the requested user parameters
	 */
	function getUser ($userId, $requestedUser)
	{
		global $db, $queries;

		$query = sprintf ($queries ['getUser'], $requestedUser);
		$result = $db->Execute ($query)
			or die ('Error retrieving userinformation' .
			$db->ErrorMsg() . " " . $query);
		$users = $this->factory->resultsetToUsers ($result);
		return $users[0];
	}

	/**
 	 * Retrieves a user based on its Id
	 *
	 * @param string userId the identifier for the user
	 * @return object a fully instantiated user object
	 */
	function getUserForId ($userId)
	{
		global $db, $queries;

		$query = sprintf ($queries ['getUserForId'], $userId);
		$result = $db->Execute ($query)
			or die ('Error retrieving userinformation' .
			$db->ErrorMsg() . " " . $query);
		$users = $this->factory->resultsetToUsers ($result);
		return $users[0];
	}
}
?>
