<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once 'util/databaseConnection.php';
include_once ('sql/authQueries.php');
include_once ('configs/adminConfiguration.php');
require_once ('model/User.php');
require_once ('model/UserFactory.php');
require_once ('model/Preference.php');
require_once ('UserOperations.php');
require_once ('PreferenceOperations.php');


$userFactory = new UserFactory ();
if (isset($_POST['submit']))
{
	/*
	 * Check for username and password on POST. If this is not set, there was an 
	 * attempt -> illegal access?
	 */
	if(!$_POST['user'] | !$_POST['password'])
	{
		$message='illegalAccess';
		Header ("Location: login.php?message=".$message);
		exit;
	}

	/*
	 * Check whether the two provided passwords match
	 */
	if ($_POST['password'] != $_POST['password2'])
	{
		$message = 'passwordMismatch';
		Header ("Location: login.php?message=".$message);
		exit;
	} 
	
	/*
	 * Query the database to see whether the requested id for the user
	 * does not already exist in the database
	 */
	$query = sprintf ($queries ['getUsernamePassword'], $_POST['user']);
	$result = $db->Execute($query) or die ($db->ErrorMsg ());

	$dbUsername = $result->fields[0];

	/*
	 * Check whether we have received a username from the database. If this
	 * is the case, the username already exists and cannot be added
	 */
	if ($dbUsername != null || $dbUsername != "")
	{
		$message='userAlreadyExists';
		Header ("Location: login.php?message=".$message);
		exit;
	}

	/*
	 * Ok, username does not exist and credentials (passwords) appear to be valid.
	 * Send a mail to the site admin
	 */
	$message = "A new user (".$_POST['user'].") just signed in";
	$message .= "
		Address: ".$_SERVER['REMOTE_ADDR'];

	$subject = "New user (".$_POST['user'].") addition";

	$headers = "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers .= "From: Booby administrator <".$adminEmail.">\r\n";
	$headers .= "To: Booby administrator <".$adminEmail.">\r\n";
	$headers .= "X-Mailer: Booby";

	mail($adminEmail, $subject, $message, $headers);
	  
	/*
	 * Now physically add the user and its preferences.
	 * We can now also savely set the username on the session so the user
	 * is directly logged in.
	 */ 
	$userSettings = $userFactory->requestToUser ();
	$preferences = new Preference ($userSettings->username, 
			$defaultLanguage, $defaultTemplate);
	$preferencesOperations = new PreferenceOperations ();
	$userOperations = new UserOperations ();
	
	session_start();
	$_SESSION['username'] = $userSettings->username;

	$preferencesOperations->addPreferences ($_SESSION['username'], $preferences);
	$userOperations->addUser ($_SESSION['username'], $userSettings);

//	$db->Close ();


	/*
	 * Start the session
	 */
//	session_start ();
//	$_SESSION['username'] = $_POST['username'];


	/*
	 * Forward to the login page with an appropriate message
	 */
	Header ("Location: index.php");
	exit;
}

?>
