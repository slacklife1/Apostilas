<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include ('util/checkLogin.php');
require_once ('UserOperations.php');
require_once ('PreferenceOperations.php');
require_once ('model/User.php');
require_once ('model/UserFactory.php');
require_once ('model/Preference.php');
require_once ('model/PreferenceFactory.php');

include ('menuItems.php');
include ('configs/preferenceConfiguration.php');
include ('configs/adminConfiguration.php');
include ('configs/languages.php');
include ('configs/templates.php');

if ($renderEngineName == 'phpSavant')
{
	include ('Savant-1.2/Savant.php');
	$renderEngine =& new Savant ();
}
else
{
	include ('configs/MySmarty.php');
	$renderEngine = new MySmarty ();
}

/*
 * First check whether we are admin.
 */
if ($_SESSION['username'] != 'admin')
{
	Header ("Location: index.php");
}
$userOperations = new UserOperations ();
$preferenceOperations = new PreferenceOperations ();
$userFactory = new UserFactory ();
$preferenceFactory = new PreferenceFactory ();
/*
 * If we have not asked for a specific action, default to show
 */
if (
	(!isset ($_GET['action'])) &&
	(!isset ($_POST['action']))
	)
{
	if ($renderEngineName == 'phpSavant')
	{
		$renderer='administration.tpl.php';
	}
	else
	{
		$renderer='administration.tpl';
	}
	$renderObjects = $userOperations->getAllUsers ($_SESSION['username']);
	$action = null;
}
/*
 * Else retrieve the parameter from the request
 */
else if (isset ($_GET['action']))
{
	$action = $_GET['action'];
}
/*
 * Else retrieve the POST parameter from the request
 */
else
{
	$action = $_POST['action'];
}

$userSettings = null;

/*
 * Modify a specific user
 */
if ($action == 'modify')
{
	$userId = $_GET['userId'];
	if ($renderEngineName == 'phpSavant')
	{
		$renderer = 'modifyPreferences.tpl.php';
	}
	else
	{
		$renderer = 'modifyPreferences.tpl';
	}
	$userSettings = $userOperations->getUserForId($userId);
	$renderObjects =
		$preferenceOperations->getPreferences($userSettings->username);
}
else if ($action == 'addAUser')
{
	if ($renderEngineName == 'phpSavant')
	{
		$renderer = 'addUser.tpl.php';
	}
	else
	{
		$renderer = 'addUser.tpl';
	}
	$renderObjects = null;
}
else if ($action == 'addUser')
{
	$usersettings=$userFactory->requestToUser ();
	$userprefs = $preferenceFactory->requestToPreferences ();
	$userprefs->owner=$usersettings->username;
	if ($usersettings->password == null)
	{
		die ("You must provide at least a password");
	}
	$userOperations->addUser ($_SESSION['username'], $usersettings);
	$preferenceOperations->addPreferences($_SESSION['username'], $userprefs);

	Header ("Location: admin.php");
}
else if ($action == 'deleteUser')
{
	$userId = $_GET['userId'];
	$userOperations->deleteUser ($_SESSION['username'], $userId);
	$preferenceOperations->deletePreferences ($_SESSION['username'], $userId);
	Header ("Location: admin.php");
}
$actions=array (
	array('href'=>'admin.php?action=addAUser', 'name'=>
		$dictionary['adduser'])
	//array('href'=>'admin.php?action=importUsers', 'name'=>
		//$dictionary['importusers']),
	//array('href'=>'admin.php?action=exportUsers', 'name'=>
		//$dictionary['exportusers'])
);

$renderEngine->assign('dictionary', $dictionary);
$renderEngine->assign('title', 'Booby - Admin');
$renderEngine->assign('languages', $languages);
$renderEngine->assign('templates', $templates);
$renderEngine->assign('menuItems', $menuItems);
$renderEngine->assign('menu', $menu);
$renderEngine->assign('userSettings', $userSettings);
$renderEngine->assign('renderObjects', $renderObjects);
$renderEngine->assign('preferences', $renderObjects);
$renderEngine->assign('renderActions', $actions);
//$renderEngine->assign('template',$_SESSION['template']);
if ($renderEngineName == 'phpSavant')
{
	 if (file_exists ('templates/'.$_SESSION['template'].'/'.$renderer))
	 {
		 $renderEngine->assign('renderer', 'templates/'.$_SESSION['template'] . '/' . $renderer);
	 }
	 else
	 {
		 $renderEngine->assign('renderer', 'templates/common/' . $renderer);
	 }
	if (isset ($_GET['debug']))
	{
		$renderEngine->display('templates/'.$_SESSION['template'] . '/' . 'template.tpl.php');
	}
	else
	{
		error_reporting(E_ERROR);
		@$renderEngine->display('templates/'.$_SESSION['template'] . '/' . 'template.tpl.php');
	}
}
else
{
	if ($renderEngine->template_exists ($_SESSION['template'] . '/' . $renderer))
	{
		$renderEngine->assign('renderer', $_SESSION['template'] . '/' . $renderer);
	}
	else
	{
		// default to common if the template does not exist
		$renderEngine->assign('renderer', 'common/' . $renderer);
	}
	if (isset ($_GET['debug']))
	{
		include ('util/debug.php');
		$renderEngine->display($_SESSION['template'] . '/' . 'template.tpl');
	}
	else
	{
		error_reporting(E_ERROR);
		@$renderEngine->display($_SESSION['template'] . '/' . 'template.tpl');
	}
}
?>
