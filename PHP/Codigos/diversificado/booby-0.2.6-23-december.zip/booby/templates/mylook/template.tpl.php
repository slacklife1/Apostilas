<html>
<head>
	<title><?php echo $title ?></title>
	<link rel="stylesheet" type="text/css" 
		href="templates/mylook/template.css" />
	<meta http-equiv="Content-Type" 
		content="text/html; charset=<?php echo $dictionary['charset'] ?>">		
<?php	
	include 'templates/mylook/smarty_icons.inc';
?>
</head>
<body>
	<table border="2" cellspacing="0" cellpadding="5"
		height="95%">
	<tr>
		<!--
			 Menu Bar
		-->
		<td colspan="2" class="menu2">
			<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td>
					<font color="white" color="+1">	
					<?php
						foreach ($menu as $crumb)
						{
					?>
						<a href="<?php echo $crumb['href'] ?>"
							class="menu"
							>[<?php echo $crumb['name'] ?>]</a>
					<?php
						}
					?>
					</font>
				</td>
				<td align="right">
					<h2>Booby</h2>
				</td>
			</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td width="200" valign="top" class="menu">
			<table witdh="195" valign="top" border="0">
			<?php
				foreach ($menuItems as $menuItem)
				{
			?>
			
				<tr>
					<td align="center" valign="top">
						<a href="<?php echo $menuItem['href'] ?>"
							><?php echo $icons[$menuItem['icon']] ?></a>
						<br />
						<?php echo $menuItem['name'] ?></a>
					</td>
				</tr>
			<?php
				}
			?>
			<tr>
				<td valign="bottom">
					<a href="index.php"><img 
						src="templates/mylook/pics/blue_booby.gif" 
						border="0"/></a>
				</td>
			</tr>
			</table>
		</td>
		<td width="100%" valign="top" bgcolor="#ffffff">
			<?php
				include $renderer;
			?>
		</td>
	</tr>
	<tr>
		<td colspan="2">
    		<p>
        		<font size="-2">
					<?php echo $dictionary['license_disclaimer'] ?>
        		</font> 
    		</p>    
		</td>
	</tr>
	</table>
</body>
</html>
