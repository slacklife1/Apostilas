<html>
<head>
	<title><?php echo $title; ?></title>
	<link rel="stylesheet" type="text/css" 
		href="templates/mylook/template.css" />
	<meta http-equiv="Content-Type" 
		content="text/html; charset=<?php echo $dictionary['charset'] ?>">		
	
<?php include "templates/sidebar/icons.inc" ?>
</head>
<body>
	<table border="2" cellspacing="0" cellpadding="0" width="99%"
		height="95%">
	<tr>
		<td>
		</td>
	</tr>
	<tr>
		<td width="100%" valign="top" bgcolor="#ffffff">
			<!-- including file: <?php echo $renderer; ?> -->
			<?php 
				include $renderer;
			?>
		</td>
	</tr>
	</table>
</body>
</html>
