<!-- FILE: showBookmarks.tpl.php -->
<?php
	include ('templates/sidebar/javascript.inc');
?>

<h2><?php echo $dictionary['bookmarks']; ?></h2>

<?php
echo ("<!--");
echo (print_r ($renderActions));
echo ("-->");
?>
<table width="100%">
<tr>
	<td>
		<?php
				//die (print_r ($renderActions));
				// an actionBlock is 'view' or 'action' 
			foreach ($renderActions as $actionBlock)
			{
				foreach ($actionBlock as $actionBlockContents)
				{
					foreach ($actionBlockContents as $renderAction)
					{
				
						$actionRef = $renderAction['href'];
						$actionName = $renderAction ['name'];
						$actionImg = $renderAction ['img'];
						if ($actionName == $dictionary['add'])
						{
		?>
					<a target=_content
					href="<?php echo $actionRef; ?>"
					onmouseover="return overlib('<?php echo $actionName; ?>', CAPTION, '');" 
						onmouseout="return nd();"
		<?php
						}
						else if ($actionName == $dictionary['home'])
						{
		?>
					<a target=_content
					href="<?php echo $actionRef; ?>"
					onmouseover="return overlib('<?php echo $actionName; ?>', CAPTION, '');" 
						onmouseout="return nd();"><?php echo $actionImg; ?></a>
		<?php
						}
						else if ($name == $dictionary['search'])
						{
							/*
							 * We might add a small search
							 * box in the sidebar in the
							 * futre
							 */
		?>
					<a target=_content
					href="<?php echo $actionRef; ?>"
					onmouseover="return overlib('<?php echo $actionName; ?>', CAPTION, '');" 
					onmouseout="return nd();"><?php echo $actionImg; ?></a>
		<?php
						}
						else
						{
			?>
					<a 
					href="<?php echo $actionRef; ?>"
					onmouseover="return overlib('<?php echo $actionName; ?>', CAPTION, '');" 
					onmouseout="return nd();"><?php echo $actionImg; ?></a>
		
		<?php
						}
					}
				}
			}
		?>
	</td>
</tr>

<tr>
		<td>
<?php
				include ('templates/sidebar/icons.inc');
				include_once "util/Tree.php";
				include_once "templates/sidebar/BookmarkExplorerTreeDelegate.php";
				$delegate = new BookmarkExplorerTreeDelegate 
					($icons, "BookmarkSidebarController.php", $dictionary);
				$tree = new Tree ($delegate);

				if (isset ($_SESSION['bookmarkExpand']))
				{
					$tree -> setExpanded ($_SESSION['bookmarkExpand']);
				}
				echo ($tree -> toHtml ($parent, $renderObjects));
?>
		</td>
</tr>
</table>
