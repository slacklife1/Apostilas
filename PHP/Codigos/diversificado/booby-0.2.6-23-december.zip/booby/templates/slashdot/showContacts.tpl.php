<?php
	include ('templates/slashdot/javascript.inc');
?>
<table width="100%">
<tr>
		<td>
		<?php
				include ('templates/slashdot/icons.inc');

				if (isset ($_SESSION['contactTree']))
				{
					if ($_SESSION['contactTree'] == "Yahoo")
					{
						include_once "util/YahooTree.php";
						include_once "templates/common/ContactYahooTreeDelegate.php";
						$delegate = new ContactYahooTreeDelegate 
							($icons, "ContactController.php", $dictionary);
						$tree = new YahooTree ($delegate);
					}
					else if ($_SESSION['contactTree'] == "Explorer")
					{
						include_once "util/Tree.php";
						include_once "templates/common/ContactExplorerTreeDelegate.php";
						$delegate = new ContactExplorerTreeDelegate 
							($icons, "ContactController.php", $dictionary);
						$tree = new Tree ($delegate);
					}
				}
				else
				{
					// default
					include_once "util/YahooTree.php";
					include_once "templates/common/ContactYahooTreeDelegate.php";
					$delegate = new ContactYahooTreeDelegate 
						($icons, "ContactController.php", $dictionary);
					$tree = new YahooTree ($delegate);
				}
				

				if (isset ($_SESSION['contactExpand']))
				{
					$tree -> setExpanded ($_SESSION['contactExpand']);
				}
				echo ($tree -> toHtml ($parent, $renderObjects));
			?>
		</td>
</tr>
</table>
