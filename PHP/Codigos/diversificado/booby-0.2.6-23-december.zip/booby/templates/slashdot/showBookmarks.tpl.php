<?php
	include ('templates/slashdot/javascript.inc');
?>
<table width="100%">
<tr>
		<td>
		<?php
				include ('templates/slashdot/icons.inc');

//				include_once "BookmarkController.php";
				if (isset ($_SESSION['bookmarkTree']))
				{
					if ($_SESSION['bookmarkTree'] == "Yahoo")
					{
						include_once "util/YahooTree.php";
						include_once "templates/common/BookmarkYahooTreeDelegate.php";
						$delegate = new BookmarkYahooTreeDelegate 
							($icons, "BookmarkController.php", $dictionary);
						$tree = new YahooTree ($delegate);
					}
					else if ($_SESSION['bookmarkTree'] == "Explorer")
					{
						include_once "util/Tree.php";
						include_once "templates/common/BookmarkExplorerTreeDelegate.php";
						$delegate = new BookmarkExplorerTreeDelegate 
							($icons, "BookmarkController.php", $dictionary);
						$tree = new Tree ($delegate);
					}
				}
				else
				{
					// default
					include_once "util/Tree.php";
					include_once "templates/common/BookmarkExplorerTreeDelegate.php";
					$delegate = new BookmarkExplorerTreeDelegate 
						($icons, "BookmarkController.php", $dictionary);
					$tree = new Tree ($delegate);
				}
				

				if (isset ($_SESSION['bookmarkExpand']))
				{
					$tree -> setExpanded ($_SESSION['bookmarkExpand']);
				}
				echo ($tree -> toHtml ($parent, $renderObjects));
		?>
		</td>
</tr>
</table>
