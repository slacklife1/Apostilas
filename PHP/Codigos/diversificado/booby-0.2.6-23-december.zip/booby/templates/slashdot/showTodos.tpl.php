<?php
	include ('templates/slashdot/javascript.inc');
?>
<table width="100%">
<tr>
		<td>
			<?php
				include ('templates/slashdot/icons.inc');
				
				if (isset ($_SESSION['todoTree']))
				{
					if ($_SESSION['todoTree'] == "Yahoo")
					{
						include_once "util/YahooTree.php";
						include_once "templates/common/TodoYahooTreeDelegate.php";
						$delegate = new TodoYahooTreeDelegate 
							($icons, "TodoController.php", $dictionary);
						$tree = new YahooTree ($delegate);
					}
					else if ($_SESSION['todoTree'] == "Explorer")
					{
						include_once "util/Tree.php";
						include_once "templates/common/TodoExplorerTreeDelegate.php";
						$delegate = new TodoExplorerTreeDelegate 
							($icons, "TodoController.php", $dictionary);
						$tree = new Tree ($delegate);
					}
				}
				else
				{
					// default
					include_once "util/YahooTree.php";
					include_once "templates/common/TodoYahooTreeDelegate.php";
					$delegate = new TodoYahooTreeDelegate 
						($icons, "TodoController.php", $dictionary);
					$tree = new YahooTree ($delegate);
				}
				

				if (isset ($_SESSION['todoExpand']))
				{
					$tree -> setExpanded ($_SESSION['todoExpand']);
				}
				echo ($tree -> toHtml ($parent, $renderObjects));
			?>
		</td>
</tr>
</table>
