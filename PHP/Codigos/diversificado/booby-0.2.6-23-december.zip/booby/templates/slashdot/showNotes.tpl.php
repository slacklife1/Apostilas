<!--
	Set some custom colors for the popup notes
-->
<script language="JavaScript">
	var ol_textcolor="#000000";
	var ol_capcolor="#000000";
	var ol_bgcolor="#ffee00";
	var ol_fgcolor="#ffff00";
</script>
<table width="100%">
<tr>
		<td>
			<?php
				include ('templates/slashdot/icons.inc');

				if (isset ($_SESSION['noteTree']))
				{
					if ($_SESSION['noteTree'] == "Yahoo")
					{
						include_once "util/YahooTree.php";
						include_once "templates/common/NoteYahooTreeDelegate.php";
						$delegate = new NoteYahooTreeDelegate 
							($icons, "NoteController.php", $dictionary);
						$tree = new YahooTree ($delegate);
					}
					else if ($_SESSION['noteTree'] == "Explorer")
					{
						include_once "util/Tree.php";
						include_once "templates/common/NoteExplorerTreeDelegate.php";
						$delegate = new NoteExplorerTreeDelegate 
							($icons, "NoteController.php", $dictionary);
						$tree = new Tree ($delegate);
					}
				}
				else
				{
					// default
					include_once "util/YahooTree.php";
					include_once "templates/common/NoteYahooTreeDelegate.php";
					$delegate = new NoteYahooTreeDelegate 
						($icons, "NoteController.php", $dictionary);
					$tree = new YahooTree ($delegate);
				}
				

				if (isset ($_SESSION['noteExpand']))
				{
					$tree -> setExpanded ($_SESSION['noteExpand']);
				}
				echo ($tree -> toHtml ($parent, $renderObjects));
			?>
		</td>
</tr>
</table>
