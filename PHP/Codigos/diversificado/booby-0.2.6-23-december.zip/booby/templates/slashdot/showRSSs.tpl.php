<?php
	include ('templates/slashdot/javascript.inc');
?>
<table width="100%">
<tr>
		<td>
			<?php
				include ('templates/slashdot/icons.inc');

				if (isset ($_SESSION['newsTree']))
				{
					if ($_SESSION['newsTree'] == "Yahoo")
					{
						include_once "util/YahooTree.php";
						include_once "templates/common/NewsYahooTreeDelegate.php";
						$delegate = new NewsYahooTreeDelegate 
							($icons, "NewsController.php", $dictionary);
						$tree = new YahooTree ($delegate);
					}
					else if ($_SESSION['newsTree'] == "Explorer")
					{
						include_once "util/Tree.php";
						include_once "templates/common/NewsExplorerTreeDelegate.php";
						$delegate = new NewsExplorerTreeDelegate 
							($icons, "NewsController.php", $dictionary);
						$tree = new Tree ($delegate);
					}
				}
				else
				{
					// default
					include_once "util/YahooTree.php";
					include_once "templates/common/NewsYahooTreeDelegate.php";
					$delegate = new NewsYahooTreeDelegate 
						($icons, "NewsController.php", $dictionary);
					$tree = new YahooTree ($delegate);
				}
				

				if (isset ($_SESSION['newsExpand']))
				{
					$tree -> setExpanded ($_SESSION['newsExpand']);
				}
				echo ($tree -> toHtml ($parent, $renderObjects));
			?>
		</td>
</tr>
</table>
