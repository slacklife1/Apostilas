<html>
<head>
	<title><?php echo $title ?></title>
	<link rel="stylesheet" type="text/css" 
		href="templates/slashdot/template.css" />
	<meta http-equiv="Content-Type" 
		content="text/html; charset=<?php echo $dictionary['charset'] ?>">		
<?php
	include 'templates/slashdot/icons.inc';
//die (print_r ($menuItems));
?>
</head>
<body bgcolor="#000000" text="#000000" link="#006666" vlink="#000000"
		topmargin="0" leftmargin="0" marginwidth="0" marginheight="0">

<table cellpadding="5" width="100%" valign="top">
	<tr>
		<td>
			<table cellpadding="0" cellspacing="0" border="0" width="99%"
					align="center" bgcolor="#ffffff">
				<tr valign="middle">
					<td valign="top" align="left"><a href="index.php"
						><img src="templates/slashdot/pics/booby_logo.gif"
							title="Booby"></a></td>
						<?php
							foreach ($menuItems as $menuItem)
							{
						?>
							<td align="right" valign="top">
								<a href="<?php echo $menuItem['href'] ?>"
									><?php echo $icons[$menuItem['icon']] ?></a>
							</td>
						<?php
							}
						?>
				</tr>
			</table>

			<table width="99%" align="center" cellpadding="5" cellspacing="5"
					border="0" bgcolor="#ffffff" height="100%">
				<tr>
					<td valign="top">
						<nobr><font size="2"><b>
						<?php
							foreach ($menu as $crumb)
							{
						?>
							<a href="<?php echo $crumb['href'] ?>"
								><?php echo $crumb['name'] ?></a>
							<br />
						<?php
							}
						?>
						</b></font></nobr>
		       		</td>
		        	<td align="left" valign="top" width="100%" height="1">
						<font color="#000000">
							<table width="100%" border="0" cellpadding="0"
									cellspacing="0">
								<tr>
									<td valign="top" bgcolor="#006666"><img
				        				src="templates/slashdot/pics/slc.gif"
        								width="13" height="16" alt="" 
										align="top"><font 
										face="arial,helvetica" size="4" 
										color="#ffffff"><b>
										<?php echo $title ?>
										</b></font>
									</td>
								</tr>
							</table>
							
							<?php
								include $renderer;
							?>
					</td>
					<td> 
					</td>
					<td align="center" valign="top" width="210" height="1">
					
					<?php
						if ($renderActions != null)
						{
							foreach ($renderActions as $renderAction)
							{
					?>
							<table width="200" border="0" cellpadding="0" 
									cellspacing="0">
               					<tr valign="top" bgcolor="#006666">
			                   		<td><font face="arial,helvetica" 
										size="4" color="#ffffff">
										<b><?php echo $renderAction['name'] ?></b>
										</font>
									</td>
			               		</tr>
            			   		<tr>
									<td bgcolor="#cccccc">
									<?php
										foreach ($renderAction['contents'] as $contents)
										{
									?>
										<a href="<?php echo $contents['href'] ?>"
											>[<?php echo $contents['name'] ?>]</a>
									<?php
										}
									?>
			                   		</td>
								</tr>
							</table>
							<br />
					<?php
							}
						}
					?>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<table cellpadding="2" cellspacing="2" border="0" width="99%"
					align="center" bgcolor="#ffffff">
				<tr valign="middle">
					<td>
			    		<p>
        					<font size="-2">
								<?php echo $dictionary['license_disclaimer'] ?>
        					</font> 
			    		</p>    
			    	</td>
			    </tr>
			</table>			
		</td>
		
	</tr>
</table>
</body>
</html>
