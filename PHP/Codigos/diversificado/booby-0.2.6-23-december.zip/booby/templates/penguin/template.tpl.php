<html>
<head>
	<title><?php echo $title ?></title>
	<link rel="stylesheet" type="text/css" 
		href="templates/penguin/template.css" />
	<meta http-equiv="Content-Type" 
		content="text/html; charset=<?php echo $dictionary['charset'] ?>">		

	
	
	<?php include "templates/".$_SESSION['template']."/icons.inc" ?>
</head>
<body bgcolor="#ffffff">

	<table border="0" cellspacing="5" cellpadding="0"
		height="95%">
	<tr>
		<!--
			 Menu Bar
		-->
		<td colspan="2" class="menu2">
			<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td>
					<font color="white" color="+1">	
					<table>
					<tr>

						<?php 
							foreach ($menu as $crumbs) 
							{
						?>
							<td align="center">
								<a href="<?php echo ($crumbs['href']) ?>"
										class="menu"
										>[<?php echo ($crumbs['name']) ?>]</a>
							</td>
						<?php
							}
						?>
					</tr>
					</table>
				</td>
			</tr>
			</table>
			</font>
		</td>
	</tr>
	<tr>
		<td width="100%" valign="top">
			<table cellpadding="5" cellspacing="5" bgcolor="#f3f3f3"
				width="100%" height="100%">
			<tr>
				<td valign="top">
				<?php 
					//die ($renderer); 
				?>
					<?php include $renderer ?>
				</td>
			</tr>
			</table>
		</td>
		<td width="200" valign="top" class="menu" bgcolor="#ffffff">
			<table witdh="195" valign="top" border="0">
			<tr>
				<td align="right">
					<img src="templates/<?php echo 
						$_SESSION['template'] ?>/pics/booby_logo.jpg">
				</td>
			</tr>
			<?php
					foreach ($menuItems as $menu)
					{
			?>
						<tr>
							<td align="center" valign="top">
								<a href="<?php echo $menu['href'] ?>"
							><?php echo $icons[$menu['icon']] ?></a>
							<br />
							<?php echo ($menu['name']) ?>
							</td>
						</tr>
			<?php
				}
			?>
			<tr>
				<td valign="bottom">
					<a href="index.php"><img 
						src="templates/penguin/pics/linux.jpg" 
						border="0"/></a>
				</td>
			</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td colspan="2">
    		<p>
        		<font size="-2">
					<?php echo $dictionary['license_disclaimer'] ?>
        		</font> 
    		</p>    
		</td>
	</tr>
	</table>
</body>
</html>
