<html>
<head>
	<title><?php echo $title ?></title>
	<link rel="stylesheet" type="text/css" 
		href="templates/barry/template.css" />
	<meta http-equiv="Content-Type" 
		content="text/html; charset=<?php echo $dictionary['charset'] ?>">		

</head>
<body>
	<table border="0" cellspacing="5" cellpadding="5">
	<tr>
		<td valign="top">
			<table width="100%" border="0">
				<tr>
					<td>
						<table border="0" width="100%">			
							<tr>
								<td>
									<h1><?php echo $title ?></h1>
								</td>
							</tr>
							<tr>
								<td>
									<table width="100%">
										<tr>
										<td class="menu">
											<a href=""></a>
										</td>
										<?php 
											foreach ($menu as $crumb)
											{
										?>
											<td class="menu">
												<a href="<?php echo $crumb['href'] ?>"
													class="menu"
													><?php echo $crumb['name'] ?></a>
											</td>
										<?php 
											}
										?>
										<td class="menu">
											<a href=""></a>
										</td>
										<?php
											foreach ($menuItems as $menuItem)
											{
										?>
											<td class="menu">
												<a href="<?php echo $menuItem['href'] ?>"
													class="menu"
												><?php echo $menuItem['name'] ?></a>
											</td>
										<?php
											}
										?>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
					<td>
						<a href="index.php"><img 
							src="templates/barry/pics/booby-small.gif" 
							border="0" align="right" /></a>	
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr height="400">
		<td valign="top">
			<?php include $renderer ?>
				<!--
			{include file="$renderer" 
				renderObjects="$renderObjects"
				renderActions="$renderActions"} 
				-->
		</td>
	</tr>
	<tr>
		<td valign="bottom">
			<?php echo $dictionary['license_disclaimer'] ?>
		</td>
	</tr>
	</table>

</body>
</html>
