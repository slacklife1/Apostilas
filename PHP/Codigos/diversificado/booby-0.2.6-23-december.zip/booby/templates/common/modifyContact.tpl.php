<table border="0" width="100%">
<tr>
	<td><h2><?php echo $dictionary['modify'] ?>&nbsp;<?php echo $dictionary['contact'] ?></h2></td>
</tr>
</table>



<form method="POST" action="ContactController.php">
	<table width="80%" border="0">
	<tr>
		<td>
			<?php echo $dictionary['name'] ?>: 
		</td>
		<td colspan="3">
		<input type="text" name="name"
			size="60"
			value="<?php echo $renderObjects->name ?>" />
		</td>
	</tr>
	<?php if (!$renderObjects->isParent) 
		{
	?>
		<tr>
			<td><?php echo $dictionary['tel_home'] ?>:
			</td>
			<td>
				<input type="text" name="telephoneHome" 
				value="<?php echo $renderObjects->telephoneHome ?>" />
			</td>
			<td><?php echo $dictionary['tel_work'] ?>:
			</td>
			<td>
				<input type="text" name="telephoneWork" 
				value="<?php echo $renderObjects->telephoneWork ?>" />
			</td>
		</tr>
		<tr>
			<td>
				<?php echo $dictionary['mobile'] ?>:
			</td>
			<td>
				<input type="text" name="mobile" 
				value="<?php echo $renderObjects->mobile ?>" />
			</td>
			<td>
				<?php echo $dictionary['faximile'] ?>:
			</td>
			<td>
				<input type="text" name="faximile" 
				value="<?php echo $renderObjects->faximile ?>" />
			</td>
		</tr>
		<tr><td colspan="4">&nbsp;</td></tr>
		<tr>
			<td><?php echo $dictionary['email'] ?>&nbsp;1:
			</td>
			<td>
				<input type="text" name="email1" 
				value="<?php echo $renderObjects->email1 ?>" />
			</td>
			<td><?php echo $dictionary['webaddress'] ?>&nbsp;1:
			</td>
			<td>
				<input type="text" name="webaddress1" 
				value="<?php echo $renderObjects->webaddress1 ?>" />
			</td>
		</tr>
		<tr>
			<td><?php echo $dictionary['email'] ?>&nbsp;2:
			</td>
			<td>
				<input type="text" name="email2" 
				value="<?php echo $renderObjects->email2 ?>" />
			</td>
			<td><?php echo $dictionary['webaddress'] ?>&nbsp;2:
			</td>
			<td>
				<input type="text" name="webaddress2" 
				value="<?php echo $renderObjects->webaddress2 ?>" />
			</td>
		</tr>
		<tr>
			<td><?php echo $dictionary['email'] ?>&nbsp;3:
			</td>
			<td>
				<input type="text" name="email3" 
				value="<?php echo $renderObjects->email3 ?>" />
			</td>
			<td><?php echo $dictionary['webaddress'] ?>&nbsp;3:
			</td>
			<td>
				<input type="text" name="webaddress3" 
				value="<?php echo $renderObjects->webaddress3 ?>" />
			</td>
		</tr>
		<tr><td colspan="4">&nbsp;</td></tr>
		<tr>
			<td>
				<?php /* echo $dictionary['birthday']  */?>:
				&nbsp;
			</td>
			<td>
				<!--
				{html_select_date start_year="-100"
				time=$renderObjects->birthday ?>
				-->
				&nbsp;
			</td>
			<td><?php echo $dictionary['jobTitle'] ?>:
			</td>
			<td>
				<input type="text" name="job" 
				value="<?php echo $renderObjects->job ?>" />
			</td>
		</tr>
		<tr>
			<td>
				<?php echo $dictionary['alias'] ?>:
			</td>
			<td>
				<input type="text" name="alias" 
				value="<?php echo $renderObjects->alias ?>" />
			</td>
			<td>
				<?php echo $dictionary['organization'] ?>:
			</td>
			<td>
				<input type="text" name="organization" 
				value="<?php echo $renderObjects->organization ?>" />
			</td>
		</tr>
		<tr>
			<td>
				<?php echo $dictionary['address'] ?>:
			</td>
			<td>
				<textarea name="address" rows="5"
				cols="25"><?php echo $renderObjects->address ?>
				</textarea>
			</td>
			<td>
				<?php echo $dictionary['org_address'] ?>
			</td>
			<td>
				<textarea name="organizationAddress" rows="5"
				cols="25"><?php echo $renderObjects->organizationAddress ?>
				</textarea>
			</td>
		</tr>
		<tr>
			<td colspan="4">
				<?php echo $dictionary['description'] ?>: <textarea name="description"
					cols="80" rows="10"
					><?php echo $renderObjects->description ?></textarea>
			</td>
		</tr>
	<?php
		}
	?>
	</table>
	<h2><?php echo $dictionary['modify'] ?> <?php echo $dictionary['contact'] ?></h2>
	<input type="hidden" name="itemId" value="<?php echo $renderObjects->itemId ?>" />
	<input type="hidden" name="parentId" value="<?php echo $renderObjects->parentId ?>" />
	<input type="hidden" value="modifyContact" name="action">
	<input type="submit" value="<?php echo $dictionary['modify'] ?>" name="modifyContact">
</form>

<h2><?php echo $dictionary['move'] ?> <?php echo $dictionary['contact'] ?></h2>
<form method="POST" action="ContactController.php">
	<input type="hidden" name="itemId" value="<?php echo $renderObjects->itemId ?>" />
	<input type="hidden" value="move" name="action">
	<input type="submit" value="<?php echo $dictionary['move'] ?>" name="move">
</form>


<h2><?php echo $dictionary['delete'] ?> <?php echo $dictionary['contact'] ?></h2>
<form method="POST" action="ContactController.php">
	<input type="hidden" name="itemId" value="<?php echo $renderObjects->itemId ?>" />
	<input type="hidden" value="deleteContact" name="action">
	<input type="submit" value="<?php echo $dictionary['delete'] ?>" name="deleteContact">
</form>
