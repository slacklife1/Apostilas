<h2><?php echo $dictionary['search'].' '.$dictionary['contacts'] ?></h2>

<table>
<tr>
	<td>
		<?php echo $dictionary['name'] ?>:
	</td>
	<td>
		<form method="POST" action="ContactController.php">
		<input type="hidden" name="field" value="name">
		<input type="text" name="value">
		<input type="hidden" name="action" value="searchContacts">
		<input type="submit" value="<?php echo $dictionary['search'] ?>">
		</form>
	</td>
</tr>
<tr>
	<td>
		<?php echo $dictionary['alias'] ?>:
	</td>
	<td>
		<form method="POST" action="ContactController.php">
		<input type="hidden" name="field" value="alias">
		<input type="text" name="value">
		<input type="hidden" name="action" value="searchContacts">
		<input type="submit" value="<?php echo $dictionary['search'] ?>">
		</form>
	</td>
</tr>
<tr>
	<td>
		<?php echo $dictionary['description'] ?>:
	</td>
	<td>
		<form method="POST" action="ContactController.php">
		<input type="hidden" name="field" value="description">
		<input type="text" name="value">
		<input type="hidden" name="action" value="searchContacts">
		<input type="submit" value="<?php echo $dictionary['search'] ?>">
		</form>
	</td>
</tr>
<tr>
	<td>
		<?php echo $dictionary['address'] ?>:
	</td>
	<td>
		<form method="POST" action="ContactsController.php">
		<input type="hidden" name="field" value="address">
		<input type="text" name="value">
		<input type="hidden" name="action" value="searchContacts">
		<input type="submit" value="<?php echo $dictionary['search'] ?>">
		</form>
	</td>
</tr>
</table>
