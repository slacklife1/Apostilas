<?php
	include ('util/DateUtils.php');

	$dateUtils = new DateUtils ();
?>
<table border="0" width="100%">
<tr>
	<td><h2><?php echo $dictionary['modify'] ?>&nbsp;<?php echo $dictionary['todo'] ?></h2></td>
</tr>
</table>



<form method="POST" action="TodoController.php">
	<table width="80%" border="1">
	<tr>
		<td colspan="2">
			<?php echo $dictionary['title'] ?>: <input type="text" name="name"
			size="40" value="<?php echo $renderObjects->name ?>" />
		</td>
	</tr>
	<tr>
		<td>
		<table>
		<tr>
			<td>
		<?php echo $dictionary['priority'] ?>:
			<select name="priority">
		       	<?php
			       	for ($i=1; $i<=5; $i++)
				{
				       	echo ('<option value="'.$i.'" ');
				       	if ($i == $renderObjects->priority)
				       	{
					       	echo ('selected="selected"');
					}
				       	echo ('>'.$i.'</option>');
		       		}
			?>
			</select>
		</td>
		<td>
			<?php echo $dictionary['complete'] ?>: <input type="text" name="perComplete"
			size="3"
			value="<?php echo $renderObjects->percentCompleted ?>"> %
		</td>
		</tr>
		<tr>
			<td><?php echo $dictionary['status'] ?>:
			</td>
			<td><input type="textfield" name="status"
				value="<?php echo $renderObjects->status ?>">
			</td>
		</tr>

		</table>
		</td>
		<td>
			<table>
			<tr>
				<td>
					<?php echo $dictionary['start_date'] ?>:
				</td>
				<td>
					<!--
						Month dropdown box
					-->
					<select name="StartDate_Month">
					<?php
						for ($i=1; $i<=12; $i++)
						{
							if ($i<10)
							{
								$currentMonth="month0$i";
							}
							else
							{
								$currentMonth="month$i";
							}
	       					echo ('<option label="'.$dictionary[$currentMonth].'" value="'.$i.'"');
	       					if ($i==$dateUtils->getMonthFromDate($renderObjects->startDate))
	       					{
	       						echo (' selected="selected"');
	       					}
	       					echo ('>'.$dictionary[$currentMonth].'</option>');
	       				}
       				?>
       				</select>
					<!--
						Day dropdown box
					-->
					<select name="StartDate_Day">
					<?php
						for ($i=1; $i<=31; $i++)
						{
							if ($i<10)
							{
								$currentDay = '0'.$i;
							}
							else
							{
								$currentDay = $i;
							}
							echo ('<option label="'.$currentDay.'" value="'.$currentDay.'"');
							if ($i == $dateUtils->getDayInMonthFromDate($renderObjects->startDate))
							{
								echo (' selected="selected"');
							}
							echo ('>'.$currentDay.'</option>');
						}
					?>
					</select>
					<!--
						Year dropdown box
					-->
					<select name="StartDate_Year">
					<?php
						$currentYear = $dateUtils->getYearFromDate ($renderObjects->startDate);

						for ($i=5; $i>10; $i--)
						{
							echo ('<option label="'.($currentYear-$i).'" value="'.($currentYear-$i).'"');
							echo ('>'.($currentYear-$i).'</option>');
						}
						echo ('<option label="'.$currentYear.'" value="'.$currentYear.'"');
						echo (' selected="selected"');
						echo ('>'.$currentYear.'</option>');
						for ($i=1; $i<=10; $i++)
						{
							echo ('<option label="'.($currentYear+$i).'" value="'.($currentYear+$i).'"');
							echo ('>'.($currentYear+$i).'</option>');
						}
					?>
					</select>

				<!--

					<php echo html_select_date
					end_year="+10"
					prefix="StartDate_"
					time=$renderObjects->startDate >
					-->
				</td>
			</tr>
			<tr>
				<td>
					<?php echo $dictionary['due_date'] ?>:
				</td>
				<td>
					<!--
						Month dropdown box
					-->
					<select name="DueDate_Month">
					<?php
						for ($i=1; $i<=12; $i++)
						{
							if ($i<10)
							{
								$currentMonth="month0$i";
							}
							else
							{
								$currentMonth="month$i";
							}
	       					echo ('<option label="'.$dictionary[$currentMonth].'" value="'.$i.'"');
	       					if ($i==$dateUtils->getMonthFromDate($renderObjects->endDate))
	       					{
	       						echo (' selected="selected"');
	       					}
	       					echo ('>'.$dictionary[$currentMonth].'</option>');
	       				}
       				?>
       				</select>
       				<!--
       					Day dropdown box
       				-->
       				<select name="DueDate_Day">
					<?php
						for ($i=1; $i<=31; $i++)
						{
							if ($i<10)
							{
								$currentDay = '0'.$i;
							}
							else
							{
								$currentDay = $i;
							}
							echo ('<option label="'.$currentDay.'" value="'.$currentDay.'"');
							if ($i == $dateUtils->getDayInMonthFromDate($renderObjects->endDate))
							{
	       						echo (' selected="selected"');
							}
							echo ('>'.$currentDay.'</option>');
						}
					?>
					</select>
       				<!--
       					Year dropdown box
       				-->
       				<select name="DueDate_Year">
       				<?php
						$currentYear = $dateUtils->getYearFromDate ($renderObjects->endDate);

						for ($i=5; $i>10; $i--)
						{
							echo ('<option label="'.($currentYear-$i).'" value="'.($currentYear-$i).'"');
							echo ('>'.($currentYear-$i).'</option>');
						}
						echo ('<option label="'.$currentYear.'" value="'.$currentYear.'"');
						echo (' selected="selected"');
						echo ('>'.$currentYear.'</option>');
						for ($i=1; $i<=10; $i++)
						{
							echo ('<option label="'.($currentYear+$i).'" value="'.($currentYear+$i).'"');
							echo ('>'.($currentYear+$i).'</option>');
						}
       				?>
       				</select>
				<!--
					<php echo html_select_date
					end_year="+10"
					prefix="DueDate_"
					time=$renderObjects->endDate >
					-->
				</td>
			</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<?php echo $dictionary['description'] ?>: <textarea name="description"
				cols="80" rows="10"
				><?php echo $renderObjects->description ?></textarea>
		</td>
	</tr>
	</table>
	<h2><?php echo $dictionary['modify'] ?> <?php echo $dictionary['todo'] ?></h2>
	<input type="hidden" value="modifyTodo" name="action" />
	<input type="hidden" value=<?php echo $renderObjects->itemId ?> name="itemId" />
	<input type="hidden" value=<?php echo $renderObjects->parentId ?> name="parentId" />
	<input type="submit" value="<?php echo $dictionary['modify'] ?>" name="modifyTodo" />
</form>

<h2><?php echo $dictionary['move'] ?> <?php echo $dictionary['todo'] ?></h2>
<form method="POST" action="TodoController.php">
	<input type="hidden" value="move" name="action" />
	<input type="hidden" value=<?php echo $renderObjects->itemId ?> name="itemId" />
	<input type="submit" value="<?php echo $dictionary['move'] ?>" name="moveItem" />
</form>

<h2><?php echo $dictionary['delete'] ?> <?php echo $dictionary['todo'] ?></h2>
<form method="POST" action="TodoController.php">
	<input type="hidden" value="delete" name="action" />
	<input type="hidden" value=<?php echo $renderObjects->itemId ?> name="itemId" />
	<input type="submit" value="<?php echo $dictionary['delete'] ?>" name="deleteTodo" />
</form>

