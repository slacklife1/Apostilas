<!--
	Set some custom colors for the popup notes
-->
<script language="JavaScript">
	var ol_textcolor="#000000";
	var ol_capcolor="#000000";
	var ol_bgcolor="#ffee00";
	var ol_fgcolor="#ffff00";
</script>
<table width="100%">
<tr>
		<td>
		<?php
				include ('templates/'.$_SESSION['template'].'/icons.inc');

				if (isset ($_SESSION['noteTree']))
				{
					if ($_SESSION['noteTree'] == "Yahoo")
					{
						include_once "util/YahooTree.php";
						include_once "templates/common/NoteYahooTreeDelegate.php";
						$delegate = new NoteYahooTreeDelegate 
							($icons, "NoteController.php", $dictionary);
						$tree = new YahooTree ($delegate);
					}
					else if ($_SESSION['noteTree'] == "Explorer")
					{
						include_once "util/Tree.php";
						include_once "templates/common/NoteExplorerTreeDelegate.php";
						$delegate = new NoteExplorerTreeDelegate 
							($icons, "NoteController.php", $dictionary);
						$tree = new Tree ($delegate);
					}
				}
				else
				{
					// default
					include_once "util/YahooTree.php";
					include_once "templates/common/NoteYahooTreeDelegate.php";
					$delegate = new NoteYahooTreeDelegate 
						($icons, "NoteController.php", $dictionary);
					$tree = new YahooTree ($delegate);
				}
				

				if (isset ($_SESSION['noteExpand']))
				{
					$tree -> setExpanded ($_SESSION['noteExpand']);
				}
				echo ($tree -> toHtml ($parent, $renderObjects));
		?>
		</td>
		<td align="right" valign="top">
			<h1><?php echo $dictionary['notes'] ?></h1>
			<?php
				foreach ($renderActions as $renderAction)
				{
			?>
				<table width="200" border="0" cellpadding="0" 
					cellspacing="0">
               			<tr valign="top">
                   			<td align="right">
						<h2><?php echo $renderAction['name'] ?></h2>
					</td>
				</tr>
				<tr>
					<td align="right">
					<?php
						foreach ($renderAction['contents'] as $current)
						{
					?>
						<a href="<?php echo $current['href'] ?>"
							>[<?php echo $current['name'] ?>]</a>
					<?php
						}
					?>
                   			</td>
				</tr>
				</table>
			<?php
				}
			?>	
			<br />
			<?php echo $dictionary['note_help'] ?>
		</td>
</tr>
</table>
