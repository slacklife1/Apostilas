<?php
	include ('templates/'.$_SESSION['template'].'/javascript.inc');
?>
<table width="100%">
<tr>
		<td>
			<?php
				include ('templates/'.$_SESSION['template'].'/icons.inc');

				include_once "util/Tree.php";
				include_once "templates/common/MoveItemExplorerTreeDelegate.php";

				$delegate = new MoveItemExplorerTreeDelegate 
					($icons, "TodoController.php", $dictionary);
				$tree = new Tree ($delegate);
				// we would like to show all folders
				$tree -> setExpanded ('*');
				echo ($tree -> toHtml ($item, $renderObjects));
			?>
		</td>
		<td align="right" valign="top">
			<?php
				foreach ($renderActions as $renderAction)
				{
			?>
				<table width="200" border="0" cellpadding="0" 
					cellspacing="0">
               			<tr valign="top">
                   			<td align="right">
							<h2><?php echo $renderAction['name'] ?></h2>

					</td>
				</tr>
				<tr>
					<td align="right">
						<?php
							foreach ($renderAction['contents'] as $current)
							{
						?>
							<a href="<?php echo $current['href'] ?>"
								>[<?php echo $current['name'] ?>]</a>
						<?php
							}
						?>
                   		</td>
					</tr>
				</table>
			<?php
				}
			?>
			<br />
			<?php echo $dictionary['contact_help'] ?>
		</td>
</tr>
</table>
