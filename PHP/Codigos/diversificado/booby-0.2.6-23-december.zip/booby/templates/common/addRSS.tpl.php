<table border="0" width="100%">
<tr>
	<td><h2><?php echo $dictionary['add'] ?>&nbsp;<?php echo $dictionary['news'] ?></h2></td>
</tr>
</table>


<form method="POST" action="NewsController.php">
	<table width="80%" border="1">
	<tr>
		<td>
			<?php echo $dictionary['title'] ?>: <input type="text" name="name"
			size="40" />
		</td>
	</tr>
	<tr>
		<td>
			<?php echo $dictionary['folder'] ?>: <input type="radio" name="isParent"
				value="1" /><br />
			<?php echo $dictionary['link'] ?>: <input type="radio" name="isParent"
				value="0" checked />
		</td>
	</tr>
	<tr>
		<td>
			<?php echo $dictionary['url'] ?> (RSS/RDF): <input type="text" name="locator"
			size="40" />
		</td>
	</tr>
	<tr>
		<td>
			<?php echo $dictionary['description'] ?>: <textarea name="description"
				cols="80" rows="10"
				></textarea>
		</td>
	</tr>
	</table>
	<br />
	<input type="hidden" name="action" value="addItem" />
	<input type="hidden" name="parentId" value="<?php echo $parentId ?>" >
	<input type="submit" value="<?php echo $dictionary['add'] ?>" name="addItem">
</form>
