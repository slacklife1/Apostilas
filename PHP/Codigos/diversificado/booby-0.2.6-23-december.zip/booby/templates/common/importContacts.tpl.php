<form enctype="multipart/form-data" action="ContactController.php" 
	method="post" name="importContacts">
	<select name="importType">
		<option value="VCard">VCard(s)</option>
		<option value="Opera">Opera</option>
		<!--
		option value="CSV"CSV/option
		-->
	</select>
	<br />

	<input type="hidden" name="action" value="importContacts" />
	<input type="hidden" name="MAX_FILE_SIZE" value="1000000">
	<?php echo $dictionary['file'] ?>: <input name="importFile" type="file"><br>
	<input type="submit" name="importSubmit" value="<?php echo $dictionary['submit'] ?>">
</form>
