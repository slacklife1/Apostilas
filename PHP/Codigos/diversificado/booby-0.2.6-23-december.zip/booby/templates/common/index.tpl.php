<?php 
	echo $renderObjects;
?>
<table border="0">
	<tr>
	<?php 
		foreach ($languages as $currentLanguage)
		{
	?>
		<td>
			<form method="POST" action="PreferenceController.php">
				<input type="hidden" name="owner" value="<?php echo $_SESSION['username']; ?>">
				<input type="hidden" value="modifyPreferences" name="action">
				<input type="hidden" name="language" value="<?php echo $currentLanguage; ?>">
				<input type="hidden" name="template" value="<?php echo $_SESSION['template'] ?>">
				<input type="image" src="templates/common/pics/flag-<?php echo $currentLanguage; ?>.png">
			</form>
		</td>
	<?php
		}
	?>
	</tr>
</table>
