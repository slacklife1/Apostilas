<table border="0" width="100%">
<tr>
	<td><h2><?php echo $dictionary['add'] ?>&nbsp;<?php echo $dictionary['contact'] ?></h2></td>
</tr>
</table>



<form method="POST" action="ContactController.php">
	<input type="hidden" value="<?php echo $parentId ?>" name="parentId" />
	<table width="80%" border="0">
	<tr>
		<td>
			<?php echo $dictionary['name'] ?>:
		</td>
		<td colspan="2">
			<input type="text" name="name"
			size="60" />
		</td>
		<td>
			<?php echo $dictionary['folder'] ?>: <input type="radio" name="isParent"
				value="1" /><br />
			<?php echo $dictionary['contact'] ?>: <input type="radio" name="isParent"
				value="0" checked />
		</td>
	</tr>

	<tr>
		<td><?php echo $dictionary['tel_home'] ?>:
		</td>
		<td>
			<input type="text" name="telephoneHome" />
		</td>
		<td><?php echo $dictionary['tel_work'] ?>:
		</td>
		<td>
			<input type="text" name="telephoneWork" />
		</td>
	</tr>
	<tr>
		<td>
			<?php echo $dictionary['mobile'] ?>:
		</td>
		<td>
			<input type="text" name="mobile" />
		</td>
		<td>
			<?php echo $dictionary['faximile'] ?>:
		</td>
		<td>
			<input type="text" name="faximile" />
		</td>
	</tr>
	<tr><td colspan="4">&nbsp;</td></tr>
	<tr>
		<td><?php echo $dictionary['email'] ?>&nbsp;1:
		</td>
		<td>
			<input type="text" name="email1" />
		</td>
		<td><?php echo $dictionary['webaddress'] ?>&nbsp;1:
		</td>
		<td>
			<input type="text" name="webaddress1" value="http://"/>
		</td>
	</tr>
	<tr>
		<td><?php echo $dictionary['email'] ?>&nbsp;2:
		</td>
		<td>
			<input type="text" name="email2" />
		</td>
		<td><?php echo $dictionary['webaddress'] ?>&nbsp;2:
		</td>
		<td>
			<input type="text" name="webaddress2" value="http://" />
		</td>
	</tr>
	<tr>
		<td><?php echo $dictionary['email'] ?>&nbsp;3:
		</td>
		<td>
			<input type="text" name="email3" />
		</td>
		<td><?php echo $dictionary['webaddress'] ?>&nbsp;3:
		</td>
		<td>
			<input type="text" name="webaddress3" value="http://" />
		</td>
	</tr>
	<tr><td colspan="4">&nbsp;</td></tr>
	<tr>
		<td>
			&nbsp;
		</td>
		<td>
			&nbsp;
		</td>
		<td><?php echo $dictionary['jobTitle'] ?>:
		</td>
		<td>
			<input type="text" name="job" />
		</td>
	</tr>
	<tr>
		<td>
			<?php echo $dictionary['alias'] ?>:
		</td>
		<td>
			<input type="text" name="alias" />
		</td>
		<td>
			<?php echo $dictionary['organization'] ?>:
		</td>
		<td>
			<input type="text" name="organization" />
		</td>
	</tr>
	<tr>
		<td>
			<?php echo $dictionary['address'] ?>:
		</td>
		<td>
			<textarea name="address" rows="5"
			cols="25"></textarea>
		</td>
		<td>
			<?php echo $dictionary['org_address'] ?>
		</td>
		<td>
			<textarea name="organizationAddress" rows="5"
			cols="25"></textarea>
		</td>
	</tr>
	<tr>
		<td colspan="4">
			<?php echo $dictionary['description'] ?>: <textarea name="description"
				cols="80" rows="10"
				></textarea>
		</td>
	</tr>
	</table>
	<br />
	<input type="hidden" name="itemId"
		value="<?php echo $renderObjects->itemId ?>" />
	<input type="hidden" value="addContact" name="action">
	<input type="submit" value="<?php echo $dictionary['add'] ?>" name="addContact">

</form>
