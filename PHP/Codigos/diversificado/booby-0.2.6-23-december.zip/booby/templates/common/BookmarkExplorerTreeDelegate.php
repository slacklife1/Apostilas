<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include_once ("util/StringUtils.php");
/**
 * Used in combination with the PHPItemTree class
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.util
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class BookmarkExplorerTreeDelegate
{
	/**
	 * String utilities
	 * @private
	 * @variable object stringUtils
	 */
	var $stringUtils;
	
	/**
	 * Icons in an hashtable. The icons must have the following keys:
	 * 'bar', 'up', 'minus', 'folder_open', 'corner', 'plus', 'tee',
	 * 'folder_closed', 'node', 'before_display', 'after_display'
	 * @private
	 * @variable hashtable icons
	 */
	var $icons;
	
	/**
	 * The URL to the callback, typically the controller
	 * @private
	 * @variable string callbackURL
	 */
	var $callbackURL;
	
	/**
	 * The dictionary that is used
	 * @private
	 * @variable array dictionary
	 */
	var $dictionary;
	
	/**
	 * Default constructor
	 * @param array theIcons the icons used for display
	 * @param string theCallbackURL
	 */
	function BookmarkExplorerTreeDelegate ($theIcons, $theCallbackURL, $theDictionary)
	{
		$this->icons = $theIcons;
		$this->stringUtils = new StringUtils ();
		$this->callbackURL = $theCallbackURL;
		$this->dictionary = $theDictionary;
	}
	
	/**
	 * Builds up html code to display the root of the tree
	 * @private
	 *
	 * @param object item the item that is the root of the tree
	 */
	function showRoot ($item, $tree)
	{
		$resultString = '<div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000;"></div><script language="JavaScript" src="templates/common/javascript/overlib.js"><!-- overLIB (c) Erik Bosrup --></script>';

		if ($item->itemId == 0)
		{
			$resultString .= $this->icons['root'];
		}
		else
		{
			$resultString .= '<h2>'.$item->name.'</h2>';
			$resultString .= '<a href="'.$this->callbackURL;
			$resultString .= '?action=show&parentId='.$item->parentId.'">';
			$resultString .= $this->icons['up'];
			$resultString .= '</a>';
		}
		return $resultString;
	}
	
	/**
	 * If the specified item is a folder, draw it
	 * @private
	 * @param object item the item to draw
	 * @param boolean isExpanded whether this folder is expanded (i.e. do the
	 * children of this folder need to be displayed as well?)
	 * @param object tree the tree that uses this class as delegate
	 * @return string the string for this folder
	 */
	function drawFolder ($item, $isExpanded, $tree, $indentLevel)
	{
		$resultString = '
								<tr><td>';
								
		for ($i=0; $i<$indentLevel; $i++)
		{
			$resultString .= $this->icons['bar'];
		}
	
		if ($isExpanded)
		{
			$res = $tree->createExpandedListWithout ($item->itemId);
			$resultString .= '<a href="';
			$resultString .= $this->callbackURL;
			$resultString .= '?expand=' . implode (',', $res);
			$resultString .= '&parentId='.$tree->root->itemId;
			$resultString .= '">';
			$resultString .= $this->icons['minus'];
			$resultString.= '</a>';
			
			$resultString.= '<a href="';
			$resultString .= $this->callbackURL;
			$resultString .= '?action=modify&itemId=';
			$resultString .= $item->itemId . '">';
			$resultString .= $this->icons['folder_open'];
			$resultString .= '</a>';
		}
		else
		{
			// ???
			$linkExpand = "";
			// ???
			if (!$tree->isExpanded ($item->itemId) && $tree->expanded != null)
			{
				$linkExpand .= implode(",", $tree->expanded).",".$item->itemId;
			}
			else
			{
				$linkExpand = $item->itemId;
			}
			if ($item->parentId != null)
			{
				$resultString .= '<a href="';
				$resultString .= $this->callbackURL;
				$resultString .= '?expand=' . $linkExpand;
				//$resultString .= '&parentId='.$item->parentId;
				$resultString .= '">';
			}
			else
			{
				$resultString .= '<a href="';
				$resultString .= $this->callbackURL;
				$resultString .= '?expand='.$linkExpand.'">';
			}
			$resultString .= $this->icons ['plus'];
			$resultString .= '</a>';
			$resultString .= '<a href="';
			$resultString .= $this->callbackURL;
			$resultString .= '?action=modify&itemId=';
			$resultString .= $item->itemId . '">';
			$resultString .= $this->icons ['folder_closed'];
			$resultString .= '</a>';
		}
		$resultString .= '<a href="';
		$resultString .= $this->callbackURL;
		$resultString .= '?action=show&parentId=';
		$resultString .= $item->itemId . '">';
		$resultString .= $item->name;
		$resultString .= '</a>';
		
		$resultString .= '</td></tr>';
		return $resultString;
	}
	
	
	/**
	 * If the specified item is a node, draw it
	 * @private
	 * @param object item the item to draw
	 * @param boolean lastNode whether this node is the last one
	 * @return string the string for this node
	 */
	function drawNode ($item, $lastNode, $tree, $indentLevel)
	{
		$resultString = '
								<tr><td>';
		for ($i=0; $i<$indentLevel; $i++)
		{
			$resultString .= $this->icons['bar'];
		}
		if ($lastNode)
		{
			$resultString .= $this->icons['corner'];
		}	
		else
		{
			$resultString .= $this->icons['tee'];
		}
		$resultString .= '<a href="';
		$resultString .= $this->callbackURL;
		$resultString .= '?action=modify&itemId=';
		$resultString .= $item->itemId . '">';
		$resultString .= $this->icons['node'];
		$resultString .= '</a>';

		$resultString .= "<a href='";
		$resultString .= $this->callbackURL;
		$resultString .= '?action=showBookmark&itemId=';
		$resultString .= $item->itemId . "' ";


		// overlib popup
		$resultString .= "onmouseover=\"return overlib('";
		$resultString .= $this->stringUtils->urlEncode (addslashes ($item->locator)) . '<br />';
		$resultString .= addslashes ($this->stringUtils->urlEncode($item->description));
		$resultString .= "', CAPTION, '";
		$resultString .= addslashes($this->stringUtils->urlEncode($item->name)) . "');\" ";
		$resultString .= "onmouseout=\"return nd();\" ";
		// end overlib popup
	
		$resultString .= 'alt="'. $item->name . '" target=_new>';
		$resultString .= $item->name;
		$resultString .= '</a>';
	
		// open in new window option
		$resultString .= '<a href="';
		$resultString .= $this->callbackURL;
		$resultString .= '?action=showBookmark&itemId=';
		$resultString .= $item->itemId . '">';
		$resultString .= $this->icons['open_new_window'] . '</a>';
	
		$resultString .= '</td></tr>';
		return $resultString;
	}	
}
?>