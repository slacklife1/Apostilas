<form enctype="multipart/form-data" action="BookmarkController.php" 
	method="post" name="importBookmarks">
	<select name="importType">
		<option value="Opera">Opera</option>
		<option value="Netscape">Netscape/Mozilla</option>
	</select>
	<br />

	<?php echo $dictionaryi['file'] ?>: 
	<input type="file" name="importFile"><br>
	<input type="hidden" name="action" value="importBookmarks" />
	<input type="hidden" name="MAX_FILE_SIZE" value="1000000">
	<input type="submit" name="importSubmit" value="<?php echo $dictionary['submit'] ?>">
</form>
