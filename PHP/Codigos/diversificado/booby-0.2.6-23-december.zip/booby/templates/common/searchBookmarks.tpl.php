<h2><?php echo $dictionary['search'].' '.$dictionary['bookmarks'] ?></h2>

<table>
<tr>
	<td>
		<?php echo $dictionary['name'] ?>:
	</td>
	<td>
		<form method="POST" action="BookmarkController.php">
		<input type="hidden" name="field" value="name">
		<input type="text" name="value">
		<input type="hidden" name="action" value="searchBookmarks">
		<input type="submit" value="<?php echo $dictionary['search'] ?>">
		</form>
	</td>
</tr>
<tr>
	<td>
		<?php echo $dictionary['url'] ?>:
	</td>
	<td>
		<form method="POST" action="BookmarkController.php">
		<input type="hidden" name="field" value="locator">
		<input type="text" name="value">
		<input type="hidden" name="action" value="searchBookmarks">
		<input type="submit" value="<?php echo $dictionary['search'] ?>">
		</form>
	</td>
</tr>
<tr>
	<td>
		<?php echo $dictionary['description'] ?>:
	</td>
	<td>
		<form method="POST" action="BookmarkController.php">
		<input type="hidden" name="field" value="description">
		<input type="text" name="value">
		<input type="hidden" name="action" value="searchBookmarks">
		<input type="submit" value="<?php echo $dictionary['search'] ?>">
		</form>
	</td>
</tr>
</table>
