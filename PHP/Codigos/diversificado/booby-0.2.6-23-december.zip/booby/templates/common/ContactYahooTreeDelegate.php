<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include_once ("util/StringUtils.php");
/**
 * Used in combination with the PHPItemTree class
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.util
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class ContactYahooTreeDelegate
{
	/**
	 * String utilities
	 * @private
	 * @variable object stringUtils
	 */
	var $stringUtils;
	
	/**
	 * Icons in an hashtable. The icons must have the following keys:
	 * 'bar', 'up', 'minus', 'folder_open', 'corner', 'plus', 'tee',
	 * 'folder_closed', 'node', 'before_display', 'after_display'
	 * @private
	 * @variable hashtable icons
	 */
	var $icons;
	
	/**
	 * The URL to the callback, typically the controller
	 * @private
	 * @variable string callbackURL
	 */
	var $callbackURL;
	
	/**
	 * The dictionary that is used
	 * @private
	 * @variable array dictionary
	 */
	var $dictionary;

	/**
	 * Default constructor
	 * @param array theIcons the icons used for display
	 * @param string theCallbackURL
	 */
	function ContactYahooTreeDelegate ($theIcons, $theCallbackURL, $theDictionary)
	{
		$this->icons = $theIcons;
		$this->stringUtils = new StringUtils ();
		$this->dictionary = $theDictionary;
		$this->callbackURL = $theCallbackURL;
	}
	
	/**
	 * Builds up html code to display the root of the tree
	 * @private
	 *
	 * @param object item the item that is the root of the tree
	 */
	function showRoot ($item, $tree)
	{
		$resultString = '';
		//$resultString = '<div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000;"></div><script language="JavaScript" src="javascript/overlib.js"><!-- overLIB (c) Erik Bosrup --></script>';

		if ($item->itemId == 0)
		{
//			$resultString .= $this->icons['root'];
		}
		else
		{
			$resultString .= '<h2>'.$item->name.'</h2>';
			$resultString .= '<a href="'.$this->callbackURL;
			$resultString .= '?action=show&parentId='.$item->parentId.'">';
			$resultString .= $this->icons['up'];
			$resultString .= '</a><br />';
		}
		return $resultString;
	}
	
	/**
	 * If the specified item is a folder, draw it
	 * @private
	 * @param object item the item to draw
	 * @param boolean isExpanded whether this folder is expanded (i.e. do the
	 * children of this folder need to be displayed as well?)
	 * @param object tree the tree that uses this class as delegate
	 * @return string the string for this folder
	 */
	function drawFolder ($item, $isExpanded, $tree, $indentLevel)
	{
		$resultString .= '<a href="';
		$resultString .= $this->callbackURL;
		$resultString .= '?action=modify&itemId=';
		$resultString .= $item->itemId . '">';
		$resultString .= $this->icons ['folder_closed'];
		$resultString .= '</a>';

		$resultString .= '<a href="';
		$resultString .= $this->callbackURL;
		$resultString .= '?action=show&parentId=';
		$resultString .= $item->itemId . '">';
		$resultString .= $item->name;
		$resultString .= '</a>';
		
		$resultString .= '<br />';
		return $resultString;
	}
	
	
	/**
	 * If the specified item is a node, draw it
	 * @private
	 * @param object item the item to draw
	 * @param boolean lastNode whether this node is the last one
	 * @return string the string for this node
	 */
	function drawNode ($item, $lastNode, $tree, $indentLevel)
	{
		$resultString .= '<table border="0" valign="top" width="220" bgcolor="#bbbbbb">';

		$resultString .= '<tr>';
		$resultString .= '<td class="menu" align="left" width="40">';
		$resultString .= '<a ';
		$resultString .= 'href="ContactController.php?itemId='.$item->itemId.'&action=modify"';
		$resultString .= '>'.$this->icons['edit'].'</a>';
		$resultString .= '<a ';
		$resultString .= 'href="ContactController.php?itemId='.$item->itemId.'&action=deleteContact"';
		$resultString .= '>'.$this->icons['delete'].'</a>';
		$resultString .= '</td>';
		$resultString .= '<td class="menu"><b>';
		$resultString .= $this->stringUtils->truncate($item->name, 20);
		$resultString .= '</b>';
		$resultString .= '</td>';
		$resultString .= '</tr>';
		
		if ($item->alias != null)
		{
			$resultString .= '<tr>';
			$resultString .= '<td class="contact">';
			$resultString .= $this->dictionary['alias'];
			$resultString .= ':</td>';
			$resultString .= '<td class="contact">';
			$resultString .= $this->stringUtils->truncate ($item->alias, 20).'</a>';
			$resultString .= '</td>';
			$resultString .= '</tr>';
		}
		if ($item->email1 != null)
		{
			$resultString .= '<tr>';
			$resultString .= '<td class="contact">';
			$resultString .= $this->dictionary['email'].'&nbsp;1:';
			$resultString .= '</td>';
			$resultString .= '<td class="contact">';
			$resultString .= '<a ';
			$resultString .= 'href="mailto:'.$item->email1.'">';
			$resultString .= $this->stringUtils->truncate ($item->email1, 20).'</a>';
			$resultString .= '</td>';
			$resultString .= '</tr>';
		}
		if ($item->email2 != null)
		{
			$resultString .= '<tr>';
			$resultString .= '<td class="contact">';
			$resultString .= $this->dictionary['email'].'&nbsp;2:';
			$resultString .= '</td>';
			$resultString .= '<td class="contact">';
			$resultString .= '<a ';
			$resultString .= 'href="mailto:'.$item->email2.'">';
			$resultString .= $this->stringUtils->truncate ($item->email2, 20).'</a>';
			$resultString .= '</td>';
			$resultString .= '</tr>';
		}
		if ($item->email3 != null)
		{
			$resultString .= '<tr>';
			$resultString .= '<td class="contact">';
			$resultString .= $this->dictionary['email'].'&nbsp;3:';
			$resultString .= '</td>';
			$resultString .= '<td class="contact">';
			$resultString .= '<a ';
			$resultString .= 'href="mailto:'.$item->email3.'">';
			$resultString .= $this->stringUtils->truncate ($item->email3, 20).'</a>';
			$resultString .= '</td>';
			$resultString .= '</tr>';
		}
		if ($item->webaddress1 != null)
		{
			$resultString .= '<tr>';
			$resultString .= '<td class="contact">';
			$resultString .= $this->dictionary['webaddress'].'&nbsp;1:';
			$resultString .= '</td>';
			$resultString .= '<td class="contact">';
			$resultString .= '<a ';
			$resultString .= 'href="'.$item->webaddress1.'">';
			$resultString .= $this->stringUtils->truncate ($item->webaddress1, 20).'</a>';
			$resultString .= '</td>';
			$resultString .= '</tr>';
		}
		if ($item->webaddress2 != null)
		{
			$resultString .= '<tr>';
			$resultString .= '<td class="contact">';
			$resultString .= $this->dictionary['webaddress'].'&nbsp;2:';
			$resultString .= '</td>';
			$resultString .= '<td class="contact">';
			$resultString .= '<a ';
			$resultString .= 'href="'.$item->webaddress2.'">';
			$resultString .= $this->stringUtils->truncate ($item->webaddress2, 20).'</a>';
			$resultString .= '</td>';
			$resultString .= '</tr>';
		}
		if ($item->webaddress3 != null)
		{
			$resultString .= '<tr>';
			$resultString .= '<td class="contact">';
			$resultString .= $this->dictionary['webaddress'].'&nbsp;3:';
			$resultString .= '</td>';
			$resultString .= '<td class="contact">';
			$resultString .= '<a ';
			$resultString .= 'href="'.$item->webaddress3.'">';
			$resultString .= $this->stringUtils->truncate ($item->webaddress3, 20).'</a>';
			$resultString .= '</td>';
			$resultString .= '</tr>';
		}
		if ($item->telephoneWork != null)
		{
			$resultString .= '<tr>';
			$resultString .= '<td class="contact">';
			$resultString .= $this->dictionary['tel_work'];
			$resultString .= ':</td>';
			$resultString .= '<td class="contact">';
			$resultString .= $item->telephoneWork;
			$resultString .= '</td>';
			$resultString .= '</tr>';
		}
		if ($item->telephoneHome != null)
		{
			$resultString .= '<tr>';
			$resultString .= '<td class="contact">';
			$resultString .= $this->dictionary['tel_home'];
			$resultString .= ':</td>';
			$resultString .= '<td class="contact">';
			$resultString .= $item->telephoneHome;
			$resultString .= '</td>';
			$resultString .= '</tr>';
		}
		if ($item->mobile != null)
		{
			$resultString .= '<tr>';
			$resultString .= '<td class="contact">';
			$resultString .= $this->dictionary['mobile'];
			$resultString .= ':</td>';
			$resultString .= '<td class="contact">';
			$resultString .= $item->mobile;
			$resultString .= '</td>';
			$resultString .= '</tr>';
		}
		if ($item->faximile != null)
		{
			$resultString .= '<tr>';
			$resultString .= '<td class="contact">';
			$resultString .= $this->dictionary['faximile'];
			$resultString .= ':</td>';
			$resultString .= '<td class="contact">';
			$resultString .= $item->faximile;
			$resultString .= '</td>';
			$resultString .= '</tr>';
		}
		if ($item->description != null)
		{
			$resultString .= '<tr>';
			$resultString .= '<td colspan="2" bgcolor="#ffffff">';
			$resultString .= $this->stringUtils->truncate ($item->description, 30);
			$resultString .= '</td>';
			$resultString .= '</tr>';
		}
		$resultString .= "<tr><td></td><td></td></tr>";
		$resultString .= '</table>';

		return $resultString;
	}	
}
?>