<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include_once ("util/StringUtils.php");
require_once ("util/magpierss/rss_fetch.inc");
require_once ("util/magpierss/rss_parse.inc");
/**
 * Used in combination with the PHPItemTree class
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.util
 * @copyright
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a>
 * and look for licenses
 */
class NewsYahooTreeDelegate
{
	/**
	 * String utilities
	 * @private
	 * @variable object stringUtils
	 */
	var $stringUtils;

	/**
	 * Icons in an hashtable. The icons must have the following keys:
	 * 'bar', 'up', 'minus', 'folder_open', 'corner', 'plus', 'tee',
	 * 'folder_closed', 'node', 'before_display', 'after_display'
	 * @private
	 * @variable hashtable icons
	 */
	var $icons;

	/**
	 * The URL to the callback, typically the controller
	 * @private
	 * @variable string callbackURL
	 */
	var $callbackURL;

	/**
	 * The dictionary that is used
	 * @private
	 * @variable array dictionary
	 */
	var $dictionary;

	/**
	 * Default constructor
	 * @param array theIcons the icons used for display
	 * @param string theCallbackURL
	 */
	function NewsYahooTreeDelegate ($theIcons, $theCallbackURL, $theDictionary)
	{
		$this->icons = $theIcons;
		$this->stringUtils = new StringUtils ();
		$this->callbackURL = $theCallbackURL;
		$this->dictionary = $theDictionary;
	}

	/**
	 * Builds up html code to display the root of the tree
	 * @private
	 *
	 * @param object item the item that is the root of the tree
	 */
	function showRoot ($item, $tree)
	{
		$resultString ='';
		if ($item->itemId == 0)
		{
//			$resultString .= $this->icons['root'];
		}
		else
		{
			$resultString .= '<h2>'.$item->name.'</h2>';
			$resultString .= '<a href="'.$this->callbackURL;
			$resultString .= '?action=show&parentId='.$item->parentId.'">';
			$resultString .= $this->icons['up'];
			$resultString .= '</a><br />';
		}
		return $resultString;
	}

	/**
	 * If the specified item is a folder, draw it
	 * @private
	 * @param object item the item to draw
	 * @param boolean isExpanded whether this folder is expanded (i.e. do the
	 * children of this folder need to be displayed as well?)
	 * @param object tree the tree that uses this class as delegate
	 * @return string the string for this folder
	 */
	function drawFolder ($item, $isExpanded, $tree, $indentLevel)
	{
		$resultString .= '<a href="';
		$resultString .= $this->callbackURL;
		$resultString .= '?action=modify&itemId=';
		$resultString .= $item->itemId . '">';
		$resultString .= $this->icons ['folder_closed'];
		$resultString .= '</a>';

		$resultString .= '<a href="';
		$resultString .= $this->callbackURL;
		$resultString .= '?action=show&parentId=';
		$resultString .= $item->itemId . '">';
		$resultString .= $item->name;
		$resultString .= '</a>';

		$resultString .= '<br />';
		return $resultString;
	}


	/**
	 * If the specified item is a node, draw it
	 * @private
	 * @param object item the item to draw
	 * @param boolean lastNode whether this node is the last one
	 * @return string the string for this node
	 */
	function drawNode ($item, $lastNode, $tree, $indentLevel)
	{
		// testing purposes. Developing on a local machine might imply that
		// you are being blocked by a proxy. Magpie does not provide
		// proxy things, so you can test by loading a file that is something
		// in the form of either file:///c:/temp/myfile.xml or
		// file:///home/barrel/tmp/myfile.xml
		//
		// Local file MUST start with 'file:///'
		if ($this->stringUtils->startsWith ($item->locator, "file:///"))
		{
			$filename = substr($item->locator, strlen("file:///"), strlen ($item->locator));
			$fh = fopen($filename, 'r') or die($php_errormsg);
    		$rss_string = fread($fh, filesize($filename) );
    		fclose($fh);
    		$rss = new MagpieRSS ($rss_string);
		}
		else
		{
			$rss = fetch_rss ($item->locator);
		}
		if ($rss)
		{
			$resultString .= '<table border="0" width="300">';

			// one row with name and icon to modify
			$resultString .= '<tr valign="top">';
			$resultString .= '<td><b>';
			$resultString .= '<a href="';
			$resultString .= $this->callbackURL;
			$resultString .= '?action=modify&itemId=';
			$resultString .= $item->itemId . '">';
			$resultString .= $this->icons['node'];
			$resultString .= '</a>';
			$resultString .= '<a href="';
			$resultString .= $rss->channel['link'];
			$resultString .= '">';
			$resultString .= $item->name;
			$resultString .= '</a></b>';
			$resultString .= '</td>';
			$resultString .= '</tr>';

			$resultString .= '<tr>';
			$resultString .= '<td><em>';
			$resultString .= $rss->channel['description'];
			$resultString .= '</em></td>';
			$resultString .= '</tr>';

			// Only show the image if the image URL is provided
			if ($rss->image['url'] != null)
			{
				$resultString .= '<tr>';
				$resultString .= '<td><img src="';
				$resultString .= $rss->image['url'];
				$resultString .= '"></td>';
				$resultString .= '</tr>';
			}
			foreach ($rss->items as $rssitem)
			{
				$resultString .= '<tr>';
				$resultString .= '<td>';
				$resultString .= '<a href="';
				$resultString .= $rssitem['link'];
				$resultString .= '">';
				$resultString .= $this->stringUtils->urlEncode ($rssitem['title']);
				$resultString .= '</a>';
				$resultString .= '</td>';
				$resultString .= '</tr>';

				$resultString .= '<tr>';
				$resultString .= '<td>';
				$resultString .= $this->stringUtils->urlEncode ($rssitem['description']);
				$resultString .= '</td>';
				$resultString .= '</tr>';
			}

			$resultString .= '</table>';
		}
		else
		{
			$resultString .= '<table border="0" width="300">';
			$resultString .= '<tr valign="top">';
			$resultString .= '<td><b>';
			$resultString .= '<a href="';
			$resultString .= $this->callbackURL;
			$resultString .= '?action=modify&itemId=';
			$resultString .= $item->itemId . '">';
			$resultString .= $this->icons['node'];
			$resultString .= '</a>';
			$resultString .= "<b>Error: </b>Could not parse ".$item->name;
			$resultString .= "</td></tr>";
			$resultString .= '</table>';

		}
		return $resultString;
	}
}
?>