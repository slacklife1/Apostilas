<h2><?php echo $dictionary['preferences'] ?></h2>
<?php
	include 'configs/adminConfiguration.php';
?>
<form method="POST" action="PreferenceController.php">
<table border="0" width="100%">
<tr>
<td width="400">
	<table>
		<tr>
			<td><?php echo $dictionary['language'] ?>:</td>
			<td>
				<select name="language">
					<?php
						foreach ($languages as $language)
						{
							echo ('<option value="'.$language.'"');
							if ($preferences->language == $language)
							{
								echo (' selected="selected"');
							}
							echo ('>'.$language.'</option>');
						}
					?>
				</select>
			</td>
		</tr>
		<tr>
			<td><?php echo $dictionary['theme'] ?>:</td>
			<td>
				<select name="template">
					<?php
						foreach ($templates as $template)
						{
							echo ('<option value="'.$template.'"');
							if ($preferences->template == $template)
							{
								echo (' selected="selected"');
							}
							echo ('>'.$template.'</option>');
						}
					?>
				</select>
			</td>
		</tr>
	</table>
</td>
<td>
	<h3>Quickmark</h3>
	<?php echo $dictionary['quickmark'] ?>
	<a href="<?php echo $quickmark ?>">Booby - Quickmark</a>
	<h3>Sidebar</h3>
	<a href="sidebar.php">Netscape/Mozilla/Opera Sidebar</a>
</td>
</tr>
</table>
<input type="hidden" name="owner" value="<?php echo $renderObjects->owner ?>">
<input type="hidden" value="modifyPreferences" name="action">
<input type="submit" value="<?php echo $dictionary['modify'] ?>">
</form>
<h2><?php echo $dictionary['user'] ?></h2>
<form method="POST" action="UsersController.php">
<table cellspacing="2" cellpadding="2">
<tr>
	<td><?php echo $dictionary['loginName'] ?>:
	</td>
	<td><?php echo $userSettings->username ?>
	</td>
</tr>
<tr>
	<td><?php echo $dictionary['password'] ?>:
	</td>
	<td><input type="password" name="password" />
	</td>
</tr>
<tr>
	<td><?php echo $dictionary['confirm'] ?>:
	</td>
	<td><input type="password" name="password2" />
	</td>
</tr>
<tr>
	<td><?php echo $dictionary['name'] ?>:
	</td>
	<td><input type="text" name="name" 
		value="<?php echo $userSettings->name ?>" />
	</td>
</tr>
<tr>
	<td><?php echo $dictionary['email'] ?>:
	</td>
	<td><input type="text" name="email" 
		value="<?php echo $userSettings->email ?>" />
	</td>
</tr>
<tr>
	<td valign="top"><?php echo $dictionary['description'] ?>:
	</td>
	<td><textarea row="5" cols="60" name="description"
		><?php echo $userSettings->description ?></textarea>
	</td>
</tr>
</table>
<input type="hidden" value="<?php echo $userSettings->userId ?>" name="userId">
<input type="hidden" value="<?php echo $userSettings->username ?>" name="user">
<input type="hidden" value="modifyUser" name="action">
<input type="submit" value="<?php echo $dictionary['modify'] ?>">
</form>
