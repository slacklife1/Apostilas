<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
include_once ("util/StringUtils.php");
/**
 * Used in combination with the PHPItemTree class
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.util
 * @copyright 
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a> 
 * and look for licenses
 */
class NoteYahooTreeDelegate
{
	/**
	 * String utilities
	 * @private
	 * @variable object stringUtils
	 */
	var $stringUtils;
	
	/**
	 * Icons in an hashtable. The icons must have the following keys:
	 * 'bar', 'up', 'minus', 'folder_open', 'corner', 'plus', 'tee',
	 * 'folder_closed', 'node', 'before_display', 'after_display'
	 * @private
	 * @variable hashtable icons
	 */
	var $icons;
	
	/**
	 * The URL to the callback, typically the controller
	 * @private
	 * @variable string callbackURL
	 */
	var $callbackURL;
	
	/**
	 * The dictionary that is used
	 * @private
	 * @variable array dictionary
	 */
	var $dictionary;

	/**
	 * Default constructor
	 * @param array theIcons the icons used for display
	 * @param string theCallbackURL
	 */
	function NoteYahooTreeDelegate ($theIcons, $theCallbackURL, $theDictionary)
	{
		$this->icons = $theIcons;
		$this->stringUtils = new StringUtils ();
		$this->callbackURL = $theCallbackURL;
		$this->dictionary = $theDictionary;
	}
	
	/**
	 * Builds up html code to display the root of the tree
	 * @private
	 *
	 * @param object item the item that is the root of the tree
	 */
	function showRoot ($item, $tree)
	{
		$resultString = '<div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000;"></div><script language="JavaScript" src="templates/common/javascript/overlib.js"><!-- overLIB (c) Erik Bosrup --></script>';

		if ($item->itemId == 0)
		{
//			$resultString .= $this->icons['root'];
		}
		else
		{
			$resultString .= '<h2>'.$item->name.'</h2>';
			$resultString .= '<a href="'.$this->callbackURL;
			$resultString .= '?action=show&parentId='.$item->parentId.'">';
			$resultString .= $this->icons['up'];
			$resultString .= '</a><br />';
		}
		return $resultString;
	}
	
	/**
	 * If the specified item is a folder, draw it
	 * @private
	 * @param object item the item to draw
	 * @param boolean isExpanded whether this folder is expanded (i.e. do the
	 * children of this folder need to be displayed as well?)
	 * @param object tree the tree that uses this class as delegate
	 * @return string the string for this folder
	 */
	function drawFolder ($item, $isExpanded, $tree, $indentLevel)
	{
		$resultString .= '<a href="';
		$resultString .= $this->callbackURL;
		$resultString .= '?action=modify&itemId=';
		$resultString .= $item->itemId . '">';
		$resultString .= $this->icons ['folder_closed'];
		$resultString .= '</a>';

		$resultString .= '<a href="';
		$resultString .= $this->callbackURL;
		$resultString .= '?action=show&parentId=';
		$resultString .= $item->itemId . '">';
		$resultString .= $item->name;
		$resultString .= '</a>';
		
		$resultString .= '<br />';
		return $resultString;
	}
	
	
	/**
	 * If the specified item is a node, draw it
	 * @private
	 * @param object item the item to draw
	 * @param boolean lastNode whether this node is the last one
	 * @return string the string for this node
	 */
	function drawNode ($item, $lastNode, $tree, $indentLevel)
	{
		$resultString  = '
						 <table border="0" valign="top" width="200"  ';
		$resultString .= 'bgcolor="#ffffff"	cellpadding="0" cellspacing="5">';
		
		
		//	Note header: title with link, icons (delete+modify)
		//	and note popup
		$resultString .= '<tr><td class="menu">';
		$resultString .= '<table width="100%" cellpadding="0" cellspacing="0" border="0">';
		$resultString .= '<tr bgcolor="#cccccc">';
		$resultString .= '<td>';
		$resultString .= '<a href="'.$this->callbackURL.'?itemId='.$item->itemId.'&action=modify" ';
		$resultString .= 'onmouseover="return overlib(\'';
		$resultString .= $this->stringUtils->urlEncode ($item->description);
		$resultString .= '\', CAPTION, \'';
		$resultString .= $this->stringUtils->urlEncode($item->name).'\');" ';
		$resultString .= ' onmouseout="return nd();"><b>';
		$resultString .= $this->stringUtils->truncate ($item->name, 30). '</b></a>';
		$resultString .= '</td><td width="20" align="right">';
		$resultString .= '<a href="'.$this->callbackURL.'?itemId=';
		$resultString .= $item->itemId.'&action=modify" ';
		$resultString .= '>'.$this->icons['edit'].'</a>';
		$resultString .= '</td><td width="20" align="right">';
		$resultString .= '<a href="'.$this->callbackURL.'?itemId=';
		$resultString .= $item->itemId.'&action=delete" ';
		$resultString .= '>'.$this->icons['delete'].'</a>';
		$resultString .= '</td></tr></table></td></tr><tr><td bgcolor="f3f3f3">';
		$resultString .= $this->stringUtils->truncate ($item->description, 60);
		$resultString .= '</td></tr></table>';
	
		$resultString .= '<br />';
		return $resultString;
	}	
}
?>