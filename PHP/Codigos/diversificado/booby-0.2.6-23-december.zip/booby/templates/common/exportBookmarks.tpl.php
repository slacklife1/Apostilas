<form action="BookmarkController.php" method="post"
		name="exportBookmarks">
	<select name="exportType">
		<option value="Opera">Opera</option>
		<option value="Netscape">Netscape/Mozilla</option>
<!--
		<option value="CSV">CSV</option>
		<option value="HTML">HTML</option>
-->
	</select>
	<br />

	<input type="hidden" name="action" value="exportBookmarks" />
	<input type="submit" name="exportSubmit" value="<?php echo $dictionary['submit'] ?>">
</form>
