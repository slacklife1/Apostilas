<table border="0" width="100%">
<tr>
	<td><h2><?php echo $dictionary['modify'] ?>&nbsp;<?php echo $dictionary['note'] ?></h2></td>
</tr>
</table>



<form method="POST" action="NoteController.php">
	<table width="80%" border="1">
	<tr>
		<td>
			<?php echo $dictionary['title'] ?>: <input type="text" name="name"
			size="40"
			value="<?php echo $renderObjects->name ?>" />
		</td>
	</tr>
	<tr>
		<td>
			<?php echo $dictionary['contents'] ?>: <textarea name="description"
				cols="80" rows="10"
				><?php echo $renderObjects->description ?></textarea>
		</td>
	</tr>
	</table>
	<h2><?php echo $dictionary['modify'] ?> <?php echo $dictionary['note'] ?></h2>
	<input type="hidden" name="itemId"
		value="<?php echo $renderObjects->itemId ?>" />
	<input type="hidden" name="parentId"
		value="<?php echo $renderObjects->parentId ?>" />
	<input type="hidden" value="modifyNote" name="action">
	<input type="submit" value="<?php echo $dictionary['modify'] ?>" name="modifyNote">

</form>

<h2><?php echo $dictionary['move'] ?> <?php echo $dictionary['note'] ?></h2>
<form method="POST" action="NoteController.php">
	<input type="hidden" name="itemId"
		value="<?php echo $renderObjects->itemId ?>" />
	<input type="hidden" value="move" name="action">
	<input type="submit" value="<?php echo $dictionary['move'] ?>" name="move">
</form>

<h2><?php echo $dictionary['delete'] ?> <?php echo $dictionary['note'] ?></h2><form method="POST" action="NoteController.php">
	<input type="hidden" name="itemId"
		value="<?php echo $renderObjects->itemId ?>" />
	<input type="hidden" value="delete" name="action">
	<input type="submit" value="<?php echo $dictionary['delete'] ?>" name="deleteNote">
</form>

