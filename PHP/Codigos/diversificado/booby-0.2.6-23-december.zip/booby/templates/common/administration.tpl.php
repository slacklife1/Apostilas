<table width="100%" border="0">
<tr>
		<td>
			<h2><?php echo $dictionary['admin'] ?></h2>
			<ul>
			<?php
				foreach ($renderObjects as $user)
				{
			?>
				<li><?php echo $user->username ?>
				<a
					href="admin.php?action=modify&userId=<?php echo $user->userId ?>"
					><img src="templates/mylook/pics/edit.png"
					border="0"></a>
				<a
					href="admin.php?action=deleteUser&userId=<?php echo $user->userId ?>"
					><img src="templates/mylook/pics/delete.png"
					border="0"></a>
			<?php
				}
			?>
			</ul>
		</td>
        <td valign="top" align="right">
            <h2><?php echo $dictionary['admin'] ?></h2>
	    <?php
		    foreach ($renderActions as $renderAction)
		    {
		?>
	     		<a href="<?php echo $renderAction['href'] ?>"
				><?php echo $renderAction['name'] ?></a>
		 <?php
		 	}
		 ?>
        </td>   
</tr>
</table>
