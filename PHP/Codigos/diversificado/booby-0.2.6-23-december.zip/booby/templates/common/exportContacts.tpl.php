<form action="ContactController.php" method="post"
		name="exportContacts">
	<select name="exportType">
		<option value="Opera">Opera</option>
		<option value="VCard">VCard(s)</option>
	</select>
	<br />

	<input type="hidden" name="action" value="exportContacts" />
	<input type="submit" name="exportSubmit" value="<?php echo $dictionary['submit'] ?>">
</form>
