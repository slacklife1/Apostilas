<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
// only used for the renderEngine setting
include ('configs/adminConfiguration.php');
require_once ('Controller.php');
require_once ('util/BookmarkUtils.php');
require_once ('model/BookmarkServices.php');
require_once ('model/BookmarkFactory.php');
/**
 * The Bookmark Controller
 *
 * @author Barry Nauta
 * @date July 2003
 * @package be.nauta.booby.controller
 * @copyright
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a>
 * and look for licenses
 */
class BookmarkController extends Controller
{
	/**
	 * Constructor. 
	 * Makes sure that the appropriate operations are instantiated.
	 * @param string renderEngineName the render engine to be used
	 * (either Smartu or phpSavant)
	 */
	function BookmarkController ($renderEngineName)
	{
		parent::Controller ($renderEngineName);
		$this->operations = new BookmarkServices ();
		$this->itemFactory = new BookmarkFactory ();
	}

	/**
	 * Returns the title of this Controller
	 *
	 * @return string the title of this controller
	 */
	function getTitle ()
	{
		return "Booby - Bookmarks";
	}

	/**
	 * Returns the name of the item that is controller by this controller
	 *
	 * @return string the name of the item that is controlled by this controller
	 */
	function getItemName ()
	{
		return "Bookmark";
	}

	/**
 	 * Returns the actions defined for this item only
 	 *
 	 * @return array an array of item specific actions (like search, import etc.)
 	 */
	function getActions ()
	{
		global $dictionary;
		$actions=array(
			array (
				'name'=> $dictionary['actions'],
				'contents'=>
				array (
					array('href' => 'BookmarkController.php?action=add&parentId='.$this->getParentId (),
						'name' => $dictionary['add']),
					array('href' => 'BookmarkController.php?action=import',
						'name' => $dictionary['import']),
					array('href' => 'BookmarkController.php?action=export',
						'name' => $dictionary['export']),
					array('href' => 'BookmarkController.php?action=search',
						'name' => $dictionary['search'])
					)
				),
			array (
				'name'=> $dictionary['view'],
				'contents' =>
				array (
					array('href' => 'BookmarkController.php?expand=*',
						'name' => $dictionary['expand']),
					array('href' => 'BookmarkController.php?expand=0',
						'name' => $dictionary['collapse']),
					array('href' => 'BookmarkController.php?action=setYahooTree&parentId='.$this->getParentId (),
						'name' => $dictionary['yahooTree']),
					array('href' => 'BookmarkController.php?action=setExplorerTree&parentId='.$this->getParentId (),
						'name' => $dictionary['explorerTree'])
				)
			),
			array (
				'name'=>$dictionary['sort'],
				'contents'=>
				array (
					array('href'=> 'BookmarkController.php?action=sort&order=DESC&field=when_visited',
						'name' => $dictionary['last_visited']),
					array('href'=> 'BookmarkController.php?action=sort&order=DESC&field=visitCount',
						'name' => $dictionary['most_visited']),
					array('href'=> 'BookmarkController.php?action=sort&order=DESC&field=when_created',
						'name' => $dictionary['last_created']),
					array('href'=> 'BookmarkController.php?action=sort&order=DESC&field=when_modified',
						'name' => $dictionary['last_modified'])
				)
			)
			/*
			array (
				'name'=> 'Help',
				'contents' =>
				array (
					array('href' => '',
						'name' => $dictionary['bookmark_help'])
				)
			),
			*/
		);
		return $actions;
	}

	/**
	 * Activate. Basically this means that the appropriate actions are executed and an optional result is returned
	 * to be processed/displayed
	 */
	function activate ()
	{
		switch ($this->getAction ())
		{
			case "add":
				$this->addAction ();
				break;
			case "addBookmark":
				$this->addItemAction ();
				break;
			case "modify":
				$this->modifyAction ();
				break;
			case "modifyBookmark":
				$this->modifyItemAction ();
				$this->getShowItemsParameters ();
				break;
			case "move":
				$this->moveAction ();
				break;
			case "moveItem":
				$this->moveItemAction ();
				$this->getShowItemsParameters ();
				break;
			case "import":
			case "export":
			case "search":
				$this->renderer = $this->getAction ().'Bookmarks';
				break;
			case "searchBookmarks":
				$this->searchItemAction ();
				break;
			case "deleteBookmark":
				$this->deleteItemAction ();
				$this->getShowItemsParameters ();
				break;
			case "quickMark":
				// Stupid... I accidentally changed the name which resulted 
				// in the quickmark no longer working.... Just added the old name
				// so people who already used it do not have to modify their 
				// quickmark. This will be removed once preferences are implemented
			case "quickmark":
				$bookmark = new Bookmark (null, $_SESSION['username'], 0, false,
					$_GET['name'], null, 'private', null, null, null, null,
					$_GET['locator'], 0);
				$this->itemId = $this->operations->addItem ($_SESSION['username'], $bookmark);
				$this->getShowItemsParameters ();
				break;
			case "showBookmark":
				$this->operations->updateVisiteCount ($_SESSION['username'], $this->itemId);
				$bookmark = $this->operations->getItem
					($_SESSION['username'], $this->itemId);
				header ("Location: " . $bookmark->locator);
   				exit;
				break;
			case "importBookmarks":
				$bookmarkUtils = new BookmarkUtils ();
				// first set the execution time to zero: unlimited.
				// Not that this has no effect if safe_mode is on
				set_time_limit (0);

		        $importType=$_POST['importType'];
		   		$importFile = $_FILES['importFile'];
		   		if ($importType == 'Opera')
		        {
		                $bookmarkUtils->importOperaBookmarks
		                	($_SESSION['username'], $importFile['tmp_name'], $this);
		        }
				else if ($importType == 'Netscape')
				{
		                $bookmarkUtils->importNetscapeBookmarks
		                	($_SESSION['username'], $importFile['tmp_name'], $this);
				}
		        else
		        {
		                die ($importType . " is not yet supported for importing bookmarks");
		        }
		        $this->getShowItemsParameters ();
		        // We need to force a redirection to this page, otherwise a reload means
		        // resending the POST data and your items will be imported twice
		        header ("Location: BookmarkController.php");
		        exit ();
				break;
			case "exportBookmarks":
				$bookmarkUtils = new BookmarkUtils ();
			    $exportType=$_POST['exportType'];
			    if ($exportType == 'Opera')
				{
					Header ("Content-type: text/plain");
					echo ("Opera Hotlist version 2.0\n\n");

					$bookmarkUtils->exportOperaBookmarks
						($_SESSION['username'], 0, $this);
					// Hmm... die here seems like a bit too rigourous action.
					// TBD FIXME CHANGE BARRY
					exit ();
				}
				else if ($exportType == 'Netscape')
				{
					Header ("Content-type: text/plain");
					$bookmarkUtils->exportNetscapeBookmarks
						($_SESSION['username'], 0, $this);
					exit ();
				}
				/*
				else if ($exportType == 'HTML')
				{
					Header ("Content-type: text/html");
					$bookmarkUtils->exportItemsToHTML
						($_SESSION['username'], 0, $this);
					die ();
				}
				else if ($exportType == 'CSV')
				{
					Header ("Content-type: text/plain");
					$bookmarkUtils->exportItemsToCSV
						($_SESSION['username'], 0, $this);
					die ();
				}
				*/
				else
				{
			    	die ($exportType . " is not yet supported for exporting bookmarks");
			    }
				break;
			case "setYahooTree":
				$_SESSION['bookmarkTree']='Yahoo';
				$this->getShowItemsParameters ();
				break;
			case "setExplorerTree":
				$_SESSION['bookmarkTree']='Explorer';
				$this->getShowItemsParameters ();
				break;
			case "sort":
				$field = $_GET['field'];
				$order = $_GET['order'];
				$this->sortAction ($field, $order);
				//$this->getShowItemsParameters ();
				break;
			default:
				$this->getShowItemsParameters ();
				break;
		}
	}

	/**
	 * Returns the list of current expanded items for the controller
	 *
	 * @return string list of commanseperated item numbers
	 */
	function getExpanded ()
	{
		$expand=0;
		if (isset ($_GET['expand']))
		{
			$expand = $_GET['expand'];
			$_SESSION['bookmarkExpand']=$expand;
		}
		else if (isset ($_SESSION['bookmarkExpand']))
		{
			$expand = $_SESSION['bookmarkExpand'];
		}
		return $expand;
	}
}
error_reporting(E_ERROR);
$controller = new BookmarkController ($renderEngineName);
$controller -> activate ();
$controller -> display ();
?>
