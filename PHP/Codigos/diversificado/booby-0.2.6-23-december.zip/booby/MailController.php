<?php
/*
 * This file is part of the Booby project.
 * The booby project is located at the following location:
 * http://www.nauta.be/booby/
 *
 * Copyright (c) 2003 Barry Nauta
 *
 * The Booby project is release under the General Public License
 * More detailes in the file 'gpl.html' or on the following
 * website: http://www.gnu.org and look for licenses
 *
 * Enjoy :-)
 */
require_once ('Controller.php');
require_once ('model/MailServices.php');
require_once ('model/MailFactory.php');


/**
 * The Mail Controller
 *
 * @author Barry Nauta
 * @date November 2003
 * @package be.nauta.booby.controller
 * @copyright
 *
 * Copyright (c) 2003 Barry Nauta <br />
 *
 * The Booby project is released under the General Public License
 * More detailes on the following
 * website: <a href="http://www.gnu.org">www.gnu.org</a>
 * and look for licenses
 */
class MailController extends Controller
{
	/**
	 * Constructor. Makes sure that the appropriate operations are instantiated.
	 */
	function MailController ()
	{
		parent::Controller ();
		$this->operations = new MailServices ();
		$this->itemFactory = new MailFactory ();
	}

	/**
	 * Returns the title of this Controller
	 *
	 * @return string the title of this controller
	 */
	function getTitle ()
	{
		return "Booby - Mail";
	}

	/**
	 * Returns the name of the item that is controller by this controller
	 *
	 * @return string the name of the item that is controlled by this controller
	 */
	function getItemName ()
	{
		return "Mail";
	}

	/**
 	 * Returns the actions defined for this item only
 	 *
 	 * @return array an array of item specific actions (like search, import etc.)
 	 */
	function getActions ()
	{
		global $dictionary;
		$actions=array(
			array (
				'name'=>$dictionary['actions'],
				'contents'=>
				array (
					array('href' => 'MailController.php?action=add&parentId='.$this->getParentId (),
						'name' => $dictionary['add']),
					array('href' => 'MailController.php?action=search',
						'name' => $dictionary['search'])
					)
				),
			array (
				'name'=>$dictionary['view'],
				'contents'=>
				array (
					array('href' => 'MailController.php?expand=*',
						'name' => $dictionary['expand']),
					array('href' => 'MailController.php?expand=0',
						'name' => $dictionary['collapse']),
					array('href' => 'MailController.php?action=setYahooTree',
						'name' => $dictionary['yahooTree']),
					array('href' => 'MailController.php?action=setExplorerTree',
						'name' => $dictionary['explorerTree'])
				)
			)
		);
		return $actions;
	}

	/**
	 * Activate. Basically this means that the appropriate actions are executed and an optional result is returned
	 * to be processed/displayed
	 */
	function activate ()
	{
		switch ($this->getAction ())
		{
			case "add":
				$this->addAction ();
				break;
			case "addItem":
				$this->addItemAction ();
				break;
			case "modify":
				$this->modifyAction ();
				break;
			case "modifyItem":
				$this->modifyItemAction ();
				$this->getShowItemsParameters ();
				break;
			case "move":
				$this->moveAction ();
				break;
			case "moveItem":
				$this->moveItemAction ();
				$this->getShowItemsParameters ();
				break;
			case "search":
				$this->renderer = $this->getAction ().'Mail.tpl';
				break;
			case "searchItems":
				$this->searchItemAction ();
				break;
			case "deleteItem":
				$this->deleteItemAction ();
				$this->getShowItemsParameters ();
				break;
			case "showItem":
				$this->operations->updateVisiteCount ($_SESSION['username'], $this->itemId);
				$bookmark = $this->operations->getItem
					($_SESSION['username'], $this->itemId);
				header ("Location: " . $bookmark->locator);
   				exit;
				break;
			case "setYahooTree":
				$_SESSION['newsTree']='Yahoo';
				$this->getShowItemsParameters ();
				break;
			case "setExplorerTree":
				$_SESSION['newsTree']='Explorer';
				$this->getShowItemsParameters ();
				break;
			default:
				$this->operations->retrieveMessages ();
				//$this->getShowItemsParameters ();
				die ();
				break;
		}
	}

		/**
	 * Returns the list of current expanded items for the controller
	 *
	 * @return string list of commanseperated item numbers
	 */
	function getExpanded ()
	{
		$expand=0;
		if (isset ($_GET['expand']))
		{
			$expand = $_GET['expand'];
			$_SESSION['newsExpand']=$expand;
		}
		else if (isset ($_SESSION['newsExpand']))
		{
			$expand = $_SESSION['newsExpand'];
		}
		return $expand;
	}
}
error_reporting(E_ERROR);
$controller = new MailController ();
$controller -> activate ();
$controller -> display ();
?>
