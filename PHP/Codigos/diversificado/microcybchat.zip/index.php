<?
/* Microcyb - Chat - Readme
===================

  A PHP/MySQL chat communications script.

  Version 0.95 07/13/2002 */
// ------------------------------------------------------------------------

if (empty($action))
  ShowLoginForm();
elseif ($action == "posts")
  ShowAddPosts();
elseif ($action == "users")
  showusers();
elseif ($action == "form")
  GetInput();
elseif ($action == "logo")
  showlogo();
elseif ($action == "enter")
  Login();

function ShowLoginForm() {
$time = date ("h:i:s A");

  ?>

        <b>Enter Your Nickname/Alias</b>
        <form name="chat" method="post" action="index.php" target="_top">
          <input type="text" name="nick" size="8" MAXLENGTH=9>
          <input type="hidden" name="action" value="enter">
          <input type="hidden" name="chat" value="Enters the Room @ <?php echo $time; ?>">
          <input type="submit" name="Submit" value="Submit">
        <script language="JavaScript">
         document.chat.nick.focus();
         </script>
        </form>

  <?php

}

function Login() {

        global $HTTP_SESSION_VARS;
        global $chat;
        global $nick;

        session_start();
        session_register("nick", $nick);
        if ($skin=="") {
        setCookie ("skin","yellow.css", time()+30240000);}
  ?>
           
        <frameset rows="*,70" cols="*,115"  >

          <frame name="posts" src="index.php?action=posts&nick=<?php echo $nick; ?>&chat=<?php echo $chat; ?>" scrolling="auto" noresize frameborder="0" border="0">
          <frame name="user" src="index.php?action=users" scrolling="no" noresize" frameborder="0" border="0" >
          <frame name="form" src="index.php?action=form&nick=<?php echo $nick; ?>" scrolling="no" noresize" frameborder="0" border="0" >
          <frame name="logo" src="index.php?action=logo" scrolling="no" noresize" frameborder="0" border="0" >

        </frameset>
          <noframes>
          <body>

          <p>This page uses frames, but your browser doesn't support them.</p>

          </body>
          </noframes>
        </frameset>

  <?php
}

function GetInput() {

        global $HTTP_SESSION_VARS;
        global $chat;
        global $nick;
        global $skin;
        $skin = $_COOKIE["skin"]; // Recommended but requires PHP 4.1
        $activedir = "./style/";
        @chdir($activedir);
  if ($skin=="") {
  print '<link rel="stylesheet" href="./style/yellow.css" type="text/css">';}
  else { ?> <link rel="stylesheet" href="<? echo $activedir.$skin; ?>" type="text/css"><?
  }
  ?>
  <body topmargin="0" leftmargin="0" marginwidth="0" marginheight="0">
        <form onSubmit="return doSubmit" name="chatform" method="post" action="index.php" target="posts" >

 <table border="0" cellpadding="1" >
 <tr>
 <td valign="top" class="avatars">

          <a href onClick="sendFace(1)"><img src="./img/smile.gif"</a>
          <a href onClick="sendFace(2)"><img src="./img/frown.gif"</a>
          <a href onClick="sendFace(3)"><img src="./img/bigsmile.gif"</a>
          <a href onClick="sendFace(4)"><img src="./img/angry.gif"</a>
          <a href onClick="sendFace(5)"><img src="./img/cool.gif"</a>
          <a href onClick="sendFace(6)"><img src="./img/tongue.gif"</a>
          <a href onClick="sendFace(7)"><img src="./img/huh.gif"</a>
          <a href onClick="sendFace(8)"><img src="./img/rolleyes.gif"</a>
          <a href onClick="sendFace(9)"><img src="./img/embarassed.gif"</a>
          <a href onClick="sendFace(10)"><img src="./img/lipsrsealed.gif"</a>
          <a href onClick="sendFace(11)"><img src="./img/kiss.gif"</a>
          <a href onClick="sendFace(12)"><img src="./img/cry.gif"</a>
          <a href onClick="sendFace(13)"><img src="./img/undecided.gif"</a>
          <a href onClick="sendFace(14)"><img src="./img/wink.gif"</a>
 </td><td valign="top" >
<select name="skin" style="font: 9.9px verdana; color: #000000; width=80px;" onChange="makecookie();">
<option>Select Skin</option>
<?

        $handle=opendir('.');
                while ($file = readdir($handle)) {
                        if(is_file($file)) {
                                $filelist[] = $file; 
                        }
                }
                closedir($handle);

                asort($filelist);
                while (list ($key, $file) = each($filelist)) {
                        ereg(".gif | .jpg",$file); 
                                if ($file != "." && $file != ".." && (!is_dir($file))) {
                                        echo "<option value=\"".$file."\">".$file."</option>";
                                }
                }
                echo '</select>';

?>
</td></tr>
 <tr>
  <td valign="top">

          <input type="text" name="chat" size="35" MAXLENGTH=200 onkeypress="if (event.keyCode==13) setTimeout('document.chatform.chat.value=\'\'',20);">

          <input type="hidden" name="nick"  value="<?php echo $nick; ?>">
          <a href="javascript:void(doSubmit())"
        onMouseover="document.images['send'].src='./img/send2.gif'"
        onMouseout ="document.images['send'].src='./img/send1.gif'">
  <img src="./img/send1.gif" name="send" border=0 align="top"></a>
</td>
</tr></td>

          <input type="hidden" name="action" value="posts">
<script language="JavaScript">
document.chatform.chat.focus();
</script>
        </form>
</table>
      <script language="JavaScript">

function makecookie() {
var expireDate = new Date
expireDate.setMonth(expireDate.getMonth()+6)
document.cookie = "skin=" + document.chatform.skin.value + "; expires=" + expireDate.toGMTString()
parent.frames[1].document.location='index.php?action=users'
parent.frames[3].document.location='index.php?action=logo'
parent.frames[0].document.location='index.php?action=posts'
parent.frames[2].document.location='index.php?action=form&nick=<?php echo $nick; ?>'
document.chatform.chat.focus();
}


          function sendFace(faceNum)
          {
            switch(faceNum)
            {
              case 1:
                document.chatform.chat.value = document.chatform.chat.value + ' :) ';
                break;
              case 2:
                document.chatform.chat.value = document.chatform.chat.value + ' :( ';
                break;
              case 3:
                document.chatform.chat.value = document.chatform.chat.value + ' :D ';
                break;
              case 4:
                document.chatform.chat.value = document.chatform.chat.value + ' >( ';
                break;
              case 5:
                document.chatform.chat.value = document.chatform.chat.value + ' 8) ';
                break;
              case 6:
                document.chatform.chat.value = document.chatform.chat.value + ' :P ';
                break;
              case 7:
                document.chatform.chat.value = document.chatform.chat.value + ' ??? ';
                break;
              case 8:
                document.chatform.chat.value = document.chatform.chat.value + ' ::) ';
                break;
              case 9:
                document.chatform.chat.value = document.chatform.chat.value + ' :-[ ';
                break;
              case 10:
                document.chatform.chat.value = document.chatform.chat.value + ' :-X ';
                break;
               case 11:
                document.chatform.chat.value = document.chatform.chat.value + ' :-* ';
                break;
              case 12:
                document.chatform.chat.value = document.chatform.chat.value + ' :\'( ';
                break;
              case 13:
                document.chatform.chat.value = document.chatform.chat.value + ' :-\\\ ';
                break;
              case 14:
                document.chatform.chat.value = document.chatform.chat.value + ' ;) ';
                break;
            }
          document.chatform.chat.focus();

          }

        function doSubmit()
        {
          if(document.chatform.chat.value == '') {
            alert('Please enter some text!');
            document.chatform.chat.focus();
            return false;
          }

               document.chatform.chat.value = document.chatform.chat.value;
          document.chatform.submit();
          document.chatform.chat.value = '';
          document.chatform.chat.focus();
          return true;
        }
        </script>
  <?php
}

function showlogo() {

        global $HTTP_SESSION_VARS;
        global $skin;
        $activedir = "./style/";
        @chdir($activedir);

  if ($skin=="") {
  print '<link rel="stylesheet" href="./style/yellow.css" type="text/css">';}
  else { ?> <link rel="stylesheet" href="<? echo $activedir.$skin; ?>" type="text/css"><?
  }
  ?>
  <body topmargin="0" leftmargin="0" marginwidth="0" marginheight="0">
  <a href="http://www.microcyb.com/chat"><b>Microcyb Chat V.0.95</b></a><br>
  <small><a href="http://www.microcyb.com/chat/count.php"><b>Download Chat</b></a></small>
  <?
  }
function ShowAddPosts() {

        global $HTTP_SESSION_VARS;
        global $chat;
        global $nick;
        global $timeoutseconds;
        global $timestamp;
        global $timeout;
        global $skin;
        $activedir = "./style/";
        @chdir($activedir);
        $timeoutseconds         = 250;                        // Timeout value in seconds
        $timestamp=time();
        $timeout=$timestamp-$timeoutseconds;  

        print '<meta http-equiv="refresh" content="10;URL=index.php?action=posts&nick=<?php echo $nick; ?>">';

        echo '<body topmargin="0" leftmargin="0" marginwidth="0" marginheight="0">';

  if ($skin=="") {
  print '<link rel="stylesheet" href="./style/yellow.css" type="text/css">';}
  else { ?> <link rel="stylesheet" href="<? echo $activedir.$skin; ?>" type="text/css"><?
  }

        include ("config.php");
        $svrConn = mysql_connect("$host", "$user", "$pass") or die("<b>Error:</b> Couldnt connect to database");
        $dbConn = mysql_select_db("$base", $svrConn) or die ("<b>Error:</b> Couldnt connect to database");
        $chat = strip_tags($chat,'<i><b><a>');

        
        if(!empty($chat)) {
                
                $strQuery = "insert into chatScript values(0, '$chat','$nick','$timestamp')";
                mysql_query($strQuery);
        } 

        $strQuery = ("DELETE FROM chatScript WHERE timestamp<$timeout") or die("$useronline $base DELETE Error");
         mysql_query($strQuery);

        $strQuery = "select theText, theNick from chatScript order by pk_Id asc";
        $chats = mysql_query($strQuery);
           echo '<table border="0" width="100%" height="100%" cellpadding="1">
           <tr><td  valign="top" align="left" width="80%" height="100%" class="chattext">';
          
        while($chatline = mysql_fetch_array($chats)) {
           print "<font size=\"2\"><b>" . $chatline["theNick"] . ":</b> " . swapFaces($chatline["theText"]) . "</b></i></font><br>";
        }
        echo '</td></tr></table>';
        ?>
        <script language="JavaScript">
        scroll(10,600)
        </script>
<?
}

function showusers() {
        global $HTTP_SESSION_VARS;
        global $nick;
        global $skin;
        $activedir = "./style/";
        @chdir($activedir);
        print '<meta http-equiv="refresh" content="15;URL=index.php?action=users">';
        echo '<body topmargin="0" leftmargin="0" marginwidth="0" marginheight="0">';
  if ($skin=="") {
  print '<link rel="stylesheet" href="./style/yellow.css" type="text/css">';}
  else { ?> <link rel="stylesheet" href="<? echo $activedir.$skin; ?>" type="text/css"><?
  }


        echo '<table border="0" width="100%" height="100%" cellpadding="1" >
           <tr>';
          
        echo '<td nowrap valign="top" align="left" width="20%" height="100%" class="online"><b>Users Online:</b><br>';
        include ("config.php");
        $svrConn = mysql_connect("$host", "$user", "$pass") or die("<b>Error:</b> Couldnt connect to database");
        $dbConn = mysql_select_db("$base", $svrConn) or die ("<b>Error:</b> Couldnt connect to database");
        $nicks = array();
        $strQuery = "select theNick from chatScript order by theNick asc";
        $chats = mysql_query($strQuery);
        while($chatline = mysql_fetch_array($chats)) {
                        if (!in_array($chatline['theNick'],$nicks)) {
                                $nicks[] = $chatline['theNick'];
                                print "" . $chatline["theNick"] . "<br>";
                        }

        }
      echo '</td></tr></table>';

     }


function swapFaces($chatLine) {

  $chatLine = str_replace("::)", "<img src='./img/rolleyes.gif'>", $chatLine);
  $chatLine = str_replace(":)", "<img src='./img/smile.gif'>", $chatLine);
  $chatLine = str_replace(":(", "<img src='./img/frown.gif'>", $chatLine);
  $chatLine = str_replace(":D", "<img src='./img/bigsmile.gif'>", $chatLine);
  $chatLine = str_replace(">(", "<img src='./img/angry.gif'>", $chatLine);
  $chatLine = str_replace("8)", "<img src='./img/cool.gif'>", $chatLine);
  $chatLine = str_replace(":P", "<img src='./img/tongue.gif'>", $chatLine);
  $chatLine = str_replace("???", "<img src='./img/huh.gif'>", $chatLine);
  $chatLine = str_replace(":-[", "<img src='./img/embarassed.gif'>", $chatLine);
  $chatLine = str_replace(":-X", "<img src='./img/lipsrsealed.gif'>", $chatLine);
  $chatLine = str_replace(':-\\', '<img src=\'./img/undecided.gif\'>', $chatLine);
  $chatLine = str_replace(":-*", "<img src='./img/kiss.gif'>", $chatLine);
  $chatLine = str_replace(":'(", "<img src='./img/cry.gif'>", $chatLine);
  $chatLine = str_replace(";)", "<img src='./img/wink.gif'>", $chatLine);
  return $chatLine;
}

?>
