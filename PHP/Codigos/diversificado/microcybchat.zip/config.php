<?php
/* Microcyb - Chat - Readme
===================

  A PHP/MySQL chat communications script.

  Version 0.95 07/13/2002 */

  // The following must be set in order to operate.
$host = "localhost"; // MySQL hostname
$user = "admin";     // MySQL user
$pass = "password";  // MySQL password
$base = "db_name";  // MySQL database name
?>

