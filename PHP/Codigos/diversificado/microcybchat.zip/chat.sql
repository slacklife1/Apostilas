# phpMyAdmin MySQL-Dump
# version 2.2.4
# http://phpwizard.net/phpMyAdmin/
# http://phpmyadmin.sourceforge.net/ (download page)
#
# Host: localhost
# Generation Time: Jun 13, 2002 at 10:10 AM
# Server version: 3.23.48
# PHP Version: 4.1.2
# Database : `microcyb_shout`
# --------------------------------------------------------

#
# Table structure for table `chatScript`
#

CREATE TABLE chatScript (
  pk_Id int(10) unsigned NOT NULL auto_increment,
  theText varchar(100) NOT NULL default '',
  theNick varchar(20) NOT NULL default '',
  timestamp int(15) NOT NULL default '0',
  PRIMARY KEY  (pk_Id),
  UNIQUE KEY id (pk_Id)
) TYPE=MyISAM;

