//       Mps Banner V1.0 - Script Freeware
//     By: Marcelo Santos Designer - mps3001@superig.com.br
//    http://www.peguei.net
//   Este � um script gratuito, n�o me responsabilizo por danos causados em seu servidor.
//  Este script pode ser modificado, desde que se mantenha a Copyright.




Version Histroy:
1.0 - 1� vers�o do MPS Banner. Suporta qualquer tipo de banner


Instala��o:

Abra mpsbanner_inc.php e modifique corretamente as vari�veis indicadas.

Envie todos os arquivos para o diret�rio "banner" e abra o arquivo mpsbanner_install.php. Clique em "Clique aqui para instalar o MPS Banner V1.0" para inst�la-lo. Se voc� receber uma mensagem de congratula��o,
delete o mpsbanner_install.php do seu servidor e abra o mpsbanner_admin.php para editar o seu sistema de banners.

� s� isso. Se aparecer mensagem de erro, voc� ter� que trabalhar


Para inclu�-lo em arquivos .html .htm .shtml .asp use:
<!--#include virtual="/banner/banner.php"-->
Mude o path do banner.php dependendo do diret�rio em seu servidor.

Para inclu�-lo em outro arquivo PHP:
<? include "/banner/banner.php" ?>



Atenciosamente 

Marcelo Santos
