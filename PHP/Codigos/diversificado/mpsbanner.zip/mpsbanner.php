<?php

//Mps Banner V1.0 - Script Freeware
//By: Marcelo Santos Designer - mps3001@superig.com.br
//http://www.peguei.net
//Este � um script gratuito, n�o me responsabilizo por danos causados em seu servidor.
//Este script pode ser modificado, desde que se mantenha a Copyright.

//Include file - S� mexa aqui se voc� mudou o nome e/ou diret�rio do arquivo
require "mpsbanner_inc.php";

//N�o precisa editar ap�s essa linha//

  /*Declarando vari�veis*/
$pagename = "$PHP_SELF"; #This Page's Name - Don't modify.

/* N�o mexa ap�s essa linha! */
/* fazendo conex�o com o banco de dados */
MYSQL_CONNECT($hostname, $username, $password) OR DIE("N�o foi possivel conectar ao MySQL");
@mysql_select_db( "$dbName") or die( "N�o foi possivel selecionar o Banco de Dados");

//Pegando n� do banner no banco de dados
$query = "SELECT * FROM $table";
$result = MYSQL_QUERY($query);
$number = MYSQL_NUMROWS($result);

//Pegando um n�mero autom�tico
  //N� SQL inicia no 0
  if($number == 0):
  print "N�o Existe Banner Cadastrado no Sistema";
  exit();
  elseif($number == 1):
  $randomnumber = 0;
  else:
  --$number;
  srand((double)microtime()*1000000);
  $randomnumber = rand(0,$number);
  endif;

//Pegando detalhes para inserir no banco de dados
$id                = mysql_result($result,$randomnumber,"id");
$image_url        = mysql_result($result,$randomnumber,"image_url");
$url                = mysql_result($result,$randomnumber,"url");
$zone                = mysql_result($result,$randomnumber,"zone");
$displays_life        = mysql_result($result,$randomnumber,"displays_life");
$displays_day        = mysql_result($result,$randomnumber,"displays_day");
$dat_type        = mysql_result($result,$randomnumber,"dat_type");
$html                = mysql_result($result,$randomnumber,"html");

 //Criando Script HTML
 print "<!-- �nicio do sistema de banners Mps Banner .  by Marcelo Santos �http://www.peguei.net -->";

if($dat_type == 'image'):
 print "<a href=\"$redirect?$id\"><img src=\"$image_url\" border=\"0\"></a>";
elseif($dat_type == 'html'):
 print "$html";
else:
 print "<a href=\"$redirect?$id\"><img src=\"$image_url\" border=\"0\"></a>";
endif;
 print "<!-- Fim do script -->";

 //Gravando Click.
++$displays_life;
++$displays_day;

 //Atualizando Banco de dados
$update_query = "UPDATE $table SET displays_life = '$displays_life' WHERE id = '$id'";
$update_result = MYSQL_QUERY($update_query);
$update_query = "UPDATE $table SET displays_day = '$displays_day' WHERE id = '$id'";
$update_result = MYSQL_QUERY($update_query);

MYSQL_CLOSE();
?>