<?php

//Mps Banner V1.0 - Script Freeware
//By: Marcelo Santos Designer - mps3001@superig.com.br
//http://www.peguei.net
//Este � um script gratuito, n�o me responsabilizo por danos causados em seu servidor.
//Este script pode ser modificado, desde que se mantenha a Copyright.

//Include file - S� mexa aqui se voc� mudou o nome e/ou diret�rio do arquivo
require "mpsbanner_inc.php";

//N�o precisa editar ap�s essa linha//

  /*Declarando Vari�veis*/
$pagename = $PHP_SELF; #Este � o nome da p�gina - n�o modifique.
$qstring=split("&", $QUERY_STRING);
$action=$qstring[0];
$ad_id=$qstring[1];

/* N�o modifique depois dessa linha! */
/* Fazendo conex�o com o banco de dados */
MYSQL_CONNECT($hostname, $username, $password) OR DIE("N�o foi possivel conectar ao MySQL");
@mysql_select_db("$dbName") or die("N�o foi Possivel selecionar o MySQL");

if($action == add):

head();
?>

        <b>Adicionar Banner (Standard)</b>
        <form action="<? echo $pagename ?>?do_add" method=POST>
        Local do Banner:<br><input type="text" name="image" size="60"><br>
        Link:<br><input type="text" name="link" size="60"><br>
        Tipo (Opcional):<br><input type="text" name="zone"><br>
        Senha:<br><input type="password" name="admin_password"><br>
        <input type="hidden" name="dat_type" value="image">
        <input type="submit" value="Adicionar Banner">
        </form>
        <br>
        OU<br><br>
        <b>Inserir c�digo HTML para adicionar banner</b><br>
        <form action="<? echo $pagename ?>?do_add" method=POST>
        <textarea name="html_input" rows="10" cols="80"></textarea><br>
        Tipo (Opicional):<br><input type="text" name="zone"><br>
        Senha:<br><input type="password" name="admin_password"><br>
        <input type="hidden" name="dat_type" value="html">
        <input type="submit" value="Adicionar Banner">
        </form>

<?php
foot();

elseif($action == do_add):
 //Check the Password
  if($admin_password != $admin_pass):
  bad_pass();
  endif;

  head();

  if($dat_type == 'image'):
     $query = "INSERT INTO $table (zone,url,image_url,dat_type) VALUES ('$zone', '$link', '$image', '$dat_type')";
     $result = MYSQL_QUERY($query);
  print "Banner Adicionado com sucesso";
  elseif($dat_type == 'html'):
     $query = "INSERT INTO $table (zone, url, html, dat_type) VALUES ('$zone', 'NULL', '$html_input', '$dat_type')";
     $result = MYSQL_QUERY($query);
  print "Banner Adicionado com sucesso";
  else:
  print "Erro, senha inv�lida";
  endif;
  foot();

elseif($action == modify):
head();

//Pegando n� do banner no banco de dados
$query = "SELECT * FROM $table";
$result = MYSQL_QUERY($query);
$number = MYSQL_NUMROWS($result);
$i=0;

print "<center>(Clique em \"modificar\" para modificar o banner)<br>";

WHILE ($i < $number):

    //Pegando detalhes para incluir registros
    $id                = mysql_result($result,$i,"id");
    $image_url        = mysql_result($result,$i,"image_url");
    $url        = mysql_result($result,$i,"url");
    $dat_type        = mysql_result($result,$i,"dat_type");
    $html        = mysql_result($result,$i,"html");

    if($dat_type == 'image'):
    print "<img src=\"$image_url\" border=\"0\">\n<br><a href=\"$pagename?mod_id&$id\">Modify</a><br>";
    elseif($dat_type == 'html'):
    print "$html<br><a href=\"$pagename?mod_id&$id\">Modificar</a><br>";
    else:
    print "<img src=\"$image_url\" border=\"0\">\n<br><a href=\"$pagename?mod_id&$id\">Modify</a><br>";
    endif;

    $i++;
ENDWHILE;
print "</center>";
foot();

elseif($action == mod_id):
$query = "SELECT * FROM $table WHERE id = '$ad_id'";
$result = MYSQL_QUERY($query);

    //Pegando detalhes para incluir registros
    $id                = mysql_result($result,0,"id");
    $zone        = mysql_result($result,0,"zone");
    $image_url        = mysql_result($result,0,"image_url");
    $url        = mysql_result($result,0,"url");
    $dat_type        = mysql_result($result,0,"dat_type");
    $html        = mysql_result($result,0,"html");

head();
    if($dat_type == 'image'):
?>
<b>Modificar</b>
<form action="<? echo $pagename ?>?do_modify" method=POST>
Local do banner:<br><input type="text" name="image" size="60" value="<? echo $image_url ?>"><br>
Link:<br><input type="text" name="link" size="60" value="<? echo $url ?>"><br>
Tipo (Opicional):<br><input type="text" name="zone" value="<? echo $zone ?>"><br>
Senha:<br><input type="password" name="admin_password"><br>
<input type="hidden" name="dat_type" value="image">
<input type="hidden" name="mod_id" value="<? echo $id ?>">
<input type="submit" value="Modificar Banner">
</form>
<?php
    elseif($dat_type == 'html'):
?>
        <form action="<? echo $pagename ?>?do_add" method=POST>
        <textarea name="html_input" rows="10" cols="80"><? echo $html ?></textarea><br>
        Tipo (Opicional:<br><input type="text" name="zone" value="<? echo $zone ?>"><br>
        Senha:<br><input type="password" name="admin_password"><br>
        <input type="hidden" name="mod_id" value="<? echo $id ?>">
        <input type="hidden" name="dat_type" value="html">
        <input type="submit" value="Adicionar Banner">
        </form>
<?php
    else:
?>
<form action="<? echo $pagename ?>?do_modify" method=POST>
Local do Banner:<br><input type="text" name="image" size="60" value="<? echo $image_url ?>"><br>
Link:<br><input type="text" name="link" size="60" value="<? echo $url ?>"><br>
Tipo (Opicional):<br><input type="text" name="zone" value="<? echo $zone ?>"><br>
Senha:<br><input type="password" name="admin_password"><br>
<input type="hidden" name="dat_type" value="image">
<input type="hidden" name="mod_id" value="<? echo $id ?>">
<input type="submit" value="Modificar Banner">
</form>

<?php
endif;
foot();

elseif($action == do_modify):
 //Checando senha
  if($admin_password != $admin_pass):
  bad_pass();
  endif;

  if($dat_type == 'image'):
   $update_query = "UPDATE $table SET zone = '$zone' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET image_url = '$image' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET url = '$link' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);

  elseif($dat_type == 'html'):
   $update_query = "UPDATE $table SET zone = '$zone' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET html = '$html' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);

  else:
   $update_query = "UPDATE $table SET zone = '$zone' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET image_url = '$image' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET url = '$link' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
  endif;

   head();
   print "Updated";
   foot();

elseif($action == delete):
head();

//Pegando n� do banner no banco de dados
$query = "SELECT * FROM $table";
$result = MYSQL_QUERY($query);
$number = MYSQL_NUMROWS($result);
$i=0;

print "<center>(Configurar banner para serem deletados)<br>";
print "<form action=\"$pagename?do_del\" method=POST>";

WHILE ($i < $number):

    //Get the details for that entry
    $id                = mysql_result($result,$i,"id");
    $image_url        = mysql_result($result,$i,"image_url");
    $url        = mysql_result($result,$i,"url");
    $dat_type        = mysql_result($result,$i,"dat_type");
    $html        = mysql_result($result,$i,"html");

  if($dat_type == 'image'):
    print "<img src=\"$image_url\" border=\"0\"><br>\n<input type=\"checkbox\" name=\"del_id[]\" value=\"$id\"><br>\n";
  elseif($dat_type == 'html'):
    print "$html<br>\n<input type=\"checkbox\" name=\"del_id[]\" value=\"$id\"><br>\n";
  else:
    print "<img src=\"$image_url\" border=\"0\"><br>\n<input type=\"checkbox\" name=\"del_id[]\" value=\"$id\"><br>\n";
  endif;

    $i++;
ENDWHILE;
print "<hr width=\"100\">Senha:<br><input type=\"password\" name=\"admin_password\"><br>";
print "<input type=\"submit\" value=\"Deletar banner selecionado\">\n";
print "</form>\n";
print "</center>\n";

foot();

elseif($action == do_del):
 //Check the Password
  if($admin_password != $admin_pass):
  bad_pass();
  endif;

//Remover banner
 head();
 for($i=0; $i < count($del_id); $i++)
 {
  $query = "DELETE FROM $table WHERE id = '$del_id[$i]'";
  $exec = MYSQL_QUERY($query);

  if($exec == 1):
   print "Banner deletado: $del_id[$i]<br>\n";
  else:
   print "Error: $del_id[$i] didn't delete properly<br>\n";
  endif;
 }

  print "\n<br>Delete Complete";
  foot();

elseif($action == stats):
head();
$font="<font face=\"Arial\" size=\"2\">";
?>
        <TABLE BORDER=1 CELLSPACING=1 CELLPADDING=0 WIDTH="95%">
        <TR ALIGN="left" VALIGN="top">
                <TH><? echo $font ?> Site (Tipo)</TH>
                    <TH><? echo $font ?> Exibidos - ao todo</TH>
                    <TH><? echo $font ?> Exibidos - hoje</TH>
                    <TH><? echo $font ?> Clicks - ao todo</TH>
                    <TH><? echo $font ?> Clicks - hoje</TH>
        </tr>
<?

$query = "SELECT * FROM $table";
$result = MYSQL_QUERY($query);
$number = MYSQL_NUMROWS($result);
$i=0;

WHILE ($i < $number):

//Pegando detalhes para incluir registros
$id                = mysql_result($result,$i,"id");
$image_url        = mysql_result($result,$i,"image_url");
$url                = mysql_result($result,$i,"url");
$zone                = mysql_result($result,$i,"zone");
$displays_life        = mysql_result($result,$i,"displays_life");
$displays_day        = mysql_result($result,$i,"displays_day");
$clicks_life        = mysql_result($result,$i,"clicks_life");
$clicks_day        = mysql_result($result,$i,"clicks_day");

          print "
          <TR ALIGN=\"left\" VALIGN=\"top\">
                    <TD>$font <a href=\"$url\" target=\"_blank\">$url</a> ($zone)</TD>
                    <TD>$font $displays_life</TD>
                    <TD>$font $displays_day</TD>
                    <TD>$font $clicks_life</TD>
                    <TD>$font $clicks_day</TD>
          </tr>";

            $tdisplays_life=$tdisplays_life+$displays_life;
            $tdisplays_day=$tdisplays_day+$displays_day;
            $tclicks_life=$tclicks_life+$clicks_life;
            $tclicks_day=$tclicks_day+$clicks_day;
    $i++;
ENDWHILE;
          print "
          <TR ALIGN=\"left\" VALIGN=\"top\">
                    <TD bgcolor=\"#000080\">$font Totals:</TD>
                    <TD bgcolor=\"#000080\">$font $tdisplays_life</TD>
                    <TD bgcolor=\"#000080\">$font $tdisplays_day</TD>
                    <TD bgcolor=\"#000080\">$font $tclicks_life</TD>
                    <TD bgcolor=\"#000080\">$font $tclicks_day</TD>
            </tr>";
         print "</TABLE>";

         foot();

elseif($action == clear_day):
head();
?>

<form action="<? echo $pagename ?>?do_clear_day" method=POST>
Senha:<br><input type="password" name="admin_password"><br>
<input type="submit" value="Limpar status">
</form>

<?php
foot();

elseif($action == do_clear_day):
 //Check the Password
  if($admin_password != $admin_pass):
  bad_pass();
  endif;
//Pegando n� do banner no banco de dados
$query = "SELECT * FROM $table";
$result = MYSQL_QUERY($query);
$number = MYSQL_NUMROWS($result);
$i=0;

WHILE ($i < $number):
    //Pegando detalhes para incluir registros
$id = mysql_result($result,$i,"id");
$update_query="UPDATE $table SET clicks_day = '0' WHERE id = '$id'";
$update_result=MYSQL_QUERY($update_query);
$update_query="UPDATE $table SET displays_day = '0' WHERE id = '$id'";
$update_result=MYSQL_QUERY($update_query);
    $i++;
ENDWHILE;

head();
print "Todas colunas de \"Hoje\" foram apagados.";
foot();

elseif($action == lframe):
?>
  <html>
  <head>
  <title>Left Frame</title>
  </head>
  <body bgcolor="#000066" text="#FFFFFF" link="#00CCFF" vlink="#00CCFF" alink="#00FFFF">
  <font face="Verdana,Arial" size="1">
<b>Op��es</b><br>
<a href="<? echo $pagename ?>?add" target="mainFrame">Adicionar banner</a><br>
<a href="<? echo $pagename ?>?modify" target="mainFrame">Modificar banner</a><br>
<a href="<? echo $pagename ?>?delete" target="mainFrame">Deletar Banner</a><br><br>
<a href="<? echo $pagename ?>?stats" target="mainFrame">Ver Status</a><br><br>
<a href="<? echo $pagename ?>?clear_day" target="mainFrame">Limpar colunas de hoje</a><br>
   </font>
  </body>
  </html>
<?php

elseif($action == rframe):
head();
?>
Bem vindo ao MPS Banner V1.0 by <a href="mailto:mps3001@superig.com.br">Marcelo Santos</a><br>
<br>
Por favor escolha uma op��o ao lado
<?php
foot();

else:
?>
  <html>
  <head>
  <title>MPS Banner V1.0 - Script Freeware</title>
  </head>
  <frameset cols="150,*" frameborder="no" border="0" framespacing="0">
    <frame name="leftFrame" scrolling="auto" noresize src="<? echo $pagename ?>?lframe">
    <frame name="mainFrame" src="<? echo $pagename ?>?rframe">
  </frameset>
  <noframes>
  <body>
      Esta p�gina usa quadros mas seu navegador n�o aceita quadros.
  </body>
  </noframe>
  </html>
<?php
endif;

MYSQL_CLOSE();
?>