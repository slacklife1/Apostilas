<?php

//Mps Banner V1.0 - Script Freeware
//By: Marcelo Santos Designer - mps3001@superig.com.br
//http://www.peguei.net
//Este � um script gratuito, n�o me responsabilizo por danos causados em seu servidor.
//Este script pode ser modificado, desde que se mantenha a Copyright.

//Include file - S� mexa aqui se voc� mudou o nome e/ou diret�rio do arquivo
require "mpsbanner_inc.php";

//N�o precisa editar ap�s essa linha//

$action=$QUERY_STRING;
$pagename=$PHP_SELF;

/* fazendo conex�o com o banco de dados */
MYSQL_CONNECT($hostname, $username, $password) OR DIE("Unable to connect to database");
@mysql_select_db("$dbName") or die( "Unable to select database");

head();
if($action == 'create_new'):
$create= "CREATE TABLE $table (id TINYINT not null AUTO_INCREMENT, zone VARCHAR (50) not null , image_url VARCHAR (200) not null , url VARCHAR (200) not null , displays_life VARCHAR (20) DEFAULT '0' not null , displays_day VARCHAR (20) DEFAULT '0' not null , clicks_life VARCHAR (20) DEFAULT '0' not null , clicks_day VARCHAR (20) DEFAULT '0' not null , dat_type VARCHAR (15) not null , html BLOB not null , PRIMARY KEY (id)) ";
$exec = MYSQL_QUERY($create);
 if($exec == 1):
 print "Tabela criado com sucesso, est� pronto o MPS Banner. Utilize o arquivo banner_admin.php para configurar o seu sistema!A seguir delete este arquivo \"banner_install.php\" para um funcionamento perfeito";
 else:
 print "Ocorreu um erro. Ou j� existe uma tabela com esse nome, ou o nome de usu�rio e/ou senha est� errado. Tente novamente";
 endif;

elseif($action == 'upgrade'):
$create= "ALTER TABLE $table ADD dat_type VARCHAR (15) not null , ADD html BLOB not null";
$exec = MYSQL_QUERY($create);
 if($exec == 1):
 print "\nTabela criado com sucesso, est� pronto o MPS Banner. Utilize o arquivo <a href=\"mpsbanner_admin.php\">mpsbanner_admin.php</a> para configurar o seu sistema!";
 else:
 print "Ocorreu algum erro. Tente novamente.";
 endif;
else:
print "<center>";
print "<a href=\"$pagename?create_new\">Clique aqui para instalar o MPS Banner V1.0</a><br><br>";
print "</center>";
endif;
foot();
MYSQL_CLOSE();
?>