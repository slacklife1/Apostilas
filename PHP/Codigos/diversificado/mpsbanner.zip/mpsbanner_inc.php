<?php

//ICQuente Banner V1.0 - Script Freeware

 //Nome do Host. Normalmente � localhost".
$hostname = "localhost";
 //Localiza��o do banner_click.php no servidor
$redirect = "mpsbanner_click.php";
 //Nome do Banco de Dados
$dbName = "banner";   # nome do Banco de Dados que sera usado para o Funcionamento do Script
 //Nome do usu�rio do MySQL
$username = "root"; #Nome de usu�rio do MySQL (N�o se preocupe, n�o ir� aparecer na p�gina)
 //Senha de conex�o ao MySQL
$password = ""; #Senha de usu�rio do MySQL (N�o se preocupe, n�o ir� aparecer na p�gina)
 //Nome da tabela do MySQL
$table = "mpsbanner"; #Nesta tabela ser�o inclusos os dados.
 //Senha Administrativa
$admin_pass = "admin"; #A senha pode ser alterada de sua prefer�ncia ou n�o
 //N�o precisa mudar depois dessa linha!
 ##################################
 //Cabe�alho e Copyright

 function head() {
 print "
 <html>

 <head>
 <meta http-equiv=\"Content-Language\" content=\"en-us\">
 <meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">
 <title>MPS Banner V1.0 - Script Freeware</title>
 <style>
 <!--
 textarea     { font-family: Tahoma; font-size: 8pt; padding: 3 }
 input        { font-family: Tahoma; font-size: 8pt;  }
 select        { font-family: Tahoma; font-size: 8pt; }
 a {text-decoration: none}
 A:hover {color: #00FFFF; text-decoration: underline}
 -->
 </style>
 </head>

 <body bgcolor=\"#000000\" text=\"#FFFFFF\" link=\"#00CCFF\" vlink=\"#00CCFF\" alink=\"#00FFFF\" style=\"font-family: Verdana;\">
<font face=\"Arial\" size=\"2\">
<center><b>MPS Banner V1.0 requer PHP e My SQL</b></center>";
 }

 function foot() {
 print "\n<center><br>Copyright by <a href=\"http://www.peguei.net/\" target=\"_top\">Peguei.Net</a><br>\n";
 print "Desenvolvido por <a href=\"mailto:mps3001@superig.com.br\">Marcelo Santos</a></font></center>\n</body>\n</html>";
 }

 //Bad Password
 function bad_pass() {
 head();
 print "Erro, Senha inv�lida";
 foot();
 exit();
 }

?>