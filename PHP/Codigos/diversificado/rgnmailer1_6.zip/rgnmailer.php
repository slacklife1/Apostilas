<?
////////////////////////////////////////////////////////////////////////////// 
// Written by Derek Major : Copyright � 2002 Derek Major
// dmajor@illigio.com
// http://www.dontak.org
// 
// June 17th 2002
// RGNmailer Version 1.6
//
//
// Visit WWW.ILLIGIO.COM for web hosting solutions.  Various Dontak Scripts
// come with installation of your virtual account.  
//
// We also offer web hosting at the Dontak site as well.
//
// 
////////////////////////////////////////////////////////////////////////////// 
//You may freely modify, use and distribute this software under the following //
//conditions:                                                                 //
//- Redistributions of this software include this message and the copyright   //
//  notice below.                                                             //
//- Modifications you made are clearly commented. If you modify the software  //
//  to patch a bug or improve it, please send a copy to dmajor@illigio.com,so //
//  that others may benefit from this modification.                           //
//                                                                            //
// This software is provided by Derek Major "as is", without any warranty.    //
////////////////////////////////////////////////////////////////////////////////
require ('config.php');

////////////////////////////////// DO NOT TOUCH BELOW ////////////////////////
$Version = "Version 1.6";

function rgn_dbconnect($db_hostname, $db_username, $db_password, $db_dbname){
$link = mysql_connect($db_hostname, $db_username, $db_password);
mysql_select_db($db_dbname);
return($link);
}

function rgn_dbdisconnect($link){
    mysql_close($link);
}


if($admin_viewlist){
    if($adminpass == $AdminPass){
    $link = rgn_dbconnect($db_hostname, $db_username, $db_password, $db_dbname);
    echo "<h3>Master List</h3>";
     if($db_type == "text"){
       $fcontents = file($userfile);
       while(list(,$value) = each ($fcontents)){
       list ($name,$password,$email) = split( "\|", $value);
        echo  "$email<BR>";
       }
      }
     elseif($db_type == "mysql"){
       $result = mysql_query("select * from mailinglist");
       $subscribers = 0;
       while($row = mysql_fetch_array($result)){
       echo "$row[email]<BR>";
       }
     }
    }
    else{echo "Error.  Wrong username and password.";} 
}
elseif($QUERY_STRING == "remove"){
display_header();
  if($mailaction == "userremove"){
  $string = "";
  $action = "Error.  No such email in database.";

   if($db_type == "text"){
     $fcontents = file($userfile);
        while(list(,$value) = each ($fcontents)){
         list ($name,$password,$email) = split( "\|", $value);

         $value = str_replace ("\n", "", $value);
         $email = str_replace ("\n", "", $email);
          if($email == $Emailitem){
            // checks if USEAUTH is on or off
           if($useauth == "on"){
              if($password == $Passitem && $name == $Nameitem){
                $action = "Email Successfully Deleted.";
	      }
             else { $string = $string."$value\n"; $action = "Wrong Password\\Username combo.";}
           } // ends auth
           else { $action = "Email successfully deleted.";} // ends auth else
          }
         else { $string = $string."$value\n"; $action = "No such email in database.";}
       } // end while of text

     $fw = fopen ($userfile, "w");
     $file = fwrite($fw,$string);
     $fp = fclose ($fw);
     echo "<h3>Result:<br><I>$action</I></h3>";
     echo "<P><font size=1><i><a href=\"http://www.dontak.org\">Powered by RGNmailer $Version</A></I></font>";
   } // end text db
   elseif($db_type == "mysql"){
     // connect to dbase
     $link = rgn_dbconnect($db_hostname, $db_username, $db_password, $db_dbname);
     $result = mysql_query("SELECT * from mailinglist");
        while($row = mysql_fetch_array($result)){
          if($row[email] == $Emailitem){
            // checks if USEAUTH is on or off
           if($useauth == "on"){
              if($row[password] == $Passitem && $row[username] == $Nameitem){
		$action = mysql_query("delete from mailinglist where username='$Nameitem'");
                $action = "Email Successfully Deleted.";
	      }
             else { $action = "Wrong Password\\Username combo.";}
           } // ends auth
           else { $action = "Email successfully deleted.";} // ends auth else
          }
         else { $string = $string."$value\n"; $action = "No such email in database.";}
       } // end while of mysql
     echo "<h3>Result:<br><I>$action</I></h3>";
     echo "<P><font size=1><i><a href=\"http://www.dontak.org\">Powered by RGNmailer $Version</A></I></font>";
     
  } // end mysql db
  else{ echo "Error.  No database specified in configuration file."; exit();}
  
   }
  else{
    echo "<font face=arial size=-1>";
    echo "Please type in your email to be removed<P>";
    echo "<form action=$fileurl?remove method=post>";
    echo "<input type=hidden name=mailaction value=\"userremove\">";
    echo "<input type=text name=Emailitem> Email Address<P>";
    if($useauth == "on"){
      echo "<input type=text name=Nameitem> User Name<P>";
      echo "<input type=password name=Passitem> Password<P>";
    }
    echo "<input type=submit name=Remove value=Remove>";
    echo "</form>";
  }
echo "<P><a href=\"$siteurl\">$sitename</A></P>";
display_footer();

} // end remove user
elseif($QUERY_STRING == "subscribe"){
     display_header();
     echo "<h3>Subscribe</h3>";
     echo "<form action=$fileurl method=post>";
     echo "<input type=hidden name=mailaction value=\"usersubscribe\">";
     if($useauth =="on"){
       echo "<input type=text name=UserName> <font size=-1>Username</font><BR>";
       echo "<input type=password name=Password> <font size=-1>Password</font><BR>";
     }
     echo "<input type=text name=Email> <font size=-1>Email</font><br>";
     echo "<input type=submit name=SignUp value=\"Sign Up!\"></form><p>";
     echo "<P><font size=-1><i><a href=\"http://www.dontak.org/\"><font color=blue>Powered by RGNmailer $Version</font></A></I></font>";
     display_footer();
}
elseif($QUERY_STRING == "password"){
  display_header();
  if($useauth == "off"){
         echo "Sorry but this feature is not available.";
  }
  else{
  if($Email){

  // if text version
  if($db_type == "text"){
    $fcontents = file($userfile);
    $find = "yes";
       while(list(,$value) = each ($fcontents)){
        list ($name,$password,$email) = split( "\|", $value);
        $value = str_replace ("\n", "", $value);
        $email = str_replace ("\n", "", $email);
         if($email == $Email){
            mail($Email, "$sitename Account info", "Name - $name\nEmail - $Email\nPassword - $password\n\n\nVisit us at $siteurl\n\nPowered by RGNmailer $Version.  http://www.dontak.org.", "From: $webmasteremail\nReply-To: $webmasteremail");
            $action = "Your password has been sent to <B>$email</B>";
            $find = "no";
         }
      }
    if($find == "yes"){
       echo "Sorry, that email does not exist in our database.";
      }
    else { echo $action; }
  }  
  elseif($db_type == "mysql"){
    $link = rgn_dbconnect($db_hostname, $db_username, $db_password, $db_dbname);
    $result = mysql_query("select * from mailinglist");
    $find = "yes";
       while($row = mysql_fetch_array($result)){
         if($row[email] == $Email){
            mail($Email, "$sitename Account info", "Name - $row[username]\nEmail - $Email\nPassword - $row[password]\n\n\nVisit us at $siteurl\n\nPowered by RGNmailer $Version.  http://www.dontak.org.", "From: $webmasteremail\nReply-To: $webmasteremail");
            $action = "Your password has been sent to <B>$Email</B>";
            $find = "no";
         }
      }
    if($find == "yes"){
       echo "Sorry, that email does not exist in our database.";
      }
    else { echo $action; }
    
  }

  else{ echo "Error.  No database specified in configuration file."; exit();}



  }
  else{
     echo "<h3>Password Retriever</h3>";
     echo "Fill out this form to have your password automatically emailed to you!<P>";
     echo "<form action=$fileurl?password method=post>";
     echo "<input type=text name=Email> <font size=-1>Email</font><br>";
     echo "<input type=submit name=SignUp value=\"Get Password\"></form><p>";
     echo "<P><font size=1><i><a href=\"http://www.dontak.org\">Powered by RGNmailer $Version</A></I></font>";
  }
}  
  display_footer();
}
elseif($mailaction == "usersubscribe"){
display_header();
if($Email != ""){
     $found = "notfound";
     $usercheck = file("$userfile");
     
     if($db_type == "text"){
     while(list(,$value) = each ($usercheck)){
      list ($name,$password,$email) = split( "\|", $value);
      $email = str_replace ("\n", "", $email);
      if($email == $Email){
	$found = "found";
      } // end if
     } // end while  
     if($found != "found"){
       $fp = fopen ($userfile, "a");
       $file = fwrite ($fp, "$UserName|$Password|$Email\n");
       $fp = fclose ($fp);
       $welcomemessage = file("$welcomefile");
       while(list(,$temp) = each ($welcomemessage)){
         $welcomemsg = $welcomemsg."$temp";
       }
       if($userauth == "on"){
         $usermsg = "Subscription Information:\n\nName - $UserName\nEmail - $Email\nPassword - $Password";
       }
       else{
       $usermsg = "Your Email: $Email";
       }
       mail($Email, "Welcome to $sitename Mailing List", "$welcomemsg\n\n$usermsg\n\n\nVisit us at $siteurl\n\nPowered by RGNmailer $Version.  http://www.dontak.org", "From: $webmasteremail\nReply-To: $webmasteremail");
       echo "Thanks!  You've been added to the newsletter!";
     }
     else {
       echo "Sorry! The email you entered already exists!<P><a href=\"$fileurl?subscribe\">Click here to go back</A>";
     }

      } // end text dbase
      elseif($db_type == "mysql"){
        $link = rgn_dbconnect($db_hostname, $db_username, $db_password, $db_dbname);
     $result = mysql_query("select * from mailinglist");   
     while($row = mysql_fetch_array($result)){
      if($row[email] == $Email){
	$found = "found";
      } // end if
     } // end while  
     if($found != "found"){
       mysql_query("INSERT INTO `mailinglist` (`id`, `username`, `password`, `email`) VALUES ('', '$UserName', '$Password', '$Email')");
       $welcomemessage = file("$welcomefile");
       while(list(,$temp) = each ($welcomemessage)){
         $welcomemsg = $welcomemsg."$temp";
       }
       if($userauth == "on"){
         $usermsg = "Subscription Information:\n\nName - $UserName\nEmail - $Email\nPassword - $Password";
       }
       else{
       $usermsg = "Your Email: $Email";
       }
       mail($Email, "Welcome to $sitename Mailing List", "$welcomemsg\n\n$usermsg\n\n\nVisit us at $siteurl\n\nPowered by RGNmailer $Version.  http://www.dontak.org", "From: $webmasteremail\nReply-To: $webmasteremail");
       echo "Thanks!  You've been added to the newsletter!";
     }
     else {
       echo "Sorry! The email you entered already exists!<P><a href=\"$fileurl?subscribe\">Click here to go back</A>";
     }

      }
      else{ echo "Error.  No database specified in configuration file."; exit();}
      
     echo "<P><a href=\"$siteurl\">$sitename</A></P>";
     echo "<P><font size=-1><i><a href=\"http://www.dontak.org\">Powered by RGNmailer $Version</A></I></font>";
}
else {
   echo "Error.  Email not entered.  Try again.";
}
     display_footer();
}

if($QUERY_STRING == "admin"){

  if($mailaction == "admindeleteuser"){
  display_header();
  if($adminpass == $AdminPass){
  $string = "";
  $action = "Error.  No such email in database.";
  
  if($db_type == "text"){
  $fcontents = file($userfile);
     while(list(,$value) = each ($fcontents)){
      list ($name,$password,$email) = split( "\|", $value);
       if($email == $Emailitem){
         # we dont write it
	 $action = "Email Successfully Deleted.";
       }
       else {
         $value = str_replace ("\n", "", $value);
         $string = $string."$value\n";
       }
    }
  $fw = fopen ($userfile, "w");
  $file = fwrite($fw,$string);
  $fp = fclose ($fw);
  echo "<h3>User Deleted: $Emailitem</h3>";
  }
  elseif($db_type == "mysql"){
    $link = rgn_dbconnect($db_hostname, $db_username, $db_password, $db_dbname);
    $result = mysql_query("select * from mailinglist");
    $action = "Email does not exist in database.";
     while($row=mysql_fetch_array($result)){
       if($row[email] == $Emailitem){
         $action = mysql_query("delete from mailinglist where email='$Emailitem'");
	 $action = "Email Successfully Deleted.";
       }
       else {
         // nothing
       }
    }
  echo "<h3>User Status: $action</h3>";
  }
  else{ echo "Error.  No database specified in configuration file."; exit();} 
  
  }
  else {
       echo "Error.  Wrong Password.  Go <a href=$fileurl?admin>Back</A>.";
  }
  echo "<P><a href=\"$siteurl\">$sitename</A></P>";
  display_footer();
  }
  elseif($mailaction == "adminmailout"){
     display_header();
     if($adminpass == $AdminPassword){
       
     
     if($db_type == "text"){
       $fcontents = file($userfile);
       while(list(,$value) = each ($fcontents)){
       list ($name,$password,$email) = split( "\|", $value);
       $email = str_replace ("\n", "", $email);

     $mailheaders  = "From: $webmasteremail\n";
     $mailheaders .= "Reply-To: $webmasteremail\n";
     $msg_body = stripslashes($MailContents);
     if ($attach != "none")
     {	$file = fopen($attach, "r");
     	$contents = fread($file, $attach_size);
     	$encoded_attach = chunk_split(base64_encode($contents));
	fclose($file);
	$mailheaders .= "MIME-version: 1.0\n";
	$mailheaders .= "Content-type: multipart/mixed; ";
	$mailheaders .= "boundary=\"Message-Boundary\"\n";
	$mailheaders .= "Content-transfer-encoding: 7BIT\n";
	$mailheaders .= "X-attachments: $attach_name";
	$body_top = "--Message-Boundary\n";
	$body_top .= "Content-type: text/plain; charset=US-ASCII\n";
	$body_top .= "Content-transfer-encoding: 7BIT\n";
	$body_top .= "Content-description: Mail message body\n\n";
	$msg_body = $body_top . $msg_body;
	$msg_body .= "\n\n--Message-Boundary\n";
	$msg_body .= "Content-type: $attach_type; name=\"$attach_name\"\n";		
	$msg_body .= "Content-Transfer-Encoding: BASE64\n";
	$msg_body .= "Content-disposition: attachment; filename=\"$attach_name\"\n\n";
	$msg_body .= "$encoded_attach\n";
	$msg_body .= "--Message-Boundary--\n";
     }

     mail($email, stripslashes($MaiLSubject), "Name - $name\nEmail - $email\n\n$msg_body",$mailheaders);
     }
     }
          elseif($db_type == "mysql"){
     $link = rgn_dbconnect($db_hostname, $db_username, $db_password, $db_dbname);
       $result = mysql_query("select * from mailinglist");
       while($row = mysql_fetch_array($result)){
     $mailheaders  = "From: $webmasteremail\n";
     $mailheaders .= "Reply-To: $webmasteremail\n";
     $msg_body = stripslashes($MailContents);
     if ($attach != "none")
     {	$file = fopen($attach, "r");
     	$contents = fread($file, $attach_size);
     	$encoded_attach = chunk_split(base64_encode($contents));
	fclose($file);
	$mailheaders .= "MIME-version: 1.0\n";
	$mailheaders .= "Content-type: multipart/mixed; ";
	$mailheaders .= "boundary=\"Message-Boundary\"\n";
	$mailheaders .= "Content-transfer-encoding: 7BIT\n";
	$mailheaders .= "X-attachments: $attach_name";
	$body_top = "--Message-Boundary\n";
	$body_top .= "Content-type: text/plain; charset=US-ASCII\n";
	$body_top .= "Content-transfer-encoding: 7BIT\n";
	$body_top .= "Content-description: Mail message body\n\n";
	$msg_body = $body_top . $msg_body;
	$msg_body .= "\n\n--Message-Boundary\n";
	$msg_body .= "Content-type: $attach_type; name=\"$attach_name\"\n";		
	$msg_body .= "Content-Transfer-Encoding: BASE64\n";
	$msg_body .= "Content-disposition: attachment; filename=\"$attach_name\"\n\n";
	$msg_body .= "$encoded_attach\n";
	$msg_body .= "--Message-Boundary--\n";
     }
     mail($row[email], stripslashes($MaiLSubject), "Name - $row[username]\nEmail - $row[email]\n\n$msg_body",$mailheaders);
          }

     }
     // checks to see if save message in archive
     //
     if($messagearchive == "on"){
         $fp = fopen ("$archivedir/$MaiLSubject.txt", "w");
         $file = fwrite ($fp, "$msg_body");
         $fp = fclose ($fp);
     }
     // ends writing file
     echo "<h3>Mail Sent!</h3>";
     }
     else {
       echo "Error.  Wrong Password.  Go <a href=$fileurl?admin>Back</A>.";
     }
     echo "<P><a href=\"$siteurl\">$sitename</A></P>";
     display_footer();
  }
  else{
     if($db_type == "mysql"){$link = rgn_dbconnect($db_hostname, $db_username, $db_password, $db_dbname);}
     display_header();
     echo "<P><a href=\"$siteurl\">$sitename</A></P>";
     echo "<h3>Admin Center</h3>\n";
     echo "<form action=$fileurl?admin method=post>";
     echo "<input type=hidden name=mailaction value=\"admindeleteuser\">";
     echo "<h4>Delete User</h4>";
     echo "<font size=-1><input type=password name=AdminPass> Admin Password</font><br>";
     echo "<input type=text name=Emailitem value=\"Type Email Here\">\n";
     echo "</select>\n<input type=submit value=\"Delete User\" name=\"admin_Delete\"></form><P>";
     echo "<form action=$fileurl method=post><h4>View Master List</h4>";
     echo "<font size=-1><input type=password name=AdminPass> Admin Password</font><br>";
     echo "</select>\n<input type=submit value=\"Click Here to View List\" name=\"admin_viewlist\"></form><BR><font size=1>You must type in the password to view your list</font>.<P>";
     if($db_type == "text"){
       $fcontents = file($userfile);
       $subscribers = 0;
       while(list(,$value) = each ($fcontents)){
       $subscribers++;
       }
      }
     elseif($db_type == "mysql"){
       $result = mysql_query("select * from mailinglist");
       $subscribers = 0;
       while($row = mysql_fetch_array($result)){
       $subscribers++;
       }
     }
     echo "<P><B>Total Subscribers: <font color=red>$subscribers</font></B></P>";
     echo "<form action=$fileurl method=post>";
     echo "<input type=hidden name=mailaction value=\"usersubscribe\">";
     echo "<input type=text name=UserName> <font size=-1>Username</font><BR>";
     echo "<input type=password name=Password> <font size=-1>Password</font><BR>";
     echo "<input type=text name=Email> <font size=-1>Email</font><br>";
     echo "<input type=submit name=SignUp value=\"Sign Up!\"></form><p>";
     echo "<h4>Email Mailing List</h4>";
     echo "<form action=$fileurl?admin method=post name=doit enctype=\"multipart/form-data\">";
     echo "<input type=hidden name=mailaction value=\"adminmailout\">";
     echo "<font size=-1><input type=password name=AdminPassword> Admin Password</font><p>";
     echo "<font size=-1><B>Attach File:</B><BR><input type=file name=\"attach\"></font><BR>";
     echo "<input type=text name=MaiLSubject> <font size=-1>Subject</font><BR>";
     echo "<TextArea name=MailContents cols=65 rows=5></TextArea><BR>";
     echo "<input type=Submit value=\"Send Mail!\" name=\"admin_Email\">";
if($messagearchive == "on"){
     echo "<h4>Mail Archive</h4>";
     $d = dir("$archivedir");
     while($entry=$d->read()) {
         if($entry == "."){ } elseif($entry == ".."){ } else {
         echo "<a href=\"$archivehttp/$entry\">$entry</A><br>\n"; }
     }
     $d->close();
  }
     display_footer();
     

  }


}
if($db_type == "mysql"){
  
  if($link){
  rgn_dbdisconnect($link);}
  ;}
///////////////////////////////////////////////////////////////////////////////////////////
// COPYRIGHT � 2002 DONTAK.ORG
///////////////////////////////////////////////////////////////////////////////////////////
