////////////////////////////////////////////////////////////////////////////// 
// Written by Derek Major : Copyright � 2002 Derek Major
// dmajor@illigio.com
// http://www.dontak.org
// 
// June 17th 2002
// RGNmailer Version 1.6
//
//
// Visit WWW.ILLIGIO.COM for web hosting solutions.  Various Dontak Scripts
// come with installation of your virtual account.  
//
// We also offer web hosting at the Dontak site as well.
//
// 
//////////////////////////////////////////////////////////////////////////////  
//You may freely modify, use and distribute this software under the following //
//conditions:                                                                 //
//- Redistributions of this software include this message and the copyright   //
//  notice below.                                                             //
//- Modifications you made are clearly commented. If you modify the software  //
//  to patch a bug or improve it, please send a copy to dmajor@illigio.com,so //
//  that others may benefit from this modification.                           //
//                                                                            //
// This software is provided by Derek Major "as is", without any warranty.    //
////////////////////////////////////////////////////////////////////////////////
// Changes from version 1.57 (Current Version 1.6)
	- mySQL support added
	- Improved Administration area

// Changes from version 1.5 (Current Version 1.57)
	- Fixed password fields in textboxes
	- Upgraded interaction with Return key board action on all accounts

// Changes from version 1.5 (Current Version 1.51)
	- Admin displays running total of subscribers
	- Fixed Security bug in mass mailing
	- Fixed subscribe function

// Changes from Version 1.01 (Current Version 1.5)
	- Attachments
	- No duplicate entries
	- URL to subscribe, not just code now
	- Requires USERNAME\PASSWORD\EMAIL (optional)
	- Password retrieve, emails password to specified email if it exists
	- Message Archive (optional)
	- Easier to use HEADER\FOOTER options
	- More error checking (subscribing)
	- Several HTML fixes (submit buttons)

// Changes from Version 1 (Current Version 1.01)
	- Added Welcome note to new subscribers
	- Made some HTML Changes, more link features for site

/// IMPORTANT NOTICE!! ///
RGNmailer Version 1.6 has been tested on PHP Version 4.  However it is known
to work on PHP 3.0.16.  Any questions, please email me at dmajor@illigio.com.

////////////////////////////////////////////////////////////////////////////////

Files:
	-> rgnmailer.php
	-> config.php
        -> address.txt
	-> readme.txt
	-> welcome.txt
	-> rgnmailer.sql

MYSQL SET UP
============
Included with the distribution is a file entitled "rgnmailer.sql".  This contains
the information for set up of your database.  I recommend using phpMyAdmin to
set up the SQL.  I use the database name "rgnmailer", however it doesn't really matter.

You however MUST use the table name "mailinglist" for mySQL.

Please note that you are NOT required to use mySQL.  RGNMailer still works perfectly
without mySQL.

SETUP INSTRUCTIONS
==================
Create a directory to store your data files.  For example /phpbin/.
Then upload:
	rpgmailer.php  -- No changes

Then upload:
	config.php -- No Changes			

Then upload:
	address.txt  -- CHMOD file 775 or 777
  				(this will allow us to write to the file)

Then upload:
	welcome.txt  -- CHMOD file 775 or 777
				(this will allow us to read the file)

Make changes to the header.txt and footer.txt files and put in what you want
for your header area and footer area.  The contents of RGNmailer goes in between
the header and footer.  If you do not upload these files, the RGNMailer program
ignores them and outputs only the operations.


CONFIG.PHP
----------
In here you will need to specify some options.

// this is the file that contains your user list
$userfile = "/usr/local/path/to/your/site/phpbin/address.txt";

// this is the location of your actual mailer script
$fileurl = "http://www.dontak.org/rgnmailer.php";

// this is the password used for the admin center
$adminpass = "monkeysoup";

// this is the email of the person who sends out to the mailing list
$webmasteremail = "webmaster@yahoo.com";

// this is the title of your website, which appears in the emails and admin center
$sitename = "Dontak";

// this is the location of your website, or host site of the script
$siteurl = "http://www.dontak.org";

// this is the file that contains the message sent in the email message sent to new subscribers
$welcomefile = "/usr/local/path/to/your/site/phpbin/welcome.txt";

// choose whether or not to use passwords\usernames for subscribers, set to OFF to not use it
$useauth = "on";

// set this to "on" if you wish to archive your emails sent to the mailing list, otherwise to OFF
$messagearchive = "on";

// if you set messagearchive to on, please specify the location to save the archives, no trailing slash
$archivedir = "/usr/local/path/to/your/site/phpbin/archives/";

// this is the browser or http location of your archive directory, no trailing slash
$archivehttp = "http://www.yoursite.com/phpbin/archives";

// choose whether or not to use mySQL or flat file (text) databases.  Please see readme for instructions.
// for mysql type in "mysql" or leave it as is for flat file "text"
$db_type = "mysql";

// MYSQL CONFIGURATION

// This will be the username assigned to you by your system administrator
$db_username = "root";

// This will be the password assigned to you by your system administrator
$db_password = "rpg987net";

// This will be the name of your database, NOT the name of the table
$db_dbname = "rgnmailer";

// Most mySQL servers are localhost, however if yours is different specify below
$db_hostname = "localhost";

You will also find the place to put your Header and footer HTML.  Just cut and paste the
header HTML between the "------" sections and do the same for the footer.  They are noted
well so you can't go wrong.

USING RGNMAILER
===============
Use the following HTML in your webpage to have somebody subscribe to your webpage:

      <form action=LOCATIONOFRGNMAILER.PHP3HERE method=post>
      <input type=hidden name=mailaction value="usersubscribe">
      <input type=text name=UserName> Username<BR>
      <input type=text name=Password> Password<BR>
      <input type=text name=Email> Email<P>
      <input type=submit name=SignUp value="Sign Up!"><BR>

Do not change any of the properties in the HTML as it can affect the PHP script.  If you are NOT
using authentication you can go ahead and delete the UserName and Password fields.

Another option you have is to direct people to 
http://www.yoururl.com/path/rgnmailer.php?subscribe
People will be presented with the form to fill out.

You can also link people to unsubscribe from your mailing list at:
http://www.yoururl.com/path/rgnmailer.php?remove

Your users can also go to the following URL to have their password emailed to them:
http://www.yoururl.com/path/rgnmailer.php?password

To use the admin center, type in:
http://www.yoururl.com/path/rgnmailer.php?admin

All options, except Add User, requires the password you specify in the config.inc
file.

That basically does it for RGNMailer.  

To report bugs or make suggestions on RGNmailer, please email me at dmajor@illigio.com.

WEB HOSTING
===========
If your looking for web hosting, please check out my web hosting company, ILLIGIO
at http://www.illigio.com.  We are not a reseller and have our own equipment
here in Calgary, Alberta, Canada!


///////////////////////////////////////////////////////////////////////////////////////////
COPYRIGHT � 2002 DONTAK.ORG
///////////////////////////////////////////////////////////////////////////////////////////
