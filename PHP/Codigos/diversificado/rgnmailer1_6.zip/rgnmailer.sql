CREATE TABLE mailinglist (
  id bigint(20) NOT NULL auto_increment,
  username varchar(20) NOT NULL default '',
  password varchar(20) NOT NULL default '',
  email varchar(45) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

