<?
////////////////////////////////////////////////////////////////////////////// 
// Written by Derek Major : Copyright � 2002 Derek Major
// dmajor@illigio.com
// http://www.dontak.org
// 
// June 17th 2002
// RGNmailer Version 1.6
//
//
// Visit WWW.ILLIGIO.COM for web hosting solutions.  Various Dontak Scripts
// come with installation of your virtual account.  
//
// We also offer web hosting at the Dontak site as well.
//
// 
////////////////////////////////////////////////////////////////////////////// 
//You may freely modify, use and distribute this software under the following //
//conditions:                                                                 //
//- Redistributions of this software include this message and the copyright   //
//  notice below.                                                             //
//- Modifications you made are clearly commented. If you modify the software  //
//  to patch a bug or improve it, please send a copy to dmajor@illigio.com,so //
//  that others may benefit from this modification.                           //
//                                                                            //
// This software is provided by Derek Major "as is", without any warranty.    //
////////////////////////////////////////////////////////////////////////////////
// config file

// Define variables

// this is the file that contains your user list
$userfile = "/usr/local/path/to/your/site/phpbin/address.txt";

// this is the location of your actual mailer script
$fileurl = "http://www.dontak.org/rgnmailer.php";

// this is the password used for the admin center
$adminpass = "monkeysoup";

// this is the email of the person who sends out to the mailing list
$webmasteremail = "webmaster@yahoo.com";

// this is the title of your website, which appears in the emails and admin center
$sitename = "Dontak";

// this is the location of your website, or host site of the script
$siteurl = "http://www.dontak.org";

// this is the file that contains the message sent in the email message sent to new subscribers
$welcomefile = "/usr/local/path/to/your/site/phpbin/welcome.txt";

// choose whether or not to use passwords\usernames for subscribers, set to OFF to not use it
$useauth = "on";

// set this to "on" if you wish to archive your emails sent to the mailing list, otherwise to OFF
$messagearchive = "on";

// if you set messagearchive to on, please specify the location to save the archives, no trailing slash
$archivedir = "/home/sites/www.dontak.org/web/rgnmailer/archives";

// this is the browser or http location of your archive directory, no trailing slash
$archivehttp = "http://www.dontak.org/rgnmailer/archives";  

// choose whether or not to use mySQL or flat file (text) databases.  Please see readme for instructions.
// for mysql type in "mysql" or leave it as is for flat file "text"
$db_type = "text";

// IF YOU SELECT MYSQL please fill out the following information, otherwise leave it as is

// username for database
$db_username = "username";

// password for database
$db_password = "password";

// database name
$db_dbname = "rgnmailer";

// Most mySQL servers are localhost, however if yours is different specify below
$db_hostname = "localhost";



//////////////// HEADER HTML CODE BELOW HERE
function display_header(){
// Start HTML
////////////////////////////////////////////////////////////////////////////////////////////
//HHHHHEEEEEAAAAADDDDDEEEEERRRRRHHHHHEEEEEAAAAADDDDDEEEEERRRRRHHHHHEEEEEAAAAADDDDDEEEEERRRRR
////////////////////////////////////////////////////////////////////////////////////////////
?>


<!-- HTML HERE -->



<?
// End HTML
////////////////////////////////////////////////////////////////////////////////////////////
//HHHHHEEEEEAAAAADDDDDEEEEERRRRRHHHHHEEEEEAAAAADDDDDEEEEERRRRRHHHHHEEEEEAAAAADDDDDEEEEERRRRR
////////////////////////////////////////////////////////////////////////////////////////////
}

function display_footer(){
// Start HTML
///////////////////////////////////////////////////////////////////////////////////////////
//FFFFF00000TTTTTTTTTTEEEEERRRRRFFFFF00000TTTTTTTTTTEEEEERRRRRFFFFF00000TTTTTTTTTTEEEEERRRRR
///////////////////////////////////////////////////////////////////////////////////////////
?>


<!-- HTML HERE -->



<?
// End HTML
///////////////////////////////////////////////////////////////////////////////////////////
//FFFFF00000TTTTTTTTTTEEEEERRRRRFFFFF00000TTTTTTTTTTEEEEERRRRRFFFFF00000TTTTTTTTTTEEEEERRRRR
///////////////////////////////////////////////////////////////////////////////////////////

}
///////////////////////////////////////////////////////////////////////////////////////////
// COPYRIGHT � 2002 DONTAK.ORG
///////////////////////////////////////////////////////////////////////////////////////////
?>
