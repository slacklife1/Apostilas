<?php
/***************************************************************************
 *   script               : vCard LITE
 *   copyright            : (C) 2001-2003 Belchior Foundry
 *   website              : www.belchiorfoundry.com
 *
 *   This program is freeware software; you can�t redistribute it under
 *   any circumstance without explicit authorization from Belchior Foundry.
 *   http://www.belchiorfoundry.com/
 *
 ***************************************************************************/

$step = $HTTP_GET_VARS['step'];
error_reporting(E_ERROR | E_WARNING | E_PARSE);
if(get_cfg_var("safe_mode")!=0)
{
	$installnote ="<p><b>Note:</b> In your server PHP configuration the <b>Safe Mode is active</b>, You can't use UPLOAD feature</p>";
	$safemode ="1";
}
function dodb_queries()
{
	global $DB_site,$query,$explain,$onvservers;
	while (list($key,$val)=each($query))
	{
		echo "<p>$explain[$key]</p>\n";
		echo "<!-- ".htmlspecialchars($val)." -->\n\n";
		flush();
		if ($onvservers==1 and substr($val, 0, 5)=="ALTER")
		{
			$DB_site->reporterror=0;
		}
		$DB_site->query($val);
		if ($onvservers==1 and substr($val, 0, 5)=="ALTER")
		{
			$DB_site->connect();
			$DB_site->reporterror=1;
		}
	}
	unset ($query);
	unset ($explain);
}
?>
<HTML>
	<HEAD>
	<title>vCard Lite Upgrading</title>
        <style type="text/css">
        BODY            {background-color: #F0F0F0; color: #3F3849; font-family: Verdana; font-size: 12px;
        UL,LI,P,TD,TR	{font-family: Verdana; font-size: 12px}
        H2              {font-family: Verdana; font-size: 14px}

        A               {font-family: Verdana; text-decoration: none;}
        A:HOVER         {font-family: Verdana; COLOR: #FFAC00;}
        A:ACTIVE        {font-family: Verdana; COLOR: #FFAC00;}

        FORM ,SELECT,INPUT,TEXTAREA        {font-family: Verdana; font-size: 10px}
	.title		{font-family: Verdana; font-size: 25px;color: #000000;}
        </style>
	</HEAD>
<BODY bgcolor="#CCCCCC" text="#3F3849" link="#3F3849" vlink="#3F3849" alink="#3F3849" leftmargin="10" topmargin="10" marginwidth="10" marginheight="10">
<?php
echo "<p class=\"title\"><b>vCard Lite upgrading to version 2.0</b></p>";
if ($step=="")
{

	echo "
	<p>Welcome to vCard Lite version 2.0 upgradings script.</p>
	<p>Running this script will the updraging of vCard Lite database strucuctury:<b> from version 1.5 to 2.0</b></p>
	<p><a href=\"$PHP_SELF?step=2\">Click here to continue --></a></p>";
	
}
if($step>=2)
{
	// step 3 and after, we are ok loading this file
	require("./admin/config.inc.php");
	require("./include/db_mysql.inc.php");
	$DB_site=new DB_Sql_vc;
	$DB_site->server=$hostname;
	$DB_site->user=$dbUser;
	$DB_site->password=$dbPass;
	$DB_site->database=$dbName;
	$DB_site->connect();
	$dbPass="";		// clear database password variable to avoid retrieving
	$DB_site->password="";
	// allow this script to catch errors
	$DB_site->reporterror=0;
	
	$DB_site->connect();
	// end init db
}

if ($step==2)
{
	echo "<p>Upgrading database tables...</p>";
	$DB_site->reporterror=0;
	
$DB_site->query("ALTER TABLE $dbtbl_card ADD `card_date` DATE NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_card ADD INDEX(`card_date`) ");
$DB_site->query("ALTER TABLE $dbtbl_card CHANGE `CardTemplate` `card_template` VARCHAR(30) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_card CHANGE `CardImgFile` `card_image` VARCHAR(150) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_card CHANGE `CardThmFile` `card_thm` VARCHAR(180) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_card CHANGE `CardCategory` `cat_id` INT(30) DEFAULT '0' NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_card CHANGE `CardID` `card_id` INT(20) NOT NULL AUTO_INCREMENT");
$DB_site->query("ALTER TABLE $dbtbl_card DROP INDEX `CardCategory` ");
$DB_site->query("ALTER TABLE $dbtbl_card ADD INDEX(`cat_id`)  ");
$DB_site->query("ALTER TABLE $dbtbl_cat CHANGE `CatID` `cat_id` INT(10) NOT NULL AUTO_INCREMENT  ");
$DB_site->query("ALTER TABLE $dbtbl_cat CHANGE `CatName` `cat_name` VARCHAR(35) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_cat DROP INDEX `CatName` ");
$DB_site->query("ALTER TABLE $dbtbl_cat ADD INDEX(`cat_name`) ");
$DB_site->query("ALTER TABLE $dbtbl_pattern CHANGE `PatternFile` `pattern_file` VARCHAR(120) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_pattern CHANGE `PatternName` `pattern_name` VARCHAR(50) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_music CHANGE `SoundFile` `sound_file` VARCHAR(150) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_music CHANGE `SoundName` `sound_name` VARCHAR(150) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_music CHANGE `SoundAuthor` `sound_author` VARCHAR(150) NOT NULL "); 
$DB_site->query("ALTER TABLE $dbtbl_music CHANGE `SoundGenre` `sound_genre` VARCHAR(150) NOT NULL");
$DB_site->query("ALTER TABLE $dbtbl_music DROP INDEX `SoundGenre` ");
$DB_site->query("ALTER TABLE $dbtbl_music ADD INDEX(`sound_genre`)");
$DB_site->query("ALTER TABLE $dbtbl_music ADD INDEX(`sound_name`)  ");
$DB_site->query("ALTER TABLE $dbtbl_stamp CHANGE `StampFile` `stamp_file` VARCHAR(120) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_stamp CHANGE `StampName` `stamp_name` VARCHAR(50) NOT NULL ");

$DB_site->query("ALTER TABLE $dbtbl_stats CHANGE `PostImage` `card_image` VARCHAR(150) NOT NULL  ");
$DB_site->query("ALTER TABLE $dbtbl_stats CHANGE `PostImageThm` `card_thm` VARCHAR(180) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_stats CHANGE `PostStamp` `stamp_file` VARCHAR(150) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_stats CHANGE `PostSound` `sound_file` VARCHAR(150) NOT NULL  ");
$DB_site->query("ALTER TABLE $dbtbl_stats CHANGE `PostBackGround` `pattern_file` VARCHAR(150) NOT NULL  ");
$DB_site->query("ALTER TABLE $dbtbl_stats CHANGE `PostTemplate` `card_template` VARCHAR(30) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_stats DROP INDEX `PostImage` ");
$DB_site->query("ALTER TABLE $dbtbl_stats DROP INDEX `PostImageThm` ");
$DB_site->query("ALTER TABLE $dbtbl_stats ADD INDEX(`card_thm`)");
$DB_site->query("ALTER TABLE $dbtbl_stats ADD INDEX(`card_image`) ");

$DB_site->query("ALTER TABLE $dbtbl_user DROP INDEX `PostToSend`  ");
$DB_site->query("ALTER TABLE $dbtbl_user DROP INDEX `PostDate`  ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostDate` `ecard_date` DATE DEFAULT '0000-00-00' NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `SenderName` `ecard_sname` VARCHAR(60) NOT NULL  ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `SenderEmail` `ecard_semail` VARCHAR(60) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `RecpName` `ecard_rname` VARCHAR(60) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `RecpEmail` `ecard_remail` VARCHAR(60) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostImage` `card_image` VARCHAR(150) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostStamp` `stamp_file` VARCHAR(150) NOT NULL  ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostSound` `sound_file` VARCHAR(150) NOT NULL   ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostHeading` `ecard_heading` VARCHAR(110) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostMessage` `ecard_message` BLOB NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostSig` `ecard_sig` VARCHAR(60) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostBackGround` `pattern_file` VARCHAR(150) NOT NULL  ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostColor` `ecard_color` VARCHAR(30) NOT NULL  ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostTemplate` `card_template` VARCHAR(30) NOT NULL  ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `MessageID` `ecard_id` VARCHAR(25) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostFontFace` `ecard_fontface` VARCHAR(30) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostFontColor` `ecard_fontcolor` VARCHAR(30) NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostFontSize` `ecard_fontsize` VARCHAR(10) NOT NULL ");
$DB_site->query("UPDATE $dbtbl_user SET PostRead='1' WHERE PostRead='Yes' ");
$DB_site->query("UPDATE $dbtbl_user SET PostRead='0' WHERE PostRead='No' ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostRead` `ecard_read` ENUM('0','1') DEFAULT '0' NOT NULL  ");
$DB_site->query("UPDATE $dbtbl_user SET PostBeNotify='1' WHERE PostBeNotify='Yes' ");
$DB_site->query("UPDATE $dbtbl_user SET PostBeNotify='0' WHERE PostBeNotify='No' ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostBeNotify` `ecard_notify` ENUM('0','1') DEFAULT '0' NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostToSend` `ecard_tosend` DATE NOT NULL ");
$DB_site->query("UPDATE $dbtbl_user SET PostSent='1' WHERE PostSent='Yes' ");
$DB_site->query("UPDATE $dbtbl_user SET PostSent='0' WHERE PostSent='No' ");
$DB_site->query("ALTER TABLE $dbtbl_user CHANGE `PostSent` `ecard_sent` ENUM('0','1') DEFAULT '1' NOT NULL ");
$DB_site->query("ALTER TABLE $dbtbl_user ADD INDEX(`ecard_tosend`) ");
$DB_site->query("ALTER TABLE $dbtbl_user ADD INDEX(`ecard_date`)  ");

$DB_site->query("CREATE TABLE $dbtbl_spam (
  id bigint(20) NOT NULL auto_increment,
  ip varchar(50) NOT NULL default '',
  date int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY ip (ip),
  KEY date (date))
  ");

	if ($DB_site->errno!=0) {
		echo "<p>The script reported errors in the upgrading of the tables. Only continue if you are sure that they are not serious.</p>";
		echo "<p>The errors were:</p>";
		echo "<p>Error number: ".$DB_site->errno."</p>";
		echo "<p>Error description: ".$DB_site->errdesc."</p>";
	}
	else
	{
		echo "<p><b>Tables set up successfully.<</b>/p>";
	}
	echo "<p>Tables upgrading successfully.</p>";
	echo "<p><a href=\"$PHP_SELF?step=".($step+1)."\">Click here to continue --></a></p>";
}

if ($step==3)
{
	echo "<p>Data Base Upgrade is complete.</p>";
	echo "<p>You have now completed the vCard Lite upgrading. Delete install.php, uninstall.php, upgrade14to15.php and upgrade15to20.php script for security reasons.</p>";
	echo "<p>Read documentation for more vCard lite information.</p>";
	echo "$installnote";
	echo "<p>The main page <a href=\"\">can be found here --></a></p>";
}
?>