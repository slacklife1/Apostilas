<html>
<!--
<?php
// determine if php is running
if (1==0)
{
	echo "-->You are not running PHP - Please contact your system administrator.<!--";
}
else
{
	echo "--".">";
}
$step = $HTTP_GET_VARS['step'];
$vCardLiteVersion="2.4.2";
error_reporting(E_ERROR | E_WARNING | E_PARSE);
if(get_cfg_var("safe_mode")!=0)
{
	$installnote ="<p><b>Note:</b> In your server PHP configuration the <b>Safe Mode is active</b>, You can't use UPLOAD feature</p>";
	$safemode ="1";
}
function dodb_queries()
{
	global $DB_site,$query,$explain,$onvservers;
	while (list($key,$val)=each($query))
	{
		echo "<p>$explain[$key]</p>\n";
		echo "<!-- ".htmlspecialchars($val)." -->\n\n";
		flush();
		if ($onvservers==1 and substr($val, 0, 5)=="ALTER")
		{
			$DB_site->reporterror=0;
		}
		$DB_site->query($val);
		if ($onvservers==1 and substr($val, 0, 5)=="ALTER")
		{
			$DB_site->connect();
			$DB_site->reporterror=1;
		}
	}
	unset ($query);
	unset ($explain);
}
?>
<HTML>
	<HEAD>
	<title>vCard Lite Data Base Wizard Install <?php echo $vCardLiteVersion; ?></title>
        <style type="text/css">
        BODY            {background-color: #F0F0F0; color: #3F3849; font-family: Verdana; font-size: 12px;
        UL,LI,P,TD,TR	{font-family: Verdana; font-size: 12px}
        H2              {font-family: Verdana; font-size: 14px}

        A               {font-family: Verdana; text-decoration: none;}
        A:HOVER         {font-family: Verdana; COLOR: #FFAC00;}
        A:ACTIVE        {font-family: Verdana; COLOR: #FFAC00;}

        FORM ,SELECT,INPUT,TEXTAREA        {font-family: Verdana; font-size: 10px}
	.title		{font-family: Verdana; font-size: 25px;color: #000000;}
        </style>
	</HEAD>
<BODY bgcolor="#CCCCCC" text="#3F3849" link="#3F3849" vlink="#3F3849" alink="#3F3849" leftmargin="10" topmargin="10" marginwidth="10" marginheight="10">
<?php
echo "<p class=\"title\"><b>vCard Lite version $vCardLiteVersion</b></p>";
if ($step=="")
{

	echo "
	<p>Welcome to vCard Lite version $vCardLiteVersion Installation script.</p>
	<p>Running this script will do an install of vCard Lite database strucuctury and default data onto your server.</p>
	<p><a href=\"$PHP_SELF?step=2\">Click here to continue --></a></p>";
	
}
if ($step==2)
{
	if (!defined('VC_IS_WINDOWS'))
	{
		if (defined('PHP_OS') && eregi('win', PHP_OS))
		{
			define('SLASH_SIGN', '\\');
		}else{
			define('SLASH_SIGN', '/');
		}
	}
	$base_path 	= str_replace("install.php",'',$HTTP_SERVER_VARS['PATH_TRANSLATED']);
	$base_path_image = str_replace('install.php', '', $base_path).'images';
	//echo 'real path to this dir= '.dirname(__FILE__).'<hr>';
	//echo 'real path to this dir= '.realpath($_SERVER['SCRIPT_FILENAME']).'<hr>';
	echo "<p>Check configuration of database</p>";
	if (file_exists("./admin/config.inc.php")==0)
	{
		echo "<p>Cannot find <b>config.inc.php</b> file in admin directory.</p>";
		echo "<p>Make sure that you have uploaded it and that it is in the admin directory.</p>";
		exit;
	}
	else
	{
		include("./admin/config.inc.php");
		echo "<p>Please confirm the details below:</p>\n";
		echo "<table border=1 cellspacing=2 cellpadding=2 align=center>";
		echo "<tr><td><b>Database server hostname / IP address:</td><td> $hostname</td></tr>\n";
		echo "<tr><td><b>Database username:</td><td> $dbUser</td></tr>\n";
		echo "<tr><td><b>Database password:</td><td> $dbPass</td></tr>\n";
		echo "<tr><td><b>Database name:</td><td> $dbName</td></tr>\n";
		echo "<tr><td><b>Full PATH to your image dir</b></td><td>$card_imagePath<br>(must be like this : <i>$base_path_image</i>)</td></tr>";
		echo "</table>";
		echo "<p>Only continue to the next step if those details are correct. If they are not, please edit your <b>config.inc.php</b> file and reupload it. The next step will test database connectivity.</p>";
		echo "<p><a href=\"$PHP_SELF?step=".($step+1)."\">Click here to continue --></a></p>";
	}
}

if($step>=3)
{
	// step 3 and after, we are ok loading this file
	include("./admin/config.inc.php");
	include("./include/db_mysql.inc.php");
	$DB_site=new DB_Sql_vc;
	$DB_site->server=$hostname;
	$DB_site->user=$dbUser;
	$DB_site->password=$dbPass;
	$DB_site->database=$dbName;
	$DB_site->reporterror=0;
	$DB_site->connect();
	$dbPass='';		// clear database password variable to avoid retrieving
	$DB_site->password="";
	// allow this script to catch errors
}
if($step==3)
{
	// end init db
	$errno=$DB_site->errno;
	if ($DB_site->link_id!=0)
	{
		if ($errno==0)
		{
			echo "<p><b>Connection succeeded! The database already exists.</b></p>";
			echo "<p><a href=\"install.php?step=".($step+1)."\">Click here to continue --></a></p>";
			exit;
		}
	}else{
		echo "<p>The database has failed to connect because you do NOT HAVE PERMISSION to connect to the server. Please go back to the last step and ensure that you have entered all your Data Base access login details correctly.</p>";
		exit;
	}
}

if ($step==4)
{
	echo "<p>Setting up tables...</p>";
	$DB_site->reporterror=0;
	
	$query[] = "CREATE TABLE $dbtbl_card (
	card_id int(20) NOT NULL auto_increment,
	cat_id int(30) DEFAULT '0' NOT NULL,
	card_image varchar(150) NOT NULL,
	card_thm varchar(180) NOT NULL,
	card_template varchar(30) NOT NULL,
	card_date date NOT NULL default '0000-00-00',
	PRIMARY KEY  (card_id),
	KEY cat_id (cat_id)
	)";
	$explain[] ="Creating table cards image";
	
	$query[] = "CREATE TABLE $dbtbl_cat (
	cat_id int(10) NOT NULL auto_increment,
	cat_name varchar(35) NOT NULL,
	PRIMARY KEY (cat_id),
	key cat_name(cat_name)
	)";
	$explain[] ="Creating table cards categories";
	
	$query[] = "CREATE TABLE $dbtbl_pattern (
	pattern_file varchar(120) NOT NULL,
	pattern_name varchar(50) NOT NULL,
	PRIMARY KEY (pattern_file)
	)";
	$explain[] ="Creating table pattern";
	
	$query[] = "CREATE TABLE $dbtbl_music (
	sound_file varchar(150) NOT NULL,
	sound_name varchar(150) NOT NULL,
	sound_author varchar(150) NOT NULL,
	sound_genre varchar(150) NOT NULL,
	PRIMARY KEY (sound_file),
	KEY sound_genre (sound_genre)
	)";
	$explain[] ="Creating table music";
	
	$query[] = "CREATE TABLE $dbtbl_stamp (
	stamp_file varchar(120) NOT NULL,
	stamp_name varchar(50) NOT NULL,
	PRIMARY KEY (stamp_file)
	)";
	$explain[] ="Creating table stamp";
	
	$query[] = "CREATE TABLE $dbtbl_stats (
	date datetime,
	card_image varchar(150) NOT NULL,
	card_thm varchar(180) NOT NULL,
	stamp_file varchar(150) NOT NULL,
	sound_file varchar(150) NOT NULL,
	pattern_file varchar(150) NOT NULL,
	card_template varchar(30) NOT NULL,
 	key card_image(card_image),
 	key card_thm(card_thm)
	)";
	$explain[] ="Creating table stats";
	
	$query[] = "CREATE TABLE $dbtbl_user (
	ecard_date date NOT NULL default '0000-00-00',
	ecard_sname varchar(60) NOT NULL default '',
	ecard_sip varchar(25) NOT NULL default '',
	ecard_semail varchar(60) NOT NULL default '',
	ecard_rname varchar(60) NOT NULL default '',
	ecard_remail varchar(60) NOT NULL default '',
	card_image varchar(150) NOT NULL default '',
	stamp_file varchar(150) NOT NULL default '',
	sound_file varchar(150) NOT NULL default '',
	ecard_heading varchar(110) NOT NULL default '',
	ecard_message blob NOT NULL,
	ecard_sig varchar(60) NOT NULL default '',
	pattern_file varchar(150) NOT NULL default '',
	ecard_color varchar(30) NOT NULL default '',
	card_template varchar(30) NOT NULL default '',
	ecard_fontface varchar(30) NOT NULL default '',
	ecard_fontcolor varchar(30) NOT NULL default '',
	ecard_fontsize varchar(10) NOT NULL default '',
	ecard_id varchar(25) NOT NULL default '',
	ecard_read enum('0','1') NOT NULL default '0',
	ecard_notify enum('0','1') NOT NULL default '0',
	ecard_tosend date NOT NULL default '0000-00-00',
	ecard_sent enum('0','1') NOT NULL default '1',
	PRIMARY KEY  (ecard_id),
	KEY ecard_date (ecard_date),
	KEY ecard_tosend (ecard_tosend)
	)";
	$explain[] ="Creating table user's cards";
	
	$query[] = "CREATE TABLE $dbtbl_spam (
	id bigint(20) NOT NULL auto_increment,
	ip varchar(50) NOT NULL default '',
	date int(11) unsigned NOT NULL default '0',
	PRIMARY KEY  (id),
	KEY ip (ip),
	KEY date (date))";
	$explain[] ="Creating antispam feature";
	
	$query[] = "CREATE TABLE $dbtbl_slog (
	logid int(15) unsigned NOT NULL auto_increment,
	date datetime NOT NULL default '0000-00-00 00:00:00',
	sentdate datetime NOT NULL default '0000-00-00 00:00:00',
	sname varchar(60) NOT NULL default '',
	semail varchar(60) NOT NULL default '',
	sip varchar(25) NOT NULL default '',
	rname varchar(60) NOT NULL default '',
	remail varchar(60) NOT NULL default '',
	ecard_id varchar(25) NOT NULL default '',
	PRIMARY KEY  (logid)
	)";
	
	$explain[] ="Creating service log feature";
	
	dodb_queries();
	if ($DB_site->errno!=0) {
		echo "<p>The script reported errors in the installation of the tables. Only continue if you are sure that they are not serious.</p>";
		echo "<p>The errors were:</p>";
		echo "<p>Error number: ".$DB_site->errno."</p>";
		echo "<p>Error description: ".$DB_site->errdesc."</p>";
	}
	else
	{
		echo "<p>Tables set up successfully.</p>";
	}
	echo "<p>Tables creation set up successfully.</p>";
	echo "<p><a href=\"$PHP_SELF?step=".($step+1)."\"><b>Click here to continue --></b></a></p>";
}

if ($step==5)
{
	echo "<p>Inserting data on tables...</p>";

	// Music
	$DB_site->query("INSERT INTO $dbtbl_music VALUES ( 'Handel_Sonata_n3_fluete_piano.mid', 'Sonata n3 - Fluete and Piano', 'Handel', 'Classic')");
	$DB_site->query("INSERT INTO $dbtbl_music VALUES ( 'Pachelbel_canon.mid', 'Canon in D', 'Pachelbel', 'Classic')");
	$DB_site->query("INSERT INTO $dbtbl_music VALUES ( 'Dorival_Caymmi_marina.mid', 'Marina', 'Dorival Caymi', 'Brazilian')");
	$DB_site->query("INSERT INTO $dbtbl_music VALUES ( 'Eagles_hotel_california.mid', 'California', 'The Eagles', 'Pop Rock')");
	$DB_site->query("INSERT INTO $dbtbl_music VALUES ( 'Edwin_van_Veldhoven_eurydice.mid', 'Eurydice', 'Edwin van Veldhove', 'Eletronic')");
	$DB_site->query("INSERT INTO $dbtbl_music VALUES ( 'Beethoven_moonlightsonata.mid', 'MoonLightSonata', 'Bethoveen', 'Classic')");
	echo "<p>added default music data</p>";
	
	// Stamps
	$DB_site->query("INSERT INTO $dbtbl_stamp VALUES ( 'stamp/stamp01.gif', 'Stamp 01')");
	$DB_site->query("INSERT INTO $dbtbl_stamp VALUES ( 'stamp/stamp02.gif', 'Stamp 02')");
	$DB_site->query("INSERT INTO $dbtbl_stamp VALUES ( 'stamp/stamp03.gif', 'Stamp 03')");
	echo "<p>added default stamp data</p>";
	
	// Stats
	$DB_site->query("INSERT INTO $dbtbl_stats VALUES ( '2001-03-02 17:51:30', 'pic001.jpg', 'thm_pic001.gif', 'stamp/stamp01.gif', '', 'bg1.jpg', 'demo')");
	$DB_site->query("INSERT INTO $dbtbl_stats VALUES ( '2001-03-02 17:51:37', 'pic001.jpg', 'thm_pic001.gif', 'stamp/stamp01.gif', '', 'bg1.jpg', 'demo')");
	$DB_site->query("INSERT INTO $dbtbl_stats VALUES ( '2001-03-02 18:13:53', 'pic001.jpg', 'thm_pic001.gif', 'stamp/stamp01.gif', '', 'bg1.jpg', 'demo')");
	$DB_site->query("INSERT INTO $dbtbl_stats VALUES ( '2001-03-02 18:13:58', 'pic001.jpg', 'thm_pic001.gif', 'stamp/stamp01.gif', '', 'bg1.jpg', 'demo')");
	$DB_site->query("INSERT INTO $dbtbl_stats VALUES ( '2001-03-02 18:14:59', 'SomeSubDir/pic002.jpg', 'SomeSubDir/thm_pic002.gif', '', '', '', 'template01')");
	$DB_site->query("INSERT INTO $dbtbl_stats VALUES ( '2001-03-02 18:15:05', 'SomeSubDir/pic002.jpg', 'SomeSubDir/thm_pic002.gif', '', '', '', 'template01')");
	echo "<p>added default stats data</p>";
	
	// Pattern
	$DB_site->query("INSERT INTO $dbtbl_pattern VALUES ( 'bg1.jpg', 'Gray Pattern')");
	$DB_site->query("INSERT INTO $dbtbl_pattern VALUES ( 'bg2.jpg', 'BluePurple Pattern')");
	echo "<p>added default pattern data</p>";

	// Gallery
	$DB_site->query("INSERT INTO $dbtbl_cat VALUES ( '1', 'General Demo')");
	$DB_site->query("INSERT INTO $dbtbl_cat VALUES ( '2', 'Flash Postcards')");
	$DB_site->query("INSERT INTO $dbtbl_cat VALUES ( '3', 'Special Cards')");
	echo "<p>added default cards categories data</p>";
	
	$DB_site->query("INSERT INTO $dbtbl_card VALUES ( '1', '1', 'pic001.jpg', 'thm_pic001.gif', '', '2002-01-01')");
	$DB_site->query("INSERT INTO $dbtbl_card VALUES ( '2', '1', 'SomeSubDir/pic002.jpg', 'SomeSubDir/thm_pic002.gif', '', '2002-01-02')");
	$DB_site->query("INSERT INTO $dbtbl_card VALUES ( '3', '1', 'pic001.jpg', 'thm_pic001.gif', 'demo', '2002-01-03')");
	$DB_site->query("INSERT INTO $dbtbl_card VALUES ( '4', '1', 'pic001.jpg', 'thm_pic001.gif', '', '2002-01-05')");
	$DB_site->query("INSERT INTO $dbtbl_card VALUES ( '5', '1', 'SomeSubDir/pic002.jpg', 'SomeSubDir/thm_pic002.gif', '', '2002-01-06')");
	$DB_site->query("INSERT INTO $dbtbl_card VALUES ( '6', '1', 'pic001.jpg', 'thm_pic001.gif', 'demo', '2002-01-07')");
	$DB_site->query("INSERT INTO $dbtbl_card VALUES ( '7', '1', 'pic001.jpg', 'thm_pic001.gif', '', '2002-01-09')");
	$DB_site->query("INSERT INTO $dbtbl_card VALUES ( '8', '1', 'SomeSubDir/pic002.jpg', 'SomeSubDir/thm_pic002.gif', '', '2002-01-10')");
	$DB_site->query("INSERT INTO $dbtbl_card VALUES ( '9', '1', 'pic001.jpg', 'thm_pic001.gif', 'demo', '2002-01-11')");
	$DB_site->query("INSERT INTO $dbtbl_card VALUES ( '10', '2', 'demoflash.swf', 'thm_demoflash.gif', '', '2002-04-04')");
	$DB_site->query("INSERT INTO $dbtbl_card VALUES ( '11', '3', 'java/RealSnow.jav', 'java/thm_snow.jpg', '', '2002-04-04')");
	$DB_site->query("INSERT INTO $dbtbl_card VALUES ( '12', '3', '', 'friends/thm_friends.gif', 'friends', '2002-04-04')");
	
	echo "<p>added default cards data</p>";

	echo "<p>added default data on  database tables successfully!</p>";
	echo "<p><a href=\"$PHP_SELF?step=".($step+1)."\"><b>Click here to continue --></b></a></p>";
}

if ($step==6)
{
	echo "<p>Data Base Set Up complete.</p>";
	echo "<p>You have now completed the vCard Lite data base installation. Delete this script at \"<b>$PHP_SELF</b>\"<br> for security reasons.</p>";
	echo "<p>Read documentation for more vCard lite information.</p>";
	echo "$installnote";
	echo "<p>The demo page <a href=\"\">can be found here --></a></p>";
}
?>