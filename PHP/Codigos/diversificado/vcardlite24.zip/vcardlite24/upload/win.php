<?php
/***************************************************************************
 *   script               : vCard LITE
 *   copyright            : (C) 2001-2003 Belchior Foundry
 *   website              : www.belchiorfoundry.com
 *
 *   This program is freeware software; you can�t redistribute it under
 *   any circumstance without explicit authorization from Belchior Foundry.
 *   http://www.belchiorfoundry.com/
 *
 ***************************************************************************/
include('./lib.inc.php');

$Info = $HTTP_GET_VARS['Info'];

$Tag_End="\n\n<!-- vCard Lite Version $vCardLiteVersion -->\n\n</body>\n</html>\n";
?>
<html>
<head>
<title><?php echo "$SiteName"; ?></title>
<?php include "./include/metatag.inc.php"; ?>
</head>
<?php
echo TAG_Body();
IF ($Info=="Emoticons"):
?>

	<?php echo "$FontTag4"; ?><B><?php echo "$MsgWinEmoticons"; ?></B></font>
	<p>
	<?php echo "$FontTag2"; ?><center>
	<?php echo "$MsgWinEmoticonsNote"; ?>
	<table border="0" cellspacing="8" cellpadding="1" bgcolor="#000000">
	  <tr><td>
	     <table width="170" border="0" cellspacing="0" cellpadding="3" bgcolor="#FFFFFF">
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>:-)</B></font></td><td align="center">=</td><td align="center"><img src="img/e/smiley.gif" alt=":-)" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>:-(</B></font></td><td align="center">=</td><td align="center"><img src="img/e/sad.gif" alt=":-(" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>:-P</B></font></td><td align="center">=</td><td align="center"><img src="img/e/tong.gif" alt=":-P" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>8-)</B></font></td><td align="center">=</td><td align="center"><img src="img/e/cool.gif" alt="8-)" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>8-P</B></font></td><td align="center">=</td><td align="center"><img src="img/e/cooltong.gif" alt="8-P" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>8-O</B></font></td><td align="center">=</td><td align="center"><img src="img/e/coolmouth.gif" alt="8-O" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>8-(</B></font></td><td align="center">=</td><td align="center"><img src="img/e/coolsad.gif" alt="8-(" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>%-)</B></font></td><td align="center">=</td><td align="center"><img src="img/e/dazed.gif" alt="%-)" width="16" height="16" border="0"></td></tr>
	     </table>
	  </td><td>
	     <table width="170" border="0" cellspacing="0" cellpadding="3" bgcolor="#FFFFFF">
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>%-O</B></font></td><td align="center">=</td><td align="center"><img src="img/e/dazedmouth.gif" alt="%-O" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>%-(</B></font></td><td align="center">=</td><td align="center"><img src="img/e/dazedsad.gif" alt="%-(" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>%-P</B></font></td><td align="center">=</td><td align="center"><img src="img/e/dazedtong.gif" alt="%-P" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>:-O</B></font></td><td align="center">=</td><td align="center"><img src="img/e/mouth.gif" alt=":-O" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>;-)</B></font></td><td align="center">=</td><td align="center"><img src="img/e/wink.gif" alt=";-)" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>;-O</B></font></td><td align="center">=</td><td align="center"><img src="img/e/winkmouth.gif" alt=";-O" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>;-(</B></font></td><td align="center">=</td><td align="center"><img src="img/e/winksad.gif" alt=";-(" width="16" height="16" border="0"></td></tr>
	        <tr><td align="center"><font face="Courier New,'Courier New',Courier,monospace"><B>;-P</B></font></td><td align="center">=</td><td align="center"><img src="img/e/winktong.gif" alt=";-P" width="16" height="16" border="0"></td></tr>
	     </table>
	</td></tr></table>
	</center>
	<?php echo "$FontTag2"; ?> &nbsp;&nbsp;
	<?php echo "$MsgWinEmoticonsNoteFotter"; ?>
	<p>
	<div align="center"><b><font face="'Courier New',Courier,monospace"> :<font color="#FF0000">-</font>) ->> :)</font></b></div>
	</font>
	
				</table>
			</td>
		</tr>
	</table>
	
<?php
ELSEIF ($Info=="Colors"):
?>
	<table border="0" cellpadding="1">
		<tr>
			<td bgcolor="#000000">
			<table border="0" cellspacing="1" cellpadding="3" bgcolor="#FFFFFF">
			<tr>
				<td colspan="2">
				<?php echo "$FontTag4"; ?><B>
				<?php echo "$MsgWinColors"; ?>
				</td>
			</tr>
			<tr><td width="130"><?php echo "$FontTag2"; ?><?php echo "$MsgWinName"; ?></font></td><td width="120"><?php echo "$FontTag2"; ?><?php echo "$MsgWinSample"; ?></td></tr>
			<tr><td><B> antiquewhite </td><td bgcolor="antiquewhite"> &nbsp; </td></tr>
			<tr><td><B> aqua </td><td bgcolor="aqua"> &nbsp; </td></tr>
			<tr><td><B> aquamarine </td><td bgcolor="aquamarine"> &nbsp; </td></tr>
			<tr><td><B> azure </td><td bgcolor="azure"> &nbsp; </td></tr>
			<tr><td><B> beige </td><td bgcolor="beige"> &nbsp; </td></tr>
			<tr><td><B> bisque </td><td bgcolor="bisque"> &nbsp; </td></tr>
			<tr><td><B> <?php echo "$MsgFontColorBlack"; ?>  </td><td bgcolor="black"> &nbsp; </td></tr>
			<tr><td><B> blanchedalmond </td><td bgcolor="blanchedalmond"> &nbsp; </td></tr>
			<tr><td><B> blue </td><td bgcolor="blue"> &nbsp; </td></tr>
			<tr><td><B> blueviolet </td><td bgcolor="blueviolet"> &nbsp; </td></tr>
			<tr><td><B> brown </td><td bgcolor="brown"> &nbsp; </td></tr>
			<tr><td><B> burlywood </td><td bgcolor="burlywood"> &nbsp; </td></tr>
			<tr><td><B> cadetblue </td><td bgcolor="cadetblue"> &nbsp; </td></tr>
			<tr><td><B> chartreuse </td><td bgcolor="chartreuse"> &nbsp; </td></tr>
			<tr><td><B> chocolate </td><td bgcolor="chocolate"> &nbsp; </td></tr>
			<tr><td><B> coral </td><td bgcolor="coral"> &nbsp; </td></tr>
			<tr><td><B> cornflowerblue </td><td bgcolor="cornflowerblue"> &nbsp; </td></tr>
			<tr><td><B> cornsilk </td><td bgcolor="cornsilk"> &nbsp; </td></tr>
			<tr><td><B> crimson </td><td bgcolor="crimson"> &nbsp; </td></tr>
			<tr><td><B> cyan </td><td bgcolor="cyan"> &nbsp; </td></tr>
			<tr><td><B> darkblue </td><td bgcolor="darkblue"> &nbsp; </td></tr>
			<tr><td><B> darkcyan </td><td bgcolor="darkcyan"> &nbsp; </td></tr>
			<tr><td><B> darkgoldenrod </td><td bgcolor="darkgoldenrod"> &nbsp; </td></tr>
			<tr><td><B> darkgray </td><td bgcolor="darkgray"> &nbsp; </td></tr>
			<tr><td><B> darkgreen </td><td bgcolor="darkgreen"> &nbsp; </td></tr>
			<tr><td><B> darkkhaki </td><td bgcolor="darkkhaki"> &nbsp; </td></tr>
			<tr><td><B> darkmagenta </td><td bgcolor="darkmagenta"> &nbsp; </td></tr>
			<tr><td><B> darkolivegreen </td><td bgcolor="darkolivegreen"> &nbsp; </td></tr>
			<tr><td><B> darkorange </td><td bgcolor="darkorange"> &nbsp; </td></tr>
			<tr><td><B> darkorchid </td><td bgcolor="darkorchid"> &nbsp; </td></tr>
			<tr><td><B> darkred </td><td bgcolor="darkred"> &nbsp; </td></tr>
			<tr><td><B> darksalmon </td><td bgcolor="darksalmon"> &nbsp; </td></tr>
			<tr><td><B> darkseagreen </td><td bgcolor="darkseagreen"> &nbsp; </td></tr>
			<tr><td><B> darkslateblue </td><td bgcolor="darkslateblue"> &nbsp; </td></tr>
			<tr><td><B> darkslategray </td><td bgcolor="darkslategray"> &nbsp; </td></tr>
			<tr><td><B> darkturquoise </td><td bgcolor="darkturquoise"> &nbsp; </td></tr>
			<tr><td><B> darkviolet </td><td bgcolor="darkviolet"> &nbsp; </td></tr>
			<tr><td><B> deeppink </td><td bgcolor="deeppink"> &nbsp; </td></tr>
			<tr><td><B> deepskyblue </td><td bgcolor="deepskyblue"> &nbsp; </td></tr>
			<tr><td><B> dimgray </td><td bgcolor="dimgray"> &nbsp; </td></tr>
			<tr><td><B> dodgerblue </td><td bgcolor="dodgerblue"> &nbsp; </td></tr>
			<tr><td><B> firebrick </td><td bgcolor="firebrick"> &nbsp; </td></tr>
			<tr><td><B> floralwhite </td><td bgcolor="floralwhite"> &nbsp; </td></tr>
			<tr><td><B> forestgreen </td><td bgcolor="forestgreen"> &nbsp; </td></tr>
			<tr><td><B> fuchsia </td><td bgcolor="fuchsia"> &nbsp; </td></tr>
			<tr><td><B> gainsboro </td><td bgcolor="gainsboro"> &nbsp; </td></tr>
			<tr><td><B> ghostwhite </td><td bgcolor="ghostwhite"> &nbsp; </td></tr>
			<tr><td><B> gold </td><td bgcolor="gold"> &nbsp; </td></tr>
			<tr><td><B> goldenrod </td><td bgcolor="goldenrod"> &nbsp; </td></tr>
			<tr><td><B> gray </td><td bgcolor="gray"> &nbsp; </td></tr>
			<tr><td><B> green </td><td bgcolor="green"> &nbsp; </td></tr>
			<tr><td><B> greenyellow </td><td bgcolor="greenyellow"> &nbsp; </td></tr>
			<tr><td><B> honeydew </td><td bgcolor="honeydew"> &nbsp; </td></tr>
			<tr><td><B> hotpink </td><td bgcolor="hotpink"> &nbsp; </td></tr>
			<tr><td><B> indianred </td><td bgcolor="indianred"> &nbsp; </td></tr>
			<tr><td><B> ivory </td><td bgcolor="ivory"> &nbsp; </td></tr>
			<tr><td><B> khaki </td><td bgcolor="khaki"> &nbsp; </td></tr>
			<tr><td><B> lavender </td><td bgcolor="lavender"> &nbsp; </td></tr>
			<tr><td><B> lavenderblush </td><td bgcolor="lavenderblush"> &nbsp; </td></tr>
			<tr><td><B> lawngreen </td><td bgcolor="lawngreen"> &nbsp; </td></tr>
			<tr><td><B> lemonchiffon </td><td bgcolor="lemonchiffon"> &nbsp; </td></tr>
			<tr><td><B> lightblue </td><td bgcolor="lightblue"> &nbsp; </td></tr>
			<tr><td><B> lightcoral </td><td bgcolor="lightcoral"> &nbsp; </td></tr>
			<tr><td><B> lightcyan </td><td bgcolor="lightcyan"> &nbsp; </td></tr>
			<tr><td><B> lightgoldenrodyellow </td><td bgcolor="lightgoldenrodyellow"> &nbsp; </td></tr>
			<tr><td><B> lightgreen </td><td bgcolor="lightgreen"> &nbsp; </td></tr>
			<tr><td><B> lightgrey </td><td bgcolor="lightgrey"> &nbsp; </td></tr>
			<tr><td><B> lightpink </td><td bgcolor="lightpink"> &nbsp; </td></tr>
			<tr><td><B> lightsalmon </td><td bgcolor="lightsalmon"> &nbsp; </td></tr>
			<tr><td><B> lightseagreen </td><td bgcolor="lightseagreen"> &nbsp; </td></tr>
			<tr><td><B> lightskyblue </td><td bgcolor="lightskyblue"> &nbsp; </td></tr>
			<tr><td><B> lightslategray </td><td bgcolor="lightslategray"> &nbsp; </td></tr>
			<tr><td><B> lightsteelblue </td><td bgcolor="lightsteelblue"> &nbsp; </td></tr>
			<tr><td><B> lightyellow </td><td bgcolor="lightyellow"> &nbsp; </td></tr>
			<tr><td><B> lime </td><td bgcolor="lime"> &nbsp; </td></tr>
			<tr><td><B> limegreen </td><td bgcolor="limegreen"> &nbsp; </td></tr>
			<tr><td><B> linen </td><td bgcolor="linen"> &nbsp; </td></tr>
			<tr><td><B> magenta </td><td bgcolor="magenta"> &nbsp; </td></tr>
			<tr><td><B> maroon </td><td bgcolor="maroon"> &nbsp; </td></tr>
			<tr><td><B> mediumaquamarine </td><td bgcolor="mediumaquamarine"> &nbsp; </td></tr>
			<tr><td><B> mediumblue </td><td bgcolor="mediumblue"> &nbsp; </td></tr>
			<tr><td><B> mediumorchid </td><td bgcolor="mediumorchid"> &nbsp; </td></tr>
			<tr><td><B> mediumpurple </td><td bgcolor="mediumpurple"> &nbsp; </td></tr>
			<tr><td><B> mediumseagreen </td><td bgcolor="mediumseagreen"> &nbsp; </td></tr>
			<tr><td><B> mediumslateblue </td><td bgcolor="mediumslateblue"> &nbsp; </td></tr>
			<tr><td><B> mediumspringgreen </td><td bgcolor="mediumspringgreen"> &nbsp; </td></tr>
			<tr><td><B> mediumturquoise </td><td bgcolor="mediumturquoise"> &nbsp; </td></tr>
			<tr><td><B> mediumvioletred </td><td bgcolor="mediumvioletred"> &nbsp; </td></tr>
			<tr><td><B> midnightblue </td><td bgcolor="midnightblue"> &nbsp; </td></tr>
			<tr><td><B> mintcream </td><td bgcolor="mintcream"> &nbsp; </td></tr>
			<tr><td><B> mistyrose </td><td bgcolor="mistyrose"> &nbsp; </td></tr>
			<tr><td><B> moccasin </td><td bgcolor="moccasin"> &nbsp; </td></tr>
			<tr><td><B> navajowhite </td><td bgcolor="navajowhite"> &nbsp; </td></tr>
			<tr><td><B> navy </td><td bgcolor="navy"> &nbsp; </td></tr>
			<tr><td><B> oldlace </td><td bgcolor="oldlace"> &nbsp; </td></tr>
			<tr><td><B> olive </td><td bgcolor="olive"> &nbsp; </td></tr>
			<tr><td><B> olivedrab </td><td bgcolor="olivedrab"> &nbsp; </td></tr>
			<tr><td><B> orange </td><td bgcolor="orange"> &nbsp; </td></tr>
			<tr><td><B> orangered </td><td bgcolor="orangered"> &nbsp; </td></tr>
			<tr><td><B> orchid </td><td bgcolor="orchid"> &nbsp; </td></tr>
			<tr><td><B> palegoldenrod </td><td bgcolor="palegoldenrod"> &nbsp; </td></tr>
			<tr><td><B> palegreen </td><td bgcolor="palegreen"> &nbsp; </td></tr>
			<tr><td><B> paleturquoise </td><td bgcolor="paleturquoise"> &nbsp; </td></tr>
			<tr><td><B> palevioletred </td><td bgcolor="palevioletred"> &nbsp; </td></tr>
			<tr><td><B> papayawhip </td><td bgcolor="papayawhip"> &nbsp; </td></tr>
			<tr><td><B> peachpuff </td><td bgcolor="peachpuff"> &nbsp; </td></tr>
			<tr><td><B> peru </td><td bgcolor="peru"> &nbsp; </td></tr>
			<tr><td><B> pink </td><td bgcolor="pink"> &nbsp; </td></tr>
			<tr><td><B> plum </td><td bgcolor="plum"> &nbsp; </td></tr>
			<tr><td><B> powderblue </td><td bgcolor="powderblue"> &nbsp; </td></tr>
			<tr><td><B> purple </td><td bgcolor="purple"> &nbsp; </td></tr>
			<tr><td><B> red </td><td bgcolor="red"> &nbsp; </td></tr>
			<tr><td><B> rosybrown </td><td bgcolor="rosybrown"> &nbsp; </td></tr>
			<tr><td><B> royalblue </td><td bgcolor="royalblue"> &nbsp; </td></tr>
			<tr><td><B> saddlebrown </td><td bgcolor="saddlebrown"> &nbsp; </td></tr>
			<tr><td><B> salmon </td><td bgcolor="salmon"> &nbsp; </td></tr>
			<tr><td><B> sandybrown </td><td bgcolor="sandybrown"> &nbsp; </td></tr>
			<tr><td><B> seagreen </td><td bgcolor="seagreen"> &nbsp; </td></tr>
			<tr><td><B> seashell </td><td bgcolor="seashell"> &nbsp; </td></tr>
			<tr><td><B> sienna </td><td bgcolor="sienna"> &nbsp; </td></tr>
			<tr><td><B> silver </td><td bgcolor="silver"> &nbsp; </td></tr>
			<tr><td><B> skyblue </td><td bgcolor="skyblue"> &nbsp; </td></tr>
			<tr><td><B> slateblue </td><td bgcolor="slateblue"> &nbsp; </td></tr>
			<tr><td><B> slategray </td><td bgcolor="slategray"> &nbsp; </td></tr>
			<tr><td><B> snow </td><td bgcolor="snow"> &nbsp; </td></tr>
			<tr><td><B> springgreen </td><td bgcolor="springgreen"> &nbsp; </td></tr>
			<tr><td><B> steelblue </td><td bgcolor="steelblue"> &nbsp; </td></tr>
			<tr><td><B> tan </td><td bgcolor="tan"> &nbsp; </td></tr>
			<tr><td><B> teal </td><td bgcolor="teal"> &nbsp; </td></tr>
			<tr><td><B> thistle </td><td bgcolor="thistle"> &nbsp; </td></tr>
			<tr><td><B> tomato </td><td bgcolor="tomato"> &nbsp; </td></tr>
			<tr><td><B> turquoise </td><td bgcolor="turquoise"> &nbsp; </td></tr>
			<tr><td><B> violet </td><td bgcolor="violet"> &nbsp; </td></tr>
			<tr><td><B> wheat </td><td bgcolor="wheat"> &nbsp; </td></tr>
			<tr><td><B> <?php echo "$MsgFontColorWhite"; ?>  </td><td bgcolor="white"> &nbsp; </td></tr>
			<tr><td><B> whitesmoke </td><td bgcolor="whitesmoke"> &nbsp; </td></tr>
			<tr><td><B> yellow </td><td bgcolor="yellow"> &nbsp; </td></tr>
			<tr><td><B> yellowgreen </td><td bgcolor="yellowgreen"> &nbsp; </td></tr>
			</table>
			</td>
		</tr>
	</table>
	</font>
	
<?php 
ELSEIF ($Info=="Notify"):
	?>
	<?php echo "$FontTag4"; ?><div align="center"><center>
	<B><?php echo "$MsgNotify"; ?>:</B></font><br>
	</center></div>
	<p>
	<?php echo "$FontTag2"; ?>
	<blockquote><?php echo "$MsgWinNotify"; ?></blockquote>
	</font>
	
<?php 
ELSEIF ($Info=="Background"):
?>
	<table border="0" cellpadding="1">
		<tr>
			<td bgcolor="#000000">
				<table border="0" cellspacing="1" cellpadding="3" bgcolor="#FFFFFF">
					<tr>
						<td colspan="2">
						<?php echo "$FontTag4"; ?><B>
						<?php echo "$MsgWinBackground"; ?>
						</td>
					</tr>
					<tr><td width="90"><?php echo "$FontTag2"; ?><?php echo "$MsgWinSample"; ?></font></td><td width="160"><?php echo "$FontTag2"; ?><?php echo "$MsgWinName"; ?></font></td></tr>
	
	<?php
	if ($SpecialLanguage == "Y")
	{
		$patternlist = $DB_site->query(" SELECT * FROM $dbtbl_pattern ORDER BY pattern_file ");
	}else{
		$patternlist = $DB_site->query(" SELECT * FROM $dbtbl_pattern ORDER BY pattern_name ");
	}
	while ($pattern = $DB_site->fetch_array($patternlist))
	{
		$patternfile = $pattern['pattern_file'];
	        $patternname = $pattern['pattern_name'];
		// Display list fo pattern
		echo "<tr><td><img src='$card_imageURL/$patternfile' width='60' height='60' border='1' align='middle'> </td><td> <B>$patternname </B> </td></tr>\n";
	}
	?>
				</table>
			</td>
		</tr>
	</table>
<?php 
ELSEIF ($Info=="Stamp"):
?>
	<table border="0" cellpadding="1">
		<tr>
			<td bgcolor="#000000">
				<table border="0" cellspacing="1" cellpadding="3" bgcolor="#FFFFFF">
					<tr>
						<td colspan="2">
						<?php echo "$FontTag4"; ?><B>
						<?php echo "$MsgWinStamp"; ?>
						</td>
					</tr>
					<tr><td width="90"><?php echo "$FontTag2"; ?><?php echo "$MsgWinSample"; ?></font></td><td width="160"><?php echo "$FontTag2"; ?><?php echo "$MsgWinName"; ?></font></td></tr>
	
<?php
	if ($SpecialLanguage == "Y")
	{
		$query = " SELECT * FROM $dbtbl_stamp ORDER BY stamp_file ";
	}else{
		$query = " SELECT * FROM $dbtbl_stamp ORDER BY stamp_name ";
	}
	$stamplist = $DB_site->query($query);
	while ($stamp = $DB_site->fetch_array($stamplist))
	{
		$stampfile = $stamp['stamp_file'];
		$stampname = $stamp['stamp_name'];
		echo( "<tr><td>	<img src=\"$card_imageURL/$stampfile\" border=0 align=\"MIDDLE\"> </td><td bgcolor=\"#FFFFFF\"> <B>$stampname </B> </td></tr>\n");
	}
?>
				</table>
			</td>
		</tr>
	</table>
<?php 
ELSEIF ($Info=="Fonts"):
?>
	<ul>
		<?php echo "$FontTag2"; ?>
		<?php echo "$MsgWinFontsNote"; ?>
		<p>
	</UL>
	<table width="100%" border="0" cellpadding="1">
		<tr>
			<td bgcolor="#000000">
				<table width="100%" border="0" cellspacing="1" cellpadding="3" bgcolor="#FFFFFF">
					<tr>
						<td colspan="2">
						<?php echo "$FontTag4"; ?><B>
						<?php echo "$MsgWinFonts"; ?>
						</td>
					</tr>
					<tr><td width="120"><?php echo "$FontTag2"; ?><?php echo "$MsgWinName"; ?></font></td><td width="120"><?php echo "$FontTag2"; ?><?php echo "$MsgWinSample"; ?></font></td></tr>
	<?php
	// Font List
	sort ($fontlist);
	reset ($fontlist);
	while (list ($key, $val) = each ($fontlist))
	{
		echo "<tr><td><font face=\"$val\" size=\"2\">$val </font></td><td><font face=\"$val\" size=\"2\">$MsgWinSampleString</td></tr>\n";
	}
	//echo FontFaceTestString(Arial);
	?>
					 
				</table>
			</td>
		</tr>
	</table>
<?php 
ENDIF;
echo "<p align=\"center\"><a href=\"javascript:window.close()\"><img src=\"img/icon_close.gif\" border=\"0\"  align=\"ABSMIDDLE\" ALT=\"$MsgCloseWindow\"></A></p>";
exit;
?>