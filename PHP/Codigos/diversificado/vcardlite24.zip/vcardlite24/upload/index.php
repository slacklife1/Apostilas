<?php
/***************************************************************************
 *   script               : vCard LITE
 *   copyright            : (C) 2001-2003 Belchior Foundry
 *   website              : www.belchiorfoundry.com
 *
 *   This program is freeware software; you can�t redistribute it under
 *   any circumstance without explicit authorization from Belchior Foundry.
 *   http://www.belchiorfoundry.com/
 *
 ***************************************************************************/
include('./lib.inc.php');
$new_icon = '<img src="img/icon_new.gif" border="0" alt="">';

if(!empty($HTTP_GET_VARS['ref']))
{
	$card_ref= $DB_site->query_first("SELECT ecard_rname,ecard_remail,ecard_sname,ecard_semail FROM $dbtbl_user WHERE ecard_id='".addslashes($HTTP_GET_VARS['ref'])."' ");
	@setcookie("vcecard_sname",  $card_ref['ecard_rname'], time()+3600,'/');
	@setcookie("vcecard_semail", $card_ref['ecard_remail'], time()+3600,'/');
	@setcookie("vcecard_rname",  $card_ref['ecard_sname'], time()+900,'/');
	@setcookie("vcecard_remail", $card_ref['ecard_semail'], time()+900,'/');
}
dovcardliteheader();

if ($SpecialLanguage == "Y")
{
	$query = "SELECT * FROM $dbtbl_cat ORDER BY cat_id";
}else{
	$query = "SELECT * FROM $dbtbl_cat ORDER BY cat_name";
}
$result = $DB_site->query($query);
$number = $DB_site->num_rows($result);

if ($number==0):
	echo TagFont($SiteFontFace,3,1,1,$MsgNoCardsinDB);
	dovcardlitefooter();

ELSE:
	$List_Categories ="\n";
	$interval = date("Y-m-d",mktime (0,0,0,date("m") ,date("d")-$site_new_days,date("Y")));
	//echo $interval;
	while  ($row  =  $DB_site->fetch_array($result))
	{
		/* CATEGORY LIST */
		$List_Categories.="\n<li>";
		$List_Categories.="<a href='$ProgFullURL/gallerybrowser.php?cat_id=$row[cat_id]'>$row[cat_name]</a>";
		if($DB_site->query_first("SELECT card_date FROM $dbtbl_card WHERE cat_id='$row[cat_id]' AND card_date >= '$interval' "))
		{
			$List_Categories .= $new_icon;
		}
	}
	
	$Upload_Option ="\n";
	if($AllowUploadFile =='Y')
	{
		$Upload_Option.= "<a href='upload.php'>$MsgUploadYourOwnFileTitle</a>";
		$T_Upload_Option_Note = "$MsgUploadYourOwnFileInfo";
	}
	
	$List_TopPostcards="\n";
	if($AllowListTopGallery =='Y')
	{
		$List_TopPostcards ="$MsgTop $GalleryListTop $MsgPostcards <br>\n";
		$i=0;
		$limit = $GalleryListTop + 5;
		$query2 = $DB_site->query("
			SELECT $dbtbl_card.card_image, $dbtbl_card.card_thm, $dbtbl_card.card_template, $dbtbl_card.card_date, $dbtbl_stats.card_image, COUNT(*) AS count
			FROM $dbtbl_stats,$dbtbl_card
			WHERE $dbtbl_stats.card_thm=$dbtbl_card.card_thm
			GROUP BY $dbtbl_card.card_image
			ORDER BY count DESC
			LIMIT $limit
			");
			
		while ($row  =  $DB_site->fetch_array($query2))
		{
			if ( !empty($row['card_image']) )
			{
				$link = "f=$row[card_image]";
				$andlink = '&amp;';
			}
			if (!empty($row['card_template']) )
			{
				$link .= $andlink.'template='.$row['card_template'];
			}
			/* TOP LIST html code */
			$List_TopPostcards.= "\n <a href='$ProgFullURL/create.php?$link'><img src='$card_imageURL/$row[card_thm]' border='0' width='$GalleryThumbWidth' height='$GalleryThumHeight' hspace='2' vspace='2'></a><br>".
			gethml_newbutton($row['card_date']). "<br>";
			$i++;
			if($i == $GalleryListTop)
			{
				break;
			}
			// echo $row[total];
		}
	}
	
	$T_MsgCategories = TagFont($SiteFontFace,0,0,0,$MsgCategories);
	$List_Categories = TagFont($SiteFontFace,0,0,0,$List_Categories);
	$Upload_Option = TagFont($SiteFontFace,0,0,0,$Upload_Option);
	$List_TopPostcards = TagFont($SiteFontFace,0,0,0,$List_TopPostcards);
	$T_Upload_Option_Note = TagFont($SiteFontFace,0,0,0,$T_Upload_Option_Note);
	
	$t->set_file(array("body" => "gallery_page.ihtml"));
	// Set 'value' and 'name' to each element's value and name:
	$t->set_var(array(
	'T_Categories' => $T_MsgCategories,
	'T_List_TopPostcards' => $List_TopPostcards,
	'T_List_Categories' => $List_Categories,
	'T_Upload_Option' => $Upload_Option,
	'T_Upload_Option_Note' => $T_Upload_Option_Note
	));
	$t->parse("output","body");
	$t->p("output");
ENDIF;

dovcardlitefooter();
?>