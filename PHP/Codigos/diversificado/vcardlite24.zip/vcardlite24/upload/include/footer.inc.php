
<!-- FOOTER HTML CODE or OTHER BANNER :) -->
<br>
<br>
<div align="center">
Sample Footer Text<br>
[to edit this footer text, open 'footer.inc.php' file, inside include directory]
</div>
<!-- FOOTER HTML CODE or OTHER BANNER -->

<!-- COPYRIGHTS : YOU CAN'T EDIT IT - License agreement -->
	<p align="center"><font face="Arial" size="1">Powered by vCard Lite v2.4.2<br>&copy;2003, <a href="http://www.belchiorfoundry.com/" target="_blank">Belchior Foundry.</a></font></p>
<!-- /COPYRIGHTS - License agreement  -->
</body>
</html>