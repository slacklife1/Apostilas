<?php
// adapted 'db class for mysql' from PHPLIB
// this class is used in all scripts
// do NOT fiddle unless you know what you are doing

class DB_Sql_vc
{
	var $database = "";

	var $link_id  = 0;
	var $query_id = 0;
	var $record   = array();
	var $errdesc    = "";
	var $errno   = 0;
	var $reporterror = 1;
	var $server   = "localhost";
	var $user     = "root";
	var $password = "";

	function connect()
	{
		global $usepconnect;
		// connect to db server
		if ( 0 == $this->link_id )
		{
			if ($this->password=="")
			{
				if ($usepconnect==1)
				{
					$this->link_id=mysql_pconnect($this->server,$this->user);
				}else{
					$this->link_id=mysql_connect($this->server,$this->user);
				}
			}else{
				if ($usepconnect==1)
				{
					$this->link_id=mysql_pconnect($this->server,$this->user,$this->password);
				}else{
					$this->link_id=mysql_connect($this->server,$this->user,$this->password);
				}
			}
			if (!$this->link_id)
			{
				$this->halt("Link-ID == false, connect failed");
			}
			if ($this->database!="")
			{
				if(!mysql_select_db($this->database, $this->link_id))
				{
					$this->halt("cannot use database ".$this->database);
				}
			}
		}
	}

	function geterrdesc()
	{
		$this->error=mysql_error();
		return $this->error;
	}

	function geterrno()
	{
		$this->errno=mysql_errno();
		return $this->errno;
	}

	function select_db($database="")
	{
		// select database
		if ($database!="")
		{
			$this->database=$database;
		}
		if(!mysql_select_db($this->database, $this->link_id))
		{
			$this->halt("cannot use database ".$this->database);
		}
	}

	function query($query_string)
	{
		global $query_count,$showqueries;
		// do query
		if ($showqueries)
		{
			echo "Query: $query_string\n";
			global $pagestarttime;
			$pageendtime=microtime();
			$starttime=explode(" ",$pagestarttime);
			$endtime=explode(" ",$pageendtime);
			$totaltime=$endtime[0]-$starttime[0];
			$totaltime=$totaltime+($endtime[1]-$starttime[1]);
			echo "Time before: $totaltime\n";
		}
		$this->query_id = mysql_query($query_string,$this->link_id);
		if (!$this->query_id)
		{
			$this->halt("Invalid SQL: ".$query_string);
		}
		$query_count++;
		if ($showqueries)
		{
			$pageendtime=microtime();
			$starttime=explode(" ",$pagestarttime);
			$endtime=explode(" ",$pageendtime);
			$totaltime=$endtime[0]-$starttime[0];
			$totaltime=$totaltime+($endtime[1]-$starttime[1]);
			echo "Time after: $totaltime\n\n";
		}
		return $this->query_id;
	}

	function fetch_array($query_id=-1,$query_string="")
	{
		// retrieve row
		if ($query_id!=-1)
		{
			$this->query_id=$query_id;
		}
		if ( isset($this->query_id) )
		{
			$this->record = mysql_fetch_array($this->query_id);
		}else{
			if ( isset($query_string) )
			{
				$this->halt("Invalid query id (".$this->query_id.") on this query: $query_string");
			}else{
				$this->halt("Invalid query id ".$this->query_id." specified");
			}
		}
		return $this->record;
	}

	function free_result($query_id=-1)
	{
		// retrieve row
		if ($query_id!=-1)
		{
			$this->query_id=$query_id;
		}
		//return @mysql_free_result($this->query_id);
	}

	function query_first($query_string)
	{
		// does a query and returns first row
		$query_id = $this->query($query_string);
		$returnarray = $this->fetch_array($query_id, $query_string);
		$this->free_result($query_id);
		return $returnarray;
	}

	function data_seek($pos,$query_id=-1)
	{
		// goes to row $pos
		if ($query_id!=-1)
		{
			$this->query_id=$query_id;
		}
		return mysql_data_seek($this->query_id, $pos);
	}

	function num_rows($query_id=-1)
	{
		// returns number of rows in query result
		if ($query_id!=-1)
		{
			$this->query_id=$query_id;
		}
		return mysql_num_rows($this->query_id);
	}

	function affected_rows($query_id=-1)
	{
		// returns number of rows in query result
		if ($query_id!=-1)
		{
			$this->query_id=$query_id;
		}
		return mysql_affected_rows($this->query_id);
	}
	
	function num_fields($query_id=-1)
	{
		// returns number of fields in query
		if ($query_id!=-1)
		{
			$this->query_id=$query_id;
		}
		return mysql_num_fields($this->query_id);
	}

	function insert_id()
	{
		// returns last auto_increment field number assigned
		return mysql_insert_id($this->link_id);
	}

	function count_records($table)
	{
		// returns total rows in table
		return mysql_result(mysql_query("select count(*) as num from $table"),0,"num");
	}

	function close()
	{
		return mysql_close($this->link_id);
	}
	function halt($msg)
	{
		$this->errdesc=mysql_error();
		$this->errno=mysql_errno();
		// prints warning message when there is an error
		if ($this->reporterror==1)
		{
		$message ="Database error: \n$msg\n";
		$message.="mysql error: $this->errdesc\n";
		$message.="mysql error number: $this->errno\n";
		$message.="Date: ".date("Y/m/d - h:i:s A")."\n";
		$message.="Script: ".getenv("REQUEST_URI")."\n";
		$message.="Referer: ".getenv("HTTP_REFERER")."\n";
		echo "</td></tr></table>\n<p>\n<pre>\n$message \n";
		//      echo "\n<!-- $message -->\n";
		die("");
		}
	}

}
?>