<!-- META, STYLE or SCRIPT TAG HERE -->

<meta http-equiv="CONTENT-TYPE" content="text/html; charset=iso-8859-1">
<style type="text/css">
a { text-decoration : none; }
td,th,p,br,body,li{
	font-size: 12px;
	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
}
form,input,option,select,textarea{
	font-size: 12px;
	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
}
input{
	font-weight : bold;
}
</style>
<!-- /META, STYLE or SCRIPT TAG HERE -->
