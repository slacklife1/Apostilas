<!-- HEADER HTML CODE or OTHER BANNER :) -->
<div align="center">
Sample Header Text<br>
[to edit text, open 'header.inc.php' file, located inside include directory]
</div>
<br>
<br>
<!-- HEADER HTML CODE or OTHER BANNER :) -->
