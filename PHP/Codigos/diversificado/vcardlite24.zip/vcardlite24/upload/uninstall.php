<?php
/***************************************************************************
 *   script               : vCard LITE
 *   copyright            : (C) 2001-2003 Belchior Foundry
 *   website              : www.belchiorfoundry.com
 *
 *   This program is freeware software; you can�t redistribute it under
 *   any circumstance without explicit authorization from Belchior Foundry.
 *   http://www.belchiorfoundry.com/
 *
 ***************************************************************************/
include('./lib.inc.php');

$action = $HTTP_GET_VARS['action'];

@header ("Pragma: no-cache");
//dovcardliteheader();
if($action == 'drop_yes')
{
$result 	= $DB_site->query("DROP TABLE IF EXISTS $dbtbl_card");
$result 	= $DB_site->query("DROP TABLE IF EXISTS $dbtbl_cat");
$result 	= $DB_site->query("DROP TABLE IF EXISTS $dbtbl_pattern");
$result 	= $DB_site->query("DROP TABLE IF EXISTS $dbtbl_music");
$result 	= $DB_site->query("DROP TABLE IF EXISTS $dbtbl_stamp");
$result 	= $DB_site->query("DROP TABLE IF EXISTS $dbtbl_stats");
$result 	= $DB_site->query("DROP TABLE IF EXISTS $dbtbl_user");
$result 	= $DB_site->query("DROP TABLE IF EXISTS $dbtbl_spam");
$result 	= $DB_site->query("DROP TABLE IF EXISTS $dbtbl_slog");
echo <<<BFT

<b>Done</b>
<p><a href="install.php">Install vCard Lite again</a>

BFT;
}else{

echo <<<BFT
<b>You will delete ALL data from your database. Are you sure</b> ?<br>
<a href="$PHP_SELF?action=drop_yes">Yes! I�m sure</a>
BFT;

}

?>
