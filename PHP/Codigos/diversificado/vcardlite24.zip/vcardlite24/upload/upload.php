<?php
/***************************************************************************
 *   script               : vCard LITE
 *   copyright            : (C) 2001-2003 Belchior Foundry
 *   website              : www.belchiorfoundry.com
 *
 *   This program is freeware software; you can�t redistribute it under
 *   any circumstance without explicit authorization from Belchior Foundry.
 *   http://www.belchiorfoundry.com/
 *
 ***************************************************************************/
include('./lib.inc.php');

@header ("Pragma: no-cache");
dovcardliteheader();

$mode = $HTTP_POST_VARS['mode'];

if ($AllowUploadFile !="Y")
{
	echo TagFont($SiteFontFace,3,1,1,"<p>$MsgFileUploadNotAllowed<p>");
	dohtmlbackbutton();
	dovcardlitefooter();
}

if ($mode == 'upload_file' )
{
	/*
	File Name $attachment_name
	File Size $attachment_size
	File Type $attachment_type
	*/
	$MaxSize 	= $MaxSizeFileUploaded*1000;
	$servertime 	= time();
	$second 	= date("s", ($servertime));
	$minute 	= date("i", ($servertime));
	$hour 		= date("H", ($servertime));
	$day		= date("d", ($servertime));
	$month 		= date("m", ($servertime));
	$year 		= date("Y", ($servertime));
	$picdate = "$year-$month-$day-$hour$minute$second";
	if(!empty($HTTP_POST_FILES['attachment']))
	{
		$file_type 	= getextension($HTTP_POST_FILES['attachment']['name']); 
		//$pic_name 	= "$picdate.$file_type";
		if($file_type=='gif'){
			$pic_name ="$picdate.gif";
		}elseif($file_type=='jpg' or $file_type=='jpeg'){
			$pic_name ="$picdate.jpg";
		}elseif($file_type=='swf'){
			$pic_name ="$picdate.swf";
		}else{
			$pic_name ="";
		} 
		if($pic_name =="$picdate." or $pic_name =="")
		{
			// Not valide file
			echo TagFont($SiteFontFace,3,1,1,"<blockquote><p>$MsgErrorFileExtension<p></blockquote>");
			dohtmlbackbutton();
			dovcardlitefooter();
		}
		$ImgTag = TAG_Image($pic_name,"$card_imageURL/$UploadedDir");
		if($HTTP_POST_FILES['attachment']['size'] > $MaxSize)
		{
			echo TagFont($SiteFontFace,3,1,1,"<p>$MsgFileBiggerThan $MaxSizeFileUploaded Kbytes!<p>");
			dohtmlbackbutton();
			dovcardlitefooter();
		}
		if($safeupload == 1)
		{
			if(function_exists("is_uploaded_file"))
			{
				if(is_uploaded_file($HTTP_POST_FILES['attachment']['tmp_name']))
				{
					if(move_uploaded_file($HTTP_POST_FILES['attachment']['tmp_name'], "$card_imagePath/$UploadedDir/$pic_name"))
					{
						chmod("$card_imagePath/$UploadedDir/$pic_name",octdec(666));
					}
				}
			}
		}else{
			@copy($HTTP_POST_FILES['attachment']['tmp_name'], "$card_imagePath/$UploadedDir/$pic_name") 
	        	or die("No copy! Verify permission of your $UploadedDir directory OR read vCard Lite documentation for more info!"); 
		}
        }
	echo "<div align=\"center\"><a href=\"$ProgFullURL/create.php?f=$UploadedDir/$pic_name\">$ImgTag<br>";
	echo TagFont($SiteFontFace,3,1,1,"$MsgFileUseFile");
	echo "</a></div>";
	dovcardlitefooter();
	
	
}else{
	echo TagFont($SiteFontFace,2,1,0,"<blockquote><br><br>$MsgFileAllowed <p><br>$MsgFileMaxSizeAllowed $MaxSizeFileUploaded Kybtes.</blockquote>");
?>

<table width="90%" cellspacing="4" align="center">
<FORM METHOD="post" ACTION="<?php echo "$ProgFullURL/upload.php"; ?>" ENCTYPE="multipart/form-data">
<input type="hidden" name="mode" value="upload_file">
<tr>
	<td><?php echo TagFont($SiteFontFace,2,1,0,"$MsgFileSelect"); ?></td>
	<td><input type="file" name="attachment" size="30"></td>
</tr>
<tr>
	<td colspan="2" align="center"><input type="submit" name="submit" value="<?php echo "$MsgFileSend"; ?>" width="150"></td>
</tr>
</table>


<?php
dovcardlitefooter();
}
?>
