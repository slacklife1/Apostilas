<?php
include('./lib.inc.php');
checkrefer();
$cat_id = $HTTP_GET_VARS['cat_id'];
$page = $HTTP_GET_VARS['page'];

dovcardliteadminheader();
dohtmladminheader();

if( empty($page) )
{
	$page = 1;
}
$prev_page = $page - 1;
$next_page = $page + 1;
$page_start = ($Admin_Images_Page * $page) - $Admin_Images_Page; 

$query = ("
	SELECT *
	FROM $dbtbl_card
	WHERE cat_id='$cat_id'
	");

$result = $DB_site->query($query);
$num_rows = $DB_site->num_rows($result);

if ($num_rows <= $Admin_Images_Page)
{
	$num_pages = 1;
}elseif (($num_rows % $Admin_Images_Page) == 0){
	$num_pages = ($num_rows / $Admin_Images_Page);
}else{
	$num_pages = ($num_rows / $Admin_Images_Page) + 1;
}
$num_pages = (int) $num_pages;

if (($page > $num_pages) || ($page < 0))
{
	echo TagFont($SiteFontFace,3,1,1,$MsgInvalidePageNumber);
	echo TagBackBar(1,$MsgBack);
	dovcardliteadminfooter();
}

$query = $query . " LIMIT $page_start, $Admin_Images_Page";  
$result = $DB_site->query($query); 
$i="0";		

IF ($num_rows==$i):
	echo TagFont($SiteFontFace,3,1,1,$MsgNoCardsinDB);
	echo TagBackBar(1,$MsgBack);
	exit;
ELSE:

$query2 = "SELECT * FROM $dbtbl_cat WHERE cat_id='$cat_id' ";
$result2 	= $DB_site->query($query2);
$myrow2 	= $DB_site->fetch_array($result2);
$catname2 	= $myrow2['cat_name'];
?>

<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
- <?php echo "$catname2 : $num_rows $MsgPostcards";?>
</b></font></td></tr></table></td></tr></table>
<P>
<table width="80%" border="0" cellspacing="2" cellpadding="8" align="center">
<tr>
<?php
$icounter ="0";
while ($row = $DB_site->fetch_array($result))
{
	echo "<TD align=\"center\" valign=\"middle\"><a href=\"gallery.php?mode=post_edit&card_id=$row[card_id]&ses=$ses\"><img src=\"$card_imageURL/$row[card_thm]\" BORDER=\"1\"><br>$MsgAdminEdit</a></tr>\n";
	$icounter++;
	if($icounter == $Admin_gallery_cols)
	{
		echo "</tr><tr>\n"; $icounter="0";
	}
}
ENDIF;
?>
</tr></table>
<p>
<div align="center">
<?php
// Previous Link

for ($i = 1; $i <= $num_pages; $i++)
{
	if ($i != $page)
	{
		$nav_bar .= " <a href=\"gallerybrowser.php?ses=$ses&cat_id=$cat_id&page=$i\">$i</a> ";
	}else{
		$nav_bar .= " [ $i ] ";
	}
}
	echo TagFont($SiteFontFace,2,0,1,"<b>$nav_bar</b> <br><a href=\"gallery.php?ses=$ses\">$MsgBackCatMain</a>");
?>
</div>
<BR>
<BR>
<?php
dovcardliteadminfooter();
exit;
?>
