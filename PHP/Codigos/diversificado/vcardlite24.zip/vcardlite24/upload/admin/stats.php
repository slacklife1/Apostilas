<?php
include('./lib.inc.php');
checkrefer();
dovcardliteadminheader();
dohtmladminheader();

$totalnum = $DB_site->count_records($dbtbl_stats);

if ($HTTP_POST_VARS['mode'] == 'stats_restart')
{
	$result = $DB_site->query("DELETE FROM $dbtbl_stats ");
	echo "$TagStartText";
	if ($result)
	{
		echo "$MsgAdminStatsDbEmpty";
	}else{
		echo ("$MsgAdminStatsDbNoEmpty".
		"<P>Error: " . mysql_error());
	}
	echo "$TagEndText";
	$mode = '';
}
if (empty($mode))
{
?>

<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#DFDFDF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
<?php echo "$MsgAdminCardStatTitle : $SiteName"; ?>
</b></font></td></tr></table></td></tr></table>
<br>   <small><?php echo "($MsgAdminCardStatTitle: $totalnum $MsgPostcards)"; ?></small>
<table width="100%" border="1" cellspacing="0" cellpadding="2" bordercolor="#C0C0C0">
<tr><th colspan="3" bgcolor="#DFDFDF"><?php echo "$MsgTop $ListTop $MsgAdminControlImageFile"; ?></th></tr>
<tr><td width="10%"><?php echo "$MsgPosition"; ?></td><td width="10%"><?php echo "$MsgHits"; ?></td><td><?php echo "$MsgAdminControlImageFile"; ?></td></tr>
<?php
$i=1;
$query = $DB_site->query("
	SELECT count(*) AS count,card_image
	FROM $dbtbl_stats
	GROUP BY card_image
	ORDER BY count DESC LIMIT $ListTop
	");

while ($row  =  $DB_site->fetch_array($query))
{
	echo "<tr><td valign=top>".$i."</td><td nowrap valign=top>";
	echo $row['count'];
	echo "</td><td valign=top>&nbsp;";
	//echo $row[card_image];
	echo "".cexpr($row['card_image']=="","uploaded or template","<a HREF=\"$card_imageURL/$row[card_image]\">$row[card_image]</a>")."";
	echo "</td></tr>"; 
	$i++; 
}
?>
</table>
<br>

<table width="100%" border="1" cellspacing="0" cellpadding="2" bordercolor="#C0C0C0">
<tr><th colspan="3" bgcolor="#DFDFDF"><?php echo "$MsgTop $ListTop $MsgAdminControlStampFile"; ?></th></tr>
<tr><td width="10%"><?php echo "$MsgPosition"; ?></td><td width="10%"><?php echo "$MsgHits"; ?></td><td><?php echo "$MsgAdminControlStampFile"; ?></td></tr>
<?php
$i="1";
$query = $DB_site->query("
	SELECT count(*) AS count,stamp_file
	FROM $dbtbl_stats
	GROUP BY stamp_file
	ORDER BY count DESC LIMIT $ListTop
	");

while ($row  =  $DB_site->fetch_array($query))
{
	echo "<tr><td valign=top>".$i."</td><td nowrap valign=top>";
	echo $row['count'];
	echo "</td><td valign=top>&nbsp;";
	echo "".cexpr($row['stamp_file']=="","without stamp","<a HREF=\"$card_imageURL/$row[stamp_file]\">$row[stamp_file]</a>")."";
	echo "</td></tr>"; 
	$i++; 
}
?>
</table>
<br>

<table width="100%" border="1" cellspacing="0" cellpadding="2" bordercolor="#C0C0C0">
<tr><th colspan="3" bgcolor="#DFDFDF"><?php echo "$MsgTop $ListTop $MsgAdminControlMusicFile"; ?></th></tr>
<tr><td width="10%"><?php echo "$MsgPosition"; ?></td><td width="10%"><?php echo "$MsgHits"; ?></td><td><?php echo "$MsgAdminControlMusicFile"; ?></td></tr>
<?php
$i="1";
$query = $DB_site->query("
	SELECT count(*) AS count,sound_file
	FROM $dbtbl_stats
	GROUP BY sound_file
	ORDER BY count DESC LIMIT $ListTop
	");

while ($row  =  $DB_site->fetch_array($query))
{
	echo "<tr><td valign=top>".$i."</td><td nowrap valign=top>";
	echo $row['count'];
	echo "</td><td valign=top>&nbsp;";
	echo "".cexpr($row['sound_file']=="","without sound","<a HREF=\"$sound_fileURL/$row[sound_file]\">$row[sound_file]</a>")."";
	echo "</td></tr>"; 
	$i++; 
}
?>
</table>
<br>

<table width="100%" border="1" cellspacing="0" cellpadding="2" bordercolor="#C0C0C0">
<tr><th colspan="3" bgcolor="#DFDFDF"><?php echo "$MsgTop $ListTop $MsgAdminControlPatternFile"; ?></th></tr>
<tr><td width="10%"><?php echo "$MsgPosition"; ?></td><td width="10%"><?php echo "$MsgHits"; ?></td><td><?php echo "$MsgAdminControlPatternFile"; ?></td></tr>
<?php
$i="1";
$query = $DB_site->query("
	SELECT count(*) AS count,pattern_file
	FROM $dbtbl_stats
	GROUP BY pattern_file
	ORDER BY count DESC LIMIT $ListTop
	");

while ($row  =  $DB_site->fetch_array($query))
{
	echo "<tr><td valign=top>".$i."</td><td nowrap valign=top>";
	echo $row['count'];
	echo "</td><td valign=top>&nbsp;";
	echo "".cexpr($row['pattern_file']=="","without background","<a HREF=\"$card_imageURL/$row[pattern_file]\">$row[pattern_file]</a>")."";
	echo "</td></tr>"; 
	$i++; 
}
?>
</table>
<br>


<table width="100%" border="1" cellspacing="0" cellpadding="2" bordercolor="#C0C0C0">
<tr><th colspan="3" bgcolor="#DFDFDF"><?php echo "$MsgTop $ListTop $MsgAdminTemplateFile"; ?></th></tr>
<tr><td width="10%"><?php echo "$MsgPosition"; ?></td><td width="10%"><?php echo "$MsgHits"; ?></td><td><?php echo "$MsgAdminTemplateFile"; ?></td></tr>
<?php
$i="1";
$query = $DB_site->query("
	SELECT count(*) AS count,card_template
	FROM $dbtbl_stats
	GROUP BY card_template
	ORDER BY count DESC LIMIT $ListTop
	");

while ($row  =  $DB_site->fetch_array($query))
{
	echo "<tr><td valign=top>".$i."</td><td nowrap valign=top>";
	echo $row['count'];
	echo "</td><td valign=top>&nbsp;";
	echo "".cexpr($row['card_template']=="","without template","<a HREF=\"$ProgFullURL/templates/$row[card_template].ihtml\">$row[card_template]</a>")."";
	echo "</td></tr>"; 
	$i++; 
}
?>
</table>
<br>

<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#DFDFDF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
<?php echo "$MsgAdminCardStatTitle : $MsgAdminStatsRestart"; ?>
</b></font></td></tr></table></td></tr></table>
<blockquote><?php
echo "<font color=\"#FF0000\"><b>$MsgAdminWarning</b></font> $MsgAdminStatsNote";
?>
<form action="stats.php?ses=<?php echo $ses; ?>" method="post">
<input type="hidden" name="mode" value="stats_restart">
<input type="submit" value="<?php echo "$MsgAdminStatsRestart"; ?>">
</form>
</blockquote>
<p></p>
<br>
<br>
<?php
dovcardliteadminfooter();
exit;
}
?>
