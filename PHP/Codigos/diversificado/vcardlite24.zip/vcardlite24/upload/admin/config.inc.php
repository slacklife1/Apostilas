<?php
/* vCard LITE version 2.4.2 - last updated 01-feb-2003 */
////////////////////////////////////////////////////////////////////////////////////
// Database Variables:
////////////////////////////////////////////////////////////////////////////////////
$hostname		="localhost";		// database host
$dbUser			="root";		// database username
$dbPass			="root";			// database password
$dbName			="vcardlite24"; 		// database name

$dbtbl_user		="card_user";		// card user table name
$dbtbl_music 	="card_sound";		// card sound table name
$dbtbl_stamp 	="card_stamp";		// card stamp table name
$dbtbl_pattern 	="card_pattern";	// card pattern/background image table name
$dbtbl_stats 	="card_stat";		// card stats table name
$dbtbl_card 	="card_img";		// card images table name
$dbtbl_cat 		="card_imgcat";		// card categorie table name
$dbtbl_spam		="card_spam";		// card antispam table name
$dbtbl_slog		='card_slog';		// card service log table name

////////////////////////////////////////////////////////////////////////////////////
// Control Panel Access:
////////////////////////////////////////////////////////////////////////////////////
$login_admin		= "admin";		// admin center login
$password_admin		= "admin1";		// admin center password

////////////////////////////////////////////////////////////////////////////////////
// Language Variables:
////////////////////////////////////////////////////////////////////////////////////
$PostLanguageFile ="en.lang.inc.php";	// determines what language set to use

$SpecialLanguage ="N";	// You will use a special translated language?
				//   Some languages will make a error in creation page
				//   because the MySQL will order pattern and music names!
				//   maybe your language don't be understanded by MySQL.
				//   Se more info in documentation.

////////////////////////////////////////////////////////////////////////////////////
// Site Variables:
////////////////////////////////////////////////////////////////////////////////////
$ProgFullURL ="http://localhost/vcardlite24/upload";
 			// Full URL where scripts is placed "WITHOUT trailing slash*
			//   ex.: http://www.domain.com/ecard

$sound_fileURL ="http://localhost/vcardlite24/upload/music";
		 	// Full URL to your music dir *WITHOUT trailing slash*
			//   ex.: http://www.domain.com/ecard/music

$card_imageURL ="http://localhost/vcardlite24/upload/images";
			// Full URL to your image dir *WITHOUT trailing slash*
			//   ex.: http://www.domain.com/ecard/images
			// ATTENTION!!!ATTENTION!!!ATTENTION!!!ATTENTION!!!
			// Upload image feature MAY not work on yours system because
			// PHP safe mode, read manual for more info.

$card_imagePath ="F:/LOCALHOST/vcardlite24/upload/images";
			// Full PATH to your image dir *WITHOUT trailing slash*
			// See your phpinfo.php file to see your directory path
			// NEVER use backslashes (\). Always use forward slashes (/),
			// for all operating systems, INCLUDING Windows
			// ATTENTION: it is the directory PATH to images directory
			// ex:
			//  unix,linux,freebsd
			//     /home/virtual/site281/fst/var/www/html/vcard/images
			//     /home/mysitename/public_html/vcard/images
			//  windows
			//     F:/intepub/www/vcardlite24/upload/images

$UploadedDir ="uploaded";
			// ATTENTION!!!ATTENTION!!!ATTENTION!!!ATTENTION!!!
			// set directory permission to CHMOD 777.
			// Edit only the directory name here.
			//
			// notes:
			// The Directory NAME where users uploaded file is stored.
			// The name of subdirectory that MUST be inside
			// card_imageURL  *WITHOUY trailing slash*
			//   ex.: http://www.domain.com/ecard/images/myuploaded
			// in this case de $UploadedDir = 'myuploaded';

$AdminAddress = "your@emailaddress.com";			// webmaster/postmaster e-mail address
$SiteName = "Your vCard Lite Site Name";			// Card Service Name
$SiteURL = "http://localhost/vcardlite24/upload/";		// Full URL to Card Service Main Page
									//   ex.: http://www.domain.com/ecard/

$SiteDateFormate ="1"; 	// Date Formate: 1 = dd/mm/yyyy and 2 = mm/dd/yyyy
				//   attention: the translation file! Looking for
				//   $MsgDateFormat
				//   to fit with this information
				
$service_log_entries = 5;
				/* Number of entries showed into service log */

// LAYOUT OPTIONS
////////////////////////////////////////////////////////////////////////////////////
// Macromedia Flash attributes
$FlashWidth ="320";	//Default Width size of flash animation
$FlashHeight ="280";	//Default Height size of flash animation

// Site default Font Face
$SiteFontFace ="Arial";	// You can use font combo
					//   ex.: $SiteFontFace ="Verdana,Arial,Helvetica";

// Font Face option List
$fontlist = array (
	"Arial",
	"Arial Black",
	"Brush Script MT",
	"Comic Sans MS",
	"Courier",
	"Courier New",
	"Garamond",
	"Georgia",
	"Helvetica,sans-serif",
	"Impact",
	"Lucida Handwriting",
	"MS Sans Serif",
	"MS Serif",
	"News Gothic MT",
	"Palantino",
	"Times New Roman",
	"Verdana");
			// Just add or remove a font from the list option: add ou delete "The Font Name"
			//   from the list above. More info in README.txt
			// You can use font combo but pay attention read README.txt!!!

// BODY TAG attributes
$SiteBGCOLOR ="#FFFFFF";
$SiteTEXT ="#000000";
$SiteLINK ="#0000FF";
$SiteVLINK ="#800080";
$SiteALINK ="#FF0000";
$SiteMARGINWIDTH ="5";  	// IExplorer marginwidth  = Nestcape leftmargin attribute 
$SiteMARGINHEIGHT ="5";  	// IExplorer marginheight = Nestcape topmargin attribute
$SiteBACKGROUND = "";
$DefaultBGImage ="background.gif";	// If you don't want allow BG Image set a default postcard's
						//   background image file here. If you don't want any image
						//   leave blank.

// CREATION PAGE
////////////////////////////////////////////////////////////////////////////////////
$FormBGcolor		="#E3E3B5";	// Form Baground Color
$FormTableWidth		="420";		// in pixel or percent
$FormFieldSize		="25";  	// It's good to edit if you use a special language
$FormAreaColSize	="25";  	// It's good to edit if you use a special language
$FormFontFace		="Times New Roman";
$FormFontSize		="3";

// GALLERY PAGE
////////////////////////////////////////////////////////////////////////////////////
$Gallery_ScriptName	="index";	// If you want use other name to
					// main page of gallery. Input here
					// *WITHOUT* .php extension.
					// and rename the file
					// ex.: "gallery" if you like rename to gallery.php

$AllowListTopGallery	="Y";		// Display Top list in gallery mode?

$GalleryThumbWidth	="50";		// Width size of Thumb image
$GalleryThumHeight	="50";		// Height size of Thumb image

$GalleryListTop		="10";		// TOP XX of stat page

$gallery_table_width ="70%";		// pixel or percent.
$gallery_cols		="3";		// Number of Coluns in Gallery browser mode

$Images_Page 		="6";		// Number of images per page

// EMAIL MESSGE TEXTS
////////////////////////////////////////////////////////////////////////////////////
//      {recipient_name} = Recipient's name
//      {sender_name}    = Sender's name
//      {today_date}     = Today Date, usefull to notify e-mail
//	{pickup_link}	 = Pick up URL link
//  ATTENTION!!!!
//  - You CAN'T use any QUOTATION MARK (")
////////////////////////////////////////////////////////////////////////////////////

// NOTIFICATION e-mail to recipients
$Recp_Subject ="You have a Virtual Postcard.";
$Recp_Message ="
Hi {recipient_name},


 {sender_name} has sent you a virtual greeting card from 
Your Site Name

  To pickup your card, just click on the URL below, or copy
and paste it into your browser's address bar:

{pickup_link}

Your Site Name
____________________________________________________________
Get your own vCard Lite virtual greeting card system from
Belchior Foundry at: http://www.belchiorfoundry.com/ ";

// "'
// NOTIFICATION e-mail to sender
$Notification_Subject ="{recipient_name} has pickup your card";
$Notification_Message ="
Hi {sender_name},


 {recipient_name} has pickup today, {today_date}, the virtual
greeting card that you sent from You Site Name.


Your Site Name
____________________________________________________________
Get your own vCard Lite virtual greeting card system from
Belchior Foundry at: http://www.belchiorfoundry.com/
";

// ADMIN PAGE OPTIONS
////////////////////////////////////////////////////////////////////////////////////
$WantListOfCard ="N";	// Want a list of card that will be deleted
				//   in admin page? If your postcard service
				//   has a great active I counsel you set "N"

$ListTop		="20";	// TOP XX of stat page

$Admin_gallery_cols	="2";	// Number of Coluns in Gallery Admin

$Admin_Images_Page 	="6";	// Number of images per page Admin

// END USER SERVICE OPTIONS
////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////

// UPLOAD
// 	ATTENTION!!!
// 	Upload image feature MAY not work on Windows systems.
//
// 	If you get error "No copy!" under Unix or Windows. Disable this feature because it may
//      caused by PHP configuration from your webhosting provider (security razion)
//
$AllowUploadFile ="Y";			// Allow user upload his your image/flash file to create
						//   postcard?
$MaxSizeFileUploaded ="40";			// 40 = 40Kbytes


$AllowMultipleRecp = "Y";			// Allow users select multiple recipients to send
						// a postcard ?

// STAMP
$AllowChooseStamp ="N";			// Allow users choose different stamp?
$DefaultStampImg ="defaultstamp.gif";	// Set a default stamp image here if no stamp image
						//   is selected by user. If you don't want any stamp by default
						//   leave blank.

// NOTIFICATION
$AllowChooseNotify ="Y";			// Allow users choose be notify when card is retrieved?

// BACKGROUND IMAGE
$AllowChooseBGimage	="Y";			// Allow users choose patter/wallpaper/background image?

// BACKGROUND SOUND
$AllowBGmusic ="Y";			// Allow users choose background music?

// ADVANCE SEND
$AllowAdvanceSend ="Y";			// Allow users choose send postcard in advacend date?
						//   You may have access to CRON (shell account)
						//   or use a url monitoring like netwhistle. See README.txt
						//   to see more info.
						//   If users use multiple recipients, don't allow advance
						//   send feature :-)
$HowAdvanceDateAllowd = 30;			// How long advanced day you want allow?
						//   XX days format


// TEMPLATES
$UseOnlyThisTemplate ="";			// If you want use only ONE template? Set the default
						//   template, if you don't want this feature, leave blank
						//   to offer the 3 default layout template.
						// Pay attention to include:
						//   &template=YouTemplateName
						//   create.php?f=pic001.jpg&template=XXXX
						//   to link url IF you want use some different template!!!!
						//   Remember: Only the name withou ".ihtmnl"

// NEW ICON
$site_new_days = 15;			// How long the "new icon" must be displayed under a new postcard
						//  added to vcard ? formate XX days
						
// Anti SPAM system
$antispam_check = "Y";			// Active AntiSpam check?
$antispam_allow_entries	= 15;			// How many cards per hour user cand send from your website?
						
$antispam_policy = "To prevent abuse <br> 
of this service by spammers you can <br>
only send 15 cards per hour";
						// The message about your anti-spam policy
						
						
////////////////////////////////////////////////////////////////////////////////////
// vCard Lite Version Note:
////////////////////////////////////////////////////////////////////////////////////
$safeupload		= 1;	// IF you want run vCard Lite in a server with PHP 3 you need safe mode=OFF
						//   without safe mode disabled in PHP 3 the upload feature won�t work.
						// If you run in a server with PHP 4 with Safe mode= ON you don�t need
						//   worry about active safe mode. Just set safeupload = "1" and
						//   upload feature will work fine.
?>