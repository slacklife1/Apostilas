<?php
include('./lib.inc.php');
checkrefer();
dovcardliteadminheader();
?>
<table width="95%" cellspacing="2" cellpadding="3" align="center" bgcolor="#ECECEC">
<tr><td><a href="http://www.belchiorfoundry.com/" target="_blank"><img src="../img/icon_powered.gif" width="102" height="47" alt="" border="0" align="middle"></a></td></tr>
<tr>
	<td><font face="<?php echo "$SiteFontFace"; ?>" size="2"><a href="main.php?ses=<?php echo $ses; ?>" target="main"><b><?php echo "$MsgMain"; ?></b></a></font></td>
</tr>
<tr>
	<td><font face="<?php echo "$SiteFontFace"; ?>" size="2"><a href="gallery.php?ses=<?php echo $ses; ?>" target="main"><b><?php echo "$MsgGallery"; ?></b></a></font></td>
</tr>
<tr>
	<td><font face="<?php echo "$SiteFontFace"; ?>" size="2"><a href="music.php?ses=<?php echo $ses; ?>" target="main"><b><?php echo "$MsgMusic"; ?></b></a></font></td>
</tr>
<tr>
	<td><font face="<?php echo "$SiteFontFace"; ?>" size="2"><a href="stamp.php?ses=<?php echo $ses; ?>" target="main"><b><?php echo "$MsgStamp"; ?></b></a></font></td>
</tr>
<tr>
	<td><font face="<?php echo "$SiteFontFace"; ?>" size="2"><a href="pattern.php?ses=<?php echo $ses; ?>" target="main"><b><?php echo "$MsgPattern"; ?></b></a></font></td>
</tr>
<tr>
	<td><font face="<?php echo "$SiteFontFace"; ?>" size="2"><a href="stats.php?ses=<?php echo $ses; ?>" target="main"><b><?php echo "$MsgStats"; ?></b></a></font></td>
</tr>
<tr>
	<td><font face="<?php echo "$SiteFontFace"; ?>" size="2"><a href="log.php?ses=<?php echo $ses; ?>" target="main"><b><?php echo "$MsgSLog"; ?></b></a></font></td>
</tr>
<tr>
	<td><font face="<?php echo "$SiteFontFace"; ?>" size="2"><a href="phpinfo.php?ses=<?php echo $ses; ?>" target="main"><b><?php echo "$MsgPHPInfo"; ?></b></a></font></td>
</tr>
<tr>
	<td><font face="<?php echo "$SiteFontFace"; ?>" size="2"><a href="http://www.belchiorfoundry.com/forum/" target="_blank"><b><?php echo "$MsgvCardLiteCommunity"; ?></b></a></font></td>
</tr>
</table>
</body>
</html>
 