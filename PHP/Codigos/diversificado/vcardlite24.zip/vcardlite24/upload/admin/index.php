<?php
include('./lib.inc.php');
if( empty($HTTP_POST_VARS['action']) )
{
?>
<table width="200" border="1" cellspacing="5" cellpadding="5" align="center" bgcolor="#C0C0C0">
<tr>	<form action="index.php" method="post">
	<th>login:</th>
	<td><input type="text" name="login"></td>
</tr>
<tr>
	<th>password:</th>
	<td><input type="password" name="password"></td>
</tr>
<tr>
	<td colspan="2" align="center">
	<input type="hidden" name="action" value="login">
	<input type="submit" value="   LOG IN   ">
	</form></td>
</tr>
</table>
<?php
	dovcardliteadminfooter();
	exit;
}
if($HTTP_POST_VARS['action'] =='login' && $si==md5($HTTP_POST_VARS['login'].$HTTP_POST_VARS['password']))
{
	$ses = md5($HTTP_POST_VARS['login'].$HTTP_POST_VARS['password']);
	//checkrefer();
?><html>
<head>
	<title>vCard Lite</title>
</head>
<frameset cols="150,*" rows="*" border="0" frameborder="0"> 
  <frame src="menu.php?ses=<?php echo $ses; ?>" name="menu">
  <frame src="main.php?ses=<?php echo $ses; ?>" name="main">
</frameset>
<noframes>
<body bgcolor="#FFFFFF">

</body>
</noframes>
</html>
<?php
	exit;
}else{
?>
	<div align="center"><h2>Forbidden Access</h2><br>try login again</div>
<?php
	exit;
}
?>