<?php
include('./lib.inc.php');
checkrefer();

dovcardliteadminheader();
dohtmladminheader();
// Category
if($HTTP_GET_VARS['mode'] == "cat_edit")
{
	$cat_info = $DB_site->query_first(" SELECT * FROM $dbtbl_cat WHERE cat_id='$HTTP_GET_VARS[cat_id]' ");
	extract($cat_info);
?>
	<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
	<?php echo "$MsgAdminModify : $MsgCategory"; ?>
	</b></font></td></tr></table></td></tr></table>
	<ul>
		<table>
		<form method="post" action="gallery.php?ses=<?php echo $ses; ?>">
		<tr>
			<td><b><?php echo "$MsgCategory"; ?> : </b></td>
			<td><input type="text" name="cat_name" value="<?php echo $cat_name; ?>"></td>
		</tr>
		<tr>
			<td colspan="2" align="center">
		<P>
		<input type="hidden" name="cat_id" value="<?php echo $cat_id; ?>">
		<input type="hidden" name="mode" value="cat_modify">
		<input type="submit" value="<?php echo "$MsgAdminModify"; ?>" width="200">
		</form></td>
		</tr>
		</table>
	</UL>

<?php
	echo TagBackBar(1,$MsgBacktoSection);
	
	exit;
}

if ($HTTP_POST_VARS['mode'] == "cat_modify")
{
	$query = ("UPDATE $dbtbl_cat SET cat_name='$HTTP_POST_VARS[cat_name]' WHERE cat_id='$HTTP_POST_VARS[cat_id]' ");
	$result = $DB_site->query($query);
	echo "$TagStartText";
	if ($result)
	{
		echo "$MsgCategory $MsgAdminModified";
	}else{
		echo ("$MsgCategory $MsgAdminNoModified".
		"<P>Error: " . mysql_error());
	}
	echo "$TagEndText";
	$mode ='';
}

if ($HTTP_GET_VARS['mode'] == "cat_delete")
{
	$result = $DB_site->query("DELETE FROM $dbtbl_cat WHERE cat_id='$HTTP_GET_VARS[cat_id]' ");
	$result2 = $DB_site->query("DELETE FROM $dbtbl_card WHERE cat_id='$HTTP_GET_VARS[cat_id]' ");
	
	echo "$TagStartText";
	if ($result)
	{
		echo "$MsgCategory $MsgAdminDeleted";
	}else{
		echo ("$MsgCategory $MsgAdminNoDeleted".
		"<P>Error: " . mysql_error());
	}
	echo "$TagEndText";
	$mode ='';

}

if ($HTTP_POST_VARS['mode'] =="cat_include")
{
	$cat_name = RemoveSpecialChar($HTTP_POST_VARS['cat_name']);

	echo "$TagStartText";
	// check if is a valide data
	if (empty($cat_name))
	{
		echo "$MsgCategory $MsgAdminFormFieldEmpty";
		echo "$TagEndText";
		echo TagBackBar(1,$MsgBacktoSection);
		exit();
	}
	$result = $DB_site->query(" INSERT INTO $dbtbl_cat (cat_name) VALUES ('$HTTP_POST_VARS[cat_name]') ");
	if ($result)
	{
		echo "$MsgCategory $MsgAdminIncluded";
	}else{
		echo ("$MsgCategory $MsgAdminNoIncluded".
		"<P>Error: " . mysql_error());
	}
	echo "$TagEndText";
	$mode ='';
}


// Postcard
if ($HTTP_GET_VARS['mode'] == "post_edit")
{
	$card_info = $DB_site->query_first("SELECT * FROM $dbtbl_card WHERE card_id='$HTTP_GET_VARS[card_id]' ");
	extract($card_info);
?>
	<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
	<?php echo "$MsgAdminModify : $MsgPostcards"; ?>
	</b></font></td></tr></table></td></tr></table>
	<ul>
		<table>
		<form action="gallery.php?ses=<?php echo $ses; ?>" method="post">
		<tr>
			<td><b><?php echo "$MsgCategory"; ?> : </b></td>
			<td><select name="cat_id">
<?php
	if ($SpecialLanguage == "Y")
	{
		$query = "SELECT * FROM $dbtbl_cat ORDER BY cat_id ";
	}else{
		$query = "SELECT * FROM $dbtbl_cat ORDER BY cat_name ";
	}
	$catlist_array = $DB_site->query($query);
	while ($cat_list_item = $DB_site->fetch_array($catlist_array))
	{
		echo "<option value=\"$cat_list_item[cat_id]\"";
		if($cat_id == $cat_list_item['cat_id'])
		{
			echo " selected"; 
		}
		echo ">$cat_list_item[cat_name]</option>\n";
	}
?>
		</select>
		</td>
	</tr>
	<tr>
		<td><b><?php echo "$MsgAdminControlPostImgFile"; ?> : </b></td>
		<td><input type="text" name="card_image" value="<?php echo $card_image; ?>" size="35"></td>
	</tr>
	<tr>
		<td><b><?php echo "$MsgAdminControlPostThmFile"; ?> : </b></td>
		<td><input type="text" name="card_thm" value="<?php echo $card_thm; ?>" size="35"></td>
	</tr>
	<tr>
		<td><b><?php echo "$MsgAdminControlPostTemplate"; ?> : </b></td>
		<td><input type="text" name="card_template" value="<?php echo $card_template; ?>" size="35"></td>
	</tr>
	<tr>
		<td align="center">
		<P><br>
		<input type="hidden" name="card_id" value="<?php echo $card_id; ?>">
		<input type="hidden" name="mode" value="post_modify">
		<input type="submit" value="<?php echo "$MsgAdminModify"; ?>" width="200">
		</form>
		</td>
		<td align="center">
		<P><br>
		<form method="post" action="gallery.php?ses=<?php echo $ses; ?>">
		<input type="hidden" name="card_id" value="<?php echo "$card_id"; ?>">
		<input type="hidden" name="mode" value="post_delete">
		<input type="submit" value="<?php echo "$MsgAdminDelete"; ?>" width="200">
		</form>
		</td>
	</tr>
	</table>
</UL>

<?php
	echo "$TagEndText";
	echo TagBackBar(1,$MsgBacktoSection);
	
	exit;
}

if ($HTTP_POST_VARS['mode'] == "post_modify")
{
	$HTTP_POST_VARS['card_template'] = eregi('.ihtml',$HTTP_POST_VARS['card_template'])? str_replace('.ihtml','',$HTTP_POST_VARS['card_template']) : $HTTP_POST_VARS['card_template'];
	$query = ("
		UPDATE $dbtbl_card
		SET cat_id='$HTTP_POST_VARS[cat_id]', card_image='$HTTP_POST_VARS[card_image]',  card_thm='$HTTP_POST_VARS[card_thm]', card_template='$HTTP_POST_VARS[card_template]'
		WHERE card_id='$HTTP_POST_VARS[card_id]'
		");
	$result = $DB_site->query($query);
	echo "$TagStartText";
	if ($result)
	{
		echo "$MsgPostcards $MsgAdminModified";
	}else{
		echo ("$MsgPostcards $MsgAdminNoModified".
		"<P>Error: " . mysql_error());
	}
	echo "$TagEndText";
	echo TagBackBar(3,$MsgBacktoSection);
	
	exit;
}

if ($HTTP_POST_VARS['mode'] == "post_delete")
{
	$query = ("DELETE FROM $dbtbl_card WHERE card_id='$HTTP_POST_VARS[card_id]' ");
	$result = $DB_site->query($query);
	echo "$TagStartText";
	if ($result)
	{
		echo "$MsgPostcards $MsgAdminDeleted";
	}else{
		echo ("$MsgPostcards $MsgAdminNoDeleted".
		"<P>Error: " . mysql_error());
	}
	echo "$TagEndText";
	echo TagBackBar(2,$MsgBacktoSection);
	
	exit;
}

if ($HTTP_POST_VARS['mode'] == "post_include")
{
	$cat_id = RemoveSpecialChar($HTTP_POST_VARS['cat_id']);
	$card_image = RemoveSpecialChar($HTTP_POST_VARS['card_image']);
	$card_thm = RemoveSpecialChar($HTTP_POST_VARS['card_thm']);
	
	$card_template = RemoveSpecialChar($HTTP_POST_VARS['card_template']);
	$card_template = eregi('.ihtml',$card_template)? str_replace('.ihtml','',$card_template) : $card_template;
	
	echo "$TagStartText";
	if (empty($cat_id))
	{
		echo "$MsgPostcards $MsgAdminFormFieldEmpty";
		echo "$TagEndText";
		echo TagBackBar(1,$MsgBacktoSection);
		exit();
	}
	if (empty($card_thm))
	{
		echo "$MsgAdminControlPostThmFile $MsgAdminFormFieldEmpty";
		echo "$TagEndText";
		echo TagBackBar(1,$MsgBacktoSection);
		exit();
	}
	$query = ("
		INSERT
		INTO $dbtbl_card ( cat_id, card_image, card_thm, card_template,card_date)
		VALUES ('$cat_id','$card_image','$card_thm','$card_template',CURDATE())
		");
	$result = $DB_site->query($query);
	if ($result)
	{
		echo "$MsgPostcards $MsgAdminIncluded";
	}else{
		echo ("$MsgPostcards $MsgAdminNoIncluded".
		"<P>Error: " . mysql_error());
	}
	echo "$TagEndText";
	$mode ='';
}

if (empty($mode))
{
?>
<!-- MAIN PAGE --><!-- MAIN PAGE --><!-- MAIN PAGE --><!-- MAIN PAGE -->

<!-- CATEGORY -->
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#DFDFDF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
<?php echo "$MsgAdminCategoryControlTitle"; ?>
</b></font></td></tr></table></td></tr></table>
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
- <?php echo "$MsgAdminEdit/$MsgAdminDelete/$MsgAdminBrowser : $MsgCategory"; ?>
</b></font></td></tr></table></td></tr></table>
<ul>
<?php
if ($SpecialLanguage == "Y")
{
	$query = "SELECT * FROM $dbtbl_cat ORDER BY cat_id ";
}else{
	$query = "SELECT * FROM $dbtbl_cat ORDER BY cat_name ";
}
$catlist_array = $DB_site->query($query);
while ($cat_info = $DB_site->fetch_array($catlist_array))
{
	echo "<li>[<a href=\"gallery.php?mode=cat_edit&cat_id=$cat_info[cat_id]&ses=$ses\">$MsgAdminLinkEdit</a>] 
	[<a href=\"gallery.php?mode=cat_delete&cat_id=$cat_info[cat_id]&ses=$ses\">$MsgAdminLinkDelete</a>] 
	[<a href=\"gallerybrowser.php?mode=cat_browser&cat_id=$cat_info[cat_id]&ses=$ses\">$MsgAdminLinkBrowser</a>] 
	- <b>$cat_info[cat_name]</b> ";
}
?>
	<BR>
</UL>

<P>
<!-- ADD: CATEGORY -->
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
- <?php echo "$MsgAdminInclude : $MsgCategory"; ?>
</b></font></td></tr></table></td></tr></table>
<ul>
	<table>
	<form method="post" action="gallery.php?ses=<?php echo $ses; ?>">
	<tr>
		<td><b><?php echo "$MsgAdminControlCatName"; ?> : </b></td>
		<td><input type="text" name="cat_name"></td>
	</tr>
	<tr>
		<td colspan="2" align="center">
	<P>
	<input type="hidden" name="mode" value="cat_include" size="35">
	<input type="submit" value="<?php echo "$MsgAdminInclude"; ?>" width="200">
	</form></td>
	</tr>
	</table>
</UL>
<!-- /ADD: CATEGORY -->

<p>

<!-- ADD: POSTCARDS -->
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
- <?php echo "$MsgAdminInclude : $MsgPostcards"; ?>
</b></font></td></tr></table></td></tr></table>
<ul>
	<table>
	<form method="post" action="gallery.php?ses=<?php echo $ses; ?>">
	<tr>
		<td><b><?php echo "$MsgCategory"; ?> : </b></td>
		<td><select name="cat_id">
<?php
if ($SpecialLanguage == "Y")
{
	$query = "SELECT * FROM $dbtbl_cat ORDER BY cat_id ";
}else{
	$query = "SELECT * FROM $dbtbl_cat ORDER BY cat_name ";
}
$catlist_array = $DB_site->query($query);
while ($cat_info = $DB_site->fetch_array($catlist_array))
{
	// Display list of soundfile
	echo( "<option value=\"$cat_info[cat_id]\" >$cat_info[cat_name]</option>\n");
}
?>
		</select>
		</td>
	</tr>
	<tr>
		<td><b><?php echo "$MsgAdminControlPostImgFile"; ?> : </b></td>
		<td><input type="text" name="card_image" size="35"></td>
	</tr>
	<tr>
		<td><b><?php echo "$MsgAdminControlPostThmFile"; ?> : </b></td>
		<td><input type="text" name="card_thm" size="35"></td>
	</tr>
	<tr>
		<td><b><?php echo "$MsgAdminControlPostTemplate"; ?> : </b></td>
		<td><input type="text" name="card_template" size="35"></td>
	</tr>
	<tr>
		<td colspan="2" align="center">
		<P>
		<input type="hidden" name="mode" value="post_include" size="35">
		<input type="submit" name="post_include" value="<?php echo "$MsgAdminInclude"; ?>" width="200">
		</form>
		</td>
	</tr>
	</table>
</UL>
<!-- /ADD: POSTCARDS -->

<?php
dovcardliteadminfooter();

exit;
}

?>
