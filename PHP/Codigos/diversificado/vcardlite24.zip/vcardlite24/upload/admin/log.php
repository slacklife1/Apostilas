<?php
include('./lib.inc.php');
checkrefer();
dovcardliteadminheader();
dohtmladminheader();

if ($HTTP_POST_VARS['mode'] == 'log_restart')
{
	$result = $DB_site->query("DELETE FROM $dbtbl_slog ");
	echo "$TagStartText";
	if ($result)
	{
		echo "$MsgAdminStatsDbEmpty";
	}else{
		echo ("$MsgAdminStatsDbNoEmpty".
		"<P>Error: " . mysql_error());
	}
	echo "$TagEndText";
	$mode = '';
}
if (empty($mode))
{

$entries_per_page = $service_log_entries;
$page = empty($HTTP_GET_VARS['page']) ? 1 : $HTTP_GET_VARS['page'];
$prev_page = $page - 1;
$next_page = $page + 1;
$page_start = ($entries_per_page * $page) - $entries_per_page;
$query = " SELECT * FROM $dbtbl_slog ORDER BY date ASC ";
$result = $DB_site->query($query);
$num_rows = $DB_site->num_rows($result);
if( $num_rows <= $entries_per_page )
{
	$num_pages = 1;
	}elseif( ($num_rows % $entries_per_page) == 0 ){
		$num_pages = ($num_rows / $entries_per_page);
	}else{
	$num_pages = ($num_rows / $entries_per_page) + 1;
}
$num_pages = (int) $num_pages;

$query = $query . " LIMIT $page_start, $entries_per_page";
$list = $DB_site->query($query); 

$totalnum = $num_rows;

?>

<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#DFDFDF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
<?php echo "$MsgAdminCardStatTitle: $MsgSLog"; ?>
</b></font></td></tr></table></td></tr></table>
<br>   <small><?php echo "($MsgAdminCardStatTitle: $totalnum $MsgAdminEntries)"; ?></small>
<table width="100%" border="1" cellspacing="0" cellpadding="2" bordercolor="#C0C0C0">
<tr><th colspan="8" bgcolor="#DFDFDF"><?php echo $MsgSLog; ?></th></tr>
<tr>
	<td><?php echo $MsgAdminLogRname; ?></td>
	<td><?php echo $MsgAdminLogRemail; ?></td>
	<td><?php echo $MsgAdminLogSname; ?></td>
	<td><?php echo $MsgAdminLogSemail; ?></td>
	<td><?php echo $MsgAdminLogSip; ?></td>
	<td><?php echo $MsgAdminLogDate; ?></td>
	<td><?php echo $MsgAdminLogSentDate; ?></td>
	<td><?php echo $MsgAdminLogEcard; ?></td>
</tr>
<?php

$now = date('Y-m-d H:m:s');
while ($row  =  $DB_site->fetch_array($list))
{
	echo '<tr><td valign="top">'.stripslashes($row['rname']).'</td>';
	echo '<td valign="top">'.$row['remail'].'</td>';
	echo '<td valign="top">'.stripslashes($row['sname']).'</td>';
	echo '<td valign="top">'.$row['semail'].'</td>';
	echo '<td valign="top">'.$row['sip'].'</td>';
	echo '<td valign="top">'.$row['date'].'</td>';
	echo ($row['sentdate'] > $now )? '<td valign="top">'.$row['sentdate'].'</td>' : '<td valign="top" bgcolor="#ffffcc">'.$row['sentdate'].'</td>';
	echo '<td valign="top">'.$row['ecard_id'].'</td>';
	echo '</tr>';
}
?>

</table>
<br>
<?php
if ($prev_page)
{
	$tmp_nav.= "&nbsp;<a href='./log.php?page=$prev_page&ses=$ses'>$MsgPrevious</a>\n";  
}
for ($i = 1; $i <= $num_pages; $i++){
	if ($i != $page)
	{
		$tmp_nav.= "&nbsp;<a href='./log.php?page=$i&ses=$ses'>$i</a>\n";
	}else{
		$tmp_nav.= "&nbsp;<b>[ $i ]</b>\n";
	}
}
if ($page != $num_pages)
{
	$tmp_nav.= "&nbsp;<a href='./log.php?page=$next_page&ses=$ses'>$MsgNext</a>\n<BR><BR>";
}
?>

<div align="center"><?php echo $tmp_nav; ?></div>

<br>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#DFDFDF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
<?php echo "$MsgSLog : $MsgAdminStatsRestart"; ?>
</b></font></td></tr></table></td></tr></table>
<blockquote><?php
echo "<font color=\"#FF0000\"><b>$MsgAdminWarning</b></font> $MsgAdminLogNote";
?>
<form action="log.php?ses=<?php echo $ses; ?>" method="post">
<input type="hidden" name="mode" value="log_restart">
<input type="submit" value="<?php echo "$MsgAdminLogRestart"; ?>">
</form>
</blockquote>
<p></p>
<br>
<br>
<?php
dovcardliteadminfooter();
exit;
}
?>
