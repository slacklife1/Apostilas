<?php
include('./lib.inc.php');
checkrefer();
phpinfo();
?>