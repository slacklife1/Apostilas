<?php
include('./lib.inc.php');
checkrefer();

dovcardliteadminheader();
dohtmladminheader();
// Stamp
if( $HTTP_POST_VARS['mode'] == 'delete')
{
	$result = $DB_site->query("DELETE FROM $dbtbl_stamp WHERE stamp_file='$HTTP_POST_VARS[stamp_file]' ");
	echo "$TagStartText";
	if ($result)
	{
		echo "$MsgAdminControlStampFile $MsgAdminDeleted";
	}else{
		echo "$MsgAdminControlStampFile $MsgAdminNoDeleted".
		"<P>Error: " . mysql_error();
	}
	echo "$TagEndText";
	$mode ='';
}

if( $HTTP_POST_VARS['mode'] == 'include' )
{
	$stamp_file = RemoveSpecialChar($HTTP_POST_VARS[stamp_file]);
	$stamp_name = RemoveSpecialChar($HTTP_POST_VARS[stamp_name]);
	echo "$TagStartText";
	// check if is a valide data
	if (empty($stamp_file))
	{
		echo "$MsgAdminControlStampFile $MsgAdminFormFieldEmpty";
		echo "$TagEndText";
		echo TagBackBar(1,$MsgBacktoSection);
		dovcardliteadminfooter();
		exit();
	}
	if (empty($stamp_name))
	{
		echo "$MsgAdminControlStampName $MsgAdminFormFieldEmpty";
		echo "$TagEndText";
		echo TagBackBar(1,$MsgBacktoSection);
		dovcardliteadminfooter();
		exit();
	}
	$result = $DB_site->query(" INSERT INTO $dbtbl_stamp ( stamp_file, stamp_name) VALUES ('$stamp_file','$stamp_name') ");
	if ($result)
	{
		echo "$MsgAdminControlStampFile $MsgAdminIncluded";
	}else{
		echo "$MsgAdminControlStampFile $MsgAdminNoIncluded".
		"<P>Error: " . mysql_error();
	}
	echo "$TagEndText";
	$mode = '';
}

if (empty($mode))
{
?>

<!-- STAMP -->
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#DFDFDF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
<?php echo "$MsgAdminStampControlTitle"; ?>
</b></font></td></tr></table></td></tr></table>
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
- <?php echo "$MsgAdminDelete"; ?>
</b></font></td></tr></table></td></tr></table>
<ul>
	<form method="post" action="stamp.php?ses=<?php echo $ses; ?>">
<?php
if ($SpecialLanguage == "Y")
{
	$query = "SELECT * FROM $dbtbl_stamp ORDER BY stamp_file ";
}else{
	$query = "SELECT * FROM $dbtbl_stamp ORDER BY stamp_name ";
}
$icounter = 0;
$stamplist_array = $DB_site->query($query);
while ($stamp_info = $DB_site->fetch_array($stamplist_array))
{
	echo( "<input type=\"radio\" name=\"stamp_file\" value=\"$stamp_info[stamp_file]\"><img src=\"$card_imageURL/$stamp_info[stamp_file]\" ALT=\"$stamp_info[stamp_name]\" WIDTH=40 HEIGHT=40 BORDER=0 ALIGN=\"MIDDLE\"> &nbsp; \n");
      	$icounter++;
	if($icounter == 6){ echo "<P>\n"; $icounter=0;}
}
?>
	<P>
	<input type="hidden" name="mode" value="delete">
	<input type="submit" value="<?php echo "$MsgAdminDelete"; ?>" width="200">
	</form>
</UL>
<P>
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
- <?php echo "$MsgAdminInclude"; ?>
</b></font></td></tr></table></td></tr></table>
<ul>
	<table>
	<form method="post" action="stamp.php?ses=<?php echo $ses; ?>">
	<tr>
		<td><b><?php echo "$MsgAdminControlStampFile"; ?> : </b></td>
		<td><input type="text" name="stamp_file"></td>
	</tr>
	<tr>
		<td><b><?php echo "$MsgAdminControlStampName"; ?> : </b></td>
		<td><input type="text" name="stamp_name"></td>
	</tr>
	<tr>
		<td colspan="2" align="center">
	<b><?php echo "$MsgAdminNote"; ?>:</b> <?php echo "$MsgAdminNoteMust"; ?> <b><?php echo "$card_imageURL"; ?></b>
	&nbsp;&nbsp;&nbsp;
	<P>
	<input type="hidden" name="mode" value="include">
	<input type="submit" value="<?php echo "$MsgAdminInclude"; ?>" width="200">
	</form></td>
	</tr>
	</table>
</UL>
<!-- /STAMP -->

<?php
dovcardliteadminfooter();
exit;
}
?>