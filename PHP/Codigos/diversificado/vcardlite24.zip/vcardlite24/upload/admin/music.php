<?php
include('./lib.inc.php');
checkrefer();

dovcardliteadminheader();
dohtmladminheader();
// MUSIC
if( $HTTP_POST_VARS['mode'] =='music_delete' )
{
	$result = $DB_site->query(" DELETE FROM $dbtbl_music WHERE sound_file='$HTTP_POST_VARS[sound_file]' ");
	echo "$TagStartText";
	if ($result)
	{
		echo "$MsgAdminControlMusicFile $MsgAdminDeleted";
	}else{
		echo "$MsgAdminControlMusicFile $MsgAdminNoDeleted".
		"<P>Error: " . mysql_error();
	}
	echo "$TagEndText";
	$mode ='';
}

if( $HTTP_POST_VARS['mode'] == 'music_include' )
{
	$sound_name = RemoveSpecialChar($HTTP_POST_VARS['sound_name']);
	$sound_file = RemoveSpecialChar($HTTP_POST_VARS['sound_file']);
	$sound_author = $HTTP_POST_VARS['sound_author'];
	$sound_genre = $HTTP_POST_VARS['sound_genre'];
	echo "$TagStartText";
	// check if is a valide data
	if ($sound_file =="")
	{
		echo "$MsgAdminControlsound_file $MsgAdminFormFieldEmpty";
		echo "$TagEndText";
		echo TagBackBar(1,$MsgBacktoSection);
		exit();
	}
	if ($sound_name =="")
	{
		echo "$MsgAdminControlsound_name $MsgAdminFormFieldEmpty";
		echo "$TagEndText";
		echo TagBackBar(1,$MsgBacktoSection);
		exit();
	}
	$query = ("
		INSERT
		INTO $dbtbl_music ( sound_file, sound_name, sound_author, sound_genre)
		VALUES ('$sound_file','$sound_name','$sound_author','$sound_genre')
		");
	$result = $DB_site->query($query);
	if ($result)
	{
		echo "$MsgAdminControlMusicFile $MsgAdminIncluded";
	}else{
		echo "$MsgAdminControlMusicFile $MsgAdminNoIncluded".
		"<P>Error: " . mysql_error();
	}
	echo "$TagEndText";
	$mode ='';
}

if (empty($mode))
{
?>
<!-- MUSIC -->
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#DFDFDF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
<?php echo "$MsgAdminMusicControlTitle"; ?>
</b></font></td></tr></table></td></tr></table>
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
- <?php echo "$MsgAdminDelete"; ?>
</b></font></td></tr></table></td></tr></table>
<ul>
	<form method="post" action="music.php?ses=<?php echo $ses; ?>" name="vCardLiteMusicForm">
	<select name="sound_file">
<?php
if ($SpecialLanguage == "Y")
{
	$query = "SELECT * FROM $dbtbl_music ORDER BY sound_file ";
}else{
	$query = "SELECT * FROM $dbtbl_music ORDER BY sound_genre, sound_author, sound_name ";
}
$musiclist_array = $DB_site->query($query);
while ($music_info = $DB_site->fetch_array($musiclist_array))
{
	echo( "<option value=\"$music_info[sound_file]\" >$music_info[sound_genre] - $music_info[sound_author] - $music_info[sound_name]</option>\n");
}
?>
	</select>&nbsp;&nbsp;&nbsp;
	<BR>
	<input type="hidden" name="mode" value="music_delete">
	<input type="button" value="<?php echo "$MsgPlay"; ?>" width="100" onClick="playmusic(document.vCardLiteMusicForm)"> &nbsp; &nbsp; 
	<input type="submit" value="<?php echo "$MsgAdminDelete"; ?>" width="200">
	</form>
</UL>
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
- <?php echo "$MsgAdminInclude"; ?>
</b></font></td></tr></table></td></tr></table>
<ul>
	<table>
	<form method="post" action="music.php?ses=<?php echo $ses; ?>">
	<tr>
		<td><b><?php echo "$MsgAdminControlMusicFile"; ?> : </b></td>
		<td><input type="text" name="sound_file"></td>
	</tr>
	<tr>
		<td><b><?php echo "$MsgAdminControlMusicName"; ?>  : </b></td>
		<td><input type="text" name="sound_name"></td>
	</tr>
	<tr>
		<td><b><?php echo "$MsgAdminControlMusicAuthor"; ?>  : </b></td>
		<td><input type="text" name="sound_author"></td>
	</tr>
	<tr>
		<td><b><?php echo "$MsgAdminControlMusicGenre"; ?>  : </b></td>
		<td><input type="text" name="sound_genre"></td>
	</tr>
	<tr>
		<td colspan="2" align="center">
		<b><?php echo "$MsgAdminNote"; ?>:</b> <?php echo "$MsgAdminNoteMust"; ?> <b><?php echo "$sound_fileURL"; ?></b>
	&nbsp;&nbsp;&nbsp;
	<P>
	<input type="hidden" name="mode" value="music_include">
	<input type="submit" value="<?php echo "$MsgAdminInclude"; ?>" width="200">
	</form></td>
	</tr>
	</table>
</UL>
<!-- /MUSIC -->

<?php
dovcardliteadminfooter();
exit;
}
?>