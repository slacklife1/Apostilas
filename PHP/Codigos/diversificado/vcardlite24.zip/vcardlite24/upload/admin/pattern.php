<?php
include('./lib.inc.php');
checkrefer();

dovcardliteadminheader();
dohtmladminheader();
// Pattern
if( $HTTP_POST_VARS['mode'] == 'delete')
{
	$query = "DELETE FROM $dbtbl_pattern WHERE pattern_file='$HTTP_POST_VARS[pattern_file]' ";
	$result = $DB_site->query($query);
	echo "$TagStartText";
	if ($result)
	{
		echo "$MsgAdminControlPatternFile $MsgAdminDeleted";
	}else{
		echo ("$MsgAdminControlPatternFile $MsgAdminNoDeleted".
		"<P>Error: " . mysql_error());
	}
	echo "$TagEndText";
	$mode = '';
}

if( $HTTP_POST_VARS['mode'] == 'include')
{
	$pattern_file = RemoveSpecialChar($HTTP_POST_VARS['pattern_file']);
	$pattern_name = RemoveSpecialChar($HTTP_POST_VARS['pattern_name']);

	echo "$TagStartText";
	// check if is a valide data
	if (empty($pattern_file))
	{
		echo "$MsgAdminControlPatternFile $MsgAdminFormFieldEmpty";
		echo "$TagEndText";
		echo TagBackBar(1,$MsgBacktoSection);
		dovcardliteadminfooter();
		exit();
	}
	if (empty($pattern_name))
	{
		echo "$MsgAdminControlPatternName $MsgAdminFormFieldEmpty";
		echo "$TagEndText";
		echo TagBackBar(1,$MsgBacktoSection);
		dovcardliteadminfooter();
		exit();
	}
	$result = $DB_site->query(" INSERT INTO $dbtbl_pattern ( pattern_file, pattern_name) VALUES ('$pattern_file','$pattern_name') ");
	if ($result)
	{
		echo "$MsgAdminControlPatternFile $MsgAdminIncluded";
	}else{
		echo ("$MsgAdminControlPatternFile $MsgAdminNoIncluded".
		"<P>Error: " . mysql_error());
	}
	echo "$TagEndText";
	$mode = '';
}

if (empty($mode))
{
?>
<!-- PATTERN -->
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#DFDFDF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
<?php echo "$MsgAdminPatternControlTitle"; ?>
</b></font></td></tr></table></td></tr></table>
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
- <?php echo "$MsgAdminDelete"; ?>
</b></font></td></tr></table></td></tr></table>
<ul>
	<form method="post" action="pattern.php?ses=<?php echo $ses; ?>">
<?php
if ($SpecialLanguage == "Y")
{
	$query = "SELECT * FROM $dbtbl_pattern ORDER BY pattern_file ";
}
else
{
	$query = "SELECT * FROM $dbtbl_pattern ORDER BY pattern_name ";
}

$icounter = 0;
$patternlist_array = $DB_site->query($query);
while ($pattern_info = $DB_site->fetch_array($patternlist_array))
{
	// Display list fo pattern
	echo( "<input type=\"radio\" name=\"pattern_file\" value=\"$pattern_info[pattern_file]\"><img src=\"$card_imageURL/$pattern_info[pattern_file]\" WIDTH=40 HEIGHT=40 BORDER=1 alt=\"$pattern_info[pattern_name]\" ALIGN=\"MIDDLE\"> &nbsp; \n");
      	$icounter++;
	if($icounter == 6){echo "<P>\n"; $icounter = 0;}
}
?>
	<P>
	<input type="hidden" name="mode" value="delete">
	<input type="submit" value="<?php echo "$MsgAdminDelete"; ?>" width="200">
	</form>
</UL>

<P>
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
- <?php echo "$MsgAdminInclude"; ?>
</b></font></td></tr></table></td></tr></table>
<ul>
	<table>
	<form action="pattern.php?ses=<?php echo $ses; ?>" method="post">
	<tr>
		<td><b><?php echo "$MsgAdminControlPatternFile"; ?> : </b></td>
		<td><input type="text" name="pattern_file"></td>
	</tr>
	<tr>
		<td><b><?php echo "$MsgAdminControlPatternName"; ?> : </b></td>
		<td><input type="text" name="pattern_name"></td>
	</tr>
	<tr>
		<td colspan="2" align="center">
	<b><?php echo "$MsgAdminNote"; ?>:</b> <?php echo "$MsgAdminNoteMust"; ?> <b><?php echo "$card_imageURL"; ?></b>
	&nbsp;&nbsp;&nbsp;
	<P>
	<input type="hidden" name="mode" value="include">
	<input type="submit" value="<?php echo "$MsgAdminInclude"; ?>" width="200">
	</form></td>
	</tr>
	</table>
</UL>
<!-- /PATTERN -->

<?php
dovcardliteadminfooter();
exit;
}
?>