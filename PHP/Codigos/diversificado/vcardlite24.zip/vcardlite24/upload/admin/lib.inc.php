<?php
/*******************************************
script settings
*******************************************/
set_magic_quotes_runtime(0);
error_reporting(E_ERROR | E_WARNING | E_PARSE);

/*******************************************
load login/password to dbase
*******************************************/
require("./config.inc.php");
$si = md5($login_admin.$password_admin);
$login_admin ='';
$password_admin ='';
/*******************************************
initiate dbase
*******************************************/
require("./../include/db_mysql.inc.php");
$DB_site=new DB_Sql_vc;
$DB_site->server=$hostname;
$DB_site->user=$dbUser;
$DB_site->password=$dbPass;
$DB_site->database=$dbName;
$DB_site->connect();
$dbPass='';
$DB_site->password='';

/*******************************************
initiate functions load
*******************************************/
require("./../include/functions.inc.php");

/*******************************************
load front end language lib
*******************************************/
if(file_exists("./../language/$PostLanguageFile")==0)
{
	require("./../language/eng.lang.inc.php");
}else{
	require("./../language/$PostLanguageFile");
}

$ses = (!empty($HTTP_POST_VARS['ses']))? $HTTP_POST_VARS['ses'] : $HTTP_GET_VARS['ses'];

$vCardLiteVersion 	= '2.4.2';
//$remoteip = getenv("REMOTE_ADDR");
$local_referer = getenv("HTTP_REFERER");
$HTTP_USER_AGENT = substr(getenv("HTTP_USER_AGENT"),0,50);
// IP
if( getenv('HTTP_X_FORWARDED_FOR') != '' )
{
	$remoteip = ( !empty($HTTP_SERVER_VARS['REMOTE_ADDR']) ) ? $HTTP_SERVER_VARS['REMOTE_ADDR'] : ( ( !empty($HTTP_ENV_VARS['REMOTE_ADDR']) ) ? $HTTP_ENV_VARS['REMOTE_ADDR'] : $REMOTE_ADDR );
	if ( preg_match("/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", getenv('HTTP_X_FORWARDED_FOR'), $ip_list) )
	{
		$private_ip = array('/^0\./', '/^127\.0\.0\.1/', '/^192\.168\..*/', '/^172\.16\..*/', '/^10..*/', '/^224..*/', '/^240..*/');
		$remoteip = preg_replace($private_ip, $remoteip, $ip_list[1]);
	}
}else{
	$remoteip = ( !empty($HTTP_SERVER_VARS['REMOTE_ADDR']) ) ? $HTTP_SERVER_VARS['REMOTE_ADDR'] : ( ( !empty($HTTP_ENV_VARS['REMOTE_ADDR']) ) ? $HTTP_ENV_VARS['REMOTE_ADDR'] : $REMOTE_ADDR );
}


function dovcardliteadminheader()
{
	global $SiteName,$SiteFontFace,$MsgActiveJS,$sound_fileURL,$MsgWinMusicNote,$temp_query_string,$htmldir;
	@header ("Pragma: no-cache");
	echo "<html dir='$htmldir'>\n<head>\n<title>$SiteName</title>\n";
	require("./../include/metatag.inc.php");
	echo "	<script language=\"JavaScript\">
	<!--
		function playmusic(formObj){
			musicName = formObj.sound_file.options[formObj.sound_file.selectedIndex].value;
			if (musicName != \"\")
				window.location= \"$sound_fileURL/\" + musicName;
			else
				alert(\"$MsgWinMusicNote\");
		}
	//-->
	</script>";
	echo "</head>\n";
	echo "<body BGCOLOR='$SiteBGCOLOR' TEXT='$SiteTEXT' LINK='$SiteLINK' VLINK='$SiteVLINK' ALINK='$SiteALINK' TOPMARGIN='$SiteMARGINHEIGHT' LEFTMARGIN='$SiteMARGINWIDTH' MARGINWIDTH='$SiteMARGINWIDTH' MARGINHEIGHT='$SiteMARGINHEIGHT'>\n";
}
function dovcardliteadminfooter()
{
	echo "<br><br>";
	echo MyCopyright();
	echo "</body>\n</html>";
	exit;
}

$cfg['site_timeoffset'] = 0;
$sys_timestamp = time()+($cfg['site_timeoffset']*3600);
$cfg['timestamp'] = $sys_timestamp;
$today_date = timestamp_to_human($sys_timestamp);

?>