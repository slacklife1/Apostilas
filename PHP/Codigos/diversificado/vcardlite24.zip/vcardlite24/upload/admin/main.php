<?php
include('./lib.inc.php');
checkrefer();
$interval = $HTTP_POST_VARS['interval'];
$readed = $HTTP_POST_VARS['readed'];
$action = $HTTP_POST_VARS['action'];

dovcardliteadminheader();
dohtmladminheader();
if( $action == 'delete' )
{
	$result = $DB_site->query("SELECT ecard_id FROM $dbtbl_user WHERE (ecard_tosend <= DATE_SUB(CURRENT_DATE, INTERVAL $interval DAY)) AND (ecard_read = '$readed') ");
	if (!$result)
	{
		echo("<P>$MsgErrorPerformingQuery: " . mysql_error() . "</P>");
		exit;
	}
	$number = "0";
	echo "$TagStartText";
	while( $row = $DB_site->fetch_array($result) )
	{
		// Display list of card to delete
		if ($WantListOfCard == "Y")
		{
			echo ("<a href=\"./../pickup.php?ecard_id=" . $row["ecard_id"] . "\">postcard #". $row["ecard_id"] ."</a><BR>\n");
		}
		$number++;
	}
	if ($readed == 1)
	{
		$MsgReaded = $MsgAdminWarningReaded;
	}else{
		$MsgReaded = $MsgAdminWarningNotReaded;
	}
	if ($number =="0")
	{
		echo "<P><b>$MsgAdminWarningNoCardDelete</P></b> ";
		echo "$TagEndText";
		dovcardliteadminfooter();
		exit();
	}
	echo "<center><H2>$MsgAdminWarning!</H2></center> $MsgAdminWarning2 <b><i><font color=\"#FF0000\">[$MsgReaded]</font></i></b> $MsgAdminWarning3 <b><i><font color=\"#FF0000\">[$interval]</font></i></b> $MsgAdminWarning4 
	<P> <i><b><font color=\"#FF0000\">[$number]</font></b></i> $MsgAdminWarning5";
	echo "</b><center>";
	echo "<FORM METHOD=\"post\" ACTION=\"main.php?ses=$ses\">";
	echo "<input type=\"hidden\" name=\"interval\" value=\"$interval\">";
	echo "<input type=\"hidden\" name=\"readed\" value=\"$readed\">";
	echo "<input type=\"submit\" name=\"confirm\" value=\"$MsgAdminWarningButtonYes\">&nbsp;&nbsp;";
	echo "<input type=\"submit\" name=\"end\" value=\"$MsgAdminWarningButtonNo\">";
	echo "</form></center><b>";
	echo "$TagEndText";
	dovcardliteadminfooter();
	exit;
}
elseif( isset($HTTP_POST_VARS['confirm']) )
{
	$query = "
		SELECT ecard_id, card_image
		FROM $dbtbl_user
		WHERE (ecard_tosend <= DATE_SUB(CURRENT_DATE, INTERVAL $interval DAY)) AND (ecard_read = '$readed')
		";
	$result = $DB_site->query($query);
	$affected_rows = 0;
	while( $row = $DB_site->fetch_array($result) )
	{
		// Delete if file is in uploaded directory
		if (ereg("$UploadedDir/",$row['card_image']))
		{
			// Check if exist
			$check = file_exists("$card_imagePath/$row[card_image]");
			if ($check)
			{
				// delete it
				$delete = unlink("$card_imagePath/$row[card_image]");
			}
		}
		$affected_rows++;
	}
	$query = "DELETE FROM $dbtbl_user WHERE (ecard_tosend <= DATE_SUB(CURRENT_DATE, INTERVAL $interval DAY)) AND (ecard_read = '$readed') ";
	$result= $DB_site->query($query);
	echo "$TagStartText";
	echo "<b>[ $affected_rows ]</b> $MsgAdminDeletedCards";
	echo "$TagEndText";
	dovcardliteadminfooter();
	exit;
}
?>
<p>

<!-- CARDS -->
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#DFDFDF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
<?php echo "$MsgAdminCardControlTitle"; ?>
</b></font></td></tr></table></td></tr></table>
<ul>
	<form method="post" action="main.php?ses=<?php echo $ses; ?>">
	<select name="interval">
	<option value="7">7 <?php echo "$MsgAdminDay"; ?></option>
	<option value="14" selected>14 <?php echo "$MsgAdminDay"; ?></option>
	<option value="30">30 <?php echo "$MsgAdminDay"; ?></option>
	<option value="60">60 <?php echo "$MsgAdminDay"; ?></option>
	</select>&nbsp;&nbsp;&nbsp;
	<select name="readed">
	<option value="1" SELECTED><?php echo "$MsgAdminDelOption1"; ?></option>
	<option value="0"><?php echo "$MsgAdminDelOption2"; ?></option>
	</select>
	<input type="hidden" name="action" value="delete">
	<P>
	<input type="submit" value="<?php echo "$MsgAdminDeleteButton"; ?>" width="200">
	</form>
	<b><?php echo "$MsgAdminNote"; ?>:</b> <?php echo "$MsgAdminCardControlNote"; ?>
</UL>
<!-- /CARDS -->

<p>

<!-- EXTRA -->
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center" bgcolor="#000000"><tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#DFDFDF"><tr><td align="left">&nbsp;<?php echo "$FontTag2"; ?><b>
<?php echo "$MsgAdminExtraInfoTitle"; ?>
</b></font></td></tr></table></td></tr></table>
<ul>
	<!-- Avaiable Version -->
	<table width="50%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td valign="top"><FONT FACE="Arial" size="2"><b><?php echo "$MsgYourVersion"; ?></b>: <?php echo "$vCardLiteVersion"; ?></td>
		<td><?php echo "$FontTag2"; ?><b><a href="http://www.belchiorfoundry.com/forum/" target="_blank"><b><?php echo "$MsgvCardLiteCommunity"; ?></b></a></td>
	</tr>
	</table>
	</font>
	<!-- /Avaiable Version -->
	
</UL>
<!-- /EXTRA -->

<?php
dovcardliteadminfooter();
exit;
?>
