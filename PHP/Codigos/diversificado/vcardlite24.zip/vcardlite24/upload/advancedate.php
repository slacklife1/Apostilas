<?php
/***************************************************************************
 *   script               : vCard LITE
 *   copyright            : (C) 2001-2003 Belchior Foundry
 *   website              : www.belchiorfoundry.com
 *
 *   This program is freeware software; you can�t redistribute it under
 *   any circumstance without explicit authorization from Belchior Foundry.
 *   http://www.belchiorfoundry.com/
 *
 ***************************************************************************/
include('./lib.inc.php');

// check date to send card use
$today = date("Y-m-d");
$result = $DB_site->query("SELECT * FROM $dbtbl_user WHERE ecard_tosend<='$today' AND ecard_sent='0' ");
if( !$result )
{
	dovcardliteheader();
	echo("<P>$MsgErrorPerformingQuery : " . mysql_error() . "</P>");
	dovcardlitefooter();
}

$number = 0;
while( $row = $DB_site->fetch_array($result) )
{
	$ecard_id 	= $row['ecard_id'];
	$ecard_sname 	= $row['ecard_sname'];
	$ecard_semail 	= $row['ecard_semail'];
	$ecard_rname 	= $row['ecard_rname'];
	$ecard_remail 	= $row['ecard_remail'];
	// send mail to the recipient notifying them of the card that s waiting for them
	SendPickupMailAdvance($ecard_remail,$ecard_rname,$ecard_semail,$ecard_sname,$ecard_id);
	$result2 = $DB_site->query(" UPDATE $dbtbl_user SET ecard_sent='1' WHERE ecard_id='$ecard_id' ");
	$update = $DB_site->query(" UPDATE $dbtbl_slog SET sentdate=NOW() WHERE ecard_id='$ecard_id' ");
	if (!$result2)
	{
		echo("<P>$MsgErrorPerformingQuery : " . mysql_error() . "</P>");
		exit;
	}
	$number++;
}

dovcardliteheader();
echo "<p>$number $MsgNPostSent</p>";
dovcardlitefooter();
?>