<?php
/***************************************************************************
 *   script               : vCard LITE
 *   copyright            : (C) 2001-2003 Belchior Foundry
 *   website              : www.belchiorfoundry.com
 *
 *   This program is freeware software; you can�t redistribute it under
 *   any circumstance without explicit authorization from Belchior Foundry.
 *   http://www.belchiorfoundry.com/
 *
 ***************************************************************************/
include('./lib.inc.php');
dovcardliteheader();

$cat_id = $HTTP_GET_VARS['cat_id'];
$page = $HTTP_GET_VARS['page'];

if( empty($page) )
{
	$page = 1;
}
$prev_page = $page - 1;
$next_page = $page + 1;
$page_start = ($Images_Page * $page) - $Images_Page;

$query 		= " SELECT * FROM $dbtbl_card WHERE cat_id='$cat_id' ";
$result 	= $DB_site->query($query);
$num_rows 	= $DB_site->num_rows($result);

if( $num_rows<=$Images_Page )
{
	$num_pages = 1;
	}elseif( ($num_rows % $Images_Page) == 0 ){
		$num_pages = ($num_rows / $Images_Page);
	}else{
	$num_pages = ($num_rows / $Images_Page) + 1;
}

$num_pages = (int) $num_pages;

if( ($page > $num_pages) || ($page < 0) )
{
	echo TagFont($SiteFontFace,3,1,1,$MsgInvalidePageNumber);
	dohtmlbackbutton();
	dovcardlitefooter();
}

$query = $query . " LIMIT $page_start, $Images_Page";
$result = $DB_site->query($query); 

IF ($num_rows==0):
	echo TagFont($SiteFontFace,3,1,1,$MsgNoCardsinDB);
	dohtmlbackbutton();
	dovcardlitefooter();
	
ELSE:
	$T_GalleryCategory ="\n";
	
	$query2 	= "SELECT * FROM $dbtbl_cat WHERE cat_id='$cat_id'";
	$result2 	= $DB_site->query($query2);
	$myrow2 	= $DB_site->fetch_array($result2);
	$catname2 	= $myrow2['cat_name'];
	$T_GalleryCategory.= "$catname2 : $num_rows $MsgPostcards";
	$T_PostcardsTable ="\n<table width=\"$gallery_table_width\" border=\"0\" cellspacing=\"2\" cellpadding=\"8\" align=\"center\">\n<tr>";
	$icounter ="0";
	while ($row = $DB_site->fetch_array($result))
	{
		$T_PostcardsTable.= "<td align=\"center\" valign=\"middle\"><a href=\"$ProgFullURL/create.php?f=$row[card_image]&template=$row[card_template]\"><img src=\"$card_imageURL/$row[card_thm]\" border=\"1\"></A><br>".
		gethml_newbutton($row['card_date']).
		"</td>\n";
		$icounter++;
		if($icounter == $gallery_cols)
		{
			$T_PostcardsTable.= "</tr><tr>\n";
			$icounter="0";
		}
	}
	while(($icounter > 0) && ($icounter != $gallery_cols))
	{ 
		$temp_categories_table .= "<td>&nbsp;</td>"; 
		$icounter++; 
	}
ENDIF;
$T_PostcardsTable.="</tr></table>\n";

// NAV BAR LINKS
/////////////////////////////////////////////////////////////////
$T_GalleryNavBar ="\n";
// Previous Link
if ($prev_page)
{
	$T_GalleryNavBar.= "&nbsp;<a href=\"$ProgFullURL/gallerybrowser.php?cat_id=$cat_id&page=$prev_page\">$MsgPrevious</a>\n";  
}

for ($i = 1; $i <= $num_pages; $i++)
{
	$T_GalleryNavBar .= ($i != $page)? "&nbsp;<a href=\"$ProgFullURL/gallerybrowser.php?cat_id=$cat_id&page=$i\">$i</a>\n" : "&nbsp;<b>[ $i ]</b>\n";
}

// Next Link
if ($page != $num_pages)
{
	$T_GalleryNavBar.= "&nbsp;<a href=\"$ProgFullURL/gallerybrowser.php?cat_id=$cat_id&page=$next_page\">$MsgNext</a>\n<br><br>";
}
	$T_BackMainPage = "<p><div align=\"center\"><a href=\"$ProgFullURL/$Gallery_ScriptName.php\">$MsgBackCatMain</a></div>";


$T_GalleryCategory= TagFont($SiteFontFace,0,0,0,"$T_GalleryCategory");
$T_GalleryNavBar= TagFont($SiteFontFace,0,0,0,"$T_GalleryNavBar");
$T_BackMainPage = TagFont($SiteFontFace,0,0,0,"$T_BackMainPage");

$t->set_file(array('body' => "gallerybrowse_page.ihtml"));
$t->set_var(array(
'T_GalleryCategory' => $T_GalleryCategory,
'T_PostcardsTable' => $T_PostcardsTable,
'T_GalleryNavBar' => $T_GalleryNavBar,
'T_BackMainPage' => $T_BackMainPage
));
$t->parse("output",'body');
$t->p("output");
dovcardlitefooter();

?>