<?php
/***************************************************************************
 *   script               : vCard LITE
 *   copyright            : (C) 2001-2003 Belchior Foundry
 *   website              : www.belchiorfoundry.com
 *
 *   This program is freeware software; you can�t redistribute it under
 *   any circumstance without explicit authorization from Belchior Foundry.
 *   http://www.belchiorfoundry.com/
 *
 ***************************************************************************/

$step = $HTTP_GET_VARS['step'];
error_reporting(E_ERROR | E_WARNING | E_PARSE);
if(get_cfg_var("safe_mode")!=0)
{
	$installnote ="<p><b>Note:</b> In your server PHP configuration the <b>Safe Mode is active</b>, You can't use UPLOAD feature</p>";
	$safemode ="1";
}
function dodb_queries()
{
	global $DB_site,$query,$explain,$onvservers;
	while (list($key,$val)=each($query))
	{
		echo "<p>$explain[$key]</p>\n";
		echo "<!-- ".htmlspecialchars($val)." -->\n\n";
		flush();
		if ($onvservers==1 and substr($val, 0, 5)=="ALTER")
		{
			$DB_site->reporterror=0;
		}
		$DB_site->query($val);
		if ($onvservers==1 and substr($val, 0, 5)=="ALTER")
		{
			$DB_site->connect();
			$DB_site->reporterror=1;
		}
	}
	unset ($query);
	unset ($explain);
}
?>
<HTML>
	<HEAD>
	<title>vCard Lite Upgrading</title>
        <style type="text/css">
        BODY            {background-color: #F0F0F0; color: #3F3849; font-family: Verdana; font-size: 12px;
        UL,LI,P,TD,TR	{font-family: Verdana; font-size: 12px}
        H2              {font-family: Verdana; font-size: 14px}

        A               {font-family: Verdana; text-decoration: none;}
        A:HOVER         {font-family: Verdana; COLOR: #FFAC00;}
        A:ACTIVE        {font-family: Verdana; COLOR: #FFAC00;}

        FORM ,SELECT,INPUT,TEXTAREA        {font-family: Verdana; font-size: 10px}
	.title		{font-family: Verdana; font-size: 25px;color: #000000;}
        </style>
	</HEAD>
<BODY bgcolor="#CCCCCC" text="#3F3849" link="#3F3849" vlink="#3F3849" alink="#3F3849" leftmargin="10" topmargin="10" marginwidth="10" marginheight="10">
<?php
echo "<p class=\"title\"><b>vCard Lite upgrading to version 15</b></p>";
if ($step=="")
{

	echo "
	<p>Welcome to vCard Lite version 1.5 upgradings script.</p>
	<p>Running this script will the updraging of vCard Lite database strucuctury:<b> from version 1.4 to 1.5</b></p>
	<p><a href=\"$PHP_SELF?step=2\">Click here to continue --></a></p>";
	
}
if($step>=2)
{
	// step 3 and after, we are ok loading this file
	require("./admin/config.inc.php");
	require("./include/db_mysql.inc.php");
	$DB_site=new DB_Sql_vc;
	$DB_site->server=$hostname;
	$DB_site->user=$dbUser;
	$DB_site->password=$dbPass;
	$DB_site->database=$dbName;
	$DB_site->connect();
	$dbPass="";		// clear database password variable to avoid retrieving
	$DB_site->password="";
	// allow this script to catch errors
	$DB_site->reporterror=0;
	
	$DB_site->connect();
	// end init db
}

if ($step==2)
{
	echo "<p>Upgrading database tables...</p>";
	$DB_site->reporterror=0;
	
	$query[] = "ALTER TABLE $PostStatsTable ADD INDEX(`PostImage`) ";
	$explain[] ="updating stats table 1";
	$query[] = " ALTER TABLE $PostStatsTable ADD INDEX(`PostImageThm`) ";
	$explain[] ="updating stats table 2";
	$query[] = "ALTER TABLE $PostImageTable ADD INDEX(`CardCategory`) ";
	$explain[] ="updating card images table";
	$query[] = "ALTER TABLE $PostImageCatTable ADD INDEX(`CatName`) ";
	$explain[] ="updating card category table";
	

	dodb_queries();
	if ($DB_site->errno!=0) {
		echo "<p>The script reported errors in the upgrading of the tables. Only continue if you are sure that they are not serious.</p>";
		echo "<p>The errors were:</p>";
		echo "<p>Error number: ".$DB_site->errno."</p>";
		echo "<p>Error description: ".$DB_site->errdesc."</p>";
	}
	else
	{
		echo "<p><b>Tables set up successfully.<</b>/p>";
	}
	echo "<p>Tables upgrading successfully.</p>";
	echo "<p><a href=\"$PHP_SELF?step=".($step+1)."\">Click here to continue --></a></p>";
}

if ($step==3)
{
	echo "<p>Data Base Upgrade is complete.</p>";
	echo "<p>You have now completed the vCard Lite upgrading. Delete install.php and upgrade14to15.php script for security reasons.</p>";
	echo "<p>Read documentation for more vCard lite information.</p>";
	echo "$installnote";
	echo "<p>The main page <a href=\"\">can be found here --></a></p>";
}
?>