<?php
/***************************************************************************
 *   script               : vCard LITE
 *   copyright            : (C) 2001-2003 Belchior Foundry
 *   website              : www.belchiorfoundry.com
 *
 *   This program is freeware software; you can�t redistribute it under
 *   any circumstance without explicit authorization from Belchior Foundry.
 *   http://www.belchiorfoundry.com/
 *
 ***************************************************************************/
/*******************************************
script settings
*******************************************/
set_magic_quotes_runtime(0);
error_reporting(E_ERROR | E_WARNING | E_PARSE);

/*******************************************
load login/password to dbase
*******************************************/
include("./admin/config.inc.php");
include('./include/functions.inc.php');
include("./include/db_mysql.inc.php");
/*******************************************
initiate template
*******************************************/
$t= new Template();
/*******************************************
initiate dbase
*******************************************/
$DB_site=new DB_Sql_vc;
$DB_site->server=$hostname;
$DB_site->user=$dbUser;
$DB_site->password=$dbPass;
$DB_site->database=$dbName;
$DB_site->connect();
$dbPass='';		// clear database password variable to avoid retrieving
$DB_site->password='';

$t = new Template();

/*******************************************
load front end language lib
*******************************************/
if(file_exists("./language/$PostLanguageFile")==0)
{
	include("./language/eng.lang.inc.php");
}else{
	include("./language/$PostLanguageFile");
}

/*******************************************
initiate user env data
*******************************************/
if( getenv('HTTP_X_FORWARDED_FOR')!='' )
{
	$client_ip = ( !empty($HTTP_SERVER_VARS['REMOTE_ADDR']) ) ? $HTTP_SERVER_VARS['REMOTE_ADDR'] : ( ( !empty($HTTP_ENV_VARS['REMOTE_ADDR']) ) ? $HTTP_ENV_VARS['REMOTE_ADDR'] : $REMOTE_ADDR );
	if ( preg_match("/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", getenv('HTTP_X_FORWARDED_FOR'), $ip_list) )
	{
		$private_ip = array('/^0\./', '/^127\.0\.0\.1/', '/^192\.168\..*/', '/^172\.16\..*/', '/^10..*/', '/^224..*/', '/^240..*/');
		$client_ip = preg_replace($private_ip, $client_ip, $ip_list[1]);
		unset($private_ip);
	}
}else{
	$client_ip = ( !empty($HTTP_SERVER_VARS['REMOTE_ADDR']) ) ? $HTTP_SERVER_VARS['REMOTE_ADDR'] : ( ( !empty($HTTP_ENV_VARS['REMOTE_ADDR']) ) ? $HTTP_ENV_VARS['REMOTE_ADDR'] : $REMOTE_ADDR );
}
$client_agent = substr(getenv("HTTP_USER_AGENT"),0,50);

$vCardLiteVersion 	= '2.4.2';
$remoteip = getenv("REMOTE_ADDR");
$enduser_ip = getenv("REMOTE_ADDR");
if(!empty($HTTP_GET_VARS['f']))			{ $temp_query_string .="f=$HTTP_GET_VARS[f]&";}
elseif(!empty($HTTP_GET_VARS['template']))	{ $temp_query_string .="template=$HTTP_GET_VARS[template]"; }

function dovcardliteheader($bground='')
{
	global $SiteName,$SiteFontFace,$MsgActiveJS,$sound_fileURL,$MsgWinMusicNote,$temp_query_string,$htmldir;
	
	echo"<html dir='$htmldir'>\n<head>\n<title> $SiteName </title>\n";
	include("./include/metatag.inc.php");
	echo "<script type='text/javascript'>
	sound_fileURL = '$sound_fileURL/';
	MsgWinMusicNote = '". addslashes($MsgWinMusicNote) ."';
	query_string = '$temp_query_string';
	</script>
	<script src='javascript.js' type='text/javascript'></script>";
	echo "</head>\n";
	echo TAG_Body($bground);
	echo "<noscript><b><font face='$SiteFontFace' size='3' color='#FF0000'>$MsgActiveJS</font></b><p></noscript>\n";
	include("./include/header.inc.php");
}
function dovcardlitefooter()
{
	global $vCardLiteVersion,$DB_site;
	$DB_site->close;
	echo "\n<!-- vCard Lite Version $vCardLiteVersion -->\n";
	include("./include/footer.inc.php");
	exit;
}
$cfg['site_timeoffset'] = 0;
$sys_timestamp = time()+($cfg['site_timeoffset']*3600);
$cfg['timestamp'] = $sys_timestamp;
$today_date = timestamp_to_human($sys_timestamp);

?>