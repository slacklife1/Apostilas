<?php
/***************************************************************************
 *   script               : vCard LITE
 *   copyright            : (C) 2001-2003 Belchior Foundry
 *   website              : www.belchiorfoundry.com
 *
 *   This program is freeware software; you can�t redistribute it under
 *   any circumstance without explicit authorization from Belchior Foundry.
 *   http://www.belchiorfoundry.com/
 *
 ***************************************************************************/
include('./lib.inc.php');
$f = (!empty($HTTP_GET_VARS['f']))? $HTTP_GET_VARS['f']: $HTTP_POST_VARS['f'] ;
$template = (!empty($HTTP_GET_VARS['template']))? $HTTP_GET_VARS['template']: $HTTP_POST_VARS['template'];
$action = (!empty($HTTP_POST_VARS['action']))? $HTTP_POST_VARS['action']: $HTTP_GET_VARS['action'];
$addrecip = $HTTP_POST_VARS['addrecip'];
$Tag_DefaultFormFont ="<font face=\"$FormFontFace\" size=\"$FormFontSize\">";



/* edit */

$ecard_rname =  (!empty($HTTP_POST_VARS['ecard_rname'])) ? $HTTP_POST_VARS['ecard_rname']  : $HTTP_COOKIE_VARS['vcecard_rname'] ;
$ecard_remail = (!empty($HTTP_POST_VARS['ecard_remail']))? $HTTP_POST_VARS['ecard_remail'] : $HTTP_COOKIE_VARS['vcecard_remail'] ;
$ecard_sname =  (!empty($HTTP_POST_VARS['ecard_sname'])) ? $HTTP_POST_VARS['ecard_sname']  : $HTTP_COOKIE_VARS['vcecard_sname'] ;
$ecard_semail = (!empty($HTTP_POST_VARS['ecard_semail']))? $HTTP_POST_VARS['ecard_semail'] : $HTTP_COOKIE_VARS['vcecard_semail'] ;

$ecard_heading = $HTTP_POST_VARS['ecard_heading'];
$ecard_message = $HTTP_POST_VARS['ecard_message'];
$ecard_sig = $HTTP_POST_VARS['ecard_sig'];

$ecard_tosend = $HTTP_POST_VARS['ecard_tosend'];
$card_image = $HTTP_POST_VARS['card_image'];
$card_template = $HTTP_POST_VARS['card_template'];

$sound_file = $HTTP_POST_VARS['sound_file'];
$stamp_file = $HTTP_POST_VARS['stamp_file'];
	$stamp_file = (empty($stamp_file))? $DefaultStampImg: $stamp_file;
	$stamp_file = ($AllowChooseStamp!='Y')? $DefaultStampImg: $stamp_file;

$pattern_file = $HTTP_POST_VARS['pattern_file'];
$ecard_color = $HTTP_POST_VARS['ecard_color'];
$ecard_fontcolor = $HTTP_POST_VARS['ecard_fontcolor'];
$ecard_fontsize = $HTTP_POST_VARS['ecard_fontsize'];
$ecard_fontface = $HTTP_POST_VARS['ecard_fontface'];
$ecard_notify = $HTTP_POST_VARS['ecard_notify'];

$FormFieldSize	= empty($FormFieldSize)? $FromFieldSize : $FormFieldSize;
$FormAreaColSize = empty($FormAreaColSize)? $FromAreaColSize: $FormAreaColSize;

/*#########################################################################
PAGE TEMP: colors list
#########################################################################*/
function colorlist($color="")
{
	$colors_list = array ('Aliceblue'=>'#F0F8FF','Antiquewhite'=>'#FAEBD7','Aqua'=>'#00FFFF','Aquamarine'=>'#7FFFD4','Azure'=>'#F0FFFF','Beige'=>'#F5F5DC','Bisque'=>'#FFE4C4','Black'=>'#000000','Blanchedalmond'=>'#FFEBCD','Blue'=>'#0000FF','Blueviolet'=>'#8A2BE2','Brown'=>'#A52A2A','Burlywood'=>'#DEB887','Cadetblue'=>'#5F9EA0','Chartreuse'=>'#7FFF00','Chocolate'=>'#D2691E','Coral'=>'#FF7F50','Cornflowerblue'=>'#6495ED','Cornsilk'=>'#FFF8DC','Crimson'=>'#DC143C','Darkblue'=>'#00008B','Darkcyan'=>'#008B8B','Darkgoldenrod'=>'#B8860B','Darkgray'=>'#A9A9A9','Darkgreen'=>'#006400','Darkkhaki'=>'#BDB76B','Darkmagenta'=>'#8B008B','Darkolivegreen'=>'#556B2F','Darkorange'=>'#FF8C00','Darkorchid'=>'#9932CC','Darkred'=>'#8B0000','Darksalmon'=>'#E9967A','Darkseagreen'=>'#8FBC8F','Darkslateblue'=>'#483D8B','Darkslategray'=>'#2F4F4F','Darkturquoise'=>'#00CED1','Darkviolet'=>'#9400D3','deeppink'=>'#FF1493','Deepskyblue'=>'#00BFFF','Dimgray'=>'#696969','Dodgerblue'=>'#1E90FF','Firebrick'=>'#B22222','Floralwhite'=>'#FFFAF0','Forestgreen'=>'#228B22','Fuchsia'=>'#FF00FF','Gainsboro'=>'#DCDCDC','Ghostwhite'=>'#F8F8FF','Gold'=>'#FFD700','Goldenrod'=>'#DAA520','Gray'=>'#808080','Green'=>'#008000','Greenyellow'=>'#ADFF2F','Honeydew'=>'#F0FFF0','Hotpink'=>'#FF69B4','Indianred'=>'#CD5C5C','Indigo'=>'#4B0082','Ivory'=>'#FFFFF0','Khaki'=>'#F0E68C','Lavender'=>'#E6E6FA','Lavenderblush'=>'#FFF0F5','Lawngreen'=>'#7CFC00','Lemonchiffon'=>'#FFFACD','Lightblue'=>'#ADD8E6','Lightcoral'=>'#F08080','Lightcyan'=>'#E0FFFF','Lightgoldenrodyellow'=>'#FAFAD2','Lightgreen'=>'#90EE90','Lightgrey'=>'#D3D3D3','Lightpink'=>'#FFB6C1','Lightsalmon'=>'#FFA07A','Lightseagreen'=>'#20B2AA','Lightskyblue'=>'#87CEFA','Lightslategray'=>'#778899','Lightsteelblue'=>'#B0C4DE','Lightyellow'=>'#FFFFE0','Lime'=>'#00FF00','Limegreen'=>'#32CD32','Linen'=>'#FAF0E6','Magenta'=>'#FF00FF','Maroon'=>'#800000','Mediumauqamarine'=>'#66CDAA','Mediumblue'=>'#0000CD','Mediumorchid'=>'#BA55D3','Mediumpurple'=>'#9370D8','Mediumseagreen'=>'#3CB371','Mediumslateblue'=>'#7B68EE','Mediumspringgreen'=>'#00FA9A','Mediumturquoise'=>'#48D1CC','Mediumvioletred'=>'#C71585','Midnightblue'=>'#191970','Mintcream'=>'#F5FFFA','Mistyrose'=>'#FFE4E1','Moccasin'=>'#FFE4B5','Navajowhite'=>'#FFDEAD','Navy'=>'#000080','Oldlace'=>'#FDF5E6','Olive'=>'#808000','Olivedrab'=>'#688E23','Orange'=>'#FFA500','Orangered'=>'#FF4500','Orchid'=>'#DA70D6','Palegoldenrod'=>'#EEE8AA','Palegreen'=>'#98FB98','Paleturquoise'=>'#AFEEEE','Palevioletred'=>'#D87093','Papayawhip'=>'#FFEFD5','Peachpuff'=>'#FFDAB9','Peru'=>'#CD853F','Pink'=>'#FFC0CB','Plum'=>'#DDA0DD','Powderblue'=>'#B0E0E6','Purple'=>'#800080','Red'=>'#FF0000','Rosybrown'=>'#BC8F8F','Royalblue'=>'#4169E1','Saddlebrown'=>'#8B4513','Salmon'=>'#FA8072','Sandybrown'=>'#F4A460','Seagreen'=>'#2E8B57','Seashell'=>'#FFF5EE','Sienna'=>'#A0522D','Silver'=>'#C0C0C0','Skyblue'=>'#87CEEB','Slateblue'=>'#6A5ACD','Slategray'=>'#708090','Snow'=>'#FFFAFA','Springgreen'=>'#00FF7F','Steelblue'=>'#4682B4','Tan'=>'#D2B48C','Teal'=>'#008080','Thistle'=>'#D8BFD8','Tomato'=>'#FF6347','Turquoise'=>'#40E0D0','Violet'=>'#EE82EE','Wheat'=>'#F5DEB3','White'=>'#FFFFFF','Whitesmoke'=>'#F5F5F5','Yellow'=>'#FFFF00','YellowGreen'=>'#9ACD32');
	$html = '';
	while (list($key, $val) = each($colors_list))
	{
		$html.= "<option value=\"$val\"";
		$html.= ($val==$color)?' selected':'';
		$html.= ">$key</option>";
	}
	return $html;
}

if( empty($action) || $action=='edit')
{
	
	dovcardliteheader();
	// IF use any template
	if( !empty($template) or !empty($UseOnlyThisTemplate) )
	{
	// IF use any template
	
		// Check FLASH or GIF/JPEG
		$T_PostImage = TAG_Image($f,$card_imageURL);
		// Check MUSIC
		$T_sound_file = TAG_Music();
		// Check STAMP
		$T_stamp_file = TAG_Stamp($stamp_file);
		if($UseOnlyThisTemplate!="")
		{
			$template="$UseOnlyThisTemplate";
		}
		$t->set_file(array("body" => "$template.ihtml"));
		// Set 'value' and 'name' to each element's value and name:
		$t->set_var(array(
				'T_SiteName' => $SiteName,
				'T_SiteURL' => $SiteURL,
				'T_SenderName' => $MsgYourName,
				'T_SenderEmail' => $MsgYourEmail,
				'T_RecpName' => $MsgRecpName,
				'T_RecpEmail' => $MsgRecpEmail,
				'T_PostImage' => $T_PostImage,
				'T_PostMessage' => $MsgMessage,
				'T_PostSig' => $MsgSignature,
				'T_PostHeading' => $MsgYourTitle,
				'T_PostSound' => $T_PostSound,
				'T_PostStamp' => $T_PostStamp,
				'T_PostBackGround' => '',
				'T_PostColor' => '',
				'T_PostTemplate' => '',
				'T_PostFontFace' => '',
				'T_PostFontColor' => '',
				'T_PostFontSize' => '',
				'T_PostBeNotify' => '',
				'T_MsgSendTo' => $MsgSendTo,
				'T_MsgClickHere' => $MsgClickHere,
				'T_SiteFontFace' => $SiteFontFace
			));
		$t->parse("output","body");
		$t->p("output");
	// IF not use any template
	}
	else
	{
	// IF not use any template
	?>
	
	<div align="center">
	<?php echo "$Tag_DefaultFormFont"; ?><font color="#000000"><b><?php echo "$MsgImage"; ?></b></font><br></font>
	<?php
	// IF not use any template > Show Image
		echo TAG_Image($f,$card_imageURL);
	}
	// GENERAL CODE FOR ALL
	?>
	</div>

	<!-- THE FORM -->
	<p></p><p></p>
	<table width="<?php echo "$FormTableWidth"; ?>" border="0" cellspacing="0" cellpadding="1" align="center"><tr><td bgcolor="#000000">
	<table border="0" cellspacing="0" cellpadding="5" align="center" bgcolor="<?php echo "$FormBGcolor"; ?>">
	<form action="create.php" method="post" name="vCardLiteform">
	<input type="hidden" name="card_image" value="<?php echo "$f"; ?>">
	
	<?php
	// OPEN > Heading > Only if file is null
	if($f != ""){
	?>
		<tr>
			<td colspan="2"><?php echo "$Tag_DefaultFormFont"; ?><font color="#FF0000"><B><?php echo "$MsgYourTitle"; ?>:</B></font></font><br>
			<input type="Text" name="ecard_heading" size="<?php echo "$FormFieldSize"; ?>" maxlength="100" value="<?php echo htmlspecialchars($ecard_heading); ?>"></td>
		</tr>
	<?php
	// CLOSE > Heading > Only if file is null
	}
	//$ecard_message = str_replace('<br>',"\n",$ecard_message);
	?>
		<tr>
			<td valign="top"><?php echo "$Tag_DefaultFormFont"; ?><font color="#000000"><B><?php echo "$MsgMessage"; ?>:</B></font></font><br>
			<TEXTAREA name="ecard_message" COLS="<?php echo "$FormAreaColSize"; ?>" ROWS="8" WRAP="VIRTUAL"><?php echo htmlspecialchars($ecard_message); ?></TEXTAREA> <a href="javascript:emoticonwin()"><img src="img/icon_help.gif" border="0" align="TOP" ALT="<?php echo "$MsgHelp"; ?>"></A>
			</td>
			<td valign="top"><?php echo "$Tag_DefaultFormFont"; ?>
	<?php
	// OPEN > FONT > Only if file is null
	if($f != ""){
	?>
		<B><?php echo "$MsgFont"; ?>:</B></font>
	<br>
			<select name="ecard_fontcolor" size="1">
	                <option value="Black"><?php echo "$MsgFontColorBlack"; ?> 
	                <option value="Black"></option>
	<?php
			echo colorlist($ecard_fontcolor);
	?>
			</select> <a href="javascript:colorwin()"><img src="img/icon_help.gif" border=0  align="ABSMIDDLE" ALT="<?php echo "$MsgHelp"; ?>"></A>
	<br>
	
			<select name="ecard_fontface">
	                <option value=""><?php echo "$MsgNoFontFace"; ?></option>
	                <option value=""></option>
	<?php
		// Font List
		sort ($fontlist);
		reset ($fontlist);
		while (list ($key, $val) = each ($fontlist))
		{
			echo "<option value=\"$val\"";
			echo ($val==$ecard_fontface)? ' selected':'';
			echo ">$val</option>\n";
			//  echo "$key - $val\n";
		}
	?>
			</select> <a href="javascript:fontface()"><img src="img/icon_help.gif" border=0  align="ABSMIDDLE" ALT="<?php echo "$MsgHelp"; ?>"></A>
	<br>
			<select name="ecard_fontsize">
	<?php
			$ecard_fontsize = ( empty($ecard_fontsize) )? '+1' : $ecard_fontsize; 
	?>
			<option value="-1"<?php echo ($ecard_fontsize=='-1')?' selected':''; echo "> $MsgFontSizeSmall"; ?></option> 
			<option value="+1"<?php echo ($ecard_fontsize=='+1')?' selected':''; echo "> $MsgFontSizeMedium"; ?></option>
			<option value="+3"<?php echo ($ecard_fontsize=='+2')?' selected':''; echo "> $MsgFontSizeLarge"; ?></option>
			<option value="+4"<?php echo ($ecard_fontsize=='+3')?' selected':''; echo "> $MsgFontSizeXLarge"; ?></option>
			</select>
	<?php
	}
	// CLOSE > FONT > Only if file is null
	?>
			</td>
		</tr>
	<?php
	// OPEN > SIG > Only if file is null
	if ($f!=""){
	?>
		<tr>
			<td colspan="2" valign="top"><?php echo "$Tag_DefaultFormFont"; ?><B><font color="#008000"><?php echo "$MsgSignature"; ?>:</font></B></font><br>
			<input type="text" name="ecard_sig" size="<?php echo "$FormFieldSize"; ?>" maxlength="50" value="<?php echo htmlspecialchars($ecard_sig); ?>">
			</td>
		</tr>
	<?php
	}
	// CLOSE > SIG > Only if file is null
	?>
		<tr>
			<td colspan="2">
			<table width="100%" border="0">
				<tr>
					<td><?php echo "$Tag_DefaultFormFont"; ?><B><?php echo "$MsgRecpName"; ?>:</B></font></td>
					<td><?php echo "$Tag_DefaultFormFont"; ?><B><?php echo "$MsgRecpEmail"; ?>:</B></font></td>
				</tr>
				<tr>
					<td><input type="text" name="ecard_rname" value="<?php echo $ecard_rname; ?>" size="<?php echo "$FormFieldSize"; ?>" maxlength="50"></td>
					<td><input type="text" name="ecard_remail" value="<?php echo $ecard_remail; ?>" size="<?php echo "$FormFieldSize"; ?>" maxlength="50"></td>
				</tr>
<?php
	if(isset($addrecip) AND $AllowMultipleRecp == "Y")
	{
		$range = $addrecip;
		$counter = "1";
		for($counter; $counter <= $range; $counter++)
		{
			eval ("\$rcp_n = \$HTTP_POST_VARS['ecard_rname$counter'];");
			eval ("\$rcp_e = \$HTTP_POST_VARS['ecard_remail$counter'];");
			echo "<tr>
			<td><input type=\"text\" name=\"ecard_rname$counter\" value=\"$rcp_n\" size=\"$FormFieldSize\" maxlength=\"50\"></td>
			<td><input type=\"text\" name=\"ecard_remail$counter\" value=\"$rcp_e\" size=\"$FormFieldSize\" maxlength=\"50\"></td>
			</tr> \n";
		}
	}
	if($AllowMultipleRecp=="Y")
	{
		if(empty($addrecip))
		{
			$addrecip = 0;
		}
			echo "
				<tr>
					<td colspan=\"1\">$Tag_DefaultFormFont
					<b>$MsgAddRecp:</b> <select name='addrecip' onChange=\"document.vCardLiteform.action.value='edit'; document.vCardLiteform.submit(); return false;\">
					<option value=\"0\"".cexpr($addrecip==0," selected","").">1</option>
					<option value=\"1\"".cexpr($addrecip==1," selected","").">2</option>
					<option value=\"2\"".cexpr($addrecip==2," selected","").">3</option>
					<option value=\"3\"".cexpr($addrecip==3," selected","").">4</option>
					<option value=\"4\"".cexpr($addrecip==4," selected","").">5</option>
					</select>
					</td>
					<td></td>
				</tr>";
	}
	?>
				<tr>
				
					<td><?php echo "$Tag_DefaultFormFont"; ?><B><?php echo "$MsgYourName"; ?>:</B></font></td>
					<td><?php echo "$Tag_DefaultFormFont"; ?><B><?php echo "$MsgYourEmail"; ?>:</B></font></td>
				</tr>
				<tr>
					<td><input type="text" name="ecard_sname" value="<?php echo $ecard_sname; ?>" size="<?php echo "$FormFieldSize"; ?>" maxlength="50"></td>
					<td><input type="text" name="ecard_semail" value="<?php echo $ecard_semail; ?>" size="<?php echo "$FormFieldSize"; ?>" maxlength="50"></td>
				</tr>
			</table>
			</td>
		</tr>
	<?php
	// OPEN allow advance send
	if ($AllowAdvanceSend=="Y" and empty($PostAddRecp))
	{
	?>
		<tr>
			<td colspan="2" valign="top"><?php echo "$Tag_DefaultFormFont"; ?><B><?php echo "$MsgChooseDate"; ?>:</B></font><br>
			
	<?php
		echo DateSelector($HowAdvanceDateAllowd,$SiteDateFormate,"ecard_tosend",$ecard_tosend);
	?>
			<br>
			<?php echo "$Tag_DefaultFormFont"; ?><small><?php echo "$MsgDateFormat"; ?></small></font><br>
			</td>
		</tr>
	<?php
	}
	else
	{
		$ecard_tosend = date ("Y-m-d");
		echo "<input type='hidden' name='ecard_tosend' value='$ecard_tosend'>";
	}
	// CLOSE allow advance send
	
	// OPEN STAMP SECTION
	if ($AllowChooseStamp =="Y" and $f!="")
	{
	?>	<tr>
			<td colspan="2" valign="top"><?php echo "$Tag_DefaultFormFont"; ?><B><?php echo "$MsgChooseStamp"; ?>:</B></font><br>
		<select name="stamp_file" size="1">
		<option value=""><?php echo "$MsgNone"; ?></option>
		<option value=""></option>
	<?php
		if ($SpecialLanguage == "Y")
		{
			$query = "SELECT stamp_file, stamp_name FROM $dbtbl_stamp ORDER BY stamp_file";
		}else{
			$query = "SELECT stamp_file, stamp_name FROM $dbtbl_stamp ORDER BY stamp_name";
		}
		$stamplist = $DB_site->query($query);
		while ($stampinfo = $DB_site->fetch_array($stamplist))
		{
			echo "<option value=\"$stampinfo[stamp_file]\" ";
			echo ($stampinfo['stamp_file'] == $stamp_file)?' selected':'';
			echo " >$stampinfo[stamp_name] </option>\n";
		}
	?>		</select> <a href="javascript:stampwin()"><img src="img/icon_help.gif" border=0  align="ABSMIDDLE" ALT="<?php echo "$MsgHelp"; ?>"></A>
			</td>
		</tr>
	<?php
	}
	// CLOSE STAMP SECTION
	
	// OPEN LAYOUT SECTION
	$card_template = !empty($HTTP_GET_VARS['template'])? $HTTP_GET_VARS['template'] : $HTTP_POST_VARS['card_template'];
	$card_template = !empty($UseOnlyThisTemplate)? $UseOnlyThisTemplate: $card_template;
	
	if(empty($card_template) || ($card_template=='template01' || $card_template=='template02' || $card_template=='template03'))
	{
		$card_template = empty($card_template) ? 'template01' : $card_template;
	?>
		<tr>
			<td colspan="2" valign="top"><?php echo "$Tag_DefaultFormFont"; ?><B><?php echo "$MsgChooseLayout"; ?>:</B></font><br>
			<table width="100%" border="0" cellspacing="0" cellpadding="4">
				<tr>
					<td align="center"><input type="radio" name="card_template" VALUE="template01" <?php echo ($card_template=='template01')? ' checked':'';  ?> ></td>
					<td align="center"><input type="radio" name="card_template" VALUE="template02" <?php echo ($card_template=='template02')? ' checked':'';  ?> ></td>
					<td align="center"><input type="radio" name="card_template" VALUE="template03" <?php echo ($card_template=='template03')? ' checked':'';  ?> ></td>
				</tr>
				<tr>
					<td align="center"><img src="img/style_01.gif" border="0" ALT=""></td>
					<td align="center"><img src="img/style_02.gif" border="0" ALT=""></td>
					<td align="center"><img src="img/style_03.gif" border="0" ALT=""></td>
				</tr>
			</table>
			</td>
		</tr>
	<?php
	}else{
		echo "<input type='hidden' name='card_template' VALUE='$card_template'>";
	}
	echo "<input type='hidden' name='template' VALUE='$card_template'>";
	// CLOSE LAYOUT SECTION
	?>
	
		<tr>
			<td colspan="2"><?php echo "$Tag_DefaultFormFont"; ?><B><?php echo "$MsgPostColor"; ?>:</B></font><br>
			<select name="ecard_color" size="1">
		        <option value="White"><?php echo "$MsgFontColorWhite"; ?>
			<option value="White"></option>
	<?php
	//		echo ($stamp['stamp_file'] == $HTTP_POST_VARS['stamp_file'])?' selected':'';
			echo colorlist($ecard_color)
			//include "./include/colors.inc.php";
	?>
			</select> <a href="javascript:colorwin()"><img src="img/icon_help.gif" border=0  align="ABSMIDDLE" ALT="<?php echo "$MsgHelp"; ?>"></A>
			</td>
		</tr>
	<?php
	// OPEN: Allow pattern/background image condition
	if ($AllowChooseBGimage=="Y"){
	?>
		<tr>
			<td colspan="2"><?php echo "$Tag_DefaultFormFont"; ?><B><?php echo "$MsgPageBackground"; ?>:</B></font><br>
			<select name="pattern_file" size="1">
			<option value=""><?php echo "$MsgNone"; ?></option> 
			<option value=""></option>
	<?php
		if ($SpecialLanguage == "Y")
		{
			$query = "SELECT pattern_file, pattern_name FROM $dbtbl_pattern ORDER BY pattern_file";
		}else{
			$query = "SELECT pattern_file, pattern_name FROM $dbtbl_pattern ORDER BY pattern_name";
		}
		$patternlist = $DB_site->query($query);
		while ($pattern = $DB_site->fetch_array($patternlist))
		{
			// Display list fo pattern
		        echo "<option value=\"$pattern[pattern_file]\" ";
			echo ($pattern_file == $pattern['pattern_file'])? ' selected':'' ;
			echo " >$pattern[pattern_name] </option>\n";
		}
	?>
			</select> <a href="javascript:bgroundwin()"><img src="img/icon_help.gif" border=0  align="ABSMIDDLE" ALT="<?php echo "$MsgHelp"; ?>"></A>
			</td>
		</tr>
	<?php
	}else{
		echo "<input type=\"hidden\" name=\"pattern_file\" 	VALUE=\"$DefaultBGImage\">";
	}
	// CLOSE: Allow pattern/background image condition
	
	// OPEN: Allow BG music condition
	if ($AllowBGmusic=="Y"){
	?>
		<tr>
			<td colspan="2" valign="top"><?php echo "$Tag_DefaultFormFont"; ?><B><?php echo "$MsgMusic"; ?>:</B></font><br>
			<select name="sound_file">
			<option value=""><?php echo "$MsgNone"; ?></option>
			<option value=""></option>
	<?php
		if ($SpecialLanguage == "Y")
		{
			$query = "SELECT sound_file, sound_name, sound_author, sound_genre FROM $dbtbl_music ORDER BY sound_file";
		}else{
			$query = "SELECT sound_file, sound_name, sound_author, sound_genre FROM $dbtbl_music ORDER BY sound_genre, sound_author, sound_name";
		}
		$musiclist = $DB_site->query($query);
		while ($music = $DB_site->fetch_array($musiclist))
		{
			echo "<option value=\"$music[sound_file]\"";
			echo ($music['sound_file'] == $sound_file)? ' selected':'';
			echo " >$music[sound_genre] - $music[sound_author] - $music[sound_name] </option>\n";
		}
	?>
			</select><br>
			<input type="button" value="<?php echo "$MsgPlay"; ?>" width="100" onClick="playmusic(document.vCardLiteform)">
			</td>
		</tr>
	<?php
	}
	// CLOSE: Allow BG music condition
	
	// OPEN: Allow Option to be notify
	if ($AllowChooseNotify == "Y"){
	?>
		<tr>
			<td colspan="2" valign="top"><?php echo "$Tag_DefaultFormFont"; ?><B><?php echo "$MsgNotify"; ?>:</B></font><br>
			<input type="radio" name="ecard_notify" VALUE="1"<?php echo ($ecard_notify ==1)? ' checked':''; ?>><?php echo "$MsgYes"; ?>
			<input type="radio" name="ecard_notify" VALUE="0"<?php echo ($ecard_notify ==0)? ' checked':''; ?>><?php echo "$MsgNo"; ?>
			 <a href="javascript:notify()"><img src="img/icon_help.gif" border=0  align="ABSMIDDLE" ALT="<?php echo "$MsgHelp"; ?>"></A>
			</td>
		</tr>
	<?php
	}
	
	echo <<<TXTHID
	<input type="hidden" name="f" value="$f">
	<input type="hidden" name="tempate" value="$template">
TXTHID;
	//CLOSE Allow Option to be notify
	?>
		</table>
		</td>
	</tr>
	</table>
	<script language="JavaScript" type="text/javascript">
	<!-- 
		document.vCardLiteform.ecard_heading.focus();
	//-->
	</script>
	<p>
	<p>
	<hr width="85%" noshade>
	<p>
	<input type="hidden" name="action" value="">
	<div align="center">
	<input type="submit" VALUE="<?php echo "$MsgPreviewButton"; ?>" onClick="vCardLiteform.action.value='preview';">
	</div>
	</form>
	<!-- /THE FORM -->
<?php
	dovcardlitefooter();
	
// if action == preview
}
if($action =='preview')
{
	//$ecard_message = wordwrap($ecard_message,60,"\n",1); 
	do_checkempty($ecard_message,$MsgErrorMessage);
	do_checkempty($ecard_rname,$MsgErrorRecpName);
	do_checkempty($ecard_remail,$MsgErrorRecpEmail);
	
	if( mailval($ecard_remail,2) )
	{
		do_checkempty('',$MsgErrorRecpEmail2);
		/* dovcardliteheader();
		echo TagFont($SiteFontFace,3,1,1,$MsgErrorRecpEmail2);
		dohtmlbackbutton();
		dovcardlitefooter();
		*/
	}
	
	do_checkempty($ecard_sname,$MsgErrorSenderName);
	do_checkempty($ecard_semail,$MsgErrorSenderEmail);
	
	if( mailval($ecard_semail,2) )
	{
		do_checkempty('',$MsgErrorSenderEmail2);
		/* dovcardliteheader();
		echo TagFont($SiteFontFace,3,1,1,$MsgErrorSenderEmail2);
		dohtmlbackbutton();
		dovcardlitefooter();
		*/
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	// Special Characters Handling:
	////////////////////////////////////////////////////////////////////////////////////
	$ecard_message = RemoveSpecialChar($ecard_message);
	$ecard_heading = RemoveSpecialChar($ecard_heading);
	$ecard_sig = RemoveSpecialChar($ecard_sig);
	$ecard_rname = RemoveSpecialChar($ecard_rname);
	$ecard_sname = RemoveSpecialChar($ecard_sname);
	
	//////////////////////////////////////////////////
	// EMOTICONS to GRAPHICS - NOT EDIT:
	//////////////////////////////////////////////////
	$T_ecard_message = EmoticonToGraphic($ecard_message);

	// Check FLASH or GIF/JPEG
	$T_card_image = TAG_Image($card_image,$card_imageURL);
	
	// Check MUSIC
	$T_sound_file = TAG_Music($sound_file);
	
	// Check STAMP
	$T_stamp_file = TAG_Stamp($stamp_file);
	
	$t->set_file(array("body" => "$card_template.ihtml"));
	// Set 'value' and 'name' to each element's value and name:
	$t->set_var(array(
				'T_SiteName',$SiteName,
				'T_SiteURL' => $SiteURL,
				'T_SenderName' => $ecard_sname,
				'T_SenderEmail' => $ecard_semail,
				'T_RecpName' => $ecard_rname,
				'T_RecpEmail' => $ecard_remail,
				'T_PostImage' => $T_card_image,
				'T_PostMessage' => $T_ecard_message,
				'T_PostSig' => $ecard_sig,
				'T_PostHeading' => $ecard_heading,
				'T_PostSound' => $T_sound_file,
				'T_PostStamp' => $T_stamp_file,
				'T_PostBackGround' => $pattern_file,
				'T_PostColor' => $ecard_color,
				'T_card_template' => $card_template,
				'T_PostFontFace' => $ecard_fontface,
				'T_PostFontColor' => $ecard_fontcolor,
				'T_PostFontSize' => $ecard_fontsize,
				'T_PostBeNotify' => $ecard_notify,
				'T_MsgSendTo' => $MsgSendTo,
				'T_MsgClickHere' => $MsgClickHere,
				'T_SiteFontFace' => $SiteFontFace
				));
	
	$t->parse("output","body");
	dovcardliteheader($pattern_file);
	
	$t->p("output");
	?>
	<div align="center">
	<br>
	<br>
	<br>
	<table width="500" border="0" cellspacing="0" cellpadding="1" bgcolor="#000000"><tr><td>
	<table width="100%" border="0" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
		<tr>
			<td align="center">
			<form action="create.php" method="post" name="vCardLiteform">
	<?php
	
	TAG_ExtraRecpField(1,$HTTP_POST_VARS['ecard_rname1'],$HTTP_POST_VARS['ecard_remail1']);
	TAG_ExtraRecpField(2,$HTTP_POST_VARS['ecard_rname2'],$HTTP_POST_VARS['ecard_remail2']);
	TAG_ExtraRecpField(3,$HTTP_POST_VARS['ecard_rname3'],$HTTP_POST_VARS['ecard_remail3']);
	TAG_ExtraRecpField(4,$HTTP_POST_VARS['ecard_rname4'],$HTTP_POST_VARS['ecard_remail4']);

	TAG_HiddenField(array(
					'f' => $card_image,
					'template' => $card_template,
					'addrecip' => $addrecip,
					'ecard_sname' => $ecard_sname,
					'ecard_semail' => $ecard_semail,
					'ecard_rname' => $ecard_rname,
					'ecard_remail' => $ecard_remail,
					'card_image' => $card_image,
					'stamp_file' => $stamp_file,
					'ecard_message' => $ecard_message,
					'ecard_sig' => $ecard_sig,
					'ecard_heading' => $ecard_heading,
					'sound_file' => $sound_file,
					'pattern_file' => $pattern_file,
					'ecard_color' => $ecard_color,
					'card_template' => $card_template,
					'ecard_fontface' => $ecard_fontface,
					'ecard_fontcolor' => $ecard_fontcolor,
					'ecard_fontsize' => $ecard_fontsize,
					'ecard_notify' => $ecard_notify,
					'ecard_tosend' => $ecard_tosend
					));
	?>
	<input type="hidden" name="action" value="">
			<table width="100%"><tr>
				<td width="50%" align="center"><input type="submit" value="<?php echo "$MsgSendButton"; ?>" width="200" onClick="vCardLiteform.action.value='sendcard';"></td>
				<td width="50%" align="center"><input type="submit" value="<?php echo "$MsgBackEditButton"; ?>" width="200" onClick="vCardLiteform.action.value='';"></form></td>
			</tr></table>
			<font color="#000000"><?php echo TagFont($SiteFontFace,2,1,1,$MsgAvoidDuplicat);?></font>
			</td>
		</tr>
	</table>
	</td></tr></table>
	</div>
<?php
	dovcardlitefooter();
}

if($action == 'sendcard')
{
	$ecard_remail1 = $HTTP_POST_VARS['ecard_remail1'];
	$ecard_remail2 = $HTTP_POST_VARS['ecard_remail2'];
	$ecard_remail3 = $HTTP_POST_VARS['ecard_remail3'];
	$ecard_remail4 = $HTTP_POST_VARS['ecard_remail4'];
	$ecard_remail5 = $HTTP_POST_VARS['ecard_remail5'];
	
	$ecard_rname1 = $HTTP_POST_VARS['ecard_rname1'];
	$ecard_rname2 = $HTTP_POST_VARS['ecard_rname2'];
	$ecard_rname3 = $HTTP_POST_VARS['ecard_rname3'];
	$ecard_rname4 = $HTTP_POST_VARS['ecard_rname4'];
	$ecard_rname5 = $HTTP_POST_VARS['ecard_rname5'];
	
	if($antispam_check == "Y")
	{
		spammer_killer();
	}
	
	if( empty($ecard_notify) )
	{
		$ecard_notify = 0;
	}
	if( $ecard_tosend == date("Y-m-d") )
	{
		// send mail to the recipient notifying about postcard
		if(!empty($ecard_remail) and !empty($ecard_rname) and !empty($ecard_sname) and !empty($ecard_semail)){
			SendPickupMail($ecard_remail,$ecard_rname,$ecard_sname,$ecard_semail,$card_image,$stamp_file, $ecard_message,$ecard_sig,$ecard_heading,$sound_file,$pattern_file,$ecard_color,$card_template,$ecard_fontface,$ecard_fontcolor,$ecard_fontsize,$ecard_notify,$ecard_tosend,$ecard_sent);
		}
		if(!empty($ecard_remail1) and !empty($ecard_rname1) and !empty($ecard_sname) and !empty($ecard_semail)){
			SendPickupMail($ecard_remail1,$ecard_rname1,$ecard_sname,$ecard_semail,$card_image,$stamp_file, $ecard_message,$ecard_sig,$ecard_heading,$sound_file,$pattern_file,$ecard_color,$card_template,$ecard_fontface,$ecard_fontcolor,$ecard_fontsize,$ecard_notify,$ecard_tosend,$ecard_sent);
		}
		if(!empty($ecard_remail2) and !empty($ecard_rname2) and !empty($ecard_sname) and !empty($ecard_semail)){
			SendPickupMail($ecard_remail2,$ecard_rname2,$ecard_sname,$ecard_semail,$card_image,$stamp_file, $ecard_message,$ecard_sig,$ecard_heading,$sound_file,$pattern_file,$ecard_color,$card_template,$ecard_fontface,$ecard_fontcolor,$ecard_fontsize,$ecard_notify,$ecard_tosend,$ecard_sent);
		}
		if(!empty($ecard_remail3) and !empty($ecard_rname3) and !empty($ecard_sname) and !empty($ecard_semail)){
			SendPickupMail($ecard_remail3,$ecard_rname3,$ecard_sname,$ecard_semail,$card_image,$stamp_file, $ecard_message,$ecard_sig,$ecard_heading,$sound_file,$pattern_file,$ecard_color,$card_template,$ecard_fontface,$ecard_fontcolor,$ecard_fontsize,$ecard_notify,$ecard_tosend,$ecard_sent);
		}
		if(!empty($ecard_remail4) and !empty($ecard_rname4) and !empty($ecard_sname) and !empty($ecard_semail)){
			SendPickupMail($ecard_remail4,$ecard_rname4,$ecard_sname,$ecard_semail,$card_image,$stamp_file, $ecard_message,$ecard_sig,$ecard_heading,$sound_file,$pattern_file,$ecard_color,$card_template,$ecard_fontface,$ecard_fontcolor,$ecard_fontsize,$ecard_notify,$ecard_tosend,$ecard_sent);
		}
	}
	else
	{
		if(!empty($ecard_remail) and !empty($ecard_rname) and !empty($ecard_sname) and !empty($ecard_semail)){
			SaveAdvancePost($ecard_remail,$ecard_rname,$ecard_sname,$ecard_semail,$card_image,$stamp_file, $ecard_message,$ecard_sig,$ecard_heading,$sound_file,$pattern_file,$ecard_color,$card_template,$ecard_fontface,$ecard_fontcolor,$ecard_fontsize,$ecard_notify,$ecard_tosend,$ecard_sent);
		}
		if(!empty($ecard_remail1) and !empty($ecard_rname1) and !empty($ecard_sname) and !empty($ecard_semail)){
			SaveAdvancePost($ecard_remail1,$ecard_rname1,$ecard_sname,$ecard_semail,$card_image,$stamp_file, $ecard_message,$ecard_sig,$ecard_heading,$sound_file,$pattern_file,$ecard_color,$card_template,$ecard_fontface,$ecard_fontcolor,$ecard_fontsize,$ecard_notify,$ecard_tosend,$ecard_sent);
		}
		if(!empty($ecard_remail2) and !empty($ecard_rname2) and !empty($ecard_sname) and !empty($ecard_semail)){
			SaveAdvancePost($ecard_remail2,$ecard_rname2,$ecard_sname,$ecard_semail,$card_image,$stamp_file, $ecard_message,$ecard_sig,$ecard_heading,$sound_file,$pattern_file,$ecard_color,$card_template,$ecard_fontface,$ecard_fontcolor,$ecard_fontsize,$ecard_notify,$ecard_tosend,$ecard_sent);
		}
		if(!empty($ecard_remail3) and !empty($ecard_rname3) and !empty($ecard_sname) and !empty($ecard_semail)){
			SaveAdvancePost($ecard_remail3,$ecard_rname3,$ecard_sname,$ecard_semail,$card_image,$stamp_file, $ecard_message,$ecard_sig,$ecard_heading,$sound_file,$pattern_file,$ecard_color,$card_template,$ecard_fontface,$ecard_fontcolor,$ecard_fontsize,$ecard_notify,$ecard_tosend,$ecard_sent);
		}
		if(!empty($ecard_remail4) and !empty($ecard_rname4) and !empty($ecard_sname) and !empty($ecard_semail)){
			SaveAdvancePost($ecard_remail4,$ecard_rname4,$ecard_sname,$ecard_semail,$card_image,$stamp_file, $ecard_message,$ecard_sig,$ecard_heading,$sound_file,$pattern_file,$ecard_color,$card_template,$ecard_fontface,$ecard_fontcolor,$ecard_fontsize,$ecard_notify,$ecard_tosend,$ecard_sent);
		}
	}

		@setcookie ('vcecard_sname', $ecard_sname, time()+3600, '/');
		@setcookie ('vcecard_semail', $ecard_semail, time()+3600, '/');
		@setcookie ('vcecard_rname', '', 3600, '/');
		@setcookie ('vcecard_remail', '', 3600, '/');
		
	dovcardliteheader();
	?>
	<br>
	<p>
	<?php
	echo TagFont($SiteFontFace,3,1,1,"<a href='$SiteURL'>$SiteName</a>");
	echo TagFont($SiteFontFace,3,1,1,"<a href='$SiteURL'>$MsgSendAnotherCard</a>");
	?>
	
	</font>
	<p> </p>
<?php
	dovcardlitefooter();
}
?>