winsettings = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,';
function colorwin(){ cyber=window.open('win.php?Info=Colors', 'info', winsettings + 'width=250,height=280') }
function bgroundwin(){ cyber=window.open('win.php?Info=Background', 'info2',  winsettings + 'width=250,height=290') }
function emoticonwin(){ cyber=window.open('win.php?Info=Emoticons', 'info4', winsettings + 'width=430,height=370') }
function exturl(){ cyber=window.open('win.php?Info=Custom', 'info5', winsettings + 'width=450,height=270') }
function notify(){ cyber=window.open('win.php?Info=Notify', 'info6', winsettings + 'width=300,height=140') }
function fontface(){ cyber=window.open('win.php?Info=Fonts', 'info7', winsettings + 'width=550,height=270') }
function stampwin(){ cyber=window.open('win.php?Info=Stamp', 'info8', winsettings + 'width=250,height=290') }
function playmusic(formObj)
{
	musicName = formObj.sound_file.options[formObj.sound_file.selectedIndex].value;
	if(musicName != ""){
	 	x=window.open('','info9', winsettings + 'width=200,height=50');
		x.document.write('<html><head><title>Music</title></head><body style="body; margin: 0px 0px 0px 0px;">\n');
		x.document.write('<embed src="'+ sound_fileURL + musicName +'" height="25" width="150" autostart="true" loop="true"><noembed><bgsound src="'+ sound_fileURL + musicName +'" loop="infinite"></noembed>\n');
		x.document.write('</body></html>');
	}else{
	   alert(MsgWinMusicNote);
	}
}
function addrecp(formObj){
  NumberRecp = formObj.addrecip.options[formObj.addrecip.selectedIndex].value;
  if(NumberRecp != ""){
    window.location="create.php?" + query_string + "&addrecip=" + NumberRecp;
  }
}
