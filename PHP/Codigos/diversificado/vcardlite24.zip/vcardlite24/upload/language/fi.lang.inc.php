<?php
/*************************************************************************
      language      : Finnish - Suomi
      file          : fi.lang.inc.php
      begin         : 2002-02-15
	  last updated  : 2003-02-19 (translated)
      translator    : kestrel (kestrel@tukirengas.net)
      home          : http://www.rdcollins.net
      charset       : ISO-8859-1
*************************************************************************/
$charset			='iso-8859-1';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect		= "Ei yhteytt� tietokantaan!";
$MsgUnableLocateDB		= "Tietokantaa ei l�ydy!";
$MsgErrorPerformingQuery	= "Hakuvirhe";

// Create, Preview and View Page
$MsgImage			= "Kuva";
$MsgYourTitle			= "Otsikko";
$MsgMessage			= "Viesti";
$MsgFont			= "Fontti";
$MsgNoFontFace			= "Ei fonttivalintaa";
$MsgFontSizeSmall		= "Pieni";
$MsgFontSizeMedium		= "Keskikoko";
$MsgFontSizeLarge		= "Suuri";
$MsgFontSizeXLarge		= "Eritt�in suuri";
$MsgFontColorBlack		= "Musta";
$MsgFontColorWhite		= "Valkoinen";
$MsgSignature			= "Allekirjoitus";
$MsgRecpName			= "Vastaanottaja";
$MsgRecpEmail			= "Vastaanottajan s�hk�posti";
$MsgAddRecp			= "Vastaanottajat";
$MsgPlay			= "Kuuntele";
$MsgYourName			= "L�hett�j�";
$MsgYourEmail			= "L�hett�j�n s�hk�posti";
$MsgChooseLayout		= "Valitse kortin asettelu";
$MsgChooseDate			= "Kortin l�hetysp�iv�";
$MsgDateFormat			= "Valitse p�iv�, oikea muoto on pv/kk/vuosi (4 num.), l�hett��ksesi kortin nyt.";
$MsgChooseStamp			= "Valitse postimerkki";
$MsgPostColor			= "Kortin taustav�ri";
$MsgPageBackground		= "Taustakuva";
$MsgNone			= "Ei";
$MsgMusic			= "Musiikki";
$MsgPreviewButton		= "Esikatsele";
$MsgNotify			= "Ilmoita, kun vastaanottaja on n�hnyt t�m�n kortin.";
$MsgYes				= "Kyll�";
$MsgNo				= "Ei";
$MsgNoFlash			= "T�m�n kortin esitt�minen tarvitsee Flash-tuen. ";
$MsgClickHereToGet		= "Lataa se t�st�!";
$MsgHelp			= "Ohje!";
$MsgCloseWindow			= "Sulje";
$MsgPrintable                   = "Tulostettava versio";

// Error Messages
$MsgActiveJS			= "Aktivoi JavaScript";
$MsgErrorMessage		= "Viestikentt� on tyhj�.";
$MsgErrorRecpName		= "Vastaanottajan nimi puuttuu.";
$MsgErrorRecpEmail		= "Vastaanottajan s�hk�postiosoite puuttuu.";
$MsgErrorRecpEmail2		= "Vastaanottajan <B>s�hk�postiosoite</B> on viallinen.";
$MsgErrorSenderName		= "L�hett�j�n nimi puuttuu.";
$MsgErrorSenderEmail		= "L�hett�j�n s�hk�postiosoite puuttuu.";
$MsgErrorSenderEmail2		= "L�hett�j�n <B>s�hk�postiosoite</B> on viallinen.";
$MsgErrorNotFoundTxt		= "Korttia ei l�ydy. Annoit joko v��r�n kortin numeron, tai kortti on vanhentuneena poistettu.";

$MsgBackEditButton		= "Takaisin";
$MsgSendButton			= "L�het�!";

$MsgSendTo			= "L�het� vastaanottajalle:";
$MsgClickHere			= "Paina t�st�";
$MsgAvoidDuplicat		= "Paina vain kerran v�ltt��ksesi tuplal�hetyksen!";

// Info Windows
$MsgWinEmoticons		= "Hymi�t";
$MsgWinEmoticonsNote		= "Kaikki merkit ovat suuraakoosia (O ja P)!";
$MsgWinEmoticonsNoteFotter	= "<B>Jos</B> Jos ET halu k�ytt�� graaffisia hymi�it�, k�yt� 'lyhennetty�' muotoa, eli kirjoita hymi� ilman 'nen��'.";
$MsgWinBackground		= "Taustakuva";
$MsgWinStamp			= "Postimerkki";
$MsgWinColors			= "V�rit";
$MsgWinMusic			= "Musiikki";
$MsgWinMusicNote		= "Valitse:";
$MsgWinNotify			= "Haluatko saada ilmoituksen, kun vastaanottaja on lukenut korttisi?";
$MsgWinFonts			= "Fontit";
$MsgWinFontsNote		= "Jos haluat k�ytt�� t�t� optiota, <FONT COLOR=red>muista:</FONT> Kaikki eiv�t v�ltt�m�tt� n�e fonttia oikein. (Koska fonttia ei ehk� ole asennettu vastaanottajan koneelle. T�ll�in vastaanottaja n�kee oletusfontin, tavallisesti Times, Arial tai Helvetica.";
$MsgWinName			= "Nimi";
$MsgWinSample			= "Esimerkki";
$MsgWinSampleString		= "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard		= "L�het� lis�� kortteja";

// Advanced Send
$MsgNPostSent			= "Kortit l�hetetty t�lt� er��..";

// Admin Page
$MsgAdminPage			= "Ohjauspaneeli";
$MsgAdminCardControlTitle	= "Postikorttikontrolli";
$MsgAdminCardControlNote	= "Ohjelma poistaa kortit, kun ne ovat XX p�iv�� vanhoja.";
$MsgAdminDay			= "P�iv��";
$MsgAdminDelOption1		= "Katsotut kortit";
$MsgAdminDelOption2		= "Katsomattomat kortit";
$MsgAdminDeleteButton		= "Poista kortit";
$MsgAdminDeletedCards		= "Kortit poistettu tietokannasta.";

$MsgAdminWarning		= "VAROITUS!";
$MsgAdminWarning2		= "T�m� poistaa kaikki kortit, jotka ovat:";
$MsgAdminWarningReaded		= "luettuja";
$MsgAdminWarningNotReaded	= "lukemattomia";
$MsgAdminWarning3		= "ja ovat";
$MsgAdminWarning4		= "p�iv�� vanhoja.";
$MsgAdminWarning5		= "Oletko varma? Kaikki m��ritellyt kriteerit t�ytt�v�t kortit poistetaan.";
$MsgAdminWarningButtonYes	= "Kyll�!";
$MsgAdminWarningButtonNo	= "Ei!";
$MsgAdminWarningNoCardDelete	= "M��ritellyt ehdot t�ytt�vi� kortteja ei l�ytyny.";

$MsgAdminPatternControlTitle	= "V�rikontrolli";
$MsgAdminMusicControlTitle	= "Musiikkikontrolli";
$MsgAdminStampControlTitle	= "Postimerkkikontrolli";
$MsgAdminIncluded		= "Lis�tty";
$MsgAdminNoIncluded		= "a EI lis�tty";
$MsgAdminDeleted		= "Poistettu";
$MsgAdminNoDeleted		= "a EI poistettu";
$MsgAdminFormFieldEmpty		= "Kentt� on tyhj�. Palaa korjaamaan!";

$MsgAdminModified		= "Muokattu";
$MsgAdminNoModified		= "a EI muokattu";

$MsgAdminInclude		= "Lis��"; 
$MsgAdminDelete			= "Poista"; 
$MsgAdminEdit			= "Muokkaa";
$MsgAdminModify			= "Muokkaa";

$MsgAdminControlMusicFile	= "Musiikkitiedosto";
$MsgAdminControlMusicName	= "Kappale";
$MsgAdminControlMusicAuthor	= "Esitt�j�";
$MsgAdminControlMusicGenre	= "Musiikkilaji";

$MsgAdminControlPatternFile	= "Taustakuvatiedoston nimi";
$MsgAdminControlPatternName	= "Taustan nimi";
$MsgAdminControlStampFile	= "Postimerkkikuvatiedoto";
$MsgAdminControlStampName	= "Postimerkin nimi";

$MsgAdminControlPostImgFile	= "(Iso) Korttikuva";
$MsgAdminControlPostThmFile	= "Pikkukuva";
$MsgAdminControlPostTemplate	= "Mallitiedosto";

$MsgAdminPostcardControlTitle	= "Korttikontrolli";
$MsgAdminCategoryControlTitle	= "Ryhm�kontrolli";

$MsgAdminExtraInfoTitle		= "Lis�tiedot";

$MsgAdminNote			= "HUOM";
$MsgAdminNoteMust		= "Tiedosto on siirrett�v� osoitteeseen:";

// Extra Info:
$MsgvCardLiteCommunity		= "vCard Lite Community (tukifoorumi)";
$MsgYourVersion			= "T�m� versio";
$MsgAvaibaleVersion		= "Saatavilla oleva versio";

// Statistic Page
$MsgAdminCardStatTitle		= "Tilasto";
$MsgAdminControlImageFile 	= "Kuvatiedosto";
$MsgAdminTemplateFile 		= "Mallitiedosto";
$MsgSeeYourStat			= "N�hd�ksesi postikorttipalvelun tilastot";
$MsgPosition 			= "Sijainti";
$MsgHits			= "Osumat";
$MsgTop 			= "Parhaat ";

$MsgAdminStatsRestart		= "Nollaa tilastot";
$MsgAdminStatsDbEmpty		= "Tilastotietokanta ON tyhj�";
$MsgAdminStatsDbNoEmpty		= "Tilastotietokanta EI OLE tyhj�";
$MsgAdminStatsNote		= "Jos haluat tyhjent�� tilastot, Voit tehd� sen painamalla t�st�. Muistathan kuitenkin, ett� se poistaa kaikki tilastotiedot. Jos haluat kuitenkin s�ilytt�� tiedot, ota tiedostosta varmuuskopio omalle kovalevyllesi.";

// Gallery Browser Pages
$MsgNext			= "Seuraava";
$MsgPrevious			= "Edellinen";
$MsgBackCatMain			= "Takaisin ryhmien p��sivulle";

$MsgNoCardsinDB			= "Ei kortteja tietokannassa.";
$MsgInvalidePageNumber		= "Annoit viallisen sivunumeron";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Ryhm�n nimi";
$MsgAdminGalleryControlTitle	= "Gallerian kontrolli";

$MsgAdminLinkBrowser		= "Selaa";
$MsgAdminLinkEdit		= "Muokkaa";
$MsgAdminLinkDelete		= "Poista";

// MENU
$MsgMusic			= "Musiikki";
$MsgPattern			= "Pohja";
$MsgMain			= "P��valinta";
$MsgGallery			= "Galleria";
$MsgStamp			= "Postimerkki";
$MsgStats			= "Tilastot";
$MsgAdminBrowser		= "Selaa";
$MsgPHPInfo			= "PHP Info";

$MsgCategories			= "Ryhm�t";
$MsgCategory			= "Ryhm�";
$MsgPostcards			= "Kortti";

// Back Link Messages
$MsgBack			= "Takaisin";
$MsgBackButton			= "Edelliselle sivulle";
$MsgBacktoSection		= "Edelliseen osioon";

// File Upload
$MsgUploadYourOwnFileTitle	= "K�yt� omaa kuvaa";
$MsgUploadYourOwnFileInfo	= "Luo kortti k�ytt�m�ll� omaa kuvaa.";
$MsgErrorFileExtension		= "Tiedosto ei kelpaa. Vain .gif, .jpeg, .jpg ja .swf tiedostot hyv�ksyt��n!";
$MsgFileBiggerThan		= "Tiedoton koko ylitt�� "; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed		= "Suurin sallittu kuvakoko on "; // Fhe max size of file is XX Kbytes
$MsgFileAllowed			= "Voit l�hett�� oman kuvasi(.gif, .jpg) tai flash-animaation(.swf) ja luoda oman korttisi. Valitse tiedosto ja paina l�hetysnappia.";
$MsgFileUploadNotAllowed	= "Tiedoston l�hett�minen on estetty t�ss� j�rjestelm�ss�.";
$MsgFileSend			= "L�het� tiedosto!";
$MsgFileSelect			= "L�het� tiedosto";
$MsgFileUseFile			= "Luo postikortti";

// added v2.4

$MsgSLog = 'Loki';
$MsgAdminEntries = 'Rekister�innit';
$MsgAdminLogRestart = 'Aloita loki uudelleen.';
$MsgAdminLogNote = 'Jos haluat aloittaa/tyhjent�� lokin, Voit tehd� sen painamalla t�st�. Muistutamme kuitenkin, ett� kaikki vanhat tiedot katoavat. Suosittelemme ottamaan lokitiedostosta ensin varmuuskopion..';
$MsgAdminLogRname = 'Vastaanottajan nimi';
$MsgAdminLogRemail = 'Vastaanottajan s�hk�posti';
$MsgAdminLogSname = 'L�hett�j�n nimi';
$MsgAdminLogSemail = 'L�hett�j�n s�hkposti';
$MsgAdminLogSip = 'L�hett�j�n IP';
$MsgAdminLogDate = 'P�iv�';
$MsgAdminLogSentDate = 'L�hetetty/L�hetysp�iv�';
$MsgAdminLogEcard = 'E-Kortti';
?>

