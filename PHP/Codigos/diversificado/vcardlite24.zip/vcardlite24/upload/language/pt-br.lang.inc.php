<?php
/*************************************************************************
      language      : brazilian portuguese
      file          : port-brazil.lang.inc.php
      begin         : 2001-02-15
	  last updated  : 2002-10-22
      copyright     : (c) 2001-2002 by Belchior Foundry
      home          : http://www.belchiorfoundry.com/
      charset       : ISO-8859-1
*************************************************************************/
$charset			='ISO-8859-1';
$htmldir			='ltr';
// database error messages
$MsgUnableConnect		= "Incapaz de se conectar ao servidor de banco de dados neste momento!";
$MsgUnableLocateDB		= "Incapaz de localizar o banco de dados neste momento!";
$MsgErrorPerformingQuery	= "Erro ao realizar query no banco de dados";

// Create, Preview and View Page
$MsgImage			= "Imagem";
$MsgYourTitle			= "Seu T�tulo";
$MsgMessage			= "Mensagem";
$MsgFont			= "Fonte";
$MsgNoFontFace			= "Nenhuma Fonte de Letra";
$MsgFontSizeSmall		= "Tamanho Pequeno";
$MsgFontSizeMedium		= "Tamanho M�dio";
$MsgFontSizeLarge		= "Tamanho Grande";
$MsgFontSizeXLarge		= "Tamanho X-Grande";
$MsgFontColorBlack		= "Cor Preta";
$MsgFontColorWhite		= "Cor Branca";
$MsgSignature			= "Assinatura";
$MsgRecpName			= "Nome do destinat�rio";
$MsgRecpEmail			= "E-mail do destinat�rio";
$MsgAddRecp			= "destinat�rios";
$MsgPlay			= "PLAY";
$MsgYourName			= "Seu nome";
$MsgYourEmail			= "Seu e-mail";
$MsgChooseLayout		= "Escolha o layout do cart�o";
$MsgChooseDate			= "Data para enviar o cart�o?";
$MsgDateFormat			= "Escolha o dia atua, que est� no formato DD/MM/AAAA, para enviar o seu cart�o agora.";
$MsgChooseStamp			= "Escolha o selo";
$MsgPostColor			= "Cor de fundo";
$MsgPageBackground		= "Papel de parede";
$MsgNone			= "Nenhum";
$MsgMusic			= "M�sica";
$MsgPreviewButton		= "Pr�via antes de enviar";
$MsgNotify			= "Notificar-me via e-mail quando o destinat�rio ler o cart�o.";
$MsgYes				= "Sim";
$MsgNo				= "N�o";
$MsgNoFlash			= "Voc� precisa do plug-in Flash player para visualizar a vers�o Flash do cart�o.";
$MsgClickHereToGet		= "Clique aqui para pegar o seu!";
$MsgHelp			= "Ajuda!";
$MsgCloseWindow			= "Fechar Janela";
$MsgPrintable                   = "Vers�o para Impress�o";

// Error Messages
$MsgActiveJS			= "Por favor abilite o javascript de seu navegador!";
$MsgErrorMessage		= "Voc� precisa escrever uma mensagem no seu cart�o.";
$MsgErrorRecpName		= "Voc� precisa fornecer o nome do destinat�rio.";
$MsgErrorRecpEmail		= "Voc� precisa fornecer o e-mail do destinat�rio.";
$MsgErrorRecpEmail2		= "O <B>endere�o de e-mail</B> do destinat�rio est� incorreto.";
$MsgErrorSenderName		= "Voc� precisa fornecer seu nome.";
$MsgErrorSenderEmail		= "Voc� precisa fornecer seu e-mail.";
$MsgErrorSenderEmail2		= "Seu <B>endere�o de e-mail</B> est� incorreto.";
$MsgErrorNotFoundTxt		= "Desculpe, nenhum cart�o foi encontrado com o dados fornecidos. Voc� pode ter errado na digita��o do endere�o ou o cart�o era muito antigo e j� foi retirado de nosso banco de dados.";

$MsgBackEditButton		= "Voltar para Editar";
$MsgSendButton			= "Enviar o Car�o!";

$MsgSendTo			= "Envie um cart�o para";
$MsgClickHere			= "clique aqui";
$MsgAvoidDuplicat		= "Clique apenas uma vez para evitar duplicatas!";

// Info Windows
$MsgWinEmoticons		= "Emoticons";
$MsgWinEmoticonsNote		= "Todos as letras devem ser em letra mai�scula (O e P)!";
$MsgWinEmoticonsNoteFotter	= "<B>Se</B> n�o quer utilizar emoticons gr�ficos, apenas retire o nariz.";
$MsgWinBackground		= "Papel de parede";
$MsgWinStamp			= "Selo";
$MsgWinColors			= "Cores";
$MsgWinMusic			= "M�sica";
$MsgWinMusicNote		= "Escolha uma op��o.";
$MsgWinNotify			= "Voc� deseja receber um e-mail de notifica��o quando o cart�o que voc� enviou for retirado pelo destinat�rio?";
$MsgWinFonts			= "Fontes de Letra";
$MsgWinFontsNote		= "Se voc� quiser utilizar esta op��o, <FONT COLOR=red>aten��o</FONT>: n�o s�o todos que possuim as mesmas fontes que est�o instaladas no seu computador. Se n�o estiver instalado a fonte padr�o utilizada ser� normalmente Times New Roman, Arial ou Helvetica.";
$MsgWinName			= "Nome";
$MsgWinSample			= "Exemplo";
$MsgWinSampleString		= "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard		= "Envie outro cart�o virtual";

// Advanced Send
$MsgNPostSent			= "cart�es foram enviados neste momento.";

// Admin Page
$MsgAdminPage			= "Painel de Controle";
$MsgAdminCardControlTitle	= "Controle de Cart�es";
$MsgAdminCardControlNote	= "Esta fun��o ir� apagar todos os cart�es que forem XX dias antigos do sistema.";
$MsgAdminDay			= "Dias";
$MsgAdminDelOption1		= "Apenas cart�es que tenham sido lidos";
$MsgAdminDelOption2		= "Apenas cart�es que N�O tenham sido lidos";
$MsgAdminDeleteButton		= "Apagar cart�es";
$MsgAdminDeletedCards		= "cart�es foram apagados do banco de dados.";

$MsgAdminWarning		= "Aten��o!";
$MsgAdminWarning2		= "Esta op��o ir� apagar todos os cart�es do seu banco de dados que";
$MsgAdminWarningReaded		= "foram lidos";
$MsgAdminWarningNotReaded	= "n�o foram lidos";
$MsgAdminWarning3		= "e que foram postados a mais de";
$MsgAdminWarning4		= "dias.";
$MsgAdminWarning5		= "cart�es ser�o deletados baseados no seu crit�rio de sele��o. Voc� tem certeza em continuar?";
$MsgAdminWarningButtonYes	= "Sim, eu tenho!";
$MsgAdminWarningButtonNo	= "N�o, por favor pare!";
$MsgAdminWarningNoCardDelete	= "Nenhum cart�o ser� deletado baseado neste crit�rio. Volte e selecione um novo crit�rio.";

$MsgAdminPatternControlTitle	= "Controle dos Pap�is de parede";
$MsgAdminMusicControlTitle	= "Controle das M�sicas";
$MsgAdminStampControlTitle	= "Controle dos Selos";
$MsgAdminIncluded		= "registro INCLUIDO";
$MsgAdminNoIncluded		= "registro N�O INCLUIDO";
$MsgAdminDeleted		= "registro APAGADO";
$MsgAdminNoDeleted		= "registro N�O APAGADO";
$MsgAdminModified		= "registro MODIFICADO";
$MsgAdminNoModified		= "registro N�O MODIFICADO";

$MsgAdminFormFieldEmpty		= "campo do formul�rio est� vazio. Volte e tente novamente!";

$MsgAdminInclude		= "Incluir"; 
$MsgAdminDelete			= "Apagar"; 
$MsgAdminEdit			= "Editar";
$MsgAdminModify			= "Modificar";

$MsgAdminControlMusicFile	= "Arquivo de m�sica";
$MsgAdminControlMusicName	= "Nome da m�sica";
$MsgAdminControlMusicAuthor	= "Autor da m�sica";
$MsgAdminControlMusicGenre	= "G�nero da m�sica";

$MsgAdminControlPatternFile	= "Arquivo do papel de parede";
$MsgAdminControlPatternName	= "Nome do papel de parede";

$MsgAdminControlStampFile	= "Arquivo do selo";
$MsgAdminControlStampName	= "Nome do selo";

$MsgAdminControlPostImgFile	= "Arquivo do cart�o";
$MsgAdminControlPostThmFile	= "Arquivo do Thumbnail do cart�o";
$MsgAdminControlPostTemplate	= "Nome do Template";

$MsgAdminPostcardControlTitle	= "Controle de Cart�es";
$MsgAdminCategoryControlTitle	= "Controle de Categorias";

$MsgAdminExtraInfoTitle		= "Informa��o Extra";

$MsgAdminNote			= "Obs";
$MsgAdminNoteMust		= "O arquivo deve ser enviado para";

// Extra Info:
$MsgvCardLiteCommunity		= "Comunidade do vCard Lite";
$MsgYourVersion			= "Sua vers�o";
$MsgAvaibaleVersion		= "Vers�o dispon�vel";

// Statistic Page
$MsgAdminCardStatTitle		= "Estat�sticas";
$MsgAdminControlImageFile 	= "Arquivo de Imagem";
$MsgAdminTemplateFile 		= "Arquivo Template";
$MsgSeeYourStat			= "Para visualizar as estat�sticas do servi�o";
$MsgPosition 			= "Posi��o";
$MsgHits			= "Hits";
$MsgTop 			= "Top ";

$MsgAdminStatsRestart		= "Reiniciar Estat�sticas";
$MsgAdminStatsDbEmpty		= "Banco de dadoso das estat�sticas est�o vazia";
$MsgAdminStatsDbNoEmpty		= "Banco de dadoso das estat�sticas N�O est�o vazia";
$MsgAdminStatsNote		= "Se voc� quiser reniniciar as estat�sticas sinta se livre para faze-lo clicando no bot�o abaixo. Lembre-se que as informa��es contidas no banco de dados ser�o apagados tamb�m. Mantenha uma c�pia destas informa��es no seu disco r�gido do seu computador.";

// Gallery Browser Pages
$MsgNext			= "Pr�ximo";
$MsgPrevious			= "Anterior";
$MsgBackCatMain			= "Voltar para p�gina de categorias";

$MsgNoCardsinDB			= "Desculpe, n�o existe cart�es no banco de dados.";
$MsgInvalidePageNumber		= "Voc� especificou um n�mero de p�gina inv�lido";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Nome da Categoria";
$MsgAdminGalleryControlTitle	= "Controle da Galeria";

$MsgAdminLinkBrowser		= "visualizar";
$MsgAdminLinkEdit		= "editar";
$MsgAdminLinkDelete		= "apagar";

// MENU
$MsgMusic			= "M�sica";
$MsgPattern			= "Papel de parede";
$MsgMain			= "Principal";
$MsgGallery			= "Galeria";
$MsgStamp			= "Selo";
$MsgStats			= "Estat�sticas";
$MsgAdminBrowser		= "Visualizar";
$MsgPHPInfo			= "Info. PHP";

$MsgCategories			= "Categorias";
$MsgCategory			= "Categoria";
$MsgPostcards			= "Cart�es";

// Back Link Messages
$MsgBack			= "Voltar";
$MsgBackButton			= "Voltar para P�gina Anterior";
$MsgBacktoSection		= "Voltar para Se��o Anterior";

// File Upload
$MsgUploadYourOwnFileTitle	= "Use sua pr�pria imagem";
$MsgUploadYourOwnFileInfo	= "Crie um cart�o utilizando sua pr�pria imagem.";
$MsgErrorFileExtension		= "Extens�o de arquivo n�o permitido. O arquivo deve ter uma das seguintes extens�es .gif, .jpg ou .swf e em letras min�sculas!";
$MsgFileBiggerThan		= "O arquivo tem mais de"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed		= "O tamanho m�ximo permito para o arquivo ser enviado � de"; // Fhe max size of file is XX Kbytes
$MsgFileAllowed			= "Voc� pode enviar sua pr�pria imagem(.gif, .jpg) ou arquivo flash(.swf) para criar um cart�o personalizado. Seleiona o arquivo e clique no bot�o Enviar Arquivo.";
$MsgFileUploadNotAllowed	= "O envio de arquivos est� desabilitado neste site! Desculpe.";
$MsgFileSend			= "Enviar Arquivo!";
$MsgFileSelect			= "Selecionar seu arquivo";
$MsgFileUseFile			= "Criar cart�o";

// added v2.4

$MsgSLog = 'Log te servi�o';
$MsgAdminEntries = 'registros';
$MsgAdminLogRestart = 'Reiniciar o Log de servi�o';
$MsgAdminLogNote = 'Se voc� quiser reiniciar/limpar o log do servi�o sinta-se livre para isso mas antes considere criar uma c�pia no seu computador, pois todos os dados ser�o eliminados no seu servidor.';
$MsgAdminLogRname = 'Destint�rio';
$MsgAdminLogRemail = 'Email Destin.';
$MsgAdminLogSname = 'Remetente';
$MsgAdminLogSemail = 'Email do Remet.';
$MsgAdminLogSip = 'IP do Remet.';
$MsgAdminLogDate = 'Data';
$MsgAdminLogSentDate = 'Data de Envio';
$MsgAdminLogEcard = 'Cart�o';


?>