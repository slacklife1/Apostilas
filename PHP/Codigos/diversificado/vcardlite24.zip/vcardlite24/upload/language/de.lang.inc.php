<?php
/*************************************************************************
      language      : deutsch
      file          : de.lang.inc.php
      begin         : 2002-10-26
	  last updated  : 2003-01-30
      translator    : Danilo (danilo@linkdb.de)
      home          : http://www.linkdb.de (vcard-mods)
      forum         : http://forum.linkdb.de
      charset       : ISO-8859-1

      Hinwei� zu Fehlern oder Verbesserungen des Languagefiles bitte an mich per Email.Danke!
*************************************************************************/
$charset			='iso-8859-1';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect	= "Leider keine Verbindung zum Datenbankserver!";
$MsgUnableLocateDB	= "Die Datenbank kann leider nicht gefunden werden!";
$MsgErrorPerformingQuery = "Fehler beim Ausf&uuml;hren der Abfrage";

// Create, Preview and View Page
$MsgImage			= "Bild";
$MsgYourTitle		= "&Uuml;berschrift";
$MsgMessage			= "Nachricht";
$MsgFont			= "Schrifteinstellungen";
$MsgNoFontFace		= "keine Schriftart";
$MsgFontSizeSmall	= "kleine Schrift";
$MsgFontSizeMedium	= "mittlere Schrift";
$MsgFontSizeLarge	= "gro&szlig;e Schrift";
$MsgFontSizeXLarge	= "rie&szlig;ige Schrift";
$MsgFontColorBlack	= "Schwarz";
$MsgFontColorWhite	= "Wei&szlig;";
$MsgSignature		= "Gr&uuml;&szlig;e";
$MsgRecpName		= "Empf&auml;ngername";
$MsgRecpEmail		= "Empf&auml;ngeremail";
$MsgAddRecp			= "Empf&auml;nger hinzuf&uuml;gen";
$MsgPlay			= "Anh&ouml;ren";
$MsgYourName		= "Dein Name";
$MsgYourEmail		= "Deine Email";
$MsgChooseLayout	= "W&auml;hle Dein Kartenlayout";
$MsgChooseDate		= "Wann verschicken?";
$MsgDateFormat		= "W&auml;hle den heutigen Tag um die Karte sofort zu versenden.";
$MsgChooseStamp		= "W&auml;hle eine Briefmarke";
$MsgPostColor		= "Hintergrundfarbe";
$MsgPageBackground	= "Hintergrundbild";
$MsgNone			= "keine";
$MsgMusic			= "Musik";
$MsgPreviewButton	= "Vorschau der Karte";
$MsgNotify			= "Benachrichtigung per Email, wenn die Karte gelesen wurde.";
$MsgYes				= "Ja";
$MsgNo				= "Nein";
$MsgNoFlash			= "Du ben&ouml;tigst ein Flash-plugin um die Karte anzusehen.";
$MsgClickHereToGet	= "Hier klicken!";
$MsgHelp			= "Hilfe!";
$MsgCloseWindow		= "Schlie&szlig;e Fenster";
$MsgPrintable       = "Druckversion";

// Error Messages
$MsgActiveJS			= "Bitte aktiviere Javascript!";
$MsgErrorMessage		= "Du hast den Text vergessen.";
$MsgErrorRecpName		= "Bitte den Empf&auml;ngername eingeben.";
$MsgErrorRecpEmail		= "Bitte die Emailadresse des Empf&auml;ngers eingeben.";
$MsgErrorRecpEmail2		= "Die Email des Empf&auml;ngers ist vermutlich ung&uuml;ltig.";
$MsgErrorSenderName		= "Bitte Dein Name eingeben.";
$MsgErrorSenderEmail	= "Bitte Deine Email eingeben.";
$MsgErrorSenderEmail2	= "Deine Emailadresse ist vermutlich ung&uuml;ltig.";
$MsgErrorNotFoundTxt	= "Sorry, diese Postkarte ist ung&uuml;ltig. Vermutlich ist die ID falsch, oder Ihre Postkarte wurde nach Ablauf der Aufbewahrungsfrist vom System automatisch gel&ouml;scht.";

$MsgBackEditButton		= "Zur&uuml;ck zum Bearbeiten";
$MsgSendButton			= "Postkarte versenden!";

$MsgSendTo				= "Sende eine Postkarte an";
$MsgClickHere			= "Hier klicken";
$MsgAvoidDuplicat		= "Bitte nur einmal klicken!";

// Info Windows
$MsgWinEmoticons		= "Emoticons";
$MsgWinEmoticonsNote	= "Alle Buchstaben gro&szlig; schreiben (O and P)!";
$MsgWinEmoticonsNoteFotter	= "Wenn f&uuml;r das Smiley keine Grafik dargestellt werden soll, muss die Nase (also das Minus) des Smileys weggelassen werden.";
$MsgWinBackground		= "Hintergrundbild";
$MsgWinStamp			= "Briefmarke";
$MsgWinColors			= "Farben";
$MsgWinMusic			= "Musik";
$MsgWinMusicNote		= "W&auml;hle etwas aus.";
$MsgWinNotify			= "M&ouml;chtest Du eine Benachrichtigung per Email, wenn der Empf&auml;nger die Gru&szlig;karte gelesen hat?";
$MsgWinFonts			= "Schrift";
$MsgWinFontsNote		= "Beachte, nicht jeder hat all diese Schriftarten auf seinem Rechner installiert. Falls nicht, wird automatisch eine Standartschrift wie z.b Times, Arial oder Helvetica angezeigt.";
$MsgWinName				= "Name";
$MsgWinSample			= "Beispiel";
$MsgWinSampleString		= "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard		= "Versende eine weitere Gru&szlig;karte";

// Advanced Send
$MsgNPostSent			= "Postkarten versendet.";

// Admin Page
$MsgAdminPage			= "Control Panel";
$MsgAdminCardControlTitle	= "Postkartenverwaltung";
$MsgAdminCardControlNote	= "L&ouml;sche alle Postkarten die XX Tage alt sind.";
$MsgAdminDay			= "Tage";
$MsgAdminDelOption1		= "Nur Postkarten, die abgeholt wurden.";
$MsgAdminDelOption2		= "Nur Postkarten, die NICHT abgeholt wurden.";
$MsgAdminDeleteButton	= "L&ouml;sche Postkarten";
$MsgAdminDeletedCards	= "Karten wurden von der Datenbank gel&ouml;scht.";

$MsgAdminWarning		= "Warnung!";
$MsgAdminWarning2		= "Diese Einstellung l&ouml;scht alle Postkarten der Datenbank die";
$MsgAdminWarningReaded	= "gelesen wurden";
$MsgAdminWarningNotReaded	= "nicht gelesen wurden";
$MsgAdminWarning3		= "und sind";
$MsgAdminWarning4		= "Tage alt.";
$MsgAdminWarning5		= "Karten werden laut Deinen Kriterien gel&ouml;scht. Bist Du sicher?";
$MsgAdminWarningButtonYes	= "Ja, bin mir sicher!";
$MsgAdminWarningButtonNo	= "Nein, bitte nicht!";
$MsgAdminWarningNoCardDelete	= "Laut Deinen Kriterien werden keine Karten gel&ouml;scht. Gehe zur&uuml;ck und verwende gegebenfalls andere L&ouml;schkriterien.";

$MsgAdminPatternControlTitle	= "Hintergrundbilder einstellen";
$MsgAdminMusicControlTitle	= "Musikeinstellungen";
$MsgAdminStampControlTitle	= "Briefmarkeneinstellungen";
$MsgAdminIncluded		= "Eintrag hinzugef&uuml;gt";
$MsgAdminNoIncluded		= "Eintrag nicht hinzugef&uuml;gt";
$MsgAdminDeleted		= "Eintrag gel&ouml;scht";
$MsgAdminNoDeleted		= "Eintrag nicht gel&ouml;scht";
$MsgAdminFormFieldEmpty	= "Formularfeld ist leer. Gehe zur&uuml;ck und versuche es noch einmal!";

$MsgAdminModified		= "Eintrag bearbeitet";
$MsgAdminNoModified		= "Eintrag nicht bearbeitet";

$MsgAdminInclude		= "Hinzf&uuml;gen";
$MsgAdminDelete			= "L&ouml;schen";
$MsgAdminEdit			= "Bearbeiten";
$MsgAdminModify			= "&Auml;ndern";

$MsgAdminControlMusicFile	= "Musikdatei";
$MsgAdminControlMusicName	= "Musikname";
$MsgAdminControlMusicAuthor	= "Musikauthor";
$MsgAdminControlMusicGenre	= "Musikgenre";

$MsgAdminControlPatternFile	= "Hintergrunddatei";
$MsgAdminControlPatternName	= "Hintergrundname";
$MsgAdminControlStampFile	= "Briefmarkendatei";
$MsgAdminControlStampName	= "Briefmarkenname";

$MsgAdminControlPostImgFile	= "Datei hochladen";
$MsgAdminControlPostThmFile	= "Vorschaubild hochladen";
$MsgAdminControlPostTemplate = "Templatename";

$MsgAdminPostcardControlTitle	= "Postkareneinstellungen";
$MsgAdminCategoryControlTitle	= "Kategorieeinstellungen";

$MsgAdminExtraInfoTitle		= "Extra Info";

$MsgAdminNote			= "Hinweis";
$MsgAdminNoteMust		= "Die Datei muss hochgeladen werden nach";

// Extra Info:
$MsgvCardLiteCommunity	= "vCard Lite Community";
$MsgYourVersion			= "Deine Version";
$MsgAvaibaleVersion		= "Verf&uuml;gbare Version";

// Statistic Page
$MsgAdminCardStatTitle		= "Statistik";
$MsgAdminControlImageFile 	= "Bilddatei";
$MsgAdminTemplateFile 		= "Templatedatei";
$MsgSeeYourStat				= "Servicestatistiken";
$MsgPosition 				= "Position";
$MsgHits					= "Zugriffe";
$MsgTop 					= "Top ";

$MsgAdminStatsRestart		= "Neustart der Statistiken";
$MsgAdminStatsDbEmpty		= "Die Statistikdatenbank ist leer.";
$MsgAdminStatsDbNoEmpty		= "Die Statistikdatenbank ist nicht leer.";
$MsgAdminStatsNote			= "Nach einem Statistikneustart, werden alle alten Statistikdaten gel&ouml;scht! Am besten vorher auf der Festplatte speichern.";

// Gallery Browser Pages
$MsgNext			= "Weiter";
$MsgPrevious		= "Zur&uuml;ck";
$MsgBackCatMain		= "Zur Hauptansicht";

$MsgNoCardsinDB		= "Schade, es sind keine Gru&szlig;karten in der Datenbank.";
$MsgInvalidePageNumber	= "Das ist leider eine ung&uuml;ltige Seitennummer.";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId	= "ID";
$MsgAdminControlCatName	= "Kategoriename";
$MsgAdminGalleryControlTitle = "Galleryeinstellungen";

$MsgAdminLinkBrowser	= "anschauen";
$MsgAdminLinkEdit		= "bearbeiten";
$MsgAdminLinkDelete		= "l&ouml;schen";

// MENU
$MsgMusic			= "Musik";
$MsgPattern			= "Hintergrundbilder";
$MsgMain			= "Hauptansicht";
$MsgGallery			= "Gallerie";
$MsgStamp			= "Briefmarken";
$MsgStats			= "Statistiken";
$MsgAdminBrowser	= "Anschauen";
$MsgPHPInfo			= "PHP Info";

$MsgCategories		= "Kategorien";
$MsgCategory		= "Kategorie";
$MsgPostcards		= "Postkarten";

// Back Link Messages
$MsgBack			= "Zur&uuml;ck";
$MsgBackButton		= "Zur&uuml;ck zur letzten Seite";
$MsgBacktoSection	= "Zur&uuml;ck zur letzten Seite";

// File Upload
$MsgUploadYourOwnFileTitle	= "Versende Dein eigenes Bild.";
$MsgUploadYourOwnFileInfo	= "Erstelle eine Postkarte mit Deinem eigenen Bild";
$MsgErrorFileExtension		= "Dateiendung nicht erlaubt. Es muss .gif, ...jpeg, .jpg oder .swf benutzt werden!";
$MsgFileBiggerThan		= "Datei gr&ouml;&szlig;er als"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed	= "Die maximal erlaubte Dateigr&ouml;&szlig;e ist "; // Fhe max size of file is XX Kbytes
$MsgFileAllowed		= "Du kannst Dein eigenes Bild(.gif, .jpg) oder Deine eigene Flash Animation(.swf) als Postkarte verschicken. W&auml;hle Deine Datei aus und klicke auf den Button.";
$MsgFileUploadNotAllowed = "Das Hochladen von Dateien ist auf dieser Seite deaktiviert!";
$MsgFileSend			= "Datei senden!";
$MsgFileSelect			= "Datei ausw&auml;hlen";
$MsgFileUseFile			= "Postkarte erstellen";

// added v2.4

$MsgSLog = 'Service Logs';
$MsgAdminEntries = 'Eintr&auml;ge';
$MsgAdminLogRestart = 'Neustart der Service Logs';
$MsgAdminLogNote = 'Ein Neustart l&ouml;scht alle alten Service Log Daten.';
$MsgAdminLogRname = 'Empf&auml;nger';
$MsgAdminLogRemail = 'Empf&auml;ngeremail';
$MsgAdminLogSname = 'Versender';
$MsgAdminLogSemail = 'Versenderemail';
$MsgAdminLogSip = 'IP des Versender';
$MsgAdminLogDate = 'Datum';
$MsgAdminLogSentDate = 'Zustelldatum';
$MsgAdminLogEcard = 'Ecard';


?>
