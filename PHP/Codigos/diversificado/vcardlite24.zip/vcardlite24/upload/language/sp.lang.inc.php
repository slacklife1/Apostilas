<?php
/*************************************************************************
      language      : spanish
      file          : sp.lang.inc.php
      begin         : 2003-01-31
      last updated  : 2003-01-31
      translator    : Marco S�nchez (warezcult@lycos.es)
      home          : http://router.dns-core.com/~drclone
      charset       : ISO-8859-1
*************************************************************************/
$charset			='iso-8859-1';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect		= "Imposible conectar con el servidor de la base de datos en este momento!";
$MsgUnableLocateDB		= "Imposible localizar la base de datos en este momento!";
$MsgErrorPerformingQuery	= "Error al realizar b�squeda en la base de datos";

// Create, Preview and View Page
$MsgImage			= "Imagen";
$MsgYourTitle			= "Su T�tulo";
$MsgMessage			= "Mensaje";
$MsgFont			= "Tipo de fuente";
$MsgNoFontFace			= "Sin tipo de fuente";
$MsgFontSizeSmall		= "Tama�o Peque�o";
$MsgFontSizeMedium		= "Tama�o Medio";
$MsgFontSizeLarge		= "Tama�o Grande";
$MsgFontSizeXLarge		= "Tama�o Extra Grande";
$MsgFontColorBlack		= "Negro";
$MsgFontColorWhite		= "Blanco";
$MsgSignature			= "Firma";
$MsgRecpName			= "Nombre del Destinatario";
$MsgRecpEmail			= "E-mail del destinatario";
$MsgAddRecp			= "Destinatarios";
$MsgPlay			= "Reproducir";
$MsgYourName			= "Su Nombre";
$MsgYourEmail			= "Su E-mail";
$MsgChooseLayout		= "Elija un dise�o de Postal";
$MsgChooseDate			= "Fecha de envio de la Postal";
$MsgDateFormat			= "Elija el d�a actual, para enviar su postal ahora. (El formato de fecha es DD/MM/AAAA)";
$MsgChooseStamp			= "Elija el Sello";
$MsgPostColor			= "Color de fondo de la Postal";
$MsgPageBackground		= "Papel Tapiz";
$MsgNone			= "Ninguno";
$MsgMusic			= "Musica";
$MsgPreviewButton		= "Previsualizar Postal";
$MsgNotify			= "Notificarme por E-mail cuando el destinatario lea la Postal";
$MsgYes				= "Si";
$MsgNo				= "No";
$MsgNoFlash			= "Necesita el plug-in de Macromedia Flash para ver Postales en Flash";
$MsgClickHereToGet		= "Pulse aqu� para descargarlo!";
$MsgHelp			= "Ayuda!";
$MsgCloseWindow			= "Cerrar Ventana";
$MsgPrintable                   = "Versi�n para Impresora";

// Error Messages
$MsgActiveJS			= "Por favor habilite javascript en su navegador!";
$MsgErrorMessage		= "Necesita escribir un mensaje para su Postal.";
$MsgErrorRecpName		= "Necesita escribir el nombre del destinatario.";
$MsgErrorRecpEmail		= "Necesita escribir el E-mail del destinatario.";
$MsgErrorRecpEmail2		= "La <B>direcci�n de E-mail</B> del destinatario no es v�lida.";
$MsgErrorSenderName		= "Necesita escribir su nombre.";
$MsgErrorSenderEmail		= "Necesita escribir su direcci�n de E-mail.";
$MsgErrorSenderEmail2		= "Su <B>direcci�n de E-mail</B> no es v�lida.";
$MsgErrorNotFoundTxt		= "Disculpe, no se encuentra una postal con estos datos. Puede haber escrito mal la identidad de la Postal, o la Postal a caducado y no est� en nuestra base de datos.";

$MsgBackEditButton		= "Volver para Editar";
$MsgSendButton			= "Enviar la Postal!";

$MsgSendTo			= "Enviar una Postal a";
$MsgClickHere			= "Pulse Aqu�";
$MsgAvoidDuplicat		= "Pulse solo una vez para evitar duplicados!";

// Info Windows
$MsgWinEmoticons		= "Caritas/Emoticons";
$MsgWinEmoticonsNote		= "Todas las letras en may�sculas (O y P)!";
$MsgWinEmoticonsNoteFotter	= "<B>Si</B> no desea Caritas/Emoticons, abandone ahora.";
$MsgWinBackground		= "Imagen del papel tapiz";
$MsgWinStamp			= "Imagen del sello";
$MsgWinColors			= "Colores";
$MsgWinMusic			= "Musica";
$MsgWinMusicNote		= "Elija una opci�n.";
$MsgWinNotify			= "Quiere recibir por E-mail una notificaci�n cuando la Postal sea vista por el destinatario?";
$MsgWinFonts			= "Fuentes";
$MsgWinFontsNote		= "Si desea utilizar esta opci�n, <FONT COLOR=red>sea consciente</FONT> de que no todo el mundo tiene estas fuentes instaladas en su computadora. De no ser as�, el destinatario ver� las fuentes por defecto, por lo general Times y Arial o Helvetica.";
$MsgWinName			= "Nombre";
$MsgWinSample			= "Ejemplo";
$MsgWinSampleString		= "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard		= "Enviar otra Postal Virtual";

// Advanced Send
$MsgNPostSent			= "postal enviada en este momento.";

// Admin Page
$MsgAdminPage			= "Panel de Control";
$MsgAdminCardControlTitle	= "Control de la Postal";
$MsgAdminCardControlNote	= "Esta opci�n borrar� las Postales con XX d�as de antiguedad.";
$MsgAdminDay			= "D�as";
$MsgAdminDelOption1		= "Solo Postales que han sido leidas";
$MsgAdminDelOption2		= "Solo Postales que no han sido leidas";
$MsgAdminDeleteButton		= "Borrar Postales";
$MsgAdminDeletedCards		= "las Postales ser�n borradas de la base de datos.";

$MsgAdminWarning		= "Advertencia!";
$MsgAdminWarning2		= "Esta opci�n borrar� todas las Postales en su base de datos que";
$MsgAdminWarningReaded		= "han sido leidas";
$MsgAdminWarningNotReaded	= "no han sido leidas";
$MsgAdminWarning3		= "o que tengan";
$MsgAdminWarning4		= "d�as de antiguedad.";
$MsgAdminWarning5		= "las Postales ser�n borradas de acuerdo a su criterio de selecci�n. Est� seguro de querer continuar?";
$MsgAdminWarningButtonYes	= "S�, estoy seguro!";
$MsgAdminWarningButtonNo	= "No, estoy seguro!";
$MsgAdminWarningNoCardDelete	= "Las Postales no se pueden borrar con este criterio de selecci�n. Regrese y cambie su criterio de selecci�n.";

$MsgAdminPatternControlTitle	= "Control del papel tapiz";
$MsgAdminMusicControlTitle	= "Control de la m�sica";
$MsgAdminStampControlTitle	= "Control del sello";
$MsgAdminIncluded		= "registro INCLUIDO";
$MsgAdminNoIncluded		= "registro NO INCUIDO";
$MsgAdminDeleted		= "registro BORRADO";
$MsgAdminNoDeleted		= "registro NO BORRADO";
$MsgAdminFormFieldEmpty		= "campo del formulario vacio. Regrese e int�ntelo de nuevo!";

$MsgAdminModified		= "registro MODIFICADO";
$MsgAdminNoModified		= "registro NO MODIFICADO";

$MsgAdminInclude		= "A�adir"; 
$MsgAdminDelete			= "Borrar"; 
$MsgAdminEdit			= "Editar";
$MsgAdminModify			= "Modificar";

$MsgAdminControlMusicFile	= "Archivo de M�sica";
$MsgAdminControlMusicName	= "Nombre del Archivo";
$MsgAdminControlMusicAuthor	= "Autor";
$MsgAdminControlMusicGenre	= "G�nero";

$MsgAdminControlPatternFile	= "Archivo de Papel Tapiz";
$MsgAdminControlPatternName	= "Nombre del Papel Tapiz";
$MsgAdminControlStampFile	= "Archivo de Sello";
$MsgAdminControlStampName	= "Nombre del Sello";

$MsgAdminControlPostImgFile	= "Archivo de Postal";
$MsgAdminControlPostThmFile	= "Archivo de la Muestra";
$MsgAdminControlPostTemplate	= "Nombre de Plantilla";

$MsgAdminPostcardControlTitle	= "Control de la Postal";
$MsgAdminCategoryControlTitle	= "Control de la Categor�a";

$MsgAdminExtraInfoTitle		= "Informaci�n Extra";

$MsgAdminNote			= "Nota";
$MsgAdminNoteMust		= "El archivo debe ser subido a";

// Extra Info:
$MsgvCardLiteCommunity		= "Foros vCard Lite";
$MsgYourVersion			= "Su versi�n";
$MsgAvaibaleVersion		= "Versi�n Disponible";

// Statistic Page
$MsgAdminCardStatTitle		= "Estad�sticas";
$MsgAdminControlImageFile 	= "Archivo de Imagen";
$MsgAdminTemplateFile 		= "Archivo de Plantilla";
$MsgSeeYourStat			= "Para ver sus estad�sticas del servicio de Postales";
$MsgPosition 			= "Posici�n";
$MsgHits			= "Visitas";
$MsgTop 			= "Top ";

$MsgAdminStatsRestart		= "Restaurar Estad�sticas";
$MsgAdminStatsDbEmpty		= "Base de datos de estad�sticas VACIA";
$MsgAdminStatsDbNoEmpty		= "Base de datos de estad�sticas NO VACIA";
$MsgAdminStatsNote		= "si quiere restaurar las estad�sticas puede hacerlo pulsando este bot�n. Tenga en cuenta que todas las estad�sticas se borrar�n. Si desea guardarlas como un historial, salve los reportes a su disco duro primero.";

// Gallery Browser Pages
$MsgNext			= "Siguiente";
$MsgPrevious			= "Anterior";
$MsgBackCatMain			= "Volver a la p�gina de Categor�as";

$MsgNoCardsinDB			= "Perdone, no se encuentran Postales en la base de datos.";
$MsgInvalidePageNumber		= "Ha especificado un n�mero de p�gina no v�lido";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Nombre de Categoria";
$MsgAdminGalleryControlTitle	= "Control de la Galeria";

$MsgAdminLinkBrowser		= "explorar";
$MsgAdminLinkEdit		= "editar";
$MsgAdminLinkDelete		= "borrar";

// MENU
$MsgMusic			= "Musica";
$MsgPattern			= "Papel Tapiz";
$MsgMain			= "Principal";
$MsgGallery			= "Galer�a";
$MsgStamp			= "Sello";
$MsgStats			= "Estad�sticas";
$MsgAdminBrowser		= "explorar";
$MsgPHPInfo			= "informaci�n PHP";

$MsgCategories			= "Categor�as";
$MsgCategory			= "Categor�a";
$MsgPostcards			= "Postales";

// Back Link Messages
$MsgBack			= "Volver";
$MsgBackButton			= "Volver a la p�gina anterior";
$MsgBacktoSection		= "Volver a la secci�n anterior";

// File Upload
$MsgUploadYourOwnFileTitle	= "Usar su propia Imagen";
$MsgUploadYourOwnFileInfo	= "Crear una Postal utilizando sus imagenes";
$MsgErrorFileExtension		= "La extension no est� permitida. Debe ser ..gif, .jpeg, .jpg o .swf y en min�sculas!";
$MsgFileBiggerThan		= "El archivo tiene mas de"; // Si el archivo es superior a XX Kbytes
$MsgFileMaxSizeAllowed		= "El tama�o m�ximo permitido de subida es "; // El tama�o m�ximo de este archivo es XX Kbytes
$MsgFileAllowed			= "Puede subir su propia imagen (.gif, .jpg) o animaci�n en flash (.swf) para crear una Postal personalizada. Pulse sobre Examinar y seleccione el archivo, luego pulse sobre Enviar archivo.";
$MsgFileUploadNotAllowed	= "El env�o de archivos est� desabilitado en este sitio!";
$MsgFileSend			= "Enviar archivo";
$MsgFileSelect			= "Seleccione el archivo";
$MsgFileUseFile			= "Crear Postal";

// added v2.4

$MsgSLog = 'Diario de Servicio';
$MsgAdminEntries = 'registros';
$MsgAdminLogRestart = 'Restaurar diario de servicio';
$MsgAdminLogNote = 'si quiere restaurar el diario de servicio puede hacerlo pulsando este bot�n. Tenga en cuenta que toda la informaci�n se borrar�. Si desea guardarlo como un historial, salve los reportes a su disco duro primero.';
$MsgAdminLogRname = 'Destinatario';
$MsgAdminLogRemail = 'E-mail dest.';
$MsgAdminLogSname = 'Remitente';
$MsgAdminLogSemail = 'E-mail Rem.';
$MsgAdminLogSip = 'IP del Rem.';
$MsgAdminLogDate = 'Fecha';
$MsgAdminLogSentDate = 'Fecha de env�o';
$MsgAdminLogEcard = 'Postal';


?>
