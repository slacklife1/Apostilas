<?php
/*************************************************************************
      file          : fr.lang.inc.php
      begin         : 2001-03-15
      translator    : ????
      home          : ????
      languag       : french
*************************************************************************/
$charset			='ISO-8859-1';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect		= "Unable to connect to the database server at this time!";
$MsgUnableLocateDB		= "Unable to locate the database at this time!";
$MsgErrorPerformingQuery	= "Error performing query";

// Create, Preview and View Page
$MsgImage			= "Image";
$MsgYourTitle			= "Votre titre";
$MsgMessage			= "Message";
$MsgFont			= "Police";
$MsgNoFontFace			= "Pas de police";
$MsgFontSizeSmall		= "Petite";
$MsgFontSizeMedium		= "Moyenne";
$MsgFontSizeLarge		= "Grande";
$MsgFontSizeXLarge		= "Tr�s grande";
$MsgFontColorBlack		= "Noire";
$MsgFontColorWhite		= "Blanche";
$MsgSignature			= "Signature";
$MsgRecpName			= "Nom du destinataire";
$MsgRecpEmail			= "Email du destinataire";
$MsgAddRecp			= "Ajouter des destinataires";
$MsgPlay			= "Lecture";
$MsgYourName			= "Votre nom";
$MsgYourEmail			= "Votre email";
$MsgChooseLayout		= "Choisissez un format de carte";
$MsgChooseDate			= "Date d'envoi?";
$MsgDateFormat			= "Choisissez aujourd'hui, le format de date est JJ/MM/YYYY, pour envoyer votre e-carte maintenant.";
$MsgChooseStamp			= "Choisissez un timbre";
$MsgPostColor			= "Couleur de fond";
$MsgPageBackground		= "Fond d'�cran";
$MsgNone			= "Rien";
$MsgMusic			= "Musique";
$MsgPreviewButton		= "Pr�-visualisation";
$MsgNotify			= "Envoyez-moi un email quand le destinataire a lu sa carte.";
$MsgYes				= "Oui";
$MsgNo				= "Non";
$MsgNoFlash			= "Vous devez installer le plug-in Flash pour voir la version flash de cette carte. ";
$MsgClickHereToGet		= "Cliquez ici pour l'obtenir!";
$MsgHelp			= "A l'aide!";
$MsgCloseWindow			= "Fermer la fen�tre";
$MsgPrintable                   = "Version imprimable";

// Error Messages
$MsgActiveJS			= "SVP activez le javascript !";
$MsgErrorMessage		= "Vous devez �crire un message pour envoyer votre e-carte.";
$MsgErrorRecpName		= "Vous devez entrer le nom du destinataire.";
$MsgErrorRecpEmail		= "Vous devez entrer les adresses email des destinataires.";
$MsgErrorRecpEmail2		= "<B>L'adresse email</B> du destinataire est invalide.";
$MsgErrorSenderName		= "Vous devez entrer votre nom.";
$MsgErrorSenderEmail		= "Vous devez entrer votre adresse.";
$MsgErrorSenderEmail2		= "Votre <B>adresse email</B> est invalide.";
$MsgErrorNotFoundTxt		= "D�sol�, aucune carte ne correspond. Vous avez mal saisi l'identifiant, ou votre carte est trop ancienne et a d�j� �t� effac�e du serveur.";

$MsgBackEditButton		= "Retour � l'�diteur";
$MsgSendButton			= "Envoyer la carte!";

$MsgSendTo			= "Envoyer une carte virtuelle �";
$MsgClickHere			= "Cliquez ici";
$MsgAvoidDuplicat		= "Cliquez ici une seule fois sur le bouton [envoyer] pour �viter les doublons!";

// Info Windows
$MsgWinEmoticons		= "Smileys";
$MsgWinEmoticonsNote		= "Tous les caract�res passent en capitale (O and P)!";
$MsgWinEmoticonsNoteFotter	= "<B>SI</B> vous ne voulez pas faire appara�tre les graphiques, mais que vous voulez utiliser les smileys originaux  il vous faudra exclure le nez.";
$MsgWinBackground		= "Image de fond d'�cran";
$MsgWinStamp			= "Image du timbre";
$MsgWinColors			= "Couleurs";
$MsgWinMusic			= "Musqiue";
$MsgWinMusicNote		= "Choisissez une option.";
$MsgWinNotify			= "Souhaites-vous recevoir une notification par email lorsque votre destinataire aura vu sa carte?";
$MsgWinFonts			= "Polices";
$MsgWinFontsNote		= "Pour utiliser cette option, <FONT COLOR=red>v�rifiez/FONT> que vos destinataires auront exactement cette police install�e sur leu ordinateur. Sinon les polices par d�faut, Times, Arial ou Helvetica, seront utilis�es.";
$MsgWinName			= "Nom";
$MsgWinSample			= "Exemple";
$MsgWinSampleString		= "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard		= "Envoyer une autre carte virtuelle";

// Advanced Send
$MsgNPostSent			= "E-carte envoy�e !.";

// Admin Page
$MsgAdminPage			= "Tableau de bord";
$MsgAdminCardControlTitle	= "R�glages pour votre e-carte";
$MsgAdminCardControlNote	= "Les e-cartes sont effac�es au bout de 10 jours.";
$MsgAdminDay			= "Jours";
$MsgAdminDelOption1		= "Seulement les e-cartes s�lectionn�es";
$MsgAdminDelOption2		= "Seulement les e-cartes NON s�lectionn�es";
$MsgAdminDeleteButton		= "Effacer les e-cartes";
$MsgAdminDeletedCards		= "Les e-cartes ont �t� supprim�es de la base de donn�es.";

$MsgAdminWarning		= "Attention !";
$MsgAdminWarning2		= "Cette option va effacer toutes les e-cartes de votre base de donn�es qui ";
$MsgAdminWarningReaded		= "ont �t� lues";
$MsgAdminWarningNotReaded	= "n'ont pas �t� lues";
$MsgAdminWarning3		= "et qui";
$MsgAdminWarning4		= "jours d'�ge.";
$MsgAdminWarning5		= "e-cartes seront d�truites selon les crit�res sp�cifi�s. Voulez-vous continuer?";
$MsgAdminWarningButtonYes	= "Oui, je veux !";
$MsgAdminWarningButtonNo	= "Non, piti�!";
$MsgAdminWarningNoCardDelete	= "Aucune e-carte ne sera d�truite en fonction de ces crit�res. Revenez en arri�re et s�lectionnez de nouveaux crit�res.";

$MsgAdminPatternControlTitle	= "Choix de la texture";
$MsgAdminMusicControlTitle	= "Choix de la musique";
$MsgAdminStampControlTitle	= "Choix du timbre";
$MsgAdminIncluded		= "entr�e INCLUSE";
$MsgAdminNoIncluded		= "entr�e NON INCLUSE";
$MsgAdminDeleted		= "entr�e EFFACEE";
$MsgAdminNoDeleted		= "entr�e NON EFFACEE";
$MsgAdminFormFieldEmpty		= "champ de formulaire vide. Revenez en arri�re et essayez de nouveau!";

$MsgAdminModified		= "entr�e MODIFIEE";
$MsgAdminNoModified		= "entr�e NON MODIFIEE";

$MsgAdminInclude		= "Ajouter"; 
$MsgAdminDelete			= "Effacer"; 
$MsgAdminEdit			= "Editer";
$MsgAdminModify			= "Modifier";

$MsgAdminControlMusicFile	= "Fichier musique";
$MsgAdminControlMusicName	= "Nom de la musique";
$MsgAdminControlMusicAuthor	= "Auteur de la musique";
$MsgAdminControlMusicGenre	= "Genre de la musique";

$MsgAdminControlPatternFile	= "Fichier texture";
$MsgAdminControlPatternName	= "Nom de la texture";
$MsgAdminControlStampFile	= "Fichier Timbre";
$MsgAdminControlStampName	= "Nom du timbre";

$MsgAdminControlPostImgFile	= "Poster le fichier";
$MsgAdminControlPostThmFile	= "Poster la pr�visualisation";
$MsgAdminControlPostTemplate	= "Nom de la Template";

$MsgAdminPostcardControlTitle	= "Controle des e-cartes";
$MsgAdminCategoryControlTitle	= "Controle des cat�gories";

$MsgAdminExtraInfoTitle		= "Extra-Info";

$MsgAdminNote			= "Note";
$MsgAdminNoteMust		= "Le fichier doit �tre t�l�charg� vers";

// Extra Info:
$MsgvCardLiteCommunity		= "vCard Lite Community"; // vCard Lite Community
$MsgYourVersion			= "Your version"; //Your version 
$MsgAvaibaleVersion		= "Avaiable version"; // Avaiable version

// Statistic Page
$MsgAdminCardStatTitle		= "Statistiques";
$MsgAdminControlImageFile 	= "Fichier image";
$MsgAdminTemplateFile 		= "Fichier Template";
$MsgSeeYourStat			= "Pour acc�der � vos statistiques";
$MsgPosition 			= "Position";
$MsgHits			= "Hits";
$MsgTop 			= "Top ";

$MsgAdminStatsRestart		= "Red�marrer les statistiques";
$MsgAdminStatsDbEmpty		= "La base de donn�es des statistiques est vide";
$MsgAdminStatsDbNoEmpty		= "La base de donn�es des statistiques n'est pas vide";
$MsgAdminStatsNote		= "If you like to restart the Statistics you're free to do so by pushing this button. Consider however that all your current statistics information is deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.";

// Gallery Browser Pages
$MsgNext			= "Suivante";
$MsgPrevious			= "Pr�c�dente";
$MsgBackCatMain			= "Retour";

$MsgNoCardsinDB			= "D�sol�, il n'y a pas encore de cartes dans la base de donn�es.";
$MsgInvalidePageNumber		= "Vous avez sp�cifi� un num�ro de page invalide.";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Cat�gorie";
$MsgAdminGalleryControlTitle	= "Gallerie";

$MsgAdminLinkBrowser		= "naviguer";
$MsgAdminLinkEdit		= "editer";
$MsgAdminLinkDelete		= "effacer";

// MENU
$MsgMusic			= "Musique";
$MsgPattern			= "Texture";
$MsgMain			= "Principal";
$MsgGallery			= "Gallerie";
$MsgStamp			= "Timbre";
$MsgStats			= "Stats";
$MsgAdminBrowser		= "Navigateur";
$MsgPHPInfo			= "PHP Info";

$MsgCategories			= "Cat�gories";
$MsgCategory			= "Categorie";
$MsgPostcards			= "E-cartes";

// Back Link Messages
$MsgBack			= "Retour";
$MsgBackButton			= "Retour � la page pr�c�dente";
$MsgBacktoSection		= "Retour � la section pr�c�dente";

// File Upload
$MsgUploadYourOwnFileTitle	= "Utilisez votre propre image";
$MsgUploadYourOwnFileInfo	= "Cr�er une e-carte en utilisant votre propre graphisme";
$MsgErrorFileExtension		= "Extension interdite. Seules sont accept�es .gif, .jpeg, .jpg ou .swf et en minuscules!";
$MsgFileBiggerThan		= "La taille du fichier d�passe les"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed		= "La taille maximum utoris�e est "; // Fhe max size of file is XX Kbytes
$MsgFileAllowed			= "Vous pouvez t�l�charger votre propre image(.gif, .jpg) ou animation flash(.swf) pour cr�er une e-carte personnalis�e. S�lectionnez votre fichier et cliquez sur le bouton.";
$MsgFileUploadNotAllowed	= "Le t�l�chargement de fichier n'est pas autoris�.";
$MsgFileSend			= "Envoyer l'image!";
$MsgFileSelect			= "S�lectionnez votre fichier";
$MsgFileUseFile			= "Cr�er votre E-Carte";

// added v2.4

$MsgSLog = 'Service Log';
$MsgAdminEntries = 'registries';
$MsgAdminLogRestart = 'Restart Service Log';
$MsgAdminLogNote = 'If you like to restart/clean the service log, you�re free to do so by pushing this button. Consider however that all your current informations are deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.';
$MsgAdminLogRname = 'Recip Name';
$MsgAdminLogRemail = 'Recip Email';
$MsgAdminLogSname = 'Sender Name';
$MsgAdminLogSemail = 'Sender Email';
$MsgAdminLogSip = 'Sender IP';
$MsgAdminLogDate = 'Date';
$MsgAdminLogSentDate = 'Sent/To Send date';
$MsgAdminLogEcard = 'Ecard';


?>