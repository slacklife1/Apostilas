<?
/*************************************************************************
      language      : german
      file          : ger.lang.inc.php
      last upadte   : 2001-03-04
      translator    : Peter Hoefer / Forrest
      email         : forrest@hosting.as
      home          : http://www.hosting.as/ww
*************************************************************************/
$charset			='iso-8859-1';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect		= "Unable to connect to the database server at this time!";
$MsgUnableLocateDB		= "Unable to locate the database at this time!";
$MsgErrorPerformingQuery	= "Error performing query";

// Create, Preview and View Page
$MsgImage			= "Bild";
$MsgYourTitle			= "�berschrift";
$MsgMessage			= "Nachricht";
$MsgFont			= "Schriftfarbe";
$MsgNoFontFace			= "Standard";
$MsgFontSizeSmall		= "Klein";
$MsgFontSizeMedium		= "Mittel";
$MsgFontSizeLarge		= "Gross";
$MsgFontSizeXLarge		= "Extra Gross";
$MsgFontColorBlack		= "Schwarz";
$MsgFontColorWhite		= "Weiss";
$MsgSignature			= "Unterschrift";
$MsgRecpName			= "Empf�nger - Name";
$MsgRecpEmail			= "Empf�nger - E-Mail";
$MsgAddRecp			= "Empf�nger hinzuf�gen";
$MsgPlay			= "PLAY";
$MsgYourName			= "Dein Name";
$MsgYourEmail			= "Deine E-Mail";
$MsgChooseLayout		= "W�hle ein Layout";
$MsgChooseDate			= "Versand-Datum";
$MsgDateFormat			= "W�hle das aktuelle Datum um die Karte sofort zu senden.";
$MsgChooseStamp			= "Briefmarke ausw�hlen";
$MsgPostColor			= "Hintergrundfarbe";
$MsgPageBackground		= "Hintergrundbild";
$MsgNone			= "Keine";
$MsgMusic			= "Musik";
$MsgPreviewButton		= "Vorschau";
$MsgNotify			= "M�chtest du eine Benachrichtigung wenn die Karte gelesen wird?";
$MsgYes				= "Ja";
$MsgNo				= "Nein";
$MsgNoFlash			= "Du ben�tigst das Flash-Player Plug-In um die Flash-Version der Postkarte zu sehen.";
$MsgClickHereToGet		= "Den Player gibt es hier!";
$MsgHelp			= "Hilfe!";
$MsgCloseWindow			= "Fenster schliessen";
$MsgPrintable                   = "Druckbare Version";

// Error Messages
$MsgActiveJS			= "Bitte Javascript aktivieren!";
$MsgErrorMessage		= "Du musst eine Nachricht in die Postkarte schreiben.";
$MsgErrorRecpName		= "Du musst den Empf�nger-Namen angeben.";
$MsgErrorRecpEmail		= "Du musst die E-Mail-Adresse des Emfp�ngers angeben.";
$MsgErrorRecpEmail2		= "Empf�nger <B>E-Mail-Adresse</B> ist fehlerhaft.";
$MsgErrorSenderName		= "Du musst deinen Namen eingeben.";
$MsgErrorSenderEmail		= "Du musst deine E-Mail-Adresse angeben.";
$MsgErrorSenderEmail2		= "Die von dir eingegebene <B>E-Mail-Adresse</B> ist fehlerhaft.";
$MsgErrorNotFoundTxt		= "Es ist keine Postkarte unter dieser Nummer gespeichert!<br>Bitte �berpr�f die von dir angegebene Postkarten-Nummer.<br>Sollte die Karte �lter als 14 Tage sein, so wurde Sie automatisch vom System gel�scht!";

$MsgBackEditButton		= "Zur�ck zum Editieren";
$MsgSendButton			= "Postkarte versenden!";

$MsgSendTo			= "Postkarte versenden an";
$MsgClickHere			= "Hier klicken";
$MsgAvoidDuplicat		= "Nur einmal klicken!";

// Info Windows
$MsgWinEmoticons		= "Emoticons";
$MsgWinEmoticonsNote		= "Alle Zeichen als Gro�buchstaben  (O and P)!";
$MsgWinEmoticonsNoteFotter	= "<B>Wenn</B> du KEINE Grafikdarstaltung m�chtest, ohne auf die Original-Emoticons zu verzichten, musst du die Nase weglassen. <B><FONT COLOR=red>-</FONT></B>  z.B. :<FONT COLOR=red>-</FONT>) --> :)";
$MsgWinBackground		= "Hintergrund";
$MsgWinStamp			= "Briefmarke";
$MsgWinColors			= "Farben";
$MsgWinMusic			= "Musik";
$MsgWinMusicNote		= "W�hle eine Option";
$MsgWinNotify			= "Du bekommst eine Best�tigung,<BR>sobald der Empf�nger die Karte<BR>gelesen hat!";
$MsgWinFonts			= "Schrift";
$MsgWinFontsNote		= "Wenn du diese Option nutzen m�chtest, <FONT COLOR=red>denke bitte daran</FONT>, da� nicht jeder die gleichen Zeichens�tze auf seinem Computer hat. F�r den Empf�nger sieht die Karte dann anders aus.";
$MsgWinName			= "Name";
$MsgWinSample			= "Beispiel";
$MsgWinSampleString		= "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard		= "Sende eine weitere Virtuelle Postkarte";

// Advanced Send
$MsgNPostSent			= "Postkarte wurde soeben versendet.";

// Admin Page
$MsgAdminPage			= "Control Panel";
$MsgAdminCardControlTitle	= "Postkarten Kontrolle";
$MsgAdminCardControlNote	= "Hiermit kannst du alle Karten l�schen, welche �lter als XX Tage sind.";
$MsgAdminDay			= "Tage";
$MsgAdminDelOption1		= "Nur Karten die bereits abgerufen wurden.";
$MsgAdminDelOption2		= "Nur Karten die noch nicht abgerufen wurden.";
$MsgAdminDeleteButton		= "Karten l�schen";
$MsgAdminDeletedCards		= "Die von dir ausgew�hlten Karten wurden gel�scht!.";

$MsgAdminWarning		= "Warnung!";
$MsgAdminWarning2		= "Diese Option l�sche alle Postkarten in deiner Datenbank welche";
$MsgAdminWarningReaded		= "gelesen wurden";
$MsgAdminWarningNotReaded	= "nicht gelesen wurden";
$MsgAdminWarning3		= "und";
$MsgAdminWarning4		= "Tage alt sind.";
$MsgAdminWarning5		= "Die Karten werden aufgrund deiner Auswahl gel�scht. M�chtest du die Karten l�schen?";
$MsgAdminWarningButtonYes	= "Ja, ich bin mir sicher!";
$MsgAdminWarningButtonNo	= "Nein, auf keinen Fall!";
$MsgAdminWarningNoCardDelete	= "Aufgrund deiner Auswahlkriterien wurden keine Karten gefunden. Geh zur�ck und w�hle andere Kriterien.";

$MsgAdminPatternControlTitle	= "Einstellungen : Hintergrund";
$MsgAdminMusicControlTitle	= "Einstellungen : Hintergrund-Musik";
$MsgAdminStampControlTitle	= "Einstellungen : Briefmarken";
$MsgAdminIncluded		= "Eintrag hinzugef�gt";
$MsgAdminNoIncluded		= "Eintrag nicht hinzugef�gt";
$MsgAdminDeleted		= "Eintrag gel�scht";
$MsgAdminNoDeleted		= "Eintrag nicht gel�scht";
$MsgAdminFormFieldEmpty		= "Eingabefeld ist leer, geh zur�ck und versuch es noch einmal!";

$MsgAdminModified		= "Eintrag ge�ndert";
$MsgAdminNoModified		= "Eitnrag nicht ge�ndert.";

$MsgAdminInclude		= "Hinzuf�gen"; 
$MsgAdminDelete			= "L�schen"; 
$MsgAdminEdit			= "Eiditieren";
$MsgAdminModify			= "�ndern";

$MsgAdminControlMusicFile	= "Musik Datei";
$MsgAdminControlMusicName	= "Musik Titel";
$MsgAdminControlMusicAuthor	= "Musik Autor";
$MsgAdminControlMusicGenre	= "Musik Genre";

$MsgAdminControlPatternFile	= "Hintergrund Datei";
$MsgAdminControlPatternName	= "Hintergrund Name";
$MsgAdminControlStampFile	= "Briefmarke Datei";
$MsgAdminControlStampName	= "Briefmarke Name";

$MsgAdminControlPostImgFile	= "Post File";
$MsgAdminControlPostThmFile	= "Post Thumb file";
$MsgAdminControlPostTemplate	= "Template Name";

$MsgAdminPostcardControlTitle	= "Postkarten Einstellungen";
$MsgAdminCategoryControlTitle	= "Einstellugen : Kategorien";

$MsgAdminExtraInfoTitle		= "Extra Info";

$MsgAdminNote			= "Hinweiss";
$MsgAdminNoteMust		= "Dieses File musst du in folgendes Verzeichniss kopieren:";

// Extra Info:
$MsgvCardLiteCommunity		= "vCard Lite Community";
$MsgYourVersion			= "Deine Version";
$MsgAvaibaleVersion		= "Verf�gbare Version";

// Statistic Page
$MsgAdminCardStatTitle		= "Statistik";
$MsgAdminControlImageFile 	= "Bild Datei";
$MsgAdminTemplateFile 		= "Template Datei";
$MsgSeeYourStat			= "Postkarten-Service Statistik anzeigen";
$MsgPosition 			= "Position";
$MsgHits			= "Zugriffe";
$MsgTop 			= "Top ";

$MsgAdminStatsRestart		= "Statistik neu Starten";
$MsgAdminStatsDbEmpty		= "Statistik Datenbank ist LEER!";
$MsgAdminStatsDbNoEmpty		= "Statistik Datenbank ist N�CHT LEER!";
$MsgAdminStatsNote		= "!!Wenn du die Statistik neu startest werden alle bisherigen Statistik-Daten unwiederruflich gel�scht!!.";

// Gallery Browser Pages
$MsgNext			= "N�chste";
$MsgPrevious			= "Zur�ck";
$MsgBackCatMain			= "Zur�ck zur Kategorie �bersicht";

$MsgNoCardsinDB			= "Es sind keine Karten in der Datenbank!";
$MsgInvalidePageNumber		= "Du hast eine falsche Seiten-Nummer angegeben";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Kategorie Name";
$MsgAdminGalleryControlTitle	= "Gallerie Einstellungen";

$MsgAdminLinkBrowser		= "browser";
$MsgAdminLinkEdit		= "Editieren";
$MsgAdminLinkDelete		= "L�schen";

// MENU
$MsgMusic			= "Musik";
$MsgPattern			= "Hintergrund";
$MsgMain			= "Main";
$MsgGallery			= "Gallery";
$MsgStamp			= "Briefmarke";
$MsgStats			= "Statistik";
$MsgAdminBrowser		= "Browser";
$MsgPHPInfo			= "PHP Info";

$MsgCategories			= "Kategorien";
$MsgCategory			= "Kategorie";
$MsgPostcards			= "Postkarten";

// Back Link Messages
$MsgBack			= "Zur�ck";
$MsgBackButton			= "Zur�ck zur vorherigen Seite";
$MsgBacktoSection		= "Back to previous section";

// File Upload
$MsgUploadYourOwnFileTitle	= "Benutze dein eigenes Bild";
$MsgUploadYourOwnFileInfo	= "Erstelle eine Postkarte mit deinem eigenen Bild";
$MsgErrorFileExtension		= "Datei-Typ nicht erlaubt. Es muss eine .gif, .jpeg, .jpg or .swf-Datei sein!";
$MsgFileBiggerThan		= "Datei ist gr��er als"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed		= "Die maximale erlaubte Datei-Gr�sse ist "; // Fhe max size of file is XX Kbytes
$MsgFileAllowed			= "Du kannst dein eigenes Bild (.gif, .jpg) oder eine Flash-Animation(.swf) hochladen um eine Postkarte zu erstellen. Select your file and click on the buttom.";
$MsgFileUploadNotAllowed	= "Datei Upload wurde deaktiviert..Sorry.";
$MsgFileSend			= "Sende Datei!";
$MsgFileSelect			= "Datei ausw�hlen";
$MsgFileUseFile			= "Erstelle Postkarte";
// added v2.4

$MsgSLog = 'Service Log';
$MsgAdminEntries = 'registries';
$MsgAdminLogRestart = 'Restart Service Log';
$MsgAdminLogNote = 'If you like to restart/clean the service log, you�re free to do so by pushing this button. Consider however that all your current informations are deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.';
$MsgAdminLogRname = 'Recip Name';
$MsgAdminLogRemail = 'Recip Email';
$MsgAdminLogSname = 'Sender Name';
$MsgAdminLogSemail = 'Sender Email';
$MsgAdminLogSip = 'Sender IP';
$MsgAdminLogDate = 'Date';
$MsgAdminLogSentDate = 'Sent/To Send date';
$MsgAdminLogEcard = 'Ecard';


?>