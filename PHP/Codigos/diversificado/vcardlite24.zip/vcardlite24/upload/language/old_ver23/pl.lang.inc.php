<?php
/*************************************************************************
      language      : polish
      file          : pl.lang.inc.php
      begin         : 2001-04-03
      translator    : Marek Pomietlo
                        debno@debno.net
                        http://pomietlo.republika.pl
                      Krzysztof Bielak
                        biekrz@freebsd.lublin.pl
                        http://www.biekrz.com
*************************************************************************/
$charset			='ISO-8859-2';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect		= "Niemo�liwe po��czenie z baz� danych w tym momencie!";
$MsgUnableLocateDB		= "Niemo�liwe zlokalizowanie bazy danych w tym momencie!";
$MsgErrorPerformingQuery	= "B��d zapytania / Error performing query";

// Create, Preview and View Page
$MsgImage			= "Obrazek";
$MsgYourTitle			= "Tw�j nag��wek"; 
$MsgMessage			= "Wiadomo��"; 
$MsgFont			= "Czcionka"; 
$MsgNoFontFace			= "Domy�lna";
$MsgFontSizeSmall		= "Ma�a"; 
$MsgFontSizeMedium		= "�rednia"; 
$MsgFontSizeLarge		= "Du�a"; 
$MsgFontSizeXLarge		= "Bardzo du�a"; 
$MsgFontColorBlack		= "Domy�lna";
$MsgFontColorWhite		= "Bia�y"; 
$MsgSignature			= "Podpis"; 
$MsgRecpName			= "Imi� odbiorcy"; 
$MsgRecpEmail			= "Adres e-mail odbiorcy"; 
$MsgAddRecp			= "Dodaj odbiorc�w"; 
$MsgPlay			= "S�UCHAJ"; 
$MsgYourName			= "Twoje imi�"; 
$MsgYourEmail			= "Tw�j adres e-mail"; 
$MsgChooseLayout		= "Wybierz wygl�d e-Kartki";
$MsgChooseDate			= "Kiedy wys�a� e-Kartk�?"; 
$MsgDateFormat			= "Wpisz dzisiejsz� dat� w formacie DD/MM/RRRR, aby wys�a� kartk� teraz."; 
$MsgChooseStamp			= "Wybierz znaczek"; 
$MsgPostColor			= "Kolor t�a e-Kartki"; 
$MsgPageBackground		= "Papeteria"; 
$MsgNone			= "Bez"; 
$MsgMusic			= "Muzyka"; 
$MsgPreviewButton		= "Obejrzyj kartk� przed wys�aniem"; 
$MsgNotify			= "Powiadom mnie o odebraniu kartki przez adresata"; 
$MsgYes				= "Tak"; 
$MsgNo				= "Nie"; 
$MsgNoFlash			= "Musisz mie� zainstalowany plugin Flash aby obejrze� wersj� Flash tej kartki!"; 
$MsgClickHereToGet		= "Kliknij tu aby pobra� plugin"; 
$MsgHelp			= "Pomoc!"; 
$MsgCloseWindow			= "Zamknij okno"; 
$MsgPrintable                   = "Wersja do druku"; 

// Error Messages
$MsgActiveJS			= "W��cz JavaScript!"; 
$MsgErrorMessage		= "Musisz wpisa� wiadomo�� do swojej kartki."; 
$MsgErrorRecpName		= "Musisz wpisa� imi� odbiorcy."; 
$MsgErrorRecpEmail		= "Musisz wpisa� adres e-mail odbiorcy."; 
$MsgErrorRecpEmail2		= "Podany przez Ciebie adres <B>e-mail</B> odbiorcy jest nieprawid�owy."; 
$MsgErrorSenderName		= "Musisz wpisa� swoje imi�."; 
$MsgErrorSenderEmail		= "Musisz wpisa� sw�j adres <B>e-mail</B>."; 
$MsgErrorSenderEmail2		= "Podany przez Ciebie adres <B>e-mail</B> jest nieprawid�owy."; 
$MsgErrorNotFoundTxt		= "Przepraszamy, link wskazuje na nieistniej�c� e-Kartk�. Prawdopodobnie up�yn�� jej okres wa�no�ci.";

$MsgBackEditButton		= "Powr�� do Edycji"; 
$MsgSendButton			= "Wy�lij e-Kartk�!"; 

$MsgSendTo			= "Wy�lij e-Kartk� do"; 
$MsgClickHere			= "Kliknij tutaj"; 
$MsgAvoidDuplicat		= "Kliknij tylko raz aby unikn�� powielenia!"; 

// Info Windows
$MsgWinEmoticons		= "Nastr�j"; 
$MsgWinEmoticonsNote		= "Wszystkie litery s� wielkie (O i P)!"; 
$MsgWinEmoticonsNoteFotter	= "Wpisywane przez Ciebie U�MIESZKI automatycznie zamieniaj� si� w obrazki. Wpisuj�c je bez NOSA <B>-</B> zachowasz ich oryginalny wygl�d.";
$MsgWinBackground		= "Obraz na papeteri�"; 
$MsgWinStamp			= "Znaczki"; 
$MsgWinColors			= "Kolory"; 
$MsgWinMusic			= "Muzyka"; 
$MsgWinMusicNote		= "Wybierz opcj�."; 
$MsgWinNotify			= "Czy chcesz otrzyma� potwierdzenie odbioru wys�anej przez Ciebie e-Kartki?"; 
$MsgWinFonts			= "Czcionki"; 
$MsgWinFontsNote		= "Je�eli chcesz u�y� tej opcji <FONT COLOR=red>musisz liczy� si� z tym</FONT>, �e nie ka�dy ma zainstalowane te rodzaje czcionek na swoim komputerze, wtedy zobaczy czcionk� domy�ln�, zwykle s� to : Times, Arial i Helvetica."; 
$MsgWinName			= "Nazwa"; 
$MsgWinSample			= "Przyk�ad"; 
$MsgWinSampleString		= "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard		= "Wy�lij nast�pn� e-Kartk�"; 

// Advanced Send
$MsgNPostSent			= "kartka wys�ana teraz."; 

// Admin Page
$MsgAdminPage			= "Panel Zarz�dzania"; 
$MsgAdminCardControlTitle	= "Zarz�dzanie kartkami"; 
$MsgAdminCardControlNote	= "Ta funkcja wykasowuje kartki, kt�re s� starsze ni� XX dni."; 
$MsgAdminDay			= "Dni";
$MsgAdminDelOption1		= "Tylko kartki, kt�re zosta�y odebrane"; 
$MsgAdminDelOption2		= "Tylko kartki, kt�re NIE zosta�y odebrane"; 
$MsgAdminDeleteButton		= "Usu� kartki"; 
$MsgAdminDeletedCards		= "Kartki zosta�y usuni�te z bazy danych."; 

$MsgAdminWarning		= "Uwaga!"; 
$MsgAdminWarning2		= "Ta opcja usuwa WSZYSTKIE kartki z Twojej bazy danych"; 
$MsgAdminWarningReaded		= "zosta�y przeczytane"; 
$MsgAdminWarningNotReaded	= "nie zosta�y przeczytane"; 
$MsgAdminWarning3		= "i s�"; 
$MsgAdminWarning4		= "dni."; 
$MsgAdminWarning5		= "Kartki zostan� usuni�te na podstawie wybranych przez Ciebie kryteri�w. Cy jeste� pewien, �e chcesz kontynuowa�?"; 
$MsgAdminWarningButtonYes	= "Tak, jestem pewien!"; 
$MsgAdminWarningButtonNo	= "Nie, prosz� przesta�!"; 
$MsgAdminWarningNoCardDelete	= "�adne kartki nie zostan� usuni�te na podstawie wybranych przez Ciebie kryteri�w. Wr�� i jeszcze raz zdecyduj kt�re kartki chcesz usun��."; 

$MsgAdminPatternControlTitle	= "Kontrola wzor�w"; 
$MsgAdminMusicControlTitle	= "Kontrola muzyki"; 
$MsgAdminStampControlTitle	= "Kontrola znaczk�w"; 
$MsgAdminIncluded		= "wpis ZA��CZONY"; 
$MsgAdminNoIncluded		= "wpis NIE ZA��CZONY"; 
$MsgAdminDeleted		= "wpis SKASOWANY"; 
$MsgAdminNoDeleted		= "wpis NIE SKASOWANY"; 
$MsgAdminFormFieldEmpty		= "Pole formularza jest puste. Wr�� i spr�buj jeszcze raz!"; 

$MsgAdminModified		= "wpis ZMIENIONY"; 
$MsgAdminNoModified		= "wpis NIE ZMIENIONY"; 

$MsgAdminInclude		= "Dodaj"; 
$MsgAdminDelete			= "Usu�"; 
$MsgAdminEdit			= "Edytuj"; 
$MsgAdminModify			= "Zmie�"; 

$MsgAdminControlMusicFile	= "Plik z muzyk�"; 
$MsgAdminControlMusicName	= "Nazwa utworu"; 
$MsgAdminControlMusicAuthor	= "Autor muzyki"; 
$MsgAdminControlMusicGenre	= "Music Genre";

$MsgAdminControlPatternFile	= "Plik z wzorem (papeteri�)"; 
$MsgAdminControlPatternName	= "Nazwa papeterii"; 
$MsgAdminControlStampFile	= "Plik ze znaczkiem"; 
$MsgAdminControlStampName	= "Nazwa znaczka"; 

$MsgAdminControlPostImgFile	= "Plik do wys�ania"; 
$MsgAdminControlPostThmFile	= "Ikona pliku do wys�ania"; 
$MsgAdminControlPostTemplate	= "Nazwa szablonu";

$MsgAdminPostcardControlTitle	= "Zarz�dzanie kartkami";
$MsgAdminCategoryControlTitle	= "Zarz�dzanie kategoriami";

$MsgAdminExtraInfoTitle		= "Dodatkowe informacje";

$MsgAdminNote			= "Wa�ne";
$MsgAdminNoteMust		= "Plik musi by� jeszcze raz wys�any do";

// Extra Info:
$MsgvCardLiteCommunity		= "vCard Lite Community";
$MsgYourVersion			= "Twoja wersja";
$MsgAvaibaleVersion		= "Dost�pna wersja";

// Statistic Page
$MsgAdminCardStatTitle		= "Statystyka";
$MsgAdminControlImageFile 	= "Plik obrazka";
$MsgAdminTemplateFile 		= "Plik szablonu";
$MsgSeeYourStat			= "Aby zobaczy� statystyki swojego serwisu kartek";
$MsgPosition 			= "Pozycja";
$MsgHits			= "Hity";
$MsgTop 			= "Najpopularniejsze";

$MsgAdminStatsRestart		= "Uruchom statystyki od nowa";
$MsgAdminStatsDbEmpty		= "Baza danych statystyk jest PUSTA";
$MsgAdminStatsDbNoEmpty		= "Baza danych statystyk NIE jest PUSTA";
$MsgAdminStatsNote		= "Je�eli chcesz uruchomi� statystyk� od nowa, mo�esz to zrobi� naciskaj�c ten przycisk. Musisz jednak pami�ta�, �e wszystkie aktualne statystyki zostan� usuni�te. Aby je zachowa� zapisz je najpierw na swoim twardym dysku.";

// Gallery Browser Pages
$MsgNext			= "=>";
$MsgPrevious			= "<=";
$MsgBackCatMain			= "Powr�t na stron� g��wn�";

$MsgNoCardsinDB			= "Niestety, nie ma �adnych kartek w bazie danych";
$MsgInvalidePageNumber		= "Wybra�e� nieprawid�owy numer strony";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Nazwa kategorii";
$MsgAdminGalleryControlTitle	= "Zarz�dzanie galeri�";

$MsgAdminLinkBrowser		= "przegl�daj";
$MsgAdminLinkEdit		= "edytuj";
$MsgAdminLinkDelete		= "usu�";

// MENU
$MsgMusic			= "Muzyka";
$MsgPattern			= "Wz�r";
$MsgMain			= "G�owna";
$MsgGallery			= "Galeria";
$MsgStamp			= "Znaczek";
$MsgStats			= "Statystyki";
$MsgAdminBrowser		= "Przegl�darka";
$MsgPHPInfo			= "PHP Info";

$MsgCategories			= "Kategorie";
$MsgCategory			= "Kategoria";
$MsgPostcards			= "";

// Back Link Messages
$MsgBack			= "Powr�t";
$MsgBackButton			= "Powr�t do poprzedniej strony";
$MsgBacktoSection		= "Powr�t do poprzedniej sekcji";

// File Upload
$MsgUploadYourOwnFileTitle	= "U�yj w�asnego obrazka";
$MsgUploadYourOwnFileInfo	= "Stw�rz kartk� u�ywaj�c w�asnego obrazka";
$MsgErrorFileExtension		= "Niedozwolone rozszerzenie pliku. Powinno by�: .gif, .jpeg, .jpg albo .swf (wszystkie ma�ymi literami)!";
$MsgFileBiggerThan		= "Rozmiar pliku jest wi�kszy ni�"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed		= "Maksymalny rozmiar pliku, kt�ry mo�esz wys�a� to "; // Fhe max size of file is XX Kbytes
 $MsgFileAllowed		= "Mo�esz wys�a� w�asny obrazek (.gif, ...jpg) albo animacj� we flash'u (.swf) aby stworzy� w�asn�, niepowtarzaln� kartk�. Wybierz sw�j plik i kliknij na przycisk";
$MsgFileUploadNotAllowed	= "Przepraszamy! System wysy�ania plik�w jest niedost�pny na tej stronie.";
$MsgFileSend			= "Wy�lij plik!";
$MsgFileSelect			= "Wybierz sw�j plik";
$MsgFileUseFile			= "Stw�rz kartk�";

// added v2.4

$MsgSLog = 'Service Log';
$MsgAdminEntries = 'registries';
$MsgAdminLogRestart = 'Restart Service Log';
$MsgAdminLogNote = 'If you like to restart/clean the service log, you�re free to do so by pushing this button. Consider however that all your current informations are deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.';
$MsgAdminLogRname = 'Recip Name';
$MsgAdminLogRemail = 'Recip Email';
$MsgAdminLogSname = 'Sender Name';
$MsgAdminLogSemail = 'Sender Email';
$MsgAdminLogSip = 'Sender IP';
$MsgAdminLogDate = 'Date';
$MsgAdminLogSentDate = 'Sent/To Send date';
$MsgAdminLogEcard = 'Ecard';


?>