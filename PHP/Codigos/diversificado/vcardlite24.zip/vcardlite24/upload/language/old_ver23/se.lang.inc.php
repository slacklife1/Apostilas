<?php
/*************************************************************************
      language      : swedish
      file          : se.lang.inc.php
      begin         : 2002-03-09
      translator    : Patrick (webmaster@osterlund.net)
      home          : http://www.osterlund.net
      version       : Swedish 1.0
      charset       : ISO-8859-1
*************************************************************************/
$charset			='ISO-8859-1';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect		= "F�r ingen kontakt med databsen just nu!";
$MsgUnableLocateDB		= "Hittar inte vald databas!";
$MsgErrorPerformingQuery	= "Ett fel uppstod vid f�rfr�gan mot databasen";

// Create, Preview and View Page
$MsgImage			= "Bild";
$MsgYourTitle			= "�verskrift";
$MsgMessage			= "Meddelande";
$MsgFont			= "Typsnitt";
$MsgNoFontFace			= "Inget typsnitt";
$MsgFontSizeSmall		= "Liten stil";
$MsgFontSizeMedium		= "Mellanstor stil";
$MsgFontSizeLarge		= "Stor stil";
$MsgFontSizeXLarge		= "XL stil";
$MsgFontColorBlack		= "Svart typsnitt";
$MsgFontColorWhite		= "vitt typsnitt";
$MsgSignature			= "Signatur";
$MsgRecpName			= "Mottagarens namn";
$MsgRecpEmail			= "Mottagarens e-post";
$MsgAddRecp			= "Mottagare";
$MsgPlay			= "Spela";
$MsgYourName			= "Ditt namn";
$MsgYourEmail			= "Din e-post";
$MsgChooseLayout		= "V�lj utseende p� ditt kort";
$MsgChooseDate			= "Datum n�r det skall skickas?";
$MsgDateFormat			= "V�lj dagens datum f�r att skicka kortet genast.";
$MsgChooseStamp			= "V�lj frim�rke";
$MsgPostColor			= "Bakgrundsf�rg f�r kortet";
$MsgPageBackground		= "Bakgrundsm�nster";
$MsgNone			= "Inget";
$MsgMusic			= "Musik";
$MsgPreviewButton		= "Titta innan du skickar";
$MsgNotify			= "Meddela mig via e-mail n�r mottagaren l�st kortet";
$MsgYes				= "Ja";
$MsgNo				= "Nej";
$MsgNoFlash			= "Du m�ste ha Flashspelarens plug-in f�r att se Flashversionen av vykortet. ";
$MsgClickHereToGet		= "Klicka h�r f�r att h�mta den!";
$MsgHelp			= "Hj�lp!";
$MsgCloseWindow			= "St�ng f�nstret";
$MsgPrintable                   = "Utskriftsversion";

// Error Messages
$MsgActiveJS			= "Du m�ste aktivera javascript!";
$MsgErrorMessage		= "Du m�ste skriva ett meddelande f�r ditt kort.";
$MsgErrorRecpName		= "Du m�ste ange mottagarens namn.";
$MsgErrorRecpEmail		= "Du m�ste ange mottagarens e-mailadress.";
$MsgErrorRecpEmail2		= "Mottagarens <B>e-mail adress</B> �r ogiltig.";
$MsgErrorSenderName		= "Du m�ste ange ditt namn.";
$MsgErrorSenderEmail		= "Du m�ste ange din e.mailadress.";
$MsgErrorSenderEmail2		= "Din <B>e-mailadress</B> �r ogiltig.";
$MsgErrorNotFoundTxt		= "Ledsen, jag kan inte hitta ngt vykort som matchar det nummer som du angett. Du kan ha skrivit fel vykortsid eller s� har ditt kort legat f�r l�nge och har blivit raderat av systemet.";

$MsgBackEditButton		= "Tillbaka till editera (OBS: all info f�rsvinner)";
$MsgSendButton			= "Skicka kortet!";

$MsgSendTo			= "Skicka ett kort till:";
$MsgClickHere			= "Klicka h�r";
$MsgAvoidDuplicat		= "Klicka enbart en g�ng f�r att undvika kopior!";

// Info Windows
$MsgWinEmoticons		= "Emoticons";
$MsgWinEmoticonsNote		= "Alla tecken �r versaler(O och P)!";
$MsgWinEmoticonsNoteFotter	= "<B>Om</B> Du INTE vill att grafiken skall visas, men fortfarande kunna anv�nda orginal emoticons m�ste du ta bort \"nosen\".";
$MsgWinBackground		= "Bakgrundsbild";
$MsgWinStamp			= "Frim�rke";
$MsgWinColors			= "F�rger";
$MsgWinMusic			= "Musik";
$MsgWinMusicNote		= "V�lj.";
$MsgWinNotify			= "Vill du f� en bekr�ftelse n�r mottagaren har h�mtat sitt kort?";
$MsgWinFonts			= "Typsnitt";
$MsgWinFontsNote		= "Om du vill utnyttja dig av denna m�jlighet, <FONT COLOR=red>t�nk p� </FONT> att alla kanske inte har exkat dessa typsnitt p� sina datorer. Om de inte finns kommer kortet att visas med \"Default\" typsnitten, vanligvis Times och Arial eller Helvetica.";
$MsgWinName			= "Namn";
$MsgWinSample			= "Demo";
$MsgWinSampleString		= "abcdefghijklmnopqrstuvwxyz���";

// Message in confirmation page
$MsgSendAnotherCard		= "Skicka ytterliggare ett virtuellt vykort";

// Advanced Send
$MsgNPostSent			= "skickade vykort denna g�ng.";

// Admin Page
$MsgAdminPage			= "Kontrollpanel";
$MsgAdminCardControlTitle	= "Vykortskontroller";
$MsgAdminCardControlNote	= "Denna funktion raderar vykort som �r XX dagar gamla.";
$MsgAdminDay			= "Dagar";
$MsgAdminDelOption1		= "Enbart h�mtade kort";
$MsgAdminDelOption2		= "Enbart o-h�mtade kort";
$MsgAdminDeleteButton		= "Radera vykort";
$MsgAdminDeletedCards		= "kort blev raderade ur databasen.";

$MsgAdminWarning		= "Varning!";
$MsgAdminWarning2		= "Detta val raderar alla kort i databasen som";
$MsgAdminWarningReaded		= "har blivit l�sta";
$MsgAdminWarningNotReaded	= "�r ol�sta";
$MsgAdminWarning3		= "och �r";
$MsgAdminWarning4		= "dagar gamla.";
$MsgAdminWarning5		= "korten kommer att bli raderade baserade p� dina val. Vill du forts�tta?";
$MsgAdminWarningButtonYes	= "Ja, jag �r s�ker!";
$MsgAdminWarningButtonNo	= "Nej, v�nta!";
$MsgAdminWarningNoCardDelete	= "Inga vykort kommer att raderas baserat p� dina val. G� tillbaka och g�r nya val.";

$MsgAdminPatternControlTitle	= "M�nsterkontroll";
$MsgAdminMusicControlTitle	= "Musikkontroll";
$MsgAdminStampControlTitle	= "Frim�rkskontroll";
$MsgAdminIncluded		= "entry INCLUDED";
$MsgAdminNoIncluded		= "entry NOT INCLUDED";
$MsgAdminDeleted		= "entry DELETED";
$MsgAdminNoDeleted		= "entry NOT DELETED";
$MsgAdminFormFieldEmpty		= "form field is empty. Go back and try again!";

$MsgAdminModified		= "entry MODIFIED";
$MsgAdminNoModified		= "entry NOT MODIFIED";

$MsgAdminInclude		= "Addera"; 
$MsgAdminDelete			= "Radera"; 
$MsgAdminEdit			= "Editera";
$MsgAdminModify			= "�ndra";

$MsgAdminControlMusicFile	= "Musikfil";
$MsgAdminControlMusicName	= "Musikens namn";
$MsgAdminControlMusicAuthor	= "F�rfattare";
$MsgAdminControlMusicGenre	= "Genre";

$MsgAdminControlPatternFile	= "M�nsterfil";
$MsgAdminControlPatternName	= "M�nstrets namn";
$MsgAdminControlStampFile	= "Frim�rksfil";
$MsgAdminControlStampName	= "Frim�kets namn";

$MsgAdminControlPostImgFile	= "Post File";
$MsgAdminControlPostThmFile	= "Post Thumb file";
$MsgAdminControlPostTemplate	= "Namn p� mallen";

$MsgAdminPostcardControlTitle	= "Vykortskontroll";
$MsgAdminCategoryControlTitle	= "Kategorier";

$MsgAdminExtraInfoTitle		= "Extrainfo";

$MsgAdminNote			= "OBS";
$MsgAdminNoteMust		= "Filen m�sta laddas upp till";

// Extra Info:
$MsgvCardLiteCommunity		= "vCard Lite Community";
$MsgYourVersion			= "Version";
$MsgAvaibaleVersion		= "Tillg�nglig version";

// Statistic Page
$MsgAdminCardStatTitle		= "Statistik";
$MsgAdminControlImageFile 	= "Bildfil";
$MsgAdminTemplateFile 		= "Mallfil";
$MsgSeeYourStat			= "F�r att se vykortsstatistik";
$MsgPosition 			= "Position";
$MsgHits			= "Tr�ffar";
$MsgTop 			= "Top ";

$MsgAdminStatsRestart		= "Starta om statistiken";
$MsgAdminStatsDbEmpty		= "Statistikdatabasen �r TOM";
$MsgAdminStatsDbNoEmpty		= "Statistikdatabasen �r INTE TOM";
$MsgAdminStatsNote		= "Om du vill starta om statistiken s� g�r du det genom att klicka p� knappen. All information kommer dock att f�rsvinna. Om du vill spara informationen kan du g�ra det genom att spara ner denna sida till din lokala h�rddisk.";

// Gallery Browser Pages
$MsgNext			= "N�sta";
$MsgPrevious			= "F�reg�ende";
$MsgBackCatMain			= "Tillbaka till kategorierna";

$MsgNoCardsinDB			= "Tyv�rr, det finns inga vykort lagrade i databasen.";
$MsgInvalidePageNumber		= "Du har angett ett ogiltigt sidnummer";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Kategorier";
$MsgAdminGalleryControlTitle	= "Gallerikontroll";

$MsgAdminLinkBrowser		= "bl�ddra";
$MsgAdminLinkEdit		= "editera";
$MsgAdminLinkDelete		= "radera";

// MENU
$MsgMusic			= "Musik";
$MsgPattern			= "M�nster";
$MsgMain			= "Main";
$MsgGallery			= "Galleriet";
$MsgStamp			= "Frim�rken";
$MsgStats			= "Stats";
$MsgAdminBrowser		= "Browser";
$MsgPHPInfo			= "PHP Info";

$MsgCategories			= "Kategorier";
$MsgCategory			= "Kategori";
$MsgPostcards			= "Vykort";

// Back Link Messages
$MsgBack			= "Tillbaka";
$MsgBackButton			= "Tillbaka till f�reg�ende sida";
$MsgBacktoSection		= "Tillbaka till f�reg�ende avdelning";

// File Upload
$MsgUploadYourOwnFileTitle	= "Anv�nd din egen bild";
$MsgUploadYourOwnFileInfo	= "Skapa ett vykort genom att anv�nda din egen bild";
$MsgErrorFileExtension		= "Filextensioner �r inte till�tna. De m�ste vara av typen .gif, .jpeg, .jpg eller .swf i gemener!";
$MsgFileBiggerThan		= "Filen �r st�rre �n "; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed		= "St�rsta till�tna storlek p� bilder �r "; // Fhe max size of file is XX Kbytes
$MsgFileAllowed			= "Du kan ladda upp din egen bild(.gif, .jpg) eller flashanimationer(.swf) f�r att skapa ett vykort. V�lj bild och klicka p� knappen.";
$MsgFileUploadNotAllowed	= "Uppladdning av filer �r f�r tillf�llet inte till�tet.";
$MsgFileSend			= "Skicka fil!";
$MsgFileSelect			= "V�lj din bild";
$MsgFileUseFile			= "Skapa vykort";

// added v2.4

$MsgSLog = 'Service Log';
$MsgAdminEntries = 'registries';
$MsgAdminLogRestart = 'Restart Service Log';
$MsgAdminLogNote = 'If you like to restart/clean the service log, you�re free to do so by pushing this button. Consider however that all your current informations are deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.';
$MsgAdminLogRname = 'Recip Name';
$MsgAdminLogRemail = 'Recip Email';
$MsgAdminLogSname = 'Sender Name';
$MsgAdminLogSemail = 'Sender Email';
$MsgAdminLogSip = 'Sender IP';
$MsgAdminLogDate = 'Date';
$MsgAdminLogSentDate = 'Sent/To Send date';
$MsgAdminLogEcard = 'Ecard';


?>