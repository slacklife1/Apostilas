<?php
/*************************************************************************
      language      : slovenian
      file          : si.lang.inc.php
      begin         : 2001-09-10
      translator    : Peter Mrhar
                      flamingo@eunet.si
      charset       : ISO-8859-2
*************************************************************************/
$charset			= 'ISO-8859-2';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect		= "Trenutno se ne morem povezati s podatkovno zbirko!";
$MsgUnableLocateDB		= "Trenutno ne morem odkriti podatkovne zbirke!";
$MsgErrorPerformingQuery	= "Ne morem izvesti poizvedba";

// Create, Preview and View Page
$MsgImage			= "Slika";
$MsgYourTitle			= "Naslov";
$MsgMessage			= "Sporo�ilo";
$MsgFont			= "Pisava";
$MsgNoFontFace			= "Ni pisav";
$MsgFontSizeSmall		= "Mala velikost";
$MsgFontSizeMedium		= "Srednja velikost";
$MsgFontSizeLarge		= "Velike �rke";
$MsgFontSizeXLarge		= "Zelo velike �rke";
$MsgFontColorBlack		= "�rna barva";
$MsgFontColorWhite		= "Bela barva";
$MsgSignature			= "Podpis";
$MsgRecpName			= "Prejemnikovo ime";
$MsgRecpEmail			= "Prejmenikov E-naslov";
$MsgAddRecp			= "Dodaj prejemnika";
$MsgPlay			= "Igraj";
$MsgYourName			= "Va�e ime";
$MsgYourEmail			= "Va� E-naslov";
$MsgChooseLayout		= "Izberite postavitev vo��ilnice";
$MsgChooseDate			= "Katerega dne odpo�ljem kartico?";
$MsgDateFormat			= "Izberite dana�nji dan - oblika datuma je DD/MM/YYYY.";
$MsgChooseStamp			= "Izberite znamko";
$MsgPostColor			= "Barva ozadja vo��ilnice";
$MsgPageBackground		= "Tapeta";
$MsgNone			= "Ni�";
$MsgMusic			= "Glasba";
$MsgPreviewButton		= "Predogled pred po�iljanjem";
$MsgNotify			= "Ko bo prejemnik prebral vo��ilnico, me obvesti prek E-po�te.";
$MsgYes				= "Da";
$MsgNo				= "Ne";
$MsgNoFlash			= "�e �elite videti to vo��ilnico, potrebujete vgradni modul Flash.";
$MsgClickHereToGet		= "Dobili ga boste, �e kliknete tu!";
$MsgHelp			= "Pomo�!";
$MsgCloseWindow			= "Zapri okno";
$MsgPrintable                   = "Razli�ica za tiskanje";

// Error Messages
$MsgActiveJS			= "Prosimo, aktivirajte javascript!";
$MsgErrorMessage		= "V pismo morate zapisati spro�ilo.";
$MsgErrorRecpName		= "Vnesti morate prejemnikovo ime.";
$MsgErrorRecpEmail		= "Vnesti morate prejemnikov E-naslov.";
$MsgErrorRecpEmail2		= "Prejemnikov <B>E-naslov</B> je napa�en.";
$MsgErrorSenderName		= "Vpistati morate va�e ime.";
$MsgErrorSenderEmail		= "Vpisati morate va� E-naslov";
$MsgErrorSenderEmail2		= "Va� <B>E-naslov</B> je napa�en.";
$MsgErrorNotFoundTxt		= "�al, nobena vo��ilnica ne ustreza �tevilki va�e vo��ilnice. Vtipkali ste napa�en ID vo��ilnice, ali je va�a  vo��ilnica prestara in je bila izbrisana iz sistema.";

$MsgBackEditButton		= "Nazaj k urejanju";
$MsgSendButton			= "Po�lji vo��ilnico!";

$MsgSendTo			= "Po�ljite vo��ilnico. Prejemnik bo ";
$MsgClickHere			= "Kliknite tu.";
$MsgAvoidDuplicat		= "�e se �elite izogniti podvajanju, kliknite samo enkrat!";

// Info Windows
$MsgWinEmoticons		= "Sme�koti";
$MsgWinEmoticonsNote		= "Vse �rke so velike (O in P)!";
$MsgWinEmoticonsNoteFotter	= "<B>�e</B> NE �elite uporabiti grafi�nega prikaza, a �elite vseeno prikazati sme�kote, ne smete vtipkati nosu.";
$MsgWinBackground		= "Slika tapete";
$MsgWinStamp			= "Slika znamke";
$MsgWinColors			= "Barve";
$MsgWinMusic			= "Glasba";
$MsgWinMusicNote		= "Izberite �eleno mo�nost.";
$MsgWinNotify			= "Naj vas prek E-po�te obvestimo, ko prejemnik prebere vo��ilnico?";
$MsgWinFonts			= "Pisave";
$MsgWinFontsNote		= "�e �elite uporabiti to mo�nost, <FONT COLOR=red>se morate zavedati</FONT>, da nima vsakdo name��enih tu prikazanih pisav. V takem primeru bo besedilo prikazano prek ene izmed privzetih pisav, na primer Timesa in Ariala oz. Helvetice.";
$MsgWinName			= "Ime";
$MsgWinSample			= "Primer";
$MsgWinSampleString		= "abc�defghijklmnoprs�tuvz�";

// Message in confirmation page
$MsgSendAnotherCard		= "Po�lji naslednjo vo��ilnico";

// Advanced Send
$MsgNPostSent			= "vo��ilnic poslanih v tem �asu.";

// Admin Page
$MsgAdminPage			= "Nadzorna plo��a";
$MsgAdminCardControlTitle	= "Nadzor vo��ilnic";
$MsgAdminCardControlNote	= "Ta pripomo�ek bo izbrisal vo��ilnice, ki so starej�e od XX dni.";
$MsgAdminDay			= "Dni";
$MsgAdminDelOption1		= "Samo vo��ilnice, ki SO bile izbrane";
$MsgAdminDelOption2		= "Samo vo��ilnice, ki NISO bile izbrane";
$MsgAdminDeleteButton		= "Izbri�i vo��ilnice";
$MsgAdminDeletedCards		= "vo��ilnic je bilo izbrisanih iz podatkovne zbirke.";

$MsgAdminWarning		= "Opozorilo!";
$MsgAdminWarning2		= "Ta izbira izbri�e iz podatkovne zbirke vse vo��ilnice, ki";
$MsgAdminWarningReaded		= "so bile prebrane";
$MsgAdminWarningNotReaded	= "�e niso bile prebrane";
$MsgAdminWarning3		= "in so";
$MsgAdminWarning4		= "dni stare.";
$MsgAdminWarning5		= "vo��ilnic bo izbrisanih po va�ih merilih. �elite resni�no nadaljevati?";
$MsgAdminWarningButtonYes	= "Da, prepri�an sem!";
$MsgAdminWarningButtonNo	= "Ne, prekini!";
$MsgAdminWarningNoCardDelete	= "Nobena vo��ilnica, izbrana po va�ih merilih, ne bo izbrisana. Vrnite se nazaj in dolo�ite nova merila.";

$MsgAdminPatternControlTitle	= "Nadzor vzorcev";
$MsgAdminMusicControlTitle	= "Nadzor pesmi";
$MsgAdminStampControlTitle	= "Nadzor znamk";
$MsgAdminIncluded		= "VNESNA";
$MsgAdminNoIncluded		= "NI VNESENA";
$MsgAdminDeleted		= "IZBRISANA";
$MsgAdminNoDeleted		= "NI IZBRISANA";
$MsgAdminFormFieldEmpty		= "polje je prazno. Vrnite se nazaj in poiskusite ponovno!";

$MsgAdminModified		= "SPREMENJENA";
$MsgAdminNoModified		= "NI SPREMENJENA";

$MsgAdminInclude		= "Dodaj";
$MsgAdminDelete			= "Izbri�i";
$MsgAdminEdit			= "Uredi";
$MsgAdminModify			= "Spremeni";

$MsgAdminControlMusicFile	= "Glasbena datoteka";
$MsgAdminControlMusicName	= "Ime pesmi";
$MsgAdminControlMusicAuthor	= "Avtor pesmi";
$MsgAdminControlMusicGenre	= "�anr glasbe";

$MsgAdminControlPatternFile	= "Datoteka vzorca";
$MsgAdminControlPatternName	= "Ime vzorca";
$MsgAdminControlStampFile	= "Datoteka znamke";
$MsgAdminControlStampName	= "Ime znamke";

$MsgAdminControlPostImgFile	= "Datoteka vo��ilnice";
$MsgAdminControlPostThmFile	= "Datoteka pomanj�ane slike";
$MsgAdminControlPostTemplate	= "Ime predloge";

$MsgAdminPostcardControlTitle	= "Nadzor vo��ilnic";
$MsgAdminCategoryControlTitle	= "Nadzor kategorij";

$MsgAdminExtraInfoTitle		= "Dodatne informacije";

$MsgAdminNote			= "Opomba";
$MsgAdminNoteMust		= "Datoteko morate presneti tudi na ";

// Extra Info:
$MsgvCardLiteCommunity		= "Skupnost vCard Lite";
$MsgYourVersion			= "Va�a razli�ica";
$MsgAvaibaleVersion		= "Zadnja razli�ica";

// Statistic Page
$MsgAdminCardStatTitle		= "Statistika";
$MsgAdminControlImageFile 	= "Slikovna datoteka";
$MsgAdminTemplateFile 		= "Datoteka predloge";
$MsgSeeYourStat			= "�e �elite videti statistike vo��ilnic";
$MsgPosition 			= "Polo�aj";
$MsgHits			= "Uporabljena";
$MsgTop 			= "Najpopularnej�ih ";

$MsgAdminStatsRestart		= "Ponovno za�enei statistike";
$MsgAdminStatsDbEmpty		= "Statisti�ni podatki NE obstajajo";
$MsgAdminStatsDbNoEmpty		= "Statisti�ni podatki so na voljo";
$MsgAdminStatsNote		= "�e �elite ponovno zagnati vodenje statisti�nih podatkov, lahko kliknete na ta gumb. Zavedati pa se morate, da bodo vsi statisti�ni podatki izbrisani. V primeru, ko �elite te �e kdaj pregledati, jih lahko shranite v trdi disk.";

// Gallery Browser Pages
$MsgNext			= "Naslednji";
$MsgPrevious			= "Prej�nji";
$MsgBackCatMain			= "Nazaj na osnovno stran kategorij";

$MsgNoCardsinDB			= "Oprostite, v podatkovni zbirki ni vo��ilnic.";
$MsgInvalidePageNumber		= "Dolo�ili ste napa�no �tevilko strani";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Ime kategorije";
$MsgAdminGalleryControlTitle	= "Nadzor galerije";

$MsgAdminLinkBrowser		= "preglej";
$MsgAdminLinkEdit		= "uredi";
$MsgAdminLinkDelete		= "izbri�i";

// MENU
$MsgMusic			= "Glasba";
$MsgPattern			= "Vzorec";
$MsgMain			= "Osnove";
$MsgGallery			= "Galerija";
$MsgStamp			= "Znamka";
$MsgStats			= "Statistike";
$MsgAdminBrowser		= "Preglej";
$MsgPHPInfo			= "Informacije o PHP";

$MsgCategories			= "Kategorije";
$MsgCategory			= "Kategorija";
$MsgPostcards			= "Vo��ilnice";

// Back Link Messages
$MsgBack			= "Nazaj";
$MsgBackButton			= "Nazaj na prej�njo stran";
$MsgBacktoSection		= "Nazaj na prej�nji odsek";

// File Upload
$MsgUploadYourOwnFileTitle	= "Uporabi lastne slike";
$MsgUploadYourOwnFileInfo	= "Ustvari vo��ilnico na podlagi tvoje slike";
$MsgErrorFileExtension		= "Taka kon�nica datoteke ni dovoljena. Uporabite lahko le .gif, .jpeg, .jpg ali .swf, vse pa morajo biti zapisane z malimi �rkami!";
$MsgFileBiggerThan		= "Velikost datoteke presega"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed		= "Najve�ja dovoljena velikost datoteke za kopiranje (upload) je "; // Fhe max size of file is XX Kbytes
$MsgFileAllowed			= "�e �elite ustvariti nove vo��ilnice, lahko na stre�nik prekopirate (upload) va�e slike (.gif, .jpg) ali animacije tipa flash (.swf). Izberite va�o datoteko in kliknite na spodnji gumb.";
$MsgFileUploadNotAllowed	= "To spletno mesto ne dovoljuje kopiranja datotek.";
$MsgFileSend			= "Po�lji datoteko!";
$MsgFileSelect			= "Izberite datoteko";
$MsgFileUseFile			= "Ustvari vo��ilnico";

// added v2.4

$MsgSLog = 'Service Log';
$MsgAdminEntries = 'registries';
$MsgAdminLogRestart = 'Restart Service Log';
$MsgAdminLogNote = 'If you like to restart/clean the service log, you�re free to do so by pushing this button. Consider however that all your current informations are deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.';
$MsgAdminLogRname = 'Recip Name';
$MsgAdminLogRemail = 'Recip Email';
$MsgAdminLogSname = 'Sender Name';
$MsgAdminLogSemail = 'Sender Email';
$MsgAdminLogSip = 'Sender IP';
$MsgAdminLogDate = 'Date';
$MsgAdminLogSentDate = 'Sent/To Send date';
$MsgAdminLogEcard = 'Ecard';


?>