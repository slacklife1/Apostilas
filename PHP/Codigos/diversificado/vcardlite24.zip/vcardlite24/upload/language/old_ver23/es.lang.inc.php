<?php
/*************************************************************************
      language      : spanish
      file          : es.lang.inc.php
      begin         : 2001-02-15
      copyright     : (c) 2001 by Enrique J. Garc�a M.
      home          : http://www.entrecristianos.com
      charset       : ISO-8859-1
*************************************************************************/
$charset			='iso-8859-1';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect = "En estos momementos no podemos conectarnos a la base de datos";
$MsgUnableLocateDB = "En estos momementos no podemos encontrar la base de datos";
$MsgErrorPerformingQuery = "Error al ejecutar la b�squeda";

// Create, Preview and View Page
$MsgImage = "Imagen";
$MsgYourTitle = "T�tulo";
$MsgMessage = "Mensaje";
$MsgFont = "Fuente";
$MsgNoFontFace = "No me importa la fuente";
$MsgFontSizeSmall = "Tama�o Peque�o";
$MsgFontSizeMedium = "Tama�o mediano";
$MsgFontSizeLarge = "Tama�o Grande";
$MsgFontSizeXLarge = "Tama�o extragrande";
$MsgFontColorBlack = "Negro";
$MsgFontColorWhite = "Blanco";
$MsgSignature = "Firma";
$MsgRecpName = "Nombre del receptor";
$MsgRecpEmail = "Email del receptor";
$MsgAddRecp = "A�adir Registros";
$MsgPlay = "Tocar";
$MsgYourName = "Tu nombre";
$MsgYourEmail = "Tu direcci�n de email";
$MsgChooseLayout = "Escoje el formato de la tarjeta";
$MsgChooseDate = "Fecha que quieres se reciba la tarjeta?";
$MsgDateFormat = "Escoje el d�a para enviar la tarjeta (formato: DD/MM/AAAA).";
$MsgChooseStamp = "Escoje el tipo de estampilla";
$MsgPostColor = "Escoje el color de fondo";
$MsgPageBackground = "Papel Tap�z";
$MsgNone = "Ninguno";
$MsgMusic = "M�sica";
$MsgPreviewButton = "Previsualizar antes de enviar";
$MsgNotify = "Notif�came cuando el receptor lea la tarjeta.";
$MsgYes = "S�";
$MsgNo = "No";
$MsgNoFlash = "Necesitas el plug-in de Macromedia Flash player plug-in para ver este tipo de tarjeta. ";
$MsgClickHereToGet = "Presiona ac� para obtenerlo";
$MsgHelp = "Ayuda";
$MsgCloseWindow = "Cerrar Ventana";
$MsgPrintable = "Version para imprimir";

// Error Messages
$MsgActiveJS = "Debes tener activo la funcionalidad de javascript en tu browser";
$MsgErrorMessage = "Debes escribir el mensaje de tu tarjeta.";
$MsgErrorRecpName = "Debes escribir el nombre del receptor de la tarjeta";
$MsgErrorRecpEmail = "Debes indicar el e-mail del receptor de la tarjeta";
$MsgErrorRecpEmail2 = "El email tuyo o el del receptor es inv�lido";
$MsgErrorSenderName = "Debes indicar tu nombre";
$MsgErrorSenderEmail = "Debes indicar tu email address.";
$MsgErrorSenderEmail2 = "Tu <B>direcci�n email</B> is inv�lida.";
$MsgErrorNotFoundTxt = "Lo siento, no existen tarjetas que concuerden con ese n�mero. Es posible que escribiste mal la identificaci�n o que la tarjeta sea demasiado vieja y ya no exista en nuestro sistema.";
$MsgBackEditButton = "Regresar atr�s para hacer cambios";
$MsgSendButton = "Enviar la tarjeta";
$MsgSendTo = "Enviar la tarjeta a";
$MsgClickHere = "Presiona aqu�";
$MsgAvoidDuplicat = "Presiona s�lo una vez para evitar que se duplique";

// Info Windows
$MsgWinEmoticons = "Emociones virtuales";
$MsgWinEmoticonsNote = "Todos los caracteres deben ser en may�sculas (O y P)";
$MsgWinEmoticonsNoteFotter = "<B>Si</B> tu no quieres que el gr�fico aparezca, pero quieres que la emoci�n virtual debes excluir la nar�z.";
$MsgWinBackground = "Im�genes de papel tapiz";
$MsgWinStamp = "Im�genes de estampillas";
$MsgWinColors = "Colores";
$MsgWinMusic = "M�sica";
$MsgWinMusicNote = "Selecciona una opci�n.";
$MsgWinNotify = "�Deseas recibir una notificaci�n por email cuando la tarjeta sea vista por el receptor?";
$MsgWinFonts = "Fuentes";
$MsgWinFontsNote = "Si deseas usar esta opci�n, <FONT COLOR=red>ten en cuenta</FONT> que no todo el mundo tiene las mismas tipos de fuentes intaladas en el computador. Si esto ocurre se utilizar�n las fuentes Times, Arial y/o Helvetica.";
$MsgWinName = "Nombre";
$MsgWinSample = "Ejemplo";
$MsgWinSampleString = "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard = "Enviar otra tarjeta virtual";

// Advanced Send
$MsgNPostSent = "Se ha enviado la tarjeta virtual";

// Admin Page
$MsgAdminPage = "Panel de Control";
$MsgAdminCardControlTitle = "Controles de tarjetas";
$MsgAdminCardControlNote = "Esta utilidad borrar� las tarjetas que tienen XX d�as en el sistema.";
$MsgAdminDay = "D�as";
$MsgAdminDelOption1 = "S�lo las tarjetas que han sido recojidas";
$MsgAdminDelOption2 = "S�lo las tarjetas que NO han sido recojidas";
$MsgAdminDeleteButton = "Borrar las tarjetas";
$MsgAdminDeletedCards = "Tarjetas que han sido borradas de la base de datos";
$MsgAdminWarning = "Atenci�n!!!!";
$MsgAdminWarning2 = "Esta opci�n borrar� las tarjetas de la base de datos que ";
$MsgAdminWarningReaded = "han sido leidas";
$MsgAdminWarningNotReaded = "no han sido leidas";
$MsgAdminWarning3 = "y tienen ";
$MsgAdminWarning4 = "d�as en el sistema.";
$MsgAdminWarning5 = "tarjetas que ser�n borradas seg�n el criterio seleccionado. Est�s seguro?";
$MsgAdminWarningButtonYes = "S�, estoy seguro!";
$MsgAdminWarningButtonNo = "No, no lo hagas!";
$MsgAdminWarningNoCardDelete = "Ninguna tarjeta ser� borrada seg�n su criterio de selecci�n. Seleccione un nuevo criterio de selecci�n.";
$MsgAdminPatternControlTitle = "Control de Textura";
$MsgAdminMusicControlTitle = "Control de M�sica";
$MsgAdminStampControlTitle = "Control de Estampillas";
$MsgAdminIncluded = "Incluida la selecci�n";
$MsgAdminNoIncluded = "La selecci�n NO fue incluida";
$MsgAdminDeleted = "Se borr� la selecci�n";
$MsgAdminNoDeleted = "No se borr� la selecci�n";
$MsgAdminFormFieldEmpty = "campo vac�o. Vuelve atr�s y reintenta";
$MsgAdminModified = "registro MODIFICADO";
$MsgAdminNoModified = "NO SE MODIFICO el registro";
$MsgAdminInclude = "A�adir"; 
$MsgAdminDelete = "Borrar"; 
$MsgAdminEdit = "Editar";
$MsgAdminModify = "Modificar";
$MsgAdminControlMusicFile = "Archivo de M�sica";
$MsgAdminControlMusicName = "Nombre de la M�sica";
$MsgAdminControlMusicAuthor = "Autor de la M�sica";
$MsgAdminControlMusicGenre = "G�nero de la M�sica";
$MsgAdminControlPatternFile = "Archivo de Textura";
$MsgAdminControlPatternName = "Nombre de la Textura";
$MsgAdminControlStampFile = "Archivo de Estampilla";
$MsgAdminControlStampName = "Nombre de la Estampilla";
$MsgAdminControlPostImgFile = "Enviar Archivo";
$MsgAdminControlPostThmFile = "Enviar Archivo Peque�o";
$MsgAdminControlPostTemplate = "Nombre del Formato";
$MsgAdminPostcardControlTitle = "Control de Tarjetas";
$MsgAdminCategoryControlTitle = "Control de Categor�as";
$MsgAdminExtraInfoTitle = "Informaci�n Adicional";
$MsgAdminNote = "Nota";
$MsgAdminNoteMust = "El Archivo debe ser cargado en";

// Extra Info:
$MsgvCardLiteCommunity = "Tarjetas entrecristianos vCard Lite";
$MsgYourVersion = "";
$MsgAvaibaleVersion = "";

// Statistic Page
$MsgAdminCardStatTitle = "Estad�sticas";
$MsgAdminControlImageFile = "Archivo de Imagen";
$MsgAdminTemplateFile = "Archivo de Formato";
$MsgSeeYourStat = "Para ver el servicio de estad�sticas postales";
$MsgPosition = "Posici�n";
$MsgHits = "Hits";
$MsgTop = "Las Top ";
$MsgAdminStatsRestart = "Reiniciar las Estad�siticas";
$MsgAdminStatsDbEmpty = "La Base de Datos de las estad�sticas est� vac�a";
$MsgAdminStatsDbNoEmpty = "Las estad�sticas no est�n vac�as";
$MsgAdminStatsNote = "Si desea reiniciar las est�disticas est� en completa libertad, presione este bot�n para hacerlo. Sin embargo tenga en cuenta que toda informaci�n ser� borrada.";

// Gallery Browser Pages
$MsgNext = "Pr�ximo";
$MsgPrevious = "Anterior";
$MsgBackCatMain = "Ir a la p�gina principal de Categor�as";
$MsgNoCardsinDB = "Lo sentimos no existen tarjetas en la base de datos.";
$MsgInvalidePageNumber = "Has indicado un n�mero de p�gina errado";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId = "ID";
$MsgAdminControlCatName = "Nombre de la categor�a";
$MsgAdminGalleryControlTitle = "Control de la Galer�a";
$MsgAdminLinkBrowser = "Visualizar";
$MsgAdminLinkEdit = "Editar";
$MsgAdminLinkDelete = "Borrar";

// MENU
$MsgMusic = "M�sica";
$MsgPattern = "Textura";
$MsgMain = "Principal";
$MsgGallery = "Galer�a";
$MsgStamp = "Estampillas";
$MsgStats = "Estad�sticas";
$MsgAdminBrowser = "Browser";
$MsgPHPInfo = "Informaci�n de PHP";
$MsgCategories = "Categor�as";
$MsgCategory = "Categor�a";
$MsgPostcards = "Tarjetas Virtuales";

// Back Link Messages
$MsgBack = "Atr�s";
$MsgBackButton = "Ir a la p�gina anterior";
$MsgBacktoSection = "Ir a la secci�n anterior";

// File Upload
$MsgUploadYourOwnFileTitle = "Utiliza tu propia im�gen";
$MsgUploadYourOwnFileInfo = "Crea tu tarjeta usando tu imagen personal";
$MsgErrorFileExtension = "Ese tipo de extensi�n no est� permitida. Debe ser .gif, .jpeg, .jpg o .swf todas en min�sculas";
$MsgFileBiggerThan = "Ese achivo es muy grande:"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed = "El tama�o m�ximo por archivo es:"; // Fhe max size of file is XX Kbytes
$MsgFileAllowed = "You can upload your own image(.gif, .jpg) or flash animation(.swf) file to create a custom postcard. Select your file and click on the buttom.";
$MsgFileUploadNotAllowed = "Lo sentimos la opci�n de enviar imag�nes a este website ha sido deshabilitado.";
$MsgFileSend = "Enviar Archivo";
$MsgFileSelect = "Selecciona tu archivo";
$MsgFileUseFile = "Crear tarjeta";
// added v2.4

$MsgSLog = 'Service Log';
$MsgAdminEntries = 'registries';
$MsgAdminLogRestart = 'Restart Service Log';
$MsgAdminLogNote = 'If you like to restart/clean the service log, you�re free to do so by pushing this button. Consider however that all your current informations are deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.';
$MsgAdminLogRname = 'Recip Name';
$MsgAdminLogRemail = 'Recip Email';
$MsgAdminLogSname = 'Sender Name';
$MsgAdminLogSemail = 'Sender Email';
$MsgAdminLogSip = 'Sender IP';
$MsgAdminLogDate = 'Date';
$MsgAdminLogSentDate = 'Sent/To Send date';
$MsgAdminLogEcard = 'Ecard';


?>