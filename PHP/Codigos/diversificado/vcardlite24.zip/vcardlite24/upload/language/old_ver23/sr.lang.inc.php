<?php
/*************************************************************************
      language      : serbian
      file          : sr.lang.inc.php
      begin         : 2001-09-10
      translator    : Ljuba Rankovic
                      ljuba_r@ptt.yu
      charset       : ISO-8859-2
*************************************************************************/
$charset			= 'ISO-8859-2';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect		= "Trenutno se ne mogu povezati s bazom podataka!";
$MsgUnableLocateDB		= "Trenutno ne mogu pronaci trazene podatke!";
$MsgErrorPerformingQuery	= "Trenutno ne mogu pretrazivati bazu";

// Create, Preview and View Page
$MsgImage			= "Slika";
$MsgYourTitle			= "Naslov";
$MsgMessage			= "Poruka";
$MsgFont			= "Font";
$MsgNoFontFace			= "Bez fonta";
$MsgFontSizeSmall		= "Mala velicina slova";
$MsgFontSizeMedium		= "Srednja velicina slova";
$MsgFontSizeLarge		= "Krupna slova";
$MsgFontSizeXLarge		= "JAKO krupna slova!";
$MsgFontColorBlack		= "Crna boja";
$MsgFontColorWhite		= "Bela boja";
$MsgSignature			= "Potpis";
$MsgRecpName			= "Primalac";
$MsgRecpEmail			= "Primaocev e-mail";
$MsgAddRecp			= "Dodaj primaoca";
$MsgPlay			= "PLAY";
$MsgYourName			= "Vase ime";
$MsgYourEmail			= "Vas e-mail";
$MsgChooseLayout		= "Izaberite podlogu za razglednicu";
$MsgChooseDate			= "Kog datuma zelite da razglednica bude poslata";
$MsgDateFormat			= "Izberite danasnji dan - oblika datuma je DD/MM/GGGG.";
$MsgChooseStamp			= "Izberite marku";
$MsgPostColor			= "Boja pozadine";
$MsgPageBackground		= "Tapeta";
$MsgNone			= "Nista";
$MsgMusic			= "Muzika";
$MsgPreviewButton		= "Pregled pre slanja";
$MsgNotify			= "Obavesti me e-mailom kad primalac preuzme razglednicu";
$MsgYes				= "Da";
$MsgNo				= "Ne";
$MsgNoFlash			= "Potreban vam je Flash modul da biste videli ovu razglednicu.";
$MsgClickHereToGet		= "Mozete ga naci ovde!";
$MsgHelp			= "Pomoc!";
$MsgCloseWindow			= "Zatvori prozor";
$MsgPrintable                   = "Verzija za stampu";

// Error Messages
$MsgActiveJS			= "Aktivirajte javascript!";
$MsgErrorMessage		= "Pismo mora sadrzati poruku.";
$MsgErrorRecpName		= "Morate uneti ime primaoca.";
$MsgErrorRecpEmail		= "Morate uneti e-mail primaoca.";
$MsgErrorRecpEmail2		= "<B>E-mail</B> primaoca je netacan.";
$MsgErrorSenderName		= "Morate uneti svoje ime .";
$MsgErrorSenderEmail		= "Morate uneti vas e-mail";
$MsgErrorSenderEmail2		= "Vas <B>e-mail</B> je netacan.";
$MsgErrorNotFoundTxt		= "Nazalost, nijedna razglednica ne odgovara broju vase razglednice. Uneli ste pogresan ID razglednice, ili je vasa  razglednica prestara te je izbrisana sa sistema. Jebiga.";

$MsgBackEditButton		= "Nazad na pravljenje razglednice";
$MsgSendButton			= "POSALJI!";

$MsgSendTo			= "Posaljite razglednicu ";
$MsgClickHere			= "Kliknite ovde.";
$MsgAvoidDuplicat		= "Da bi ste izbegli dupliranje slanja, kliknite samo jednom!";

// Info Windows
$MsgWinEmoticons		= "Smajliji";
$MsgWinEmoticonsNote		= "Sva slova su velika (O i P)!";
$MsgWinEmoticonsNoteFotter	= "<B>Ako</B> NE ZELITE upotrebiti smajlije nego proste karaktere, ne smete crtati nos.";
$MsgWinBackground		= "Slika tapete";
$MsgWinStamp			= "Slika markice";
$MsgWinColors			= "Boje";
$MsgWinMusic			= "Muzika";
$MsgWinMusicNote		= "Izberite neku opciju.";
$MsgWinNotify			= "Da li zelite da vas e-mailom obavestimo kad primalac pogleda razglednicu?";
$MsgWinFonts			= "Fontovi";
$MsgWinFontsNote		= "Ako zelite da koristite ovu opciju, <FONT COLOR=red>imajte na umu</FONT> da nemaju svi instalirane ove fontove, pa ce im se u tom, slucaju tekst prikazati u (na primer) Timesu, Arialu ili Helvetici.";
$MsgWinName			= "Ime";
$MsgWinSample			= "Primer";
$MsgWinSampleString		= "abvgddjezzijklljmnnjoprstcufhccdzs";

// Message in confirmation page
$MsgSendAnotherCard		= "Posalji jos jednu e-razglednicu";

// Advanced Send
$MsgNPostSent			= "razglednica poslatih u ovom trenutku.";

// Admin Page
$MsgAdminPage			= "Kontrolna ploca";
$MsgAdminCardControlTitle	= "Kontrola razglednica";
$MsgAdminCardControlNote	= "Ova opcija ce izbrisati razglednice koje su starije od XX dana.";
$MsgAdminDay			= "Dana";
$MsgAdminDelOption1		= "Samo razglednice koje su izabrane";
$MsgAdminDelOption2		= "Samo razglednice koje NISU bile izbrane";
$MsgAdminDeleteButton		= "Izbrisi razglednice";
$MsgAdminDeletedCards		= "Razglednice su izbrisane iz baze.";

$MsgAdminWarning		= "Upozorenje!";
$MsgAdminWarning2		= "Ova opcija izbrisace sve razglednice koje su ";
$MsgAdminWarningReaded		= "bile procitane";
$MsgAdminWarningNotReaded	= "nisu bile procitane";
$MsgAdminWarning3		= "a pored toga su i ";
$MsgAdminWarning4		= "dana stare.";
$MsgAdminWarning5		= "Razglednice ce biti izbrisane po kriterijumima koje ste izabrali. Sigurni ste da zelite da nastavite?";
$MsgAdminWarningButtonYes	= "Da, siguran sam!";
$MsgAdminWarningButtonNo	= "Ne, prekini!";
$MsgAdminWarningNoCardDelete	= "Nijedna razglednica nece biti izbrisana. Unesite druge kriterijume.";

$MsgAdminPatternControlTitle	= "Nadzor patterna";
$MsgAdminMusicControlTitle	= "Nadzor muzike";
$MsgAdminStampControlTitle	= "Nadzor markica";
$MsgAdminIncluded		= "DODAT";
$MsgAdminNoIncluded		= "NIJE DODAT";
$MsgAdminDeleted		= "IZBRISANA";
$MsgAdminNoDeleted		= "NIJE IZBRISANA";
$MsgAdminFormFieldEmpty		= "polje je prazno. Vrnite se nazaj in poiskusite ponovno!";

$MsgAdminModified		= "PROMENJENO";
$MsgAdminNoModified		= "NIJE PROMENJENO";

$MsgAdminInclude		= "Dodaj";
$MsgAdminDelete			= "Izbrisi";
$MsgAdminEdit			= "Uredi";
$MsgAdminModify			= "Promeni";

$MsgAdminControlMusicFile	= "Muzicka datoteka";
$MsgAdminControlMusicName	= "Ime pesme";
$MsgAdminControlMusicAuthor	= "Autor pesme";
$MsgAdminControlMusicGenre	= "Zanr pesme";

$MsgAdminControlPatternFile	= "Datoteka uzoraka";
$MsgAdminControlPatternName	= "Ime uzorka";
$MsgAdminControlStampFile	= "Datoteka markica";
$MsgAdminControlStampName	= "Ime markice";

$MsgAdminControlPostImgFile	= "Datoteka razglednica";
$MsgAdminControlPostThmFile	= "Datoteka umanjenih slika";
$MsgAdminControlPostTemplate	= "Ime templejta";

$MsgAdminPostcardControlTitle	= "Nadzor razglednice";
$MsgAdminCategoryControlTitle	= "Nadzor kategorija";

$MsgAdminExtraInfoTitle		= "Dodatne informacije";

$MsgAdminNote			= "Poruka";
$MsgAdminNoteMust		= "Datoteka mora biti uploadovana na ";

// Extra Info:
$MsgvCardLiteCommunity		= "vCard Lite komuna";
$MsgYourVersion			= "Vasa verzija";
$MsgAvaibaleVersion		= "Zadnja verzija";

// Statistic Page
$MsgAdminCardStatTitle		= "Statistika";
$MsgAdminControlImageFile 	= "Slikovna datoteka";
$MsgAdminTemplateFile 		= "Datoteka templejta";
$MsgSeeYourStat			= "Da vidite statistiku";
$MsgPosition 			= "Polozaj";
$MsgHits			= "Upotrebljena";
$MsgTop 			= "Najpopularnijih ";

$MsgAdminStatsRestart		= "Restuj statistiku";
$MsgAdminStatsDbEmpty		= "Statisticki podaci su prazni";
$MsgAdminStatsDbNoEmpty		= "Statisticki podaci nisu prazni";
$MsgAdminStatsNote		= "If you like to restart the Statistics you're free to do so by pushing this button. Consider however that all your current statistics information is deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.";

// Gallery Browser Pages
$MsgNext			= "Sledeci";
$MsgPrevious			= "Prethodni";
$MsgBackCatMain			= "Nazad na osnovnu stranu kategorije";

$MsgNoCardsinDB			= "Na zalost nema razglednica u bazi. Razglednice mozete poslati sledeci link <b>galerija</b> sa glavne strane prezentacije Revije KOLUBARA.";
$MsgInvalidePageNumber		= "Uneli ste pogresan broj strane";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Ime kategorije";
$MsgAdminGalleryControlTitle	= "Nadzor galerije";

$MsgAdminLinkBrowser		= "pregledaj";
$MsgAdminLinkEdit		= "uredi";
$MsgAdminLinkDelete		= "izbrisi";

// MENU
$MsgMusic			= "Muzika";
$MsgPattern			= "Uzorak";
$MsgMain			= "Osnove";
$MsgGallery			= "Galerija";
$MsgStamp			= "Marka";
$MsgStats			= "Statistike";
$MsgAdminBrowser		= "Pregled";
$MsgPHPInfo			= "Informacije o PHP";

$MsgCategories			= "Kategorije";
$MsgCategory			= "Kategorija";
$MsgPostcards			= "Razglednica";

// Back Link Messages
$MsgBack			= "Nazad";
$MsgBackButton			= "Nazad na prethodnu stranu";
$MsgBacktoSection		= "Nazaj na prethodnu sekciju";

// File Upload
$MsgUploadYourOwnFileTitle	= "Iskoristi svoju sliku";
$MsgUploadYourOwnFileInfo	= "Napravi razglednicu koristeci svoju sliku";
$MsgErrorFileExtension		= "Ovaj tip fajla nije podrzan. Mora biti ..gif, .jpeg, .jpg ili .swf, sve napisano malim slovima!";
$MsgFileBiggerThan		= "Fajl je preveliki"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed		= "Najveca dozvoljena velicina datoteke za kopiranje (upload) je "; // Fhe max size of file is XX Kbytes
$MsgFileAllowed			= "Mozete napraviti nove razglednice ako prekopirate (upload) vase slike (.gif, .jpg) ili animacije tipa flash (.swf). Izberite vasu datoteku i kliknite na dugme.";
$MsgFileUploadNotAllowed	= "Na zalost ovaj sajt ne podrzava upload fajlova.";
$MsgFileSend			= "Posalji datoteku!";
$MsgFileSelect			= "Izberite datoteku";
$MsgFileUseFile			= "Napravi razglednicu";

// added v2.4

$MsgSLog = 'Service Log';
$MsgAdminEntries = 'registries';
$MsgAdminLogRestart = 'Restart Service Log';
$MsgAdminLogNote = 'If you like to restart/clean the service log, you�re free to do so by pushing this button. Consider however that all your current informations are deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.';
$MsgAdminLogRname = 'Recip Name';
$MsgAdminLogRemail = 'Recip Email';
$MsgAdminLogSname = 'Sender Name';
$MsgAdminLogSemail = 'Sender Email';
$MsgAdminLogSip = 'Sender IP';
$MsgAdminLogDate = 'Date';
$MsgAdminLogSentDate = 'Sent/To Send date';
$MsgAdminLogEcard = 'Ecard';


?>
