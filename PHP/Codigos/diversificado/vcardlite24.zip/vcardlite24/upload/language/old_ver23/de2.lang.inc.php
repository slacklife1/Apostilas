<?
/*************************************************************************
      language      : german
      file          : de.lang.inc.php
      last upadte   : 2001-03-04
      translator    : Peter Hoefer / Forrest
      email         : forrest@hosting.as
      home          : http://www.hosting.as/ww

         new version by: Uwe Schiewe
         updated:      : 2002-04-23
         email         : schiewe@T-Motion.de
         home          : http://www.t-motion.de 
*************************************************************************/
$charset			='iso-8859-1';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect		= "Die Datenbank kann momentan nicht erreicht werden!";
$MsgUnableLocateDB		= "Die Datenbank kann momentan nicht gefunden werden!";
$MsgErrorPerformingQuery	= "Datenbankfehler";

// Create, Preview and View Page
$MsgImage			= "Bild";
$MsgYourTitle			= "�berschrift";
$MsgMessage			= "Text";
$MsgFont			= "Schriftfarbe";
$MsgNoFontFace			= "Standard";
$MsgFontSizeSmall		= "Klein";
$MsgFontSizeMedium		= "Mittel";
$MsgFontSizeLarge		= "Gross";
$MsgFontSizeXLarge		= "Extragross";
$MsgFontColorBlack		= "Schwarz";
$MsgFontColorWhite		= "Weiss";
$MsgSignature			= "Unterschrift";
$MsgRecpName			= "Empf�nger-Name";
$MsgRecpEmail			= "Empf�nger-EMail";
$MsgAddRecp			= "Empf�nger hinzuf�gen";
$MsgPlay			= "PLAY";
$MsgYourName			= "Dein Name";
$MsgYourEmail			= "Deine EMail";
$MsgChooseLayout		= "W�hle ein Layout";
$MsgChooseDate			= "Versand-Datum";
$MsgDateFormat			= "W�hle das aktuelle Datum um die Karte sofort zu senden.";
$MsgChooseStamp			= "Briefmarke ausw�hlen";
$MsgPostColor			= "Hintergrundfarbe";
$MsgPageBackground		= "Hintergrundbild";
$MsgNone			= "Keine";
$MsgMusic			= "Musik";
$MsgPreviewButton		= "Vorschau";
$MsgNotify			= "M�chtest Du eine EMail-Benachrichtigung, wenn die Karte gelesen wird?";
$MsgYes				= "Ja";
$MsgNo				= "Nein";
$MsgNoFlash			= "Du ben�tigst das Flash-Player Plug-In um die Flash-Version der Postkarte zu sehen.";
$MsgClickHereToGet		= "Den Player gibt es hier!";
$MsgHelp			= "Hilfe!";
$MsgCloseWindow			= "Fenster schliessen";
$MsgPrintable                   = "Druckbare Version";

// Error Messages
$MsgActiveJS			= "Bitte Javascript aktivieren!";
$MsgErrorMessage		= "Du mu�t eine Nachricht in die Postkarte schreiben.";
$MsgErrorRecpName		= "Du mu�t den Empf�nger-Namen angeben.";
$MsgErrorRecpEmail		= "Du mu�t die EMail-Adresse des Empf�ngers angeben.";
$MsgErrorRecpEmail2		= "Empf�nger <B>E-Mail-Adresse</B> ist fehlerhaft.";
$MsgErrorSenderName		= "Du mu�t Deinen Namen eingeben.";
$MsgErrorSenderEmail		= "Du mu�t deine EMail-Adresse angeben.";
$MsgErrorSenderEmail2		= "Die von dir eingegebene <B>EMail-Adresse</B> ist fehlerhaft.";
$MsgErrorNotFoundTxt		= "Es ist keine Postkarte unter dieser Nummer gespeichert!<br>Bitte �berpr�f die von dir angegebene Postkarten-Nummer.<br>Sollte die Karte �lter als 14 Tage sein, so wurde Sie automatisch vom System gel�scht!";

$MsgBackEditButton		= "Zur�ck zum Editieren";
$MsgSendButton			= "Postkarte versenden!";

$MsgSendTo			= "Postkarte versenden an";
$MsgClickHere			= "Hier klicken";
$MsgAvoidDuplicat		= "Nur einmal klicken!";

// Info Windows
$MsgWinEmoticons		= "Emoticons";
$MsgWinEmoticonsNote		= "Alle Zeichen als Gro�buchstaben  (O and P)!";
$MsgWinEmoticonsNoteFotter	= "<B>Wenn</B> Du KEINE Grafikdarstaltung m�chtest, ohne auf die Original-Emoticons zu verzichten, mu�t Du die Nase weglassen. <B><FONT COLOR=red>-</FONT></B>  z.B. :<FONT COLOR=red>-</FONT>) --> :)";
$MsgWinBackground		= "Hintergrund";
$MsgWinStamp			= "Briefmarke";
$MsgWinColors			= "Farben";
$MsgWinMusic			= "Musik";
$MsgWinMusicNote		= "W�hle eine Option";
$MsgWinNotify			= "Du bekommst eine Best�tigung,<BR>sobald der Empf�nger die Karte<BR>gelesen hat!";
$MsgWinFonts			= "Schrift";
$MsgWinFontsNote		= "Wenn Du diese Option nutzen m�chtest, <FONT COLOR=red>denke bitte daran</FONT>, da� nicht jeder die gleichen Zeichens�tze auf seinem Computer hat. F�r den Empf�nger sieht die Karte dann anders aus.";
$MsgWinName			= "Name";
$MsgWinSample			= "Beispiel";
$MsgWinSampleString		= "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard		= "Sende eine weitere virtuelle Postkarte";

// Advanced Send
$MsgNPostSent			= "Postkarte wurde soeben versendet.";

// Admin Page
$MsgAdminPage			= "Control-Panel";
$MsgAdminCardControlTitle	= "Postkarten-Kontrolle";
$MsgAdminCardControlNote	= "Hier kannst Du alle Karten l�schen, die �lter als XX Tage sind.";
$MsgAdminDay			= "Tage";
$MsgAdminDelOption1		= "Nur Karten, die bereits abgerufen wurden.";
$MsgAdminDelOption2		= "Nur Karten, die noch nicht abgerufen wurden.";
$MsgAdminDeleteButton		= "Karten l�schen";
$MsgAdminDeletedCards		= "Die von dir ausgew�hlten Karten wurden gel�scht!";

$MsgAdminWarning		= "Warnung!";
$MsgAdminWarning2		= "Diese Option l�sche alle Postkarten in deiner Datenbank welche";
$MsgAdminWarningReaded		= "gelesen wurden";
$MsgAdminWarningNotReaded	= "nicht gelesen wurden";
$MsgAdminWarning3		= "und";
$MsgAdminWarning4		= "Tage alt sind.";
$MsgAdminWarning5		= "Die Karten werden aufgrund Deiner Auswahl gel�scht. M�chtest Du die Karten l�schen?";
$MsgAdminWarningButtonYes	= "Ja, ich bin mir sicher!";
$MsgAdminWarningButtonNo	= "Nein, auf keinen Fall!";
$MsgAdminWarningNoCardDelete	= "Aufgrund Deiner Auswahlkriterien wurden keine Karten gefunden. Geh zur�ck und w�hle andere Kriterien.";

$MsgAdminPatternControlTitle	= "Einstellungen : Hintergrund";
$MsgAdminMusicControlTitle	= "Einstellungen : Hintergrund-Musik";
$MsgAdminStampControlTitle	= "Einstellungen : Briefmarken";
$MsgAdminIncluded		= "Eintrag hinzugef�gt";
$MsgAdminNoIncluded		= "Eintrag nicht hinzugef�gt";
$MsgAdminDeleted		= "Eintrag gel�scht";
$MsgAdminNoDeleted		= "Eintrag nicht gel�scht";
$MsgAdminFormFieldEmpty		= "Eingabefeld ist leer, geh zur�ck und versuch es noch einmal!";

$MsgAdminModified		= "Eintrag ge�ndert";
$MsgAdminNoModified		= "Eintrag nicht ge�ndert.";

$MsgAdminInclude		= "Hinzuf�gen"; 
$MsgAdminDelete			= "L�schen"; 
$MsgAdminEdit			= "Editieren";
$MsgAdminModify			= "�ndern";

$MsgAdminControlMusicFile	= "Musik Datei";
$MsgAdminControlMusicName	= "Musik Titel";
$MsgAdminControlMusicAuthor	= "Musik Autor";
$MsgAdminControlMusicGenre	= "Musik Genre";

$MsgAdminControlPatternFile	= "Hintergrund Datei";
$MsgAdminControlPatternName	= "Hintergrund Name";
$MsgAdminControlStampFile	= "Briefmarke Datei";
$MsgAdminControlStampName	= "Briefmarke Name";

$MsgAdminControlPostImgFile	= "Bilddatei";
$MsgAdminControlPostThmFile	= "Vorschau-Bilddatei";
$MsgAdminControlPostTemplate	= "Template Name";

$MsgAdminPostcardControlTitle	= "Postkarten Einstellungen";
$MsgAdminCategoryControlTitle	= "Einstellungen : Kategorien";

$MsgAdminExtraInfoTitle		= "Extra Info";

$MsgAdminNote			= "Hinweis";
$MsgAdminNoteMust		= "Dieses File mu�t Du in folgendes Verzeichnis kopieren:";

// Extra Info:
$MsgvCardLiteCommunity		= "vCard Lite Community";
$MsgYourVersion			= "Deine Version";
$MsgAvaibaleVersion		= "Verf�gbare Version";

// Statistic Page
$MsgAdminCardStatTitle		= "Statistik";
$MsgAdminControlImageFile 	= "Bilddatei";
$MsgAdminTemplateFile 		= "Template Datei";
$MsgSeeYourStat			= "Postkarten-Service Statistik anzeigen";
$MsgPosition 			= "Position";
$MsgHits			= "Zugriffe";
$MsgTop 			= "Top ";

$MsgAdminStatsRestart		= "Statistik neu Starten";
$MsgAdminStatsDbEmpty		= "Statistik Datenbank ist LEER!";
$MsgAdminStatsDbNoEmpty		= "Statistik Datenbank ist N�CHT LEER!";
$MsgAdminStatsNote		= "!!Wenn Du die Statistik neu startest werden alle bisherigen Statistik-Daten unwiederruflich gel�scht!!.";

// Gallery Browser Pages
$MsgNext			= "N�chste";
$MsgPrevious			= "Zur�ck";
$MsgBackCatMain			= "Zur�ck zur Kategorieauswahl";

$MsgNoCardsinDB			= "Es sind keine Karten in der Datenbank!";
$MsgInvalidePageNumber		= "Du hast eine falsche Seiten-Nummer angegeben";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Kategorie Name";
$MsgAdminGalleryControlTitle	= "Galerie-Einstellungen";

$MsgAdminLinkBrowser		= "Browser";
$MsgAdminLinkEdit		= "Editieren";
$MsgAdminLinkDelete		= "L�schen";

// MENU
$MsgMusic			= "Musik";
$MsgPattern			= "Hintergrund";
$MsgMain			= "Main";
$MsgGallery			= "Galerie";
$MsgStamp			= "Briefmarke";
$MsgStats			= "Statistik";
$MsgAdminBrowser		= "Browser";
$MsgPHPInfo			= "PHP Info";

$MsgCategories			= "Kategorieauswahl";
$MsgCategory			= "Kategorie";
$MsgPostcards			= "Postkarten";

// Back Link Messages
$MsgBack			= "Zur�ck";
$MsgBackButton			= "Zur�ck zur vorherigen Seite";
$MsgBacktoSection		= "Zur�ck zur vorherigen Sektion.";

// File Upload
$MsgUploadYourOwnFileTitle	= "Benutze Dein eigenes Bild";
$MsgUploadYourOwnFileInfo	= "Erstelle eine Postkarte mit Deinem eigenen Bild";
$MsgErrorFileExtension		= "Datei-Typ nicht erlaubt. Es mu� eine .gif, .jpeg, .jpg or .swf-Datei sein!";
$MsgFileBiggerThan		= "Datei ist gr��er als"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed		= "Die maximal erlaubte Dateigr��e ist "; // Fhe max size of file is XX Kbytes
$MsgFileAllowed			= "Du kannst Dein eigenes Bild (.gif, .jpg) oder eine Flash-Animation(.swf) hochladen, um eine Postkarte zu erstellen. W�hle die Datei aus und klick auf den Button.";
$MsgFileUploadNotAllowed	= "Datei Upload wurde deaktiviert. Sorry.";
$MsgFileSend			= "Sende Datei!";
$MsgFileSelect			= "Datei ausw�hlen";
$MsgFileUseFile			= "Erstelle Postkarte";
// added v2.4

$MsgSLog = 'Service Log';
$MsgAdminEntries = 'registries';
$MsgAdminLogRestart = 'Restart Service Log';
$MsgAdminLogNote = 'If you like to restart/clean the service log, you�re free to do so by pushing this button. Consider however that all your current informations are deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.';
$MsgAdminLogRname = 'Recip Name';
$MsgAdminLogRemail = 'Recip Email';
$MsgAdminLogSname = 'Sender Name';
$MsgAdminLogSemail = 'Sender Email';
$MsgAdminLogSip = 'Sender IP';
$MsgAdminLogDate = 'Date';
$MsgAdminLogSentDate = 'Sent/To Send date';
$MsgAdminLogEcard = 'Ecard';


?>