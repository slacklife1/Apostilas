<?php
/*************************************************************************
      language      : italian
      file          : it.lang.inc.php
      begin         : 2001-02-15
      translator    : Angelo Gelmi
      home          : http://www.web3king.com
*************************************************************************/
$charset			='ISO-8859-1';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect                = "Non sono in grado si connettermi al server database in questo momento...!";
$MsgUnableLocateDB               = "Non sono in grado di reperire il database in questo momento!";
$MsgErrorPerformingQuery         = "Errore eseguendo una query";

// Create, Preview and View Page
$MsgImage                        = "Immagine";
$MsgYourTitle                    = "Il tuo titolo";
$MsgMessage                      = "Messaggio";
$MsgFont                         = "Font";
$MsgNoFontFace                   = "Nessun font";
$MsgFontSizeSmall                = "Piccolo";
$MsgFontSizeMedium               = "Medio";
$MsgFontSizeLarge                = "Grande";
$MsgFontSizeXLarge               = "X-Large";
$MsgFontColorBlack               = "Nero";
$MsgFontColorWhite               = "Bianco";
$MsgSignature                    = "Firma";
$MsgRecpName                     = "Nome del ricevente";
$MsgRecpEmail                    = "Email del ricevente";
$MsgAddRecp                      = "Aggiungi destinatari";
$MsgPlay                         = "PLAY";
$MsgYourName                     = "Il tuo nome";
$MsgYourEmail                    = "La tua email";
$MsgChooseLayout                 = "Scegli un Layout per la cartolina";
$MsgChooseDate                   = "Data per mandare la cartolina?";
$MsgDateFormat                   = "Scegli il giorno corrente (il formato della data � DD/MM/YYYY) per spedire la tua cartolina adesso.";
$MsgChooseStamp                  = "Scegli francobollo";
$MsgPostColor                    = "Colore di sfondo della cartolina";
$MsgPageBackground               = "Wallpaper";
$MsgNone                         = "Nome";
$MsgMusic                        = "Musica";
$MsgPreviewButton                = "Anteprima pre-spedizione";
$MsgNotify                       = "Notificami per e-mail quando il destinatario ha letto il messaggio. ";
$MsgYes                          = "Si";
$MsgNo                           = "No";
$MsgNoFlash                      = "Hai bisogno del plug-in player per vedere per vedere la versione flash della cartolina. ";
$MsgClickHereToGet               = "Clicca qui per prenderlo!";
$MsgHelp                         = "Aiuto!";
$MsgCloseWindow                  = "Chiudi finestra";
$MsgPrintable                    = "Versione stampabile";

// Error Messages
$MsgActiveJS                     = "Per favore attiva il supporto javascript!";
$MsgErrorMessage                 = "Devi scrivere un messaggio per la tua cartolina.";
$MsgErrorRecpName                = "Devi inserire il nome del destinatario.";
$MsgErrorRecpEmail               = "Devi inserire l'indirizzo e-mail del destinatario.";
$MsgErrorRecpEmail2              = "<B>L'indirizzo e-mail</B> del destinatario non � valido.";
$MsgErrorSenderName              = "Devi inserire il tuo nome.";
$MsgErrorSenderEmail             = "Devi inserire il tuo indirizzo e-mail.";
$MsgErrorSenderEmail2            = "Il tuo <B>indirizzo e-mail</B> non � valido.";
$MsgErrorNotFoundTxt             = "Spiacenti ma nessuna cartolina corrisponde con il numero specificato. L'ID cartolina � stato specificato male, o la tua cartolina potrebbe essere troppo vecchia ed � stata cancellata dal sistema.";
$MsgBackEditButton               = "Ritorna ad editare";
$MsgSendButton                   = "Segli un'altra cartolina!";

$MsgSendTo                       = "Manda una cartolina a:";
$MsgClickHere                    = "Clicca qui";
$MsgAvoidDuplicat                = "Clicca una sola volta per evitare duplicati!";

// Info Windows
$MsgWinEmoticons                 = "Emoticons";
$MsgWinEmoticonsNote             = "Tutti i caratteri sono maiuscoli (O and P)!";
$MsgWinEmoticonsNoteFotter       = "<B>Se</B> NON vuoi che la grafica appaia, ma vuoi usarele emoticons originali non verr� visualizzato il naso.";
$MsgWinBackground                = "Immagine di sfondo";
$MsgWinStamp                     = "Immagine del francobollo";
$MsgWinColors                    = "Colori";
$MsgWinMusic                     = "Musica";
$MsgWinMusicNote                 = "Scegli un opzione.";
$MsgWinNotify                    = "Vuoi ricevere un'email di notifica quando la tua cartolina verr� letta da ricevente?";
$MsgWinFonts                     = "Carattere";
$MsgWinFontsNote                 = "Se usi questa opzione, <FONT COLOR=red>considera</FONT> che non tutti possono avere questo tipo di carattere installato sul loro computer. Se no loro vedranno il carattere principale, solitamente Times e Arial oppure Helvetica.";
$MsgWinName                      = "Nome";
$MsgWinSample                    = "Campione";
$MsgWinSampleString              = "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard              = "Spedisci un'altra cartolina virtuale";

// Advanced Send
$MsgNPostSent                    = "Spedisci la cartolina ora.";

// Admin Page
$MsgAdminPage                    = "Controlla pannello";
$MsgAdminCardControlTitle        = "Controlla cartolina";
$MsgAdminCardControlNote         = "Questo servizio cancella le cartoline dopo XX giorni.";
$MsgAdminDay                     = "Giorni";
$MsgAdminDelOption1              = "Solo le cartoline che sono state lette";
$MsgAdminDelOption2              = "Solo le cartoline che NON sono state lette";
$MsgAdminDeleteButton            = "Cancella cartoline";
$MsgAdminDeletedCards            = "Le cartoline sono state cancellate dal database.";

$MsgAdminWarning                 = "Attenzione!";
$MsgAdminWarning2                = "Questa opzione cancellera' tutte le cartoline dal suo database";
$MsgAdminWarningReaded           = "Sono stati letti";
$MsgAdminWarningNotReaded        = "Non sono stati letti";
$MsgAdminWarning3                = "e sono vecchi di";
$MsgAdminWarning4                = "giorni.";
$MsgAdminWarning5                = "Le cartoline verranno cancellate secondo i tuoi criteri di selezione. Sei sicuro di continuare?";
$MsgAdminWarningButtonYes        = "Si, sono sicuro!";
$MsgAdminWarningButtonNo         = "No, fermati!";
$MsgAdminWarningNoCardDelete     = "Non cancellare secondo i criteri di selezione. Torna indietro e seleziona un nuovo criterio.";

$MsgAdminPatternControlTitle     = "Controllo modello";
$MsgAdminMusicControlTitle       = "Controllo musica";
$MsgAdminStampControlTitle       = "Controllo francobollo";
$MsgAdminIncluded                = "Messaggio INSERITO";
$MsgAdminNoIncluded              = "Messaggio NON INSERITO";
$MsgAdminDeleted                 = "Messagggio CANCELLATO";
$MsgAdminNoDeleted               = "Messaggio NON CANCELLATO";
$MsgAdminFormFieldEmpty          = "Il campo DA: � vuoto. Torna indietro e riprova!";

$MsgAdminModified                = "Messaggio MODIFICATO";
$MsgAdminNoModified              = "Messaggio NON MODIFICATO";

$MsgAdminInclude                 = "Aggiungi";
$MsgAdminDelete                  = "Cancella";
$MsgAdminEdit                    = "Edita";
$MsgAdminModify                  = "Modifica";

$MsgAdminControlMusicFile        = "File musicale";
$MsgAdminControlMusicName        = "Nome del brano musicale";
$MsgAdminControlMusicAuthor      = "Nome autore";
$MsgAdminControlMusicGenre       = "Genere musicale";

$MsgAdminControlPatternFile      = "File del modello";
$MsgAdminControlPatternName      = "Nome del modello";
$MsgAdminControlStampFile        = "File del francobollo";
$MsgAdminControlStampName        = "Nome del francobollo";

$MsgAdminControlPostImgFile      = "File della cartolina";
$MsgAdminControlPostThmFile      = "File della miniatura della cartolina";
$MsgAdminControlPostTemplate     = "Nome modello";

$MsgAdminPostcardControlTitle    = "Controllo cartolina";
$MsgAdminCategoryControlTitle    = "Controllo categoria";

$MsgAdminExtraInfoTitle          = "Altre informazioni";

$MsgAdminNote                    = "Note";
$MsgAdminNoteMust                = "Il file deve essere caricato sul server";

// Extra Info:
$MsgvCardLiteCommunity           = "Comunit� Card Lite";
$MsgYourVersion                  = "Tua versione";
$MsgAvaibaleVersion              = "Versione disponibile";

// Statistic Page
$MsgAdminCardStatTitle           = "Statistiche";
$MsgAdminControlImageFile        = "File dell'immagine";
$MsgAdminTemplateFile            = "File modello";
$MsgSeeYourStat                  = "Per vedere il servizio di statistiche della tua cartolina";
$MsgPosition                     = "Posizione";
$MsgHits                         = "Classificche";
$MsgTop                          = "La pi� letta ";

$MsgAdminStatsRestart            = "Riavvia statistiche";
$MsgAdminStatsDbEmpty            = "Il data base delle statistiche � VUOTO";
$MsgAdminStatsDbNoEmpty          = "Il data base delle statistiche NON � VUOTO";
$MsgAdminStatsNote               = "Se vuoi ricominciare le statistiche, sei libero di farlo cliccando questo pulsante. Considera tuttavia che le informazioni sulle statistiche correnti verranno cancellate. Per salvare queste informazioni ti consigliamo di salvarle sul tuo harddisk prima.";

// Gallery Browser Pages
$MsgNext                         = "Seguente";
$MsgPrevious                     = "Precedente";
$MsgBackCatMain                  = "Torna alla pagina principale della categoria";

$MsgNoCardsinDB                  = "Spiacenti, non ha nessuna cartolina nel data base.";
$MsgInvalidePageNumber           = "Hai specificato un numero di pagina non valido";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId            = "ID";
$MsgAdminControlCatName          = "Nome categoria";
$MsgAdminGalleryControlTitle     = "Gestione Gallery";

$MsgAdminLinkBrowser             = "Sfoglia";
$MsgAdminLinkEdit                = "edita";
$MsgAdminLinkDelete              = "Cancella";

// MENU
$MsgMusic                        = "Musica";
$MsgPattern                      = "Modello";
$MsgMain                         = "Principale";
$MsgGallery                      = "Gallery";
$MsgStamp                        = "Francobollo";
$MsgStats                        = "Statistiche";
$MsgAdminBrowser                 = "Sfoglia";
$MsgPHPInfo                      = "PHP info";

$MsgCategories                   = "Categorie";
$MsgCategory                     = "Categoria";
$MsgPostcards                    = "Cartoline";

// Back Link Messages
$MsgBack                         = "Indietro";
$MsgBackButton                   = "Ritorna alla pagina precedente";
$MsgBacktoSection                = "Ritorna alla selezione precedente";

// File Upload
$MsgUploadYourOwnFileTitle       = "Utilizza una tua immagine";
$MsgUploadYourOwnFileInfo        = "Crea una cartolina usando una tua immagine";
$MsgErrorFileExtension           = "Estensione file non valida. Deve essere .gif, .jpeg, .jpg o .swf tutti scritti in minuscolo!";
$MsgFileBiggerThan               = "Il file � pi� grande di"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed           = "La grandezza massima del file da caricare � "; // Fhe max size of file is XX Kbytes
$MsgFileAllowed                  = "Puoi caricare una tua immagine (.gif, .jpg) o un animazione flash (.swf) file per creare una cartolina personalizzata. Selezziona il file e clicca il pulsante.";
$MsgFileUploadNotAllowed         = "Il sistema di caricamento file � disabilitato in questo sito! Spiacenti.";
$MsgFileSend                     = "Spedisci File!";
$MsgFileSelect                   = "Seleziona il tuo file";
$MsgFileUseFile                  = "Crea la cartolina";

// added v2.4

$MsgSLog = 'Service Log';
$MsgAdminEntries = 'registries';
$MsgAdminLogRestart = 'Restart Service Log';
$MsgAdminLogNote = 'If you like to restart/clean the service log, you�re free to do so by pushing this button. Consider however that all your current informations are deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.';
$MsgAdminLogRname = 'Recip Name';
$MsgAdminLogRemail = 'Recip Email';
$MsgAdminLogSname = 'Sender Name';
$MsgAdminLogSemail = 'Sender Email';
$MsgAdminLogSip = 'Sender IP';
$MsgAdminLogDate = 'Date';
$MsgAdminLogSentDate = 'Sent/To Send date';
$MsgAdminLogEcard = 'Ecard';


?>