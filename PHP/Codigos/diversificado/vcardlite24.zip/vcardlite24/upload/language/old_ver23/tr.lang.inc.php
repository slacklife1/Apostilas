<?php
/*************************************************************************
      language      : Turkish
      file          : tr.lang.inc.php
      begin         : 2002-06-20
      translator    : Merih (info@mesir.net)
      home          : http://www.mesir.net
      charset       : windows-1254
*************************************************************************/
$charset			='WINDOWS-1254';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect		= "Unable to connect to the database server at this time!";
$MsgUnableLocateDB		= "Unable to locate the database at this time!";
$MsgErrorPerformingQuery	= "Error performing query";

// Create, Preview and View Page
$MsgImage			= "Resim";
$MsgYourTitle			= "Mesaj Ba�l���";
$MsgMessage			= "Mesaj�n�z";
$MsgFont			= "Font";
$MsgNoFontFace			= "No Font Face";
$MsgFontSizeSmall		= "Small Type";
$MsgFontSizeMedium		= "Medium Type";
$MsgFontSizeLarge		= "Large Type";
$MsgFontSizeXLarge		= "X-Large Type";
$MsgFontColorBlack		= "Black Type";
$MsgFontColorWhite		= "White Type";
$MsgSignature			= "�mzan�z";
$MsgRecpName			= "Al�c�n�n Ad�";
$MsgRecpEmail			= "Al�c�n�n email adresi";
$MsgAddRecp			= "Al�c� Say�s�";
$MsgPlay			= "PLAY";
$MsgYourName			= "Ad�n�z Soyad�n�z";
$MsgYourEmail			= "E-mail adresiniz";
$MsgChooseLayout		= "Kart G�r�n�m�";
$MsgChooseDate			= "G�nderim Tarihi?";
$MsgDateFormat			= "E-Kart�n g�nderim tarihini se�ebilirsiniz GG/AY/YYYY, e-kart bu tarihte g�nderilecektir.";
$MsgChooseStamp			= "Pul Se�iniz";
$MsgPostColor			= "Arkaplan Rengi";
$MsgPageBackground		= "Wallpaper";
$MsgNone			= "YOK";
$MsgMusic			= "M�zik";
$MsgPreviewButton		= "G�ndermeden �nce izleyin";
$MsgNotify			= "E-Kart okundu�u zaman haberdar olmak istiyorum.";
$MsgYes				= "Evet";
$MsgNo				= "Hay�r";
$MsgNoFlash			= "Flash ile haz�rlanm�� e-kart� izlemek i�in Flash player a ihtiyac�n�z var. ";
$MsgClickHereToGet		= "T�klay�n�p �zleyiniz!";
$MsgHelp			= "Yard�m!";
$MsgCloseWindow			= "Pencereyi Kapat";
$MsgPrintable                   = "Yaz�c�da G�r�n�m";

// Error Messages
$MsgActiveJS			= "Javascript aktif olmal�!";
$MsgErrorMessage		= "E-Kart �zerine mesaj�n�z� yazmal�s�n�z.";
$MsgErrorRecpName		= "Al�c� ad�n� girmelisiniz.";
$MsgErrorRecpEmail		= "Al�c� e-mail adresini girmelisiniz.";
$MsgErrorRecpEmail2		= "Al�c�n�n <B>email adresi</B> hatal�.";
$MsgErrorSenderName		= "Ad�n�z� soyad�n�z� girmelisiniz.";
$MsgErrorSenderEmail		= "Email adresinizi girmelisiniz.";
$MsgErrorSenderEmail2		= "Sizin <B>email adresiniz</B> hatal� veya yanl��.";
$MsgErrorNotFoundTxt		= "�z�r dileriz, e-kart numaran�zla e�le�en kart bulunamad�. E-Kart numaran�z hatal� veya �ok eski bir numara oldu�u i�in sistem taraf�ndan silinmi�tir.";

$MsgBackEditButton		= "Geri";
$MsgSendButton			= "G�NDER!";

$MsgSendTo			= "E-Kart� g�ndermek i�in";
$MsgClickHere			= "buraya t�klay�n�z";
$MsgAvoidDuplicat		= "L�tfen bir kere t�klay�n�z!";

// Info Windows
$MsgWinEmoticons		= "Emoticons";
$MsgWinEmoticonsNote		= "T�m karekterler b�y�k harf olmal� (A dan Z ye)!";
$MsgWinEmoticonsNoteFotter	= "<B>if</B> you do NOT want the graphic to appear, but still want to use the original emoticons you will have to exclude the nose.";
$MsgWinBackground		= "Wallpaper Image";
$MsgWinStamp			= "Pul Resimleri";
$MsgWinColors			= "Renkler";
$MsgWinMusic			= "M�zik";
$MsgWinMusicNote		= "Opsiyon Se�iniz.";
$MsgWinNotify			= "Al�c� e-kart�n� izledi�inde e-mail ile bilgilendirilmek istermisiniz?";
$MsgWinFonts			= "Fonts";
$MsgWinFontsNote		= "E�er bu opsiyonu se�erseniz, <FONT COLOR=red>Bu hususlara dikkat ediniz</FONT> t�m al�c�lar se�mi� oldu�unuz fontlar� bilgisayarlar�na y�klememi� olabilirler. E�er bu fontlar yok ise, default fontlar� ile izleyeceklerdir, genellikle Times ve Arial veya Helvetica fontlar� mevcuttur.";
$MsgWinName			= "Ad�";
$MsgWinSample			= "�rnek";
$MsgWinSampleString		= "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard		= "Tekrar Kart G�nder";

// Advanced Send
$MsgNPostSent			= "E-kart g�nderim zaman�.";

// Admin Page
$MsgAdminPage			= "Kontrol Panel";
$MsgAdminCardControlTitle	= "E-Kart Kontrol";
$MsgAdminCardControlNote	= "Bu program XX g�n �nceki g�nderimleri sistemden siler.";
$MsgAdminDay			= "G�n";
$MsgAdminDelOption1		= "Sadece okunmu� olan kartlar";
$MsgAdminDelOption2		= "Sadece okunmam�� olan kartlar";
$MsgAdminDeleteButton		= "Kartlar� Sil";
$MsgAdminDeletedCards		= " e-kart database kay�tlar�ndan silinmi�tir.";

$MsgAdminWarning		= "Dikkat!";
$MsgAdminWarning2		= "Bu opsiyon database �zerindeki kart bilgilerini silecektir Silinecek Kart Tipi :";
$MsgAdminWarningReaded		= "Okunmu� olan kartlar";
$MsgAdminWarningNotReaded	= "Okunmam�� olan kartlar";
$MsgAdminWarning3		= "ve";
$MsgAdminWarning4		= "g�n �nce g�nderilenler.";
$MsgAdminWarning5		= "se�ti�iniz kriterlere g�re kart bilgileri silinecektir. Devam etmek istedi�inizden eminmisiniz?";
$MsgAdminWarningButtonYes	= "Evet, Eminim!";
$MsgAdminWarningButtonNo	= "Hay�r, vazge�tim!";
$MsgAdminWarningNoCardDelete	= "Krtierlerinize uygun e-kart bulunamad�. Tekrar yeni kriterlerinizi belirleyiniz.";

$MsgAdminPatternControlTitle	= "Pattern Kontrol";
$MsgAdminMusicControlTitle	= "M�zik Kontrol";
$MsgAdminStampControlTitle	= "Pul Kontrol";
$MsgAdminIncluded		= "entry INCLUDED";
$MsgAdminNoIncluded		= "entry NOT INCLUDED";
$MsgAdminDeleted		= "entry DELETED";
$MsgAdminNoDeleted		= "entry NOT DELETED";
$MsgAdminFormFieldEmpty		= "form bilgisi bo�. L�tfen tekrar deneyiniz!";

$MsgAdminModified		= "entry MODIFIED";
$MsgAdminNoModified		= "entry NOT MODIFIED";

$MsgAdminInclude		= "Ekle"; 
$MsgAdminDelete			= "S�L"; 
$MsgAdminEdit			= "Edit";
$MsgAdminModify			= "D�zenle";

$MsgAdminControlMusicFile	= "M�zik Dosyas�";
$MsgAdminControlMusicName	= "M�zik Ad�";
$MsgAdminControlMusicAuthor	= "M�zik Bestecisi";
$MsgAdminControlMusicGenre	= "Music Genre";

$MsgAdminControlPatternFile	= "Pattern Dosyas�";
$MsgAdminControlPatternName	= "Pattern Ad�";
$MsgAdminControlStampFile	= "Pul Dosyas�";
$MsgAdminControlStampName	= "Pul Ad�";

$MsgAdminControlPostImgFile	= "G�nderilen Dosya";
$MsgAdminControlPostThmFile	= "G�nderilen Resim";
$MsgAdminControlPostTemplate	= "Template Ad�";

$MsgAdminPostcardControlTitle	= "E-Kart kontrol";
$MsgAdminCategoryControlTitle	= "Kategori Kontrol";

$MsgAdminExtraInfoTitle		= "Extra Bilgi";

$MsgAdminNote			= "Not";
$MsgAdminNoteMust		= "Bu dosya g�sterilen foldera upload edilmelidir :";

// Extra Info:
$MsgvCardLiteCommunity		= "vCard Lite �leti�im";
$MsgYourVersion			= "S�r�m Bilgisi";
$MsgAvaibaleVersion		= "Ge�erli S�r�m";

// Statistic Page
$MsgAdminCardStatTitle		= "�statistik";
$MsgAdminControlImageFile 	= "Resim Dosyas�";
$MsgAdminTemplateFile 		= "Template Dosyas�";
$MsgSeeYourStat			= "E-Kart servisi istatistikleriniz";
$MsgPosition 			= "Pozisyon";
$MsgHits			= "Hit";
$MsgTop 			= "En �ok G�nderilen ";

$MsgAdminStatsRestart		= "�statistikleri �ptal";
$MsgAdminStatsDbEmpty		= "�statistik database i BO�";
$MsgAdminStatsDbNoEmpty		= "�statistik database i DOLU";
$MsgAdminStatsNote		= "�statistik bilgilerinizi iptal etmek istiyorsan�z bunu butona basarak yapabilirsiniz . Sistem taraf�ndan t�m istatistik bilgileri silinecektir. Bu nedenle �ncelikle raporlar� kendi sisteminize yedeklemenizde fayda vard�r.";

// Gallery Browser Pages
$MsgNext			= "�leri";
$MsgPrevious			= "Geri";
$MsgBackCatMain			= "Kategori Ana Sayfas�n�na D�n";

$MsgNoCardsinDB			= "�z�r Dileriz, bu b�l�mde e-kart bulunamad�.";
$MsgInvalidePageNumber		= "Hatal� sayfa numaras� girdiniz";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Kategori Ad�";
$MsgAdminGalleryControlTitle	= "Galeri Kontrol";

$MsgAdminLinkBrowser		= "g�ster";
$MsgAdminLinkEdit		= "d�zenle";
$MsgAdminLinkDelete		= "sil";

// MENU
$MsgMusic			= "M�zik";
$MsgPattern			= "Pattern";
$MsgMain			= "Ana";
$MsgGallery			= "Galeri";
$MsgStamp			= "Pul";
$MsgStats			= "�statistik";
$MsgAdminBrowser		= "Browser";
$MsgPHPInfo			= "PHP Info";

$MsgCategories			= "Kategoriler";
$MsgCategory			= "Category";
$MsgPostcards			= "E-Kart";

// Back Link Messages
$MsgBack			= "Back";
$MsgBackButton			= "�nceki Sayfaya D�n";
$MsgBacktoSection		= "�nceki B�l�me D�n";

// File Upload
$MsgUploadYourOwnFileTitle	= "Kendin Yap Yolla";
$MsgUploadYourOwnFileInfo	= "Kendiniz e-kart haz�rlay�p g�nderebilirsiniz";
$MsgErrorFileExtension		= "File extension not allowed. It must be ..gif, .jpeg, .jpg or .swf all em lowercase!";
$MsgFileBiggerThan		= "File size is bigger than"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed		= "The max size of file allowed to be uploaded is "; // Fhe max size of file is XX Kbytes
$MsgFileAllowed			= "You can upload your own image(.gif, .jpg) or flash animation(.swf) file to create a custom postcard. Select your file and click on the buttom.";
$MsgFileUploadNotAllowed	= "Dosya upload sistemi ge�ici olarak kapat�lm��t�r! �z�r Dileriz.";
$MsgFileSend			= "G�nderilen Dosya!";
$MsgFileSelect			= "Dosyan�z� Se�iniz";
$MsgFileUseFile			= "E-Kart�n�z� yarat�n";

// added v2.4

$MsgSLog = 'Service Log';
$MsgAdminEntries = 'registries';
$MsgAdminLogRestart = 'Restart Service Log';
$MsgAdminLogNote = 'If you like to restart/clean the service log, you�re free to do so by pushing this button. Consider however that all your current informations are deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.';
$MsgAdminLogRname = 'Recip Name';
$MsgAdminLogRemail = 'Recip Email';
$MsgAdminLogSname = 'Sender Name';
$MsgAdminLogSemail = 'Sender Email';
$MsgAdminLogSip = 'Sender IP';
$MsgAdminLogDate = 'Date';
$MsgAdminLogSentDate = 'Sent/To Send date';
$MsgAdminLogEcard = 'Ecard';


?>