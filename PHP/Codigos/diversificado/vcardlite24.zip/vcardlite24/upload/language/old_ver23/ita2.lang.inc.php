<?php
/*************************************************************************
      language      : italian
      file          : ita2.lang.inc.php
      begin         : 2001-02-15
      translator    : Dean (dean@rdcollins.net)
      home          : http://www.rdcollins.net
*************************************************************************/
$charset			='ISO-8859-1';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect		= "Impossibile connettersi al database server in questo momento!";
$MsgUnableLocateDB		= "Impossibile individuare il database in questo momento!";
$MsgErrorPerformingQuery	= "Errore performing query";

// Create, Preview and View Page
$MsgImage			= "Immagine";
$MsgYourTitle			= "Titolo";
$MsgMessage			= "Messaggio";
$MsgFont			= "Carattere";
$MsgNoFontFace			= "Nessun Carattere";
$MsgFontSizeSmall		= "Piccolo";
$MsgFontSizeMedium		= "Medio";
$MsgFontSizeLarge		= "Largo";
$MsgFontSizeXLarge		= "Extra-largo";
$MsgFontColorBlack		= "Nero";
$MsgFontColorWhite		= "Bianco";
$MsgSignature			= "Firma";
$MsgRecpName			= "Nome del Destinatario";
$MsgRecpEmail			= "E-mail del Destinatario";
$MsgAddRecp			= "Aggiungi Destinatari";
$MsgPlay			= "ASCOLTA";
$MsgYourName			= "Il tuo nome";
$MsgYourEmail			= "La tua e-mail";
$MsgChooseLayout		= "Scegli il Layout della cartolina";
$MsgChooseDate			= "Data di spedizione della cartolina?";
$MsgDateFormat			= "Seleziona il giorno di spedizione della cartolina, il formato data � GG/MM/AAAA, .";
$MsgChooseStamp			= "Scegliere il Francobollo";
$MsgPostColor			= "Colore di sfondo della cartolina";
$MsgPageBackground		= "Immagine di Sfondo";
$MsgNone			= "Nessuno";
$MsgMusic			= "Musica";
$MsgPreviewButton		= "Anteprima della cartolina";
$MsgNotify			= "Notifica con e-mail quando il destinatario legge questa cartolina.";
$MsgYes				= "Si";
$MsgNo				= "No";
$MsgNoFlash			= "C'� bisogno del Flash player plug-in per vedere le cartoline in formato Flash. ";
$MsgClickHereToGet		= "Clicca qui per scaricarlo!";
$MsgHelp			= "Aiuto!";
$MsgCloseWindow			= "Chiudi Finestra";
$MsgPrintable                   = "Versione stampabile";

// Error Messages
$MsgActiveJS			= "Prego attiva javascript!";
$MsgErrorMessage		= "Devi scrivere un messaggio per la tua cartolina.";
$MsgErrorRecpName		= "Manca il nome del destinatario.";
$MsgErrorRecpEmail		= "Manca l'indirizzo e-mail del destinatario.";
$MsgErrorRecpEmail2		= "<B>L'indirizzo e-mail</B> del destinatario non � valido.";
$MsgErrorSenderName		= "Manca il tuo nome.";
$MsgErrorSenderEmail		= "Manca il tuo indirizzo e-mail.";
$MsgErrorSenderEmail2		= "Il tuo <B>indirizzo e-mail</B> non � valido.";
$MsgErrorNotFoundTxt		= "Spiacenti, nessuna cartolina � abbinata al vostro identificativo. Potrebbe essere sbagliato il tuo indice di cartolina, oppure la tua cartolina � troppo vecchia ed � stata cancellata dal server.";

$MsgBackEditButton		= "Torna alla creazione";
$MsgSendButton			= "Spedisci!";

$MsgSendTo			= "Spedisci  una cartolina a";
$MsgClickHere			= "clicca qu�";
$MsgAvoidDuplicat		= "Clicca solo una volta per evitare duplicati!";

// Info Windows
$MsgWinEmoticons		= "Emoticons";
$MsgWinEmoticonsNote		= "Tutti i caratteri sono maiuscoli (O e P)!";
$MsgWinEmoticonsNoteFotter	= "<B>Se</B> non vuoi che appaia l'immagine grafica, ma vuoi usare le emoticons originali, devi escludere il naso.";
$MsgWinBackground		= "Immagine di sfondo";
$MsgWinStamp			= "Immagine del francobollo";
$MsgWinColors			= "Colori";
$MsgWinMusic			= "Musica";
$MsgWinMusicNote		= "Scegliere un'opzione.";
$MsgWinNotify			= "Desideri ricevere una e-mail di notifica, quando il destinatario legge la tua cartolina?";
$MsgWinFonts			= "Caratteri";
$MsgWinFontsNote		= "Se usi questa opzione, <FONT COLOR=red>attenzione</FONT> il carattere che scegli dovr� essere installato anche sul computer che riceve. Altrimenti, la cartolina verr� visualizzata con caratteri standard, generalmente Times e Arial o Helvetica.";
$MsgWinName			= "Nome";
$MsgWinSample			= "Esempio";
$MsgWinSampleString		= "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard		= "Spedisci un'altra Cartolina virtuale";

// Advanced Send
$MsgNPostSent			= "Cartolina spedita in questo momento.";

// Admin Page
$MsgAdminPage			= "Pannello di controllo";
$MsgAdminCardControlTitle	= "Pannello di Controllo Cartoline";
$MsgAdminCardControlNote	= "Questa utiliti canceller� le cartoline vecchie di XX giorni.";
$MsgAdminDay			= "Giorni";
$MsgAdminDelOption1		= "Solo le cartoline che sono state viste";
$MsgAdminDelOption2		= "Solo le cartoline che non sono state viste";
$MsgAdminDeleteButton		= "Cancella Cartoline";
$MsgAdminDeletedCards		= "La Cartolina � stata rimossa dal database.";

$MsgAdminWarning		= "Attenzione!";
$MsgAdminWarning2		= "Questa operazione canceller� tutte le cartoline dal database";
$MsgAdminWarningReaded		= "sono state lette";
$MsgAdminWarningNotReaded	= "non sono state lette";
$MsgAdminWarning3		= "e sono";
$MsgAdminWarning4		= "vecchie di giorni.";
$MsgAdminWarning5		= "Le cartoline saranno cancellate in base alle opzioni scelte. Sei sicuro di voler continuare?";
$MsgAdminWarningButtonYes	= "Si, sono sicuro!";
$MsgAdminWarningButtonNo	= "No, annulla!";
$MsgAdminWarningNoCardDelete	= "Nessuna cartolina sar� cancellata in base alle opzioni scelte, torna indietro � ripeti l'operazione";

$MsgAdminPatternControlTitle	= "Pattern Control";
$MsgAdminMusicControlTitle	= "Pannello di controllo musica";
$MsgAdminStampControlTitle	= "Pannello di controllo francobolli";
$MsgAdminIncluded		= "Selezionate INCLUSE";
$MsgAdminNoIncluded		= "Selezionate non INCLUSE";
$MsgAdminDeleted		= "Selezionate CANCELLATE";
$MsgAdminNoDeleted		= "Selezionate non CANCELLATE";
$MsgAdminFormFieldEmpty		= "Il campo � vuoto, torna indietro e prova ancora!";

$MsgAdminModified		= "Selezionate MODIFICATE";
$MsgAdminNoModified		= "Selezionate non MODIFICATE";

$MsgAdminInclude		= "Aggiungi"; 
$MsgAdminDelete			= "Cancella"; 
$MsgAdminEdit			= "Edita";
$MsgAdminModify			= "Modifica";

$MsgAdminControlMusicFile	= "File Musicali";
$MsgAdminControlMusicName	= "Titolo Musica";
$MsgAdminControlMusicAuthor	= "Autore Musica";
$MsgAdminControlMusicGenre	= "Genere Musicale";

$MsgAdminControlPatternFile	= "Files Sfondi";
$MsgAdminControlPatternName	= "Nome Files Sfondi";
$MsgAdminControlStampFile	= "File Francobollo";
$MsgAdminControlStampName	= "Nome Francobollo";

$MsgAdminControlPostImgFile	= "File Cartolina da caricare";
$MsgAdminControlPostThmFile	= "File Miniatura da caricare";
$MsgAdminControlPostTemplate	= "Nome Template";

$MsgAdminPostcardControlTitle	= "Pannello di controllo CARTOLINE";
$MsgAdminCategoryControlTitle	= "Pannello di controllo CATEGORIE";

$MsgAdminExtraInfoTitle		= "Informazioni extra";

$MsgAdminNote			= "Note";
$MsgAdminNoteMust		= "Il file � stato caricato su";

// Extra Info:
$MsgvCardLiteCommunity		= "vCard Lite Community";
$MsgYourVersion			= "La tua versione";
$MsgAvaibaleVersion		= "Versione disponibile";

// Statistic Page
$MsgAdminCardStatTitle		= "Statistiche";
$MsgAdminControlImageFile 	= "Image File";
$MsgAdminTemplateFile 		= "File Template ";
$MsgSeeYourStat			= "Per vedere le statistiche della tua cartolina";
$MsgPosition 			= "Posizione";
$MsgHits			= "Clic";
$MsgTop 			= "Top ";

$MsgAdminStatsRestart		= "Resetta";
$MsgAdminStatsDbEmpty		= "Il Database sulle statistiche � vuoto";
$MsgAdminStatsDbNoEmpty		= "Il Database sulle statistiche non � vuoto";
$MsgAdminStatsNote		= "Per resettare le statistiche clicca sul pulsante Resetta. Premendo questo pulsante vengono cancellate tutte le informazioni sulle statistiche quindi per conservare un'archivio storico prima di resettare salvare una copia del rapporto sul proprio harddisk ..";

// Gallery Browser Pages
$MsgNext			= "Successivo";
$MsgPrevious			= "Precedente";
$MsgBackCatMain			= "Torna all'indice delle categorie";

$MsgNoCardsinDB			= "Spiacenti, non ci sono cartoline nel database.";
$MsgInvalidePageNumber		= "Il numero di pagina specificato non � valido";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Nome Categoria";
$MsgAdminGalleryControlTitle	= "Pannello di Controllo Gallerie";

$MsgAdminLinkBrowser		= "sfoglia";
$MsgAdminLinkEdit		= "modifica";
$MsgAdminLinkDelete		= "cancella";

// MENU
$MsgMusic			= "Musica";
$MsgPattern			= "Immagini di fondo";
$MsgMain			= "Principale";
$MsgGallery			= "Galleria";
$MsgStamp			= "Francobolli";
$MsgStats			= "Statistiche";
$MsgAdminBrowser		= "Sfoglia";
$MsgPHPInfo			= "PHP Info";

$MsgCategories			= "Categorie";
$MsgCategory			= "Categoria";
$MsgPostcards			= "Cartoline";

// Back Link Messages
$MsgBack			= "Indietro";
$MsgBackButton			= "Torna alla pagina precedente";
$MsgBacktoSection		= "Torna alla sezione precedente";

// File Upload
$MsgUploadYourOwnFileTitle	= "Usa una tua immagine";
$MsgUploadYourOwnFileInfo	= "Crea la tua cartolina usando un'immaggine dal tuo pc";
$MsgErrorFileExtension		= "Estensione non permessa. Deve essere .gif, ..jpeg, .jpg oppure .swf tutte lettere minuscole!";
$MsgFileBiggerThan		= "La dimensione del file � maggiore di"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed		= "Il formato massimo permesso per il file da caricare �  "; // Fhe max size of file is XX Kbytes
$MsgFileAllowed			= "Puoi caricare un'immagine dal tuo computer (.gif, ..jpg) o animazione flash (.swf) per creare una Cartolina personalizzata. Seleziona il tuo file e clicca su spedisci file!.";
$MsgFileUploadNotAllowed	= "Il sistema di caricamento del file e disabilitato su questo server! Scusa.";
$MsgFileSend			= "Spedisci file!";
$MsgFileSelect			= "Seleziona il tuo file";
$MsgFileUseFile			= "Crea Cartolina";

// added v2.4

$MsgSLog = 'Service Log';
$MsgAdminEntries = 'registries';
$MsgAdminLogRestart = 'Restart Service Log';
$MsgAdminLogNote = 'If you like to restart/clean the service log, you�re free to do so by pushing this button. Consider however that all your current informations are deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.';
$MsgAdminLogRname = 'Recip Name';
$MsgAdminLogRemail = 'Recip Email';
$MsgAdminLogSname = 'Sender Name';
$MsgAdminLogSemail = 'Sender Email';
$MsgAdminLogSip = 'Sender IP';
$MsgAdminLogDate = 'Date';
$MsgAdminLogSentDate = 'Sent/To Send date';
$MsgAdminLogEcard = 'Ecard';


?>