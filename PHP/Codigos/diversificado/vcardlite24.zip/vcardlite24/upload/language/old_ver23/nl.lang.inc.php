<?php
/*************************************************************************
      language      : Dutch (Netherlands)
      file          : nl.lang.inc.php
      begin         : 2001-02-15
      translator    : Arjan (aterol@ploink-brothers.com)
      home          : http://www.ploink-brothers.com
*************************************************************************/
$charset			='ISO-8859-1';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect		= "Niet is staat een verbinding te maken met de Database op dit moment!";
$MsgUnableLocateDB		= "De Database is NIET gevonden!";
$MsgErrorPerformingQuery	= "Error tijdens opdracht";

// Create, Preview and View Page
$MsgImage			= "Plaatje";
$MsgYourTitle			= "Jou titel";
$MsgMessage			= "Bericht";
$MsgFont			= "Lettertype";
$MsgNoFontFace			= "Geen letter types";
$MsgFontSizeSmall		= "Klein Lettertype";
$MsgFontSizeMedium		= "Medium Lettertype";
$MsgFontSizeLarge		= "Groot Lettertype";
$MsgFontSizeXLarge		= "X-Large Lettertype";
$MsgFontColorBlack		= "Zwart Lettertype";
$MsgFontColorWhite		= "Wit Lettertype";
$MsgSignature			= "Handtekening";
$MsgRecpName			= "Naam ontvanger";
$MsgRecpEmail			= "E-mail ontvanger";
$MsgAddRecp			= "Voeg ontvanger toe";
$MsgPlay			= "SPEEL AF";
$MsgYourName			= "Je naam";
$MsgYourEmail			= "Je e-mail adres";
$MsgChooseLayout		= "Kies een Lay-out";
$MsgChooseDate			= "Datum van zenden?";
$MsgDateFormat			= "Kies Vandaag, de datum weergave is DD/MM/YYYY, om je kaart nu te verzenden.";
$MsgChooseStamp			= "Kies postzegel";
$MsgPostColor			= "Kaart achtergrond kleur";
$MsgPageBackground		= "Achtergrond";
$MsgNone			= "None";
$MsgMusic			= "Muziek";
$MsgPreviewButton		= "Preview voor verzenden";
$MsgNotify			= "Stel mij op de hoogte wanneer de ontvanger mijn kaart heeft gelezen.";
$MsgYes				= "Ja";
$MsgNo				= "Nee";
$MsgNoFlash			= "Oeps! De Fash Player plug-in moet ge�nstalleerd zijn om deze kaart af te spelen. ";
$MsgClickHereToGet		= "Klik hier om het te instaleren!";
$MsgHelp			= "Help!";
$MsgCloseWindow			= "Sluit venster";
$MsgPrintable                   = "Print Versie";

// Error Messages
$MsgActiveJS			= "Activeer JavaScript in je browser!";
$MsgErrorMessage			= "Je moet een bericht schrijven voor je kaart!";
$MsgErrorRecpName			= "Je moet wel de naam van de ontvanger invullen.";
$MsgErrorRecpEmail		= "Je moet het e-mail adres van de ontvanger invullen.";
$MsgErrorRecpEmail2		= "Het <b>e-mail adres</b> van de ontvanger is ongeldig.";
$MsgErrorSenderName		= "Vul je naam is.";
$MsgErrorSenderEmail		= "Je moet je e-mail adres invullen.";
$MsgErrorSenderEmail2		= "Je <B>e-mail adres</B> is ongeldig.";
$MsgErrorNotFoundTxt		= "Het spijt ons; er zijn geen kaarten gevonden met jou virtuele kaart nummer!? Waarschijnlijk is het kaart nummer verkeerd ingevoerd of de kaart is te oud en inmiddels verwijdert van het systeem.";

$MsgBackEditButton		= "Terug naar Invoer";
$MsgSendButton			= "Verstuur Virtuele Kaart!";

$MsgSendTo				= "Verstuur een kaart naar";
$MsgClickHere			= "klik hier";
$MsgAvoidDuplicat			= "Klik maar EEN keer om dubbele invoer te voorkomen!";

// Info Windows
$MsgWinEmoticons			= "Emotie iconen";
$MsgWinEmoticonsNote		= "Alle karakters zijn in 'uppercase' (O en P)!";
$MsgWinEmoticonsNoteFotter	= "<B>Als</B> je het plaatje niet wilt laten zien, maar de originele emotie iconen wilt gebruiken, dan moet je de notitie uitsluiten.";
$MsgWinBackground			= "Desktop Plaatje";
$MsgWinStamp			= "Postzegel Plaatje";
$MsgWinColors			= "Kleuren";
$MsgWinMusic			= "Muziek";
$MsgWinMusicNote			= "Maak je keuze.";
$MsgWinNotify			= "Wil je een bericht krijgen wanneer de ontvanger je virtuele kaart heeft gelezen?";
$MsgWinFonts			= "Lettertypes";
$MsgWinFontsNote			= "Met deze keuze moet je rekening houden met de mogelijkheid dat niet iedereen het lettertype heeft ge�nstalleerd wat jij hebt uitgekozen. Wanneer dat zo is dan ziet de ontvanger de kaart in de gebruikelijke lettertypes Ariel, Times en/of Helvetica.";
$MsgWinName				= "Naam";
$MsgWinSample			= "Voorbeeld";
$MsgWinSampleString		= "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard		= "Verstuur een andere Virtuele Kaart";

// Advanced Send
$MsgNPostSent			= "kaart is nu verstuurd.";

// Admin Page
$MsgAdminPage			= "Controle Paneel";
$MsgAdminCardControlTitle	= "Kaarten Opties";
$MsgAdminCardControlNote	= "Deze optie verwijdert kaarten ouder dan XX dagen.";
$MsgAdminDay			= "Dagen";
$MsgAdminDelOption1		= "Alleen opgehaalde kaarten";
$MsgAdminDelOption2		= "Alleen kaarten die NOOIT zijn opgehaald";
$MsgAdminDeleteButton		= "Verwijder kaarten";
$MsgAdminDeletedCards		= "kaarten zijn verwijdert uit de database.";

$MsgAdminWarning			= "WAARSCHUWING!";
$MsgAdminWarning2			= "Deze optie verwijderd kaarten uit de database die ";
$MsgAdminWarningReaded		= "gelezen zijn";
$MsgAdminWarningNotReaded	= "niet zijn gelezen";
$MsgAdminWarning3			= "en ";
$MsgAdminWarning4			= "dagen oud zijn.";
$MsgAdminWarning5			= "kaarten worden verwijderd op basis van je wensen. Weet je zeker dat je door wilt gaan?";
$MsgAdminWarningButtonYes	= "Ja, zeker!";
$MsgAdminWarningButtonNo	= "Nee, stop!";
$MsgAdminWarningNoCardDelete	= "Kaarten zijn niet verwijderd! Ga terug en pas je criteria aan.";

$MsgAdminPatternControlTitle	= "Patronen Opties";
$MsgAdminMusicControlTitle	= "Muziek Opties";
$MsgAdminStampControlTitle	= "Postzegel Opties";
$MsgAdminIncluded			= "entry INCLUDED";
$MsgAdminNoIncluded		= "entry NOT INCLUDED";
$MsgAdminDeleted			= "entry DELETED";
$MsgAdminNoDeleted		= "entry NOT DELETED";
$MsgAdminFormFieldEmpty		= "formulier veld is leeg. Ga terug en probeer het nog een keer!";

$MsgAdminModified			= "entry MODIFIED";
$MsgAdminNoModified		= "entry NOT MODIFIED";

$MsgAdminInclude			= "Voeg toe"; 
$MsgAdminDelete			= "Verwijder"; 
$MsgAdminEdit			= "Wijzig";
$MsgAdminModify			= "Aanpassen";

$MsgAdminControlMusicFile	= "Muziek Bestand";
$MsgAdminControlMusicName	= "Naam Muziek";
$MsgAdminControlMusicAuthor	= "Auteur Muziek";
$MsgAdminControlMusicGenre	= "Muziek Genre";

$MsgAdminControlPatternFile	= "Patroon Plaatje";
$MsgAdminControlPatternName	= "Naam Patroon";
$MsgAdminControlStampFile	= "Postzegel Plaatje";
$MsgAdminControlStampName	= "Naam Postzegel";

$MsgAdminControlPostImgFile	= "Plaats Bestand";
$MsgAdminControlPostThmFile	= "Plaats Thumb Bestand";
$MsgAdminControlPostTemplate	= "Naam Template";

$MsgAdminPostcardControlTitle	= "Kaart Opties";
$MsgAdminCategoryControlTitle	= "Categorie Opties";

$MsgAdminExtraInfoTitle		= "Extra Informatie";

$MsgAdminNote			= "Let op";
$MsgAdminNoteMust			= "Het bestand moet worden geupload naar";

// Extra Info:
$MsgvCardLiteCommunity		= "vCard Lite Community";
$MsgYourVersion			= "Je versie";
$MsgAvaibaleVersion		= "Beschikbare versie";

// Statistic Page
$MsgAdminCardStatTitle		= "Statistieken";
$MsgAdminControlImageFile 	= "Plaatje Bestand";
$MsgAdminTemplateFile 		= "Template Bestand";
$MsgSeeYourStat			= "Bekijk je de statistieken van je PostKantoor";
$MsgPosition 			= "Plaats";
$MsgHits				= "Hits";
$MsgTop 				= "Top ";

$MsgAdminStatsRestart		= "Statistieken herstarten";
$MsgAdminStatsDbEmpty		= "Statistieken data base is LEEG";
$MsgAdminStatsDbNoEmpty		= "Statistieken data base is NIET LEEG";
$MsgAdminStatsNote		= "Wanneer je de statistieken wil herstarten dan moet je op de knop drukken. Let wel op dat alle voorafgaande statistieken worden verwijderd.";

// Gallery Browser Pages
$MsgNext				= "Volgende";
$MsgPrevious			= "Vorige";
$MsgBackCatMain			= "Terug naar de Categorie�n";

$MsgNoCardsinDB			= "Sorry, er zijn nog geen kaarten in de database.";
$MsgInvalidePageNumber		= "Je hebt een ongeldig pagina nummer opgegeven";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Naam Categorie";
$MsgAdminGalleryControlTitle	= "Galerij Opties";

$MsgAdminLinkBrowser		= "browse";
$MsgAdminLinkEdit			= "wijzig";
$MsgAdminLinkDelete		= "verwijder";

// MENU
$MsgMusic			= "Muziek";
$MsgPattern			= "Patroon";
$MsgMain			= "Kantoor";
$MsgGallery			= "Galerij";
$MsgStamp			= "Postzegel";
$MsgStats			= "Statistieken";
$MsgAdminBrowser		= "Browser";
$MsgPHPInfo			= "PHP Info";

$MsgCategories			= "Categorie�n";
$MsgCategory			= "Categorie";
$MsgPostcards			= "Virtuele Postkaarten";

// Back Link Messages
$MsgBack			= "Terug";
$MsgBackButton		= "Terug naar vorige pagina";
$MsgBacktoSection		= "Terug naar vorige selectie";

// File Upload
$MsgUploadYourOwnFileTitle	= "Gebruik een eigen plaatje";
$MsgUploadYourOwnFileInfo	= "Maak een kaart met je eigen plaatje";
$MsgErrorFileExtension		= "Bestand extensie niet geoorloofd. Het mogen allen .gif, .jpeg, .jpg en .swf extensies zijn (lowercase)!";
$MsgFileBiggerThan		= "Bestandsgrote is groter dan"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed		= "De maximum grote om te uploaden is "; // Fhe max size of file is XX Kbytes
$MsgFileAllowed			= "Je mag je eigen plaatje(.gif, .jpg) of een flash animatie(.swf) uploaden om een persoonlijke kaart te maken. Selecteer je bestand van je harde schijf en klik op de knop.";
$MsgFileUploadNotAllowed	= "Uploading is verboden op dit systeem! Sorrie.";
$MsgFileSend			= "Verstuur!";
$MsgFileSelect			= "Selecteer je bestand";
$MsgFileUseFile			= "Maak kaart";

// added v2.4

$MsgSLog = 'Service Log';
$MsgAdminEntries = 'registries';
$MsgAdminLogRestart = 'Restart Service Log';
$MsgAdminLogNote = 'If you like to restart/clean the service log, you�re free to do so by pushing this button. Consider however that all your current informations are deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.';
$MsgAdminLogRname = 'Recip Name';
$MsgAdminLogRemail = 'Recip Email';
$MsgAdminLogSname = 'Sender Name';
$MsgAdminLogSemail = 'Sender Email';
$MsgAdminLogSip = 'Sender IP';
$MsgAdminLogDate = 'Date';
$MsgAdminLogSentDate = 'Sent/To Send date';
$MsgAdminLogEcard = 'Ecard';


?>