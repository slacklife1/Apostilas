Hi,

  These language files need some translation. In the footer there are new lines that you need translate to your tongue.

  Into TOP page there is a new line too.
  
  $htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left
  
  This is the HTML code to indicate to browser which direction the text string must have.
  
  regards