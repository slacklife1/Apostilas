<?php
/*************************************************************************
      language      : english
      file          : en.lang.inc.php
      begin         : 2002-02-15
	  last updated  : 2002-10-22
      translator    : Dean (dean@rdcollins.net)
      home          : http://www.rdcollins.net
      charset       : ISO-8859-1
*************************************************************************/
$charset			='iso-8859-1';
$htmldir			='ltr'; // Content direction LTR = Left to Right, RTL = Right to Left

// database error messages
$MsgUnableConnect		= "Unable to connect to the database server at this time!";
$MsgUnableLocateDB		= "Unable to locate the database at this time!";
$MsgErrorPerformingQuery	= "Error performing query";

// Create, Preview and View Page
$MsgImage			= "Image";
$MsgYourTitle			= "Your Title";
$MsgMessage			= "Message";
$MsgFont			= "Font";
$MsgNoFontFace			= "No Font Face";
$MsgFontSizeSmall		= "Small Type";
$MsgFontSizeMedium		= "Medium Type";
$MsgFontSizeLarge		= "Large Type";
$MsgFontSizeXLarge		= "X-Large Type";
$MsgFontColorBlack		= "Black Type";
$MsgFontColorWhite		= "White Type";
$MsgSignature			= "Signature";
$MsgRecpName			= "Recipient's name";
$MsgRecpEmail			= "Recipient's email";
$MsgAddRecp			= "Recipients";
$MsgPlay			= "PLAY";
$MsgYourName			= "Your name";
$MsgYourEmail			= "Your email";
$MsgChooseLayout		= "Choose a Card Layout";
$MsgChooseDate			= "Date to send card?";
$MsgDateFormat			= "Choose current day, the date format is DD/MM/YYYY, to send your postcard now.";
$MsgChooseStamp			= "Choose Stamp";
$MsgPostColor			= "Card background color";
$MsgPageBackground		= "Wallpaper";
$MsgNone			= "None";
$MsgMusic			= "Music";
$MsgPreviewButton		= "Preview before sending";
$MsgNotify			= "Notify me by email when the recipient reads this greeting.";
$MsgYes				= "Yes";
$MsgNo				= "No";
$MsgNoFlash			= "You need the Flash player plug-in to see the Flash version of the postcard. ";
$MsgClickHereToGet		= "Click here to get it!";
$MsgHelp			= "Help!";
$MsgCloseWindow			= "Close Window";
$MsgPrintable                   = "Printable Version";

// Error Messages
$MsgActiveJS			= "Please activate javascript!";
$MsgErrorMessage		= "You must write a message for your postcard.";
$MsgErrorRecpName		= "You must enter the recipient's name.";
$MsgErrorRecpEmail		= "You must enter the recipients's e-mail address.";
$MsgErrorRecpEmail2		= "Recipients's <B>email address</B> is invalid.";
$MsgErrorSenderName		= "You must enter your name.";
$MsgErrorSenderEmail		= "You must enter your email address.";
$MsgErrorSenderEmail2		= "Your <B>email address</B> is invalid.";
$MsgErrorNotFoundTxt		= "Sorry, no postcard matches your postcard number. You may have mistyped the postcard's ID, or your postcard may be too old and has already been erased from the system.";

$MsgBackEditButton		= "Back to Edit";
$MsgSendButton			= "Send Postcard!";

$MsgSendTo			= "Send a postcard to";
$MsgClickHere			= "click here";
$MsgAvoidDuplicat		= "Click only once to avoid duplicates!";

// Info Windows
$MsgWinEmoticons		= "Emoticons";
$MsgWinEmoticonsNote		= "All characters are uppercased (O and P)!";
$MsgWinEmoticonsNoteFotter	= "<B>If</B> you do NOT want the graphic to appear, but still want to use the original emoticons you will have to exclude the nose.";
$MsgWinBackground		= "Wallpaper Image";
$MsgWinStamp			= "Stamp Image";
$MsgWinColors			= "Colors";
$MsgWinMusic			= "Music";
$MsgWinMusicNote		= "Choose an option.";
$MsgWinNotify			= "Do you want to receive an email notification when your postcard is viewed by the recipient?";
$MsgWinFonts			= "Fonts";
$MsgWinFontsNote		= "If you want to use this option, <FONT COLOR=red>please be aware</FONT> that not everyone will have these exact fonts installed on their computers. If not, they will see the default fonts, usually Times and Arial or Helvetica.";
$MsgWinName			= "Name";
$MsgWinSample			= "Sample";
$MsgWinSampleString		= "abcdefghijklmnopqrstuvwxyz";

// Message in confirmation page
$MsgSendAnotherCard		= "Send Another Virtual Card";

// Advanced Send
$MsgNPostSent			= "postcard sent in this time.";

// Admin Page
$MsgAdminPage			= "Control Painel";
$MsgAdminCardControlTitle	= "Postcard Controls";
$MsgAdminCardControlNote	= "This utility will delete postcards are XX days old.";
$MsgAdminDay			= "Days";
$MsgAdminDelOption1		= "Only cards that have been picked-up";
$MsgAdminDelOption2		= "Only cards that have NOT been picked-up";
$MsgAdminDeleteButton		= "Delete Postcards";
$MsgAdminDeletedCards		= "cards were deleted from the database.";

$MsgAdminWarning		= "Warning!";
$MsgAdminWarning2		= "This option will delete all the postcards in your database that";
$MsgAdminWarningReaded		= "have been read";
$MsgAdminWarningNotReaded	= "have not been read";
$MsgAdminWarning3		= "and are";
$MsgAdminWarning4		= "days old.";
$MsgAdminWarning5		= "cards will be deleted based on your selection criteria. Are you sure you want to continue?";
$MsgAdminWarningButtonYes	= "Yes, I'm sure!";
$MsgAdminWarningButtonNo	= "No, please stop!";
$MsgAdminWarningNoCardDelete	= "No cards will be deleted based on your selection criteria. Go back and select new criteria.";

$MsgAdminPatternControlTitle	= "Pattern Control";
$MsgAdminMusicControlTitle	= "Music Control";
$MsgAdminStampControlTitle	= "Stamp Control";
$MsgAdminIncluded		= "entry INCLUDED";
$MsgAdminNoIncluded		= "entry NOT INCLUDED";
$MsgAdminDeleted		= "entry DELETED";
$MsgAdminNoDeleted		= "entry NOT DELETED";
$MsgAdminFormFieldEmpty		= "form field is empty. Go back and try again!";

$MsgAdminModified		= "entry MODIFIED";
$MsgAdminNoModified		= "entry NOT MODIFIED";

$MsgAdminInclude		= "Add"; 
$MsgAdminDelete			= "Delete"; 
$MsgAdminEdit			= "Edit";
$MsgAdminModify			= "Modify";

$MsgAdminControlMusicFile	= "Music File";
$MsgAdminControlMusicName	= "Music Name";
$MsgAdminControlMusicAuthor	= "Music Author";
$MsgAdminControlMusicGenre	= "Music Genre";

$MsgAdminControlPatternFile	= "Pattern File";
$MsgAdminControlPatternName	= "Pattern Name";
$MsgAdminControlStampFile	= "Stamp File";
$MsgAdminControlStampName	= "Stamp Name";

$MsgAdminControlPostImgFile	= "Post File";
$MsgAdminControlPostThmFile	= "Post Thumb file";
$MsgAdminControlPostTemplate	= "Template Name";

$MsgAdminPostcardControlTitle	= "Postcard Control";
$MsgAdminCategoryControlTitle	= "Category Control";

$MsgAdminExtraInfoTitle		= "Extra Info";

$MsgAdminNote			= "Note";
$MsgAdminNoteMust		= "The file must be uploaded to";

// Extra Info:
$MsgvCardLiteCommunity		= "vCard Lite Community";
$MsgYourVersion			= "Your version";
$MsgAvaibaleVersion		= "Avaiable version";

// Statistic Page
$MsgAdminCardStatTitle		= "Statistic";
$MsgAdminControlImageFile 	= "Image File";
$MsgAdminTemplateFile 		= "Template File";
$MsgSeeYourStat			= "To see your postcard service statistics";
$MsgPosition 			= "Position";
$MsgHits			= "Hits";
$MsgTop 			= "Top ";

$MsgAdminStatsRestart		= "Restart Statistics";
$MsgAdminStatsDbEmpty		= "Stats data base is EMPTY";
$MsgAdminStatsDbNoEmpty		= "Stats data base NOT EMPTY";
$MsgAdminStatsNote		= "If you like to restart the Statistics you're free to do so by pushing this button. Consider however that all your current statistics information is deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.";

// Gallery Browser Pages
$MsgNext			= "Next";
$MsgPrevious			= "Prev";
$MsgBackCatMain			= "Back Category Main Page";

$MsgNoCardsinDB			= "Sorry, there are no cards in the database.";
$MsgInvalidePageNumber		= "You have specified an invalid page number";

// AdminL: Gallery Browser Pages
$MsgAdminControlCatId		= "ID";
$MsgAdminControlCatName		= "Category Name";
$MsgAdminGalleryControlTitle	= "Gallery Control";

$MsgAdminLinkBrowser		= "browse";
$MsgAdminLinkEdit		= "edit";
$MsgAdminLinkDelete		= "delete";

// MENU
$MsgMusic			= "Music";
$MsgPattern			= "Pattern";
$MsgMain			= "Main";
$MsgGallery			= "Gallery";
$MsgStamp			= "Stamp";
$MsgStats			= "Stats";
$MsgAdminBrowser		= "Browser";
$MsgPHPInfo			= "PHP Info";

$MsgCategories			= "Categories";
$MsgCategory			= "Category";
$MsgPostcards			= "Postcards";

// Back Link Messages
$MsgBack			= "Back";
$MsgBackButton			= "Back to Previous Page";
$MsgBacktoSection		= "Back to previous section";

// File Upload
$MsgUploadYourOwnFileTitle	= "Use your Own Pic";
$MsgUploadYourOwnFileInfo	= "Create a postcard using your own picture";
$MsgErrorFileExtension		= "File extension not allowed. It must be .gif, .jpeg, .jpg or .swf all em lowercase!";
$MsgFileBiggerThan		= "File size is bigger than"; // File size is bigger than XX Kbytes
$MsgFileMaxSizeAllowed		= "The max size of file allowed to be uploaded is "; // Fhe max size of file is XX Kbytes
$MsgFileAllowed			= "You can upload your own image(.gif, .jpg) or flash animation(.swf) file to create a custom postcard. Select your file and click on the buttom.";
$MsgFileUploadNotAllowed	= "File Uploading system is disable in this site! Soory.";
$MsgFileSend			= "Send File!";
$MsgFileSelect			= "Select your file";
$MsgFileUseFile			= "Create postcard";

// added v2.4

$MsgSLog = 'Service Log';
$MsgAdminEntries = 'registries';
$MsgAdminLogRestart = 'Restart Service Log';
$MsgAdminLogNote = 'If you like to restart/clean the service log, you�re free to do so by pushing this button. Consider however that all your current informations are deleted than. In order to keep that information as a history file save your current reports to your own harddisk first.';
$MsgAdminLogRname = 'Recip Name';
$MsgAdminLogRemail = 'Recip Email';
$MsgAdminLogSname = 'Sender Name';
$MsgAdminLogSemail = 'Sender Email';
$MsgAdminLogSip = 'Sender IP';
$MsgAdminLogDate = 'Date';
$MsgAdminLogSentDate = 'Sent/To Send date';
$MsgAdminLogEcard = 'Ecard';


?>