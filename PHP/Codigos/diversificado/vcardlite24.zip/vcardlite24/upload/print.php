<?php
/***************************************************************************
 *   script               : vCard LITE
 *   copyright            : (C) 2001-2003 Belchior Foundry
 *   website              : www.belchiorfoundry.com
 *
 *   This program is freeware software; you can�t redistribute it under
 *   any circumstance without explicit authorization from Belchior Foundry.
 *   http://www.belchiorfoundry.com/
 *
 ***************************************************************************/
include('./lib.inc.php');
$ecard_id = $HTTP_GET_VARS['ecard_id'];

$result 	= $DB_site->query("SELECT * FROM $dbtbl_user WHERE ecard_id='$ecard_id'");
$number 	= $DB_site->num_rows($result);
$cardinfo 	= $DB_site->fetch_array($result);
$DB_site->free_result($result);

// If there are no matches in the DB, then return an error message 
if( $number==0 )
{

	dovcardliteheader();
	echo TagFont($SiteFontFace,3,1,1,$MsgErrorNotFoundTxt);
	dovcardlitefooter();
	exit;
}
extract($cardinfo);
// convert Original -> emoticon -> graphic
$ecard_messageShow = $ecard_message;
$T_ecard_message = EmoticonToGraphic($ecard_messageShow);
// Check FLASH or GIF/JPEG
$T_card_image = TAG_Image($card_image,$card_imageURL);
// Check MUSIC
$T_sound_file = "";
// Check STAMP
$T_stamp_file = TAG_Stamp($stamp_file);

$t->set_file(array("body" => "$card_template.ihtml"));
$t->set_var(array(
		'T_SiteName' => $SiteName,
		'T_SiteURL' => $SiteURL,
		'T_SenderName' => $ecard_sname,
		'T_SenderEmail' => $ecard_semail,
		'T_RecpName' => $ecard_rname,
		'T_RecpEmail' => $ecard_remail,
		'T_PostImage' => $T_card_image,
		'T_PostMessage' => $T_ecard_message,
		'T_PostSig' => $ecard_sig,
		'T_PostHeading' => $ecard_heading,
		'T_PostSound' => $T_sound_file,
		'T_PostStamp' => $T_stamp_file,
		'T_PostBackGround' => $pattern_file,
		'T_PostColor' => $ecard_color,
		'T_PostFontFace' => $ecard_fontface,
		'T_PostFontColor' => $ecard_fontcolor,
		'T_PostFontSize' => $ecard_fontsize,
		'T_MsgSendTo' => $MsgSendTo,
		'T_MsgClickHere' => $MsgClickHere,
		'T_SiteFontFace' => $SiteFontFace
		));
$t->parse("output","body");

dovcardliteheader($pattern_file);
$t->p("output");
dovcardlitefooter();

?>