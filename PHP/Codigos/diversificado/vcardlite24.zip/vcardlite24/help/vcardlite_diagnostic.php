<?
@header ("Pragma: no-cache");
set_magic_quotes_runtime(0);
error_reporting(E_ERROR | E_WARNING | E_PARSE);
if(!empty($HTTP_COOKIE_VARS)) {
	while(list($xxxname, $value) = each($HTTP_COOKIE_VARS)) {
		$$xxxname = $value;
    }
}
if(!empty($HTTP_GET_VARS)) {
	while(list($xxxname, $value) = each($HTTP_GET_VARS)) {
		$$xxxname = $value;
    }
}
if(!empty($HTTP_POST_VARS)){
	while(list($xxxname, $value) = each($HTTP_POST_VARS)) {
		$$xxxname = $value;
	}
}
if(!empty($HTTP_POST_FILES)) {
	while(list($xxxname, $value) = each($HTTP_POST_FILES)) {
    	$$xxxname = $value['tmp_name'];
    }
}
function filecheck($file_item)
{
	echo "<table width=\"600\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\" align=\"center\" bgcolor=\"#000000\">
	<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#CCCCFF\" width=\"450\"><b> $file_item </b></td><td align=\"left\"><table cellspacing=0 cellpadding=0 bgcolor=#FF0000><tr><td><pre class=\"textpre\">";
	include("$file_item");
	echo "</pre></td></tr></table></td></tr></table>";
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>CHECK TOOL for vCard Lite</title>
</head>
<STYLE TYPE="text/css"><!--
A { text-decoration: none; }
A:hover { text-decoration: underline; }
H1 { font-family: arial,helvetica,sans-serif; font-size: 18pt; font-weight: bold;}
H2 { font-family: arial,helvetica,sans-serif; font-size: 14pt; font-weight: bold;}
BODY,TD,FORM,INPUT,TEXTAREA { font-family: arial,helvetica,sans-serif; font-size: 10pt; }
TH { font-family: arial,helvetica,sans-serif; font-size: 11pt; font-weight: bold; }
.textpre {font-family : "Courier New", Courier, monospace; font-size : 1px; font-weight : bold;}
//--></STYLE>
<body>
<div align=center>
<a href="vcardlite_diagnostic.php">MAIN PAGE</a><br>
<br>
[ <a href="vcardlite_diagnostic.php?item=files">Files</a> ] 
[ <a href="vcardlite_diagnostic.php?item=db">Database</a> ] 
[ <a href="vcardlite_diagnostic.php?item=config">Config</a> ] 
[ <a href="vcardlite_diagnostic.php?item=env">PHP Environment</a> ] 
[ <a href="vcardlite_diagnostic.php?item=mail">PHP Mail</a> ] 
[ <a href="vcardlite_diagnostic.php?item=upload">PHP Upload</a> ] 
</div>
<br>
<br>
<div align="center"><b>Note</b>: This file must be located at your <i>main vcard lite directory</i>. Not help directory.</div>
<br>

<?php
// ######################## require files and blank spaces
if($item=="files")
{
?>
<table width="600" border="0" cellspacing="1" cellpadding="3" align="center" bgcolor="#000000">
<tr valign="baseline" bgcolor="#CCCCCC"><td bgcolor="#9999CC" colspan="2" align="center"><b> File Check </b></td></tr>
<tr valign="baseline" bgcolor="#CCCCCC"><td bgcolor="#9999CC" colspan="2" align="center">If you see a read bar into file, there is a <b>blank space</b> that must be removed from file.<br> Check these blank space after <b>?></b> signal into bottom of file</td></tr>
</table>
<?
	filecheck("./admin/config.inc.php");
	filecheck("./include/db_mysql.inc.php");
	filecheck("./include/functions.inc.php");
	//filecheck("./language/eng.lang.inc.php");
	if(file_exists("./admin/config.inc.php"))
	{
		include("./admin/config.inc.php");
		filecheck("./language/$PostLanguageFile");
	}
}
// ######################## php info
if($item=="env")
{
	phpinfo();
}

// ######################## mail function
if($item=="mail")
{
	echo "
	<form action=\"vcardlite_diagnostic.php\" method=\"post\">
	<table width=\"600\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\" align=\"center\" bgcolor=\"#000000\">
	<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#9999CC\" colspan=\"2\" align=\"center\"><b> PHP mail function </b></td></tr>
	<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#CCCCFF\"><b> To email address </b></td><td align=\"left\"> <input type=\"text\" name=\"address\" value=\"\"> </td></tr>
	<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#9999CC\" colspan=\"2\" align=\"center\"><b><input type=\"submit\"> </b></td></tr>
	</table><br>
	<input type=\"hidden\" name=\"action\" value=\"mail_send\"></form>";
}
if($action=="mail_send")
{
	mail("$address","Testing mail() function","This is a test email");
	echo "<blockquote><p>Mail sent.<br>
	<b>Were any errors shown</b>? If there were, mail is probably not set up correctly. And you need contact your web hosting provider about this problem.</p></blockquote>";
}

// ######################## config info
if($item=="config")
{
	include("./admin/config.inc.php");

echo "
<table width=\"600\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\" align=\"center\" bgcolor=\"#000000\">
<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#9999CC\" colspan=\"2\" align=\"center\"><b> Configuration </b></td></tr>
<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#CCCCFF\"><b> DB Server </b></td><td align=\"left\"> $hostname </td></tr>
<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#CCCCFF\"><b> DB name </b></td><td align=\"left\"> $dbName </td></tr>
<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#CCCCFF\"><b> DB username </b></td><td align=\"left\"> $dbUser </td></tr>
<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#CCCCFF\"><b> DB password </b></td><td align=\"left\"> $dbPass </td></tr>
</table><br>
";
}

// ######################## upload function

if($action=="upload")
{
	$destination_path = "$destination/$attachment_name";
	echo "
	attachment = $attachment <br>
	attachment_name = $attachment_name<br>
	attachment_size = $attachment_size<br>
	attachment_type = $attachment_type<br>
	uploading process";
	if($safeupload == "1")
	{
		if(function_exists("is_uploaded_file"))
		{
			if(is_uploaded_file($attachment))
			{
				if(move_uploaded_file($attachment, $destination_path))
				{
				}
			}
		}
	}else{
		copy($attachment, $destination_path);
	}
	echo "<p align=\"center\"><a href=\"$attachment_name\">$attachment_name</a></p>";
	exit;
}

if($item=="upload")
{
	$page = split("/", getenv('SCRIPT_NAME')); 
	$n = count($page)-1; 
	$page = $page[$n]; 
	//$page = split("\.", $page, 2); 
	//$page = $page[0];
	//echo $HTTP_SERVER_VARS['PATH_TRANSLATED'];
	if( ereg(":\\\\",$HTTP_SERVER_VARS['PATH_TRANSLATED']) )
	{
	// NT
		$current_dir = eregi_replace($page,'', $HTTP_SERVER_VARS['PATH_TRANSLATED']);
		$system = "Windows NT";
	}
	else
	{
	// UNIX
		$current_dir = eregi_replace($page,'', $HTTP_SERVER_VARS['PATH_TRANSLATED']);
		$system = "*NIX - CHMOD 777";
	}
	$system = (eregi('win', PHP_OS))? 'Windows' : 'Unix/Linux.<br> Require you CHMOD 777 (change directory permissions) the directory you want upload file using PHP.';
	echo "
	<form action=\"vcardlite_diagnostic.php\" method=\"post\" enctype=\"multipart/form-data\">
	<input type=\"hidden\" name=\"action\" value=\"upload\">
	<table width=\"600\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\" align=\"center\" bgcolor=\"#000000\">
	<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#9999CC\" colspan=\"2\" align=\"center\"><b> PHP upload function </b></td></tr>
	<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#CCCCFF\"><b> File </b></td><td align=\"left\"> <input type=\"file\" name=\"attachment\"> </td></tr>
	<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#CCCCFF\"><b> Safe Mode </b></td><td align=\"left\"><select name=\"safeupload\"><option value=\"0\">safe mode off</option><option value=\"1\">safe mode on (only PHP4)</option></td></tr>
	<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#CCCCFF\"><b> Destination </b></td><td align=\"left\"> <input type=\"text\" name=\"destination\" value=\"$current_dir\" size=50><br>
	<b>Server Operation System is</b>: $system </td></tr>
	<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#9999CC\" colspan=\"2\" align=\"center\"><b><input type=\"submit\"></b></td></tr>
	</table><br>
	</form>";
}

// ######################## data base connection
if($item=="db")
{
	if( file_exists("./admin/config.inc.php") )
	{
		include("./admin/config.inc.php");
	}
?>
<form action="vcardlite_diagnostic.php">
<input type="hidden" name="item" value="db_check">
<table width="600" border="0" cellspacing="1" cellpadding="3" align="center" bgcolor="#000000">
<tr valign="baseline" bgcolor="#CCCCCC"><td bgcolor="#9999CC" colspan="2" align="center"><b> Database Check </b></td></tr>
<tr valign="baseline" bgcolor="#CCCCCC"><td bgcolor="#CCCCFF"><b> DB Server </b></td><td align="left"> <input type="text" name="hostname" value="<? echo $hostname; ?>"> </td></tr>
<tr valign="baseline" bgcolor="#CCCCCC"><td bgcolor="#CCCCFF"><b> DB name </b></td><td align="left"> <input type="text" name="dbname" value="<? echo $dbName; ?>"> </td></tr>
<tr valign="baseline" bgcolor="#CCCCCC"><td bgcolor="#CCCCFF"><b> DB username </b></td><td align="left"> <input type="text" name="dbuser" value="<? echo $dbUser; ?>"> </td></tr>
<tr valign="baseline" bgcolor="#CCCCCC"><td bgcolor="#CCCCFF"><b> DB password </b></td><td align="left"> <input type="text" name="dbpass" value="<? echo $dbPass; ?>"> </td></tr>
<tr valign="baseline" bgcolor="#CCCCCC"><td bgcolor="#9999CC" colspan="2" align="center"><b><input type="submit"> </b></td></tr>
</table>

</form>
<br>
<?
}
if($item=="db_check")
{
	/*******************************************
	initiate dbase
	*******************************************/
	include("./include/db_mysql.inc.php");
	$DB_site=new DB_Sql;
	$DB_site->server=$hostname;
	$DB_site->user=$dbuser;
	$DB_site->password=$dbpass;
	$DB_site->database=$dbname;
	$DB_site->connect();
	
	$dbPass="";		// clear database password variable to avoid retrieving
	$DB_site->password="";
	// allow this script to catch errors
	$DB_site->reporterror=0;
	
	$DB_site->connect();
	// end init db
	$errno=$DB_site->errno;
	echo "<table width=\"600\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\" align=\"center\" bgcolor=\"#000000\">
	<tr valign=\"baseline\" bgcolor=\"#CCCCCC\"><td bgcolor=\"#9999CC\" colspan=\"2\" align=\"center\"><b> Database Check </b></td></tr>";
	echo "<tr valign=\"baseline\" bgcolor=\"#CCCCCC\" colspan=\"2\"><td bgcolor=\"#CCCCFF\" align=\"center\"><b> ";
	if ($DB_site->link_id!=0)
	{
		if ($errno!=0)
		{
			if ($errno==1049)
			{
				echo "<p>You have specified a non existent database. Trying to create one now...</p>";
				//$DB_site->query("CREATE DATABASE $dbname");
				echo "<p>Trying to connect again...</p>";
				$DB_site->select_db($dbname);
				$errno=$DB_site->geterrno();
				if ($errno==0)
				{
					echo "<p>Connect succeeded!</p>";
				}else{
					echo "<p>Connect failed again! Please ensure that the database and server is correctly configured and try again.</p>";
					exit;
				}
			}else{
				echo "<p>Connect failed: unexpected error from the database.</p>";
				echo "<p>Error number: ".$DB_site->errno."</p>";
				echo "<p>Error description: ".$DB_site->errdesc."</p>";
				echo "<p>Please ensure that the database and server is correctly configured and try again.</p>";
				exit;
			}
		}else{
			// succeeded! yay!
			echo "<p><b>Connection succeeded! The database already exists.</b></p>";
		}
	}else{
		echo "<p>The database has failed to connect because you do not have permission to connect to the server. Please go back to the last step and ensure that you have entered all your login details correctly.</p>";
		exit;
	}
	echo "</b></td></tr>
</table><br>
";
}

?>
<br>
<br>
<div align="center">&copy;<? echo date("Y")?> <a href="http://www.belchiorfoundry.com" target="_blank">Belchior Foundry</a></div>
<br>
<br>
</body>
</html>
