<html>
	<head>
	<title>vCard PHP Test</title>
	</head>
<body>
<!--
<?php

// determine if php is running
if (1==0) {
  echo "-->PHP is not installed correctly - Please contact your system administrator.<!--";
} else {
  echo "--".">";
}

echo "PHP is installed correctly";

echo "<"."!--";
?>

-->
</body>
</html>