<?php 
echo 'real path to this dir= '.dirname(__FILE__).'<hr>';
echo 'real path to this dir= '.realpath($_SERVER['SCRIPT_FILENAME']).'<hr>';

phpinfo();
?>