 <?
 /* WEB - TOOLS - www.web-tools.kit.net [ Caso essa linha seja apagada
o sistema ir� parar de funcionar] */
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Newsletter :: Atualiza&ccedil;&otilde;es em www.web-tools.kit.net</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
@import url("../estilos.css");
-->
</style>
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="3"><img src="newsletter_logo.jpg" width="778" height="150"></td>
  </tr>
  <tr> 
    <td colspan="3"><img src="barra.jpg" width="778" height="20"></td>
  </tr>
  <tr> 
    <td width="150" bgcolor="#F7F7F7">&nbsp;</td>
    <td width="471" bgcolor="#F7F7F7">&nbsp;</td>
    <td width="157" bgcolor="#F7F7F7">&nbsp;</td>
  </tr>
  <tr> 
    <td width="150" height="200" bgcolor="#F8F8F8">&nbsp; </td>
    <td><table border="0" cellpadding="0" cellspacing="0">
<tr>
          <td width="600" height="200">
<div align="center">
              <form action="confirmar_login.php" method="post" name="F1" id="F1">
<table width="35%" border="0" cellspacing="0" cellpadding="0">
                  <tr> 
                    <td colspan="2"><strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Administra&ccedil;&atilde;o:</font></strong></td>
                  </tr>
                  <tr> 
                    <td width="19%"><strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Usuario:</font></strong></td>
                    <td width="81%"><strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                      <input name="username" type="text" class="form" id="username">
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td><strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Senha:</font></strong></td>
                    <td><strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                      <input name="senha" type="password" class="form" id="senha">
                      </font></strong></td>
                  </tr>
                  <tr> 
                    <td>&nbsp;</td>
                    <td><strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                      <input name="Submit" type="submit" class="botao" value="Logar &gt;&gt;">
                      </font></strong></td>
                  </tr>
                </table>
              </form>
</div></td>
        </tr>
      </table></td>
    <td width="157" bgcolor="#F7F7F7">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="2" bgcolor="#F7F7F7">&nbsp;</td>
    <td bgcolor="#F7F7F7">&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="3"><img src="barra.jpg" width="778" height="20"></td>
  </tr>
  <tr> 
    <td colspan="3"><img src="redape.jpg" width="778" height="100"></td>
  </tr>
</table>
</body>
</html>
