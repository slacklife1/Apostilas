<?
/* WEB - TOOLS - www.web-tools.kit.net [ Caso essa linha seja apagada
o sistema ir� parar de funcionar] */

setcookie("username");
setcookie("senha");
header("Location: index.php");

?>

