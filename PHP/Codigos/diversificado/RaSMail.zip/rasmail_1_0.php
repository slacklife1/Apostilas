<?php
/*****************************************
* Script: 	RaS!Mail					 *
* Author: 	Alberto "RaS!" Sartori       *
* Contact: 	ras78@caltanet.it		     *
* Version: 	1.0 						 *
* Created:  12/06/2002 12:19:37		     *
* Revision: //							 *
*****************************************/

//Building class
class MailSender {
	var $sender;
	var $recipient;
	var $oggetto;
	var $body;
 	var $mailformat;
	var $priority;
 	var $recipient_CC;
 	var $recipient_BCC;
 	var $attachedfile;

 //Check sender
 function Sender($sender) {
  if ($sender=="") {
   $this->ErrorOutput(2);
  } else {
  if (!eregi("^[a-z0-9\._-]+@+[a-z0-9\._-]+\.+[a-z]{2,4}$", $sender)) {
   $this->ErrorOutput(4);  
   } else $this->mittente=$sender;
  }
 }

 //Check recipient
 function Recipient($recipient) {
  if ($recipient=="") {
   $this->ErrorOutput(1);
  } else {
  if (!eregi("^[a-z0-9\._-]+@+[a-z0-9\._-]+\.+[a-z]{2,4}$", $recipient)) {
   $this->ErrorOutput(3);
   } else $this->destinatario=$recipient;
  }
 }

 //Check subject
 function Subject($oggetto) {
  if ($oggetto!="") {
  $oggetto=str_replace("\'","'",$oggetto);
  $this->oggetto=$oggetto;  
  }
 }

 //Check body
 function Body($body) {
  if ($body!="") {
   $body=str_replace("\'","'",$body);
   $this->body=$body;
  }
 }

 //Check mailformat
 function Mailformat($mailformat) {
  if ($mailformat!="") {
   if ($mailformat!="1" && $mailformat!="0") {
     $this->ErrorOutput(5); 
   } else $this->formato=$mailformat;
  }
 }

 //Check priority
 function Priority($priority) {
  if ($priority!="") {
   if ($priority!="5" && $priority!="3" && $priority!="1") {
     $this->ErrorOutput(6); 
   } else $this->priorita=$priority;
  }
 }

 //Check recipient CC
 function RecipientCC($recipientCC) {
  if ($recipientCC!="") {
   if (!eregi("^[a-z0-9\._-]+@+[a-z0-9\._-]+\.+[a-z]{2,4}$", $recipientCC)) {
     $this->ErrorOutput(7);
   } else $this->destinatarioCC=$recipientCC;
  }
 }

 //Check recipient BCC
 function RecipientBCC($recipientBCC) {
  if ($recipientBCC!="") {
   if (!eregi("^[a-z0-9\._-]+@+[a-z0-9\._-]+\.+[a-z]{2,4}$", $recipientBCC)) {
     $this->ErrorOutput(8);
   } else $this->destinatarioBCC=$recipientBCC;
  }
 }

 //Check attachment
 function Attachment($attachedfile) {
  if ($attachedfile) {
  $pf=@fopen($attachedfile,"r") or die($this->ErrorOutput(9));
  $bytes=fread($pf,filesize($attachedfile));
  $file=chunk_split(base64_encode($bytes));
  fclose($pf);
  }
  if (!$file) {
   $this->ErrorOutput(9);
  } else {
   $this->allegato=$attachedfile;
   $this->filestream=$file;
   }
  }

 //Main function of sendmail
 function Execute()
 {
  //Setting up headers
  $forma=($this->formato==1)? "plain" : "html";
  $headers= "From: $this->mittente\n";
  $headers.= "cc: $this->destinatarioCC\n";
  $headers.= "Bcc: $this->destinatarioBCC\n";
  $headers.= "X-Priority: $this->priorita\n";
  $headers.= "X-Mailer: 'RaS! Mailer'\n";
  $headers.= "Content-Type: text/$forma; charset=iso-88592"; 
  $this->headers=$headers;
 if ($this->allegato) {
  $headers.= "MIME-version: 1.0\n";
  $headers.= "Content-type: multipart/mixed; "; 
  $headers.= "boundary=\"Message-Boundary\"\n";
  $headers.= "Content-transfer-encoding: 7BIT\n";
  $this->headers=$headers;
 }
 //ReSet the body's headers if we have the attachment
 if ($this->allegato) {
  $body = "--Message-Boundary\n";
  $body .= "Content-Type: text/$forma; charset=iso-8859-1\n"; 
  $body .= "Content-transfer-encoding: 7bit\n";
  $body .= "Content-description: Mail message body\n";
  $body .= $this->body."\n";
  $body .= "--Message-Boundary\n";
  $body .= "Content-type: application/octet-stream name=\"".basename($this->allegato)."\"\n"; 
  $body .= "Content-Transfer-Encoding: base64\n";
  $body .= "Content-disposition: attachment; filename=\"".basename($this->allegato)."\"\n";
  $body .= $this->filestream."\n";
  $body .= "--Message-Boundary--\n";
  $this->body=$body;
 }

 //Sending mail
 mail($this->destinatario, $this->oggetto, $this->body, $this->headers);
 echo "Mail delivered to <strong>$this->destinatario</strong>";
 }

 function ErrorOutput($err_code) {
  if ($err_code!="") {
   switch($err_code) {
    case 1  : $err_msg="ERROR: Enter the recipient address!";
			  break;
    case 2  : $err_msg="ERROR: Enter the sender address!";
			  break;
    case 3  : $err_msg="ERROR: Mail address of sender is not valid!";
			  break;
    case 4  : $err_msg="ERROR: Mail address of recipient is not valid!";
			  break;
    case 5  : $err_msg="ERROR: The mailformat must be 0(html) or 1(textplain)";
			  break;
    case 6  : $err_msg="ERROR: Set the priority 5(low), 3(normal), 1(high)";
			  break;
    case 7  : $err_msg="ERROR: Mail address of CC recipient is not valid!";
			  break;
    case 8  : $err_msg="ERROR: Mail address of BCC recipient is not valid!";
			  break;
    case 9  : $err_msg="ERROR: File doesn't exists!";
			  break;
    default : $err_msg="ERROR: Generic error!";
			  break;
   }
  echo $err_msg;
  exit;
  }
 }
}
?>
