RASMAIL 1.0 by Alberto "RaS!" Sartori, June 2002
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

This is my first php class and my first oop project. I hope I did good work.
It's a simple class thats include all the classic methods for send mail. It
support attachment, html or texplain mailformat and other features.
Report bugs at: ras78@caltanet.it 
Sincerly your,
		RaS!