<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<title>Example</title>
</head>
<body>
<?php
//Example of use
include("rasmail_1_0.php");

$NewMail=new MailSender();
 $NewMail->Sender("sender@domain.com");
 $NewMail->Recipient("recipient@domain.com");
 $NewMail->Subject("Hello World!");
 $NewMail->Body("The subject sucks!");
 $NewMail->Mailformat("1");
 $NewMail->Priority("3");
 $NewMail->Execute();
?>
</body>
</html>
