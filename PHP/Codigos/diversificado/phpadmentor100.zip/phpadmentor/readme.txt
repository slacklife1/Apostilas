Welcome to PhpAdMentor!

http://www.aspcode.net/php/article

Copyright Stefan Holmberg 2001


1. Installation
******************
You have already downloaded the zip-file and I bet you have
unzipped it to <webroot>/phpadmentor

Good. Now create a MySQL database - call it phpadmentor.

Run the script database.txt in that database.

Open up phpadmentor_config.php

Change these lines:
$sPhpAdMentor_InstallPath = "http://yourwebserver/phpadmentor/";
$sPhpAdMentor_DBHost = "localhost";
$sPhpAdMentor_DBUser = "youruser";
$sPhpAdMentor_DBPassword = "yourpassword";
$sPhpAdMentor_DBDatabase = "phpadmentor";

$sPhpAdMentor_DefaultBanner = "http://www.aspcode.net/images/aspcode46860.gif";
$sPhpAdMentor_DefaultClick = "http://www.aspcode.net/";


2. Fire up the browser. Go to http://yourwebserver/phpadmentor/admin/index.php
Login as administrator with password test.

You are ready to start using PhpAdMentor!