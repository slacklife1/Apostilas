<?
$sPhpAdMentor_InstallPath = "http://www.aspcode.net/phpadmentor/";
$sPhpAdMentor_DBHost = "localhost";
$sPhpAdMentor_DBUser = "youruserid";
$sPhpAdMentor_DBPassword = "yourpassword";
$sPhpAdMentor_DBDatabase = "phpadmentor";

$sPhpAdMentor_DefaultBanner = "http://www.aspcode.net/images/aspcode46860.gif";
$sPhpAdMentor_DefaultClick = "http://www.aspcode.net/";


//$PhpAdMentor_admin_user = "stefan";
//$PhpAdMentor_admin_pass = "stefan";

$sPhpAdMentor_MaxInt = 2147483647;
$sPhpAdMentor_MaxDate = "2020-10-10";

function PhpAdMentor_MaxIntToNull( $val )
{
global $sPhpAdMentor_MaxInt;
if ( $val == $sPhpAdMentor_MaxInt )
    return "";
return $val;
}

//Do not modify functions below...
function PhpAdMentor_GetDatabaseConn()
{
    global $sPhpAdMentor_DBHost;
    global $sPhpAdMentor_DBUser;
    global  $sPhpAdMentor_DBPassword;
    global $sPhpAdMentor_DBDatabase;
    $conn = mysql_connect($sPhpAdMentor_DBHost, $sPhpAdMentor_DBUser, $sPhpAdMentor_DBPassword);
    mysql_select_db($sPhpAdMentor_DBDatabase, $conn);
    return $conn;
}

function PhpAdMentor_UpdateStats( $connadmentor, $id, $addclicksno, $addimpressionsno )
{
    global $sPhpAdMentor_DBDatabase;


    $sSQL = "select count(*) as antal from $sPhpAdMentor_DBDatabase.stats where bannerid=$id and datum=curdate()";
    $oRS = mysql_query( $sSQL, $connadmentor );

    $row = mysql_fetch_array($oRS);
    if ( $row["antal"] != 0 )
        {
        //Already exists
        $sSQL = "update $sPhpAdMentor_DBDatabase.stats set ";
        if (  $addclicksno )
            $sSQL = $sSQL . "clicks=clicks+1";
        if (  $addimpressionsno )
            $sSQL = $sSQL . "impressions=impressions+1";
        $sSQL = $sSQL . " where datum=Now() and bannerid=$id ";
        }
    else
        {
        $sSQL = "insert into $sPhpAdMentor_DBDatabase.stats( bannerid,datum,clicks,impressions ) values($id, Now() ";
        if (  $addclicksno )
            $sSQL = $sSQL . ",1";
        else
            $sSQL = $sSQL . ",0";
        if (  $addimpressionsno )
            $sSQL = $sSQL . ",1";
        else
            $sSQL = $sSQL . ",0";
        $sSQL = $sSQL . ")";
        }
    mysql_query( $sSQL, $connadmentor );

    $sSQL = "update $sPhpAdMentor_DBDatabase.banner set showcount=showcount+";
    if (  $addimpressionsno )
        $sSQL = $sSQL . "1";
    else
        $sSQL = $sSQL . "0";
    $sSQL = $sSQL . ",clickcount=clickcount+";

    if (  $addclicksno )
        $sSQL = $sSQL . "1";
    else
        $sSQL = $sSQL . "0";
    $sSQL = $sSQL . " where bannerid=$id";
    mysql_query( $sSQL, $connadmentor );
}



function AdSQL_AddAndWhere( $sWhere, $sWhat )
{
    $sRet = "";
    if ( $sWhere == "" )
        $sRet = " WHERE ";
    else
        $sRet = $sWhere .  " AND ";

    $sRet = $sRet . " " . $sWhat;
    return $sRet;
}
function PhpAdMentor_GetBanner($bid, $gifurl, $xsize, $ysize )
{
        global $sPhpAdMentor_InstallPath;
        if ($xsize != 0 )
            $xsizestring = "width='$xsize'";
        if ($ysize != 0 )
            $ysizestring = "height='$ysize'";

        $sClickUrl = $sPhpAdMentor_InstallPath . "click.php?mgr=aspcode.net&id=" . $bid;
        return "<a href='$sClickUrl'><img border='0' src='$gifurl' $xsizestring $ysizestring></a>";
}

function PhpAdMentor_GetHTMLBanner( $htmlcode )
{
//Replace with special tags...
$htmlcode = stripslashes($htmlcode);

srand ((double) microtime() * 1000000);

$lastrandom ="";

$nOffset = 0;
while ( $posstart = strpos($htmlcode, "<ADM_RANDOM", $nOffset ) )
    {
//                echo($posstart);
    //Found one, now we need to find end tag
    $posend = strpos( $htmlcode, ">", $posstart+1 );
    if ( !$posend )
        break;
//                echo($posend);
    $len = $posend-$posstart;
    $wholetag = substr($htmlcode, $posstart, $len+1  );
    if ($wholetag == "<ADM_RANDOM-LAST>" )
        {
        $left = substr($htmlcode,0,$posstart);
        $right =substr($htmlcode,$posend+1);
        $htmlcode =$left . $lastrandom . $right;
        }
    else
        {
        $vArr = split( "-", $htmlcode );
        $leftnum = $vArr[1];
        $rightnum = $vArr[2];
        $lastrandom = rand(  $leftnum, $rightnum );
        $left = substr($htmlcode,0,$posstart);
        $right =substr($htmlcode,$posend+1);
        $htmlcode =$left . $lastrandom . $right;
        }
    }
return $htmlcode;
}


function PhpAdMentor_GetAd( $sZones, $nAdPos, $nBannerId = 0, $conn=0 )
{
    global $sPhpAdMentor_DBHost;
    global $sPhpAdMentor_DBUser;
    global  $sPhpAdMentor_DBPassword;
    global $sPhpAdMentor_DBDatabase;
    global $sPhpAdMentor_DefaultBanner;
    global $sPhpAdMentor_InstallPath;

    $sSQL = "";
    $sWhere = "";

    if ( $conn== 0)
        $connadmentor = mysql_pconnect($sPhpAdMentor_DBHost, $sPhpAdMentor_DBUser, $sPhpAdMentor_DBPassword);
    else
        $connadmentor = $conn;

    $sSQL =     "select distinct banner.bannerid as bannerid, gifurl, ishtml, htmlcode ";
    $sSQL = $sSQL . " from $sPhpAdMentor_DBDatabase.banner ";

    if (  $nBannerId != 0 )
        $sWhere = AdSQL_AddAndWhere( $sWhere, "banner.bannerid=" . $nBannerId );
    else
        {
        if( $sZones != "" )
            {
            $sSQL = $sSQL . ",$sPhpAdMentor_DBDatabase.banzone ";
            $sWhere = AdSQL_AddAndWhere( $sWhere, "banner.bannerid=banzone.bannerid" );
            $sWhere = AdSQL_AddAndWhere( $sWhere, "banzone.zoneid in ( " . $sZones . ")" );
            }
        if ( $nAdPos != 0 )
            {
            $sWhere = AdSQL_AddAndWhere( $sWhere, "banner.farmid=" . $nAdPos );
            }

        $sWhere = AdSQL_AddAndWhere( $sWhere, "weight > 0 and showcount < maximpressions AND validtodate >= now() AND validfromdate <= now()" );
        $sWhere = AdSQL_AddAndWhere( $sWhere, " (( ishtml=1 ) OR ( clickcount < maxclicks ) )"  );
        }

    $sSQL = $sSQL . $sWhere;
    $sSQL = $sSQL . " ORDER BY weight * RAND() limit 0,1";

    $oRS = mysql_query( $sSQL, $connadmentor );
    if ( mysql_num_rows($oRS) == 0 )
        {
        //default
        $sClickUrl = $sPhpAdMentor_InstallPath . "click.php?mgr=aspcode.net&id=-1";
        return "<a href='$sClickUrl'><img border='0' src='$sPhpAdMentor_DefaultBanner'></a>";
        }
    else
        {
        $row = mysql_fetch_array($oRS);
        //Simply generate the banner html
        if ($row["ishtml"] == 1 )
            {
            $htmlcode = PhpAdMentor_GetHTMLBanner($row["htmlcode"]);
            PhpAdMentor_UpdateStats( $connadmentor, $row["bannerid"], false,true );
            return $htmlcode;
            }

        $htmlcode = PhpAdMentor_GetBanner( $row["bannerid"], $row["gifurl"], $row["xsize"], $row["ysize"]  );
        PhpAdMentor_UpdateStats( $connadmentor, $row["bannerid"], false,true );
        return $htmlcode;
        }
}






?>
