<?
require("phpadmentor_config.php");

if ( $id == -1 )
    $redirurl = $sPhpAdMentor_DefaultClick;
else
    {
    //Find the url...
    $conn = PhpAdMentor_GetDatabaseConn();
    $sSQL = "select redirurl from banner where bannerid=$id ";
    $oRS = mysql_db_query( $sPhpAdMentor_DBDatabase, $sSQL, $conn );
    if ( mysql_num_rows($oRS) == 0 )
        {
        $redirurl = $sPhpAdMentor_DefaultClick;
        }
    else
        {
        $row = mysql_fetch_array($oRS);
        $redirurl = $row["redirurl"];
        //Update stats
        PhpAdMentor_UpdateStats( $conn, $id, true, false );
        }
    }
//echo($redirurl);
header("Location: $redirurl");
?>