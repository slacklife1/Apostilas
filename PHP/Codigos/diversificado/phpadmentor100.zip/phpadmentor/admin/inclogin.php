<?
$g_sUser_Name = "";
$g_fUser_Admin = false;
$g_sUser_Fullname  = "";
$g_sUser_FldAuto = 0;

function DBUserCheck2( $SessionId )
{
global $g_sUser_Name,$g_sUser_Password,$g_fUser_Admin,$g_sUser_Fullname, $g_sUser_FldAuto;

mysql_query("DELETE FROM admin_session WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(lastused) > 43200");

$sSQL = "select * from admin_session where sessionid='$SessionId' ";
$oRS = mysql_query($sSQL);
if ( ! ($row = mysql_fetch_array($oRS)) )
    {
    LoginForm();
    exit();
    }
$fldAuto = $row["sessiondata"];
$sSQL = "select * from user where fldAuto='$fldAuto' ";
$oRS = mysql_query($sSQL);
if ( ! ($row = mysql_fetch_array($oRS)) )
    {
    LoginForm();
    exit();
    }
$g_sUser_Name = $username;
if ( $row["admin"] == 1 )
    $g_fUser_Admin = true;
$g_sUser_Fullname = $row["fullname"];
$g_sUser_FldAuto = $row["fldAuto"];
}


//User management
function DBUserCheck( $username, $password )
{
global $g_sUser_Name,$g_sUser_Password,$g_fUser_Admin,$g_sUser_Fullname, $g_sUser_FldAuto, $g_fUser_Admin;
mysql_query("DELETE FROM admin_session WHERE UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(lastused) > 43200");

$sSQL = "select * from user where name='$username' ";
$sSQL = $sSQL . " and pwd='$password'";
$oRS = mysql_query($sSQL);
if ( ! ($row = mysql_fetch_array($oRS)) )
    {
    LoginForm();
    exit();
    }
$g_sUser_Name = $username;
if ( $row["admin"] == 1 )
    $g_fUser_Admin = true;
$g_sUser_Fullname = $row["fullname"];
$g_sUser_FldAuto = $row["fldAuto"];
}

function LoginForm()
{
    global $sContent, $sHeader;

    $sContent = $sContent. "<b>Login:</b><p>\n";
    $sContent = $sContent. "<form action=index.php method=post><input type=hidden name=action value=login>\n";
    $sContent = $sContent. "Username: <input type=text name=loginusername size=20><p>\n";
    $sContent = $sContent. "Password: <input type=password name=loginuserpassword size=20><p>\n";
    $sContent = $sContent. "<input type=submit value=Submit></form><p>\n";
    PhpAdMentor_WriteContent( $sHeader, $sContent );
    exit();
}

?>