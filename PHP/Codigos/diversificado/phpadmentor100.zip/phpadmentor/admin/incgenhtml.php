<?

function ListBanners()
{
    $sRet = "";
    $oRS = mysql_query("select name, bannerid from banner")  ;
    while( $row = mysql_fetch_array($oRS) )
        {
        $name =$row["name"];
        $thisid=$row["bannerid"];
        $sRet =  $sRet . "<option ";
        $sRet = $sRet . "value=\"$thisid\">$name</option>";
        }
    return $sRet;
}



function GenHTML()
{
    global $sHeader;
    global $sContent;
    global $action;
    global $farmid, $zones, $bannerid;
    global $sPhpAdMentor_InstallPath;
    $sHeader = "Generate PHP code to insert into your pages";

    if ( trim($farmid) != "" )
        {
        //Something selected
        if ( isset($zones ))
        foreach($zones as $key => $val)
            {
            if ( $hej != "" )
                $hej = $hej . ",";
            $hej = $hej . $val;
            }

        if ( $bannerid == "" )
            $bannerid = 0;
        $ainclude = "/filepath/to/phpadmentor_config.php";
        $sContent = $sContent . "Make sure you have included phpadmentor_config.php like this<br><textarea rows=5 cols=60>require(\"$ainclude\")</textarea>";
        $sContent = $sContent . "<br><br>Then where you want the banner just <br><textarea rows=5 cols=60>echo(PhpAdMentor_GetAd(\"$hej\", $farmid, $bannerid) );</textarea>";
        }
    else
        {
        $sContent = $sContent . "                        <form method=\"POST\" action=\"index.php\">
        <input type=hidden name=action value=\"$action\">
                            <table border=\"0\" bgcolor=\"#000000\" cellpadding=\"1\" cellspacing=\"0\" width=\"80%\"><tr><td>
                            <center>
                            <table bgcolor=\"#ffffff\"  border=\"0\" cellpadding=\"0\" cellspacing=\"2\" width=\"100%\">
                                <tr>
                                  <td width=\"482\"><b>Ad position ( size of banner ):</b></td>
                                  <td width=\"191\">&nbsp;
                                    <p><select size=\"1\" name=\"farmid\">" .
                              ListFarms( -1 );
        $sContent = $sContent . "</select></p>
                                    <p>&nbsp;</td>
                                </tr>
                                <tr>
                                  <td valign=\"top\" width=\"482\"><b>
                              Zones to target:</b></td>
                                  <td width=\"191\"><select size=\"5\" name=\"zones[]\" multiple>" .
                              ListZones(-1) . "
                              </select>
                                    <p>&nbsp;</td>
                                </tr>
                                <tr>
                                  <td valign=\"top\" width=\"482\"><b>Select a specific banner ( all
                                    other stuff won't be used ):</b></td>
                                  <td width=\"191\"><select size=\"5\" name=\"bannerid\">
                              &nbsp;" .
                              ListBanners() . "
                              </select>
                                    <p>&nbsp;</td>
                                </tr>
                                <tr>
                                  <td width=\"482\"><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></td>
                                  <td width=\"191\"></td>
                                </tr>
                              </table>
                            </center>
                             </td></tr></table>
                            </form>
                                ";
    }
    return $sContent;

}



?>