<?
function PhpAdMentor_WriteMenuItem( $sRef, $sText )
{
    echo( "<img src=\"box.gif\"><a href=\"$sRef\"><font color=#000066 size=\"1\" face=\"Arial,Helvetica\"> $sText </font></a><br>");
}


function PhpAdMentor_AdAdminWriteMenu()
{
    global $g_fUser_Admin;
    echo( "<b>AdMentor Menu</b><br>" );
    PhpAdMentor_WriteMenuItem(     "index.php?action=myaccount", "My account" );
    if ( $g_fUser_Admin == true )
        {
        PhpAdMentor_WriteMenuItem(     "index.php?action=advertisers", "Advertisers" );
        PhpAdMentor_WriteMenuItem (    "index.php?action=zones", "Zones" );
        PhpAdMentor_WriteMenuItem (    "index.php?action=adpos", "Ad positions" );
        PhpAdMentor_WriteMenuItem (    "index.php?action=campaigns", "Campaigns/creatives" );
        PhpAdMentor_WriteMenuItem (    "index.php?action=genhtml", "Generate HTML code" );
        }
    PhpAdMentor_WriteMenuItem (    "index.php?action=reports", "Reports" );
}

function PhpAdMentor_WriteContent( $sHeader, $sContent )
{
?>
<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>PhpAdMentor - Admin interface</title>
<style type="text/css">
<!--
     body {  font-family: Arial, Geneva, Helvetica, Verdana; font-size: smaller; color: #000000}
     td {  font-family: Arial, Geneva, Helvetica, Verdana; font-size: smaller; color: #000000}
     th {  font-family: Arial, Geneva, Helvetica, Verdana; font-size: smaller; color: #000000}
     A:link {text-decoration: none;}
     A:visited {text-decoration: none;}
     A:hover {text-decoration: underline;}
-->
</style>
</head>

<body>

<table align="center" bgColor="#ECECD9" border="0" cellPadding="3" cellSpacing="0" height="100%" width="100%">
  <tbody>
    <tr>
      <td vAlign="top" width="50%" height="60">
      <img src="administration.gif" border="0" alt="">
      </td>
      <td vAlign="top" width="468" height="60">
      <b><font face="verdana,arial,helvetica" size="+2"><?echo($sHeader);?></font></b>
      <table border="0" width="100%">
        <tr>
                            <td width="50%">
                            </td>
        </tr>
      </table>
      </td>
    </tr>
    <tr>
      <td height="100%" vAlign="top" width="100%" colspan="2">
        <table align="center" bgColor="#ffffff" border="0" cellPadding="0" cellSpacing="0" height="100%" width="100%">
          <tbody>
            <tr>
              <td height="100%" vAlign="top" width="85%">
                <table bgColor="#ffffff" border="0" cellPadding="10" cellSpacing="0" height="100%" width="100%">
                  <tbody>
                    <tr>
                      <td align="left" height="100%" vAlign="top" width="65%">
                        <table border="0" width="100%">
                          <tr>
                            <td width="50%"><b><font color="#aa3333" face="verdana,arial,helvetica" size="4">Welcome <%=Session("fullname")%></font></b>

                            </td>
                            <td width="50%">
                            </td>
                          </tr>
                        </table>
                        <font color="#aa3333" face="verdana,arial,helvetica" size="+2">
                        <hr color="#000066" noShade SIZE="1">

                        </font>

                        <table border="0" width="100%">
                          <tr>
                            <td width="120" valign="top">
                              <? PhpAdMentor_AdAdminWriteMenu(); ?></td>
                            <td width="70%">
                        <?echo($sContent);?>

                        <p><font face="helvetica, arial" size="2">AdMentor is
                        developed by <a href="http://www.aspcode.net">ASPCode.net</a>. Usage of it is totally free.</font></td>
                          </tr>
                        </table>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
  </tbody>
</table>

</body>

</html>
<?
}
?>