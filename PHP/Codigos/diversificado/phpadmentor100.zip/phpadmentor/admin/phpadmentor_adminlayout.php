<?

function PhpAdMentor_login($username, $password)
{
        setcookie("PhpAdMentor_Cookie_User", $username, time() + 3600);
        setcookie("PhpAdMentor_Cookie_Pass", $password, time() + 3600);
        header("Location: index.php");
        exit;
}

function PhpAdMentor_html_header($title)
{
        // open header file - replace %title% in the file with whatever title is
        include("header.html");
         return "";
}

function PhpAdMentor_html_footer()
{
        include("footer.html");
         return "";
}

?>