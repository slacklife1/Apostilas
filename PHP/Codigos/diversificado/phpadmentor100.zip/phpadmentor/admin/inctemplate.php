<?
function PhpAdMentor_WriteMenuItem( $sRef, $sText )
{
    echo( "<img src=\"box.gif\"><a href=\"$sRef\"><font color=#000066 size=\"1\" face=\"Arial,Helvetica\"> $sText </font></a><br>");
}


function PhpAdMentor_AdAdminWriteMenu()
{
    global $g_fUser_Admin;
    echo( "<b>AdMentor Menu</b><br>" );
    PhpAdMentor_WriteMenuItem(     "index.php?action=myaccount", "My account" );
    if ( $g_fUser_Admin == true )
        {
        PhpAdMentor_WriteMenuItem(     "index.php?action=advertisers", "Advertisers" );
        PhpAdMentor_WriteMenuItem (    "index.php?action=zones", "Zones" );
        PhpAdMentor_WriteMenuItem (    "index.php?action=adpos", "Ad positions" );
        PhpAdMentor_WriteMenuItem (    "index.php?action=campaigns", "Campaigns/creatives" );
        PhpAdMentor_WriteMenuItem (    "index.php?action=genhtml", "Generate HTML code" );
        }
    PhpAdMentor_WriteMenuItem (    "index.php?action=reports", "Reports" );
    PhpAdMentor_WriteMenuItem (    "index.php?action=logout", "Logout" );
}

function PhpAdMentor_WriteContent( $sHeader, $sContent )
{
?>
<html>

<head>
<meta http-equiv="Content-Language" content="sv">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<LINK
href="style.css" rel=stylesheet type=text/css>
<title>PhpAdMentor</title>

        </head>

<body>
<table align="center" bgColor="#A9C0D8" border="0" cellPadding="3" cellSpacing="0"
height="100%" width="100%">
<tr>
<td align="center" colspan=2></td>
</tr>
  <tr>
    <td vAlign="top"><font color="#660000" face="Tahoma,Verdana,Arial" size="+3"><b>PhpAdMentor</b></font><br>
    <b><font size="4"><?echo($sHeader);?></font></b></td>
    <td vAlign="middle" width="468">
    </td>
  </tr>
  <tr>
    <td colspan="2">
<TABLE bgColor=black border=0 cellPadding=1 cellSpacing=0 width="100%">
  <TR>
    <TD>
      <TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
        <TBODY>
        <TR bgColor=#eeeeaa>
          <TD><B><FONT face="Arial,Helvetica,sans serif" size=2>�</FONT></B><b><font face="Arial,Helvetica" size="2"></font></b></TD><!-- Search Form -->
          <TD align=right vAlign=baseline>
          </TD></TR></TBODY></TABLE></TD>
          </TR></TABLE>
    </td>
  </tr>
  <tr>
    <td height="100%" vAlign="top" width="100%" colspan="2"><table align="center"
    bgColor="#ffffff" border="0" cellSpacing="1" height="100%" width="100%">
<tbody>
      <tr>
        <td height="100%" vAlign="top"><table bgColor="#ffffff" border="0"
        cellPadding="10" cellSpacing="0" height="100%" width="100%">
<tbody>
          <tr>
            <td align="left" vAlign="top"><? PhpAdMentor_AdAdminWriteMenu(); ?></td>
            <td align="left" vAlign="top"><? echo($sContent); ?></td>
          </tr>
          <tr>
            <td align="left" vAlign="top">
              <p align="center"></p>
            </td>
          </tr>
</tbody>
        </table>
        </td>
      </tr>
</tbody>
    </table>
    </td>
  </tr>
  <tr>
    <td height="100%" vAlign="top" width="100%" colspan="2">
    </td>
  </tr>
</table>
<br><br><br>
</body>

</html>
<?php
}
?>
