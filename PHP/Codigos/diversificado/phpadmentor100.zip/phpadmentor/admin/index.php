<?
require("../phpadmentor_config.php");
require("inctemplate.php");
require("inclogin.php");
require("inccampaign.php");
require("incgenhtml.php");
require("increports.php");


$sContent = "";
$sHeader = "";

$conn = PhpAdMentor_GetDatabaseConn();


//Check if we are logged in etc
if ($action=="login" )
    {
    $loginusername = trim($loginusername);
    $loginuserpassword = trim($loginuserpassword);
    //Try to login
    DBUserCheck($loginusername, $loginuserpassword);
    $PhpAdMentor_SessionID = uniqid("adm");
    $oRS = mysql_query("insert into admin_session(sessionid, sessiondata) values ('$PhpAdMentor_SessionID', '$g_sUser_FldAuto')");
    setcookie("PhpAdMentor_SessionID", $PhpAdMentor_SessionID, time() + 3600);
    header("Location: index.php");
    }

//Are we logged on?
$PhpAdMentor_SessionID = trim($PhpAdMentor_SessionID);
if ( $PhpAdMentor_SessionID == "" )
    {
    LoginForm();
    }

//Try to log on
DBUserCheck2($PhpAdMentor_SessionID );


//AdPos
function AdPos()
{
global $id, $action, $g_fUser_Admin, $Save;
global $name, $descr;
$sError = "";
$sRet = "";

if ( $Save == "yes" )
    {
    //Lets update...
    if ( $action == "deladpos")
        {
        $oRS = mysql_query("delete from adposition where adposid=$id"  );
        header("Location: index.php?action=adpos");
        exit;
        }
    if ( $action == "editadpos")
        {
        if ( $sError == "" )
            {
            $sSQL = "update adposition set adposname='$name', adposdescr='$descr'";
           $sSQL = $sSQL . " where adposid=$id ";
            $oRS =mysql_query($sSQL  );
        header("Location: index.php?action=adpos");
           }
        }
    if ( $action == "newadpos")
        {
            $sSQL = "insert into adposition ( adposname , adposdescr  ) values('$name', '$descr')";
            $oRS =mysql_query($sSQL  );
            $id = mysql_insert_ID();
        header("Location: index.php?action=adpos");
        }
    }
if ( $sError == "" && $id <> "" )
    {
    $oRS = mysql_query("select * from adposition where adposid=$id"  );
     $row = mysql_fetch_array($oRS);
     $name = $row["adposname"];
     $descr = $row["adposdescr"];
    }
$sRet = $sRet . "<table border=0 width=100%>";
if ( $Save == "yes" && $name != "" && $sError == "" )
    {
    $sRet = $sRet . "<tr><td width=22%></td><td width=78%><font color=#008000 size=1>Changes saved OK</font></td></tr>";
    }

$sRet = $sRet . "<form method=POST action=index.php>";
$sRet = $sRet . "<input type=hidden name=id value=$id>";
$sRet = $sRet . "<input type=hidden name=Save value=yes>";
$sRet = $sRet . "<input type=hidden name=action value=$action>";
if ( $action=="deladpos" )
    {
        $sRet = $sRet . "<tr>
                                       <td width=\"22%\"></td>
                                        <td width=\"78%\"><font size=\"3\" color=\"#FF0000\">Delete: Are you sure???</font>&nbsp;</td>
                                      </tr>";
    }
else
    {
      $sRet = $sRet . "<tr>
                                        <td width=\"22%\"><b>Name</b>:</td>
                                        <td width=\"78%\"><input type=\"text\" name=\"name\" size=\"25\" value=\"$name\">
                                        </td>
                                      </tr>";
      $sRet = $sRet . "<tr>
                                        <td width=\"22%\"><b>Description</b>:</td>
                                        <td width=\"78%\"><input type=\"text\" name=\"descr\" size=\"25\" value=\"$descr\">
                                        </td>
                                      </tr>";
    }
$sRet = $sRet ."<tr><td colspan=2><p><input type=\"submit\" value=\"Submit\" name=\"B1\"></p></td></tr>";
$sRet = $sRet . "</form></table>";

//    }
return $sRet;
}




//Zone
function Zone()
{
global $id, $action, $g_fUser_Admin, $Save;
global $name, $descr;
$sError = "";
$sRet = "";

if ( $Save == "yes" )
    {
    //Lets update...
    if ( $action == "delzone")
        {
        $oRS = mysql_query("delete from zone where zoneid=$id"  );
        header("Location: index.php?action=zones");
        exit;
        }
    if ( $action == "editzone")
        {
        if ( $sError == "" )
            {
            $sSQL = "update zone set zonename='$name', zonedescr='$descr'";
           $sSQL = $sSQL . " where zoneid=$id ";
            $oRS =mysql_query($sSQL  );
        header("Location: index.php?action=zones");
           }
        }
    if ( $action == "newzone")
        {
            $sSQL = "insert into zone ( zonename , zonedescr  ) values('$name', '$descr')";
            $oRS =mysql_query($sSQL  );
            $id = mysql_insert_ID();
            $action="editzone";
        header("Location: index.php?action=zones");
        }
    }
if ( $sError == "" && $id <> "" )
    {
    $oRS = mysql_query("select * from zone where zoneid=$id"  );
     $row = mysql_fetch_array($oRS);
     $name = $row["zonename"];
     $descr = $row["zonedescr"];
    }
$sRet = $sRet . "<table border=0 width=100%>";
if ( $Save == "yes" && $name != "" && $sError == "" )
    {
    $sRet = $sRet . "<tr><td width=22%></td><td width=78%><font color=#008000 size=1>Changes saved OK</font></td></tr>";
    }

$sRet = $sRet . "<form method=POST action=index.php>";
$sRet = $sRet . "<input type=hidden name=id value=$id>";
$sRet = $sRet . "<input type=hidden name=Save value=yes>";
$sRet = $sRet . "<input type=hidden name=action value=$action>";
if ( $action=="delzone" )
    {
        $sRet = $sRet . "<tr>
                                       <td width=\"22%\"></td>
                                        <td width=\"78%\"><font size=\"3\" color=\"#FF0000\">Delete: Are you sure???</font>&nbsp;</td>
                                      </tr>";
    }
else
    {
      $sRet = $sRet . "<tr>
                                        <td width=\"22%\"><b>Name</b>:</td>
                                        <td width=\"78%\"><input type=\"text\" name=\"name\" size=\"25\" value=\"$name\">
                                        </td>
                                      </tr>";
      $sRet = $sRet . "<tr>
                                        <td width=\"22%\"><b>Description</b>:</td>
                                        <td width=\"78%\"><input type=\"text\" name=\"descr\" size=\"25\" value=\"$descr\">
                                        </td>
                                      </tr>";
    }
$sRet = $sRet ."<tr><td colspan=2><p><input type=\"submit\" value=\"Submit\" name=\"B1\"></p></td></tr>";
$sRet = $sRet . "</form></table>";

//    }
return $sRet;
}

function MyAccount()
{
global $id, $action, $g_fUser_Admin, $Save, $g_sUser_FldAuto;
global $name, $pwdnew, $pwdnew2, $emailaddress, $fullname, $admin, $oldname;
$sError = "";
$sRet = "";

$id = $g_sUser_FldAuto;

if ( $Save == "yes" )
    {
    //Lets update...
    //Verify
   if (( trim($pwdnew)<>"" || trim($pwdnew2)<>"")  && ( $pwdnew2 != $pwdnew ))
    $sError = "PasswordError";
    if ( $sError == "" )
        {
        $sSQL = "update user set ";
        if ( isset($name) && $g_fUser_Admin )
            $sSQL = $sSQL . " name='$name', ";
        if ( trim($pwdnew)<>""  )
            $sSQL = $sSQL . " pwd='$pwdnew', ";
        $sSQL = $sSQL . " emailaddress='$emailaddress', ";
        if ( $admin == "" )
            $admin = 0;
        $sSQL = $sSQL . " fullname='$fullname ' ";
       $sSQL = $sSQL . " where fldAuto=$id ";
//       echo($sSQL);
        $oRS =mysql_query($sSQL  );
       }
    }
if ( $sError == "" && $id <> "" )
    {
    $oRS = mysql_query("select * from user where fldAuto=$id"  );
     $row = mysql_fetch_array($oRS);
     $name = $row["name"];
     $oldname = $name;
     $pwd = $row["pwd"];
     $admin = $row["admin"];
     $emailaddress = $row["emailaddress"];
     $fullname = $row["fullname"];
    }
$sRet = $sRet . "<table border=0 width=100%>";
if ( $Save == "yes" && $name != "" && $sError == "" )
    {
    $sRet = $sRet . "<tr><td width=22%></td><td width=78%><font color=#008000 size=1>Changes saved OK</font></td></tr>";
    }

$sRet = $sRet . "<form method=POST action=index.php>";
$sRet = $sRet . "<input type=hidden name=id value=$id>";
$sRet = $sRet . "<input type=hidden name=Save value=yes>";
$sRet = $sRet . "<input type=hidden name=action value=$action>";
$sRet = $sRet . "<input type=hidden name=oldname value=\"$oldname\">";
$sRet = $sRet . "<tr><td width=22%><b>Userid</b>:</td>";
$sRet = $sRet . "<td width=78%>$name</td>";
$sRet = $sRet . "</tr>";
if (  $sError == "PasswordError" )
    $sRet = $sRet . "<tr>
                                   <td width=\"22%\"></td>
                                    <td width=\"78%\"><font size=\"1\" color=\"#FF0000\">Password
                                      and password again not identical</font>&nbsp;</td>
                                  </tr>";

  $sRet = $sRet . "<tr>
                                    <td width=\"22%\"><b>New password</b>:</td>
                                    <td width=\"78%\"><input type=\"password\" name=\"pwdnew\" size=\"15\">
                                      <font size=\"1\">(Leave empty if you want to
                                      keep your old password )</font></td>
                                  </tr>";
  $sRet = $sRet ."<tr>
                                    <td width=\"22%\"><b>New password again</b>:</td>
                                    <td width=\"78%\"><input type=\"password\" name=\"pwdnew2\" size=\"15\"><font size=\"1\">(Leave
                                      empty if you want to keep your old
   password )</font></td></tr>";
$sRet = $sRet ."<tr>
                                    <td width=\"22%\"><b>Email address:</b></td>
                                    <td width=\"78%\"><input type=\"text\" name=\"emailaddress\" size=\"40\" value=\"$emailaddress\"></td>
                                  </tr>
                                  <tr>
                                    <td width=\"22%\"><b>Full name:</b><b> </b></td>
                                    <td width=\"78%\"><input type=\"text\" name=\"fullname\" size=\"40\" value=\"$fullname\"></td>
                                  </tr>
                                ";
$sRet = $sRet ."<tr><td colspan=2><p><input type=\"submit\" value=\"Submit\" name=\"B1\"></p></td></tr>";
$sRet = $sRet . "</form></table>";

return $sRet;
}


//Advertiser
function Advertiser()
{
global $id, $action, $g_fUser_Admin, $Save;
global $name, $pwdnew, $pwdnew2, $emailaddress, $fullname, $admin, $oldname;
$sError = "";
$sRet = "";

if ( $Save == "yes" )
    {
    //Lets update...
    if ( $action == "deladvertiser")
        {
        $oRS = mysql_query("delete from user where fldAuto=$id"  );
        header("Location: index.php?action=advertisers");
        exit;
        }
    if ( $action == "editadvertiser")
        {
        //Verify
        if (( trim($pwdnew)<>"" || trim($pwdnew2)<>"")  && ( $pwdnew2 != $pwdnew ))
            $sError = "PasswordError";
        if ( $g_fUser_Admin && !isset($name) )
            $sError = "NameError";
       //Check so name is not taken...
        $oRS =mysql_query("select count(*) as antal from user where name='$name' and fldAuto <> $id"  );
        $row = mysql_fetch_array($oRS);
        if ($row["antal"] > 0 )
            $sError = "NameTaken";
        if ( $sError == "" )
            {
            $sSQL = "update user set ";
            if ( isset($name) && $g_fUser_Admin )
                $sSQL = $sSQL . " name='$name', ";
            if ( trim($pwdnew)<>""  )
                $sSQL = $sSQL . " pwd='$pwdnew', ";
            $sSQL = $sSQL . " emailaddress='$emailaddress', ";
            if ( $admin == "" )
                $admin = 0;
            if ( isset($admin) || $g_fUser_Admin )
                $sSQL = $sSQL . " admin=$admin, ";
            $sSQL = $sSQL . " fullname='$fullname ' ";
           $sSQL = $sSQL . " where fldAuto=$id ";
//           echo($sSQL);
            $oRS =mysql_query($sSQL  );
           }
        }
    if ( $action == "newadvertiser")
        {
        //Verify
        if (( trim($pwdnew)<>"" || trim($pwdnew2)<>"")  && ( $pwdnew2 != $pwdnew ))
            $sError = "PasswordError";
        if ( $g_fUser_Admin && !isset($name) )
            $sError = "NameError";
       //Check so name is not taken...
        $oRS =mysql_query("select count(*) as antal from user where name='$name'"  );
        $row = mysql_fetch_array($oRS);
        if ($row["antal"] > 0 )
            $sError = "NameTaken";
        if ( $sError == "" )
            {
            if ( $admin == "" )
                $admin = 0;
            $sSQL = "insert into user ( name , pwd , admin , emailaddress , fullname  ) values('$name', '$pwdnew', '$admin', '$emailaddress', '$fullname')";
            $oRS =mysql_query($sSQL  );
//            echo($sSQL);
            $id = mysql_insert_ID();
            $action="editadvertiser";
           }
        }
    }
if ( $sError == "" && $id <> "" )
    {
    $oRS = mysql_query("select * from user where fldAuto=$id"  );
     $row = mysql_fetch_array($oRS);
     $name = $row["name"];
     $oldname = $name;
     $pwd = $row["pwd"];
     $admin = $row["admin"];
     $emailaddress = $row["emailaddress"];
     $fullname = $row["fullname"];
    }
$sRet = $sRet . "<table border=0 width=100%>";
if ( $sError == "NameTaken" )
    {
    $sRet = $sRet . "<tr>";
    $sRet = $sRet . "<td width=22%></td>";
    $sRet = $sRet . "<td width=78%><font color=#FF0000 size=1>User id is already used by someone else</font></td>";
    $sRet = $sRet . "</tr>";
    }
if ( $sError == "NameError" )
    {
    $sRet = $sRet . "<tr>";
    $sRet = $sRet . "<td width=22%></td>";
    $sRet = $sRet . "<td width=78%><font color=#FF0000 size=1>User id must be specified</font></td>";
    $sRet = $sRet . "</tr>";
    }
if ( $Save == "yes" && $name != "" && $sError == "" )
    {
    $sRet = $sRet . "<tr><td width=22%></td><td width=78%><font color=#008000 size=1>Changes saved OK</font></td></tr>";
    }

$sRet = $sRet . "<form method=POST action=index.php>";
$sRet = $sRet . "<input type=hidden name=id value=$id>";
$sRet = $sRet . "<input type=hidden name=Save value=yes>";
$sRet = $sRet . "<input type=hidden name=action value=$action>";
$sRet = $sRet . "<input type=hidden name=oldname value=\"$oldname\">";
$sRet = $sRet . "<tr><td width=22%><b>Userid</b>:</td>";
if ( $g_fUser_Admin && $action!="deladvertiser")
    $sRet = $sRet . "<td width=\"78%\"><input type=\"text\" name=\"name\" size=\"15\" value=\"$name\" ></td>";
else
    $sRet = $sRet . "<td width=78%>$name</td>";
$sRet = $sRet . "</tr>";
if ( $action=="deladvertiser" )
    {
        $sRet = $sRet . "<tr>
                                       <td width=\"22%\"></td>
                                        <td width=\"78%\"><font size=\"3\" color=\"#FF0000\">Delete: Are you sure???</font>&nbsp;</td>
                                      </tr>";
    }
else
    {
    if (  $sError == "PasswordError" )
        $sRet = $sRet . "<tr>
                                       <td width=\"22%\"></td>
                                        <td width=\"78%\"><font size=\"1\" color=\"#FF0000\">Password
                                          and password again not identical</font>&nbsp;</td>
                                      </tr>";

      $sRet = $sRet . "<tr>
                                        <td width=\"22%\"><b>New password</b>:</td>
                                        <td width=\"78%\"><input type=\"password\" name=\"pwdnew\" size=\"15\">
                                          <font size=\"1\">(Leave empty if you want to
                                          keep your old password )</font></td>
                                      </tr>";
      $sRet = $sRet ."<tr>
                                        <td width=\"22%\"><b>New password again</b>:</td>
                                        <td width=\"78%\"><input type=\"password\" name=\"pwdnew2\" size=\"15\"><font size=\"1\">(Leave
                                          empty if you want to keep your old
       password )</font></td></tr>";
    $admincheck = "";
    if ($admin)
        $admincheck = " CHECKED ";
    if ( $g_fUser_Admin )
        $sRet = $sRet ."<tr>
                                        <td width=\"22%\"><b>Admin rights:</b></td>
                                        <td width=\"78%\"><input type=\"checkbox\" name=\"admin\" value=\"1\" $admincheck></td>
                                      </tr>";
    $sRet = $sRet ."<tr>
                                        <td width=\"22%\"><b>Email address:</b></td>
                                        <td width=\"78%\"><input type=\"text\" name=\"emailaddress\" size=\"40\" value=\"$emailaddress\"></td>
                                      </tr>
                                      <tr>
                                        <td width=\"22%\"><b>Full name:</b><b> </b></td>
                                        <td width=\"78%\"><input type=\"text\" name=\"fullname\" size=\"40\" value=\"$fullname\"></td>
                                      </tr>
                                    ";
    }
$sRet = $sRet ."<tr><td colspan=2><p><input type=\"submit\" value=\"Submit\" name=\"B1\"></p></td></tr>";
$sRet = $sRet . "</form></table>";

//    }
return $sRet;
}


//Default formul�ret...
if ( $action == "" )
    {
    $sHeader = "Admin interface";
    $sContent = "Welcome to PhpAdMentor!";
    }
if ( $action == "newadvertiser" )
    {
    $sHeader = "New advertiser";
    $sContent = Advertiser();
    }
if ( $action == "editadvertiser" )
    {
    $sHeader = "Edit advertiser";
    $sContent = Advertiser();
    }
if ( $action == "deladvertiser" )
    {
    $sHeader = "Delete advertiser";
    $sContent = Advertiser();
    }
if ( $action == "myaccount" )
    {
    $sHeader = "My account";
    $sContent = MyAccount();
    }

if ( $action == "advertisers" )
    {
    $sHeader = "Advertisers/Users";
    $sContent = "<div align=\"right\"><a href=\"index.php?action=newadvertiser\"><img border=0 src=\"addnewaccount.gif\"></a></div>";
    $sContent = $sContent ."<hr color=#000066 noShade SIZE=1>";
    //List all
    $sContent = $sContent ."<div align=center>";
    $sContent = $sContent ."<table border=\"0\" bgcolor=\"#000000\" cellpadding=\"0\" cellspacing=\"0\"><tr><td>";
    $sContent = $sContent ."<center>";
    $sContent = $sContent ."<table border=0 cellpadding=2 cellspacing=1>";
    $sContent = $sContent ."<tr>";
    $sContent = $sContent ."<td bgcolor=#C0C0C0 ><b>Login name</b></td>";
    $sContent = $sContent ."<td bgcolor=#C0C0C0 ><b>Administrator</b></td>";
    $sContent = $sContent ."<td bgcolor=#C0C0C0 ><b>Full name</b></td>";
    $sContent = $sContent ."<td bgcolor=#C0C0C0 ><b>Action</b></td>";
    $sContent = $sContent ."</tr>";

    $conn = PhpAdMentor_GetDatabaseConn();
    $oRS = mysql_query("select * from user" );
     while ($row = mysql_fetch_array($oRS))
        {
        $id =$row["fldAuto"];
        if ( $row["admin"] == 0 )
            $administrator = "No";
        else
            $administrator = "Yes";
        $sContent = $sContent . "                  <tr>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF>" . $row["name"] . "</td>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF>$administrator</td>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF>" .$row["fullname"] ."</td>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF><a href=\"index.php?action=editadvertiser&id=$id\"><img border=0 src=\"edit.gif\"></a>&nbsp;&nbsp;&nbsp;<a href=\"index.php?action=deladvertiser&id=$id\"><img border=0 src=\"delete.gif\"></a>";
        $sContent = $sContent . "&nbsp;</td></tr>";
        }
    $sContent = $sContent . "</table></div></td></tr></table>";
    }





if ( $action == "newzone" )
    {
    $sHeader = "New zone";
    $sContent = Zone();
    }
if ( $action == "editzone" )
    {
    $sHeader = "Edit zone";
    $sContent = Zone();
    }
if ( $action == "delzone" )
    {
    $sHeader = "Delete zone";
    $sContent = Zone();
    }
if ( $action == "zones" )
    {
    $sHeader = "Zones";
    $sContent = "<div align=\"right\"><a href=\"index.php?action=newzone\"><img border=0 src=\"addnewzone.gif\"></a></div>";
    $sContent = $sContent ."<hr color=#000066 noShade SIZE=1>";
    //List all
    $sContent = $sContent ."<div align=center>";
    $sContent = $sContent ."<table border=\"0\" bgcolor=\"#000000\" cellpadding=\"0\" cellspacing=\"0\"><tr><td>";
    $sContent = $sContent ."<center>";
    $sContent = $sContent ."<table border=0 cellpadding=2 cellspacing=1>";
    $sContent = $sContent ."<tr>";
    $sContent = $sContent ."<td bgcolor=#C0C0C0 ><b>Name</b></td>";
    $sContent = $sContent ."<td bgcolor=#C0C0C0 ><b>Description</b></td>";
    $sContent = $sContent ."<td bgcolor=#C0C0C0 ><b>Action</b></td>";
    $sContent = $sContent ."</tr>";

    $conn = PhpAdMentor_GetDatabaseConn();
    $oRS = mysql_query("select * from zone" );
     while ($row = mysql_fetch_array($oRS))
        {
        $id =$row["zoneid"];
        $sContent = $sContent . "                  <tr>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF>" . $row["zonename"] . "</td>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF>" .$row["zonedescr"] ."</td>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF><a href=\"index.php?action=editzone&id=$id\"><img border=0 src=\"edit.gif\"></a>&nbsp;&nbsp;&nbsp;<a href=\"index.php?action=delzone&id=$id\"><img border=0 src=\"delete.gif\"></a>";
        $sContent = $sContent . "&nbsp;</td></tr>";
        }
    $sContent = $sContent . "</table></div></td></tr></table>";
    }




if ( $action == "newadpos" )
    {
    $sHeader = "New ad position";
    $sContent = AdPos();
    }
if ( $action == "editadpos" )
    {
    $sHeader = "Edit ad position";
    $sContent = AdPos();
    }
if ( $action == "deladpos" )
    {
    $sHeader = "Delete as position";
    $sContent = AdPos();
    }
if ( $action == "adpos" )
    {
    $sHeader = "Ad positions";
    $sContent = "<div align=\"right\"><a href=\"index.php?action=newadpos\"><img border=0 src=\"addnewfarm.gif\"></a></div>";
    $sContent = $sContent ."<hr color=#000066 noShade SIZE=1>";
    //List all
    $sContent = $sContent ."<div align=center>";
    $sContent = $sContent ."<table border=\"0\" bgcolor=\"#000000\" cellpadding=\"0\" cellspacing=\"0\"><tr><td>";
    $sContent = $sContent ."<center>";
    $sContent = $sContent ."<table border=0 cellpadding=2 cellspacing=1>";
    $sContent = $sContent ."<tr>";
    $sContent = $sContent ."<td bgcolor=#C0C0C0 ><b>Name</b></td>";
    $sContent = $sContent ."<td bgcolor=#C0C0C0 ><b>Description</b></td>";
    $sContent = $sContent ."<td bgcolor=#C0C0C0 ><b>Action</b></td>";
    $sContent = $sContent ."</tr>";

    $conn = PhpAdMentor_GetDatabaseConn();
    $oRS = mysql_query("select * from adposition" );
     while ($row = mysql_fetch_array($oRS))
        {
        $id =$row["adposid"];
        $sContent = $sContent . "                  <tr>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF>" . $row["adposname"] . "</td>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF>" .$row["adposdescr"] ."</td>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF><a href=\"index.php?action=editadpos&id=$id\"><img border=0 src=\"edit.gif\"></a>&nbsp;&nbsp;&nbsp;<a href=\"index.php?action=deladpos&id=$id\"><img border=0 src=\"delete.gif\"></a>";
        $sContent = $sContent . "&nbsp;</td></tr>";
        }
    $sContent = $sContent . "</table></div></td></tr></table>";
    }


if ( $action == "genhtml" )
    {
    $sHeader = "Generate the PHP code";
    $sContent = GenHTML();
    }
if ( $action == "reports" )
    {
    $sHeader = "Reports";
    $sContent = Show_Reports();
    }
if ( $action == "reportsresult" )
    {
    $sHeader = "Reports";
    $sContent = Show_Reports();
    }




if ( $action == "newcampaign" )
    {
    $sHeader = "New campaign";
    $sContent = Campaign();
    }
if ( $action == "editcampaign" )
    {
    $sHeader = "Edit campaign";
    $sContent = Campaign();
    }
if ( $action == "delcampaign" )
    {
    $sHeader = "Delete campaign";
    $sContent = Campaign();
    }
if ( $action == "campaigns" )
    {
    $sHeader = "Campaigns";
    $sContent = Campaigns();
    }

if ( $action == "showbannerpop" )
    {
    $sHeader = "Show campaign";
    $sContent = Campaigns_ShowBannerPop();
    }
if ( $action=="logout")
    {
    $sHeader = "Logged out";
    $sContent = "PhpAdMentor";
    $g_sUser_Name = "";
    $g_fUser_Admin = false;
    $g_sUser_Fullname  = "";
    $g_sUser_FldAuto = 0;
    $conn = PhpAdMentor_GetDatabaseConn();
    mysql_query("delete from admin_session where sessionid ='$PhpAdMentor_SessionID'" );
    }




PhpAdMentor_WriteContent( $sHeader, $sContent );
?>