<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Help</title>
</head>

<body>
<?

switch( $id )
    {
    case "ban_name":
        $sRubrik = "Banner name";
        $sText = "Just a name of your banner to help you identify it. Use anything you'd like";
        break;
    case "ban_redir":
        $sRubrik = "Banner redir url";
        $sText = "The url where to send the visitor when he/she clicks on the banner.
<b>Remember to include the http:// part!</b> ";
        break;

    case "ban_pic":
        $sRubrik = "Banner picture url";
        $sText = "The url to the banner picture. <b>Remember to include the http:// part!</b> ";
        break;
    case "ban_weight":
        $sRubrik = "Banner weight";
        $sText = "A numeric value. Anything goes. Weight is relative to other banners weight and therefore the HIGHER value the MORE impressions will it get";
        break;
    case "ban_width":
        $sRubrik = "Banner width";
        $sText = "A numeric value. Ex 468 for a regular banner";
        break;
    case "ban_height":
        $sRubrik = "Banner height";
        $sText = "A numeric value. Ex 60 for a regular banner";
        break;
    case "ban_html":
        $sRubrik  = "Use with IFRAME as well ";
        $sText = "If you want this campaign to be used with IFRAME-supporting browsers ( IE 3.0 or higher )" ;
        break;

    case "ban_geninfo":
        $sRubrik  = "General info";
        $sText = "Regular img/src banners can be used with all types of browsers ( if you click the 'Use with IFRAME as well ).<br><br>" ;
        $sText = $sText & "HTML banners will only be used with IFRAME enables browsers ( IE 3.0 or higher )" ;
        break;
    case "ban_specialtags":
        $sRubrik  = "Special tags";
        $sText = "There are some special<br>tags you can use whereever in your HTML<br>code that will be switched:<br><br>";
        $sText = $sText . "<b>&lt;ADM_RANDOM-XXX-YYY&gt;</b><br>";
        $sText = $sText . "This will be changed to a random number between XXX and YYY<br><br>";
        $sText = $sText . "<b>&lt;ADM_RANDOM-LAST&gt;</b><br>";
        $sText = $sText . "This will be changed to the same number as last time<br>" ;
        break;
    default:
        $sRubrik = "Not implemented yet";
        $sText = "This help topic is not implemented yet";
    }
?>
<H2><? echo($sRubrik); ?></H2>
<?echo($sText);?>
</body>

</html>