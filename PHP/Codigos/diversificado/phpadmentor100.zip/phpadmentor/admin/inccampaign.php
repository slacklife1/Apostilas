<?
function Campaigns_ShowBannerPop()
{
global $id, $action, $g_fUser_Admin, $Save, $html, $g_sUser_FldAuto;

$sSQL ="select * from banner where bannerid=$id";
if ($g_fUser_Admin == false )
    $sSQL = $sSQL . " AND advid=$g_sUser_FldAuto";

$oRS = mysql_query( $sSQL );
 $row = mysql_fetch_array($oRS);
 $redirurl = $row["redirurl"];
 $gifurl = $row["gifurl"];
 $weight = $row["weight"];
 $alttext = $row["alttext"];
 $showcount = $row["showcount"];
 $clickcount = $row["clickcount"];
 $farmid = $row["farmid"];
 $xsize = $row["xsize"];
 $ysize = $row["ysize"];
 $validtodate = $row["validtodate"];
 $maxclicks = $row["maxclicks"];
 $maximpressions = $row["maximpressions"];
 $validfromdate = $row["validfromdate"];
 $htmlcode = stripslashes($row["htmlcode"]);
 $ishtml = $row["ishtml"];
 $html=$ishtml;
 $advid = $row["advid"];
 $name = $row["name"];
 $descr = $row["adposdescr"];

$showbannercode = "Here ";
if ( $html == 1 )
    {
    $showbannercode = PhpAdMentor_GetHTMLBanner($htmlcode);
    //$showbannercode = $htmlcode;
    }
else
    {
    $showbannercode = PhpAdMentor_GetBanner( $id, $gifurl, $xsize, $ysize  );
    }
return $showbannercode;
}

function Campaigns()
{
//    global $sHeader;
//    global $sContent;
//    $sHeader = "Ad campaigns";
    $sContent = "<div align=\"right\"><a href=\"index.php?action=newcampaign\"><img border=0 src=\"addnewcampaign.gif\"></a>  <a href=\"index.php?action=newcampaign&html=1\"><img border=0 src=\"addnewhtmlcampaign.gif\"></a></div>";
    $sContent = $sContent ."<hr color=#000066 noShade SIZE=1>";
    //List all
    $sContent = $sContent ."<div align=center>";
    $sContent = $sContent ."<table border=\"0\" bgcolor=\"#000000\" cellpadding=\"0\" cellspacing=\"0\"><tr><td>";
    $sContent = $sContent ."<center>";
    $sContent = $sContent ."<table border=0 cellpadding=2 cellspacing=1>";
    $sContent = $sContent . "                          <tr>
                            <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\"><b> Campaign </b></td>
                            <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\"><b> Weight </td>
                            <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\"><b> Impressions </b></td>
                            <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\" ><b> Clicks </b></td>
                            <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\"><b> Ad position </b></td>
                            <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\"><b> Zones </b></td>
                            <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\"><b> Action </b></td>
                          </tr>";

    $oRS = mysql_query("select * from banner" );
     while ($row = mysql_fetch_array($oRS))
        {
        if (  $row["ishtml"] == 1 )
            $clickcount="N/A (HTML)";
        else
            $clickcount=$row["clickcount"];
        $id =$row["bannerid"];
        $sContent = $sContent . "                  <tr>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF>" . $row["name"] . "</td>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF>" .$row["weight"] ."</td>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF>" .$row["showcount"] ."</td>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF>" .$clickcount ."</td>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF>" .AdPosForBanner($id) ."</td>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF>" .ZonesForBanner($id) ."</td>";
        $sContent = $sContent . "<td bgcolor=#FFFFFF><a href=\"index.php?action=editcampaign&id=$id\"><img border=0 src=\"edit.gif\"></a>&nbsp;&nbsp;&nbsp;<a href=\"index.php?action=delcampaign&id=$id\"><img border=0 src=\"delete.gif\"></a>";
        $sContent = $sContent . "&nbsp;</td></tr>";
        }
    $sContent = $sContent . "</table></div></td></tr></table>";
    return $sContent;
}

function AdPosForBanner($bannerid)
{
    $sRet = "";
    $oRS = mysql_query("select adposid, adposname from adposition, banner where banner.farmid=adposition.adposid and banner.bannerid=$bannerid"  );
    $row = mysql_fetch_array($oRS);
    return $row["adposname"];
}

function ZonesForBanner($bannerid)
{
    $sRet = "";
    $oRS = mysql_query("select zonename from zone,banzone,banner where banner.bannerid=banzone.bannerid and banzone.zoneid=zone.zoneid and  banner.bannerid=$bannerid"  );
    while ( $row = mysql_fetch_array($oRS) )
        {
        if ( $sRet != "" )
            $sRet = $sRet . "<br>";
        $sRet = $sRet .    $row["zonename"];
        }
    return $sRet;
}


function ListFarms($farmid)
{
    $sRet = "";
    $oRS = mysql_query("select * from adposition order by adposname"  );
    while($row = mysql_fetch_array($oRS) )
        {
        $sRet =  $sRet . "<option ";
        $name =$row["adposname"];
        $thisid=$row["adposid"];
        if ( $farmid == $thisid )
            $sRet = $sRet . "selected=\"yes\" ";
        $sRet = $sRet . "value=\"$thisid\">$name</option>";
        }
    return $sRet;
}

function GetZoneString( $nBannerId )
{
    $sRet = "";
    $oRS = mysql_query("select zoneid from banzone where bannerid = $nBannerId"  );
    while($row = mysql_fetch_array($oRS) )
        {
        if ( $sRet != "" )
            $sRet = $sRet . ",";
        $sRet = $sRet . $row["zoneid"];
    }
    return $sRet;
}

function ArrContains( $sArr, $nVal )
{
    for ($k=0; $k<count($sArr); $k++)
        if ( intval($nVal) == intval($sArr[$k]) )
            return true;
    return false;
}


function ListZones( $sZones )
{
   $sRet = "";
    $sArr = split( ",", $sZones);


    $oRS = mysql_query("select * from zone order by zoneid"  );
    while($row = mysql_fetch_array($oRS) )
        {
        $sRet = $sRet . "<option ";
        $name =$row["zonename"];
        $thisid=$row["zoneid"];

        if ( ArrContains( $sArr, $thisid ) )
            $sRet = $sRet . "selected=\"yes\" ";
        $sRet = $sRet . "value=\"$thisid\">$name</option>";
        }
    return $sRet;
}


function ListUsers($advid)
{
    $sRet = "";
    $oRS = mysql_query("select * from user order by name"  );
    while($row = mysql_fetch_array($oRS) )
        {
        $sRet =  $sRet . "<option ";
        $name =$row["name"];
        $thisid=$row["fldAuto"];
        if ( $advid    == $thisid )
            $sRet = $sRet . "selected=\"yes\" ";
        $sRet = $sRet . "value=\"$thisid\">$name</option>";
        }
    return $sRet;
}

function myislong($var )
{
if ( !is_numeric($var))
    return false;
$newhaystack = "_".$var;
if (strpos($newhaystack, ".")) {return false; }
return true;
}

function Campaign_Validate()
{
global $id, $action, $g_fUser_Admin, $Save, $html;
global $sPhpAdMentor_MaxInt, $sPhpAdMentor_MaxDate;
global $name, $redirurl, $gifurl,$weight, $alttext, $showcount,$clickcount,$farmid,$xsize, $ysize, $validtodate, $maxclicks, $maximpressions, $validfromdate, $htmlcode, $ishtml, $advid ;
if ( trim($name) == "" )
    return  "Name_Error";

if ( $html == 1 )
    {
     if ( trim($htmlcode) == "" )
        return "Htmlcode_Error";
    //
    }
else
     {
     if ( trim($redirurl) == "" )
        return "Redirurl_Error";
     if ( trim($gifurl) == "" )
        return "Gif_Error";
     }
if ( trim($weight) == "" )
        return "Weight_Error";
if ( !myislong($weight))
    return "Weight_Error";

if ( trim($validtodate) == "" )
    $validtodate = "2020-01-01";
if ( trim($validfromdate) == "" )
    $validfromdate = date("Y-m-d");
if ( trim($maximpressions) == ""  )
    $maximpressions = $sPhpAdMentor_MaxInt;
if ( !myislong($maximpressions))
    return "MaxImpressions_Error";
if ( trim($maxclicks) == ""  )
    $maxclicks = $sPhpAdMentor_MaxInt;
if ( !myislong($maxclicks))
    return "MaxClicks_Error";
if ( trim($xsize) == "" )
    $xsize = 0;
if ( trim($ysize) == "" )
    $ysize = 0;
return $sError;
}



//Campaign
function Campaign()
{
global $id, $action, $g_fUser_Admin, $Save, $html;
global $name, $redirurl, $gifurl,$weight, $alttext, $showcount,$clickcount,$farmid,$xsize, $ysize, $validtodate, $maxclicks, $maximpressions, $validfromdate, $htmlcode, $ishtml, $advid, $zones ;
$sError = "";
$sRet = "<script language=\"JavaScript\">
<!-- hide from JavaScript-challenged browsers
function openWindow(url) {
  popupWin = window.open(url,'new_page','width=400,height=400')
}
// done hiding -->
</script>
";

if ( $Save == "yes" )
    {
    //Lets update...
    if ( $action == "delcampaign")
        {
        mysql_query("delete from banner where bannerid=$id"  );
        mysql_query("delete from banzone where bannerid=$id"  );
        header("Location: index.php?action=campaigns");
        exit;
        }
    if ( $action == "editcampaign")
        {
        //Validate...
        $sError = Campaign_Validate();
        if ( $sError == "" )
            {
            if ( $html != 1 )
                {
                $sSQL = "update banner set name='$name', gifurl='$gifurl', redirurl='$redirurl', weight=$weight,farmid=$farmid, xsize=$xsize, ysize=$ysize, validtodate='$validtodate', validfromdate='$validfromdate', maxclicks=$maxclicks, maximpressions=$maximpressions, advid= $advid ";
                }
            else
                {
                $dbhtmlcode = addslashes($htmlcode);
                $sSQL = "update banner set name='$name', weight=$weight,farmid=$farmid, validtodate='$validtodate', validfromdate='$validfromdate', maxclicks=$maxclicks, maximpressions=$maximpressions, advid= $advid, htmlcode='$dbhtmlcode' ";
                }

           $sSQL = $sSQL . " where bannerid=$id ";
            $oRS =mysql_query($sSQL  );

           $sSQL = " delete from  banzone where bannerid=$id";
            mysql_query($sSQL  );

    if($zones)
        {
        foreach($zones as $key => $val)
            {
            if($val == '')
                {
                array_pop($zones);
                }
            else {
                continue;
                }
            }
        foreach($zones as $val)
            {
            mysql_query( "insert into banzone(bannerid, zoneid) values($id, $val) " );
            }
        }


        header("Location: index.php?action=campaigns");
           }
        }
    if ( $action == "newcampaign")
        {
            //First of all some validation...
        $sError = Campaign_Validate();
        if ( $sError == "" )
            {
            if ( $html != 1 )
                {
                $sSQL = "insert into banner ( name, gifurl, redirurl, weight,farmid, xsize, ysize, validtodate, validfromdate, maxclicks, maximpressions, ishtml, advid  ) values('$name', '$gifurl', '$redirurl', $weight, $farmid, $xsize, $ysize, '$validtodate', '$validfromdate', $maxclicks, $maximpressions, 0, $advid )";
                }
            else
                {
                $dbhtmlcode = addslashes($htmlcode);
                $sSQL = "insert into banner ( name, weight,farmid, validtodate, validfromdate, maxclicks, maximpressions, ishtml, advid, htmlcode  ) values('$name',  $weight, $farmid, '$validtodate', '$validfromdate', $maxclicks, $maximpressions, 1, $advid, '$dbhtmlcode' )";
                }

            $oRS =mysql_query($sSQL  );
            $id = mysql_insert_ID();

    if($zones)
        {
        foreach($zones as $key => $val)
            {
            if($val == '')
                {
                array_pop($zones);
                }
            else {
                continue;
                }
            }
        foreach($zones as $val)
            {
            mysql_query( "insert into banzone(bannerid, zoneid) values($id, $val) " );
            }
        }

            header("Location: index.php?action=campaigns");
            }
        }
    }
if ( $sError == "" && $id <> "" )
    {
    $oRS = mysql_query("select * from banner where bannerid=$id"  );
     $row = mysql_fetch_array($oRS);
     $redirurl = $row["redirurl"];
     $gifurl = $row["gifurl"];
     $weight = $row["weight"];
     $alttext = $row["alttext"];
     $showcount = $row["showcount"];
     $clickcount = $row["clickcount"];
     $farmid = $row["farmid"];
     $xsize = $row["xsize"];
     $ysize = $row["ysize"];
     $validtodate = $row["validtodate"];
     $maxclicks = $row["maxclicks"];
     $maximpressions = $row["maximpressions"];
     $validfromdate = $row["validfromdate"];
     $htmlcode = stripslashes($row["htmlcode"]);
     $ishtml = $row["ishtml"];
     $html=$ishtml;
     $advid = $row["advid"];
     $name = $row["name"];
     $descr = $row["adposdescr"];
     $sZoneString =GetZoneString($id);
    }
if ( $sError == "Name_Error" )
    $Name_Error = "<font size=\"1\" color=\"#FF0000\"><br>Name can't be blank</font>&nbsp;";
if ( $sError == "Redirurl_Error" )
    $Redir_Error = "<font size=\"1\" color=\"#FF0000\"><br>Redir url can't be blank</font>&nbsp;";
if ( $sError == "Gif_Error" )
    $Gif_Error = "<font size=\"1\" color=\"#FF0000\"><br>Picture url can't be blank</font>&nbsp;";
if ( $sError == "Weight_Error" )
    $Weight_Error = "<font size=\"1\" color=\"#FF0000\"><br>Weight must be numeric</font>&nbsp;";
if ( $sError == "MaxImpressions_Error" )
    $Maximpressions_Error = "<font size=\"1\" color=\"#FF0000\"><br>Maximpressions must be numeric</font>&nbsp;";
if ( $sError == "MaxClicks_Error" )
    $Maxclicks_Error = "<font size=\"1\" color=\"#FF0000\"><br>Maxclicks must be numeric</font>&nbsp;";
if ( $sError == "Htmlcode_Error" )
    $Htmlcode_Error = "<font size=\"1\" color=\"#FF0000\"><br>HTML Code can't be empty</font>&nbsp;";
$sRet = $sRet . "<table border=0 width=100%>";
if ( $Save == "yes" && $name != "" && $sError == "" )
    {
    $sRet = $sRet . "<tr><td width=22%></td><td width=78%><font color=#008000 size=1>Changes saved OK</font></td></tr>";
    }


$showbannercode = "Here ";
if ( $html == 1 )
    {
    $showbannercode = PhpAdMentor_GetHTMLBanner($htmlcode);
    //$showbannercode = $htmlcode;
    }
else
    {
    $showbannercode = PhpAdMentor_GetBanner( $id, $gifurl, $xsize, $ysize  );
    }

$sRet = $sRet . "<tr><td width=100% align=center>$showbannercode</td><td></td></tr>";

$sRet = $sRet . "<form method=POST action=index.php>";
$sRet = $sRet . "<input type=hidden name=id value=$id>";
$sRet = $sRet . "<input type=hidden name=Save value=yes>";
$sRet = $sRet . "<input type=hidden name=action value=$action>";
$sRet = $sRet . "<input type=hidden name=html value=$html>";
if ( $action=="delcampaign" )
    {
        $sRet = $sRet . "<tr>
                                       <td width=\"99%\"><font size=\"3\" color=\"#FF0000\">Delete banner $name: Are you sure???</font>&nbsp;</td>
                                        <td width=\"1%\"></td>
                                      </tr>
                                  <tr>
                                    <td width=\"99%\"><input type=\"submit\" value=\"Yes, delete it!\" name=\"B1\">
                                    <td width=\"1%\">&nbsp;</td>
                                    </td>
                                  </tr>";
    }
else
    {
      $sRet = $sRet . "
                                    <table border=0 cellspacing=0 width=80% align=\"center\">
                                    <tr>
                                    <td bgcolor=#000000 align=center>
                                <table border=\"0\" width=\"100%\" cellpadding=\"2\" cellspacing=\"0\" bgcolor=\"#ffffff\">
                                  <tr>
                                    <td width=\"90%\" colspan=\"2\" bgcolor=\"#AA3333\"><b><font color=\"#FFFFFF\">GENERAL
                                      INFO</font></b></td>
                                  </tr>
                                  <tr>
                                    <td width=\"29%\"><b>Name</b>: <a href=\"javascript:openWindow('help.php?id=ban_name')\"> <img border=\"0\" src=\"QuestionButton.gif\"></a>$Name_Error</td>
                                    <td width=\"61%\"><input type=\"text\" name=\"name\" size=\"20\" value=\"$name\"></td>
                                  </tr>";
if ( $html != 1 )
    $sRet = $sRet . "<tr>
                                    <td width=\"29%\"><b>Redir url</b>: <a href=\"javascript:openWindow('help.php?id=ban_redir')\"> <img border=\"0\" src=\"QuestionButton.gif\"></a>$Redir_Error</td>
                                    <td width=\"61%\"><input type=\"text\" name=\"redirurl\" size=\"30\" value=\"$redirurl\"></td>
                                  </tr>
                                  <tr>
                                    <td width=\"29%\"><b>Picture url: </b><a href=\"javascript:openWindow('help.php?id=ban_pic')\"><img border=\"0\" src=\"QuestionButton.gif\"></a>$Gif_Error</td>
                                    <td width=\"61%\"><input type=\"text\" name=\"gifurl\" size=\"30\" value=\"$gifurl\"></td>
                                  </tr>
                                  <tr>
                                    <td width=\"29%\"><b>Width:&nbsp; </b><a href=\"javascript:openWindow('help.php?id=ban_width')\"><img border=\"0\" src=\"QuestionButton.gif\" width=\"14\" height=\"13\"></a></td>
                                    <td width=\"61%\"><input type=\"text\" name=\"xsize\" size=\"7\" value=\"$xsize\"></td>
                                  </tr>
                                  <tr>
                                    <td width=\"29%\"><b>Height: </b><a href=\"javascript:openWindow('help.php?id=ban_height')\"><img border=\"0\" src=\"QuestionButton.gif\"></a></td>
                                    <td width=\"61%\"><input type=\"text\" name=\"ysize\" size=\"7\" value=\"$ysize\"></td>
                                  </tr>";

else
    $sRet = $sRet . "<tr>
                                    <td width=\"90%\" colspan=\"2\"><font size=\"1\">You can specify any HTML
                                      tags/JavaScript etc you'd like.&nbsp;&nbsp;</font></td>
                                  </tr>
                                  <tr>
                                    <td width=\"29%\" valign=\"top\"><b>HTMLCode: </b><a href=\"javascript:openWindow('help.php?id=ban_specialtags')\"><img border=\"0\" src=\"specialtags.gif\"></a>
                                    $Htmlcode_Error</td>
                                    <td width=\"61%\">
                                    <textarea rows=\"10\" name=\"htmlcode\" cols=\"40\">$htmlcode</textarea>
                                    </td>
                                  </tr>";
$sRet = $sRet . "<tr>
                                    <td width=\"29%\"><b>Weight</b><b>: </b><a href=\"javascript:openWindow('help.php?id=ban_weight')\"><img border=\"0\" src=\"QuestionButton.gif\"></a>$Weight_Error</td>
                                    <td width=\"61%\"><input type=\"text\" name=\"weight\" size=\"7\" value=\"$weight\"></td>
                                  </tr>
                                  <tr>
                                    <td width=\"29%\"><b>Farm id:&nbsp; </b></td>
                                    <td width=\"61%\"><select size=\"1\" name=\"farmid\">" . ListFarms($farmid) . "
                                      </select></td>
                                  </tr>
                                  <tr>
                                    <td width=\"29%\"><b>User id:&nbsp; </b></td>
                                    <td width=\"61%\"><select size=\"1\" name=\"advid\">" . ListUsers($advid) . "
                                      </select></td>
                                  </tr>
                                  <tr>
                                    <td width=\"90%\" bgcolor=\"#AA3333\" colspan=\"2\"><b><font color=\"#FFFFFF\">VALID THROUGH INFO</font></b></td>
                                  </tr>
                                  <tr>
                                    <td width=\"90%\" colspan=\"2\"><font size=\"1\">If you
                                      specify none then it is always valid. If
                                      you specify more than one, then it is
                                      valid until the first one of the
                                      conditions that triggers.</font></td>
                                  </tr>
                                  <tr>
                                    <td width=\"29%\"><b>Valid dates:</b></td>
                                    <td width=\"61%\">From:<input type=\"text\" name=\"validfromdate\" size=\"14\" value=\"$validfromdate\">
                                      To: <input type=\"text\" name=\"validtodate\" size=\"13\" value=\"$validtodate\"></td>
                                  </tr>
                                  <tr>
                                    <td width=\"29%\"><b>Max number of
                                      impressions: </b>$Maximpressions_Error</td>
                                    <td width=\"61%\"><input type=\"text\" name=\"maximpressions\" size=\"20\" value=\"" . PhpAdMentor_MaxIntToNull($maximpressions) . "\">
                                    </td>
                                  </tr>
                                  <tr>
                                    <td width=\"29%\"><b>Max number of clicks:</b>$Maxclicks_Error</td>
                                    <td width=\"61%\"><input type=\"text\" name=\"maxclicks\" size=\"20\" value=\"" . PhpAdMentor_MaxIntToNull($maxclicks) . "\">
                                    </td>
                                  </tr>
                                  <tr>
                                    <td width=\"90%\" bgcolor=\"#AA3333\" colspan=\"2\"><b><font color=\"#FFFFFF\">TARGETING</font></b></td>
                                  </tr>
                                  <tr>
                                    <td width=\"90%\" colspan=\"2\"><font size=\"1\">Select which
                                      so called zones you want the banner in.
                                      This makes it possible to show the banner
                                      only on certain pages etc</font></td>
                                  </tr>
                                  <tr>
                                    <td width=\"29%\"><b>Zones: </b></td>
                                    <td width=\"61%\"><select size=\"4\" name=\"zones[]\" multiple>" .
                                        ListZones( $sZoneString ) . "
                                      </select>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td width=\"29%\">&nbsp;</td>
                                    <td width=\"61%\"><input type=\"submit\" value=\"Save\" name=\"B1\">
                                    </td>
                                  </tr>
                                </table>
                                    </td></tr></table>
                               <p>&nbsp;</p>
                              </form>
"
;
    }
$sRet = $sRet . "</form></table>";

//    }
return $sRet;
}


?>