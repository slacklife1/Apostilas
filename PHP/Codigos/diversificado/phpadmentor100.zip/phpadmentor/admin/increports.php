<?

function Reports_ListZones()
{
    $sRet = Reports_AddOption( "All", -1 );
    $oRS = mysql_query("select * from zone order by zoneid"  );
    while($row = mysql_fetch_array($oRS) )
        {
        $sRet =  $sRet .Reports_AddOption( $row["zonename"], $row["zoneid"] );
        }
    return $sRet;
}


function Reports_ListFarms()
{
    $sRet = Reports_AddOption( "All", -1 );
    $oRS = mysql_query("select * from adposition order by adposname"  );
    while($row = mysql_fetch_array($oRS) )
        {
        $sRet =  $sRet .Reports_AddOption( $row["adposname"], $row["adposid"] );
        }
    return $sRet;
}


function Reports_ListBanners()
{
    global $g_fUser_Admin, $g_sUser_FldAuto;

    $sRet = "";
    $sSQL = "select name, bannerid from banner ";
    if ( $g_fUser_Admin == false )
        $sSQL = $sSQL . "where advid=$g_sUser_FldAuto";

    $oRS = mysql_query($sSQL)  ;
    while( $row = mysql_fetch_array($oRS) )
        {
        $name =$row["name"];
        $thisid=$row["bannerid"];
        $sRet =  $sRet . "<option ";
        $sRet = $sRet . "value=\"$thisid\">$name</option>";
        }
    return $sRet;
}

function Reports_AddOption( $sName, $sValue, $sSelected=false )
{
if ( $sSelected )
    $sSelected2 = " SELECTED ";
return "<option $sSelected2 value=\"$sValue\">$sName</option>";
}

function Reports_ListPeriod( $sWhat )
{
    $sRet = "";
    if ( $sWhat == "year" )
        {
        $oRS = mysql_query("select distinct year(datum) as yea from stats")  ;
        while( $row = mysql_fetch_array($oRS) )
            {
            $sRet = $sRet . Reports_AddOption($row["yea"], $row["yea"], date("y") ==$row["yea"] );
            }
        }
    if ( $sWhat == "month" )
        {
        $sRet = $sRet . Reports_AddOption("Jan", 1, date("m") == 1);
        $sRet = $sRet . Reports_AddOption("Feb", 2, date("m") == 2);
        $sRet = $sRet . Reports_AddOption("Mar", 3, date("m") == 3);
        $sRet = $sRet . Reports_AddOption("Apr", 4, date("m") == 4);
        $sRet = $sRet . Reports_AddOption("May", 5, date("m") == 5);
        $sRet = $sRet . Reports_AddOption("Jun", 6, date("m") == 6);
        $sRet = $sRet . Reports_AddOption("Jul", 7, date("m") == 7);
        $sRet = $sRet . Reports_AddOption("Aug", 8, date("m") == 8);
        $sRet = $sRet . Reports_AddOption("Sep", 9, date("m") == 9);
        $sRet = $sRet . Reports_AddOption("Oct", 10, date("m") == 10);
        $sRet = $sRet . Reports_AddOption("Nov", 11, date("m") == 11);
        $sRet = $sRet . Reports_AddOption("Dec", 12, date("m") == 12);
        }
    if ( $sWhat == "day" )
        {
        for ( $i = 1; $i <= 31; $i++)
            $sRet = $sRet . Reports_AddOption($i, $i, date("d") == $i);
        }
    return $sRet;
}



function Show_Reports()
{
//    global $sHeader;
//    global $sContent;
    global $action;
    global $farmid, $zones, $bannerid, $zone, $year,$month,$day, $year2, $month2,$day2;
    global $sPhpAdMentor_InstallPath, $doreport, $g_sUser_FldAuto, $g_fUser_Admin;
    global $sHeader;
    global $sContent;


    if ( trim($doreport) == "yes" )
        {
        //
        $startdat = $year . "-" . $month . "-" . $day;
        $startdat2 = $year2 . "-" . $month2 . "-" . $day2;
        $sSQL = "select max(banner.name) as bannername, max(banner.ishtml) as ishtml, max(stats.bannerid) as bannerid,  max(adposition.adposname) as adposname, max(stats.datum) as datum, sum(stats.clicks) as clicks,
                sum(stats.impressions) as impressions from stats, banner, adposition where banner.farmid=adposition.adposid AND banner.bannerid=stats.bannerid ";
        if ( $bannerid != "" )
            $sSQL =$sSQL . " AND banner.bannerid=$bannerid";
        else
            {
            if ( $farmid != -1 )
                $sSQL =$sSQL . " AND banner.farmid=$farmid";
            }
        if ( $g_fUser_Admin == false )
            $sSQL = $sSQL . " AND banner.advid=$g_sUser_FldAuto ";

        $sSQL =$sSQL . " AND datum >='$startdat' and datum <='$startdat2' ";
        $sSQL =$sSQL . "                  group by stats.datum, stats.bannerid order by datum";
//        echo($sSQL);
        //List it...
        $sRet = $sRet ."<div align=center>";
        $sRet = $sRet ."<table border=\"0\" bgcolor=\"#000000\" cellpadding=\"0\" cellspacing=\"0\"><tr><td>";
        $sRet = $sRet ."<center>";
        $sRet = $sRet ."<table border=0 cellpadding=2 cellspacing=1>";
        $sRet = $sRet . "                          <tr>
                                <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\"><b> Date </td>
                                <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\"><b> Campaign </b></td>
                                <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\"><b> Ad position </td>
                                <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\"><b> Zones </b></td>
                                <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\"><b> Impressions </b></td>
                                <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\" ><b> Clicks </b></td>
                                <td valign=\"bottom\" nowrap bgcolor=\"#C0C0C0\"><b> Action </b></td>
                              </tr>";
//        echo($sSQL);
        $oRS = mysql_query($sSQL)  ;
        $totalimpr = 0;
        $totalclicks = 0;
        $totalregimp = 0;

         while ($row = mysql_fetch_array($oRS))
            {
            $id =$row["bannerid"];
            if ( $zone != -1 )
                {
                $sSQL2 =" select count(*) as antal from banzone where bannerid=$id AND zoneid=$zone";
                $oRS2 = mysql_query($sSQL2)  ;
                $row2 = mysql_fetch_array($oRS2);
                if ( $row2["antal"]==0 )
                    continue;
                }

            $totalimpr = $totalimpr +  $row["impressions"];
            if (  $row["ishtml"] == 1 )
                $clickcount="N/A (HTML)";
            else
                {
                $clickcount=$row["clicks"];
                $totalclicks = $totalclicks +$row["clicks"];
                $totalregimp = $totalregimp +$row["impressions"];
                }

            $sRet = $sRet . "                  <tr>";
            $sRet = $sRet . "<td bgcolor=#FFFFFF>" . $row["datum"] . "</td>";
            $sRet = $sRet . "<td bgcolor=#FFFFFF>" . $row["bannername"] . "</td>";
            $sRet = $sRet . "<td bgcolor=#FFFFFF>" .$row["adposname"] ."</td>";
            $sRet = $sRet . "<td bgcolor=#FFFFFF>" .ZonesForBanner($id) ."</td>";
            $sRet = $sRet . "<td bgcolor=#FFFFFF>" .$row["impressions"] ."</td>";
            $sRet = $sRet . "<td bgcolor=#FFFFFF>" .$clickcount ."</td>";
            $sRet = $sRet . "<td bgcolor=#FFFFFF>";
            if ( $g_fUser_Admin == true )
                 $sRet = $sRet  . "<a href=\"index.php?action=editcampaign&id=$id\"><img border=0 src=\"edit.gif\"></a>";
            else
                $sRet = $sRet . "<a href=\"index.php?action=showbannerpop&id=$id\">See banner</a>";
            $sRet = $sRet . "&nbsp;</td></tr>";
            }
        $sRet = $sRet . "                  <tr>";
            $sRet = $sRet . "<td bgcolor=#AA9988 colspan=7><b>Total impressions: $totalimpr<br>Impressions with regular(NonHTML) banners: $totalregimp<br>Total clicks: $totalclicks </b></td>";
            $sRet = $sRet . "</tr>";
        $sRet = $sRet . "</table></div></td></tr></table>";

       $sContent = $sRet;
        }
    else
        {
        $sContent = "                     <form method=\"POST\" action=\"index.php\">
        <input type=hidden name=action value=\"$action\">
        <input type=hidden name=doreport value=\"yes\">
                            <center>
                            <table border=\"0\" bgcolor=\"#000000\" cellpadding=\"1\" cellspacing=\"0\" width=\"80%\"><tr><td>
                            <table bgcolor=\"#ffffff\"  border=\"0\" cellpadding=\"0\" cellspacing=\"2\" width=\"100%\">
                                <tr>
                                  <td width=\"482\"><b>Ad position ( size of banner ):</b></td>
                                  <td width=\"191\">&nbsp;
                                    <p><select size=\"1\" name=\"farmid\">" .
                              Reports_ListFarms();
        $sContent = $sContent . "</select></p>
                                    <p>&nbsp;</td>
                                </tr>
                                <tr>
                                  <td valign=\"top\" width=\"482\"><b>
                              Zones:</b></td>
                                  <td width=\"191\"><select size=\"1\" name=\"zone\">" .
                              Reports_ListZones() . "
                              </select>
                                    <p>&nbsp;</td>
                                </tr>
                                <tr>
                                  <td valign=\"top\" width=\"482\"><b>Specific banner ( all
                                    other stuff won't be used ):</b></td>
                                  <td width=\"191\"><select size=\"5\" name=\"bannerid\">
                              &nbsp;" .
                              Reports_ListBanners() . "
                              </select>
                                    <p>&nbsp;</td>
                                </tr>";
$sContent = $sContent . "                                <tr>
                                  <td valign=\"top\"><b>
                              Period start:</b></td>
                                  <td><select size=\"1\" name=\"year\">" .
                              Reports_ListPeriod( "year" ) . "</select>
                                  <select size=\"1\" name=\"month\">" .
                              Reports_ListPeriod( "month" ) . "</select>
                                  <select size=\"1\" name=\"day\">" .
                              Reports_ListPeriod( "day" ) . "
                              </select>
                                    <p>&nbsp;</td>
                                </tr>
                                <tr>
                                  <td valign=\"top\"><b>
                              Period end:</b></td>
                                  <td><select size=\"1\" name=\"year2\">" .
                              Reports_ListPeriod( "year" ) . "</select>
                                  <select size=\"1\" name=\"month2\">" .
                              Reports_ListPeriod( "month" ) . "</select>
                                  <select size=\"1\" name=\"day2\">" .
                              Reports_ListPeriod( "day" ) . "
                              </select>
                                    <p>&nbsp;</td>
                                </tr>";
                    $sContent = $sContent . "            <tr>
                                  <td width=\"482\"><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></td>
                                  <td width=\"191\"></td>
                                </tr>
                              </table>
                                    </td></tr></table>
                               <p>&nbsp;</p>
                            </center>
                            </form>
                                ";
    }
    return $sContent;

}



?>