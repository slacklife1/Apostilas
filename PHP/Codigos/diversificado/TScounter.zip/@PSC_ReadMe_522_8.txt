Title: TScounter 3.12
Description: TScounter is an object oriented counter, which uses session management and ip comparison with a reload restriction to detect the real number of visitors of a website. Most PHP counter only use one of these possibilities to decide, whether to increase the number of total visitors or not if the webpage is requested by somebody. TScounter knows over 100 spiders and robots and does not count them as real visitors. TScounter stores all information in text files.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=522&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
