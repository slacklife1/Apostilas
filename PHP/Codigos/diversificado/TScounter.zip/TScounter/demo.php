<?php


/************************************************
*                                               *
*  TScounter                                    *
*                                               *
*  by Thomas Schuster                           *
*  http://www.TSinter.net                       *
*                                               *
*  file: demo.php                               *
*  version: 3.12                                *
*  license: GNU General Public License          *
*  created: 05.04.2002                          *
*  email: admin@TSinter.net                     *
*                                               *
*                                               *
*  This is an advanced counter in OO-design     *
*  which uses both, session management AND      *
*  ip comparison with a reload restriction,     *
*  to recognize different visitors of a         *
*  website. It recognizes over 100 spiders and  *
*  robots and does not count them as visitors.  *
*  It counts the impressions for every webpage  *
*  of the website.                              *
*                                               *
*  Copyright (c) 2001-2002 TSinter.net          *
*  All rights reserved.                         *
*                                               *
************************************************/



//---------------------------------------------------//
// Set the relative path to the TScounter directory. //
// (ex. "/php/scripts/")                             //
//---------------------------------------------------//
$script_path = "/relative-path/TScounter/";

//---------------------------------------//
// Do not change the following line!     //
//---------------------------------------//
include($DOCUMENT_ROOT.$script_path."config.php");


// Display the actual visitor number.
echo("<b>".$counter->_getNumberOf("visitor")."</b> visitors, ");

// Display the page impressions of the current webpage.
echo("this webpage has been requested <b>".$counter->_getNumberOf("impression")."</b> times.");



?>


<p>&nbsp;</p>
<p>Versucht die folgenden Anweisungen, um die Funktionalt&auml;t von TScounter 
  zu testen:</p>
<p>1.) Ruft diese Webpage einfach noch einmal auf =&gt; nur die Anzahl der Page 
  Impressions wird erh&ouml;ht!!</p>

<p>2.) Deaktiviert Cookies (IE: Extras-&gt;Internet Optionen-&gt;Sicherheit-&gt;Stufe 
  anpassen -&gt;Cookies deaktivieren) und ruft die Seite abermals auf =&gt; es 
  werden wiederum nur die Anzahl der Page Impressions erh&ouml;ht, da du anhand 
  der IP als schon registrierter Besucher erkannt wirst! (Reloadsperre)</p>
<p>3.) (Aktiviere Cookies) Schlie&szlig;e alle Browserfenster und lade die Seite 
  erneut (keine neue Session ID bei erstem Re-Load) =&gt; es werden nur die Anzahl 
  der Page Impressions erh&ouml;ht, da du anhand der IP als schon registrierter 
  Besucher erkannt wirst! =&gt; Rufe die Seite nochmals auf (du erh&auml;lst nun 
  eine Session ID)=&gt; Es werden nur die Page Impressions hochgez&auml;hlt, da 
  deine IP sich ja nicht ge&auml;ndert hat =&gt; Lade die Seite ein drittes Mal 
  =&gt; Du wirst anhand deiner Session ID erkannt und es werden wiederum ur die 
  Page Impression erh&ouml;ht!!</p>
 
<p>4.) Trenne deine Verbindung zum Provider und w&auml;hle dich neu ein (du bekommst 
  eine neue IP) und lade die Seite neu =&gt; es werden erneut nur die Page Impressions 
  hochgez&auml;hlt, da du durch deine Session ID als bereits registrierter Besucher 
  identifiziert wirst!</p>
<p>&nbsp;</p>
<p><a href="http://www.tsinter.net/source/counter/version_3/index.xml?language=de">TScounter</a>&#153; 
  &copy; 2001-2002 <a href="http://www.TSinter.net">TSinter.net</a></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<form action="http://www.hotscripts.com/cgi-bin/rate.cgi" method="POST"><input type="hidden" name="ID" value="13725"><table BORDER="0" CELLSPACING="0" bgcolor="#E2E2E2"><tr>
      <td align="center"><font face="arial, verdana" size="2"><b>Rate My Program</b><br>
        <a href="http://www.hotscripts.com"><small>@ HotScripts.com</small></a></font></td></tr><tr><td align="center"><table border="0" cellspacing="0" width="100%" bgcolor="#FFFFEA"><tr><td><input type="radio" value="5" name="ex_rate"></td><td><font face="arial, verdana" size="2">Excellent!</font></td></tr><tr><td><input type="radio" value="4" name="ex_rate"></td><td><font face="arial, verdana" size="2">Very Good</font></td></tr><tr><td><input type="radio" value="3" name="ex_rate"></td><td><font face="arial, verdana" size="2">Good</font></td></tr><tr><td><input type="radio" value="2" name="ex_rate"></td><td><font face="arial, verdana" size="2">Fair</font></td></tr><tr><td><input type="radio" value="1" name="ex_rate"></td><td><font face="arial, verdana" size="2">Poor</font></td></tr></table></td></tr><tr><td align="center"><input type="submit" value="Cast My Vote!"></td></tr></table></form>


