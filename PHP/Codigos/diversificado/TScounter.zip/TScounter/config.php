<?php

/************************************************
*                                               *
*  TScounter                                    *
*                                               *
*  by Thomas Schuster                           *
*  http://www.TSinter.net                       *
*                                               *
*  file: install.php                            *
*  version: 3.12                                *
*  license: GNU General Public License          *
*  created: 05.04.2002                          *
*  email: admin@TSinter.net                     *
*                                               *
*                                               *
*  This is an advanced counter in OO-design     *
*  which uses both, session management AND      *
*  ip comparison with a reload restriction,     *
*  to recognize different visitors of a         *
*  website. It recognizes over 100 spiders and  *
*  robots and does not count them as visitors.  *
*  It counts the impressions for every webpage  *
*  of the website.                              *
*                                               *
*  Copyright (c) 2001-2002 TSinter.net          *
*  All rights reserved.                         *
*                                               *
************************************************/



//-------------------------------//
// Do not change anything below! //
//-------------------------------//


// If the client browser supports cookies, TScounter will use session management.
session_start();
session_register("cookie");

// Include the classes.
include($DOCUMENT_ROOT.$script_path."class_support.php");
include($DOCUMENT_ROOT.$script_path."class_counter.php");

// Instanciate a new object.
$counter = new TScounter($script_path);

// Process the page request.
$counter->_processPageRequest($counter->_cookieCheck());


?>