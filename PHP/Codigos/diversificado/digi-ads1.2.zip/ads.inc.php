<?php
$ads = array();
$digiAds = array();
$digiAdsTime = time();
$lines = file($digiAdsPath) or die();
foreach ($lines as $line) {
    $line = chop($line);
    if (($line != '') && (!ereg('^#', $line))) {
        if (ereg('^[A-Za-z0-9]+\|\|', $line)) {
            $ads[] = $line;
        } else {
            list ($key, $val) = explode('=', $line);
            $digiAds[$key] = $val;
        }
    }
}
function writeads()
{
    global $digiAdsPath, $ads, $digiAds;
    $data = fopen($digiAdsPath, 'w') or die();
    flock($data, 2) or die();
    fputs($data, @join("\n", $ads)."\n");
    while (list ($key, $val) = each ($digiAds)) {
        if (($key != '') && ($val != '')) {
            fputs($data, $key.'='.$val."\n");
        }
    }
    flock($data, 3);
    fclose($data);
    reset($digiAds);
}
?>