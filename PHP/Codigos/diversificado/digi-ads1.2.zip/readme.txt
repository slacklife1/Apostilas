README file for digi-ads 1.2
http://www.digi-fx.net
andrew@digi-fx.net

//////////////////
//    Files
//////////////////
1.)  admin.php
2.)  ads.inc.php
3.)  ads.php
4.)  click.php
5.)  stats.php
6.)  js.php
7.)  install.php
8.)  upgrade.php
9.)  template.htm
10.) bar.gif
11.) baroff.gif
12.) ads.dat
13.) readme.txt
14.) license.txt

//////////////////
// Requirements
//////////////////
- PHP4

//////////////////
// Installation
//////////////////
1.) Open "admin.php", "ads.php", "click.php", and "stats.php" in a TEXT-ONLY
editor. Notepad or any other editor will suffice. Do not use an HTML editor
or Word.

  Edit the lines that read:
     $digiAdsPath = '/path/to/digi-ads/ads.dat';
     require '/path/to/digi-ads/ads.inc.php';

You should change the absolute paths to mirror your directory structure. It
is recommended that you place "ads.dat" in a directory not accessible from
the web.

2.) Open "js.php" in a TEXT-ONLY editor.

  Edit the line that reads:
     require '/path/to/digi-ads/ads.php';

You should change the absolute path to mirror your directory structure.

3.) Edit "template.htm" to match the look and feel of your web site. This
file is used to render the display of an individual ad's stats. Don't remove
the template variables.

4.) Upload all files, except "upgrade.php", into a directory named "digi-ads".
All files should be uploaded in ASCII mode except for "bar.gif" and
"baroff.gif" which should be uploaded in binary mode. It is recommended that
you place "ads.dat" in a directory not accessible from the web, so not in the
directory "digi-ads".

5.) On UNIX-like operating systems, CHMOD "ads.dat" 777.

6.) Visit "install.php" in your web browser e.g.
http://www.domain.com/digi-ads/install.php and follow the instructions given.

7.) If all goes well in step 6, remove "install.php" immediately.

//////////////////
// Upgrade
//////////////////
1.) Open "admin.php", "ads.php", "click.php", and "stats.php" in a TEXT-ONLY
editor.

  Edit the lines that read:
     $digiAdsPath = '/path/to/digi-ads/ads.dat';
     require '/path/to/digi-ads/ads.inc.php';

You should change the absolute paths to mirror your directory structure.
If you are unsure, look at the first three lines of your old "admin.php",
"ads.php", "click.php", or "stats.php".

2.) Open "js.php" in a TEXT-ONLY editor.

  Edit the line that reads:
     require '/path/to/digi-ads/ads.php';

You should change the absolute path to mirror your directory structure.

3.) Edit "template.htm" to match the look and feel of your web site.

4.) Upload "admin.php", "ads.inc.php", "ads.php", "click.php", "stats.php",
"js.php", "upgrade.php", and "template.htm" to the "digi-ads" directory in
ASCII mode. DO NOT upload "ads.dat".

5.) Visit "upgrade.php" in your web browser e.g.
http://www.domain.com/digi-ads/upgrade.php and follow the instructions given.

6.) If all goes well in step 5, remove "upgrade.php" immediately.

7.) Go to "admin.php", login to the control panel, and edit the configuration.

//////////////////
// Script Usage
//////////////////
1.) Visit "admin.php" in your web browser e.g.
http://www.domain.com/digi-ads/admin.php

2.) Login to the control panel using the following login name and password:
       Login Name: admin
       Password:   1234

3.) Configure the script by clicking on "Configuration".

4.) Ad ads as necessary.

5.) Displaying ads is relatively simple. Visit the "Code Generator" in the
control panel and follow the instructions. When all is done, copy and paste
the code created for you into a file where you'd like the ads displayed.

6.) To display a specified ad's stats, call stats.php with a query string
/stats.php?id=$id where $id equals the unique id of the ad.

//////////////////
//  Thank Yous!
//////////////////
digi-FX would like to thank the following people for their help in making
digi-ads an excellent script:
- Ales Povalac and Arnaud Jacques for their help on security issues.
- Dave (e-mail: clickcraft@aol.com  web: http://www.clickcraft.net) for his
  numerous ideas: javascript invocation, custom ad IDs, and upgrade.php
  and for his help testing digi-ads 1.2.

//////////////////
//  Change Log
//////////////////
Version 1.2 - Security bug fixed.
              Password is hashed in login cookie and ads.dat for added security.
              PHP warning errors don't display anymore.
              Fixed a bug that deleted the configuration data.
              Compatible with register_globals turned off.
              All output is XHTML 1.0 compatible.
              Interface and usability enhancements.
              JavaScript can now be used instead of PHP to display ads.
              Updated the code generator and added the ability to generate JavaScript invocation code.
              Adminstrators can now specify custom ad IDs to mirror large web advertising companies.
              Added an install.php script to properly encrypt passwords for new installs.
              Added an upgrade.php script to facilitate those upgrading from previous versions.

Version 1.1 - Fixed a bug requiring one to have an extra ad in the database.
              Ability to display a specific ad ID has been added.
              A code generator was added to generate the code needed to display ads.

Version 1.0 - Official Release