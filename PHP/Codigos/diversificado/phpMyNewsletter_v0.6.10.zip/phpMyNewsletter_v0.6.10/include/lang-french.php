<?

function translate($phrase) {
 return $phrase;
}




/*function translate($phrase){

switch($phrase) {
	default:	$tmp=$phrase; break;
	}	
return($tmp);
}*/

?>
