<html>
<head> 
<title> Curso PHP </title>
</head>
<body>
<form name="form1" method="POST" action="paridade.php">
<b> Digite um N�mero:</b>
<input  type="text" name="num" size="20" maxlength="10">
<p align ="center">
<input type="submit" name="submit" value="Verificar a Paridade">
</p>
</form>

<?php

# Script desenvolvido por Nicolau Sar�ty
# nicolau@saraty.com.br
# Bacharel em Ci�ncia da Computa��o

//Na parte do HTML o action do formul�rio � a pr�pria p�gina, pois o script roda na mesma 
function paridade($num2){ //declara��o da fun��o que verifica se um n�mero � par ou �mpar

		 if ($num2 % 2 == 0 ){ //se o resto da divis�o der 0 ent�o � par
		 	$Fparidade = "O n�mero [ $num2 ] � par";
		 
		 } else{
		 	$Fparidade = "O n�mero [ $num2 ] � �mpar"; //sen�o � impar
		 
		 }
return $Fparidade; //no final da fun��o sempre ela retornar� um valor.
}
//o in�cio do script
if ($_POST["submit"]){ //verifica se o bot�o da p�gina foi apertado
$var=$_POST["num"]; //a vari�vel $var recebe o valor digitado na p�gina num=nome do campo da p�gina
print paridade($var); //chama a fun��o declarada e passa o parametro $var que na fun��o � $num2

}

?>