<p>Conte quantas vogais tem em uma frase que voc&ecirc; escrever!!</p>
<form name="form1" method="post" action="contavogal.php">
  <p>FRASE: 
    <input name="nome" type="text" id="nome" size="80" maxlength="62">
</p>
  <p>
    <input type="submit" name="Submit" value="Contar">
</p>
</form>

<?php

# Script desenvolvido por Nicolau Sar�ty
# nicolau@saraty.com.br
# Bacharel em Ci�ncia da Computa��o

//Script Para Contar Quantas Vogais Tem Em Uma Frase!!!
$frase=$_POST['nome']; //captura o nome do campo do formul�rio para a vari�vel
$x=strtoupper($frase); //transforma a frase em mai�scula
$a=strlen($x); //conta quantos caracteres tem na frase.
 
for ($i=0;$i<$a;$i++)//percorre a frase caracter a caracter
{
switch($x[$i]) //verifica se cada caracter � uma das vogais do case 
{
case A: $cont=$cont+1; break;
case E: $cont=$cont+1; break; 
case I: $cont=$cont+1; break;
case O: $cont=$cont+1; break;
case U: $cont=$cont+1; break;

}//fim do swicth 
}//fim fo for
if ($cont==0)
{
print"N�o tem Vogal!!";
}
else
{
$aux=$a-$contador-$aux; //faz o c�lculo para saber quantas consoantes tem.
print "A frase $frase tem $cont vogais"; ?><BR><BR><?
print "O n�mero de consoantes �: $aux";
}//fim do programa
?>