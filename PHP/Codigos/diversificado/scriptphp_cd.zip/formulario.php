<html>
<head>
<title> Curso PHP </title>
</head>
<body>
<form name="form1" method="GET" action="formulario.php">
<b> Digite o seu nome:</b>
<input  type="text" name="nome" size="20" maxlength="25">
<p align ="center">
<input type="submit" name="submit" value="ok">
</p>

<?
# Script desenvolvido por Nicolau Sar�ty
# nicolau@saraty.com.br
# Bacharel em Ci�ncia da Computa��o

print $_GET["nome"]; /*Aqui ensina como capturar uma vari�vel de um formul�rio 
             Repare que o que est� dentro do ["nome"] � o nome do campo do formul�rio */
print $nome;  # Impreme na tela o nome que foi digitado							  
?>

</form>
</body>
</html>