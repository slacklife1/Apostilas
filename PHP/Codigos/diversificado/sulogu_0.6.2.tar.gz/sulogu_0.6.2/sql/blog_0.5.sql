CREATE TABLE blog (
  timeid timestamp(12) NOT NULL,
  title varchar(180) default NULL,
  content text default NULL,
  image smallint
) TYPE=MyISAM;

CREATE TABLE blogimages (
  id smallint,
  name varchar(40) NOT NULL,
  description varchar(200) default NULL
) TYPE=MyISAM;