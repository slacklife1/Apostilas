CREATE TABLE blog (
  timeid timestamp(12) NOT NULL,
  title varchar(180) default NULL,
  content text default NULL,
  image smallint
) TYPE=MyISAM;

CREATE TABLE blogimages (
  id smallint,
  name varchar(40) NOT NULL,
  description varchar(200) default NULL
) TYPE=MyISAM;

CREATE TABLE blogcomments (
  timeid timestamp(12) NOT NULL,
  storyid char(12) NOT NULL,
  name varchar(40) default NULL,
  email varchar(40) default NULL,
  url varchar(255) default NULL,
  usrcomment text default NULL,
  ipaddress varchar(15) default NULL,
  hostname varchar(120) default NULL
) TYPE=MyISAM;
