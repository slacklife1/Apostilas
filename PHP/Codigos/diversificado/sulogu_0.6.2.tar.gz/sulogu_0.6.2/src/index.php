<?php

// ####################################################################
// ____________________
// Su Logu - A PHP Blog
// --------------------
//
// (C) 2002, 2003 Fabio Pani
// http://www.fabiopani.it/blog/sulogu.html
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License.
// ####################################################################

include("include/database.php");
include("include/config.php");
include("include/utils.php");
require_once("language/language.php");

// Create a vertical space of $px pixels.
function spacer($px) {
	return "\n<TABLE CELLSPACING=\"0\" CELLPADDING=\"0\" BORDER=\"0\">\n<TR>\n<TD HEIGHT=\"" . $px . "\"><IMG SRC=\"images/pixel.png\" BORDER=\"0\" HEIGHT=\"" . $px . "\"></TD>\n</TR>\n</TABLE>\n\n";
}

// Return the name of the thumbnail file, corresponding to the image identified by $id.
// Rule: if an image file name is, for example, 'image.jpg', the corresponding thumbnail file name will be named 'image_t.jpg'.
// File names must be in the form <name>.<type> and they must contain only one dot '.' character.
function thumbname($id) {
	global $imagedir;

	$sql = "SELECT name FROM blogimages WHERE id = " . $id;
	$res = mysql_query($sql);
	if (mysql_num_rows($res) > 0) {
		$line = mysql_fetch_array($res);
		$name = explode(".", $line['name']);	// only one dot ('.') in the file name
		return $imagedir . $name[0] . "_t." . $name[1];
	}
}

// Return HTML code that defines a thumbnail linked to its full-size image (identified by $id).
// $align = {"left" | "center" | "right"} - specifies the image alignment.
function thumblink($id, $align, $page = 0) {
	global $showall, $language, $fullwidth;

	$res = "<A HREF=\"index.php?imageid=" . $id;
	$res .= "&language=" . $language;
	if ($fullwidth)   { $res .= "&fullwidth=1"; }
	if ($page > 0)   { $res .= "&page=" . $page; }
	if ($showall == 1)   { $res .= "&showall=1"; }
	$res .= "\"><IMG SRC=\"" . thumbname($id) . "\" BORDER=\"0\" ALT=\"\"";
	if ($align)   { $res .= " ALIGN=\"" . $align . "\""; }
	$res .= "></A>\n";
	return $res;
}

// Return a link to a story, using the story title as description.
// $image is not used and it can be used, for example, to show a flag indicating an image associated to this story.
function storytitle($timeid, $title, $image, $shortdate = FALSE) {
	global $language;

	$link = "index.php?timeid=" . $timeid . "&language=" . $language;
	$res = "<SPAN CLASS=\"storylinktitle\"><A HREF=\"" . $link . "\"><STRONG>" . $title . "</STRONG></A>&nbsp;</SPAN>";
	$res .= "<SPAN CLASS=\"storylinkdate\">(<A HREF=\"" . $link . "&tm=1\">" . fmtdatetime($timeid, $shortdate) . "</A>)</SPAN>";
	return $res;
}

// Show titles of the latest stories.
function showlateststories() {
	global $latestnum;

	$sql = "SELECT timeid, title, image FROM blog ";
	$sql .= "WHERE timeid <= '" . gettimestamp12() . "' ";
	$sql .= "ORDER BY timeid DESC LIMIT " . $latestnum;
	$res = mysql_query($sql);
	while ($line = mysql_fetch_array($res)) {
		if ($s)   { $s .= "<BR>\n"; }
		$s .= storytitle($line['timeid'], $line['title'], $line['image'], TRUE);
	}
	print("<BR><BR>\n");
	print("<TABLE CLASS=\"block\" WIDTH=\"100%\" CELLSPACING=\"1\" CELLPADDING=\"2\" BORDER=\"0\">\n");
	print("<TR>\n");
	print("<TD CLASS=\"blocktitle\" ALIGN=\"left\" VALIGN=\"middle\">\n");
	print("<SPAN CLASS=\"leftblockhdrtext\"><STRONG>" . constant("LANG_LATEST") . "</STRONG></SPAN>");
	print("</TD>\n");
	print("</TR>\n");
	print("<TR>\n");
	print("<TD CLASS=\"blockcontent\" ALIGN=\"left\" VALIGN=\"middle\">\n");
	print($s);
	print("</TD>\n");
	print("</TR>\n");
	print("</TABLE>\n");
}

// Show time archive links.
function showtimearchive() {
	global $startyear, $startmonth, $language;

	print("<BR>\n");
	print("<TABLE CLASS=\"block\" WIDTH=\"100%\" CELLSPACING=\"1\" CELLPADDING=\"2\" BORDER=\"0\">\n");
	print("<TR>\n");
	print("<TD CLASS=\"blocktitle\" ALIGN=\"left\" VALIGN=\"middle\">\n");
	print("<SPAN CLASS=\"leftblockhdrtext\"><STRONG>" . constant("LANG_ARCHIVE") . "</STRONG></SPAN>");
	print("</TD>\n");
	print("</TR>\n");
	print("<TR>\n");
	print("<TD CLASS=\"blockcontent\" ALIGN=\"left\" VALIGN=\"middle\">\n");

	// print calendar list of links
	$nowtimestamp = gettimestamp12();
	$year = substr($nowtimestamp, 0, 2);
	$month = substr($nowtimestamp, 2, 2);
	while ($year . $month >= $startyear . $startmonth) {
		if ($s)   { $s .= "<BR>\n"; }
		$s .= "<A HREF=\"index.php?timeid=" . $year . $month . "&language=" . $language . "\">" . monthname($month) . " 20" . $year . "</A>";
		$month--;
		if ($month == 0) {
			$month = "12";
			$year--;
		}
		if (strlen($month) == 1)   { $month = "0" . $month; }
		if (strlen($year) == 1)   { $year = "0" . $year; }
	}
	print("<SPAN CLASS=\"smalltext\">" . $s . "</SPAN>\n");
	print("</TD>\n");
	print("</TR>\n");
	print("</TABLE>\n");
}

// Return the index page for a given image.
function getpageid($id) {
	global $thumbperpage;

	$res = mysql_query("SELECT COUNT(id) AS tot FROM blogimages WHERE id <= " . $id);
	$line = mysql_fetch_array($res);
	return ceil($line['tot'] / $thumbperpage);
}

// Return a navigation menu for images.
function imagenavmenu($id, $page) {
	global $showall, $language;

	$res = mysql_query("SELECT id FROM blogimages WHERE id < " . $id . " ORDER BY id DESC LIMIT 1");
	if (mysql_num_rows($res)) {
		$line = mysql_fetch_array($res);
		$previd = $line['id'];
	}
	if ($showall == 1) {	// link all images
		$res = mysql_query("SELECT id AS imgid FROM blogimages WHERE id > " . $id . " ORDER BY id ASC LIMIT 1");
	} else {	// don't link images related to stories programmed in the future
		$sql = "SELECT blogimages.id AS imgid FROM blogimages, blog ";
		$sql .= "WHERE (id > " . $id . ") AND ";
		$sql .= "(blogimages.id = blog.image) AND ";
		$sql .= "(blog.timeid <= '" . gettimestamp12() . "') ";
		$sql .= "ORDER BY id ASC LIMIT 1";
		$res = mysql_query($sql);
	}
	if (mysql_num_rows($res)) {
		$line = mysql_fetch_array($res);
		$nextid = $line['imgid'];
	}
	$urlconst = "index.php?language=" . $language . "&imageid=";
	$menu = "<SPAN CLASS=\"defaulttext\"><STRONG>";
	if ($previd) {
		$menu .= "<A HREF=\"" . $urlconst . $previd . "&page=" . getpageid($previd);
		if ($showall == 1)   { $menu .= "&showall=1"; }
		$menu .= "\">&lt;&lt;&nbsp;" . constant("LANG_PREVIOUS") . "</A>";
	} else {
		$menu .= "&lt;&lt;&nbsp;" . constant("LANG_PREVIOUS");
	}
	$menu .= "&nbsp;|&nbsp;";
	$menu .= "<A HREF=\"" . $urlconst . "0&page=" . $page;
	if ($showall == 1)   { $menu .= "&showall=1"; }
	$menu .= "\">" . constant("LANG_INDEX") . "</A>";
	$menu .= "&nbsp;|&nbsp;";
	if ($nextid) {
		$menu .= "<A HREF=\"" . $urlconst . $nextid . "&page=" . getpageid($nextid);
		if ($showall == 1)   { $menu .= "&showall=1"; }
		$menu .= "\">" . constant("LANG_NEXT") . "&nbsp;&gt;&gt;</A>";
	} else {
		$menu .= constant("LANG_NEXT") . "&nbsp;&gt;&gt;";
	}
	$menu .= "</STRONG></SPAN>\n";
	return $menu;
}

// Return a navigation menu for stories.
function storynavmenu($timeid) {
	global $showall, $language, $fullwidth;

	$res = mysql_query("SELECT timeid FROM blog WHERE timeid < '" . $timeid . "' ORDER BY timeid DESC LIMIT 1");
	if (mysql_num_rows($res)) {
		$line = mysql_fetch_array($res);
		$previd = $line['timeid'];
	}
	if ($showall == 1) {
		$res = mysql_query("SELECT timeid FROM blog WHERE timeid > '" . $timeid . "' ORDER BY timeid ASC LIMIT 1");
	} else {
		$sql = "SELECT timeid FROM blog ";
		$sql .= "WHERE (timeid > '" . $timeid . "') AND ";
		$sql .= "(timeid <= '" . gettimestamp12() . "') ";
		$sql .= "ORDER BY timeid ASC LIMIT 1";
		$res = mysql_query($sql);
	}
	if (mysql_num_rows($res)) {
		$line = mysql_fetch_array($res);
		$nextid = $line['timeid'];
	}
	$urlconst = "index.php?language=" . $language . "&timeid=";
	$menu = "<SPAN CLASS=\"defaulttext\"><STRONG>";
	if ($previd) {
		$menu .= "<A HREF=\"" . $urlconst . $previd;
		if ($showall == 1)   { $menu .= "&showall=1"; }
		if ($fullwidth)   { $menu .= "&fullwidth=1"; }
		$menu .= "\">&lt;&lt;&nbsp;" . constant("LANG_PREVIOUS") . "</A>";
	} else {
		$menu .= "&lt;&lt;&nbsp;" . constant("LANG_PREVIOUS");
	}
	$menu .= "&nbsp;|&nbsp;";
	if ($nextid) {
		$menu .= "<A HREF=\"" . $urlconst . $nextid;
		if ($showall == 1)   { $menu .= "&showall=1"; }
		if ($fullwidth)   { $menu .= "&fullwidth=1"; }
		$menu .= "\">" . constant("LANG_NEXT") . "&nbsp;&gt;&gt;</A>";
	} else {
		$menu .= constant("LANG_NEXT") . "&nbsp;&gt;&gt;";
	}
	$menu .= "</STRONG></SPAN>\n";
	return $menu;
}

// Return the comment bar for the specified story.
function commentbar($storyid) {
	global $language;
	// count comments
	$sql = "SELECT COUNT(blogcomments.storyid) AS totcomments FROM blogcomments, blog ";
	$sql .= "WHERE (blogcomments.storyid = blog.timeid) AND ";
	$sql .= "(blogcomments.storyid = '" . $storyid . "')";
	$res = mysql_query($sql);
	$line = mysql_fetch_array($res);
	$linkdesc = constant("LANG_COMMENTS") . ": " . $line['totcomments'];
	$s = "<SCRIPT LANGUAGE=\"javascript\">commentlink('" . $storyid . "', '" . $linkdesc . "', '" . $language . "')</SCRIPT>\n";
	$s .= "<NOSCRIPT><SPAN CLASS=\"commentbartext\"><A HREF=\"comments.php?id=";
	$s .= $storyid . "&language=" . $language . "\" TARGET=\"_blank\">";
	$s .= $linkdesc . "</A></SPAN></NOSCRIPT>";
	return $s;
}

// Show the list of stories, with first $full in full format.
// If $navmenu is TRUE, show navigation menu too.
function showstorylist($sql, $full, $navmenu = FALSE) {
	global $smileys, $showpermalinks, $permalinkmarker, $language, $enablecomments, $fullwidth;

	$urlconst = "index.php?language=" . $language . "&timeid=";
	$cnt = 0;
	$res = mysql_query($sql);
	if (mysql_num_rows($res) > 0) {
		while ($line = mysql_fetch_array($res)) {
			$cnt++;
			if ($cnt <= $full) {		// full format
				if ($s)   { $s .= spacer(12); }
				// story header
				$s .= "<TABLE CLASS=\"storyblock\" WIDTH=\"100%\" CELLSPACING=\"1\" CELLPADDING=\"2\" BORDER=\"0\">\n";
				$s .= "<TR>\n";
				$s .= "<TD CLASS=\"storytitle\" ALIGN=\"left\" VALIGN=\"bottom\">\n";
				$s .= "<A HREF=\"" . $urlconst . $line['timeid'] . "&fullwidth=" . abs($fullwidth - 1) . "\"><SPAN CLASS=\"storytitletext\">" . $line['title'] . "</SPAN></A>\n";
				// permalink
				if ($showpermalinks) {	// don't put language in permalink: default will be set
					$s .= "&nbsp;<A HREF=\"" . baseurl() . "?timeid=" . $line['timeid'] . "\" TITLE=\"" . constant("LANG_PERMALINK") . "\"><SPAN CLASS=\"datetitletext\"><SMALL>" . $permalinkmarker . "</SMALL></SPAN></A>\n";
				}
				$s .= "</TD>\n";
				$s .= "<TD CLASS=\"storytitle\" ALIGN=\"right\" VALIGN=\"bottom\">\n";
				$s .= "<A HREF=\"" . $urlconst . $line['timeid'] . "&tm=1\"><SPAN CLASS=\"datetitletext\">" . fmtdatetime($line['timeid'], FALSE) . "</SPAN></A>\n";
				$s .= "</TD>\n";
				$s .= "</TR>\n";
				// story content
				$s .= "<TR>\n";
				$s .= "<TD CLASS=\"storycontent\" ALIGN=\"left\" VALIGN=\"top\" COLSPAN=\"2\">\n";
				if ($line['image'] > 0) { $s .= thumblink($line['image'], "right"); }
				$s .= "<SPAN CLASS=\"storycontenttext\">";
				if ($smileys) {
					$s .= showsmileys($line['content']);
				} else {
					$s .= $line['content'];
				}
				$s .= "</SPAN>\n";
				$s .= "</TD>\n";
				$s .= "</TR>\n";

				// comment bar
				if ($enablecomments) { $s .= "<TR>\n<TD CLASS=\"commentbar\" ALIGN=\"left\" VALIGN=\"middle\" COLSPAN=\"2\">\n" . commentbar($line['timeid']) . "</TD>\n</TR>\n"; }

				$s .= "</TABLE>\n\n";
				$lasttimeid = $line['timeid'];		// to be used for navigation menu generation
			} else {					// title only
				if (!$t) {
					$t .= spacer(12);
				} else {
					$t .= "<BR>\n";
				}
				$t .= storytitle($line['timeid'], $line['title'], $line['image']);
			}
		}
		// show navigation menu if required
		if ($navmenu)   { $menu = "<BR>" . storynavmenu($lasttimeid) . "\n"; }
	} else {	// no stories found
		$s .= "<TABLE WIDTH=\"100%\" CELLSPACING=\"0\" CELLPADDING=\"8\" BORDER=\"0\">\n";
		$s .= "<TR>\n";
		$s .= "<TD ALIGN=\"center\"><SPAN CLASS=\"defaulttext\"><STRONG>" . constant("LANG_NOTFOUND") . "</STRONG></SPAN></TD>\n";
		$s .= "</TR>\n";
		$s .= "</TABLE>\n\n";
	}
	print($s . $t . $menu);
}

// Show an image.
function showimage($id, $page, $all) {
	global $imagedir, $language;

	$sql = "SELECT name, description FROM blogimages WHERE id = " . $id;
	$res = mysql_query($sql);
	if (mysql_num_rows($res) > 0) {
		$line = mysql_fetch_array($res);
		print("<IMG SRC=\"" . $imagedir . $line['name'] . "\" ALT=\"\" BORDER=\"0\"><BR>\n");
		print("<SPAN CLASS=\"defaulttext\">" . $line['description'] . "</SPAN>");
		print("<BR>\n<SPAN CLASS=\"showrelatedtext\"><A HREF=\"index.php?language=" . $language . "&rel=" . $id . "\">" . constant("LANG_RELATED") . "</A></SPAN>");
		if ($page > 0) { print("<BR>\n" . imagenavmenu($id, $page, $all)); }
		print("\n");
	}
}

// Show an image thumbnail index (one page).
function showimageindex($page) {
	global $thumbperrow, $thumbperpage, $showall, $language;

	$cnt = 0;		// image counter
	$rowcnt = 0;	// images in the current row
	$nowtstamp = gettimestamp12();

	// count images in the database
	if ($showall == 1) {		// all pictures, even those related to stories programmed in the future
		$sql = "SELECT COUNT(id) AS totimages FROM blogimages";
	} else {
		$sql = "SELECT COUNT(DISTINCT blogimages.id) AS totimages FROM blogimages, blog ";
		$sql .= "WHERE (blogimages.id = blog.image) AND ";
		$sql .= "(blog.timeid <= '" . $nowtstamp . "')";
	}
	$res = mysql_query($sql);
	$line = mysql_fetch_array($res);
	$totimages = $line['totimages'];				// total images in database
	$totpages = ceil($totimages / $thumbperpage);	// total pages
	$imgtoskip = $thumbperpage * ($page - 1);		// number of images to skip

	$urlconst = "index.php?language=" . $language . "&imageid=";

	// display top navigation menu for thumbnail pages (only if more than one page)
	if ($totpages > 1) {
		print("<TABLE WIDTH=\"100%\" CELLSPACING=\"0\" CELLPADDING=\"0\" BORDER=\"0\">\n");
		print("<TR>\n");
		print("<TD ALIGN=\"center\" VALIGN=\"middle\">\n");
		print("<SPAN CLASS=\"defaulttext\">\n<STRONG>\n");
		if ($page == 1) {
			print("&lt;&lt;&nbsp;" . constant("LANG_PREVIOUS"));
		} else {
			print("<A HREF=\"" . $urlconst . "0&page=" . ($page - 1));
			if ($showall == 1)   { print("&showall=1"); }
			print("\">&lt;&lt;&nbsp;" . constant("LANG_PREVIOUS") . "</A>");
		}
		print("&nbsp;&nbsp;&nbsp;");
		for ($i = 1; $i <= $totpages; $i++) {
			if ($i > 1)   { print("&nbsp;|&nbsp;"); }
			if ($i == $page) {
				print($i);
			} else {
				print("<A HREF=\"" . $urlconst . "0&page=" . $i);
				if ($showall == 1)   { print("&showall=1"); }
				print("\">" . $i . "</A>");
			}
		}
		print("&nbsp;&nbsp;&nbsp;");
		if ($page == $totpages) {
			print(constant("LANG_NEXT") . "&nbsp;&gt;&gt;");
		} else {
			print("<A HREF=\"" . $urlconst . "0&page=" . ($page + 1));
			if ($showall == 1)   { print("&showall=1"); }
			print("\">" . constant("LANG_NEXT") . "&nbsp;&gt;&gt;</A>");
		}
		print("\n</STRONG><BR>\n&nbsp;</SPAN>\n");
		print("</TD>\n");
		print("</TR>\n");
		print("</TABLE>\n");
		spacer(12);
	}

	// thumbnail table
	if ($showall == 1) {
		$sql = "SELECT id AS imgid, name AS imgname FROM blogimages ORDER BY id ASC";
	} else {
		$sql = "SELECT DISTINCT blogimages.id AS imgid, blogimages.name AS imgname FROM blogimages, blog ";
		$sql .= "WHERE (blogimages.id = blog.image) AND ";
		$sql .= "(blog.timeid <= '" . $nowtstamp . "')";
		$sql .= "ORDER BY id ASC";
	}
	$res = mysql_query($sql);
	$totimages = mysql_num_rows($res);
	if ($totimages > 0) {
		print("<TABLE WIDTH=\"100%\" CELLSPACING=\"2\" CELLPADDING=\"2\" BORDER=\"0\">\n");
		while (($cnt < ($page * $thumbperpage)) && ($line = mysql_fetch_array($res))) {
			$cnt++;
			if ($cnt > $imgtoskip) {
				$rowcnt++;
				if ($rowcnt > $thumbperrow) {
					print("<TR>\n" . $row . "</TR>\n");
					$row = "";
					$rowcnt = 1;
				}
				$row .= "<TD ALIGN=\"center\" VALIGN=\"middle\">" . thumblink($line['imgid'], "", $page) . "</TD>\n";
			}
		}
		// fill remaining TD's
		while ($rowcnt < $thumbperrow) {
			$row .= "<TD>&nbsp;</TD>\n";
			$rowcnt++;
		}
		if ($row)   { print("<TR>\n" . $row . "</TR>\n"); }		// print last TR if not printed yet
		print("</TABLE>\n");
	}
}

// Main display function.
function showcontent() {
	global $fullnum, $titlenum, $timeid, $imageid, $rel, $search, $page, $tm, $showall;

	if (isset($imageid)) {		// pictures
		if ($imageid > 0) {
			showimage($imageid, $page, ($showall == 1));
		} else {
			if (!isset($page))   { $page = 1; }
			showimageindex($page);
		}
	} else {
		$archiveflag = FALSE;
		$sql = "SELECT * FROM blog ";
		if (isset($search)) {	// search results
			$keywords = explode(" ", $search);
			for ($i = 0; $i < count($keywords); $i++) {
				if (strlen($keywords[$i]) > 2) {		// consider at least three-chars-long words only
					if ($s)   { $s .= " OR "; }			// search for stories with ANY specified words
					$k = htmlentities($keywords[$i]);
					$s .= "(title LIKE '%" . $k . "%') OR (content LIKE '%" . $k . "%')";
				}
			}
			$sql .= "WHERE (timeid <= '" . gettimestamp12() . "')";
			if ($s)   { $sql .= " AND (" . $s . ")"; }
		} else {				// stories
			if ($rel > 0) {		// related stories
				$sql .= "WHERE (image = " . $rel . ") ";
			} else {			// stories
				if (isset($timeid)) {				// one story or go to a date/time
					if (strlen($timeid) == 4) {		// archive search (month stories)
						$archiveflag = TRUE;
						$sql .= "WHERE (timeid >= '" . $timeid . "01000000') AND (timeid < '";
						if ($timeid == substr(gettimestamp12(), 0, 4)) {	// current month and year: don't show stories in the future
							$sql .= gettimestamp12();
						} else {
							$y = substr($timeid, 0, 2);
							$m = substr($timeid, 2, 2) + 1;
							if ($m > 12) {
								$m = "01";
								$y++;
							}
							if (strlen($m) == 1)   { $m = "0" . $m; }
							if (strlen($y) == 1)   { $y = "0" . $y; }
							$sql .= $y . $m . "01000000";
						}
						$sql .= "') ";
					} else {
						if ($tm == 1) {		// time machine: go to a date/time
							$sql .= "WHERE (timeid <= '" . $timeid . "') AND ";
							$sql .= "(timeid >= '". substr($timeid, 0, 4) . "01000000')";
						} else {			// that one story
							$sql .= "WHERE (timeid = '" . $timeid . "')";
							$storymenu = TRUE;
						}
					}
				} else {		// latest stories starting from now
					$sql .= "WHERE (timeid <= '" . gettimestamp12() . "') ";
				}
			}
		}
		$sql .= "ORDER BY timeid DESC";
		if (!$archiveflag)   { $sql .= " LIMIT " . ($fullnum + $titlenum); }
		showstorylist($sql, $fullnum, $storymenu);
	}
}

// Before sending any headers, check if RSS has been required.
if (isset($rss)) {
	if (dbconnect()) {
		print(getrss($rss));
		dbdisconnect();
	}
	exit();
}

// Before sending any headers, check if a new language has been required.
if ($newlang) {
	$language = $newlang;		// set new language
	setcookie("bloglang", $newlang);					// try to set a cookie to remember preferred language
	$oldq = explode("&", $_SERVER['QUERY_STRING']);		// split current query string
	for ($i = 0; $i < count($oldq); $i++) {				// create a new query string excluding newlang and previous language parameter
		if (substr($oldq[$i], 0, 8) != "language") {
			if ($newq)   { $newq .= "&"; }
			if (substr($oldq[$i], 0, 7) == "newlang") {
				$newq .= "language=" . $newlang;
			} else {
				$newq .= $oldq[$i];
			}
		}
	}
	if ($newq)   { $newq = "?" . $newq; }
	header("Location: index.php" . $newq);			// reload main default page
	exit();
}

// Set default language (if not specified)
if (!$language) {
	// try to set the user's preferred language from a previous cookie
	if ($_COOKIE['bloglang']) {
		$language = $_COOKIE['bloglang'];
	} else {
		$language = $defaultlanguage;
		setcookie("bloglang", $defaultlanguage);
	}
} else {	// language must exists among defined tags
	if (!languageexists($language)) {
		$language = $defaultlanguage;
		setcookie("bloglang", $defaultlanguage);
	}
}

// Include corresponding language file.
include("language/" . $language . ".php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE><?php print($blogname); ?></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<LINK REL="stylesheet" TYPE="text/css" HREF="style.css">
<LINK REL="icon" HREF="favicon.ico" TYPE="image/x-icon">

<SCRIPT LANGUAGE="javascript">
	<!--
	function commentlink(id, desc, lang) {
		q = "'";
		qcq = "','"
		document.write('<SPAN CLASS="commentbartext"><A HREF="javascript:void(0)" onclick="window.open(' + q +
			'comments.php?id=' + id + '&language=' + lang + qcq + 'blogcomments' + qcq +
			'scrollbars=yes,resizable=yes,height=320,width=320,left=60,top=60' + q + ')">' +
			desc + '</A></SPAN>');
	}
	-->
</SCRIPT>

</HEAD>
<BODY CLASS="defaultbody">
<!-- header -->
<TABLE WIDTH="100%" CELLSPACING="0" CELLPADDING="0" BORDER="0">
<TR>
	<TD CLASS="header" ALIGN="left" VALIGN="middle">
	<A HREF="index.php"><SPAN CLASS="headertext"><?php print($blogname); ?></SPAN></A>
	</TD>
	<TD CLASS="header" ALIGN="center" VALIGN="bottom">
	<?php
	if ($showlangmenu) {
       	global $lang;
		foreach ($lang as $k => $l) {
			if ($lm)   { $lm .= "<SPAN CLASS=\"headerdeftext\"><SMALL><SMALL><STRONG>&nbsp;|&nbsp;</STRONG></SMALL></SMALL></SPAN>"; }
			$lm .= "<A HREF=\"index.php?newlang=" . $l;
			if ($_SERVER['QUERY_STRING'])   { $lm .= "&" . $_SERVER['QUERY_STRING']; }	// propagate query string to reload current display after changing language
			$lm .= "\"><SPAN CLASS=\"headerdeftext\"><SMALL><SMALL>" . $k . "</SMALL></SMALL></SPAN></A>";
		}
		print($lm . "\n");
	}
	?>
	</TD>
	<TD CLASS="header" ALIGN="right" VALIGN="bottom">
	<?php
	if (($homepagelink) && ($homepagedesc)) {
		print("<A HREF=\"" . $homepagelink . "\"><SPAN CLASS=\"headerdeftext\"><STRONG>" . $homepagedesc . "</STRONG></SPAN></A><BR>\n");
	}
	?>
	<FORM ACTION="index.php">
	<SPAN CLASS="headerdeftext"><?php print(constant("LANG_SEARCH")); ?>&nbsp;</SPAN>
	<?php
	print("<INPUT TYPE=\"text\" NAME=\"search\" VALUE=\"" . ereg_replace("\\\'", "'", $search) . "\">\n");
	print("<INPUT TYPE=\"hidden\" NAME=\"language\" VALUE=\"" . $language . "\">\n");
	?>
	&nbsp;<INPUT TYPE="image" SRC="images/search.png">
	</FORM>
	</TD>
</TR>
<TR>
	<TD CLASS="header" HEIGHT="4" COLSPAN="3"><IMG SRC="images/pixel.png" BORDER="0" HEIGHT="4"></TD>
</TR>
</TABLE>
<?php print(spacer(12)); ?>
<TABLE WIDTH="100%" CELLSPACING="0" CELLPADDING="0" BORDER="0">
<?php
print("<TR>\n");
// left side
if (!$fullwidth) {
	print("<TD CLASS=\"blockcontent\" ALIGN=\"left\" VALIGN=\"top\" WIDTH=\"" . $leftsidewidth . "\">\n");
	print("<A HREF=\"index.php?language=" . $language . "\"><SPAN CLASS=\"leftmenutext\"><STRONG>" . constant("LANG_STORIES") . "</STRONG></SPAN></A><BR>\n");
	print("<A HREF=\"index.php?language=" . $language . "&imageid=0\"><SPAN CLASS=\"leftmenutext\"><STRONG>" . constant("LANG_PICTURES") . "</STRONG></SPAN></A>\n");
}

// Read from database and create layout.
if (dbconnect()) {
	if (!$fullwidth) {
		showlateststories();
		showtimearchive();

		// XML RSS 2.0 headlines news source link
		print("<BR>\n");
		print("<A HREF=\"index.php?rss=xml\"><IMG SRC=\"images/xml.png\" BORDER=\"0\" ALT=\"XML RSS 2.0\"></A>");
		print("</TD>\n");

		print("<TD WIDTH=\"" . $vspace . "\">&nbsp;</TD>\n");	// vertical spacer
	}

	// content area
	print("<TD ALIGN=\"center\" VALIGN=\"top\">\n");
	showcontent();
	print("</TD>\n");
	print("</TR>\n");

	dbdisconnect();
}
?>
</TABLE>
<?php
// credits
print(spacer(12));
print("<HR>\n");
print("<CENTER>\n");
if ($credits1)   { print("<SPAN CLASS=\"smalltext\">" . $credits1 . "</SPAN><BR>\n"); }
if ($credits2)   { print("<SPAN CLASS=\"smalltext\">" . $credits2 . "</SPAN><BR>\n"); }
if ($credits3)   { print("<SPAN CLASS=\"smalltext\">" . $credits3 . "</SPAN><BR>\n"); }
print("<SPAN CLASS=\"smalltext\">Powered by <A HREF=\"http://www.fabiopani.it/blog/sulogu.php\" TARGET=\"_blank\" TITLE=\"Su Logu Official Page\"><STRONG>Su Logu</STRONG></A> - A free PHP blog by <A HREF=\"http://www.fabiopani.it\" TARGET=\"_blank\"><STRONG>Fabiux</STRONG></A> (version " . $version . ")</SPAN></CENTER>\n");
?>
</BODY>
</HTML>
