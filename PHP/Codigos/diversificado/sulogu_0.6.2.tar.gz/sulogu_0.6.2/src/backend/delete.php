<?php

// ####################################################################
// ____________________
// Su Logu - A PHP Blog
// --------------------
//
// (C) 2002, 2003 Fabio Pani
// http://www.fabiopani.it/blog/sulogu.html
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License.
// ####################################################################

include("database.php");
include("utils.php");

// Check deletion before sending header
if ($op == "delete") {
	if (dbconnect()) {
		// remove story
		$sql = "DELETE FROM blog WHERE timeid = '" . $timeid . "'";
		mysql_query($sql);
		// remove image, if requested by the user
		if ($image > 0) {
			$sql = "DELETE FROM blogimages WHERE id = " . $image;
			mysql_query($sql);
		}
		dbdisconnect();
		header("Location: delete.php?op=ok");
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE>Su Logu - Delete a story!</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<LINK REL="stylesheet" TYPE="text/css" HREF="backend.css" >
</HEAD>

<BODY CLASS="defaultbody">
<P ALIGN="left">
<SPAN CLASS="titletext">Delete a story!</SPAN>
</P>

<?php
print("<P ALIGN=\"left\">\n");
if ($op == "ok") {
	print("<SPAN CLASS=\"defaulttext\">Story has been successfully deleted.</SPAN><BR>\n");
	print("<SPAN CLASS=\"defaulttext\"><A HREF=\"delete.php\">Delete a story</A><STRONG> | </STRONG><A HREF=\"post.php\">Post a story</A></SPAN>\n");
} else {
	if (dbconnect()) {
		if ($op == "confirm") {		// confirm
			if ($timeid) {
				$sql = "SELECT title, image FROM blog WHERE timeid = '" . $timeid . "'";
				$res = mysql_query($sql);
				$line = mysql_fetch_array($res);
				print("<SPAN CLASS=\"defaulttext\"><SMALL>" . fmtdatetime($timeid, FALSE) . "</SMALL> - " . $line['title'] . "</SPAN><BR>\n");
				print("<SPAN CLASS=\"defaulttext\"><STRONG>Do you really want to delete this story?</STRONG></SPAN><BR>\n");
				$link = "delete.php?op=delete&timeid=" . $timeid;
				print("<SPAN CLASS=\"defaulttext\"><STRONG><A HREF=\"" . $link . "\">Delete story</A> | ");
				if ($line['image'] > 0) {
					print("<SPAN CLASS=\"defaulttext\"><STRONG><A HREF=\"" . $link . "&image=" . $line['image'] . "\">Delete story and image</A> | ");
				}
				print("<A HREF=\"delete.php?month=" . $month . "\">Cancel</A></STRONG></SPAN>");
			} else {
				print("<SPAN CLASS=\"defaulttext\">Please select a story to delete!</SPAN><BR>\n");
				print("<SPAN CLASS=\"defaulttext\"><A HREF=\"delete.php?month=" . $month . "\">Back</A></SPAN>");
			}
		} else {	// default page
			print("<FORM ACTION=\"delete.php\" METHOD=\"get\">\n");
			print("<INPUT TYPE=\"hidden\" NAME=\"month\" VALUE=\"" . $month . "\">\n");
			print("<TABLE CELLSPACING=\"2\" CELLPADDING=\"4\" BORDER=\"1\">\n");
			print("<TR>\n");
			print("<TD>&nbsp;</TD>\n");
			print("<TD ALIGN=\"center\" VALIGN=\"middle\"><SPAN CLASS=\"defaulttext\"><STRONG>Date</STRONG></SPAN></TD>\n");
			print("<TD ALIGN=\"center\" VALIGN=\"middle\"><SPAN CLASS=\"defaulttext\"><STRONG>Time ID</STRONG></SPAN></TD>\n");
			print("<TD ALIGN=\"center\" VALIGN=\"middle\"><SPAN CLASS=\"defaulttext\"><STRONG>Image ID</STRONG></SPAN></TD>\n");
			print("<TD ALIGN=\"center\" VALIGN=\"middle\"><SPAN CLASS=\"defaulttext\"><STRONG>Title</STRONG></SPAN></TD>\n");
			print("</TR>\n");
			$sql = "SELECT timeid, title, image FROM blog ";
			$sql .= "WHERE timeid LIKE '";
			if ($month) {
				$sql .= $month;
			} else {
				$sql .= substr(gettimestamp12(), 0, 4);
			}
			$sql .= "%' ";
			$sql .= "ORDER BY timeid DESC";
			$res = mysql_query($sql);
			if (mysql_num_rows($res) > 0) {
				while ($line = mysql_fetch_array($res)) {
					print("<TR>\n");
					print("<TD ALIGN=\"center\" VALIGN=\"middle\">\n");
					print("<INPUT TYPE=\"radio\" NAME=\"timeid\" VALUE=\"" . $line['timeid'] . "\">\n");
					print("</TD>\n");
					print("<TD ALIGN=\"left\" VALIGN=\"middle\">\n");
					print("<SPAN CLASS=\"defaulttext\"><SMALL>" . fmtdatetime($line['timeid'], FALSE) . "</SMALL></SPAN>\n");
					print("</TD>\n");
					print("<TD ALIGN=\"center\" VALIGN=\"middle\">\n");
					print("<SPAN CLASS=\"defaulttext\"><SMALL>" .$line['timeid'] . "</SMALL></SPAN>\n");
					print("</TD>\n");
					print("<TD ALIGN=\"center\" VALIGN=\"middle\">\n");
					print("<SPAN CLASS=\"defaulttext\">" .$line['image'] . "</SPAN>\n");
					print("</TD>\n");
					print("<TD ALIGN=\"left\" VALIGN=\"middle\">\n");
					print("<SPAN CLASS=\"defaulttext\">" . $line['title'] . "</SPAN>\n");
					print("</TD>\n");
					print("</TR>\n");
				}
				print("</TABLE>\n");
				print("<INPUT TYPE=\"hidden\" NAME=\"op\" VALUE=\"confirm\">\n");
				print("<INPUT TYPE=\"submit\" VALUE=\"&nbsp;Delete&nbsp;\">\n");
				print("</FORM>\n");
			} else {
				print("<P ALIGN=\"left\">\n");
				print("<SPAN CLASS=\"defaulttext\"><STRONG>No stories found!</STRONG></SPAN>");
				print("</P>\n\n");
			}

			// print links to other periods
			print("<SPAN CLASS=\"defaulttext\">Select another month:</SPAN><BR>\n");
			$nowtimestamp = gettimestamp12();
			$yy = substr($nowtimestamp, 0, 2);
			$mm = substr($nowtimestamp, 2, 2);
			while ($yy . $mm >= "0212") {		// ### please edit and put your preferred starting period (format: YYMM) ###
				if ($s)   { $s .= "<BR>\n"; }
				$s .= "<A HREF=\"delete.php?month=" . $yy . $mm . "\">" . monthname($mm) . " 20" . $yy . "</A>";
				$mm--;
				if ($mm == 0) {
					$mm = "12";
					$yy--;
				}
				if (strlen($mm) == 1)   { $mm = "0" . $mm; }
				if (strlen($yy) == 1)   { $yy = "0" . $yy; }
			}
			print("<SPAN CLASS=\"defaulttext\"><SMALL>" . $s . "</SMALL></SPAN>\n");
		}
		dbdisconnect();
	}
}
print("</P>\n");
?>

</BODY>
</HTML>
