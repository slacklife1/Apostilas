<?php
include("database.php");
include("config.php");
include("utils.php");

if (dbconnect()) {
	$s = getrss("xml");
	// Please, set a valid and writeable path below.
	$fp = fopen("/var/tmp/rss.xml", "w");
	fwrite($fp, $s, strlen($s));
	fclose($fp);
	dbdisconnect();
}
?>
