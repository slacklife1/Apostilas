<?php

// ####################################################################
// ____________________
// Su Logu - A PHP Blog
// --------------------
//
// (C) 2002, 2003 Fabio Pani
// http://www.fabiopani.it/blog/sulogu.html
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License.
// ####################################################################

include("include/database.php");
include("include/utils.php");

// Convert some HTML special characters. See PHP manual.
// (to be improved)
function htmlconvert($s) {
	$s = htmlentities(stripslashes($s), ENT_NOQUOTES);
	$s = ereg_replace("'", "&#039;", $s);
	$s = ereg_replace("&gt;", ">", $s);
	$s = ereg_replace("&lt;", "<", $s);
	$s = ereg_replace("&amp;", "&", $s);
	return $s;
}

// Print error messages
function printerror($msg) {
	print("<P ALIGN=\"left\">\n<SPAN CLASS=\"errortext\">" . $msg . "</SPAN>\n</P>\n\n");
}

// Print the preview
function printpreview() {
	global $title, $content;

	print("<P ALIGN=\"left\">\n");
	print("<SPAN CLASS=\"defaulttext\"><STRONG>" . htmlconvert($title) . "</STRONG></SPAN><BR>\n");
	print("<TABLE CELLSPACING=\"0\" CELLPADDING=\"0\" BORDER=\"0\">\n");
	print("<TR>\n<TD CLASS=\"storycontent\" ALIGN=\"left\" VALIGN=\"top\">\n");
	print("<SPAN CLASS=\"defaulttext\">" . htmlconvert($content) . "</SPAN>\n");
	print("</TD>\n</TR>\n</TABLE>\n");
	print("</P>\n<HR>\n\n");
}

// Print the input form
function printform() {
	global $title, $content, $image, $imgname, $nextid;

	print("<FORM ACTION=\"post.php\" METHOD=\"post\">\n");
	print("<SPAN CLASS=\"defaulttext\">Title of the story</SPAN><BR>\n");
	print("<INPUT TYPE=\"text\" SIZE=\"80\" NAME=\"title\" VALUE=\"" . htmlconvert($title) . "\"><BR><BR>\n");
	print("<SPAN CLASS=\"defaulttext\">Content of the story</SPAN><BR>\n");
	print("<TEXTAREA COLS=\"80\" ROWS=\"20\" NAME=\"content\">");
	if ($content)   { print(htmlconvert($content)); }
	print("</TEXTAREA><BR><BR>\n");
	print("<SPAN CLASS=\"defaulttext\">Timestamp (only required if you want to force the date/time)&nbsp;&nbsp;</SPAN>");
	print("<INPUT TYPE=\"text\" SIZE=\"18\" MAXLENGTH=\"12\" NAME=\"timeid\"><BR><BR>\n");
	print("<SPAN CLASS=\"defaulttext\">Associated image</SPAN><BR>\n");
	print("<TABLE CELLSPACING=\"4\" CELLPADDING=\"4\" BORDER=\"0\">\n");
	print("<TR>\n");
	print("<TD ALIGN=\"left\" VALIGN=\"middle\" COLSPAN=\"3\">");
	print("<INPUT TYPE=\"radio\" NAME=\"whatimage\" VALUE=\"0\"><SPAN CLASS=\"defaulttext\">&nbsp;No image</SPAN></INPUT>\n");
	print("</TD>\n");
	print("</TR>\n");
	print("<TR>\n");
	print("<TD ALIGN=\"left\" VALIGN=\"middle\">");
	print("<INPUT TYPE=\"radio\" NAME=\"whatimage\" VALUE=\"1\"><SPAN CLASS=\"defaulttext\">&nbsp;Existing image</SPAN></INPUT>\n");
	print("</TD>\n");
	print("<TD ALIGN=\"right\" VALIGN=\"middle\">");
	print("<SPAN CLASS=\"defaulttext\">Image id</SPAN>\n");
	print("</TD>\n");
	print("<TD ALIGN=\"left\" VALIGN=\"middle\">");
	print("<INPUT TYPE=\"text\" SIZE=\"6\" NAME=\"image\" VALUE=\"" . $image . "\">\n");
	print("</TD>\n");
	print("</TR>\n");
	print("<TR>\n");
	print("<TD ALIGN=\"left\" VALIGN=\"top\">");
	print("<INPUT TYPE=\"radio\" NAME=\"whatimage\" VALUE=\"2\"><SPAN CLASS=\"defaulttext\">&nbsp;New image (id = " . $nextid . ")</SPAN></INPUT>\n");
	print("</TD>\n");
	print("<TD ALIGN=\"right\" VALIGN=\"top\">");
	print("<SPAN CLASS=\"defaulttext\">Image name</SPAN>\n");
	print("</TD>\n");
	print("<TD ALIGN=\"left\" VALIGN=\"top\">");
	print("<INPUT TYPE=\"text\" SIZE=\"30\" NAME=\"imgname\" VALUE=\"" . $imgname . "\">\n");
	print("</TD>\n");
	print("</TR>\n");
	print("<TR>\n");
	print("<TD>&nbsp;</TD>\n");
	print("<TD ALIGN=\"right\" VALIGN=\"middle\">");
	print("<SPAN CLASS=\"defaulttext\">Image description</SPAN>\n");
	print("</TD>\n");
	print("<TD ALIGN=\"left\" VALIGN=\"middle\">");
	print("<INPUT TYPE=\"text\" SIZE=\"60\" NAME=\"imgdesc\" VALUE=\"" . $imgdesc . "\">\n");
	print("</TD>\n");
	print("</TR>\n");
	print("</TABLE>\n");
	print("<SELECT NAME=\"op\">\n");
	print("<OPTION>preview\n");
	print("<OPTION>post\n");
	print("</SELECT>\n");
	print("&nbsp;&nbsp;&nbsp;<INPUT TYPE=\"submit\" VALUE=\"&nbsp;&nbsp;Go!&nbsp;&nbsp;\"");
	print("<INPUT TYPE=\"hidden\" NAME=\"nextid\" VALUE=\"" . $nextid . "\">\n");
	print("</FORM>\n");
}

// If posting data, check before sending header
if ($op == "post") {
	if (!$title)   { $res = urlencode("You must specify the title."); }
	if (!$content) {
		if ($res)   { $res .= "<BR>"; }
		$res .= urlencode("You must specify the content.");
	}
	if ($timeid) {
		// check here
		if (!ereg("^[0-9]+$", $timeid)) {
			if ($res)   { $res .= "<BR>"; }
			$res .= "If specified, timestamp must contain numbers only.";
		}
	}
	if (!isset($whatimage)) {
		if ($res)   { $res .= "<BR>"; }
		$res .= urlencode("You must specify an image");
	} else {
		if ($whatimage == 1) {
			if (!$image) {
				if ($res)   { $res .= "<BR>"; }
				$res .= urlencode("For an existing image you must specify the id.");
			} else {
				// id must exists
				if (dbconnect()) {
					$sql = "SELECT id FROM blogimages WHERE id = " . $image;
					$result = mysql_query($sql);
					if (mysql_num_rows($result) == 0) {
						if ($res)   { $res .= "<BR>"; }
						$res .= urlencode("The id " . $image ." doesn&quot;t exist.");
					}
					dbdisconnect();
				}
			}
		}
		if ($whatimage == 2) {
			if ((!$imgname) || (!$imgdesc)) {
				if ($res)   { $res .= "<BR>"; }
				$res .= urlencode("For a new image you must specify the file name and the description.");
			} else {
				// name must NOT exist
				if (dbconnect()) {
					$sql = "SELECT id FROM blogimages WHERE name = '" . $imgname . "'";
					$result = mysql_query($sql);
					if (mysql_num_rows($result) > 0) {
						if ($res)   { $res .= "<BR>"; }
						$res .= urlencode("The image file " . $imgname ." already exists.");
					}
					dbdisconnect();
				}
			}
		}
	}

	if ($res) {
		$res = "errmsg=" . $res;
		$res .= "&title=" . $_POST['title'];
		$res .= "&content=" . $_POST['content'];
	} else {
		if (dbconnect()) {
			$sql = "INSERT INTO blog VALUES (";
			if ($timeid) {
				$sql .= "'" . $timeid . "'";
			} else {
				//$sql .= "NULL";
				$sql .= "'" . gettimestamp12() . "'";
			}
			$sql .= ", '" . htmlconvert($title) . "', ";
			$sql .= "'" . htmlconvert($content) . "', ";
			if ($whatimage == 0) {
				$sql .= "0";
			} else {
				if ($whatimage == 1) {
					$sql .= $image;
				} else {
					$sql .= $nextid;
				}
			}
			$sql .= ")";
			mysql_query($sql);

			if ($whatimage == 2) {
				$sql = "INSERT INTO blogimages VALUES (";
				$sql .= $nextid . ", ";
				$sql .= "'" . $imgname . "', ";
				$sql .= "'" . htmlconvert($imgdesc) . "')";
				mysql_query($sql);
			}
			dbdisconnect();
		}
		$res = "op=ok";
	}
	header("Location: post.php?" . $res);
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE>Su Logu - Post a new story!</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<LINK REL="stylesheet" TYPE="text/css" HREF="backend.css" >
</HEAD>

<BODY CLASS="defaultbody">
<P ALIGN="left">
<SPAN CLASS="titletext">Post a new story!</SPAN>
</P>

<?php
if (dbconnect()) {
	if ($errmsg) { printerror($errmsg); }

	if ($op == "ok") {				// story was succesfully posted
		print("<P ALIGN=\"left\">\n");
		print("<SPAN CLASS=\"defaulttext\">Story has been successfully posted. Please, check your blog.</SPAN><BR>\n");
		print("<SPAN CLASS=\"defaulttext\"><A HREF=\"post.php\">Post another story</A></SPAN>\n");
		print("</P>\n");
	} else {
		if ($op == "preview") {		// show story preview
			if (!$errmsg)   { printpreview(); }
		} else {					// default page
			// find next available id for a new picture
			$sql = "SELECT MAX(id) AS maxid FROM blogimages";
			$res = mysql_query($sql);
			$line = mysql_fetch_array($res);
			$nextid = $line['maxid'] + 1;
		}
		printform();
	}

	dbdisconnect();
}
?>

</BODY>
</HTML>
