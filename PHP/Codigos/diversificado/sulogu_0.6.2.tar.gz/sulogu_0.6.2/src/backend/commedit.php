<?php

// ####################################################################
// ____________________
// Su Logu - A PHP Blog
// --------------------
//
// (C) 2002, 2003 Fabio Pani
// http://www.fabiopani.it/blog/sulogu.html
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License.
// ####################################################################


// #@#@# $limit: numero degli ultimi commenti da visualizzare - REMOVE THIS COMMENT!!!
include("database.php");
include("utils.php");

// Check deletion before sending header
if ($op == "delete") {
	if (dbconnect()) {
		// remove comment
		$id = explode("_", $commentid);
		$sql = "DELETE FROM blogcomments ";
		$sql .= "WHERE (timeid = '" . $id[0] . "') AND ";
		$sql .= "(storyid = '" . $id[1] . "')";
		mysql_query($sql);
		dbdisconnect();
		header("Location: commedit.php?op=ok");
	}
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE>Su Logu - Comment viewer</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<LINK REL="stylesheet" TYPE="text/css" HREF="backend.css" >
</HEAD>

<BODY CLASS="defaultbody">
<P ALIGN="left">
<SPAN CLASS="titletext">Comment viewer</SPAN>
</P>

<?php

if ($op == "ok") {
	print("<SPAN CLASS=\"defaulttext\">Comment has been successfully deleted.</SPAN><BR>\n");
	print("<SPAN CLASS=\"defaulttext\">Back to <A HREF=\"commedit.php\">comment viewer</A></SPAN>\n");
} else {
	if (dbconnect()) {
		if ($op == "confirm") {		// confirm
			if ($commentid) {
				$id = explode("_", $commentid);
				$sql = "SELECT usrcomment FROM blogcomments ";
				$sql .= "WHERE (timeid = '" . $id[0] . "') AND ";
				$sql .= "(storyid = '" . $id[1] . "')";
				$res = mysql_query($sql);
				$line = mysql_fetch_array($res);
				print("<P ALIGN=\"left\"><SPAN CLASS=\"defaulttext\"><SMALL>" . $line['usrcomment'] . "</SMALL></SPAN></P>\n");
				print("<P ALIGN=\"left\"><SPAN CLASS=\"defaulttext\"><STRONG>Do you really want to delete this comment?</STRONG></SPAN></P>\n");
				print("<P ALIGN=\"left\"><SPAN CLASS=\"defaulttext\"><STRONG><A HREF=\"commedit.php?op=delete&commentid=" . $commentid . "\">Delete comment</A> | ");
				print("<A HREF=\"commedit.php\">Cancel</A></STRONG></SPAN></P>");
			} else {
				print("<SPAN CLASS=\"defaulttext\">Please select a comment to delete!</SPAN><BR>\n");
				print("<SPAN CLASS=\"defaulttext\"><A HREF=\"commedit.php\">Back</A></SPAN>");
			}
		} else {					// default page
			print("<FORM ACTION=\"commedit.php\" METHOD=\"get\">\n");
			//print("<INPUT TYPE=\"hidden\" NAME=\"month\" VALUE=\"" . $month . "\">\n");
			print("<TABLE CELLSPACING=\"2\" CELLPADDING=\"4\" BORDER=\"1\">\n");
			print("<TR>\n");
			print("<TD>&nbsp;</TD>\n");
			print("<TD ALIGN=\"center\" VALIGN=\"middle\"><SPAN CLASS=\"defaulttext\"><STRONG>Comment date</STRONG></SPAN></TD>\n");
			print("<TD ALIGN=\"center\" VALIGN=\"middle\"><SPAN CLASS=\"defaulttext\"><STRONG>Story date</STRONG></SPAN></TD>\n");
			print("<TD ALIGN=\"center\" VALIGN=\"middle\"><SPAN CLASS=\"defaulttext\"><STRONG>Story title</STRONG></SPAN></TD>\n");
			print("<TD ALIGN=\"center\" VALIGN=\"middle\"><SPAN CLASS=\"defaulttext\"><STRONG>Comment</STRONG></SPAN></TD>\n");
			print("<TD ALIGN=\"center\" VALIGN=\"middle\"><SPAN CLASS=\"defaulttext\"><STRONG>Name</STRONG></SPAN></TD>\n");
			print("<TD ALIGN=\"center\" VALIGN=\"middle\"><SPAN CLASS=\"defaulttext\"><STRONG>URL</STRONG></SPAN></TD>\n");
			print("<TD ALIGN=\"center\" VALIGN=\"middle\"><SPAN CLASS=\"defaulttext\"><STRONG>Host</STRONG></SPAN></TD>\n");
			print("</TR>\n");

			$sql = "SELECT blogcomments.timeid AS commtime, ";
			$sql .= "blogcomments.storyid AS storytime, ";
			$sql .= "blog.title AS storytitle, ";
			$sql .= "blogcomments.name AS username, ";
			$sql .= "blogcomments.email AS useremail, ";
			$sql .= "blogcomments.usrcomment AS usercomment, ";
			$sql .= "blogcomments.url AS userurl, ";
			$sql .= "blogcomments.ipaddress AS userip, ";
			$sql .= "blogcomments.hostname AS userhost ";
			$sql .= "FROM blogcomments, blog ";
			$sql .= "WHERE (blogcomments.storyid = blog.timeid) ";
			$sql .= "ORDER BY blogcomments.timeid DESC";
			if ($limit)   { $sql .= " LIMIT " . $limit; }
			$res = mysql_query($sql);
			if (mysql_num_rows($res) > 0) {
				while ($line = mysql_fetch_array($res)) {
					print("<TR>\n");
					print("<TD ALIGN=\"center\" VALIGN=\"middle\">\n");
					print("<INPUT TYPE=\"radio\" NAME=\"commentid\" VALUE=\"" . $line['commtime'] . "_" . $line['storytime'] . "\">\n");
					print("</TD>\n");
					print("<TD ALIGN=\"left\" VALIGN=\"middle\">\n");
					print("<SPAN CLASS=\"defaulttext\">" . fmtdatetime($line['commtime'], FALSE) . "</SPAN>\n");
					print("</TD>\n");
					print("<TD ALIGN=\"left\" VALIGN=\"middle\">\n");
					print("<SPAN CLASS=\"defaulttext\">" . fmtdatetime($line['storytime'], FALSE) . "</SPAN>\n");
					print("</TD>\n");
					print("<TD ALIGN=\"center\" VALIGN=\"middle\">\n");
					print("<SPAN CLASS=\"defaulttext\">" . $line['storytitle'] . "</SPAN>\n");
					print("</TD>\n");
					$name = $line['username'];
					if ($line['useremail']) {
						if ($name)   { $name .= "<BR>"; }
						$name .= $line['useremail'];
					}
					if (!$name)   { $name = "&nbsp;"; }
					print("<TD CLASS=\"storycontent\" ALIGN=\"left\" VALIGN=\"middle\">\n");
					print("<SPAN CLASS=\"defaulttext\">" .$line['usercomment'] . "</SPAN>\n");
					print("</TD>\n");
					print("<TD ALIGN=\"center\" VALIGN=\"middle\">\n");
					print("<SPAN CLASS=\"defaulttext\"><SMALL>" .$name . "</SMALL></SPAN>\n");
					print("</TD>\n");
					print("<TD ALIGN=\"left\" VALIGN=\"middle\">\n");
					if (validurl($line['userurl'])) {
						$u = "<A HREF=\"" . $line['userurl'] . "\" TARGET=\"_blank\">" . $line['userurl'] . "</A>";
					} else {
						$u = "&nbsp;";
					}
					print("<SPAN CLASS=\"defaulttext\"><SMALL>" . $u . "</SMALL></SPAN>\n");
					print("</TD>\n");
					$host = $line['userip'];
					if ($host != $line['userhost'])   { $host .= "<BR>" . $line['userhost']; }
					print("<TD ALIGN=\"left\" VALIGN=\"middle\">\n");
					print("<SPAN CLASS=\"defaulttext\"><SMALL>" . $host . "</SMALL></SPAN>\n");
					print("</TD>\n");
					print("</TR>\n");
				}
				print("</TABLE>\n");
				print("<INPUT TYPE=\"hidden\" NAME=\"op\" VALUE=\"confirm\">\n");
				print("<INPUT TYPE=\"submit\" VALUE=\"&nbsp;Delete&nbsp;\">\n");
				print("</FORM>\n");
			} else {
				print("<P ALIGN=\"left\">\n");
				print("<SPAN CLASS=\"defaulttext\"><STRONG>No comments found!</STRONG></SPAN>");
				print("</P>\n\n");
			}

		}

		dbdisconnect();
	}
}

?>

</BODY>
</HTML>
