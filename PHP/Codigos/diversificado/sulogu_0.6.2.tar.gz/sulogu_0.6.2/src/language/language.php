<?php

// ####################################################################
// ____________________
// Su Logu - A PHP Blog
// --------------------
//
// (C) 2002, 2003 Fabio Pani
// http://www.fabiopani.it/blog/sulogu.html
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License.
// ####################################################################

// Defined languages
//$lang = array("English"=>"eng", "Espa&ntilde;ol"=>"spa", "Fran&ccedil;ais"=>"fre", "Deutsch"=>"ger", "Italiano"=>"ita");
//$lang = array("English"=>"eng", "Italiano"=>"ita");	// English and Italian
$lang = array("English"=>"eng");						// English only: in this case you'd better set $showlangmenu to FALSE

$defaultlanguage = "eng";
$showlangmenu = FALSE;			// show (TRUE) or hide (FALSE) the language menu
?>
