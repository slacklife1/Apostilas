<?php

// ####################################################################
// ____________________
// Su Logu - A PHP Blog
// --------------------
//
// (C) 2002, 2003 Fabio Pani
// http://www.fabiopani.it/blog/sulogu.html
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License.
// ####################################################################

// index.php
define("LANG_SEARCH", "Chercher");
define("LANG_STORIES", "Histoires du blog");
define("LANG_PICTURES", "Images du blog");
define("LANG_LATEST", "Derni&egrave;res histoires");
define("LANG_ARCHIVE", "Archives");
define("LANG_PERMALINK", "lien permanent à cette histoire");
define("LANG_INDEX", "Index");
define("LANG_PREVIOUS", "Pr&eacute;c&eacute;dente");
define("LANG_NEXT", "Suivante");
define("LANG_RELATED", "visualiser histoires en corr&eacute;lation");
define("LANG_NOTFOUND", "Aucune histoire trouv&eacute;e");
define("LANG_COMMENTS", "commentaires");

// comments.php
define("LANG_ADDCOMM", "ajouter ton commentaire");
define("LANG_YOURCOMM", "ton commentaire");
define("LANG_NAME", "nom");
define("LANG_SUBMIT", "envoyer ton commentaire");
define("LANG_ANON", "anonyme");
define("LANG_ALLOW", "permis");

$months = array("janvier", "f&eacute;vrier", "mars", "avril", "mai", "juin", "juillet", "ao&ucirc;t", "septembre", "octobre", "novembre", "d&eacute;cembre");
?>
