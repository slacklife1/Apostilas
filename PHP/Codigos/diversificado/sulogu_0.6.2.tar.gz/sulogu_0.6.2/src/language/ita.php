<?php

// ####################################################################
// ____________________
// Su Logu - A PHP Blog
// --------------------
//
// (C) 2002, 2003 Fabio Pani
// http://www.fabiopani.it/blog/sulogu.html
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License.
// ####################################################################

// index.php
define("LANG_SEARCH", "Cerca");
define("LANG_STORIES", "Storie del blog");
define("LANG_PICTURES", "Immagini del blog");
define("LANG_LATEST", "Storie pi&ugrave; recenti");
define("LANG_ARCHIVE", "Archivio");
define("LANG_PERMALINK", "link permanente a questa storia");
define("LANG_INDEX", "Indice");
define("LANG_PREVIOUS", "Precedente");
define("LANG_NEXT", "Seguente");
define("LANG_RELATED", "visualizza storie correlate");
define("LANG_NOTFOUND", "Nessuna storia trovata");
define("LANG_COMMENTS", "commenti");

// comments.php
define("LANG_ADDCOMM", "aggiungi un commento");
define("LANG_YOURCOMM", "il tuo commento");
define("LANG_NAME", "nome");
define("LANG_SUBMIT", "inoltra il tuo commento");
define("LANG_ANON", "anonimo");
define("LANG_ALLOW", "consentito");

$months = array("gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre");
?>
