<?php

// ####################################################################
// ____________________
// Su Logu - A PHP Blog
// --------------------
//
// (C) 2002, 2003 Fabio Pani
// http://www.fabiopani.it/blog/sulogu.html
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License.
// ####################################################################

// index.php
define("LANG_SEARCH", "Buscar");
define("LANG_STORIES", "Historias del blog");
define("LANG_PICTURES", "Im&aacute;genes del blog");
define("LANG_LATEST", "&Uacute;ltimas historias");
define("LANG_ARCHIVE", "Archivo");
define("LANG_PERMALINK", "enlace permanente a esta historia");
define("LANG_INDEX", "&Iacute;ndice");
define("LANG_PREVIOUS", "Anterior");
define("LANG_NEXT", "Siguiente");
define("LANG_RELATED", "mostrar historias relacionadas");
define("LANG_NOTFOUND", "Ninguna historias encontradas");
define("LANG_COMMENTS", "comentarios");

// comments.php
define("LANG_ADDCOMM", "agregar un comentario");
define("LANG_YOURCOMM", "tu comentario");
define("LANG_NAME", "nombre");
define("LANG_SUBMIT", "enviar tu comentario");
define("LANG_ANON", "an&oacute;nimo");
define("LANG_ALLOW", "permitido");

$months = array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Deciembre");
?>
