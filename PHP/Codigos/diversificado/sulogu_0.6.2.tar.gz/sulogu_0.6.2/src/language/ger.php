<?php

// ####################################################################
// ____________________
// Su Logu - A PHP Blog
// --------------------
//
// (C) 2002, 2003 Fabio Pani
// http://www.fabiopani.it/blog/sulogu.html
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License.
// ####################################################################

// index.php
define("LANG_SEARCH", "Suche");
define("LANG_STORIES", "Blog-Geschichten");
define("LANG_PICTURES", "Blog-Bilder");
define("LANG_LATEST", "Neueste Geschichten");
define("LANG_ARCHIVE", "Archiv");
define("LANG_PERMALINK", "dauerhafte Verbindung zu dieser Geschichte");
define("LANG_INDEX", "Index");
define("LANG_PREVIOUS", "Zur&uuml;ck");
define("LANG_NEXT", "Vorw&auml;rts");
define("LANG_RELATED", "zeigen Sie in Verbindung stehende Geschichten");
define("LANG_NOTFOUND", "Keine Geschichten fanden");
define("LANG_COMMENTS", "Anmerkungen");

// comments.php
define("LANG_ADDCOMM", "addieren Sie Ihre Anmerkung");
define("LANG_YOURCOMM", "Ihre Anmerkung");
define("LANG_NAME", "Name");
define("LANG_SUBMIT", "senden Sie Ihre Anmerkung");
define("LANG_ANON", "anonym");
define("LANG_ALLOW", "gew&auml;hrt");

$months = array("Januar", "Februar", "M&auml;rz", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember");
?>
