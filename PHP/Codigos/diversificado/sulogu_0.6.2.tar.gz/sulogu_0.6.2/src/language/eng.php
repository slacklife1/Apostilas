<?php

// ####################################################################
// ____________________
// Su Logu - A PHP Blog
// --------------------
//
// (C) 2002, 2003 Fabio Pani
// http://www.fabiopani.it/blog/sulogu.html
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License.
// ####################################################################

// index.php
define("LANG_SEARCH", "Search");
define("LANG_STORIES", "Blog stories");
define("LANG_PICTURES", "Blog pictures");
define("LANG_LATEST", "Latest stories");
define("LANG_ARCHIVE", "Archive");
define("LANG_PERMALINK", "permalink to this story");
define("LANG_INDEX", "Index");
define("LANG_PREVIOUS", "Previous");
define("LANG_NEXT", "Next");
define("LANG_RELATED", "show related stories");
define("LANG_NOTFOUND", "No stories found");
define("LANG_COMMENTS", "comments");

// comments.php
define("LANG_ADDCOMM", "add a comment");
define("LANG_YOURCOMM", "your comment");
define("LANG_NAME", "name");
define("LANG_SUBMIT", "post your comment");
define("LANG_ANON", "anonymous");
define("LANG_ALLOW", "allowed");

$months = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
?>
