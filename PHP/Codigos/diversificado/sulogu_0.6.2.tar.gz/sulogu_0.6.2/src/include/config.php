<?php

// ####################################################################
// ____________________
// Su Logu - A PHP Blog
// --------------------
//
// (C) 2002, 2003 Fabio Pani
// http://www.fabiopani.it/blog/sulogu.html
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License.
// ####################################################################


$leftsidewidth = 240;		// left side table width (pixels)
$vspace = 8;			// used to create a vertical space (pixels)

$imagedir = "images/";		// subdir location for blog pictures

$thumbperrow = 4;		// max thumbnails per row on the picture index
$thumbperpage = 12;		// max thumbnails per page on the picture index (should be a multiple of $thumbperrow)

$startyear = "03";              // First blog online date: year (last two characters)
$startmonth = "01";             // First blog online date: month (use two characters)

$fullnum = 4;			// max number of full stories to show on the main view
$titlenum = 20;			// max number of title to show on the main view
$latestnum = 8;			// max number of title to show in the "Latest stories" section

$blogname = "Give-Me-A-Name-Please!";	// blog name appearing on top-left of the page
$credits1 = "";			// add credits here (you can add up to three lines for your credits)
$credits2 = "";			// add credits here
$credits3 = "";			// add credits here
$permalinkmarker = "+";		// marker used for the permalinks
$showpermalinks = TRUE;         // { FALSE | TRUE } hide/show permalinks

//--- XML RSS 2.0 headlines news feed ---
$rssnum = 10;                    // max number of titles
$blogdesc = "Put-a-description-here";			// blog description (required)
$bloglang = "";			// blog language (optional) (for example, en-us, it-it)
$blogcopyright = "";		// blog copyright note (optional)
$rssttl = 0;			// time to live (minutes) (optional - 0 = don't put it in RSS file)
$blogeditormail = "";		// blog managing editor email (optional)
$webmastermail = "";		// webmaster email (optional)

// You can specify a link to a main page here, otherwise leave it blank.
// Link will appear on top-right of the page.
$homepagelink = "";		// main home page link (for example, "http://www.my-blog-domain.com")
$homepagedesc = "";		// main home page description (for example: "Go to my Home Page")

$enablecomments = FALSE;	// { FALSE | TRUE } disable/enable reader comments
$allowedtags = "<B><I><U>";     // allowed HTML tags in reader comments

$version = "0.6.2";

if (eregi("config.php", $PHP_SELF)) {
	header("Location: ../index.php");
	die();
}

?>
