<?php

// ####################################################################
// ____________________
// Su Logu - A PHP Blog
// --------------------
//
// (C) 2002, 2003 Fabio Pani
// http://www.fabiopani.it/blog/sulogu.html
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License.
// ####################################################################

// Database connection settings - please check and set the correct values for the following variables!
$dbhost = "localhost";
$dbuser = "mysql_user";
$dbpassword = "mysql_password";
$dbname = "mysql_db_name";

function dbconnect() {
	global $db;
	global $dbhost;
	global $dbuser;
	global $dbpassword;
	global $dbname;

	$db = mysql_connect($dbhost, $dbuser, $dbpassword);
	if ($db) {
		return mysql_select_db($dbname);
	} else {
		return FALSE;
	}
}

function dbdisconnect() {
	global $db;

	@mysql_close($db);
}

if (eregi("database.php", $PHP_SELF)) {
	header("Location: ../index.php");
	die();
}
?>
