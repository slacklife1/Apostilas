<?php

// ####################################################################
// ____________________
// Su Logu - A PHP Blog
// --------------------
//
// (C) 2002, 2003 Fabio Pani
// http://www.fabiopani.it/blog/sulogu.html
//
// This program is free software. You can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License.
// ####################################################################

include("include/database.php");
include("include/config.php");
include("include/utils.php");
require_once("language/language.php");

// Obfuscate email address to spambots.
function encodeemail($emailaddress) {
	$encoded = chunk_split(bin2hex($emailaddress), 2, "%");
	return "%" . substr($encoded, 0, strlen($encoded) - 1);
}

// Convert some HTML special characters. See PHP manual.
// Filter the user comment.
function filtercomment($s) {
	global $allowedtags;

	$s = htmlentities(strip_tags(stripslashes($s), $allowedtags), ENT_NOQUOTES);
	$s = ereg_replace("'", "&#039;", $s);
	$s = ereg_replace("&gt;", ">", $s);
	$s = ereg_replace("&lt;", "<", $s);
	$s = ereg_replace("&amp;", "&", $s);
	$s = ereg_replace("\n", "<BR>", $s);
	return $s;
}

// check now if the user wants to post a new comment
if (($action == "post") && ($usrcomment)) {		// avoid to post empty comments
	$action = "";
	if (dbconnect()) {
		$sql = "INSERT INTO blogcomments VALUES (";
		$sql .= "NULL, ";												// timeid
		$sql .= "'" . $id . "', ";										// storyid
		$sql .= "'" . $name . "', ";									// name
		$sql .= "'" . $email . "', ";									// email
		$sql .= "'" . $url . "', ";										// url
		$sql .= "'" . filtercomment($usrcomment) . "', ";				// usrcomment
		$sql .= "'" . $_SERVER['REMOTE_ADDR'] . "', ";					// ipaddress
		$sql .= "'" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . "')";	// hostname
		mysql_query($sql);
		dbdisconnect();
	}
}

// Set default language (if not specified)
if (!$language) {
	// try to set the user's preferred language from a previous cookie
	if ($_COOKIE['bloglang']) {
		$language = $_COOKIE['bloglang'];
	} else {
		$language = $defaultlanguage;
		setcookie("bloglang", $defaultlanguage);
	}
} else {	// language must exists among defined tags
	if (!languageexists($language)) {
		$language = $defaultlanguage;
		setcookie("bloglang", $defaultlanguage);
	}
}

// Include corresponding language file.
include("language/" . $language . ".php");

$title = $blogname . ": " . constant("LANG_COMMENTS");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE><?php print($title); ?></TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<LINK REL="stylesheet" TYPE="text/css" HREF="style.css" >
</HEAD>
<BODY CLASS="defaultbody">
<?php
print("<P ALIGN=\"left\"><SPAN CLASS=\"commentbigtext\"><STRONG>" . $title . "</STRONG></SPAN><BR>\n");

if ($id) {
	if (dbconnect()) {
		$sql = "SELECT timeid FROM blog WHERE timeid = '" . $id . "'";
		$res = mysql_query($sql);
		if (mysql_num_rows($res) == 0) {	// no stories found
			print("<SPAN CLASS=\"commenttext\"><STRONG>" . constant("LANG_NOTFOUND") . "</STRONG>\n</P>\n");
		} else {
			print("<SPAN CLASS=\"commenttext\"><A HREF=\"#addcomment\">" . constant("LANG_ADDCOMM") . "</A></SPAN></P>\n");
			print("<HR SIZE=\"1\" NOSHADE>");
			// comments
			$sql = "SELECT timeid, name, email, url, usrcomment FROM blogcomments ";
			$sql .= "WHERE storyid = '" . $id . "' ";
			$sql .= "ORDER BY timeid DESC";
			$res = mysql_query($sql);
			$cnt = mysql_num_rows($res);
			while ($line = mysql_fetch_array($res)) {
				print("<TABLE WIDTH=\"100%\" CELLSPACING=\"0\" CELLPADDING=\"2\"BORDER=\"0\">\n");
				print("<TR>\n");
				print("<TD ALIGN=\"left\"><SPAN CLASS=\"commenttext\"><STRONG>[" . $cnt . "]</STRONG></SPAN></TD>\n");
				print("<TD ALIGN=\"right\"><SPAN CLASS=\"commenttext\">" . fmtdatetime($line['timeid'], FALSE) . "</SPAN></TD>\n");
				print("</TR>\n");
				print("<TR><TD COLSPAN=\"2\"><SPAN CLASS=\"commenttext\">&nbsp;</TD></TR>\n");
				print("<TR>\n");
				print("<TD ALIGN=\"leftt\" COLSPAN=\"2\"><SPAN CLASS=\"commenttext\">" . $line['usrcomment'] . "</SPAN></TD>\n");
				print("</TR>\n");
				print("<TR><TD COLSPAN=\"2\"><SPAN CLASS=\"commenttext\">&nbsp;</TD></TR>\n");
				print("<TR>\n");
				if ($line['name']) {
					$usrname = $line['name'];
				} else {
					$usrname = "(" . constant("LANG_ANON") . ")";
				}
				print("<TD ALIGN=\"left\"><SPAN CLASS=\"commenttext\"><STRONG>" . $usrname . "</STRONG></SPAN></TD>\n");
				$s = "";
				if ($line['email'])   { $s = "<A HREF=\"mailto:" . encodeemail($line['email']) . "\">e-mail</A>"; }
				if (validurl($line['url'])) {
					if ($s)   { $s .= "<STRONG> | </STRONG>"; }
					$s .= "<A HREF=\"" . $line['url'] . "\" TARGET=\"_blank\">web</A>";
				}
				print("<TD ALIGN=\"right\"><SPAN CLASS=\"commenttext\">" . $s . "</SPAN></TD>\n");
				print("</TR>\n");
				print("</TABLE>\n");
				print("<HR SIZE=\"1\" NOSHADE>");
				$cnt--;
			}

			// your comment
			print("<A NAME=\"addcomment\"></A>\n");
			print("<FORM ACTION=\"comments.php\" METHOD=\"post\">\n");
			print("<TABLE WIDTH=\"100%\" CELLSPACING=\"0\" CELLPADDING=\"2\"BORDER=\"0\">\n");
			print("<TR><TD COLSPAN=\"2\"><SPAN CLASS=\"commenttext\"><STRONG>" . constant("LANG_YOURCOMM") . "</STRONG></SPAN></TD></TR>\n");
			print("<TR>\n");
			print("<TD ALIGN=\"left\"><SPAN CLASS=\"commenttext\">" . constant("LANG_NAME") . ":</SPAN></TD>\n");
			print("<TD ALIGN=\"right\">\n");
			print("<INPUT CLASS=\"commentinput\" TYPE=\"text\" NAME=\"name\" SIZE=\"30\" MAXLENGTH=\"40\">\n");
			print("</TD>\n");
			print("</TR>\n");
			print("<TR>\n");
			print("<TD ALIGN=\"left\"><SPAN CLASS=\"commenttext\">email:</SPAN></TD>\n");
			print("<TD ALIGN=\"right\">\n");
			print("<INPUT CLASS=\"commentinput\" TYPE=\"text\" NAME=\"email\" SIZE=\"30\" MAXLENGTH=\"40\">\n");
			print("</TD>\n");
			print("</TR>\n");
			print("<TR>\n");
			print("<TD ALIGN=\"left\"><SPAN CLASS=\"commenttext\">web:</SPAN></TD>\n");
			print("<TD ALIGN=\"right\">\n");
			print("<INPUT CLASS=\"commentinput\" TYPE=\"text\" NAME=\"url\" VALUE=\"http://\" SIZE=\"30\" MAXLENGTH=\"255\">\n");
			print("</TD>\n");
			print("</TR>\n");
			print("<TR>\n");
			print("<TD ALIGN=\"left\" COLSPAN=\"2\">\n");
			print("<TEXTAREA CLASS=\"commentinput\" NAME=\"usrcomment\" ROWS=\"6\" COLS=\"40\"></TEXTAREA>\n");
			print("<INPUT TYPE=\"hidden\" NAME=\"language\" VALUE=\"" . $language . "\">\n");
			print("<INPUT TYPE=\"hidden\" NAME=\"id\" VALUE=\"" . $id . "\">\n");
			print("<INPUT TYPE=\"hidden\" NAME=\"action\" VALUE=\"post\">\n");
			print("</TD>\n");
			print("</TR>\n");
			print("<TR>\n");
			print("<TD ALIGN=\"left\"><SPAN CLASS=\"commenttext\">" . constant("LANG_ALLOW") . ": " . ereg_replace("<", "&lt;", ereg_replace(">", "&gt;", $allowedtags)) . "</SPAN></TD>\n");
			print("<TD ALIGN=\"right\"><INPUT CLASS=\"commentsubmit\" TYPE=\"submit\" VALUE=\"" . constant("LANG_SUBMIT") . "\"></TD>\n");
			print("</TR>\n");
			print("</TABLE>\n");
			print("</FORM>\n");
			print("<HR SIZE=\"1\" NOSHADE>");

			// credits
			print("<CENTER><SPAN CLASS=\"smalltext\">Powered by <A HREF=\"http://www.fabiopani.it/blog/sulogu.html\" TARGET=\"_blank\" TITLE=\"Su Logu Official Page\"><STRONG>Su Logu</STRONG></A> - A free PHP blog by <A HREF=\"http://www.fabiopani.it\" TARGET=\"_blank\"><STRONG>Fabiux</STRONG></A> (version " . $version . ")</SPAN></CENTER>\n");
		}
		dbdisconnect();
	}
} else {	// $id not specified
	print("<SPAN CLASS=\"commenttext\"><STRONG>" . constant("LANG_NOTFOUND") . "</STRONG>\n</P>\n");
}
?>
</BODY>
</HTML>
