       <html>
<head>
<title>
IP to DNS to IP
</title>
<body bgcolor=blue>
        <center>
<hr>
<form method=post name =ip action=ip.php>
<input type=text name=ip_host size=25>
<br>
<input type=submit value="IP to DNS">
</form>
<br>
<hr>
<form method=post name = dns action=dns.php>
<input type=text name=dns_host size=25>
<br>
<input type=submit name=dns value="DNS to IP">
</form>


     </center>
<?php

$dns_value=gethostbyname($dns_host);

 if($dns_value==$dns_host){

   echo"<center><font color=white size=+1>Invalid DNS !</font></center>";

     }
   else

  echo"<center><font color=white size=+2><b>$dns_value</b></font></center>";


?>
</body>
</html>
