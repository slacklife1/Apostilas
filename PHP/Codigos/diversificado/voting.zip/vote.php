<?

    $filename = "poll.txt";
    $fl=fopen($filename,'r');

    $name = fgets($fl, 4096);
    $options[0] = fgets($fl, 5);

    $temp = $options[0];
    while ($temp) {
        $theoptions[$temp] = fgets($fl, 4096);
        $temp = $temp - 1;
    }

    $temp = $options[0];
    while ($temp) {
        $thevalues[$temp] = fgets($fl, 4096);
        $temp = $temp - 1;
    }
    fclose($fl);


    if ($results) {

        echo "$name<br>";
        $temp = $options[0];
        while ($temp) {
            if ($thevalues[$temp] == 0) {
                $percent = 0;
            } else {

                $tempnum = $options[0];
                $total = 0;
                while ($tempnum) {
                    $total += Trim($thevalues[$tempnum]);
                    $tempnum = $tempnum - 1;
                }

                $percent = 100 * Trim($thevalues[$temp]) / $total;
                if (strlen($percent) > 4) {
                   $percent = substr($percent, 0, 4);
                }
            }

            echo "$theoptions[$temp]: $percent% ($thevalues[$temp] votes)<br><br>";
            $temp = $temp - 1;
        }

   } elseif ($vote) {

       echo "You voted for $theoptions[$optradio]<br>";

       unlink($filename);
       $fl = fopen($filename, 'w');
       fputs($fl, "$name");
       fputs($fl, "$options[0]");

       $temp = $options[0];
       while ($temp) {
           fputs($fl, "$theoptions[$temp]");
           $temp = $temp - 1;
       }

       $temp = $options[0];
       while ($temp) {
           if ($temp == $optradio) {
               fputs($fl, "$thevalues[$temp]" + 1);
               fputs($fl, "\n");
               $temp = $temp - 1;
           } else {
               fputs($fl, "$thevalues[$temp]");
               $temp = $temp - 1;
           }
       }
       fclose($fl);

   } else {
       echo "$name<br>";
       $temp = $options[0];
       echo "<form method=\"post\" action=\"$PHP_SELF\">";
       while ($temp) {
           echo "<input type=\"radio\" name=\"optradio\" value=\"$temp\"> $theoptions[$temp]<br>";
           $temp = $temp - 1;
       }
       echo "<input type=\"submit\" name=\"vote\" value=\"Vote\">";
       echo "<input type=\"submit\" name=\"results\" value=\"View Results\">";
   }

?> 