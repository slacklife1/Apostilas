A "fairly" simple PHP voting script. The script requires a file "poll.txt" with the following format:

poll name
number of poll options
poll option
poll option
...
value of poll option 1
value of poll option 2
...

Example:
Do you like PHP?
3
Yes
No
Maybe
6
4
1