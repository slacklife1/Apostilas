#include <libpem.h>
#include <phpdl.h>

/* string pem_encrypt(string method,string key,string data); */
DLEXPORT void pem_encrypt(INTERNAL_FUNCTION_PARAMETERS)
{
	pval *method,*key,*data;
	char *buffer;
	long outsize=0;
	encPlug Pem;

	if ((ARG_COUNT(ht)!=3)||getParameters(ht,3,&method,&key,&data)==FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_string(method);
	convert_to_string(key);
	convert_to_string(data);

	Pem=getPemPlugin(method->value.str.val);
	
	if(Pem==NULL) {
		if(pemError!=NULL) {
			php3_error(E_WARNING,pemError);
			RETURN_FALSE;
		} else {
			php3_error(E_WARNING,"Unable to load PEM plugin %s...\n",method->value.str.val);
			RETURN_FALSE;
		}
	}
	
	Pem->blockEncrypt(key->value.str.val,key->value.str.len,data->value.str.val,data->value.str.len,&buffer,&outsize);

	RETURN_STRINGL(buffer,outsize,TRUE);
}

/* string pem_decrypt(string method,string key,string data); */
DLEXPORT void pem_decrypt(INTERNAL_FUNCTION_PARAMETERS)
{
	pval *method,*key,*data;
	char *buffer;
	u4byte outsize=0;
	encPlug Pem;

	if ((ARG_COUNT(ht)!=3)||getParameters(ht,3,&method,&key,&data)==FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_string(method);
	convert_to_string(key);
	convert_to_string(data);

	Pem=getPemPlugin(method->value.str.val);
	
	if(Pem==NULL) {
		if(pemError!=NULL) {
			php3_error(E_WARNING,pemError);
			RETURN_FALSE;
		} else {
			php3_error(E_WARNING,"Unable to load PEM plugin %s...\n",method->value.str.val);
			RETURN_FALSE;
		}
	}
	
	Pem->blockDecrypt(key->value.str.val,key->value.str.len,data->value.str.val,data->value.str.len,&buffer,&outsize);

	RETURN_STRINGL(buffer,outsize,TRUE);
}

DLEXPORT void pem_enumplugs(INTERNAL_FUNCTION_PARAMETERS) {
	int i;
	if(ARG_COUNT(ht)!=0) { WRONG_PARAM_COUNT };
	if(nrPemPlugs==0) RETURN_FALSE;
	array_init(return_value);
	for(i=0;i<nrPemPlugs;i++) {
		pval plug;
		plug.value.str.val=pemPlugs[i]->Alg_Ident();
		plug.value.str.len=strlen(plug.value.str.val);
		plug.type=IS_STRING;
		pval_copy_constructor(&plug);
		_php3_hash_index_update(return_value->value.ht, i, (void *) &plug, sizeof(pval), NULL);
	}
}

function_entry pem_functions[] = {
	{"pem_encrypt", pem_encrypt, NULL},
	{"pem_decrypt", pem_decrypt, NULL},
	{"pem_enumplugs", pem_enumplugs, NULL},
	{NULL,NULL,NULL}
};

php3_module_entry pem_module_entry = {
	"pem", pem_functions, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL
};

#if COMPILE_DL
DLEXPORT php3_module_entry *get_module(void) { return &pem_module_entry; }
#endif
