#!/bin/sh
langs=
for i in *.vl; do
 lang=`echo $i | sed "s/.vl//"`
 echo Making LINC for "$lang"...
 ./make_linc.py < $i > $lang.linc
 langs="$langs $lang"
done
echo Generating LINC database...
./make_lincdb.py $langs > lincdb.inc
