#!/usr/bin/env python

import sys;

print "<?\nfunction LINCDB() {\n";
i = 0;
for linc in sys.argv[1:]:
 f = open(linc + ".vl", "r");
 lang = f.readline();
 lang = lang[0:-1];

 print " $LINCS[%i][0] = \"%s\";" % (i, linc);
 print " $LINCS[%i][1] = \"%s\";" % (i, lang);
 i=i+1;

print " return $LINCS;\n}\n?>";
