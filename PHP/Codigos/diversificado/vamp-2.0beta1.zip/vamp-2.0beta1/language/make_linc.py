#!/usr/bin/env python
import sys;

template = open('default.vl', 'r');

print "<?\nfunction TRANSLATE($old) {";

los = [];
lts = [];

while 1:
 lo = template.readline();
 lt = sys.stdin.readline();
 if (lo == "") or (lt == ""):
  break;
 lo = lo[0:-1];
 lt = lt[0:-1];
 if los.count(lo) > 0:
  sys.stderr.write("Warning, duplicate template for '"+lo+"'!\n");
 if lts.count(lt) > 0:
  sys.stderr.write("Warning, duplicate translation for '"+lt+"'!\n");
 los.append(lo);
 lts.append(lt);
 print " if($old == \""+lo+"\") return \""+lt+"\";";

print "return $old;";
print "}";
