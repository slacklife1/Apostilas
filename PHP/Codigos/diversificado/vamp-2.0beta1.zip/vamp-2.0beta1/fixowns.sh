#!/bin/sh

chown -R $1 *
chgrp -R $2 *
chmod -R og-rwx *
