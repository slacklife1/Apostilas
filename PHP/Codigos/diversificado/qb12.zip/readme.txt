		/*-------------------------------------------------------------*\
		|								|
		|								|
		|	       		 *---QuickBlogger v1.2---*		|
		|								|
		|								|
		|		Created By: Jaryd White-AKA-JRiderofShade	|
		|								|
		|		Last updated: 6-13-03				|
		|								|
		|			::::Extra Thanks to::::			|
		|								|
		|	roy		http://www.neopages.net/		|
		|	boy		http://boy.neominds.net/		|
		|	d3p		http://vlad.neosurge.net/		|
		|	f1		http://mywebland.neopages.net/		|
		|	epic		http://www.phpnation.net/		|
		|	VersusVS	http://www.blackcode.org/afterglow/	|
		|								|
		|								|
		|								|
		|								|
		|								|
		\*-------------------------------------------------------------*/

Contents:
I.	Overveiw
II.	Whats new
III.	Installation
IV.	Useing
V.	Other Information



*--------Overveiw--------*

QuickBlogger v1.2 is the third release of a script designed to make it very fast and easy to add and edit entries in your blog with a SQL database. The only requirement to use this script is that your host supports php4+. You can use this script for your blog or to add news to your site. QuickBlogger v1.2 supports up to two(2) different sections to edit and password authentication.

QuickBlogger is a simple script that allows you to write to a file being read by your blog page with a simple form.
No need to open your html files and edit manually. QuickBlogger will also insert the correct date for you.



*--------Whats new--------*

Lots new this time around. I added the ability to edit your entries without having a SQL database. QuickBlogger now uses a flat file database. It took awhile to get it to work without anyway to screw it up but now it works great! I also added a simple feature to allow you to post images or links within your blog without having to know the code!
-Changed output format
-Added link and image feature
-Added editing capabilities
-Bugs fixed
-Easier to set up



*--------Installation--------*



*-----EXTRACTING
Extract all files from qb12.zip to your harddrive. 





*-----SETTING UP PASSWORD
Open the file "new.php" and "edit3.php" in notepad. Find the this line in each file:

$mypassword = "mysecretpassword";

Change mysecretpassword to your desired password.





*-----UPLOADING
Upload the whole QuickBlogger folder to your root directory. CHMOD bs1.html and bs2.html to 777.

*EXAMPLE*
This is your root directory
http://www.yourdomain.com/

And the QuickBlogger folder would be here:
http://www.yourdomain.com/quickblogger/      





*-----SETTING UP

1. Setting up for an existing blog page
2. Setting up useing the template blog included in zip file


1-Existing blog page
To set up QuickBlogger with your webpage you must insert this code wherever you want the entries to show:



<iframe src="file.html" width="100%" height="100%" name="bs1" frameborder="0"></iframe>


And place this code where you want the information in the second file to show:


<iframe src="bs2.html" width="100%" height="100%" name="bs2" frameborder="0"></iframe>

Also note that your blog page needs to be named blog.html and it must be in your quickblogger directory.



2-Useing blog template

Simply edit the links in the template file (blog.html) however you want and then upload to your quickblogger directory.




*--------Using--------*

Goto the URL of acc.html, this should be http://www.yourdomain.com/quickblogger/acc.html Select wheter you want to ADD a new entry to your blog or EDIT and existing entry.




*-------New Entries
Fill in the information in each feild and click the submition button. *NOTE* You cannot add to both sections at once.

It is a good idea to set the background color of the html document to match your website, do this first by typing in this code and replaceing the colors to match your own:

<body bgcolor="#000000" text="#000000" link="#000000" alink="#000000" vlink="#000000">

To find the bg color of one of the templates, just search for the hex code in the html file.



*------Editing entries
Select from the drop down menu the entry you wish to edit. The newest entry is always numbered 0 and the oldest entry is always the highest number. So entry number 2 whould be numbered 1 and entry number 5 would be numbered 4, etc.

Once you have selected the entry to edit click the sumbit button and proceed to the next page. You will be shown what is on that entry so you can copy and paste if you wish. Fill in the feilds like you would when adding a new entry and click the submit button.

*NOTE* When editing an entry you cannot edit your name, we presumed that the editor would have the same name as the poster :D



*--------Other--------*

Since I have added so much more to this script this round I will assume there will be some bugs, plz email them to the address below. If you are interested in helping with further production of QuickBlogger and other scripts also email the one below. If you are having trouble setting up this script, guess what to do? yea thats right, email the address below :P Thx!
support@shadecorp.neopages.net thanks!

*-----Copyright info: This script is freeware, you can modify any of the files however you want and distribute FREELY. Please leave the credits in the readme file if you plan to distribute, take credit for your own work not mine. If u wanna be in the credits then email me and help with the next version. Also report any sale of this script to my email listed above.  Visit my website http://shade.makes.it

THANKS!
Jaryd White-AKA-JRiderofShade