<?
$mypassword ="mysecretpassword";
if($HTTP_POST_VARS['password'] == $mypassword) {
if($HTTP_POST_VARS['mood']=='' || $HTTP_POST_VARS['entry']==''){
echo "<td height='475' width='100%' valign='center'> <strong><font size='2' face='Tahoma'>You 
left one of the required feilds blank. Please go back and fix this.</font></strong></td>";
}

elseif($HTTP_POST_VARS['mood']=='|' || $HTTP_POST_VARS['mood']=='\n' || $HTTP_POST_VARS['entry']=='|' || $HTTP_POST_VARS['entry']=='\n'){
echo "<td height='475' width='100%' valign='center'> <strong><font size='2' face='Tahoma'>No feilds can contain the pipe symbol! Please go back and fix this.</font></strong></td>";
}
else {
$filename = 'file.html';
$fp = fopen( $filename, 'r' );
$file_contents = fread( $fp, filesize( $filename ) );
fclose( $fp );
$line = explode("\n", $file_contents);
$arraysize = count ($line);
$i = $_POST['number'];

$entry = explode("|", $line[$i]);
$entry[1] = $_POST['mood'];
$entry[3] = str_replace("\n", "<br>", $_POST['entry']); 
$edited = stripslashes($entry[3]);
$line[$i] = $entry[0] . "|" . "<b>Mood: </b>" . $entry[1] . "<br>|" . $entry[2] . "|" . $edited . "<BR><BR>";
$finish = implode("\n", $line);
$fp = fopen( $filename, 'w' );
fwrite( $fp, $finish );
fclose( $fp );
print "<center><b>Entry edited successfully</b><br><br><a href=confirm.php>Click here for results</a></center>";
}
}
else {
echo "<center><b>PASSWORD INCORRECT!</b>";
}
?>
