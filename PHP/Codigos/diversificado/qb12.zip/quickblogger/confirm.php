<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<title>ACC</title>
<style>
body {font-family:verdana; font-size: 12px; color:black}
td {font-family:verdana; font-size:11px}
.button { font-family:verdana; font-size:12px; font-weight:bold; color:white}
H3
{font-family:verdana; font-size: 18px;
    MARGIN-TOP: 3px;
    MARGIN-BOTTOM: 3px

}
H4
{font-family:verdana; font-size: 16px;
    MARGIN-TOP: 3px;
    MARGIN-BOTTOM: 3px

}
H5
{font-family:verdana; font-size: 14px;
    MARGIN-TOP: 3px;
    MARGIN-BOTTOM: 3px
}
ul { MARGIN-TOP: 3px; MARGIN-BOTTOM: 3px }
A
{
	color: black;
    TEXT-DECORATION: underline
}
A:hover
{
	color: #9999cc;
	TEXT-DECORATION:none
}
</style>
</head>

<body bgcolor="White">

<table align=center width="700" cellspacing="0" cellpadding="0" border="0">
	<tr><td><img border="0" src="top.jpg" width="700" height="17"></td></tr>
</table>

<table align=center width="700" cellspacing="0" cellpadding="1" border="0" height="400">
	<tr><td bgcolor="#9999cc">
		<table align=center width="100%" cellspacing="0" cellpadding="0" border="0" height="100%">
		<tr><td bgcolor="white" valign="top">
    		<table cellspacing=20 border=0 align=center width=100%>
      		<tr><td width=100% valign=top><h5>Results</h5><hr size=1>


<a href="acc.html">Click here to return to ACC</a><br><br>

<?
$file = "file.html";
$file_point = fopen($file, "r");
$file_read = fread($file_point, filesize($file));
print "<b>CONTENTS OF MAIN BLOG SPACE:</b><br><br>$file_read<br><hr size=1><br>";
$file2 = "bs2.html";
$file_point2 = fopen($file2, "r");
$file_read2 = fread($file_point2, filesize($file2));
print "<b>CONTENTS OF SECOND BLOG SPACE:</b><br><br>$file_read2";
?>
              </td>  
     	  </tr>
       	</table>       </td></tr>
		</table>
	</td></tr>
</table>
<table align=center width="700" cellspacing="0" cellpadding="0" border="0" height="8">
	<tr><td><img border="0" src="x.gif" width="700" height="8"></td></tr>
</table>
<table align=center width="700" cellspacing="0" cellpadding="1" border="0" height="60">
	<tr><td bgcolor="#000000">
		<table align=center width="100%" cellspacing="0" cellpadding="0" border="0" height="100%">
		<tr><td bgcolor="#9999cc" height="4"><img src="x.gif" width="600" height="4"></td></tr>
		<tr><td bgcolor="#000000" height="10"><img src="x.gif" width="600" height="10"></td></tr>
		<tr><td bgcolor="#9999cc" height="46" valign="top"><div align=center style="color:white; font-size: 10px">| <a href="acc.html" style="color:white">ACC</a> | <a href="blog.html" style="color:white">View Blog</a> | 
		<a href="confirm.php" style="color:white">View File Contents</a> | 
		<a href=mailto:support@shadecorp.neopages.net style="color:white">Help</a> | 
<br>QuickBlogger V1.2<br>Created by Jaryd White</div></td></tr>
		</table>
	</td></tr>
</table>
</body>
</html>


