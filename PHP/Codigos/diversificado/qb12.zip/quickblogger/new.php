<?

// CHANGE "password" TO YOUR DESIRED PASSWORD
$mypassword = "mysecretpassword";


//			START
if(isset($_POST['first'])) {


//			START
if($HTTP_POST_VARS['password'] == $mypassword) {


//			START
if($HTTP_POST_VARS['mood']=='' || $HTTP_POST_VARS['blogspaceone']==''){
echo "<b><center>You left one of the required feilds blank. Please go back and fix this.</b></center>";
//			END
}
elseif($HTTP_POST_VARS['mood']=='|' || $HTTP_POST_VARS['mood']=='\n' || $HTTP_POST_VARS['blogspaceone']=='|' || $HTTP_POST_VARS['blogspaceone']=='\n'){
echo "<center><b>No feilds can contain the pipe symbol! Please go back and fix this.</b></center>";
}
//			START
else {

$date = date("m.d.y g:i a");
$name = $_POST['name'];
$mood = $_POST['mood'];
$temp = str_replace("\n", "<br>", $_POST['blogspaceone']);
$new = stripslashes($temp);
$file = "file.html";
$file_point = fopen($file, "r");
$file_read = fread($file_point, filesize($file));
$old = $file_read;
fclose($file_point);
$file_name = "file.html";
$file_pointer = fopen($file_name, "w+");

$combine = "<b>-" . $name . "</b><br>|<b>Mood: </b>" . $mood . "<BR>|<I>" . $date . "</i><br>|" . $new . "<BR><BR>\n" . $old;

fwrite($file_pointer, $combine);
print "<center><b>Entry added successfully</b><br><br><a href=confirm.php>Click here for results</a></center>";
fclose($file_pointer);

//			END
}
//			END 
}


else {
echo "<center><b>PASSWORD INCORRECT!</b>";
}

//			END
}

//			START
if(isset($_POST['second'])) {


//			START
if($HTTP_POST_VARS['password'] == $mypassword){


//			START
if($HTTP_POST_VARS['blogspacetwo']==''){
echo "<b><center>You left one of the required feilds blank. Please go back and fix this.</b></center>";


//			END
} 

//			START
else {

$two = stripslashes($_POST['blogspacetwo']);

$file_name2 = "bs2.html";
$file_pointer2 = fopen($file_name2, "w+");
fwrite($file_pointer2, "$two");
print "<center><b>Data edited successfully</b><br><br><a href=confirm.php>Click here for results</a></center>";
fclose($file_pointer2); 


//			END
}

//			END
}
else {
echo "<center><b>PASSWORD INCORRECT!</b>";
}

//			END
}
?>
