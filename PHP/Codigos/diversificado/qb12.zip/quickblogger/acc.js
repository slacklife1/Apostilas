function link(){ 
var link = prompt("Type in the location here \n(EXAMPLE: http://www.yahoo.com)","http://"); 
var name = prompt("Type the text to display here \n (EXAMPLE: Click Here!)","Click Here"); 
var themessage = "<a href=" + link + " target=_blank>" + name + "</a>"; 
document.theform.blogspaceone.value += themessage; 
}

function image(){ 
var image = prompt("Type in the location of the image here \n(EXAMPLE: http://www.yahoo.com)","http://"); 
var themessage = "<img src=" + image + " >"; 
document.theform.blogspaceone.value += themessage; 
}
