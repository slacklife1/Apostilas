<?php
//DON'T MESS WITH ANY OF THIS!
session_start();
include("common.php");

		$link = mysql_connect ($server, $user, $password);
		if (! $link)
			{
			die ("Couldn't connect to mySQL server");
			}
		if (!mysql_select_db ($db, $link) )
			{
			die ("Coldn't open $db: ".mysql_error() );
			}


if ($current_user == "" AND $agentname == "")
	{

	
	include("./templates/user_top.html");
	print "<P><form action=\"./agentadmin.php\" method=\"post\">Please enter your user name and password:<P>";
	print "Login Name: <input type=text name=agentname><P> ";
	print "Password: <input type=text name=agentpassword><P><input type=submit value=\"Log In\"></form><P>";
	
	print "<form action=\"emailpass.php\">Enter your address to get your password emailed to you:<BR><input type=text name=email><P><input type=submit></form><P>";
	include("./templates/user_bottom.html");
	exit;

 } elseif ($agentname != "" OR $current_user != "")
	{


	$sql = "SELECT id 
		FROM agents 
		WHERE agent='$agentname' 
		and agentpass='$agentpassword'";

	$result = mysql_query($sql)
		or die("Couldn't execute query.");

	$num = mysql_numrows($result);

	if ($num == 1) {
		session_register("agentname");
		session_register("agentpassword");
		
		echo "<!-- USER : $agentname -->\r\n";
		print "<!-- Your session ID is ".session_id()."-->\r\n";
		
		session_register("current_user");
		session_register("agent");
		session_register("agenturl");
		session_register("agentemail");
		
		
		//COLLECT INFORMATION ABOUT THE CURRENT USER
		$result = mysql_query("SELECT * FROM agents WHERE agent='$agentname';",$link);
		while ($a_row =mysql_fetch_array ($result) )
		{
			$current_user = $a_row[id];
			$agent = $a_row[agent];
			$agenturl = $a_row[agenturl];
			$agentemail = $a_row[agentemail];
		
		}
		
		
		print "<!-- You are user #$current_user -->\r\n\r\n";
		
		
		

	} else if ($num == 0)  {
		include("./templates/user_top.html");
		echo 'That login/password combination is incorrect.<P>';
		print "<P><form action=\"./agentadmin.php\" method=\"post\">Please enter your user name and password:<P>";
		print "Login Name: <input type=text name=agentname><P> ";
		print "Password: <input type=text name=agentpassword><P><input type=submit value=\"Log In\"></form><P>";
		
		print "<form action=\"emailpass.php\">Enter your address to get your password emailed to you:<BR><input type=text name=email><P><input type=submit></form><P>";
		include("./templates/user_bottom.html");
		exit;

	}

}


			



//print the header
print "<!-- HERE BEGINNETH THE HEADER -->\r\n";
include("./templates/agent_top.html");
	

	//ERRORS AND STATUS DISPLAY IN THE BOX
	
	//DELETE A RECORD
	if ($delete != "")
		{


		
		$query = "DELETE FROM homes WHERE ((id = '$delete') AND (owner = $current_user))";
		if (!mysql_query ($query, $link) )
			{
			die (mysql_error());
			}
		print "Listing #$delete has been removed...";
		
		$query = "DELETE FROM tbl_Files WHERE ((prop_num = '$delete') AND (owner = '$current_user'))";
			if (!mysql_query ($query, $link) )
				{
				die (mysql_error());
				}
			print "Images for property #$delete have also been removed...";
		}
	

	//DELETE AN IMAGE
			
			if ($deleteimage != "")
				{
				$query = "DELETE FROM tbl_Files WHERE ((id_files = $deleteimage) AND (owner='$current_user'))";
				if (!mysql_query ($query, $link) )
					{
					die (mysql_error());
					}
				print "$filename has been removed...";
				
				}


			if ($action == "upload")
				{
				if (isset($binFile) && $binFile != "none")
  					{
   					$data = addslashes(fread(fopen($binFile, "r"), filesize($binFile)));
    				$strDescription = addslashes(nl2br($txtDescription));
    				$sql = "INSERT INTO tbl_Files ";
    				$sql .= "(description, bin_data, filename, filesize, filetype, owner, prop_num) ";
    				$sql .= "VALUES ('$strDescription', '$data', ";
    				$sql .= "'$binFile_name', '$binFile_size', '$binFile_type', '$current_user', '$propnum')";
    	
    				if (!mysql_query ($sql, $link) )
						{
						die (mysql_error());
						}
    	
    				echo "Your image has been added ($binFile_name).";
    
  					}
				}
	
	//MODIFY A RECORD
	if ($modify != "")
		{
		print "editing field $modify...";
			
		//add slashes to input so things don't get fucked up in mySQL	
		$title = addslashes($title);
		$address = addslashes($address);
		$city = addslashes($city);
		$previewdesc = addslashes($previewdesc);
		$fulldesc = addslashes($fulldesc);
		$neighborhood = addslashes($neighborhood);
		$notes = addslashes($notes);
		
		//strip extra characters out of the price
		$price = ereg_replace("[^[:alnum:]]","",$price);
		$sqfeet = ereg_replace("[^[:alnum:]]","",$sqfeet);
		$proptax = ereg_replace("[^[:alnum:]]","",$proptax);

		//formats the description text, if necessary
		if ($linefeeds == "Y")
			{
			$previewdesc = ereg_replace("(\r\n|\n|\r)", "<br>", $previewdesc);
			$fulldesc = ereg_replace("(\r\n|\n|\r)", "<br>", $fulldesc);
			}
			
		
		$query = "UPDATE homes SET title = '$title', address = '$address', city = '$city', state = '$state', zip = '$zip', price = '$price', previewdesc = '$previewdesc', fulldesc = '$fulldesc', type = '$type', imageloc = '$imageloc',  beds ='$beds', baths='$baths', status='$status', featured='$featured', mls='$mls', neighborhood='$neighborhood', agent='$agent', agenturl='$agenturl', agentemail='$agentemail', air = '$air', alrm = '$alrm', bcny = '$bcny', cbl = '$cbl', crp = '$crp', dw = '$dw', dsp = '$dsp', fire = '$fire', gas = '$gas', hdwd = '$hdwd', mw = '$mw', onw = '$onw', pto = '$pto', wadr = '$wadr', wc = '$wc', fee = '$fee', bp = '$bp', boat = '$boat', clb = '$clb', gtd = '$gtd', crt = '$crt', fit = '$fit', ong = '$ong', pw = '$pw', pool = '$pool', pt = '$pt', spa = '$spa', spo = '$spo', tns = '$tns', notes = '$notes', owner = '$current_user', yearbuilt= '$yearbuilt', sqfeet = '$sqfeet', lotsize= '$lotsize', numfloors = '$numfloors', garagesize = '$garagesize', proptax = '$proptax', country = '$country', virtualtour = '$virtualtour' WHERE ((id='$modify') AND (owner = $current_user))";

		if (!mysql_query ($query, $link) )
			{
			die (mysql_error());
			}
		print "Listing #$modify has been updated...";
		}
	
	//ADD A RECORD
	if ($action=="add")
		{
		$dberror = "";
		

		
		//add slashes to input so things don't get fucked up in mySQL	
		$title = addslashes($title);
		$address = addslashes($address);
		$city = addslashes($city);
		$previewdesc = addslashes($previewdesc);
		$fulldesc = addslashes($fulldesc);
		$neighborhood = addslashes($neighborhood);
		
		//strip extra characters out of the price
		$price = ereg_replace("[^[:alnum:]]","",$price);
		$sqfeet = ereg_replace("[^[:alnum:]]","",$sqfeet);
		$proptax = ereg_replace("[^[:alnum:]]","",$proptax);
		
		if ($linefeeds == "Y")
			{
			$previewdesc = ereg_replace("(\r\n|\n|\r)", "<br>", $previewdesc);
			$fulldesc = ereg_replace("(\r\n|\n|\r)", "<br>", $fulldesc);
			}
		
		$query = "INSERT INTO homes (title, address, city, state, zip, price, previewdesc, fulldesc, type, imageloc, beds, baths, status, featured, mls, neighborhood, agent, agenturl, agentemail, air, alrm, bcny, cbl, crp, dw, dsp, fire, gas, hdwd, mw, onw, pto, wadr, wc, fee, bp, boat, clb, gtd, crt, fit, ong, pw, pool, pt, spa, spo, tns, notes, owner, yearbuilt, sqfeet, lotsize, numfloors, garagesize, proptax, country, virtualtour) values ('$title', '$address', '$city', '$state', '$zip', '$price', '$previewdesc', '$fulldesc', '$type', '$imageloc', '$beds', '$baths', '$status', '$featured','$mls', '$neighborhood', '$agent', '$agenturl', '$agentemail', '$air', '$alrm', '$bcny', '$cbl', '$crp', '$dw', '$dsp', '$fire', '$gas', '$hdwd', '$mw', '$onw', '$pto', '$wadr', '$wc', '$fee', '$bp', '$boat', '$clb', '$gtd', '$crt', '$fit', '$ong', '$pw', '$pool', '$pt', '$spa', '$spo', '$tns', '$notes', '$current_user', '$yearbuilt', '$sqfeet', '$lotsize', '$numfloors', '$garagesize', '$proptax', '$country', '$virtualtour')";
  
		if (!mysql_query ($query, $link) )
			{
			die (mysql_error());
			}
		print "Your listing has been added...";
		}
		
		
	//THUS ENDS THE STATUS AREA...	
	?>
	
	
	</font></td></tr>
	</table><P>

<?php
	// THIS IS THE MAIN PROGRAM LOGIC
	
	if ($edit != "")
		//show a specific listing
		{

		session_register("propnum");
		
		print "<center><a href=\"./propview.php?view=$edit\">Preview Listing</a><BR></center>";
		
		$result = mysql_query("SELECT * FROM homes WHERE ((id='$edit') AND (owner = '$current_user'));",$link);
		while ($a_row =mysql_fetch_array ($result) )
			{
			$propnum = $a_row[id];
			
			
			//strip slashes so input appears correctly
			$a_row[title] = stripslashes ($a_row[title]);
			$a_row[address] = stripslashes($a_row[address]);
			$a_row[city] = stripslashes($a_row[city]);
			$a_row[previewdesc] = stripslashes($a_row[previewdesc]);
			$a_row[fulldesc] = stripslashes($a_row[fulldesc]);
			$a_row[neighborhood] = stripslashes($a_row[neighborhood]);
			$a_row[notes] = stripslashes($a_row[notes]);
			
			//format description fields appropriately
			if ($linefeeds == "Y")
				{
				$a_row[previewdesc] = ereg_replace("<br>", "\r\n", $a_row[previewdesc]);
				$a_row[fulldesc] = ereg_replace("<br>", "\r\n", $a_row[fulldesc]);
				}
			
			
			print "<P><form name=\"addlisting\" action=\"./agentadmin.php?modify=$a_row[id]&edit=$a_row[id]\" method=\"post\"><table width=580 border=0 cellpadding=3>";
			
			print "<table width=580 border=0 cellpadding=3>";
			print "<TR><TD width=120 valign=top align=center><font size=1 face=\"Arial,Helvetica,Geneva,Swiss,SunSans-Regular\">";
			
			//select images connected to a given listing
			$query = "SELECT * FROM tbl_Files WHERE prop_num = $propnum";
			$result = mysql_query("$query",$link);
			$num_images = 0;
			while ($image_row =mysql_fetch_array ($result) )
				{
				
				echo "<P> \n";
				echo "<B>$image_row[filename]</b><BR>\n";
				echo "$image_row[filetype] (Size $image_row[filesize])<P>\n";
				echo "<a href='image.php?Id=$image_row[id_files]' target=\"_new\"><img src='image.php?Id=$image_row[id_files]' border=0 width=100 alt='Click to Enlarge'></a><BR>";
				echo stripslashes($image_row[description]) . "<P>\n";
	
				echo "<a href=\"./agentadmin.php?deleteimage=$image_row[id_files]&filename=$image_row[filename]&edit=$propnum\">delete image</a><P><HR><B>";
				$num_images++;
				}
			print "</font></td><td><table width=560>";
			
			print "<tr><td align=right>title:</td><td align=left> <input type=\"text\" name=\"title\" value=\"$a_row[title]\"></td></tr>";
			print "<tr><td align=right>address:</td><td align=left> <input type=\"text\" name=\"address\" value=\"$a_row[address]\"></td></tr>";
			print "<tr><td align=right>city:</td><td align=left> <input type=\"text\" name=\"city\" value=\"$a_row[city]\"></td></tr>";
			print "<tr><td align=right>State:</td><td align=left> ";
			print "<select name=\"state\"> ";
			print "<option value=\"$a_row[state]\">$a_row[state]";
			print "<option value=\"\">-----------";
			print "<option value=\"Alabama\">Alabama";
			print "<option value=\"Alaska\">Alaska";
			print "<option value=\"Arizona\">Arizona";
			print "<option value=\"Arkansas\">Arkansas";
			print "<option value=\"California\">California";
			print "<option value=\"Colorado\">Colorado";
			print "<option value=\"Connecticut\">Connecticut";
			print "<option value=\"Delaware\">Delaware";
			print "<option value=\"District of Columbia\">District of Columbia";
			print "<option value=\"Florida\">Florida";
			print "<option value=\"Georgia\">Georgia";
			print "<option value=\"Hawaii\">Hawaii";
			print "<option value=\"Idaho\">Idaho";
			print "<option value=\"Illinois\">Illinois";
			print "<option value=\"Indiana\">Indiana";
			print "<option value=\"Iowa\">Iowa";
			print "<option value=\"Kansas\">Kansas";
			print "<option value=\"Kentucky\">Kentucky";
			print "<option value=\"Louisiana\">Louisiana";
			print "<option value=\"Maine\">Maine";
			print "<option value=\"Maryland\">Maryland";
			print "<option value=\"Massachusetts\">Massachusetts";
			print "<option value=\"Michigan\">Michigan";
			print "<option value=\"Minnesota\">Minnesota";
			print "<option value=\"Mississippi\">Mississippi";
			print "<option value=\"Missouri\">Missouri";
			print "<option value=\"Montana\">Montana";
			print "<option value=\"Nebraska\">Nebraska";
			print "<option value=\"Nevada\">Nevada";
			print "<option value=\"New Hampshire\">New Hampshire";
			print "<option value=\"New Jersey\">New Jersey";
			print "<option value=\"New Mexico\">New Mexico";
			print "<option value=\"New York\">New York";
			print "<option value=\"North Carolina\">North Carolina";
			print "<option value=\"North Dakota\">North Dakota";
			print "<option value=\"Ohio\">Ohio";
			print "<option value=\"Oklahoma\">Oklahoma";
			print "<option value=\"Oregon\">Oregon";
			print "<option value=\"Pennsylvania\">Pennsylvania";
			print "<option value=\"Rhode Island\">Rhode Island";
			print "<option value=\"South Carolina\">South Carolina";
			print "<option value=\"South Dakota\">South Dakota";
			print "<option value=\"Tennessee\">Tennessee";
			print "<option value=\"Texas\">Texas";
			print "<option value=\"Utah\">Utah";
			print "<option value=\"Vermont\">Vermont";
			print "<option value=\"Virginia\">Virginia";
			print "<option value=\"Washington\">Washington";
			print "<option value=\"West Virginia\">West Virginia";
			print "<option value=\"Wisconsin\">Wisconsin";
			print "<option value=\"Wyoming\">Wyoming";
			print "</select>";
			
			
			
			print "</td></tr>";
			if ($use_country == "Y")
				{
				print "<tr><td align=right>country:</td><td align=left> <input type=\"text\" name=\"country\" value=\"$a_row[country]\"></td></tr>";
				}
				
			print "<tr><td align=right>zip:</td><td align=left> <input type=\"text\" name=\"zip\" value=\"$a_row[zip]\"></td></tr>";
			print "<tr><td align=right>neighborhood:</td><td align=left> <input type=\"text\" name=\"neighborhood\" value=\"$a_row[neighborhood]\">  ";

			
			print "<tr><td align=right>price:</td><td align=left> <input type=\"text\" name=\"price\" value=\"$a_row[price]\">.00</td></tr>";
			
			
			print "<tr><td align=right>preview description:</td><td align=left> <textarea name=\"previewdesc\" rows=2 cols=40>$a_row[previewdesc]</textarea></td></tr>";
			print "<tr><td align=right>full description:</td><td align=left> <textarea name=\"fulldesc\" rows=4 cols=80>$a_row[fulldesc]</textarea></td></tr>";
			print "<tr><td align=right>Type:</td><td align=left>  ";
			print "<SELECT NAME=\"type\"><option value=\"$a_row[type]\">$a_row[type] ";
			print "<option value=\"\">-----------<option value=\"Single Family\">Single Family<option value=\"Condo/Townhouse\">Condo/Townhouse<option value=\"Duplex/Triplex\">Duplex/Triplex<option value=\"Mobile Home\">Mobile Home<option value=\"Vacant Land\">Vacant Land<option value=\"Farm/Ranch\">Farm Ranch<option value=\"Rental Only\">Rental Only<option value=\"Time Share\">Time Share<option value=\"Co-op\">Co-op<option value=\"Other\">Other</SELECT> ";
			
			Print "</td></tr>";
			
			print "<tr><td align=right>beds:</td><td align=left> <input type=\"text\" name=\"beds\" value=\"$a_row[beds]\"></td></tr>";
			print "<tr><td align=right>baths:</td><td align=left> <input type=\"text\" name=\"baths\" value=\"$a_row[baths]\"></td></tr>";
			print "<tr><td align=right>number of floors:</td><td align=left> <input type=\"text\" name=\"numfloors\" value=\"$a_row[numfloors]\"></td></tr>";
		
			print "<tr><td align=right>year built:</td><td align=left> <input type=\"text\" name=\"yearbuilt\" value=\"$a_row[yearbuilt]\"></td></tr>";
			print "<tr><td align=right>square feet:</td><td align=left> <input type=\"text\" name=\"sqfeet\" value=\"$a_row[sqfeet]\"></td></tr>";
			print "<tr><td align=right>lot size:</td><td align=left> <input type=\"text\" name=\"lotsize\" value=\"$a_row[lotsize]\"></td></tr>";
			print "<tr><td align=right>garage size:</td><td align=left> <input type=\"text\" name=\"garagesize\" value=\"$a_row[garagesize]\"></td></tr>";
			print "<tr><td align=right>annual prop tax:</td><td align=left> <input type=\"text\" name=\"proptax\" value=\"$a_row[proptax]\"></td></tr>";
			
			
			
			print "<tr><td align=right>Status:</td><td align=left>  <select name=\"status\" > ";
			print "<option value=\"$a_row[status]\" SELECTED>$a_row[status]</option>";
			print "<option value=\"\">-----------";
			print "<option value=\"Active\">Active</option>";
			print "<option value=\"Pending\">Pending</option>";
			print "<option value=\"Sold\">Sold</option";
			
			print "</select></td></tr>";
			
			if ($agent_feature == "Y")
				{
				print "<tr><td align=right>featured:</td><td align=left>";
				print "<select name=\"featured\"  > ";
				print "<option value=\"Y\">Yes</option>";
				print "<option value=\"N\" SELECTED>No</option>";
				print "</select></td></tr>";
				}
			else
				{
				print "<input type=hidden name=\"featured\" value=\"$a_row[featured]\"> ";
				}
					
					
			print "<tr><td align=right>mls:</td><td align=left> <input type=\"text\" name=\"mls\" value=\"$a_row[mls]\"></td></tr>";			
			
			if ($show_tour == "Y")
				{
				print "<tr><td align=right>virtual tour url:</td><td align=left> <input type=\"text\" name=\"virtualtour\" value=\"$a_row[virtualtour]\"></td></tr>";			
				}
			
			print "<tr><td align=right>agent:</td><td align=left> $a_row[agent]</td></tr>";			
			print "<tr><td align=right>Notes:<br>(Not visible to users)</td><td align=left> <textarea name=\"notes\" rows=4 cols=80>$a_row[notes]</textarea></td></tr>";
			
			print "<TR height=10><td></td><Td></td>";
			print "<tr><td></td><td align=left></td>";
			print "</table>";
			
		
			print "<center><b>Please mark whichever features apply:</b></i>";

				print "<table border=0 width=400 cellpadding=2 cellspacing=0>";
  						print "<tr>";
  							print "<td align=center>";
  								print "<B>HOME FEATURES</b>";
  							print "</td>";
  							print "<td align=center>";
  								print "<b>COMMUNITY FEATURES</b>";
  							print "</td>";
  						print "</tr>";
  						print "<tr>";
  							print "<td valign=top align=right>";
  							
  								print "Balcony <input type=checkbox name=\"bcny\" value=\"y\" ";
  								if ($a_row[bcny] == "y"){print "checked";}
    							print "><br>";
    							
    							print "Patio/Deck <input type=checkbox name=\"pto\" value=\"y\"  ";
  								if ($a_row[pto] == "y"){print "checked";}
    							print "><br>";
    							
    							print "Waterfront <input type=checkbox name=\"onw\" value=\"y\" ";
  								if ($a_row[onw] == "y"){print "checked";}
    							print "><br>";
    							print "<br>";
    							
    							print "Dishwasher <input type=checkbox name=\"dw\" value=\"y\" ";
  								if ($a_row[dw] == "y"){print "checked";}
    							print "><br>";
  								
  								print "Disposal <input type=checkbox name=\"dsp\" value=\"y\" ";
  								if ($a_row[dsp] == "y"){print "checked";}
  								print "><br>";
    							
    							print "Gas Range <input type=checkbox name=\"gas\" value=\"y\"  ";
  								if ($a_row[gas] == "y"){print "checked";}
    							print "><br>";
    							
    							print "Microwave <input type=checkbox name=\"mw\" value=\"y\"  ";
  								if ($a_row[mw] == "y"){print "checked";}
    							print "><br>";
    							
    							print "Washer/Dryer <input type=checkbox name=\"wadr\" value=\"y\" ";
  								if ($a_row[wadr] == "y"){print "checked";}
    							print "><br>";
    							print "<br>";
    							
    							
    							print "Carpeted Floors <input type=checkbox name=\"crp\" value=\"y\" ";
    							if ($a_row[crp] == "y"){print "checked";}
    							print "><br>";
    							
    							print "Hardwood Floors <input type=checkbox name=\"hdwd\" value=\"y\"  ";
  								if ($a_row[hdwd] == "y"){print "checked";}
    							print "><br>";
    							print "<br>";
    							
    						   							  							
    							print "Air Conditioning <input type=checkbox name=\"air\" value=\"y\" ";
    							if ($a_row[air] == "y"){print "checked";}
    							print "><br>";
    							
    							print "Alarm <input type=checkbox name=\"alrm\" value=\"y\" ";
    							if ($a_row[alrm] == "y"){print "checked";}
    							print "><br>";    							    							
  								
 								print " Cable/Satellite TV <input type=checkbox name=\"cbl\" value=\"y\" ";
 								if ($a_row[cbl] == "y"){print "checked";}
    							print "><br>";
    							
  								print "Fireplace <input type=checkbox name=\"fire\" value=\"y\"  ";
  								if ($a_row[fire] == "y"){print "checked";}
    							print "><br>";
  								
  								print "Wheelchair Access <input type=checkbox name=\"wc\" value=\"y\"  ";
  								if ($a_row[wc] == "y"){print "checked";}
    							print "><br>";

    							
  							print "</td>";
  							print "<td valign=top align=right>";
  							
  								print "Fitness Center <input type=checkbox name=\"fit\" value=\"y\"   ";
  								if ($a_row[fit] == "y"){print "checked";}
    							print "><br>";
    							
    							print "Golf Course <input type=checkbox name=\"ong\" value=\"y\"   ";
  								if ($a_row[ong] == "y"){print "checked";}
    							print "><br>";
    							
    							print "Pool <input type=checkbox name=\"pool\" value=\"y\"   ";
  								if ($a_row[pool] == "y"){print "checked";}
    							print "><br>";
    							
    							print "Spa/Jacuzzi <input type=checkbox name=\"spa\" value=\"y\"   ";
  								if ($a_row[spa] == "y"){print "checked";}
    							print "><br>";
    							
    							print "Sports Complex <input type=checkbox name=\"spo\" value=\"y\"   ";
  								if ($a_row[spo] == "y"){print "checked";}
    							print "><br>";
    							
    							print "Tennis Courts <input type=checkbox name=\"tns\" value=\"y\"  ";
  								if ($a_row[tns] == "y"){print "checked";}
    							print "><br>";
    							print "<br>";
    							
    							
  								print "Bike Paths <input type=checkbox name=\"bp\" value=\"y\"   ";
  								if ($a_row[bp] == "y"){print "checked";}
    							print "><br>";
  								
  								print "Boating <input type=checkbox name=\"boat\" value=\"y\"   ";
  								if ($a_row[boat] == "y"){print "checked";}
    							print "><br>";
    							
    							print "Courtyard <input type=checkbox name=\"crt\" value=\"y\"   ";
  								if ($a_row[crt] == "y"){print "checked";}
    							print "><br>";
    							
    							print "Playground/Park <input type=checkbox name=\"pw\" value=\"y\"  ";
  								if ($a_row[pw] == "y"){print "checked";}
    							print "><br>";
    							print "<br>";
    							
    							
  								
  								print "Association Fee <input type=checkbox name=\"fee\" value=\"y\"  ";
  								if ($a_row[fee] == "y"){print "checked";}
    							print "><br>";

 								print "Clubhouse <input type=checkbox name=\"clb\" value=\"y\"  ";
  								if ($a_row[clb] == "y"){print "checked";}
    							print "><br>";

  								print "Controlled Access <input type=checkbox name=\"gtd\" value=\"y\"  ";
  								if ($a_row[gtd] == "y"){print "checked";}
    							print "><br>";

  								print "Public Transportation <input type=checkbox name=\"pt\" value=\"y\"   ";
  								if ($a_row[pt] == "y"){print "checked";}
    							print "><br>";

  								print "<br>";
  								


  								


  							print "</td>";
						print "</tr>";
					print "</table>";
		
			
			print "<P>";
			print "<input type=submit value=\"Update\"></form>";
			
			
			if ($num_images < $max_images)
				{
				print "<CENTER><B>Manage Images</b></center><P>";
				print"<FORM METHOD=\"post\" ACTION=\"agentadmin.php\" ENCTYPE=\"multipart/form-data\">";
				print"<INPUT TYPE=\"hidden\" NAME=\"MAX_FILE_SIZE\" VALUE=\"$max_prop_upload\">";
				print"<INPUT TYPE=\"hidden\" NAME=\"edit\" VALUE=\"$propnum\">";
				print"<INPUT TYPE=\"hidden\" NAME=\"action\" VALUE=\"upload\">";
					print"<TABLE BORDER=\"0\" cellpadding=3>";
						print"<TR>";
  					 		print"<TD>Title: </TD>";
 	  						print"<TD><INPUT NAME=\"txtDescription\" COLS=\"50\"></TD>";
	  					print"</TR>";
  						print"<TR>";
				  	 		print"<TD>File: </TD>";
 					  		print"<TD><INPUT TYPE=\"file\" NAME=\"binFile\"></TD>";
	 				 	print"</TR>";
  						print"<TR>";
  	 						print"<TD COLSPAN=\"2\"><INPUT TYPE=\"submit\" VALUE=\"Upload\"></TD>";
 	 					print"</TR>";
					print"</TABLE>";

				print"</FORM>";
				print "</center></td></tr></table>";
				}
			else
				{
				print "<CENTER><B>Maximum number of images added</b></center>";
				}
			}
	
			
		}
		elseif ($action == "addlisting")
			//add a listing to the directory
			{
			
			//retrieve some information about the user
					
			
			print "<table border=0 cellspacing=0 cellpadding=0 width=580><tr><td>";
 			print "<font face=\"arial,ms sans serif\" size=3><b>Add Listing</b></font>";
 			print "</td></tr></table><P>";

			print "<form name=\"addlisting\" action=\"./agentadmin.php?action=add\" method=post>";
			print "<table width=580 border=0 cellpadding=3>";
			print "<tr><td align=right>title:</td><td align=left> <input type=\"text\" name=\"title\"></td></tr>";
			print "<tr><td align=right>address:</td><td align=left> <input type=\"text\" name=\"address\"></td></tr>";
			print "<tr><td align=right>city:</td><td align=left> <input type=\"text\" name=\"city\"></td></tr>";
			print "<tr><td align=right>state:</td><td align=left>  ";
			print "<SELECT NAME=\"state\"> ";
			
			print "<option value=\"Alabama\">Alabama";
			print "<option value=\"Alaska\">Alaska";
			print "<option value=\"Arizona\">Arizona";
			print "<option value=\"Arkansas\">Arkansas";
			print "<option value=\"California\">California";
			print "<option value=\"Colorado\">Colorado";
			print "<option value=\"Connecticut\">Connecticut";
			print "<option value=\"Delaware\">Delaware";
			print "<option value=\"District of Columbia\">District of Columbia";
			print "<option value=\"Florida\">Florida";
			print "<option value=\"Georgia\">Georgia";
			print "<option value=\"Hawaii\">Hawaii";
			print "<option value=\"Idaho\">Idaho";
			print "<option value=\"Illinois\">Illinois";
			print "<option value=\"Indiana\">Indiana";
			print "<option value=\"Iowa\">Iowa";
			print "<option value=\"Kansas\">Kansas";
			print "<option value=\"Kentucky\">Kentucky";
			print "<option value=\"Louisiana\">Louisiana";
			print "<option value=\"Maine\">Maine";
			print "<option value=\"Maryland\">Maryland";
			print "<option value=\"Massachusetts\">Massachusetts";
			print "<option value=\"Michigan\">Michigan";
			print "<option value=\"Minnesota\">Minnesota";
			print "<option value=\"Mississippi\">Mississippi";
			print "<option value=\"Missouri\">Missouri";
			print "<option value=\"Montana\">Montana";
			print "<option value=\"Nebraska\">Nebraska";
			print "<option value=\"Nevada\">Nevada";
			print "<option value=\"New Hampshire\">New Hampshire";
			print "<option value=\"New Jersey\">New Jersey";
			print "<option value=\"New Mexico\">New Mexico";
			print "<option value=\"New York\">New York";
			print "<option value=\"North Carolina\">North Carolina";
			print "<option value=\"North Dakota\">North Dakota";
			print "<option value=\"Ohio\">Ohio";
			print "<option value=\"Oklahoma\">Oklahoma";
			print "<option value=\"Oregon\">Oregon";
			print "<option value=\"Pennsylvania\">Pennsylvania";
			print "<option value=\"Rhode Island\">Rhode Island";
			print "<option value=\"South Carolina\">South Carolina";
			print "<option value=\"South Dakota\">South Dakota";
			print "<option value=\"Tennessee\">Tennessee";
			print "<option value=\"Texas\">Texas";
			print "<option value=\"Utah\">Utah";
			print "<option value=\"Vermont\">Vermont";
			print "<option value=\"Virginia\">Virginia";
			print "<option value=\"Washington\">Washington";
			print "<option value=\"West Virginia\">West Virginia";
			print "<option value=\"Wisconsin\">Wisconsin";
			print "<option value=\"Wyoming\">Wyoming";
			print "</select>";
			
			
			
			print "</td></tr>";
			
			if ($use_country == "Y")
				{
				print "<tr><td align=right>country:</td><td align=left> <input type=\"text\" name=\"country\" value=\"\"></td></tr>";
				}
				
			print "<tr><td align=right>zip:</td><td align=left> <input type=\"text\" name=\"zip\"></td></tr>";
			print "<tr><td align=right>neighborhood:</td><td align=left> <input type=\"text\" name=\"neighborhood\">";
			
			print "<tr><td align=right>price:</td><td align=left> <input type=\"text\" name=\"price\">.00</td></tr>";
			print "<tr><td align=right>preview description:</td><td align=left> <textarea name=\"previewdesc\" rows=2 cols=40></textarea></td></tr>";
			print "<tr><td align=right>full description:</td><td align=left> <textarea name=\"fulldesc\" rows=4 cols=80></textarea></td></tr>";
			print "<tr><td align=right>Type:</td><td align=left>  ";
			print "<SELECT NAME=\"type\"><option value=\"Single Family\" SELECTED>Single Family<option value=\"Condo/Townhouse\">Condo/Townhouse<option value=\"Duplex/Triplex\">Duplex/Triplex<option NAME=\"Mobile Home\" value=\"Mobile Home\">Mobile Home<option value=\"Vacant Land\">Vacant Land<option value=\"Farm/Ranch\">Farm Ranch<option value=\"Rental Only\">Rental Only<option value=\"Time Share\">Time Share<option value=\"Co-op\">Co-op<option value=\"Other\">Other</SELECT> ";
		
			Print "</td></tr>";

			print "<tr><td align=right>beds:</td><td align=left> <input type=\"text\" name=\"beds\" value=\"\"></td></tr>";
			print "<tr><td align=right>baths:</td><td align=left> <input type=\"text\" name=\"baths\" value=\"\"></td></tr>";
			print "<tr><td align=right>number of floors:</td><td align=left> <input type=\"text\" name=\"numfloors\" value\"\"></td></tr>";
			
			print "<tr><td align=right>year built:</td><td align=left> <input type=\"text\" name=\"yearbuilt\" value=\"\"></td></tr>";
			print "<tr><td align=right>square feet:</td><td align=left> <input type=\"text\" name=\"sqfeet\" value=\"\"></td></tr>";
			print "<tr><td align=right>lot size:</td><td align=left> <input type=\"text\" name=\"lotsize\" value=\"\"></td></tr>";
			print "<tr><td align=right>garage size:</td><td align=left> <input type=\"text\" name=\"garagesize\" value=\"\"></td></tr>";
			print "<tr><td align=right>annual prop tax:</td><td align=left> <input type=\"text\" name=\"proptax\" value=\"\"></td></tr>";
			
			
			
			print "<tr><td align=right>Status:</td><td align=left> <select name=\"status\" > ";
			print "<option value=\"Active\" SELECTED>Active</option>";
			print "<option value=\"Pending\">Pending</option>";
			print "<option value=\"Sold\">Sold</option>";
			
			print "</select></td></tr>";
			
			
			//can agents make a listing into a featured listing?
			
			if ($agent_feature == "Y")
				{
				print "<tr><td align=right>featured:</td><td align=left>  <select name=\"featured\"   > ";
				print "<option value=\"Y\">Yes</option>";
				print "<option value=\"N\" SELECTED>No</option>";
				print "</select></td></tr>";
				}
				
			
				
			print "<tr><td align=right>mls:</td><td align=left> <input type=\"text\" name=\"mls\" value=\"\"></td></tr>";			
			if ($show_tour == "Y")
				{
				print "<tr><td align=right>virtual tour url:</td><td align=left> <input type=\"text\" name=\"virtualtour\" value=\"\"></td></tr>";			
				}
			
			print "<tr><td align=right>Agent:</td><td align=left> $agent</td></tr>";			
			
			
			print "<tr><td align=right>Notes:<BR><font size=1>(Not visible to users)</font></td><td align=left> <textarea name=\"notes\" rows=4 cols=80></textarea></td></tr>";
			

			print "<TR height=10><td></td><Td></td>";
			print "<tr><td></td><td align=left></td>";
			print "</table>";
			
			//define features
			print "<b>Please mark whichever features apply:</b></i>";

				print "<table border=0 width=400 cellpadding=2 cellspacing=0>";
  						print "<tr>";
  							print "<td align=right>";
  								print "<B>HOME FEATURES</b>";
  							print "</td>";
  							print "<td align=right>";
  								print "<b>COMMUNITY FEATURES</b>";
  							print "</td>";
  						print "</tr>";
  						print "<tr>";
  							print "<td valign=top align=right>";
								
									print "Balcony <input type=checkbox name=\"bcny\" value=\"y\" ><br>";
  								print "Patio/Deck <input type=checkbox name=\"pto\" value=\"y\" ><br>";
 								 print "Waterfront <input type=checkbox name=\"onw\" value=\"y\" ><br>";
  								print "<br>";

  								print "Dishwasher <input type=checkbox name=\"dw\" value=\"y\" ><br>";									
									print "Disposal <input type=checkbox name=\"dsp\" value=\"y\" ><br>";
  								print "Gas Range <input type=checkbox name=\"gas\" value=\"y\" ><br>";
  								print "Microwave <input type=checkbox name=\"mw\" value=\"y\" ><br>";
  								print "Washer/Dryer <input type=checkbox name=\"wadr\" value=\"y\" ><br>";
  								print "<br>";

								print "Carpeted Floors <input type=checkbox name=\"crp\" value=\"y\" ><br>";
  								print "Hardwood Floors <input type=checkbox name=\"hdwd\" value=\"y\" ><br>";
  								print "<br>";

    							print "Air Conditioning <input type=checkbox name=\"air\" value=\"y\" ><br>";
    							print "Alarm <input type=checkbox name=\"alrm\" value=\"y\" ><br>";
  								print " Cable/Satellite TV <input type=checkbox name=\"cbl\" value=\"y\" ><br>";
  								print "Fireplace <input type=checkbox name=\"fire\" value=\"y\" ><br>";
  								print "Wheelchair Access <input type=checkbox name=\"wc\" value=\"y\" ><br>";
  								print "<br>";







  							print "</td>";
  							print "<td valign=top align=right>";
  								print "Fitness Center <input type=checkbox name=\"fit\" value=\"y\" ><br>";
 								 print "Golf Course <input type=checkbox name=\"ong\" value=\"y\" ><br>";
  								print "Pool <input type=checkbox name=\"pool\" value=\"y\" ><br>";
  								print "Spa/Jacuzzi <input type=checkbox name=\"spa\" value=\"y\" ><br>";
  								print "Sports Complex <input type=checkbox name=\"spo\" value=\"y\" ><br>";
  								print "Tennis Courts <input type=checkbox name=\"tns\" value=\"y\"><br>";
  								print "<br>";

  								print "Bike Paths <input type=checkbox name=\"bp\" value=\"y\" ><br>";
 								 print " Boating <input type=checkbox name=\"boat\" value=\"y\" ><br>";
  								print "Courtyard <input type=checkbox name=\"crt\" value=\"y\" ><br>";
  								print "Playground/Park <input type=checkbox name=\"pw\" value=\"y\" ><br>";
  								print "<br>";

  								print "Association Fee <input type=checkbox name=\"fee\" value=\"y\" ><br>";
 								 print "Clubhouse <input type=checkbox name=\"clb\" value=\"y\" ><br>";
  								print "Controlled Access <input type=checkbox name=\"gtd\" value=\"y\" ><br>";
  								print "Public Transportation <input type=checkbox name=\"pt\" value=\"y\" ><br>";
  								print "<br>";







  							print "</td>";
						print "</tr>";
					print "</table>";

			
			print "<P>";
			print "<input type=submit></form>";
			print "<P><font size=1>Once you add a listing, you may attach images.<P></font>";
			}
		
		else
			//show all listings
			{				
			$result = mysql_query("SELECT * FROM homes WHERE owner = '$current_user'",$link);
			
			$num_rows = mysql_num_rows($result);
			Print "<table border=0 cellspacing=0 cellpadding = 2 width=580><TR><TD align=left>There are currently <B>$num_rows properties</b> listed.<BR>";
			
			
			
			if ($cur_page == "") {$cur_page = 0;}
			$page_num = $cur_page + 1;
			$total_num_page = ceil($num_rows/$properties_per_page);
		
			print "<Center>";
		
		
		
			if ($total_num_page != 0)
				{
				Print "This is page $page_num of $total_num_page<BR>";
		
				$prevpage = $cur_page-1;
				$nextpage = $cur_page+1;
				if ($page_num != 1){print "<a href=\"./agentadmin.php?cur_page=$prevpage\">Previous Page</a>     ";}
				if ($page_num != $total_num_page){print "  <a href=\"./agentadmin.php?cur_page=$nextpage\">Next Page</a>     ";}
				}
			
			print "</td></tr></table>";
		
			$limit_str = "LIMIT ". $cur_page * $properties_per_page .",$properties_per_page";
			
			$result = mysql_query("SELECT * FROM homes WHERE owner = '$current_user' $limit_str",$link);
			
			while ($a_row =mysql_fetch_array ($result) )
				{
				
				//strip slashes so input appears correctly
				$a_row[title] = stripslashes ($a_row[title]);
				$a_row[address] = stripslashes($a_row[address]);
				$a_row[city] = stripslashes($a_row[city]);
				$a_row[previewdesc] = stripslashes($a_row[previewdesc]);
				$a_row[fulldesc] = stripslashes($a_row[fulldesc]);
				$a_row[neighborhood] = stripslashes($a_row[neighborhood]);
				
				print "<P><table width=580 border=0 cellpadding=3>";
				print "<tr bgcolor=\"black\"><td align=right width=150><B><font size=3 color=\"white\">listing number: $a_row[id]</b></font></td><td align=center bgcolor=\"#CCCCCC\" width=310> <B> <a href=\"./agentadmin.php?edit=$a_row[id]\">modify listing</a></b></td><td width=120 align=middle bgcolor=\"#CCCCCC\"><a href=\"./agentadmin.php?delete=$a_row[id]\">delete listing</a></td></tr>";	
				print "<tr><td align=center valign=middle>";
				
				
				//select images connected to a given listing
						$count = 0;
						$query = "SELECT * FROM tbl_Files WHERE prop_num = $a_row[id] LIMIT 1";
						$output = mysql_query("$query",$link);
						while ($image_row =mysql_fetch_array ($output) )
							{
				
							echo "<a href=\"./agentadmin.php?edit=$a_row[id]\"><img src='image.php?Id=$image_row[id_files]' width=100 border=1></a><BR>";
							$count++;
	
				
							}
						print "</font>";
						
						if ($count == 0)
     					 	{
     					 	print "<a href=\"./agentadmin.php?edit=$a_row[id]\"><img src=\"./images/nophoto.gif\" border=1></a>";
     					 	}
     					 	
				
				print "</td><td><B>$a_row[title]</b><P>$a_row[previewdesc]</td><td></td>";
				print "</table>\r\n\r\n";
			}
		}
	
		//print the footer
		print"\r\n<!-- THUS ENDETH THE MAIN CONTENT -->\r\n<!-- HERE BEGINNETH THE FOOTER -->";
		include("./templates/user_bottom.html");
		
		//gots to close the mysql connection
		mysql_close($link);
?>