<?php
//DON'T MESS WITH THIS CODE!
include("common.php");

//set up SQL connection
	$link = mysql_connect ($server, $user, $password);
		if (! $link)
			{
			die ("Couldn't connect to mySQL server");
			}
		if (!mysql_select_db ($db, $link) )
			{
			die ("Coldn't open $db: ".mysql_error() );
			}
//print the header
print "<!-- HERE BEGINNETH THE HEADER -->\r\n";
include("./templates/user_top.html");


?>

						<center>
							
							
							<font face='\"ms' sans serif\" size="4"><b>Browse Listings</b></font>
							<P>
							<?php
							//calculates the total number of records
							$result = mysql_query("SELECT * FROM homes",$link);
							$num_rows = mysql_num_rows($result);
							?>
							<font face='\"ms' sans serif\" size="3"><a href="./propview.php">Show all properties (<?php print "$num_rows"; ?>)</a></font>

							
				
										<form name=pricesearch action="./propview.php">
							<table border=0 cellspacing=3 cellpadding=3>
							<TR>
								<TD align=center><B>Find me the perfect property:</b></td>
							</tr>
							
							<tr>
								<td ALIGN=right>Minimum Price:</TD><td align=left><input type="text" name="minprice">.00</td>
							</tr>
							<TR>
								<td ALIGN=right>Maximum Price:</TD><td align=left><input type="text" name="maxprice">.00</td>
							</tr>
							<tr>
								<td align=right>City:</td>
								<td align=left>
									<select name="citystate[]" size="4" multiple>
									<?php
									$result = mysql_query("SELECT homes.city, state, count(*) AS num_town FROM homes GROUP BY city ORDER BY state, city;",$link);
									while ($a_row =mysql_fetch_array ($result) )
										{
										$city = stripslashes($a_row[city]);
										print "<option name=\"citystate\" value=\"$a_row[city]___$a_row[state]\">$city, $a_row[state] ($a_row[num_town])";
										}
									?>
									</select>
								</td>
							</tr>
							
							<tr>
								<td align=right>Type:</td>
								<td align=left>
									<select name="typechoice[]" size="4" multiple>
									<?php
									$result = mysql_query("SELECT type, count(*) AS num_type FROM homes GROUP BY type;",$link);
									while ($a_row =mysql_fetch_array ($result) )
										{
										print "<option name=\"typechoice[]\" value=\"$a_row[type]\">$a_row[type] ($a_row[num_type])";
										}
									?>
									</select>
								</td>
							</tr>
							
							<tr>
								<td align=right>Status:</td>
								<td align=left>
									<select name="statuschoice[]" size="4" multiple>
									<?php
									$result = mysql_query("SELECT status, count(*) AS num_town FROM homes GROUP BY status;",$link);
									while ($a_row =mysql_fetch_array ($result) )
										{
										print "<option name=\"statuschoice[]\" value=\"$a_row[status]\">$a_row[status] ($a_row[num_town])";
										}
									?>
									</select>
								</td>
							</tr>
							
								
							
							<tr>
								<td align=center></td>
							</tr>
								
							</table>
							
											<table border=0 width=400 cellpadding=2 cellspacing=0>
  						<tr>
  							<td align=right>
  								<B>HOME FEATURES</b>
  							</td>
  							<td align=right>
  								<b>COMMUNITY FEATURES</b>
  							</td>
  						</tr>
  						<tr>
  							<td valign=top align=right>
								
								Balcony <input type=checkbox name="bcny" value="y" ><br>
  								Patio/Deck <input type=checkbox name="pto" value="y" ><br>
 								Waterfront <input type=checkbox name="onw" value="y" ><br>
  								<br>

  								Dishwasher <input type=checkbox name="dw" value="y" ><br>									
								Disposal <input type=checkbox name="dsp" value="y" ><br>
  								Gas Range <input type=checkbox name="gas" value="y" ><br>
  								Microwave <input type=checkbox name="mw" value="y" ><br>
  								Washer/Dryer <input type=checkbox name="wadr" value="y" ><br>
  								<br>

								Carpeted Floors <input type=checkbox name="crp" value="y" ><br>
  								Hardwood Floors <input type=checkbox name="hdwd" value="y" ><br>
  								<br>

    							Air Conditioning <input type=checkbox name="air" value="y" ><br>
    							Alarm <input type=checkbox name="alrm" value="y" ><br>
  								Cable/Satellite TV <input type=checkbox name="cbl" value="y" ><br>
  								Fireplace <input type=checkbox name="fire" value="y" ><br>
  								Wheelchair Access <input type=checkbox name="wc" value="y" ><br>
  								<br>







  							</td>
  							<td valign=top align=right>
  								Fitness Center <input type=checkbox name="fit" value="y" ><br>
 								Golf Course <input type=checkbox name="ong" value="y" ><br>
  								Pool <input type=checkbox name="pool" value="y" ><br>
  								Spa/Jacuzzi <input type=checkbox name="spa" value="y" ><br>
  								Sports Complex <input type=checkbox name="spo" value="y" ><br>
  								Tennis Courts <input type=checkbox name="tns" value="y"><br>
  								<br>

  								Bike Paths <input type=checkbox name="bp" value="y" ><br>
 								Boating <input type=checkbox name="boat" value="y" ><br>
  								Courtyard <input type=checkbox name="crt" value="y" ><br>
  								Playground/Park <input type=checkbox name="pw" value="y" ><br>
  								<br>

  								Association Fee <input type=checkbox name="fee" value="y" ><br>
 								Clubhouse <input type=checkbox name="clb" value="y" ><br>
  								Controlled Access <input type=checkbox name="gtd" value="y" ><br>
  								Public Transportation <input type=checkbox name="pt" value="y" ><br>
  								<br>







  							</td>
						</tr>
					</table>
							
							
							<input type=submit></form>
				
				</table>
				</center>
				
				
<?php
//print the footer
		print"\r\n<!-- THUS ENDETH THE MAIN CONTENT -->\r\n<!-- HERE BEGINNETH THE FOOTER -->";
		include("./templates/user_bottom.html");

//gots to close the mysql connection
mysql_close($link);
?>
