<?php

include("./admin_upper.html");

?>
<P>
<table border=1 cellspacing=3 cellpadding=3>
	<tr>
		<TD bgcolor=black align=center><font color=white>Admin Functions</font></td>
	</tr>
	<tr><td align=center><a href="admin.php">Main Administration Tool</a></td></tr>
	<tr><td align=center><a href="agenteditor.php">Agent Editor</a></td></tr>
	<tr><td align=center><a href="phpinfo.php">Site Configuration Information</a></td></tr>
	
</table>
<P>

<?php
include("./admin_lower.html");
?>