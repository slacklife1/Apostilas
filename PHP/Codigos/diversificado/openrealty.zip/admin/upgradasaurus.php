<?php
include("../common.php");

  //login authorization code
  if(!isset($PHP_AUTH_USER)) {
    Header("WWW-Authenticate: Basic realm=\"OpenRealty\"");
    Header("HTTP/1.0 401 Unauthorized");
    echo "You must enter a username and password\n";
    exit;
  } else {
    if ($PHP_AUTH_USER != $openadmin) {Header( "HTTP/1.0 401 Unauthorized");die("Enter the correct username");}
    if ($PHP_AUTH_PW != $openpassword) {Header( "HTTP/1.0 401 Unauthorized");die("Enter the correct password");}
  }


//set up SQL connection
	print "Connecting to DB....<BR>";
	$link = mysql_connect ("localhost", $user, $password);
		if (! $link)
			{
			die ("Couldn't connect to mySQL server");
			}
		if (!mysql_select_db ($db, $link) )
			{
			die ("Coldn't open $db: ".mysql_error() );
			}
	Print "Connected!<BR>";
		
		//build tables:
		
		print "Adding materials to table homes:<BR>";
		$querystring = "ALTER TABLE homes ADD (notes TEXT, agentemail VARCHAR (30), owner int, numfloors VARCHAR (30), yearbuilt int, sqfeet int, lotsize VARCHAR (30), garagesize VARCHAR (30), proptax int, country VARCHAR (30), virtualtour VARCHAR (60) );"; 
		print $querystring;
		print "<BR>";
		$result = mysql_query("$querystring");
		if (!$result) print mysql_error();
		print "Created table in $db<BR>";
		
		
		print "Adding table agents:<BR>";
		$querystring = "CREATE TABLE agents (id int NOT NULL AUTO_INCREMENT, PRIMARY KEY (id), agent VARCHAR (30), agentpass VARCHAR (10), agenturl VARCHAR (70), agentemail VARCHAR (70), notes TEXT, agentphone VARCHAR(30), agentcell VARCHAR(30), agentfax VARCHAR (30) );"; 
		print $querystring;
		print "<BR>";
		$result = mysql_query("$querystring");
		if (!$result) print mysql_error();
		print "Created table in $db<BR>";
		
		print "Adding table agent_tbl_Files:<BR>";
		$querystring = "CREATE TABLE agent_tbl_Files (id_files int not null auto_increment, PRIMARY KEY (id_files), bin_data longblob not null, description tinytext, filename VARCHAR (50), filesize VARCHAR (50), filetype VARCHAR (50), agentnum int, owner int );"; 
		print $querystring;
		print "<BR>";
		$result = mysql_query("$querystring");
		if (!$result) print mysql_error();
		print "Created table in $db<BR>";
		
		
		print "Adding table tbl_Files:<BR>";
		$querystring = "CREATE TABLE tbl_Files (id_files int not null auto_increment, PRIMARY KEY (id_files), bin_data longblob not null, description tinytext, filename VARCHAR (50), filesize VARCHAR (50), filetype VARCHAR (50), prop_num int, owner int);"; 
		print $querystring;
		print "<BR>";
		$result = mysql_query("$querystring");
		if (!$result) print mysql_error();
		print "Created table in $db<BR>";
		
	
	
		print "<P><B>Installation Succeeded!</b><P>";
		
		Print "<a href=\"./index.php\">Load OpenRealty</a>";
		
?>