<?php
session_start();
include("../common.php");

 //login authorization code
if ($admin_user != $openadmin)
    {
	print "<P><form action=\"./configurator.php\" method=\"post\">Please enter your user name and password:<P>";
	print "Login Name: <input type=text name=admin_user><P> ";
	print "Password: <input type=text name=admin_password><P><input type=submit value=\"Log In\"></form><P>";
	die("Enter the correct username");
	}
if ($admin_password != $openpassword)
    {
    print "<P><form action=\"./configurator.php\" method=\"post\">Please enter your user name and password:<P>";
	print "Login Name: <input type=text name=admin_user><P> ";
	print "Password: <input type=text name=admin_password><P><input type=submit value=\"Log In\"></form><P>";
    die("Enter the correct password");
    }
    
session_register("admin_user");
session_register("admin_password");


//set up SQL connection
	print "Connecting to DB....<BR>";
	$link = mysql_connect ("localhost", $user, $password);
		if (! $link)
			{
			die ("Couldn't connect to mySQL server");
			}
		if (!mysql_select_db ($db, $link) )
			{
			die ("Coldn't open $db: ".mysql_error() );
			}
	Print "Connected!<BR>";
		
		//build tables:
		
		print "Adding table homes:<BR>";
		$querystring = "CREATE TABLE homes (id INT NOT NULL AUTO_INCREMENT, PRIMARY KEY (id), title VARCHAR (250), address VARCHAR (250), city VARCHAR (50), state VARCHAR (20), zip VARCHAR (20), price int, previewdesc TEXT, fulldesc TEXT, type VARCHAR (20), imageloc VARCHAR (50), beds int, baths FLOAT, status VARCHAR (10), featured VARCHAR (1), mls VARCHAR (20), dateposted DATE, neighborhood VARCHAR (50), agent VARCHAR (30), agenturl VARCHAR (30), air VARCHAR (1), alrm VARCHAR (1), bcny VARCHAR (1), cbl VARCHAR (1), crp VARCHAR (1), dw VARCHAR (1), dsp VARCHAR (1), fire VARCHAR (1), gas VARCHAR (1), hdwd VARCHAR (1), mw VARCHAR (1), onw VARCHAR (1), pto VARCHAR (1), wadr VARCHAR (1), wc VARCHAR (1), fee VARCHAR (1), bp VARCHAR (1), boat VARCHAR (1), clb VARCHAR (1), gtd VARCHAR (1), crt VARCHAR (1), fit VARCHAR (1), ong VARCHAR (1), pw VARCHAR (1), pool VARCHAR (1), pt VARCHAR (1), spa VARCHAR (1), spo VARCHAR (1), tns VARCHAR (1), notes TEXT, agentemail VARCHAR (30), owner int, numfloors VARCHAR (30), yearbuilt int, sqfeet int, lotsize VARCHAR (30), garagesize VARCHAR (30), proptax int, country VARCHAR (30), virtualtour VARCHAR (60) );"; 
		print $querystring;
		print "<BR>";
		$result = mysql_query("$querystring");
		if (!$result) print mysql_error();
		print "Created table in $db<BR>";
		
		
		print "Adding table agents:<BR>";
		$querystring = "CREATE TABLE agents (id int NOT NULL AUTO_INCREMENT, PRIMARY KEY (id), agent VARCHAR (30), agentpass VARCHAR (10), agenturl VARCHAR (70), agentemail VARCHAR (70), notes TEXT, agentphone VARCHAR(30), agentcell VARCHAR(30), agentfax VARCHAR (30) );"; 
		print $querystring;
		print "<BR>";
		$result = mysql_query("$querystring");
		if (!$result) print mysql_error();
		print "Created table in $db<BR>";
		
		print "Adding table agent_tbl_Files:<BR>";
		$querystring = "CREATE TABLE agent_tbl_Files (id_files int not null auto_increment, PRIMARY KEY (id_files), bin_data longblob not null, description tinytext, filename VARCHAR (50), filesize VARCHAR (50), filetype VARCHAR (50), agentnum int, owner int );"; 
		print $querystring;
		print "<BR>";
		$result = mysql_query("$querystring");
		if (!$result) print mysql_error();
		print "Created table in $db<BR>";
		
		
		print "Adding table tbl_Files:<BR>";
		$querystring = "CREATE TABLE tbl_Files (id_files int not null auto_increment, PRIMARY KEY (id_files), bin_data longblob not null, description tinytext, filename VARCHAR (50), filesize VARCHAR (50), filetype VARCHAR (50), prop_num int, owner int);"; 
		print $querystring;
		print "<BR>";
		$result = mysql_query("$querystring");
		if (!$result) print mysql_error();
		print "Created table in $db<BR>";
		
	
	
		print "<P><B>Installation Succeeded!</b><P>";
		
		Print "<a href=\"../index.php\">Load OpenRealty</a>";
		
?>