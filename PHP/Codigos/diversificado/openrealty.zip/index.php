<?php
include("common.php");

//set up SQL connection
	$link = mysql_connect ($server, $user, $password);
		if (! $link)
			{
			die ("Couldn't connect to mySQL server");
			}
		if (!mysql_select_db ($db, $link) )
			{
			die ("Coldn't open $db: ".mysql_error() );
			}
print "<!-- HERE BEGINNETH THE HEADER -->\r\n";
include("./templates/user_top.html");
?>


<table border=0 cellspacing=0>
<tr><td width=120 valign=top>
<!-- left navigation bar -->

<!-- begin feature code-->
<center>


<B><font face=\"ms sans serif\" size=2>Featured Listings:</font></b>


<?php
//EXAMPLE CODE:

//handles the listing of featured properties
$result = mysql_query("SELECT * FROM homes WHERE featured = 'Y';",$link);
while ($a_row =mysql_fetch_array ($result) )
	{
	//add commas to price
	$a_row[price] = number_format ($a_row[price]);
	
	print "<P>";
	print "<a href=\"./propview.php?view=$a_row[id]\"><b>$a_row[title]</b></a><BR>";
	//select images connected to a given listing
				$query = "SELECT * FROM tbl_Files WHERE prop_num = $a_row[id] LIMIT 1";
				$output = mysql_query("$query",$link);
				
				
				$count = 0;
				while ($image_row =mysql_fetch_array ($output) )
					{
					
					
					print "<a href=\"propview.php?view=$a_row[id]\"><img src='image.php?Id=$image_row[id_files]' border=1 width=100 alt=\"Photo\"></a><br>";
					$count++;
					}
				
				
				if ($count == 0)
					{
					print "<a href=\"./propview.php?view=$a_row[id]\"><img src=\"./images/nophoto.gif\" border=1 width=100 alt=\"View Listing\"></a><br>";
					}	
				
	
 	print "$a_row[beds] beds/$a_row[baths] baths<BR>";
  	print "\$$a_row[price]<BR>";
  	print "<P>";
  	

	
	}
//END OF EXAMPLE
?>

</font></center>
</td>
<!-- End feature code -->
<td width=30> </td>
<td valign=top>
<!-- End Header -->


<!-- begin main content -->


<center>
<font face=\"ms sans serif\" size=4><B>Welcome to OpenRealty 2.6 BETA</b></font></center>
<P>
<font face=\"ms sans serif\" size=3>
<center><a href="./browse.php">Browse Listings</a>  |  <a href="http://jonroig.com/freecode/openrealty/bbs/bbbb.php3">Support Forum</a>
<BR>
<BR><a href="http://jonroig.com/freecode/realestate16/openrealty.zip">Download OpenRealty 2.6 BETA</a>
</center>
<p><B>So easy, even a real estate agent can do it!</b> OpenRealty is a free, open source real estate listing manager. Intended to be both easy to install and easy to administer, OpenRealty uses PHP to drive a mySQL backend, thus creating a tool which is fast and flexible.</p>
		<p>While the basic version of OpenRealty can be downloaded for free, I'm always available to customize it for your specific needs. Feel free to <a href="mailto:jon@jonroig.com">contact me</a>.</font></p>
		<BR>
		<P>
		
		
		
		<p><b>Features:</b></p>
		<ul>
			<li>Allows visitors to look through your real estate listings 24 hours a day, 7 days a week, 365.25 days a year.
			<li>Easily keep your property listings updated -- no HTML coding required to add, delete, or modify listings.
			<li>Built-in image manager -- upload photos via your web browser, either when creating new listings or modifying an existing one. If photos are not uploaded for a property, a &quot;photo not available&quot; image will be automatically displayed for the listing.
			<li>Automagically interfaces with Yahoo Maps -- potential customers will always know exactly where to find your property.
			<li>MySQL database backend -- free and fast, mySQL is standard with most hosting plans.
			<li>Secure -- no one but you can change your listings.
			<li>Viral Marketing -- visitors can email listings to their friends right from OpenRealty.
			<li>Easy to install -- just edit a single configuration file.
			<li>Showcase specific properties -- built-in featured listing manager allows you to place special offerings right on your front page.
			<li>Flexible search -- browse properties according to whatever criteria you like.
			<li>Easy setup -- configurator tool makes OpenRealty 2.6 easy to install.
		</ul>
		<p>Of course, OpenRealty is written entirely in PHP, which makes it easy to customize and revise to match the look of your website.</p>
		<p><br>
		<center><B><a href="./openrealty_readme.html">Installation Instructions</a>  |  <a href="http://jonroig.com/freecode/openrealty/bbs/bbbb.php3">Support Forum</a></b></center>
		<P>
		<p><b>Version 2.6 update (3-18-01):</b></p>
		<UL>
			<LI>Changed the authentication scheme. Should now be compatible with a variety of servers, including IIS and NT-based machines.
			<LI>Like version 2.5x, this is not a major upgrade -- no need to do anything if you're happy with the last version
			<LI>Users of version 2.5x shouldn't need to do anything to do the database if they do want to upgrade.
		</UL>
		
		<p><b>Version 2.5.1 update (2-28-01):</b></p>
		SUMMARY OF BUGFIXES FOR THIS VERSION:
		<UL>
			<LI>Not a major upgrade -- no need to do anything if you're happy with the last version
			<LI>Numerous minor tweaks in the agent admin interface and interface improvements
			<LI>Moved the size of uploads to the common.php file
			<LI>Added ability to sort searches... might get an upgrade in the future...
			
		</UL>
		
		PLANNED FOR NEXT VERSION:
		<UL>
			<LI>Reworking of code to make it easier to modify and extend OpenRealty in the future
			<LI>I'm investigating the use of auto-thumbnailing capabilities in PHP, but am not sure if that'll go in the next version.
			<LI>???? Let me know what you're looking for
			
		</UL>


		<p><b>Version 2.5 update (2-20-01):</b></p>
		SUMMARY OF BUGFIXES FOR THIS VERSION:
		<UL>
			<LI>Completely new, database-driven image management system 
			<LI>Ability to handle several agents at once and an admin mode to 
			<LI>Improved interface 
			<LI>Template-driven HTML pages 
			<LI>More feature fields -- including square footage and property size 
		</UL>

		<UL>
			<LI>Closed mySQL connections at the end of every page. This seems important for scalablilty. 
			<LI>Change of 'localhost' to a variable defined in the common.php file.(Way more flexible. Default will still be localhost. 
			<LI>Addition of limits to how many pictures a property can have or an agent can post. Defined in the common.php shared file. 
			<LI>Ability to recognize returns in the comment fields -- so, the agent won't have to worry about an HTML at all. 
			<LI>New image management solves all the jpg/png/gif problems. 
			<LI>The code strips out decimal points when searching by price. Interface changes to help control user input. 
			<LI>Select listing for Washington, DC in 'states' list
			<LI>Stashed admin tools in their own directory
			<LI>Lots of little bug fixes and corrections 
		</UL>

</font>
		<p>
		</table>
		
<?php		
//print the footer
		print"\r\n<!-- THUS ENDETH THE MAIN CONTENT -->\r\n<!-- HERE BEGINNETH THE FOOTER -->";
		include("./templates/user_bottom.html");
		
//gots to close the mysql connection
	mysql_close($link);
?>