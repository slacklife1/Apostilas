<?php
//common include file

//mysql database setup
$user = "db_user";
$password = "db_password";
$db = "realestate_db";
$server = "localhost";


//OPENREALTY ADMIN PASS AND LOGIN
//DEFAULTS TO MYSQL DATABASE USER/PASS
$openadmin = "$user";
$openpassword = "$password";



//SITE INFORMATION
//used mostly for the email a friend function...
//but may come in handy elsewhere.
$baseurl = "http://www.yoursite.com";
$yourname = "Your Name";
$youremail = "Your Name";

//number of properties to list at once:
$properties_per_page = 10;


//AGENT ADMINISTRATION
//use linefeed in description fields 'Y' or 'N'
$linefeeds = "Y";

//maximum number of imges for a given agent
$max_agent_images =1;

//can agents decide to feature a property? 'Y' on 'N'
$agent_feature = "N";

//how large can an agent image be? (n bytes)
$max_agent_upload = 1000000;

//INDIVIDUAL PROPERTY LISTING OPTIONS
//use yahoo maps? 'Y' or 'N'
$yahoomaps = "Y";

//use email-a-friend option? 'Y' or 'N'
$friendmail = "Y";

//maximum numer of images for one property
$max_images = 6;

//use virtual tour URL? 'Y' or 'N'
$show_tour = "Y";

//max size of property images (in bytes)
$max_prop_upload = 1000000;

//use country? 'Y' or 'N'
$use_country = "N";

?>