<?
/***************************************************************************
 *                                
 *   nome do script       : Login AS                
 *   por                  : Arthur Silva
 *   email                : arthursilva@planetstar.com.br
 *   copyright            : (C) 2003 Planet Star
 *   site					  : http://www.as.planetstar.com.br
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   Este programa � livre; voc� pode redistribuir ou modificar
 *   esses s�o os termos do GNU General Public License que � uma publica��o da
 *   Funda��o Livre de Software
 *
 ***************************************************************************/
?>
<br><br><br><br>

 <center><b>
 <h2>Menu</h2><br><br>
 <a href="create.php">Cadastrar usu�rio</a><br><br>
 <a href="alter.php">Modificar usu�rio</a><br><br>
 <a href="del.php">Deletar usu�rio</a><br>
 </b></center>
 