<?
/***************************************************************************
 *                                
 *   nome do script       : Login AS                
 *   por                  : Arthur Silva
 *   email                : arthursilva@planetstar.com.br
 * 
 *   site					  : http://www.as.planetstar.com.br
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   Este programa � livre; voc� pode redistribuir ou modificar
 *   esses s�o os termos do GNU General Public License que � uma publica��o da
 *   Funda��o Livre de Software
 *
 ***************************************************************************/
 ?>
 <br><br><br><br>
 <table width="30%" border="0" cellpading="15" cellspacing="1" align="center" BGColor="black" >
 <tr><td BGColor="white">
 <font face="Hevetica, Arial">
 <small><h3> Administra��o: </h3></small>
 
 
 <form name="form" method="POST" action="check.php">
 Usu�rio<br><input type="text" name="user_form" size="25" value=""><br>
 Senha<br><input type="text" name="pass_form" size="25" value=""><br><br>
 <input type="submit" value="Entrar">
</form> 

  </td></tr>
 </table>
 </font>
 
  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  <center>
 <font face="Hevetica, Arial" size="1">
 <a href="http://www.as.planetstar.com.br>as.planetstar.com.br</a> - Copyright� - Todos os direitos reservados</font></center>
 
