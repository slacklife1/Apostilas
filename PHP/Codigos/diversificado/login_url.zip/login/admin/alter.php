<?
/***************************************************************************
 *                                
 *   nome do script       : Login AS                
 *   por                  : Arthur Silva
 *   email                : arthursilva@planetstar.com.br
 * 
 *   site					  : http://www.as.planetstar.com.br
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   Este programa � livre; voc� pode redistribuir ou modificar
 *   esses s�o os termos do GNU General Public License que � uma publica��o da
 *   Funda��o Livre de Software
 *
 ***************************************************************************/
 ?>
 <font size="2" face="Hevetica, Arial">
 <br><br><br><center>
 <b>Modificar usu�rio:</b><br><br><br>
 <form name="form" method="POST" action="alter_user.php"> 
 Usu�rio:<br><input type="text" name="user_form" maxlength="20" value=""><br>
 <input type="submit" value="Modificar">
 </center>
 
 </font>