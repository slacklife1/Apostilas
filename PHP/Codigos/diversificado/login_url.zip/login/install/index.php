<html>
<center><h2>Instala��o do Login AS </h2><br><br><br></center>

<font size="2" face="Hevetica, Arial">
<b>Configura��o do MYSQL:</b><br><br>
<form name="form" method="POST" action="install.php">
Host:<br><input type="text" name="form_host" value=""><br>
Usu�rio:<br><input type="text" name="form_user" value=""><br>
Senha:<br><input type="text" name="form_pass" value=""><br>
Banco de dados:<br><input type="text" name="form_db" value=""><br><br>
<input type="submit" value="Configurar 01">
</form>
<br>
<br>
<b>Configura��o do usu�rio e senha da administra��o:</b><br><br>
<form name="form" method="POST" action="mysql.php">
Usu�rio:<br><input type="text" name="form_user_adm" value=""><br>
Senha:<br><input type="text" name="form_pass_adm" value=""><br><br>
<input type="submit" value="Configurar 02">
</form>
<br>
<br>
</font>



