<?
/***************************************************************************
 *                                
 *   nome do script       : Login AS                
 *   por                  : Arthur Silva
 *   email                : arthursilva@planetstar.com.br
 *   copyright            : (C) 2003 Planet Star
 *   site					  : http://www.as.planetstar.com.br
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   Este programa � livre; voc� pode redistribuir ou modificar
 *   esses s�o os termos do GNU General Public License que � uma publica��o da
 *   Funda��o Livre de Software
 *
 ***************************************************************************/
 ?>
 <br><br><br><br>
 <table width="30%" border="0" cellpading="15" cellspacing="1" align="center" BGColor="black" >
 <tr><td BGColor="white">
 <font face="Hevetica, Arial">
 <small><h3> Digite seu login e senha: </h3></small>
 
 
 <form name="form" method="POST" action="check.php">
 Usu�rio<br><input type="text" name="userlogin" size="25" value=""><br>
 Senha<br><input type="password" name="userpass" size="25" value=""><br><br>
 <input type="submit" value="Entrar">
</form> 
 
  </td></tr>
 </table>
 </font>
 
