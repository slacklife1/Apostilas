/***************************************************************************
 *                                
 *   nome do script       : Login AS  1.2               
 *   por                  : Arthur Silva
 *   email                : arthursilva@planetstar.com.br
 *   copyright            : (C) 2003 Planet Star
 *   site					  : http://www.as.planetstar.com.br
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   Este programa � livre; voc� pode redistribuir ou modificar
 *   esses s�o os termos do GNU General Public License que � uma publica��o da
 *   Funda��o Livre de Software
 *
 ***************************************************************************/
 
 Para que ele funcione corretamente, de chmod 777 no arquivo "config.php"
 e configure tudo de acordo com seu servidor, para isso entre na pasta
 "install", ap�s a instala��o delete essa pasta de seu servidor.
 
 � altamente recomendavel na parte de admin, voc� pedir seu servidor para 
 por senha na pasta toda.
 
 
 ----------------------------------------
 
 ## Novidades da vers�o 1.2 ## 
 -> Adicionei um limite de caracteres nos campos
 -> Na administra��o, voc� pode alterar os dados do usu�rio