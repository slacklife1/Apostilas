<?
 		 /* Configura��o do Login AS */ 


$host = "localhost"; 

$user = "aeav"; 

$pass = "123456"; 

$db = "planarbr"; 

?>