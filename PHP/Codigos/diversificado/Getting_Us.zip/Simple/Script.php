<html>
<body>
<?php
Echo ("Welcome $name $lname We appreciate you for visiting This is the Information We Gatherd from you");
?>
<br>
<br>
<?php
Echo ("Site: <a href=$url>$sname</a> <br>E-Mail: <a href=$email>$email</a> <br>Age: $age<br> Gender: $gend <br> IP: $REMOTE_ADDR");
?>
</body>
</html>