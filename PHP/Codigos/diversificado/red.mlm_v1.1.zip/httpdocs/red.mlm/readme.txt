////////////////////////////////////////////////////////////////////
//                                                                //
// Red Dot Mailing List Manager v1.1                              //
//                                                                //
//  Copyright 1999 Richard Heyes.                                 //
//                                                                //
//  http://www.heyes-computing.net/red.software/                  //
//  red.software@heyes-computing.net                              //
//                                                                //
//                                                                //
// Permission to use this software and its                        //
// documentation for any purpose other than its incorporation     //
// into a commercial product is hereby granted without fee,       //
// as long as the author is notified that this piece of software  //
// is being used in other applications.                           //
// Permission to copy and distribute this software and its        //
// documentation only for non-commercial use is also granted      //
// without fee, provided, however, that the above copyright       //
// notice appears in all copies and that both the copyright notice//
// and this permission notice appear in supporting documentation. //
// The author makes no representations about the suitability      //
// of this software for any purpose.  It is provided "as is",     //
// without express or implied warranty.                           //
//                                                                //
// Thanks go to Sloopy Joe.                                       //
//                                                                //
////////////////////////////////////////////////////////////////////


-=-=-=-=-=-=-=-=-=-=-=-=-=-=CONTENTS=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-


In the zip file you should find:

/
|-/confirm/                 # A directory
| |
| |dummy_file.txt           # Dummy file. Delete this.
|
|-/images/                  # A directory
| |
| |red.mlm.title.gif        # The title image
|
|common.html.footer.inc     # Goes at the bottom of most screens
|common.html.header.inc     # Goes at the top of most screens
|compose.php3               # The script for sending a message
|onfirm.subscribe.php3      # Subscription confirmation script
|confirm.unsubscribe.php3   # Unsubscription confirmation script
|index.php3                 # The page where peeps subscribe
|list.admin.php3            # The main admin script
|list.php3                  # Processes results of index.php3
|login.php3                 # For logging in to admin script
|readme.txt                 # This file
|stylesheet.css             # Controls some aspects of display
|variables.inc              # Some variables for you to configure


-=-=-=-=-=-=-=-=-=-=-=-=-=-=-SETUP-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

After unpacking the files you need to consider where to put them. I
recommend you leave the structure as-is, otherwise you will
encounter problems when the files call each other. So simply put all
the files in a directory by themselves like so:
 http://www.yourwebsite.com/mailing.list/

Then you need to edit the variables.inc file and set each variable
as listed below:


$fromname = "Mailing List Name";

 This is the name of the mailing list. It will appear in the From:
 box of the subscribers' mail client.
-------------------------------------------------------------------

$fromemail = "mailing.list@yourdomain.com";

 This is the email address of the mailing list. It will also appear
 in the From: box of the subscribers' mail client. This must be a
 valid email address.
-------------------------------------------------------------------

$list_owner = "your.email@yourdomain.com";

 This is your email address. 
-------------------------------------------------------------------

$db = "mailing_list";

 This is the database name. Usually case sensitive.
-------------------------------------------------------------------

$mysql_user = "";

 This is your username for your MySQL server.
-------------------------------------------------------------------

$mysql_pass = "";

 This is your password for your MySQL server.
-------------------------------------------------------------------

$mysql_server = "localhost";

 This is the address of your MySQL server.
-------------------------------------------------------------------

$confirm_fromname = "Mailing List Name";

 This is name of the mailing list. This will go out on all of the
 confirmation emails that get sent out. Virtually always the same
 as above.
-------------------------------------------------------------------

$confirm_fromemail = "mailing.list@yourdomain.com";

 This is the email address that gets sent out with each and every
 confirmation email. This is usually the same as above.
-------------------------------------------------------------------

$easyunsubscribe = "1";

 This determines whether the subscribers have to confirm their
 unsubscription. If set to one, then no they don't, if set to
 zero, then yes they do. It's good netiquette in my opinion to
 have this set to one to make it a simple operation for
 subscribers to get off your list.
-------------------------------------------------------------------

$sub_msg = "Blah blah blah...";

 This is the message that gets sent out in the confirmation email
 asking the subscriber to go to a certain webpage to be confirmed.
 See variables.inc for an example.
-------------------------------------------------------------------

$unsub_msg = "Blah blah blah...";

 This is the message that gets sent out in the confirmation
 email asking the subscriber to go to a certain webpage to be
 confirmed for unsubscription. See variables.inc for an example.
-------------------------------------------------------------------

$instructions = "Blah blah blah...";

 This is what potential subscribers see after submitting their
 email address for inclusion.
-------------------------------------------------------------------

$unsub_instructions = "Blah blah blah...";

 This is what potential unsubscribers see after submitting their
 email address for removal. This is only used if $easyunsubscribe
 is set to zero.
-------------------------------------------------------------------

$url = "http://www.yourdomain.com/red.mlm/";

 This is where you put the files on your website. ALWAYS has to
 have a trailing slash! 
-------------------------------------------------------------------

NOTE: If you alter a files' name, you must check near the top of
      the contents of that file andd see whether you have to change
      a variable called "$nameofdoc". Self explanatory.


Now, on to the creation of the databases...!

The program expects a database something like this:

 create database mailing_list
 create table email_addresses (user_id int(8) not null auto_increment, email varchar(40) not null, date date not null, primary key (user_id), unique idx_user_id (user_id), unique idx_email (email))
 alter table email_addresses alter user_id set default 0
 create table users (user_name varchar(16) NOT NULL, password varchar(16) NOT NULL, UNIQUE (user_name))
 insert into email_addresses values('0', 'richard.heyes@heyes-computing.net', '19991015')
 insert into users values('admin', 'password')

The above lines are not wrapped in any way. Enter each line, execute
it, then carry on to the next. You will almost certainly want to
change the last line for an appropriate username and password.
If you're not sure what to do, then ask your system administrator
or tech support for help. As you will see from the "To do" list I
intend to eventually write an installation script that
automatically creates an appropriate database.

After you`ve created the databases you should be ready to test the
scripts. If you didn`t change any of the database values then your
username to log in with is "admin" and the password is "password".
So go to "login.php3" on your webserver, and log in. Hopefully it
should take you straight to the "list.admin.php3" script, in the form
of the admin menu.

-=-=-=-=-=-=-=-=-=-=-=-=-=-OPERATION-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

On the admin menu you will see:

COMPOSE MESSAGE

 Choose this to compose a message to send to the list.  After
 selecting this you will be taken to compose.php3, at which you
 will see a subject box and message box. Fill them both in and hit
 the button. Take care to read the note about IE4+ - message will
 wrap at 60 characters.

LIST SUBSCRIBERS

 Not a wise idea to use this if you have a large amount of
 subscribers. If you do choose this the program will list each
 subscribers id number, email address and date they joined the list.
 Additionally each entry will have a tick box next to it. Tick this
 box and hit the "Delete Selected" button to delete a particular
 subscriber. You can select more than one at once.

DELETE SUBSCRIBER

 This deletes a subscriber. It goes by id number, not by email
 address and you enter it in the box to the right of the option.
 Since to get this id number you will probably have to do a search
 and when you do a search you also get the tick boxes, I may well
 take this out.

SEARCH FOR A SUBSCRIBER

 As it says, this option searchs based on the value you enter in the
 box to the right of the option. It searchs the email field, not the
 user id field. There are two wild cards that you can use:

 %  -  This specifies "any number of characters".
 _  -  This specifies "one character".

 EG.   richard%  would find any address beginning with richard.
       _ichard%  and so would this.
       %richard% would find any address with richard in it.
       %.co.uk   would find any address ending with .co.uk

ADD A SUBSCRIBER

 As the title suggests, this option adds the email address that you
 enter in the box to the right of the option.

IMPORT LIST OF SUBSCRIBERS

 This could be useful if you already have a mailing list as many
 programs will either keep the list a text file or will at least
 export one. The file needs to be one email address per line, and
 you will of course need to upload it to the same place you keep
 the mailing list scripts. The box on the right of the option is
 for the filename. You will get a list after importing telling you
 which names were successful, which weren't and how many in total
 were imported.

EXPORT LIST OF SUBSCRIBERS

 This simply exports a list of subscribers to a text file, one
 address per line. The box on the right of the option is for the
 filename. Something to note for windows users, is that only <LF>
 is used instead of <CR><LF> for new lines. What this means is that
 if you open the newly generated file in Notepad you will get all
 the email addresses on one line seperated by small black boxes.
 To get around this simply open the file in Wordpad (write.exe),
 save it, and then re-open in Notepad and it should be fine. Of
 course you could just use Wordpad instead of Notepad altogether.

And thats it. 

-=-=-=-=-=-=-=-=-=-=-=-=-=-=ISSUES=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

A. If you have a large mailing list then you may need to increase
   the maximum timelimit for a single script or the script will
   timeout before finishing sending the mail. I'm not too sure
   if Unix users will even have this issue as I've never configured
   PHP under that OS, only under Win32. Speak to your system
   administrator or tech support for further help on this.

B. The speed of the mail() function seems to depend on your OS. For
   example, on unix (FreeBSD 3.0) using sendmail I've had the mail()
   function send approximately 2000 messages in 20 seconds. Naturally
   sendmail was taking a bit longer to get through them. However on
   my Win32 system I couldn't even get it to send more than around
   30-35 messages at all, using two different mail servers. Maybe
   this was due to my php setup, I don't know. If someone could
   confirm or refute this problem, I'd be grateful.

-=-=-=-=-=-=-=-=-=-=-=-=-=TO DO LIST=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Still quite a bit to do as yet (No particular order):

 - Write User management routine.

 - Export routine based upon search results.

 - Unsub/Sub routine could really do with checking to see if the
   email addresses is in the database already before sending out the
   mail.

 - Could do with checking validity of email address before
   subscription confirmation routine.

 - Need to check whether anything was actually entered into boxes by
   subscribers.

 - Write install script.

 - Mailing list header and footer routine.

-=-=-=-=-=-=-=-=-=-SUGGESTIONS AND FEEDBACK-=-=-=-=-=-=-=-=-=-=-=-=

If you have any suggestions or feedback whatsoever (good or bad)
please don't hesitate to email me at:

red.software@heyes-computing.net

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=BUGS-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

If you find any bugs, please could you report them to me at:

red.software@heyes-computing.net

or via my web site:

http://www.heyes-computing.net/red.software/

Thanks very much for using this script and for reading this
document.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

                richard.heyes@heyes-computing.net

                        Red Dot Software




