<?
/*     
    PanaChart - PHP Chart Generator -  October 2003    
	
    Copyright (C) 2003 Eugen Fernea - eugenf@panacode.com
    Panacode Software - info@panacode.com
    http://www.panacode.com/
    
    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation;
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.    
*/  

	Header("Content-Type: image/png");
	require("./panachart.php");
	
	$vCht4 = array(60,40,20,34,5,52,41,20,34,43,64,40);
	$vCht5 = array(12,21,36,27,14,23,3,5,29,23,12,5);
	$vCht6 = array(5,7,3,15,7,8,2,2,2,11,22,3);
	$vLabels = array('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	
	$ochart = new chart(250,130,5, '#eeeeee');
	$ochart->setTitle("Impuls plot","#000000",2);
	$ochart->setPlotArea(SOLID,"#444444", '#dddddd');
	$ochart->setFormat(0,',','.');
	$ochart->addSeries($vCht4,'impuls','Series1', SOLID,'#000000', '#0000ff');
	$ochart->setXAxis('#000000', SOLID, 1, "X Axis");
	$ochart->setYAxis('#000000', SOLID, 2, "");
	$ochart->setLabels($vLabels, '#000000', 1, VERTICAL);
	$ochart->setGrid("#bbbbbb", DASHED, "#bbbbbb", DOTTED);		
	$ochart->plot('');	
?>
