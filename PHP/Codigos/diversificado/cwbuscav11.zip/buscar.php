<?
#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################


include("parte_cima.php");
include("config.php");

if($palavra != ""){
ECHO"
<FONT FACE='$fonte'><FONT SIZE=-1><b>Buscar</b></font><FONT FACE='$fonte'><FONT SIZE=-2><br>A palavra procurada foi: <b>$palavra</b><BR><br>";

// Realiza busca no banco de dados.
$busca = mysql_query("SELECT * FROM sites WHERE descricao LIKE '%$palavra%' and aprovado LIKE '%1%' ORDER BY nomesite") or print (mysql_error());
$lpp = $resultadospg; // Especifique quantos resultados voc� quer por p�gina
$total = mysql_num_rows($busca); // Esta fun��o ir� retornar o total de linhas na tabela
$paginas = ceil($total / $lpp); // Retorna o total de p�ginas
if(!isset($pagina)) { $pagina = 0; } // Especifica uma valor para variavel pagina caso a mesma n�o esteja setada
$inicio = $pagina * $lpp; // Retorna qual ser� a primeira linha a ser mostrada no MySQL
$buscar = mysql_query("SELECT * FROM sites WHERE descricao LIKE '%$palavra%' and aprovado LIKE '%1%' ORDER BY nomesite LIMIT $inicio, $lpp"); // Executa a query no MySQL com o limite de linhas.

while($linha = mysql_fetch_array($buscar)){

$id = $linha["id"];
$nomesite = $linha["nomesite"];
$endsite = $linha["endsite"];
$descricao = $linha["descricao"];
$diacad = $linha["diacad"];
$mescad = $linha["mescad"];
$anocad = $linha["anocad"];
$votos = $linha["votos"];
$notas = $linha["notas"];
$categoria = $linha["categoria"];
$cliques = $linha["cliques"];

if($notas >= 1 or $votos >= 1){
$mediat = ($notas/$votos);

$tamanho = strlen($mediat);
$quantidade = "4";
if($tamanho <= $quantidade)
{
$media = substr_replace($mediat, " ", $quantidade, $tamanho - $quantidade);
}

}else{
$media = $notas;
}

echo" <a href='click.php?acao=visitar&id=$id' target='_blank'><b>$nomesite</b></a>: $descricao<br>
<font color='#909090'>Categoria: <a href='categorias.php?vercat=$categoria'><font color='#909090'>$categoria</a> | Adicionado em: $diacad/$mescad/$anocad<BR>
Cliques: $cliques | M�dia de votos: $media |
<a href='votar.php?idsite=$id'><font color='#909090'>Votar neste Site</a><BR> ";
if($nivelbusca == 2){
echo"<b><a href='modificarsite.php?id=$id'>Modificar</a> | <a href='deletarsite.php?acao=deletar&ida=$id'>Deletar</a></b><BR>";
}
echo"<BR></font></font></font>";
}
// Mosta as op��es Anterior, n�mero das p�ginas e Pr�xima p�gina.
if($pagina > 0) {
   $menos = $pagina - 1;
   $url = "?em=descricao&palavra=$palavra&pagina=$menos";
   echo "<FONT FACE='$fonte'><FONT SIZE=-2><a href='$url'>Anterior</a>"; // Vai para a p�gina anterior

}

for($i=0;$i<$paginas;$i++) { // Gera um loop com o link para as p�ginas
   $url = "?em=descricao&palavra=$palavra&pagina=$i";
   echo "<FONT FACE='$fonte'><FONT SIZE=-2> | <a href='$url'>$i</a> ";
}

if($pagina < ($paginas - 1)) {
   $mais = $pagina + 1;
   $url = "?em=descricao&palavra=$palavra&pagina=$mais";
   echo " | <a href='$url'>Pr�xima</a> </font>";
   }

// Caso n�o haja nenhum resultado da busca.
$total2 = mysql_num_rows($busca);
if($total2 == 0){
echo"<BR>Nenhum resultado foi encontrado com:<BR><BR><b>$palavra
<BR><BR><font color='#FF0000'><b>Tente novamente utilizando outros valores.</b></font></b><BR><BR><a href='javascript:history.go(-1)'>�� Voltar</a>";
}
mysql_free_result($busca);
}

if($palavra == ""){
echo" <FONT FACE='$fonte'><FONT SIZE=-1><b>Buscar</b></font></font><BR><br>
<FONT FACE='$fonte'><FONT SIZE=-2><font color='#FF0000'><b>Erro na busca:</b></font> � necess�rio digitar uma palavra para realizar uma busca.<BR><BR><a href='javascript:history.go(-1)'>�� Voltar</a>";
}


mysql_close($conexao);
include("parte_baixo.php");
?>
