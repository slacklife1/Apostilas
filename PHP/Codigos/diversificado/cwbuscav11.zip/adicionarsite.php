<?

#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("config.php");
include("verifica.php");
include("parte_cima.php");

// Pega o dia, o m�s e o ano
$diacad = date("d");
$mescad = date("m");
$anocad = date("Y");

if($acao == cadastrar){
####################
$sql = "SELECT * FROM sites WHERE nomesite='$nomesite_'";
$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

if(mysql_num_rows($resultado)>0) {

while ($linha=mysql_fetch_array($resultado)) {
$nomesite = $linha["nomesite"];
$endsite = $linha["endsite"];
}
}
// Verifica se algum dado j� est� cadastrado no banco de dados
  if($nomesite_ == $nomesite or $endsite_ == $endsite){
echo"
<FONT FACE='$fonte'><FONT SIZE=-2>
<b><font color='#FF0000'>Erro:</font></b> Este site j� se encontra em nosso banco de dados. Voc� s� pode cadastrar uma vez cada site seu.<br><br><a href='javascript:history.go(-1)'>�� Voltar</a></TD>
";
}
// Verifica campos obrigat�rios em branco
elseif($nomesite_ == "" || $endsite_ == "" || $descricao_ == "" || $cat_ == ""){
echo"

<FONT FACE='$fonte'><FONT SIZE=-2>
<b><font color='#FF0000'>Erro:</font></b> Voc� n�o preencheu todos os campos necess�rios para o cadastro. Por favor, volte e corrija o erro.<br><br><a href='javascript:history.go(-1)'>�� Voltar</a>

";
}else{
// Se ouver algum c�digo html no campo descri��o ele ir� adicionar de forma que ele n�o seja executado em forma de html
$descricao2_ = eregi_replace("<","&lt;",$descricao_);
// Verifica sua op��o no config.php
if($aprovar==0){
$valoraprovar=1;
}
$sql = mysql_query("INSERT INTO sites (nomeuser, nomesite, endsite, descricao, diacad, mescad, anocad, categoria, aprovado) VALUES ('$buscauser', '$nomesite_', '$endsite_', '$descricao2_', '$diacad', '$mescad', '$anocad', '$cat_', '$valoraprovar')") or print(mysql_error());


// ENVIA E-MAIL CONFIRMANDO CADASTRO

$assunto = "$titulosite" ;
$email = "";
$header = "From: $nomesiteb\n";
$header .= "Content-Type: text/html; charset=us-ascii\n";
$header .= "$mailcadastrosite\n";

mail ("$email_", $assunto, $email, $header);

echo"

<FONT FACE='$fonte'><FONT SIZE=-2>
<b><font color='#FF0000'>Sucesso:</font></b> Voc� acaba de cadastrar o seguinte site em nosso sistema:<BR><br>
<b>Nome do Site:</b> $nomesite_<br>
<b>Endere�o do Site:</b> $endsite_<br>
<b>Descri��o:</b> $descricao_<br>
<b>Categoria:</b> $cat_<br>
<b>Cadastrado em:</b> $diacad / $mescad / $anocad
<BR>
<br><a href='javascript:history.go(-1)'>�� Voltar</a>
";

}

}
####################


else{

echo"
<FONT FACE='$fonte'><FONT SIZE=-1><b>Adicionar Site</b></font><br>
<FONT FACE='$fonte'><FONT SIZE=-2>
<form method='POST' action='adicionarsite.php?acao=cadastrar'>
<b>$buscauser</b> voc� pode adicionar quantos sites quiser ao nosso sistema.<BR>";
if($aprovar==1){
echo"Todos os sites cadastrados passar�o por nossa avalia��o antes de ser adiconado ao sistema.<BR>";
}
echo"
<BR><font face='$fonte' size='-2'><b>Nome do site:</b><br>
<input type='text' name='nomesite_' size='20'  style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>
<b>Endere�o do site:</b><br>
<input type='text' name='endsite_' value='http://' size='20' style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>

<b>Descri��o do site:</b><br>
<textarea wrap=on rows='3' name='descricao_' cols='20'  style='font-size: 11px; width: 180; font-family: $fonte; height: 70; border: 1px solid #C0C0C0'></textarea>
  <BR>
<b>Categoria:</b><BR>";
$sql = mysql_query("SELECT * FROM categorias ORDER BY categoria");

while($linha = mysql_fetch_array($sql)) {
$id = $linha["id"];
$cat = $linha["categoria"];
echo"<input type='radio' name='cat_' value='$cat'> $cat <br>
";
}

echo"
</font>
<input type='submit' value='Cadastrar' name='B1'><br>
( Todos os �tens s�o obrigat�rios. )
</form>
<br><a href='javascript:history.go(-1)'>�� Voltar</a>

";
}
mysql_close($conexao);
include("parte_baixo.php");
?>
