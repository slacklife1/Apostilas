<?
#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

$diacad = date("d");
$mescad = date("m");
$anocad = date("Y");

include('config.php');
include('parte_cima.php');

{$query_Recordset = "SELECT COUNT(*) AS total FROM sites";
$Recordset = mysql_query($query_Recordset, $conexao) or die(mysql_error());
$row_Recordset = mysql_fetch_assoc($Recordset);
mysql_free_result($Recordset);
$totalsites = $row_Recordset['total'];
}

echo"<font face='$fonte' size='-1'><b>Seja bem vindo ao nosso site de buscas. O $nomesiteb est� aguardando voc� se apaixonar.<br>
<BR><font face='$fonte' size='-1'></b>Existem <b>$totalsites</b> sites cadastrados no sistema.<BR>
<font face='$fonte' size='-2'><BR><BR><b>Categorias:</b></b><BR><BR>
 <table width='50%' border='0' cellspacing='0' cellpadding='0'>
  <tr>";

// Coloca as categorias em 2 colunas

$select = mysql_query("SELECT * FROM categorias ORDER BY categoria");
$total = mysql_num_rows($select);
$i = 0;
while($dados = mysql_fetch_array($select)){
$i = $i+1;
  if($i%2 == 0){
   echo"<td>";
   echo"<font face='$fonte' size='-2'><font color='#FF0000'><a href='categorias.php?vercat=".$dados["categoria"]."'>".$dados["categoria"]."</a></font></strong></td></tr>";
  }
  else{
   echo"<tr><td>";
   echo"<font face='$fonte' size='-2'><font color='#CC0099'><a href='categorias.php?vercat=".$dados["categoria"]."'>".$dados["categoria"]."</a></font><br>";
  }
 }

echo"</tr></table>";
mysql_close($conexao);
include('parte_baixo.php');

?>
