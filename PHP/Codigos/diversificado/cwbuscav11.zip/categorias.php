<?
#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("parte_cima.php");
include("config.php");

$sql = mysql_query("Select * from categorias WHERE categoria='$vercat'");
while($linha = mysql_fetch_array($sql)) {

$categoria2 = $linha["categoria"];
}

if($categoria2 != $vercat){
echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Buscar</b></font><FONT FACE='$fonte'><FONT SIZE=-2><br>Voc� est� na categoria: <b>$vercat</b><BR><br>
<FONT FACE='$fonte'><FONT SIZE=-2><font color='#FF0000'>A categoria <b>$vercat</b> n�o existe em nosso banco de dados.</font>
<BR><BR><a href='javascript:history.go(-1)'>�� Voltar</a>";
}
else{
ECHO"
<FONT FACE='$fonte'><FONT SIZE=-1><b>Buscar</b></font><FONT FACE='$fonte'><FONT SIZE=-2><br>Voc� est� na categoria: <b>$vercat</b><BR><br>";

$busca = mysql_query("SELECT * FROM sites WHERE categoria = '$vercat' and aprovado = '1' ORDER BY nomesite") or print (mysql_error());
$lpp = $resultadospg; // Especifique quantos resultados voc� quer por p�gina
$total = mysql_num_rows($busca); // Esta fun��o ir� retornar o total de linhas na tabela
$paginas = ceil($total / $lpp); // Retorna o total de p�ginas
if(!isset($pagina)) { $pagina = 0; } // Especifica uma valor para variavel pagina caso a mesma n�o esteja setada
$inicio = $pagina * $lpp; // Retorna qual ser� a primeira linha a ser mostrada no MySQL
$buscar = mysql_query("SELECT * FROM sites WHERE categoria = '$vercat' and aprovado = '1' ORDER BY nomesite LIMIT $inicio, $lpp"); // Executa a query no MySQL com o limite de linhas.

while($linha = mysql_fetch_array($buscar)){

$id = $linha["id"];
$nomesite = $linha["nomesite"];
$endsite = $linha["endsite"];
$descricao = $linha["descricao"];
$diacad = $linha["diacad"];
$mescad = $linha["mescad"];
$anocad = $linha["anocad"];
$votos = $linha["votos"];
$notas = $linha["notas"];
$categoria = $linha["categoria"];
$cliques = $linha["cliques"];

if($notas >= 2 or $votos >= 2){
$mediat = ($notas/$votos);

$tamanho = strlen($mediat);
$quantidade = "4";
if($tamanho <= $quantidade)
{$media = substr_replace($mediat, " ", $quantidade, $tamanho - $quantidade);}

}else{
$media = $notas;
}
echo" <a href='click.php?acao=visitar&id=$id'><b>$nomesite</b></a>: $descricao<br>
<font color='#909090'>Categoria: <a href='categorias.php?vercat=$categoria'><font color='#909090'>$categoria</a> | Adicionado em: $diacad/$mescad/$anocad<BR>
Cliques: $cliques | M�dia de votos: $media |
<a href='votar.php?idsite=$id'><font color='#909090'>Votar neste Site</a><BR>";
if($nivelbusca == 2){
echo"<b><a href='modificarsite.php?id=$id'>Modificar</a> | <a href='deletarsite.php?acao=deletar&ida=$id'>Deletar</a></b><BR>";
}
echo"<BR></font></font></font>";
}
if($pagina > 0) {
   $menos = $pagina - 1;
   $url = "?vercat=$vercat&pagina=$menos";
   echo "<FONT FACE='$fonte'><FONT SIZE=-2><a href='$url'>Anterior</a>"; // Vai para a p�gina anterior

}
for($i=0;$i<$paginas;$i++) { // Gera um loop com o link para as p�ginas
   $url = "?vercat=$vercat&pagina=$i";
   echo "<FONT FACE='$fonte'><FONT SIZE=-2> | <a href='$url'>$i</a> ";
}
if($pagina < ($paginas - 1)) {
   $mais = $pagina + 1;
   $url = "?vercat=$vercat&pagina=$mais";
   echo " | <a href='$url'>Pr�xima</a> </font>";
   }

if($vercat == ""){
echo"<FONT FACE='$fonte'><FONT SIZE=-2><font color='#FF0000'>O campo da categoria est� em branco. � preciso acessar uma categoria existente.</font><BR><BR><a href='javascript:history.go(-1)'>�� Voltar</a>";
}
elseif($total == "0"){
echo"<FONT FACE='$fonte'><FONT SIZE=-2><font color='#FF0000'>Nesta categoria n�o existe nenhum site cadastrado.</font><BR><BR><a href='javascript:history.go(-1)'>�� Voltar</a>";
}

mysql_free_result($busca);
}


mysql_close($conexao);
include("parte_baixo.php");
?>
