<?

#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("config.php");
include("verifica.php");
include("parte_cima.php");

// Pega o dia, o m�s e o ano
$diacad = date("d");
$mescad = date("m");
$anocad = date("Y");

if($acao == cadastrar){
####################
$sql = "SELECT * FROM categorias";
$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

if(mysql_num_rows($resultado)>0) {

while ($linha=mysql_fetch_array($resultado)) {
$nomecat = $linha["categoria"];

}
}
// Verifica se a categoria cadastrada j� existe no banco de dados.
  if($nomecat_ == $nomecat){
echo"
<FONT FACE='$fonte'><FONT SIZE=-2>
<b><font color='#FF0000'>Erro:</font></b> Esta Categoria j� existe em nosso banco de dados.<br><br><a href='javascript:history.go(-1)'>�� Voltar</a></TD>
";
// Verfica se o campo $nomecat est� em branco
}elseif($nomecat_ == ""){
echo"

<FONT FACE='$fonte'><FONT SIZE=-2>
<b><font color='#FF0000'>Erro:</font></b> Voc� n�o preencheu todos o nome da categoria. Por favor, volte e corrija o erro.<br><br><a href='javascript:history.go(-1)'>�� Voltar</a>

";
}else{
// Se estiver tudo certoe ele adiciona a categoria ao banco de dados.
$sql = mysql_query("INSERT INTO categorias (categoria) VALUES ('$nomecat_')") or print(mysql_error());

echo"

<FONT FACE='$fonte'><FONT SIZE=-2>
<b><font color='#FF0000'>Sucesso:</font></b> Voc� acaba de adicionar corretamente a seguinte categoria:<BR><br>
<b>Nome da Categoria:</b> $nomecat_<br>
<br><br><a href='adicionarcategoria.php'>�� Voltar</a>
";
}
}
####################
elseif($acao == deletar){
####################
// Deleta a categoria

$deletar = "DELETE FROM categorias WHERE categoria='$cat_'";
$resultado = mysql_query($deletar)
or die ("N�o foi poss�vel realizar a exclus�o dos dados.");
echo"

<FONT FACE='$fonte'><FONT SIZE=-2>
<b><font color='#FF0000'>Sucesso:</font></b> Voc� acaba de deletar corretamente a seguinte categoria:<BR><br>
<b>Nome da Categoria:</b> $cat_<br>
<br><br><a href='adicionarcategoria.php'>�� Voltar</a>
";
}
###################
else{

echo"
<FONT FACE='$fonte'><FONT SIZE=-1><b>Adicionar Categoria</b></font><br>
<FONT FACE='$fonte'><FONT SIZE=-2>
<form method='POST' action='adicionarcategoria.php?acao=cadastrar'>
<b>$buscauser</b> voc� pode adicionar quantas categorias quiser.<BR>
<BR><font face='$fonte' size='-2'><b>Nome da categoria:</b><br>
<input type='text' name='nomecat_' size='20'  style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>
<BR><font size='-2'><b>Aten��o:</b> N�o utilize espa�os ou virgulas.<BR><BR>
</font>
<input type='submit' value='Cadastrar Categoria' name='B1'><br>
</form>
<FONT FACE='$fonte'><FONT SIZE=-1><b>Deletar Categoria</b></font>
<BR>Selecione a Categoria que deseja deletar:
<form method='POST' action='adicionarcategoria.php?acao=deletar'>
";
$sql = mysql_query("SELECT * FROM categorias ORDER BY categoria");

while($linha = mysql_fetch_array($sql)) {
$idc = $linha["id"];
$cat = $linha["categoria"];
echo"<input type='radio' name='cat_' value='$cat'> $cat <br>
";
}
echo"<input type='submit' value='Deletar Categoria' name='B1'><br>
</form>

<br><a href='javascript:history.go(-1)'>�� Voltar</a>";
}
include("parte_baixo.php");
?>
