# MySQL-Front Dump 2.5
#
# Host: localhost   Database: cwbusca2
# --------------------------------------------------------
# Server version 3.23.32

USE cwbusca2;


#
# Table structure for table 'categorias'
#

DROP TABLE IF EXISTS categorias;
CREATE TABLE categorias (
  id int(5) unsigned NOT NULL auto_increment,
  categoria varchar(255) default NULL,
  PRIMARY KEY (id)
) TYPE=MyISAM;



#
# Dumping data for table 'categorias'
#

INSERT INTO categorias VALUES("1", "Cultura");
INSERT INTO categorias VALUES("2", "Esportes");
INSERT INTO categorias VALUES("3", "Games");
INSERT INTO categorias VALUES("4", "Hackers");
INSERT INTO categorias VALUES("5", "Humor");
INSERT INTO categorias VALUES("6", "Inform�tica");
INSERT INTO categorias VALUES("7", "Internet");
INSERT INTO categorias VALUES("8", "Mista");
INSERT INTO categorias VALUES("9", "M�sica");
INSERT INTO categorias VALUES("10", "Pessoal");
INSERT INTO categorias VALUES("11", "Portais");
INSERT INTO categorias VALUES("12", "Servi�os");
INSERT INTO categorias VALUES("13", "Webmaster");


#
# Table structure for table 'membros'
#

DROP TABLE IF EXISTS membros;
CREATE TABLE membros (
  id int(5) unsigned NOT NULL auto_increment,
  nome varchar(255) default NULL,
  email varchar(255) default NULL,
  login varchar(255) default NULL,
  senha varchar(255) default NULL,
  nivel int(5) unsigned default '1',
  ativo int(5) unsigned default '1',
  PRIMARY KEY (id)
) TYPE=MyISAM;



#
# Dumping data for table 'membros'
#

INSERT INTO membros VALUES("1", "Fernando", "webmaster@comunidadewebmaster.com", "cwbusca", "123", "1", "0");
INSERT INTO membros VALUES("2", "Fernando", "webmaster@comunidadewebmaster.com", "admin", "123", "2", "0");


#
# Table structure for table 'sites'
#

DROP TABLE IF EXISTS sites;
CREATE TABLE sites (
  id int(5) unsigned NOT NULL auto_increment,
  nomeuser varchar(255) default NULL,
  nomesite varchar(255) default NULL,
  endsite varchar(255) default NULL,
  descricao varchar(255) default NULL,
  diacad int(2) default NULL,
  mescad int(2) default NULL,
  anocad int(4) default NULL,
  categoria varchar(255) default NULL,
  aprovado int(5) default '0',
  votos int(5) default '0',
  notas int(5) default '0',
  cliques int(10) default '0',
  PRIMARY KEY (id)
) TYPE=MyISAM;



#
# Dumping data for table 'sites'
#

INSERT INTO sites VALUES("1", "cwbusca", "Comunidade Webmaster", "http://www.comunidadewebmaster.com", "Um site completo voltado exclusivamente para os webmasters do Brasil.", "14", "2", "2004", "Webmaster", "1", "1", "10", "0");
INSERT INTO sites VALUES("2", "cwbusca", "S� Pr�mios", "http://www.sopremios.com", "Um dos melhores top sites do Brasil. A mais de 5 meses no ar e fazendo o maior sucesso.", "14", "2", "2004", "Webmaster", "1", "1", "10", "0");
