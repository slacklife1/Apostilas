<?

#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("config.php");
include("verifica.php");

include('parte_cima.php');
if($nivelbusca == 2){

$sql = mysql_query("SELECT * FROM sites ORDER BY id");


echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Lista de Sites Cadastrados</b></font><br>
<FONT FACE='$fonte'><FONT SIZE=-2>Clique sobre o nome do site para modificar algum dado.</font><BR><br>";

while($linha = mysql_fetch_array($sql)) {
$idsite = $linha["id"];
$nomesite = $linha["nomesite"];
$endsite = $linha["endsite"];
$descricao = $linha["descricao"];
$aprovado = $linha["aprovado"];

if($aprovado == 0){
$status = "<font color='#808000'><b>Aguardando aprova��o</b></font>";
}elseif($aprovado == 1){
$status = "<font color='#0000FF'><b>Aprovado</b></font>";
}elseif($aprovado == 2){
$status = "<font color='#FF0000'><b>Bloqueado</b></font>";
}

echo"<FONT FACE='$fonte'><FONT SIZE=-2>$idsite - <a href='modificarsite.php?id=$idsite'>$nomesite</a> - Status: $status<BR><BR></FONT></FONT>";}
echo"<br><FONT FACE='$fonte'><FONT SIZE=2><a href='javascript:history.go(-1)'>�� Voltar</a></font>";
 }
 else{
 echo"<br><FONT FACE='$fonte'><FONT SIZE=2><b><font color='#FF0000'>Voc� n�o tem permiss�o para acessar esta p�gina</font></b>";
 }
 mysql_close($conexao);
include('parte_baixo.php');
?>
