</TD>
</TR>

<TR>
<TD>
<!-- CW SCRIPTS - ATEN��O!!!!
N�O RETIRE O COPYRIGHT DA COMUNIDADE WEBMASTER
SUGEITO A PROCESSOS SE RETIRADA SEM AUTORIZA��O.
PARA RETIRAR � NECESS�RIO A COMPRA DA LICENSA
DE USO DO SISTEMA. ENVIE UM E-MAIL PARA:
WEBMASTER@COMUNIDADEWEBMASTER.COM PARA SABER MAIS.
-->

<br><br><CENTER><FONT FACE="Verdana"><FONT SIZE=-2>Copyright 2004 &copy; - Todos os direitos reservados<br>
Sistema desenvolvido por <a href="http://www.comunidadewebmaster.com" target="_blank">CWScript</a></FONT></FONT></CENTER>
</TD>
</TR>
</TABLE></CENTER>

</BODY>
</HTML>
