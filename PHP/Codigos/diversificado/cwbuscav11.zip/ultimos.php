<?
#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include('config.php');
include('parte_cima.php');
echo"<font face='$fonte' size='-1'><b>�ltimos $quantidade sites cadastrados";
if($aprovar==1){
echo" e aprovados</b>";
}
echo"
:</b><BR><br>";

$sql = mysql_query("SELECT * FROM sites WHERE aprovado='1' ORDER BY id DESC");

$lpp = $quantidade; // Especifique quantos resultados voc� quer por p�gina
$total = mysql_num_rows($sql); // Esta fun��o ir� retornar o total de linhas na tabela
$paginas = ceil($total / $lpp); // Retorna o total de p�ginas
if(!isset($pagina)) { $pagina = 0; } // Especifica uma valor para variavel pagina caso a mesma n�o esteja setada
$inicio = $pagina * $lpp; // Retorna qual ser� a primeira linha a ser mostrada no MySQL
$sql = mysql_query("SELECT * FROM sites  WHERE aprovado='1' ORDER BY id DESC LIMIT $inicio, $lpp"); // Executa a query no MySQL com o limite de linhas.

while($linha = mysql_fetch_array($sql)) {

$id = $linha["id"];
$nomesite = $linha["nomesite"];
$endsite = $linha["endsite"];
$descricao = $linha["descricao"];
$diacad = $linha["diacad"];
$mescad = $linha["mescad"];
$anocad = $linha["anocad"];
$votos = $linha["votos"];
$notas = $linha["notas"];
$categoria = $linha["categoria"];
$cliques = $linha["cliques"];

if($notas >= 1 or $votos >= 1){
$mediat = ($notas/$votos);

$tamanho = strlen($mediat);
$quantidade = "5";
if($tamanho <= $quantidade)
{$media = substr_replace($mediat, " ", $quantidade, $tamanho - $quantidade);}

}else{
$media = $notas;
}

echo "
<font face='$fonte' size='-2'><a href='click.php?acao=visitar&id=$id' target='_blank'><b>$nomesite</b></a>: $descricao<br>
<font color='#909090'>Categoria: <a href='categorias.php?vercat=$categoria'><font color='#909090'>$categoria</a> | Adicionado em: $diacad/$mescad/$anocad<BR>
Cliques: $cliques | M�dia de votos: $media |
<a href='votar.php?idsite=$id'><font color='#909090'>Votar neste Site</a><BR>";
if($nivelbusca == 2){
echo"<b><a href='modificarsite.php?id=$id'>Modificar</a> | <a href='deletarsite.php?acao=deletar&ida=$id'>Deletar</a></b><BR>";
}
echo"<BR></font></font></font>";
}
mysql_close($conexao);
include('parte_baixo.php');

?>
