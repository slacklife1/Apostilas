<?

#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

# INFORMA��ES DO SEU HOST
# Modifique conforme as informa��es de seu host

$dbhost="localhost";
$dbuser="comunida_comunid";
$dbpasswd="";
$dbname="cwbusca";

########################################
# INFORMA��ES DO SITE                  #
# Modifique conforme suas necessidades #
########################################

// Nome do site
$nomesiteb = "CW Busca";

// Endere�o do site
$endsite = "http://www.comunidadewebmaster.com";

// Nome do Webmaster
$webmaster = "Foxter";

// E-mail do Webmaster
$emailmaster = "webmaster@comunidadewebmaster.com";

// Fonte do site. Ex: Arial, Verdana, etc
$fonte = "Verdana";

// Quantidade de resultado por p�gina na busca
$resultadospg = "10";

// Quantidade de sites listados em: �ltimos Cadastros e Top visitas
$quantidade = "5";

// Voc� deseja aprovar os sites antes de eles serem adicionados aos resultados das buscas? Sim = 1 | 2 = N�o
$aprovar = "1";

// Vers�o deste sistema. N�O MODIFICAR.
$versao = "1.1";

#######################################
#    E-MAILS CADASTRO DE SITES        #
#######################################

// Voc� poder� utilizar as seguintes vari�veis em qualquer parte do e-mail.
// $buscauser => Nome do usu�rio
// $nomesite_ => Nome do site adicionado
// $endsite_ => Ender�o do site adicionado

// Aqui voc� coloca o t�tulo do e-mail que ser� enviado ao usu�rio sempre que ele adicionar um site.
$titulosite = "$nomesite_ - Cadastrado com sucesso";

// Aqui voc� coloca o e-mail que ser� enviado ao usu�rio que adicionou o site. Voc� pode utilizar:
$mailcadastrosite = "<font face=$fonte size=2><b>Ol� $buscauser,</b><br>voc� acaba de registrar o site <b>$nomesite_</b> no sistema de busca $nomesite. Obrigado pela prefer�ncia.";

#######################################
#    E-MAILS CADASTRO DE USU�RIOS     #
#######################################

// Voc� poder� utilizar as seguintes vari�veis em qualquer parte do e-mail.
// $nome_ => Nome do usu�rio que acabou de se registrar
// $login_ => Login do usu�rio
// $senha_ => Senha do usu�rio

// Aqui voc� coloca o t�tulo do e-mail que ser� enviado quando um usu�rio se cadastrar no site.
$titulousuario = "$nome_ - Cadastro no $nomesite";

$mailcadastrouser = "<b>Ol� $nome_,</b><br>voc� acaba de se registrar no $nomesite, e a partir de agora poder� cadastrar todos os seus sites utilizando somente o usu�rio <b>$login_</b> e a senha <b>$senha_</b>";


#######################################
#  N�O MODIFIQUE ESTAS LINHAS         #
#######################################
$conexao = @mysql_pconnect($dbhost, $dbuser, $dbpasswd) or die ("N�o foi poss�vel conectar-se ao servidor MySQL");
$db = @mysql_select_db($dbname) or die ("N�o foi poss�vel selecionar o banco de dados <b>$dbname</b>");

?>
