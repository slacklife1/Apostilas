<?

#######################################
# CW Scripts - CW Paquera             #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("config.php");
include("verifica.php");

$deletar1 = mysql_query("SELECT * FROM membros ORDER BY id LIMIT 1");

include('parte_cima.php');
echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Deletar Usu�rios</b><BR><BR>";

if($acao == deletar){

while($linha = mysql_fetch_array($deletar1)) {
$id = $linha["id"];
$loginu = $linha["login"];
$senha = $linha["senha"];

if($nivelbusca == 2){
$sql = "DELETE FROM membros WHERE id='$ida'";
$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a exclus�o dos dados.");
echo "
<FONT FACE='$fonte'><FONT SIZE=-2>
O usuario foi deletado com sucesso.
";
}
elseif($nivelbusca != 2){
echo"<FONT FACE='$fonte'><FONT SIZE=-2><font color=\"#FF0000\">Voc� n�o pode deletar este usu�rio.<BR></font>";
}
}
}

echo"<BR><br><FONT FACE='$fonte'><FONT SIZE=2><a href='javascript:history.go(-1)'>�� Voltar</a></font>";

mysql_close($conexao);
include('parte_baixo.php');

?>
