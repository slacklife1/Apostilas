<?

#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("config.php");
include("parte_cima.php");

if($acao == cadastrar){
####################
$sql = "SELECT * FROM membros where email='$email_' OR login='$login_'";
$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

if(mysql_num_rows($resultado)>0) {

while ($linha=mysql_fetch_array($resultado)) {
$email = $linha["email"];
$login = $linha["login"];
}
}

if($nome_ == "" || $email_ == "" || $login_ == "" || $senha_ == ""){
echo" <FONT FACE='$fonte'><FONT SIZE=-2>
<b><font color='#FF0000'>Erro:</font></b> Voc� n�o preencheu todos os campos necess�rios para o cadastro. Por favor, volte e corrija o erro.<br><br><a href='javascript:history.go(-1)'>�� Voltar</a>
";}elseif($email_ == $email OR $login_ == $login){
echo"<FONT FACE='$fonte'><FONT SIZE=-2>
<b><font color='#FF0000'>Erro:</font></b> Este email ou login j� est� sendo utilizado por outro membro. <br><br><a href='javascript:history.go(-1)'>�� Voltar</a></TD>
";
}elseif(!eregi("^[0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\\.[a-z]{2,3}$",$email_)){
echo "<FONT FACE='$fonte'><FONT SIZE=-2>
<b><font color='#FF0000'>Erro:</font></b> Digite corretamente o seu e-mail.<br><br><a href='javascript:history.go(-1)'>�� Voltar</a></TD>";
}else{
$nivel = 1;
$ativo = "0";
$sql = mysql_query("INSERT INTO membros (nome, email, login, senha, nivel, ativo) VALUES ('$nome_', '$email_', '$login_', '$senha_', '$nivel', '$ativo')") or print(mysql_error());


// ENVIA E-MAIL CONFIRMANDO CADASTRO

$assunto = "$titulousuario" ;
$email = "";
$header = "From: $nomesite\n";
$header .= "Content-Type: text/html; charset=us-ascii\n";
$header .= "<font face=$fonte size=2>$mailcadastrouser\n";

mail ("$email_", $assunto, $email, $header);

echo"

<FONT FACE='$fonte'><FONT SIZE=-2>
<b><font color='#FF0000'>Sucesso:</font></b> Seu cadastro foi efetuado com sucesso. <br>As informa��es cadastradas foram: <BR><br>
<b>Nome:</b> $nome_<br>
<b>E-mail:</b> $email_<br>
<b>Login:</b> $login_<br>
<b>Senha:</b> $senha_<br>
<BR>
<b><font color='#000080'>Realizar Login:</font></b><BR>
<form action=\"login.php\" method=\"post\">
Usu�rio:<BR> <input type='text' name='login' value='$login_' size='20'  style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><BR>
Senha:<BR> <input type='password' name='senha' value='$senha_' size='20' style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'>
<BR><input type='submit' name='logar' value='Logar' style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'>
";

}
}

####################


else{

echo"
<FONT FACE='$fonte'><FONT SIZE=-1><b>Cadastro de Usu�rio</b></font><br>
<FONT FACE='$fonte'><FONT SIZE=-2>
<form method='POST' action='cadastrouser.php?acao=cadastrar'>
Formul�rio de Cadastro no <b>$nomesiteb</b>, para adicionar sites em nosso sistema � necess�rio realizar esta busca.<br>
<font face='$fonte' size='-2'><b>Seu Nome:</b><br>
<input type='text' name='nome_' size='20'  style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>
<b>E-mail:</b><br>
<input type='text' name='email_' size='20' style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>

<b>Login:</b><br>
<input type='text' name='login_' size='20'  maxlength='7' style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>

<b>Senha:</b><br>
<input type='text' name='senha_' size='20'  maxlength='7' style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>

</font>
<input type='submit' value='Cadastrar' name='B1'><br>
( Todos os �tens s�o obrigat�rios. )
</form>
<br><a href='javascript:history.go(-1)'>�� Voltar</a>

";
}
mysql_close($conexao);
include("parte_baixo.php");
?>
