<?

#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("config.php");

$query = mysql_query("Select * From membros where login='".$_POST[login]."' and senha='".$_POST[senha]."' and ativo='0'");
$valida = mysql_fetch_array($query);

if($_POST[login] == '' || $_POST[senha] == ''){
include('parte_cima.php');
echo"
<FONT FACE='$fonte'><FONT SIZE=-2><b>Login Administrativo:</b><br>
<form action=\"login.php\" method=\"post\">
<table width=\"25%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
<tr><td><font face=\"verdana\" size='2'>Usu�rio:</font></td><td><input name=\"login\" type=\"text\"></td></tr>
<tr><td><font face=\"$fonte\" size='2'>Senha:</font></td><td><input name=\"senha\" type=\"password\"></td></tr>
<tr><td>&nbsp;</td><td><input name=\"logar\" type=\"submit\" value=\"Logar\"></td></tr>
</table>
<BR><FONT FACE='$fonte'><FONT SIZE=-2><b>Usu�rio Comum:</b> cwbusca<BR>
<b>Senha:</b> 123
<BR><BR>
<b>Usu�rio Administrador:</b> admin  <BR>
<b>Senha:</b> 123
</form>
</HTML>";
} elseif($_POST[login] == $valida["login"] && $_POST[senha] == $valida["senha"]){
setcookie("buscauser", $_POST[login]);
setcookie("buscapass", $_POST[senha]);
setcookie("nivelbusca", $valida["nivel"]);
header("Location: logado.php");
} elseif($_POST[login] != $valida["login"] || $_POST[senha] != $valida["senha"]){
include('parte_cima.php');
echo"<font face=\"$fonte\"size='2'><b><font color='#FF0000'>Usu�rio ou senha inv�lido.</font><br><BR><font face=\"$fonte\"size='-2'>� poss�vel que sua conta tenha sido bloqueada por algum administrador e por algum motivo. Tente novamente, se a senha e o usu�rio estiverem em corretos, entre em <a href='mailto:$emailmaster'>contato</a>.</b><br>
<BR><BR><a href='javascript:history.go(-1)'>�� Voltar</a></font>";
}
mysql_close($conexao);

include('parte_baixo.php');?>
