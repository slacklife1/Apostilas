
<?

#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("config.php");

include('parte_cima.php');
echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Site Aleat�rio</b></font><FONT SIZE=-2><br></font>";

// Faz um sorteio entre todos os sites cadastrados no sistema atrav�z o RAND()
$sites = mysql_query("SELECT * FROM sites WHERE id and aprovado='1' ORDER BY RAND() LIMIT 1");

while($linha = mysql_fetch_array($sites)) {
$id = $linha["id"];
$nomesite = $linha["nomesite"];
$endsite = $linha["endsite"];
$descricao = $linha["descricao"];
$diacad = $linha["diacad"];
$mescad = $linha["mescad"];
$anocad = $linha["anocad"];
$votos = $linha["votos"];
$notas = $linha["notas"];
$categoria = $linha["categoria"];
$cliques = $linha["cliques"];

if($notas >= 2 or $votos >= 2){
$mediat = ($notas/$votos);

$tamanho = strlen($mediat);
$quantidade = "4";
if($tamanho <= $quantidade)
{$media = substr_replace($mediat, " ", $quantidade, $tamanho - $quantidade);}

}else{
$media = $notas;
}

echo"<BR><FONT FACE='$fonte'><FONT SIZE=-2><a href='click.php?acao=visitar&id=$id' target='_blank'><b>$nomesite</b></a>: $descricao<br>
<font color='#909090'>Categoria: <a href='categorias.php?vercat=$categoria'><font color='#909090'>$categoria</a> | Adicionado em: $diacad/$mescad/$anocad<BR>
Cliques: $cliques | M�dia de votos: $media |
<a href='votar.php?idsite=$id'><font color='#909090'>Votar neste Site</a><BR></font></font></font>
";
if($nivelbusca == 2){
echo"<b><a href='modificarsite.php?id=$id'>Modificar</a> | <a href='deletarsite.php?acao=deletar&ida=$id'>Deletar</a></b><BR>";
}
}
echo"<FONT FACE='$fonte'><FONT SIZE=-2><br><a href='aleatorio.php'>Sortear Outro Site</a><br><br><a href='javascript:history.go(-1)'>�� Voltar</a></font>";
mysql_free_result($sites);
mysql_close($conexao);
include('parte_baixo.php');
?>
