<?
#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("config.php");
if($acao == visitar){

include("parte_cima.php");
$sql = mysql_query("Select * from sites WHERE id='$id'");
while($linha = mysql_fetch_array($sql)) {

$endsite = $linha["endsite"];
$nomesite = $linha["nomesite"];
$cliquesbd = $linha["cliques"];
}
// Verifica quantos cliques o site j� possui e soma mais 1
$cliquesatual = ($cliquesbd + "1");

// Atualiza no banco de dados...
$sql = "UPDATE sites SET cliques = '$cliquesatual' WHERE id='$id'";
$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a exclus�o dos dados.");

echo"<META HTTP-EQUIV=REFRESH CONTENT='4; URL=$endsite'>
<FONT FACE='$fonte'><FONT SIZE=-1><b>Visitar Site</b></font>
<FONT SIZE=-2><BR><BR>
Aguarde... Acessando site <b>$nomesite</b>.<BR><BR>
( <a href='$endsite'>Ou clique aqui para n�o esperar</a> )";

mysql_close($conexao);
include("parte_baixo.php");
}

?>
