<?

#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("config.php");
include("verifica.php");

// Verifica quantos sites est�o aguardando para serem aprovados.
{$query_Recordset = "SELECT COUNT(*) AS total FROM sites WHERE aprovado=0";
$Recordset = mysql_query($query_Recordset, $conexao) or die(mysql_error());
$row_Recordset = mysql_fetch_assoc($Recordset);
mysql_free_result($Recordset);
$totalaprovar = $row_Recordset['total'];
}

include('parte_cima.php');

if($acao == aprovar){
####################
if($nivelbusca == 2){

$sqla = "UPDATE sites SET aprovado ='1' WHERE id='$ida' ";
$resultado = mysql_query($sqla)
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

$sql = mysql_query("SELECT * FROM sites WHERE id='$ida' ORDER BY id");
while($linha = mysql_fetch_array($sql)) {
$idsite = $linha["id"];
$nomesite = $linha["nomesite"];
$endsite = $linha["endsite"];
$descricaosite = $linha["descricao"];
$diacad = $linha["diacad"];
$mescad = $linha["mescad"];
$anocad = $linha["anocad"];
$categoria = $linha["categoria"];

echo"

<FONT FACE='$fonte'><FONT SIZE=-2><FONT FACE='$fonte'><FONT SIZE=-1><b>Aprovar Sites para entrar no sistema</b></font></font><BR><BR>
<b><font color='#FF0000'>Sucesso:</font></b> O site a seguir foi aprovado e j� est� dispon�vel na busca: <BR><br>
<b>Nome do Site:</b> $nomesite<br>
<b>Endere�o do Site:</b> $endsite<br>
<b>Descri�ao do Site:</b> $descricaosite<br>
<b>Categoria:</b> $categoria
<BR>
<br><FONT FACE='$fonte'><FONT SIZE=2><a href='aprovarsites.php'>�� Voltar</a></font>
";

}
}

}else{
######################################
######################################
if($nivelbusca == 2 and $aprovar == 1){

$sql = mysql_query("SELECT * FROM sites WHERE aprovado=0 ORDER BY id");

echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Aprovar Sites para entrar no sistema</b><BR>Existem <b>$totalaprovar</b> sites para serem aprovados.</font><br><br>";

while($linha = mysql_fetch_array($sql)) {
$idsite = $linha["id"];
$nomesite = $linha["nomesite"];
$endsite = $linha["endsite"];
$descricaosite = $linha["descricao"];
$diacad = $linha["diacad"];
$mescad = $linha["mescad"];
$anocad = $linha["anocad"];
$categoria = $linha["categoria"];
$nomeuser = $linha["nomeuser"];

echo"<b><FONT FACE='$fonte'><FONT SIZE=-2>$idsite - <a href='$endsite' target=_blank>$nomesite</a></b><BR>
<b>Descri��o:</b> $descricaosite<BR>
<b>Cadastrado em:</b> $diacad/$mescad/$anocad - <b>Categoria:</b> $categoria<BR>
<b><a href='aprovarsites.php?acao=aprovar&ida=$idsite'><font color='#0000ff'>Aprovar site</a></font>| <a href='modificarsite.php?id=$idsite'><font color='#808000'>Editar Site</a></font></b>
<br><BR></FONT></FONT>";}
echo"<br><FONT FACE='$fonte'><FONT SIZE=2><a href='logado.php'>�� Voltar</a></font>";
 }
 else{
 echo"<br><FONT FACE='$fonte'><FONT SIZE=2><b><font color='#FF0000'>Voc� n�o tem permiss�o para acessar esta p�gina</font></b>";
 }
 }
mysql_close($conexao);
include('parte_baixo.php');
?>
