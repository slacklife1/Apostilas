<?
#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

$diacad = date("d");
$mescad = date("m");
$anocad = date("Y");

include('config.php');
include('parte_cima.php');

echo"<FONT FACE='$fonte'><FONT SIZE=-2><BR><b>Top Sites por cliques</b><BR><BR>";

$top = mysql_query("SELECT * FROM sites WHERE aprovado='1' ORDER BY cliques DESC");

$lpp = $quantidade; // Especifique quantos resultados voc� quer por p�gina
$total = mysql_num_rows($top); // Esta fun��o ir� retornar o total de linhas na tabela
$paginas = ceil($total / $lpp); // Retorna o total de p�ginas
if(!isset($pagina)) { $pagina = 0; } // Especifica uma valor para variavel pagina caso a mesma n�o esteja setada
$inicio = $pagina * $lpp; // Retorna qual ser� a primeira linha a ser mostrada no MySQL
$top2 = mysql_query("SELECT * FROM sites WHERE aprovado='1' ORDER BY cliques DESC LIMIT $inicio, $lpp"); // Executa a query no MySQL com o limite de linhas.

while($linha = mysql_fetch_array($top2)) {

$id = $linha["id"];
$nomesite_ = $linha["nomesite"];
$descricao_ = $linha["descricao"];
$categoria = $linha["categoria"];
$cliques = $linha["cliques"];
$votos = $linha["votos"];
$notas = $linha["notas"];

if($notas >= 1 or $votos >= 1){
$mediat = ($notas/$votos);

$tamanho = strlen($mediat);
$quantidade = "4";
if($tamanho <= $quantidade)
{$media = substr_replace($mediat, " ", $quantidade, $tamanho - $quantidade);}

}else{
$media = $notas;
}

echo "
<a href='click.php?acao=visitar&id=$id' target='_blank'><b>$nomesite_</b></a>: $descricao_<br>
<font color='#909090'>Categoria: <a href='categorias.php?vercat=$categoria'><font color='#909090'>$categoria</a> | Adicionado em: $diacad/$mescad/$anocad<BR>
Cliques: $cliques | M�dia de votos: $media |
<a href='votar.php?idsite=$id'><font color='#909090'>Votar neste Site</a><BR>";
if($nivelbusca == 2){
echo"<b><a href='modificarsite.php?id=$id'>Modificar</a> | <a href='deletarsite.php?acao=deletar&ida=$id'>Deletar</a></b><BR>";
}
echo"<BR></font></font></font>";
}
mysql_close($conexao);
include('parte_baixo.php');

?>
