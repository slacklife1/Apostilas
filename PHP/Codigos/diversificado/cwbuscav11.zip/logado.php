<?
#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################


if($acao == sair){
        setcookie("buscapass");
        setcookie("buscauser");
        setcookie("nivelbusca");

header("Location: login.php");
}
include("verifica.php");
include("config.php");

{$query_Recordset = "SELECT COUNT(*) AS total FROM sites WHERE nomeuser='$buscauser'";
$Recordset = mysql_query($query_Recordset, $conexao) or die(mysql_error());
$row_Recordset = mysql_fetch_assoc($Recordset);
mysql_free_result($Recordset);
$totalsitesuser = $row_Recordset['total'];
}

{$query_Recordset = "SELECT COUNT(*) AS total FROM sites";
$Recordset = mysql_query($query_Recordset, $conexao) or die(mysql_error());
$row_Recordset = mysql_fetch_assoc($Recordset);
mysql_free_result($Recordset);
$totalsites = $row_Recordset['total'];
}

{$query_Recordset = "SELECT COUNT(*) AS total FROM membros";
$Recordset = mysql_query($query_Recordset, $conexao) or die(mysql_error());
$row_Recordset = mysql_fetch_assoc($Recordset);
mysql_free_result($Recordset);
$totalmembros = $row_Recordset['total'];
}

include("parte_cima.php");


echo"<FONT FACE='$fonte'><FONT SIZE=2><b>Administra��o</b><br><br>
</FONT></FONT>
<FONT FACE='$fonte'><FONT SIZE=-2>
Ol� <b>$buscauser</b>, seja bem vindo a sua conta administrativa no <b>$nomesiteb</b>.
<br><br></FONT></FONT>";

$sql = "SELECT * FROM membros where login='$buscauser'";
$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

while ($linha=mysql_fetch_array($resultado)) {

$id = $linha["id"];
$nivel = $linha["nivel"];
$email = $linha["email"];
}


if($nivel == 1){

echo"
<FONT FACE='$fonte'><FONT SIZE=-2><b>Escolha o que deseja fazer:</b><br><br>
<FONT FACE='$fonte'><FONT SIZE=-2><a href='modificaruser.php?id=$id'>Modificar Seus Dados Cadastrados</a><br>
<FONT FACE='$fonte'><FONT SIZE=-2><a href='adicionarsite.php'>Adicionar um site ao sistema</a><br>
<FONT FACE='$fonte'><FONT SIZE=-2><a href='mailto:$emailmaster'>Entre em Contato com o administrador</a><br>
<br><FONT FACE='$fonte'><FONT SIZE=-2><b>Seus Sites</b><br>
Voc� possui <b>$totalsitesuser</b> sites cadastrados:<BR><BR>";

$sql = mysql_query("SELECT * FROM sites WHERE nomeuser='$buscauser' ORDER BY id");
while($linha = mysql_fetch_array($sql)) {

$ids = $linha["id"];
$nomesite = $linha["nomesite"];
$endsite = $linha["endsite"];
$descricao = $linha["descricao"];
$aprovado = $linha["aprovado"];

echo"<FONT FACE='$fonte'><FONT SIZE=-2><b>Site:</b> <a href='click.php?acao=visitar&id=$ids' target='_blank'>$nomesite</a>
<BR><b>Descri��o:</b> $descricao</font><BR><b>Status: </b>";
if($aprovado == 0){
echo"<font color='#DCB61D'>Aguardando aprova��o</font><BR><a href='modificarsite.php?id=$ids'>Editar site</a> - <a href='deletarsite.php?acao=deletar&ida=$ids'>Deletar Site</a> *</font><BR><hr width='250' size='1' align='left'>";
}elseif($aprovado == 1){
echo"<font color='#0000FF'>Aprovado</font><BR><a href='modificarsite.php?id=$ids'>Editar site</a> - <a href='deletarsite.php?acao=deletar&ida=$ids'>Deletar Site</a> *</font><BR><hr width='250' size='1' align='left'>";
}elseif($aprovado == 2){
echo"<font color='#FF0000'>Bloqueado</font><BR><a href='modificarsite.php?id=$ids'>Editar site</a> - <a href='deletarsite.php?acao=deletar&ida=$ids'>Deletar Site</a> *</font><BR><hr width='250' size='1' align='left'>";
}
}
 echo"<u>( * Uma vez deletado n�o tem como recuperar o site )</u><BR>
<BR><BR>
<FONT FACE='$fonte'><FONT SIZE=-2><a href='logado.php?acao=sair'>Logout</a>
</FONT></FONT>
";
}

elseif($nivel == 2){
echo"
<FONT FACE='$fonte'><FONT SIZE=-2>
<b>Membros</b><BR>
<FONT FACE='$fonte'><FONT SIZE=-2><a href='modificaruser.php?id=$id'>Modificar Seus Dados Cadastrados</a><br>
<FONT FACE='$fonte'><FONT SIZE=-2><a href='listamembros.php'>Modificar outros Membros</a><br>
<BR>
<b>Sites</b><BR>
<FONT FACE='$fonte'><FONT SIZE=-2><a href='adicionarsite.php'>Adicionar um site ao sistema</a><br>
<FONT FACE='$fonte'><FONT SIZE=-2><a href='listasites.php'>Modificar algum site cadastrado no sistema</a><br>
<FONT FACE='$fonte'><FONT SIZE=-2><a href='deletarsite.php?acao=deletarlista'>Lista para deletar sites</a><br>
<BR>
<b>Busca</b><BR>
<FONT FACE='$fonte'><FONT SIZE=-2><a href='adicionarcategoria.php'>Adicionar/Deletar Categoria</a><br>";
if($aprovar == 1){
echo"<FONT FACE='$fonte'><FONT SIZE=-2><a href='aprovarsites.php'>Aprovar Sites para entrar ao sistema</a><br>";
}
echo"<br><FONT FACE='$fonte'><FONT SIZE=-2><b>Seus Sites</b><br>
Voc� possui <b>$totalsitesuser</b> sites cadastrados:<BR><BR>";
$sql = mysql_query("SELECT * FROM sites WHERE nomeuser='$buscauser' ORDER BY id");
while($linha = mysql_fetch_array($sql)) {

$ids = $linha["id"];
$nomesite = $linha["nomesite"];
$endsite = $linha["endsite"];
$descricao = $linha["descricao"];
$aprovado = $linha["aprovado"];

echo"<FONT FACE='$fonte'><FONT SIZE=-2><b>Site:</b> <a href='click.php?acao=visitar&id=$ids' target='_blank'>$nomesite</a>
<BR><b>Descri��o:</b> $descricao</font><BR><b>Status: </b>";
if($aprovado == 0){
echo"<font color='#808000'>Aguardando aprova��o</font><BR><a href='modificarsite.php?id=$ids'>Editar site</a> - <a href='deletarsite.php?acao=deletar&ida=$ids'>Deletar Site</a> *</font><BR><hr width='250' size='1' align='left'>";
}elseif($aprovado == 1){
echo"<font color='#0000FF'>Aprovado</font><BR><a href='modificarsite.php?id=$ids'>Editar site</a> - <a href='deletarsite.php?acao=deletar&ida=$ids'>Deletar Site</a> *</font><BR><hr width='250' size='1' align='left'>";
}elseif($aprovado == 2){
echo"<font color='#FF0000'>Bloqueado</font><BR><a href='modificarsite.php?id=$ids'>Editar site</a> - <a href='deletarsite.php?acao=deletar&ida=$ids'>Deletar Site</a> *</font><BR><hr width='250' size='1' align='left'>";
}
}
echo"<u>( * Uma vez deletado n�o tem como recuperar o site )</u><BR>
<BR><BR>

<b>Estat�sticas:</b><BR>
O site <b>$nomesiteb</b> possui <b>$totalmembros</b> membros cadastrados, que adicionaram juntos <b>$totalsites</b> sites ao sistema.
<br>Voc� est� utilizando a vers�o <b>$versao</b> do CW Busca. A mais recente lan�ada � a vers�o <img src=\"http://www.comunidadewebmaster.com/cwscripts/novabusca.gif\" border=\"0\">. <BR><a href='http://www.comunidadewebmaster.com' target='comunidade'>Clique aqui para baixar a vers�o mais recente.</a><BR></FONT></FONT>

<BR><FONT FACE='$fonte'><FONT SIZE=-2><a href='logado.php?acao=sair'>Logout</a>";
}
mysql_close($conexao);
include("parte_baixo.php");
?>
