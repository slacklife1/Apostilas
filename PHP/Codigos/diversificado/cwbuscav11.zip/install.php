<?
#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

// Antes de executar este arquivo modifique as informa��es em config.php
include "parte_cima.php";
include "config.php";

if($acao == "instalar3"){
echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Instala��o Autom�tica - Parte 3 de 3</b></font></font><BR><BR>
<FONT FACE='$fonte'><FONT SIZE=-3>Parab�ns!!! Voc� acaba de instalar o CW Busca.<BR><BR>
<b>� extremamente recomend�vel que voc� delete de seu servidor este arquivo (install.php).</b><BR><BR>
<a href='index.php'>Acessar Sistema -></a>";

}else{

if($acao == "instalar2"){
echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Instala��o Autom�tica - Parte 3 de 3</b></font><BR><BR>";

$query4=("INSERT INTO sites VALUES('1', 'cwbusca', 'Comunidade Webmaster', 'http://www.comunidadewebmaster.com', 'Um site completo voltado exclusivamente para os webmasters do Brasil.', '14', '2', '2004', 'Webmaster', '1', '1', '10', '0'),('2', 'cwbusca', 'S� Pr�mios', 'http://www.sopremios.com', 'Um dos melhores top sites do Brasil. A mais de 5 meses no ar e fazendo o maior sucesso.', '14', '2', '2004', 'Webmaster', '1', '1', '10', '0');");
$query5=("INSERT INTO membros VALUES('1', 'Fernando', 'webmaster@comunidadewebmaster.com', 'cwbusca', '123', '1', '0');");
$query6=("INSERT INTO membros VALUES('2', 'Fernando', 'webmaster@comunidadewebmaster.com', 'admin', '123', '2', '0');");
$query7=("INSERT INTO categorias VALUES('1', 'Cultura'), ('2', 'Esportes'), ('3', 'Games'), ('4', 'Hackers'), ('5', 'Humor'), ('6', 'Inform�tica'), ('7', 'Internet'), ('8', 'Mista'), ('9', 'M�sica'), ('10', 'Pessoal'), ('11', 'Portais'), ('12', 'Servi�os'), ('13', 'Webmaster');");


$adicionar = mysql_query($query4);
$adicionar2 = mysql_query($query5);
$adicionar3 = mysql_query($query6);
$adicionar4 = mysql_query($query7);

if($adicionar){
echo "<FONT FACE='$fonte'><FONT SIZE=-1>Dados de <b>sites</b> adicionados com sucesso.</font><br>";
} else {
echo "<FONT FACE='$fonte'><FONT SIZE=-1><font color=\"#FF0000\">Erro ao adicionar um site ao sistema. Tente novamente ou instale manualmente utilizando o arquivo cwbusca.sql.</font></font><BR><br>";
}

if($adicionar2){
echo"<FONT FACE='$fonte'><FONT SIZE=-1>Dados de <b>usu�rio comum</b> adicionado com sucesso</font><br>";
} else {
echo "<FONT FACE='$fonte'><FONT SIZE=-1><font color=\"#FF0000\">Erro ao adicionar usu�rio comum. Tente novamente ou instale manualmente utilizando o arquivo cwbusca.sql.</font></font><BR><br>";
}

if($adicionar3){
echo"<FONT FACE='$fonte'><FONT SIZE=-1>Dados de <b>usu�rio administratador</b> adicionado com sucesso</font><br>";
} else {
echo "<FONT FACE='$fonte'><FONT SIZE=-1><font color=\"#FF0000\">Erro ao adicionar administrador comum. Tente novamente ou instale manualmente utilizando o arquivo cwbusca.sql.</font></font><BR><br>";
}

if($adicionar4){
echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Categorias</b> adicionadas com sucesso.</font><br>";
} else {
echo "<FONT FACE='$fonte'><FONT SIZE=-1><font color=\"#FF0000\">Erro ao adicionar as categorias. Tente novamente ou instale manualmente utilizando o arquivo cwbusca.sql.</font></font><BR><br>";
}

echo"<BR> <FONT FACE='$fonte'><FONT SIZE=-1><a href='install.php?acao=instalar3'>Terminar -></a></font>";

}else{

if($acao == "instalar"){
echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Instala��o Autom�tica - Parte 2 de 3</b></font><BR><BR>";

$query = "CREATE TABLE `categorias` (
  `id` int(5) unsigned NOT NULL auto_increment,
  `categoria` varchar(255) default NULL,
  PRIMARY KEY (`id`));";

$query2 = "CREATE TABLE `membros` (
  `id` int(5) unsigned NOT NULL auto_increment,
  `nome` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `login` varchar(255) default NULL,
  `senha` varchar(255) default NULL,
  `nivel` int(5) unsigned default '1',
  `ativo` int(5) unsigned default '1',
  PRIMARY KEY (`id`));";

$query3= "CREATE TABLE `sites` (
  `id` int(5) unsigned NOT NULL auto_increment,
  `nomeuser` varchar(255) default NULL,
  `nomesite` varchar(255) default NULL,
  `endsite` varchar(255) default NULL,
  `descricao` varchar(255) default NULL,
  `diacad` int(2) default NULL,
  `mescad` int(2) default NULL,
  `anocad` int(4) default NULL,
  `categoria` varchar(255) default NULL,
  `aprovado` int(5) default '0',
  `votos` int(5) default '0',
  `notas` int(5) default '0',
  `cliques` int(10) default '0',
  PRIMARY KEY (`id`));";

$resultado = mysql_query($query);
$resultado2 = mysql_query($query2);
$resultado3 = mysql_query($query3);

if($resultado){
echo "<FONT FACE='$fonte'><FONT SIZE=-1>Tabela das <b>categorias</b> foi criada com sucesso</font><br>";
} else {
echo "<FONT FACE='$fonte'><FONT SIZE=-1><font color=\"#FF0000\">Erro ao criar a tabela <b>categorias</b>. Tente novamente ou instale manualmente utilizando o arquivo cwbusca.sql.</font></font><BR><br>";
}

if($resultado2){
echo"<FONT FACE='$fonte'><FONT SIZE=-1>Tabela das <b>membros</b> foi criada com sucesso</font><br>";
} else {
echo "<FONT FACE='$fonte'><FONT SIZE=-1><font color=\"#FF0000\">Erro ao criar a tabela <b>membros</b>. Tente novamente ou instale manualmente utilizando o arquivo cwbusca.sql.</font></font><BR><br>";
}

if($resultado3){
echo"<FONT FACE='$fonte'><FONT SIZE=-1>Tabela das <b>sites</b> foi criada com sucesso</font><br>";
} else {
echo "<FONT FACE='$fonte'><FONT SIZE=-1><font color=\"#FF0000\">Erro ao criar a tabela <b>sites</b>. Tente novamente ou instale manualmente utilizando o arquivo cwbusca.sql.</font></font><BR><br>";
}

echo"<BR> <FONT FACE='$fonte'><FONT SIZE=-1><a href='install.php?acao=instalar2'>Avan�ar -></a></font>";

}else{
echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Instala��o Autom�tica - Parte 1 de 3</b></font><BR><BR>
<FONT FACE='$fonte'><FONT SIZE=-2>Obrigado por escolher o <b>CW Busca</b>. <BR>Siga todas as instru��es e fa�a bom proveito do sistema.<BR><BR>
     <ul type=\"circle\">
   <li>Crie um banco de dados em seu servidor com um usu�rio.<BR><BR>
  </li></ul>

<ul type=\"circle\">
   <li>Abra o arquivo config.php. Edite as informa��es de:<BR><BR>
   <b>$ dbhost</b>=\"localhost\";<BR>
   <b>$ dbuser</b>=\"cwbusca\";<BR>
   <b>$ dbpasswd</b>=\"\";<BR>
   <b>$ dbname</b>=\"cwbusca\";<BR> <BR>
   Para as informa��es de seu host. Lembrando: <b>$ dbuser</b> � o usu�rio do banco de dados, <b>$ dbpasswd</b> � a senha do banco de dados e <b>$ dbname</b> � o nome do banco de dados.
<BR>Inicialmente, basta voc� realizar estas mudan�as e salvar.
   </li>
</ul>

<ul type=\"circle\">
   <li>Pronto... Agora voc� pode prosseguir a instala��o.<BR><BR>
  </li></ul>
  
  <a href='install.php?acao=instalar'>Avan�ar -></a>
  ";
}
}
}
mysql_close($conexao);
include "parte_baixo.php";
?>

