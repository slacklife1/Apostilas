<?
#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("config.php");
include("parte_cima.php");

if($acao == votar){
####################
$sql2 = mysql_query("Select * from sites WHERE id='$id'");
while($linha = mysql_fetch_array($sql2)) {

$votos = $linha["votos"];
$notas = $linha["notas"];

// Verifica quantos votos o site possui e soma mais um
// Verifica tamb�m qual a nota total e soma mais a nota que acabou de ser dada ao site

$totalvotos = (1+$votos);
$totalnotas = ($notas+$nota);

$atualizar = "UPDATE sites SET votos ='$totalvotos', notas ='$totalnotas' WHERE id='$id'";
$resultado = mysql_query($atualizar)
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

echo"
<FONT FACE='$fonte'><FONT SIZE=-2>
<b><font color='#FF0000'>Sucesso:</font></b> Sua nota foi computada. <BR><br>
<b>Sua Nota:</b> $nota<br>
<br><a href='javascript:history.go(-1)'>�� Voltar</a>
";

}
}

####################


else{

$votar = mysql_query("SELECT * FROM sites WHERE id='$idsite'") or print (mysql_error());
while($linha = mysql_fetch_array($votar)){

$id = $linha["id"];
$nomesite = $linha["nomesite"];
$endsite = $linha["endsite"];

echo"
<FONT FACE='$fonte'><FONT SIZE=-1><b>Votar no Site</b></font><br>
<FONT FACE='$fonte'><FONT SIZE=-2>
<form method='POST' action='votar.php?acao=votar&id=$idsite'>
Aqui voc� pode dar uma nota para o site <b><a href='$endsite'>$nomesite</a></b>. Selecione sua nota:<br>
<select size='1' name='nota'>
   <option value='10'>10</option>
   <option value='9'>9</option>
   <option value='8'>8</option>
   <option value='7'>7</option>
   <option value='6'>6</option>
   <option value='5'>5</option>
   <option value='4'>4</option>
   <option value='3'>3</option>
</select>
</font>
<input type='submit' value='Votar' name='B1'><br>
</form><FONT FACE='$fonte'><FONT SIZE=-2>
<br><a href='javascript:history.go(-1)'>�� Voltar</a>

";
}
}
mysql_close($conexao);
include("parte_baixo.php");
?>
