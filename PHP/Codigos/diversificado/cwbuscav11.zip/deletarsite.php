<?

#######################################
# CW Scripts - CW Paquera             #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("config.php");
include("verifica.php");

$deletar1 = mysql_query("SELECT * FROM sites ORDER BY id LIMIT 1");

include('parte_cima.php');
echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Deletar Sites</b><BR><BR>";

if($acao == deletar){

while($linha = mysql_fetch_array($deletar1)) {
$id = $linha["id"];
$nomeuser = $linha["nomeuser"];
$nomesite2 = $linha["nomesite"];
$endsite = $linha["endsite"];

if($nivelbusca == 2 or $buscauser == "$nomeuser"){
$sql = "DELETE FROM sites WHERE id='$ida'";
$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a exclus�o dos dados.");
echo "
<FONT FACE='$fonte'><FONT SIZE=-2>
O site <b>$nomesite2</b> foi deletado com sucesso.
";
}
elseif($nivelbusca != 2 or $buscauser != "$nomeuser"){
echo"<FONT FACE='$fonte'><FONT SIZE=-2><font color=\"#FF0000\">Voc� n�o pode deletar este site.<BR></font>";
}
}
}
if($acao == deletarlista){

$deletar2 = mysql_query("SELECT * FROM sites ORDER BY id");
if($nivelbusca == 2 or $buscauser == "$nomeuser"){
while($linha = mysql_fetch_array($deletar2)) {
$id = $linha["id"];
$nomeuser = $linha["nomeuser"];
$nomesite = $linha["nomesite"];
$endsite = $linha["endsite"];

echo"<FONT FACE='$fonte'><FONT SIZE=-2>$id - <a href='click.php?acao=visitar&id=$id' target='_blank'>$nomesite</a> - <a href='deletarsite.php?acao=deletar&ida=$id'><font color='#FF0000'>Deletar site</font></a><BR></font>";
}
}
elseif($nivelbusca != 2 or $buscauser != "$nomeuser"){
echo"Voc� n�o tem acesso a esta p�gina.";
}
}

echo"<BR><br><FONT FACE='$fonte'><FONT SIZE=2><a href='javascript:history.go(-1)'>�� Voltar</a></font>";

mysql_close($conexao);
include('parte_baixo.php');

?>
