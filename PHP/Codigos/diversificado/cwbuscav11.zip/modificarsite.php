<?

#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("verifica.php");
include("config.php");

include('parte_cima.php');
echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Editar Site</b></font><br></font>";

if($acao == modificar){
if($nomesite_ == "" || $endsite_ == "" || $descricao_ == "" || $categoria_ == ""){
echo"
<FONT FACE='$fonte'><FONT SIZE=-2><font color='Red'><B>Erro:</B>
Voc&ecirc; n&atilde;o preencheu todos os campos necess&aacute;rios. Por favor, volte e corrija o erro.</FONT></FONT></font>";
}else{
$conexao = mysql_connect("$dbhost", "$dbuser", "$dbpasswd");
$db = mysql_select_db("$dbname");
$descricao2_ = eregi_replace("<","&lt;",$descricao_);
if($nivelbusca == 1){
$sql = "UPDATE sites SET nomesite ='$nomesite_', endsite ='$endsite_', descricao ='$descricao2_', categoria ='$categoria_' WHERE id='$id'";
}
if($nivelbusca==2){
$sql = "UPDATE sites SET nomesite ='$nomesite_', endsite ='$endsite_', descricao ='$descricao2_', categoria ='$categoria_', diacad ='$diacad_', mescad ='$mescad_', anocad ='$anocad_', votos ='$votos_', notas ='$notas_', cliques ='$cliques_', aprovado ='$aprovado_' WHERE id='$id'";
}
$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

$msg_mod_ok = "<b>Sucesso:</b> Os dados foram modificados com sucesso!<br>";
}
}

// Realiza busca no banco de dados segundo o id e retorna o sorteio cadastrado por essa id
// Formul�rio para modificar sorteios

$sql = mysql_query("Select * from sites WHERE id='$id'");
while($linha = mysql_fetch_array($sql)) {

$idsite = $linha["id"];
$nomeuser = $linha["nomeuser"];
$nomesite = $linha["nomesite"];
$endsite = $linha["endsite"];
$descricao = $linha["descricao"];
$diacad = $linha["diacad"];
$mescad = $linha["mescad"];
$anocad = $linha["anocad"];
$votos = $linha["votos"];
$notas = $linha["notas"];
$categoria = $linha["categoria"];
$cliques = $linha["cliques"];
$aprovado = $linha["aprovado"];

}
if($buscauser == $nomeuser OR $nivelbusca == 2){
echo"
<FONT FACE='$fonte'><FONT SIZE=-2>$msg_mod_ok
$msg_mod_mail_erro";
if($aprovado == 2 and $nivelbusca != 2){
echo"<BR><font color='#FF0000'><b>Este site se encontra bloqueado, por esse motivo n�o � permitido modificar as informa��es cadastradas</b></font><BR><BR>";
}elseif($aprovado !=2 or $nivelbusca == 2 or $buscauser == $nomeuser){
echo"
<form method='POST' action='modificarsite.php?acao=modificar&id=$id'>";
}
echo"
<font face='$fonte' size='-2'><b>Adicionado por *:</b><br>
<input type='text' name='nomeuser_' value='$nomeuser' size='20' readonly style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>
<b>Nome do Site *:</b><br>
<input type='text' name='nomesite_' value='$nomesite' size='20' style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>

<b>Endere�o do Site *:</b><br>
<input type='text' name='endsite_'  value='$endsite' size='20'  maxlength='7' style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>

<b>Descri��o *:</b><br>
<textarea wrap=on rows='3' name='descricao_' cols='20'  style='font-size: 11px; width: 180; font-family: $fonte; height: 70; border: 1px solid #C0C0C0'>$descricao</textarea>
<BR><b>Categoria *:</b> <input type='radio' name='categoria_' value='$categoria' checked> <b>$categoria</b> <- Atual<br>
";
$sql = mysql_query("SELECT * FROM categorias ORDER BY categoria");

while($linha = mysql_fetch_array($sql)) {
$id = $linha["id"];
$cat = $linha["categoria"];
echo"<input type='radio' name='categoria_' value='$cat'> $cat <br>
";
}

if($nivelbusca==2){
echo"<BR><BR><b><font face='$fonte' size='-1'>Administrador:</font></b><BR><BR>
<b>Cadastrado em:</b><BR>
<input type='text' name='diacad_'  value='$diacad' size='2'  maxlength='2' style='font-size: 11px; width: 20; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'> / <input type='text' name='diacad_'  value='$diacad' size='2'  maxlength='2' style='font-size: 11px; width: 20; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'> / <input type='text' name='anocad_'  value='$anocad' size='4'  maxlength='4' style='font-size: 11px; width: 40; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>

<b>Votos recebidos:</b><br>
<input type='text' name='votos_'  value='$votos' size='20'  maxlength='7' style='font-size: 11px; width: 40; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>

<b>Total de notas:</b><br>
<input type='text' name='notas_'  value='$notas' size='20'  maxlength='7' style='font-size: 11px; width: 40; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>

<b>Total de Visitas:</b><br>
<input type='text' name='cliques_'  value='$cliques' size='20'  maxlength='7' style='font-size: 11px; width: 40; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>

<b>Status:</b> ";
if($aprovado == 0){
echo"<font color='#808000'><b>Aguardando aprova��o</b></font> <- Atual<BR>";
}elseif($aprovado == 1){
echo"<font color='#0000FF'><b>Aprovado</b></font> <- Atual<BR>";
}elseif($aprovado == 2){
echo"<font color='#FF0000'><b>Bloqueado</b></font> <- Atual<BR>";
}
echo"
<select size='1' name='aprovado_'>
   <option value=0>Aguardando Aprova��o</option>
   <option value=1 selected>Aprovado</option>
   <option value=2>Bloquear Site</option>
</select>
";}

if($aprovado == 2 and $nivelbusca != 2){
echo"<BR><font color='#FF0000'><b>Este site se encontra bloqueado, por esse motivo n�o � permitido modificar as informa��es cadastradas</b></font><BR><BR>";
}elseif($aprovado !=2 or $nivelbusca == 2 or $buscauser == $nomeuser){
echo"
<br><BR>
<input type='submit' value='Modificar' name='B1'>";
if($nivelbusca == 2){
echo" - <b><a href='deletarsite.php?acao=deletar&ida=$idsite'>Deletar Site</a></b>
";

}
echo"
<br>
( * ) �tem Obrigat�rio.
</form>
";
}
echo"<br><FONT FACE='$fonte'><FONT SIZE=2><a href='javascript:history.go(-1)'>�� Voltar</a></font>";
}
elseif($nivelbusca != 2 or $buscauser != $nomeuser){
echo"<FONT FACE='$fonte'><FONT SIZE=-2><font color='#FF0000'><b><BR>Voc� n�o tem permiss�o para modificar este site</a><br></font></font></font><BR></b><FONT FACE='$fonte'><FONT SIZE=-2><a href='javascript:history.go(-1)'>�� Voltar</a></font>";
}


mysql_free_result($sql);
mysql_close($conexao);
include('parte_baixo.php');
?>
