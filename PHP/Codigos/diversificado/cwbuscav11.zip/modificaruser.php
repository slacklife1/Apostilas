<?

#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("verifica.php");
include("config.php");

include('parte_cima.php');
echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Editar Usu�rio</b></font><br></font>";

if($acao == modificar){

if(!eregi("^[0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\\.[a-z]{2,3}$",$email_)){
$msg_mod_mail_erro = "<FONT FACE='$fonte'><FONT SIZE=-2> <b><font color='#FF0000'>Erro:</font></b> Digite corretamente o seu e-mail.
";
}

  elseif($nome_ == "" || $email_ == "" || $login_ == "" || $senha_ == ""){

echo"
<FONT FACE='$fonte'><FONT SIZE=-2><font color='Red'><B>Erro:</B>
Voc&ecirc; n&atilde;o preencheu todos os campos necess&aacute;rios para
o modificar cadastro de sorteio. Por favor, volte e corrija o erro.</FONT></FONT></font>";
}else{
$conexao = mysql_connect("$dbhost", "$dbuser", "$dbpasswd");
$db = mysql_select_db("$dbname");
if($nivelbusca == 1){
$sql = "UPDATE membros SET nome ='$nome_', email ='$email_', login ='$login_', senha ='$senha_' WHERE id='$id'";
}
if($nivelbusca == 2){
$sql = "UPDATE membros SET nome ='$nome_', email ='$email_', login ='$login_', senha ='$senha_', ativo ='$ativo_', nivel ='$nivel_' WHERE id='$id'";}
$resultado = mysql_query($sql)
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

$msg_mod_ok = "<b>Sucesso:</b> Os dados foram modificados com sucesso!<br>";
}
}

// Realiza busca no banco de dados segundo o id e retorna o sorteio cadastrado por essa id
// Formul�rio para modificar sorteios

$sql = mysql_query("Select * from membros WHERE id='$id'");
while($linha = mysql_fetch_array($sql)) {

$nome = $linha["nome"];
$email = $linha["email"];
$login = $linha["login"];
$senha = $linha["senha"];
$ativo = $linha["ativo"];
$nivel = $linha["nivel"];

}
if($buscauser == $login OR $nivelbusca == 2){
echo"
<FONT FACE='$fonte'><FONT SIZE=-2>$msg_mod_ok
$msg_mod_mail_erro
<form method='POST' action='modificaruser.php?acao=modificar&id=$id'>
<font face='$fonte' size='-2'><b>Seu Nome *:</b><br>
<input type='text' name='nome_' value='$nome' size='20'  style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>
<b>E-mail *:</b><br>
<input type='text' name='email_' value='$email' size='20' style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>

<b>Login *:</b><br>
<input type='text' name='login_'  value='$login' readonly size='20'  maxlength='7' style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>

<b>Senha *:</b><br>
<input type='password' name='senha_'  value='$senha' size='20'  maxlength='7' style='font-size: 11px; width: 120; font-family: $fonte; height: 19; border: 1px solid #C0C0C0'><br>
";

if($nivelbusca==2){
echo"<BR><BR><b><font face='$fonte' size='-1'>Administrador:</font></b><BR><BR><b>N�vel:</b> <b>";

if($nivel == 1){
echo"Usu�rio Normal";}
elseif($nivel == 2){
echo"Administrador";}

echo"</b> <- Atual<br>
<select size='1' name='nivel_'>
   <option value='1'>Usu�rio Normal</option>
   <option value='2'>Administrador</option>
</select>  <Br>
<BR>
<b>Ativo:</b> <b>";
if($ativo == 0){
echo"Sim";
}else{
echo"<font color=\"#FF0000\">N�o</font>";
}
echo"</b> <- Atual<br>
<select size='1' name='ativo_'>
   <option value='0'>Sim</option>
   <option value='1'>N�o</option>
</select> <BR>
";}

echo"
<br>
<input type='submit' value='Modificar' name='B1'>";
if($nivelbusca == 2){
echo" - <b><a href='deletaruser.php?acao=deletar&ida=$id'>Deletar Usu�rio</a></b>
";
}


echo"
<br>
( * ) �tem Obrigat�rio.
</form>

";
echo"<br><FONT FACE='$fonte'><FONT SIZE=2><a href='javascript:history.go(-1)'>�� Voltar</a></font>";
}else{
echo"<FONT FACE='$fonte'><FONT SIZE=-2><font color='#FF0000'><b><BR>Voc� n�o tem permiss�o para modificar este usu�rio</a>";
}
mysql_free_result($sql);
mysql_close($conexao);
include('parte_baixo.php');
?>
