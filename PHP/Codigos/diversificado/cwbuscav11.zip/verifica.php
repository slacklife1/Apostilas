<?

#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

// Sistema para verificar se o usu�rio j� est� logado ou n�o
if(!$HTTP_COOKIE_VARS["buscauser"] && !$HTTP_COOKIE_VARS["buscapass"]&& !$HTTP_COOKIE_VARS["nivelbusca"]){
header("Location: login.php");
}
?>
