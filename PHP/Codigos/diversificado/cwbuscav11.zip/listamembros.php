<?

#######################################
# CW Scripts - CW Busca               #
# Autor: Fernando Paes                #
# http://www.comunidadewebmaster.com  #
#######################################

include("config.php");
include("verifica.php");

include('parte_cima.php');
if($nivelbusca == 2){

$sql = mysql_query("SELECT * FROM membros ORDER BY id");

echo"<FONT FACE='$fonte'><FONT SIZE=-1><b>Lista de Membros Cadastrados</b></font><br><br>";

while($linha = mysql_fetch_array($sql)) {
$iduser = $linha["id"];
$loginuser = $linha["login"];
$ativouser = $linha["ativo"];
$emailuser = $linha["email"];

echo"<FONT FACE='$fonte'><FONT SIZE=-2>$iduser - <a href='modificaruser.php?id=$iduser'>$loginuser</a> - Ativo:";
if($ativouser == "1"){
echo "<font color='#FF0000'><b> N�o</b></font>";
}
elseif($ativouser == "0"){
echo "<font color='#0000ff'><b> Sim</b></font>";
}
echo" - <a href='mailto:$emailuser'>$emailuser</a>
<br><BR></FONT></FONT>";}
echo"<br><FONT FACE='$fonte'><FONT SIZE=2><a href='javascript:history.go(-1)'>�� Voltar</a></font>";
 }
 else{
 echo"<br><FONT FACE='$fonte'><FONT SIZE=2><b><font color='#FF0000'>Voc� n�o tem permiss�o para acessar esta p�gina</font></b>";
 }
 mysql_close($conexao);
include('parte_baixo.php');
?>
