<? include('config.php');?>

<HTML>
<HEAD>
   <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
   <META NAME="Author" CONTENT="f">
   <META NAME="GENERATOR" CONTENT="Mozilla/4.03 [pt] (WinNT; I) [Netscape]">
   <TITLE>CWScripts - <? echo"$nomesiteb";?></TITLE>
</HEAD>
<BODY TEXT="#000000" BGCOLOR="#FFFFFF" LINK="#000000" VLINK="#000000" ALINK="#000000">

<CENTER><TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 COLS=1 WIDTH="600" >
<TR>
<TD VALIGN=BOTTOM HEIGHT="140" BACKGROUND="logo.gif">
<BR>
<form method='POST' action='buscar.php?acao=buscar'>
<CENTER><TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 COLS=1 WIDTH="25%"  VALIGN=BOTTOM >
<TR>
<TD VALIGN=BOTTOM><input type="text" name="palavra"  style='font-size: 11px; width: 80; font-family: $fonte; height: 19; border: 1px solid #000000'><input type="submit" value="Ir" style='font-size: 11px; width: 20; font-family: $fonte; height: 19; border: 1px solid #000000'></TD>
</form></TR>
</TABLE></CENTER>
 <BR>
<CENTER></CENTER>
</TD>
</TR>

<TR>
<TD HEIGHT="22" BACKGROUND="cwmenu.gif">
<CENTER><!-- --></CENTER>

<DIV ALIGN=right><TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 COLS=1 WIDTH="67%" >
<TR>
<TD><FONT FACE="Verdana"><FONT SIZE=-2><b><a href="index.php">Principal</a> | <a href="cadastrouser.php">Cadastrar</a> | <a href="aleatorio.php">Aleat�rio</a> | <a href="ultimos.php">&Uacute;ltimos</a>
| <a href="top.php">Top+</a> | <a href="logado.php">Administrar</a> | <a href="leiame.txt" target="_blank">Leia</a></b></FONT></FONT></TD>
</TR>
</TABLE></DIV>

<CENTER><!-- --></CENTER>
</TD>
</TR>

<TR>
<TD>
<BR>

