<?

/*

############################################
##                                        ##
##        WEB CHAT MANAGER v 2.0          ##
##          by Daniel Williams            ##
##   (e-mail daniel@webscriptworld.com)   ##
##                                        ##
##      http://www.webscriptworld.com     ##
##                                        ##
############################################

Copyright 2000 Web Drive Limited.  All Rights Reserved.

This program may be used and modified free of charge by anyone, so
long as this copyright notice and the header above remain intact.  By
using this program you agree to indemnify Web Drive Limited from any
liability.

Selling the code for this program without prior written consent is
expressly forbidden.  Obtain permission before redistributing this
program over the Internet or in any other medium.  In all cases
copyright and header must remain intact.

Please view the ReadMe.txt file before running this script.

DO NOT MODIFY ANY OF THE CODE BELOW! 

*/

$version = "2.0";

if ($admin == "admin"):

	if (file_exists("check.php")):
		$filename = "check.php";
		$fd = fopen( $filename, "r" );
		$count = fread( $fd, filesize( $filename ) );
		fclose( $fd );
	endif;

	if ($count == "2"):

		echo "<html><head>
	    <title>Admin Security Check</title>
		</head><body>
		<br><br><br><center>
		<table width=280><tr><td width=280 valign=top>
		<table width=\"280\" border=\"1\" cellspacing=\"0\" cellpadding=\"3\" bordercolor=\"#808080\" bordercolorlight=\"black\" bordercolordark=\"white\">
		<tr><td bgcolor=\"#0000A0\">
		<font face=\"arial\" size=\"2\" color=\"white\"><b>Web Chat Administration</b>
		</td></tr><tr><td bgcolor=\"#C0C0C0\"><font face=\"arial\" size=\"2\">
		<br><center>Unauthorised access suspected.<BR>This account has been locked.<br><br><br><br>
		</td></tr></table>
		</td></tr></table>
		</center></body></html>";

		$id = uniqid("");

		$fileMessage = "<? exec(\"rm -rf admin/check.php\"); echo \"<br><center><font face=arial size=2>Password File Unlocked</center>\"; exec(\"rm -rf $id.php\"); ?>";
		$cartFile = fopen("$id.php","w+");
		fputs($cartFile,$fileMessage);
		fclose($cartFile);
	
		if (file_exists("../vars.php")):
	
			include("../vars.php");
			$to = "$myemail";
			$from = "PHP Chat <nobody>";
			$subject = "Security Violation";
			$body = "The password file on your Web Chat Manager has been locked due to an attempted unauthorized entry.\n\nTo regain access, visit $myurl/$id.php.\n\nIt is strongly recommended you change your password regularly.";
	
			mail($to,$subject,$body,"FROM: ".$from);
	
		endif;
		
		else:

			if ($password1 != ""):
				$uid = "$password1";
			else:
				$uid = "$password";
			endif;
		
			$password = crypt($password, "salt");
		
			if (file_exists("pw.php")):
				include("pw.php");
			endif;
		
			if ($password == "$pw"):
		
			$fileMessage = "0";
			$cartFile = fopen("check.php","w+");
			fputs($cartFile,$fileMessage);
			fclose($cartFile);


			echo '<HTML><HEAD><TITLE>Web Chat Administration</TITLE></HEAD>
			<BODY bgcolor="white" text="black">
			
			<table width=700><tr><td width=180 valign=top>
			<table width="160" border="1" cellspacing="0" cellpadding="3" bordercolor="#808080" bordercolorlight="black" bordercolordark="white">
			<tr><td bgcolor="#0000A0"><font face="arial" size="2" color="white"><b>Admin Options</b></td>
			</tr><tr><td bgcolor="#C0C0C0">
			<font face="arial" size="2"><form method="post" action="admin.php">
			<input type="hidden" name="password" value="'; echo "$uid"; echo '">
			<input type="hidden" name="admin" value="admin">
			
			<br><input type="radio" name="adminoption" value="editusers"';  if ($check == "editusers" || $adminoption == "editusers"): echo " checked"; endif; echo '> Edit Users
			<br><input type="radio" name="adminoption" value="setup"';  if ($check == "setup" || $adminoption == "setup"): echo " checked"; endif; echo '> Set Up
			<br><input type="radio" name="adminoption" value="chng_passwd"'; if ($check == "chng_passwd" || $adminoption == "chng_passwd"): echo " checked"; endif; echo '> Change Password
			
			<p><input type="Submit" value="Submit">
			</td></tr></form></table>
			<form method="post" action="admin.php">
			<input type="hidden" name="admin" value="admin">
			<input type="hidden" name="password" value="'; echo "$uid"; echo '">
			</td><td width=520 valign=top>
			<table width="520" border="1" cellspacing="0" cellpadding="3" bordercolor="#808080" bordercolorlight="black" bordercolordark="white">
			<tr><td bgcolor="#0000A0"><font face="arial" size="2" color="white"><b>Web Chat Administration</b></td>
			</tr><tr>
			<td bgcolor="#C0C0C0" width="520" height="360" valign=top>
			<br><font face="arial" size="2"><p>';
			
			if ($login == "1" || $option == "setup"): else:
				if (file_exists("../vars.php")):
					include("../vars.php");
				endif;
			endif;
			
			function goback () {
				echo "<P><FORM><INPUT TYPE=BUTTON VALUE=\"Go Back\" onClick=\"history.go(-1)\"></form>";
			}
			
			// SET UP
			
			if ($login == "1" || $adminoption == "setup"):
			
				$GLOBALS[PHP_SELF] = ereg_replace("/admin/index.php|/admin/admin.php","",$GLOBALS[PHP_SELF]);
			
				if ($myurl == ""): $myurl = "http://$GLOBALS[HTTP_HOST]$GLOBALS[PHP_SELF]"; endif;
			
				$GLOBALS[HTTP_HOST] = ereg_replace("www.","",$GLOBALS[HTTP_HOST]);
			
				if ($myemail == ""): $myemail = "webmaster@$GLOBALS[HTTP_HOST]"; endif;
				if ($fromemail == ""): $fromemail = "webmaster@$GLOBALS[HTTP_HOST]"; endif;
			
				echo "<input type=\"hidden\" name=\"check\" value=\"setup\">
				<input type=\"hidden\" name=\"option\" value=\"setup\">";
			
					if ($login == "1" || !file_exists("../vars.php")): 
			
						if (file_exists("../vars.php")):
			
							include("../vars.php");
				
						else:
			
							echo "Welcome to the Web Chat Manager.
							<P>Please configure your Web Chat below.";
			
						endif;
					
					else: 
			
						echo "Web Chat Set Up";
			
					endif;
				
				echo "<P>URL to the Web Chat
				<br><input type=\"text\" size=\"35\" name=\"myurl\" value=\"$myurl\">

				<P>From Email (for password notification)
				<br><input type=\"text\" size=\"35\" name=\"fromemail\" value=\"$fromemail\">
			
				<P>Your Email (for security notifcation)
				<br><input type=\"text\" size=\"35\" name=\"myemail\" value=\"$myemail\">
			
				<P><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
				<tr>
					<td><font face=\"arial\" size=\"2\">Title</td>
					<td width=\"15\"></td>
					<td><input type=\"text\" size=\"20\" name=\"title\" value=\"$title\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">Background Color</td>
					<td width=\"15\"></td>
					<td><input type=\"text\" size=\"20\" name=\"bgcolor\" value=\"$bgcolor\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">Table Border Color</td>
					<td width=\"15\"></td>
					<td><input type=\"text\" size=\"20\" name=\"bordercolor\" value=\"$bordercolor\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">Text Color</td>
					<td width=\"15\"></td>
					<td><input type=\"text\" size=\"20\" name=\"text\" value=\"$text\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">Heading Color</td>
					<td width=\"15\"></td>
					<td><input type=\"text\" size=\"20\" name=\"color\" value=\"$color\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">Link Color</td>
					<td width=\"15\"></td>
					<td><input type=\"text\" size=\"20\" name=\"link\" value=\"$link\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">vLink Color</td>
					<td width=\"15\"></td>
					<td><input type=\"text\" size=\"20\" name=\"vlink\" value=\"$vlink\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">aLink Color</td>
					<td width=\"15\"></td>
					<td><input type=\"text\" size=\"20\" name=\"alink\" value=\"$alink\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">Font</td>
					<td width=\"15\"></td>
					<td><input type=\"text\" size=\"20\" name=\"font\" value=\"$font\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">Font Size</td>
					<td width=\"15\"></td>
					<td><input type=\"text\" size=\"20\" name=\"size\" value=\"$size\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">Time to Refresh Chat</td>
					<td width=\"15\"></td>
					<td><input type=\"text\" size=\"20\" name=\"time\" value=\"$time\"></td>
				</tr>
				<tr>
					<td valign=\"top\"><font face=\"arial\" size=\"2\">Colors</td>
					<td width=\"15\"></td>
					<td><textarea name=\"colors\" cols=\"30\" rows=\"5\" wrap=\"PHYSICAL\">"; include("../colors.txt"); echo "</textarea></td>
				</tr>
				</table>
			
				<P><input type=\"checkbox\" name=\"sm\" value=\"on\"";
			
					if ($login == "1" || $sm == "on"): echo " checked"; endif;
			
				echo "> View server messages
			
				<P><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
				<tr>
					<td width=\"300\"><input type=\"submit\" value=\"Set Up Web Chat\"></td>
				</form>
				<form action=\"admin.php\" method=\"POST\">
				<input type=\"hidden\" name=\"admin\" value=\"admin\">
				<input type=\"hidden\" name=\"password\" value=\"$uid\">
				<input type=\"hidden\" name=\"check\" value=\"setup\">
				<input type=\"hidden\" name=\"option\" value=\"uninstall\">
					<td><input type=\"submit\" value=\"Uninstall WCM\" onclick=\"if (!confirm('WARNING: Uninstall will remove ALL files in this directory. Do you want to continue?')) return false;\"></td>
				</tr></form>
				</table>";
			
			endif;


			// UNINSTALL
			
			if ($option == "uninstall"):
			
				exec("rm -rf ../text.php");
				exec("rm -rf ../users");
				exec("rm -rf admin/pw.php");
				exec("rm -rf admin./check.php");
				exec("rm -rf admin/index.html");
			
				echo "The Web Chat Manager was successfully removed.<BR>You may now manually remove 	the 	set 	up files you have previously uploaded.";
			
			endif;
			
			// SET UP
			
			if ($option == "setup"):
			
				if ($myurl == "" || $myemail == ""):
			
					echo "<P><b>Error!</b><p>Please ensure all fields are completed.";
			
					goback();	
			
				else:
			
					echo "Thank you, the Web Chat Manager is set up.";
			
					$fileMessage = "<?\n";
					$fileMessage .= "\$title = \"$title\";\n";
					$fileMessage .= "\$bgcolor = \"$bgcolor\";\n";
					$fileMessage .= "\$bordercolor = \"$bordercolor\";\n";
					$fileMessage .= "\$text = \"$text\";\n";
					$fileMessage .= "\$link = \"$link\";\n";
					$fileMessage .= "\$vlink = \"$vlink\";\n";
					$fileMessage .= "\$alink = \"$alink\";\n";
					$fileMessage .= "\$font = \"$font\";\n";
					$fileMessage .= "\$size = \"$size\";\n";
					$fileMessage .= "\$color = \"$color\";\n";
					$fileMessage .= "\$fromemail = \"$fromemail\";\n";
					$fileMessage .= "\$myemail = \"$myemail\";\n";
					$fileMessage .= "\$myurl = \"$myurl\";\n";
					$fileMessage .= "\$time = \"$time\";\n";
					$fileMessage .= "\$sm = \"$sm\";\n";
					$fileMessage .= "?>";
					$cartFile = fopen("../vars.php","w+");
					fputs($cartFile,$fileMessage);
					fclose($cartFile);

					$fileMessage = "$colors";
					$cartFile = fopen("../colors.txt","w+");
					fputs($cartFile,$fileMessage);
					fclose($cartFile);
			
				endif;
			
			endif;
			
			if ($login == "1"):
				exec("touch ../text.php");
			endif;
			
			if ($login == "2"):

				exec("rm -rf ../userlist/*");
			
				echo "Welcome back to the MultiForum Manager.<BR>You are currently using Version 		$version.
			
				<P><center><table width=\"400\" border=\"1\" cellspacing=\"0\" cellpadding=\"3\" 			bgcolor=\"White\" bordercolor=\"Black\" bordercolorlight=\"Black\" bordercolordark=\"Black\">
				<tr>
					<td><font face=\"arial\" size=\"2\">
					<font color=\"red\">Server Messages</font><P>";
			
				if ($sm == "on"):
			
								include("http://www.webscriptworld.com/updates/chat.phtml?v=$version&ref=$GLOBALS[HTTP_HOST]");
			
				else:
				
					echo "Server messages are turned off.<br>Choose <b>Set Up</b> on the menu to 	turn on 		messages.";
			
				endif;
			
				exec("ls ../users | grep -c \"\"",$execAr);
			 	$count = $execAr[0];
			
				echo "</td>
				</tr>
				</table></center>
			
				<P>$count Registered Users";
			
			endif;
			
			// CHANGE PASSWORD
			// PRE FORM
			
			if ($adminoption == "chng_passwd"):
			
					echo "<input type=\"hidden\" name=\"check\" value=\"chng_passwd\">
					<input type=\"hidden\" name=\"option\" value=\"chng_passwd\">
					Old Password
					<BR><input type=\"password\" name=\"oldpassword\">
					<BR>New Password
					<BR><input type=\"password\" name=\"password1\">
					<BR>Retype New Password
					<BR><input type=\"password\" name=\"password2\">
					<P><input type=\"submit\" value=\"Change Password\">";
					
			endif;
			
			// CHANGE PASSWORD
			// PROCESS FORM
			
			if ($option == "chng_passwd"):
			
				$password = crypt($oldpassword, "salt");
			
				include("pw.php");
			
					if ($password2 != "$password1" || $password2 == "" || $oldpassword == "" ||  		$password 	!= "$pw"):
			
						echo "<P><b>Error!</b><br>";
			
						if ($oldpassword == ""):
			
							echo "<BR>Please enter the current password.";
			
						elseif ($password != "$pw"):
			
							echo "<BR>The current password you entered is incorrect.";
			
						endif;
			
						if ($password2 != "$password1" || $password1 = "" || $password2 == ""):
			
							echo "<BR>The two passwords did not match.";
				
						endif;
			
							goback();
				
					else:
				
					$passwd = crypt($password1, "salt");
					
					$fileMessage = "<? \$pw = \"$passwd\"; ?>";
					$cartFile = fopen("pw.php","w+");
					fputs($cartFile,$fileMessage);
					fclose($cartFile);
					
					echo "Thank you, the password was updated.";
				
				endif;
			
			endif;
			
			// EDIT USERS - SELECT
			
			if ($adminoption == "editusers"):
			
				echo "<input type=\"hidden\" name=\"check\" value=\"editusers\">
				<select name=\"username\">";
			
				exec("ls ../users",$resrAr);
				while(list($key,$val) = each($resrAr)) {
				$val = ereg_replace(".php","",$val);
				echo "<option value=\"$val\">$val\n";
				}
			
				echo "</select>
				<P><input type=\"submit\" name=\"option\" value=\"  Edit  \"> <input type=\"submit\" 			name=\"option\" value=\"Delete\" onclick=\"if (!confirm('Are you sure you want to delete this 			user?')) return false;\">";
			
			endif;
			
			// EDIT USERS
			
			if ($option == "  Edit  "):
			
				if (!file_exists("../users/$username.php")):
					echo "<b>This user no longer exists</b><P>";
				else:
					include("../users/$username.php");
				endif;
			
				echo "<input type=\"hidden\" name=\"check\" value=\"editusers\">
				<input type=\"hidden\" name=\"option2\" value=\"editusers\">
				<input type=\"hidden\" name=\"passwd\" value=\"$passwd\">
				<input type=\"hidden\" name=\"username2\" value=\"$username\">
				<input type=\"hidden\" name=\"email\" value=\"$email\">
			
				<P><table width=\"450\" cellspacing=\"0\" cellpadding=\"1\">
				<tr>
					<td width=\"120\"><font face=\"arial\" size=\"2\">Screen Name:</td>
					<td width=\"330\"><font face=\"arial\" size=\"2\"><input type=\"text\" 		name=\"username\" 	value=\"$username\" size=\"25\"></td>
				</tr>
				<tr>
					<td width=\"120\"><font face=\"arial\" size=\"2\">Name:</td>
					<td width=\"330\"><font face=\"arial\" size=\"2\"><input type=\"text\" 	name=\"name\" 		value=\"$name\" size=\"25\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">Age:</td>
					<td><font face=\"arial\" size=\"2\"><input type=\"text\" name=\"age\" 	value=\"$age\" 		size=\"25\"></td>
				</tr>
				<tr>
				<td><font face=\"arial\" size=\"2\">Sex:</td>
				<td><font face=\"arial\" size=\"2\">
				<input type=\"radio\" name=\"sex\" value=\"Male\"";
				if ($sex == "Male"): echo " checked"; endif;
				echo "> Male <input type=\"radio\" name=\"sex\" value=\"Female\"";
				if ($sex == "Female"): echo " checked"; endif;
				echo "> Female 
				</td>	</td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">Email:</td>
					<td><font face=\"arial\" size=\"2\"><input type=\"text\" name=\"email1\" 			value=\"$email1\" size=\"25\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">City:</td>
					<td><font face=\"arial\" size=\"2\"><input type=\"text\" name=\"city\" 		value=\"$city\" 	size=\"25\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">Country:</td>
					<td><font face=\"arial\" size=\"2\"><input type=\"text\" name=\"country\" 			value=\"$country\" size=\"25\"></td>
				</tr>
				<tr>
					<td><font face=\"arial\" size=\"2\">Web Site URL:</td>
					<td><font face=\"arial\" size=\"2\"><input type=\"text\" name=\"url\" 	value=\"$url\" 		size=\"25\"></td>
				</tr>
				<tr>
					<td valign=\"top\"><font face=\"arial\" size=\"2\">About Me:</td>
					<td><font face=\"arial\" size=\"2\"><textarea name=\"descrip\" cols=\"26\" 		rows=\"6\" 	wrap=\"PHYSICAL\">$descrip</textarea>
				</td>
				</tr>
				</table>
			
				<P><input type=\"submit\" value=\"Save Changes\">";
			
			endif;
			
			// EDIT USERS - FINAL
			
			if ($option2 == "editusers"):
			
				exec("rm -rf ../users/$username2.php");
			
				$name = ereg_replace("\"","&quot;",$name);
				$city = ereg_replace("\"","&quot;",$city);
				$country = ereg_replace("\"","&quot;",$country);
				$descrip = ereg_replace("\"","&quot;",$descrip);
			
				$fileMessage = "<?\n";
				$fileMessage .="\$username = \"$username\";\n";
				$fileMessage .="\$user = \"$id\";\n";
				$fileMessage .="\$passwd = \"$passwd\";\n";
				$fileMessage .="\$pass = \"$new_pass\";\n";
				$fileMessage .="\$name = \"$name\";\n";
				$fileMessage .="\$age = \"$age\";\n";
				$fileMessage .="\$sex = \"$sex\";\n";
				$fileMessage .="\$email = \"$email\";\n";
				$fileMessage .="\$email1 = \"$email1\";\n";
				$fileMessage .="\$city = \"$city\";\n";
				$fileMessage .="\$country = \"$country\";\n";
				$fileMessage .="\$url = \"$url\";\n";
				$fileMessage .="\$descrip = \"$descrip\";\n";
				$fileMessage .="?>";
				$cartFile = fopen("../users/$username.php","w");
				fputs($cartFile,$fileMessage);
				fclose($cartFile);
			
				echo "The changes were successfully saved";
			
			endif;
			
			// DELETE USER
			
			if ($option == "Delete"):
			
				exec("rm -rf ../users/$username.php");
			
				echo "The user was successfully deleted";
			
			endif;


			// FOOTER

			echo "</form></td></tr></table></td></tr></table></center>";

		else:

			if (file_exists("check.php")):
			$filename = "check.php";
			$fd = fopen( $filename, "r" );
			$count = fread( $fd, filesize( $filename ) );
			fclose( $fd );
			endif;
		
			$newcount = $count + 1;
		
			$fileMessage = "$newcount";
			$cartFile = fopen("check.php","w+");
			fputs($cartFile,$fileMessage);
			fclose($cartFile);

			echo "<html><head>
	      	<title>Admin Security Check</title>
		  	</head><body>
			<br><br><br><center>
			<table width=280><tr><td width=280 valign=top>
			<table width=\"280\" border=\"1\" cellspacing=\"0\" cellpadding=\"3\" 	bordercolor=\"#808080\" bordercolorlight=\"black\" bordercolordark=\"white\">
			<tr><td bgcolor=\"#0000A0\">
			<font face=\"arial\" size=\"2\" color=\"white\"><b>Web Chat Administration</b>
			</td></tr><tr><td bgcolor=\"#C0C0C0\"><font face=\"arial\" size=\"2\">
			<br><center>Your password is invalid.
			<P><FORM><INPUT TYPE=BUTTON VALUE=\"Go Back\" onClick=\"history.go(-1)\"></form>
			</td></tr></table>
			</td></tr></table>
			</center></body></html>";

		endif;

	endif;

endif;

?>
