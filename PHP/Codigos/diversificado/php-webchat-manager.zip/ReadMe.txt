		############################################
		##                                        ##
		##          PHP WEB CHAT v 2.0            ##
		##          by Daniel Williams            ##
		##                                        ##
		##      http://www.webscriptworld.com     ##
		##                                        ##
		############################################
					
Copyright 2000 Web Drive Limited. All Rights Reserved.

This program may be used and modified free of charge by anyone, so long as this
copyright notice and the header above remain intact.  By using this program you agree
to indemnify Web Drive Limited from any liability.

Selling the code for this program without prior written consent is expressly forbidden.
Obtain permission before redistributing this program over the Internet or in any other
medium.  In all cases copyright and header must remain intact.

Send support requests, bug reports, suggestions and feedback to daniel@webdrive.co.nz

########################################################################################

ABOUT THE PHP WEB CHAT MANAGER

The PHP Web Chat Manager allows you to manage a web-based chat system from a centralized
administration system.

The notes below describe the features of the PHP Web Chat Manager, as well as support notes.
Please read the following notes before setting up your PHP Web Chat Manager.

QUICK FEATURES

* Web-based real-time chat system
* Users register to participate
* User profiles
* Manage registered users
* Web-based interface
* Fully customisable layout

Descriptions below...

########################################################################################

ABOUT SECURITY

Security Features:

* Max 3 Login attempts allowed. Upon 3 incorrect attempts the Password file is locked
  and an email message sent to the administrator informing of the breach.

########################################################################################

SETTING UP THE PHP WEB CHAT MANAGER FOR ADVANCED USERS

1. Create a directory called "chat" or something similar
2. Inside this directory create two directories, "admin", "users" and "userlist"
3. Upload INDEX.php and ADMIN.php to the "admin" directory
4. Upload the remaining files into the "chat" directory
5. Chmod "colors.txt", "vars.php" "text.php" "admin", "users" and "userlist" to 707
6. Access the admin from "yourdomain.com/chat/admin/index.php"
7. Set up the Web Chat from your web-based admin

########################################################################################

SETTING UP THE PHP WEB CHAT MANAGER FOR BEGINNERS

First you need to create a directory where you will store the Web Chat Manager.
"chat" is a good name to use.

Inside this directory create three new directories called "admin", "users" and "userlist".

Upload these files to the "admin" directory you just created
- index.php
- admin.php

Upload the remaining files to the "chat" directory.

Now change the permissions (chmod) of the directories "admin", "users", "userlist" and the 
files "color.txt", "vars.php" and "text.php" to 707. You can do this in most FTP clients 
by selecting the directory and choosing the option "Change File Attributes."

Now via the Web go to the "yourdomain.com/chat/admin/index.php" directory you just 
created. You will be prompted to enter a password. You can choose anything you like, 
but ensure you remember the password as you'll need to enter it every time you access 
the Web Chat Manager.

Note: For added security it is a good idea to change the name of the index.php file 
to something else. This will make it even harder for hackers and crackers to find your
login page. A blank html file is created by the script to remove the directory listing
of the admin directory in the browser.

You can change the password at any time by selecting "Change Password" on the menu.

Once you have logged in for the first time you'll need to enter some information about 
your site.

The first is the URL of your Web Chat. This field should already be filled in.

The second is your email address. This is the address that security messages will be 
sent if there is any suspected breaches of security, i.e., when an unauthorized person 
is trying to access your Web Chat Manager and is locked out.

The following fields are where you can customise the look of the Web Chat. You can also 
make changes to the "header.php" and "footer.php" files to customise the look of
your system. 

Note: Unless you know what you're doing do not change any of the code inside the <? ?>
tags in these files or the script will generate errors.

Next you can enter different colors your users can use for typing their text. The script
comes with some pre-defined colors already. Make sure to keep the same format as is 
already displayed.

Lastly is the option to view server messages. This will show a box with messages from 
our server to inform you of news and updates to the script. We'll also let you know about
support, bugs and future scripts.

You can change any of this information at any time by selecting "Set Up" from the menu.

########################################################################################

USING THE PHP WEB CHAT MANAGER

Now that you've gone through the initial set up process you'll be ready to start using the 
Web Chat Manager.

###########################################
* Editing Users *
###########################################

Here you can edit and delete users. Select "Edit Users" from the menu. You can then 
select the user by their registered username name and edit and delete their details.

###########################################
* Registering *
###########################################

Users must register to use the chat. Upon entering the front page the user can follow 
the link to the registration page. They must enter a username and a valid email address.
Their password will be sent to their email address.

They can also add additional details about themselves for others to view in their profile.
Users can edit any of their details at any time.

###########################################
* Retrieving a Password *
###########################################

If a user loses their password they can simply enter their username on the front page 
and a new password will be sent to their email address.

###########################################
* Logging in and Out *
###########################################

When a user logs in a message notifying other users of their arrival will be posted. The 
same applies for users leaving the chat.

###########################################
* Chat Refresh Rate *
###########################################

The default setting is 8 seconds, but you can change this if you wish in the Set Up 
section of the admin system.

###########################################
* Support *
###########################################

This script is provided "as is". If you need help with this script please post a message on the Support Forum at http://www.webscriptworld.com

########################################################################################

Copyright 2000 Web Drive Limited
