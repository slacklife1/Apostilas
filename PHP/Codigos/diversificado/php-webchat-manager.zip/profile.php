<?

if (file_exists("vars.php")):
	include("vars.php");
endif;	

?>

<html>
<head>
	<title><? echo "$title"; ?></title>
</head>	

<?
echo "<body bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">";
echo "<font face=\"$font\" size=\"$size\">";
?>	

<?
if (file_exists("users/$username.php")):
	include("users/$username.php");
endif;
?>

<center>
<P><table width="450" border="1" cellspacing="0" cellpadding="5" bordercolor="<? echo "$bordercolor"; ?>" bordercolorlight="<? echo "$bordercolor"; ?>" bordercolordark="<? echo "$bordercolor"; ?>">
<tr>
	<td width="120"><? echo "<font face=\"$font\" size=\"$size\" color=\"$color\">"; ?>Screen Name:</td>
	<td width="330"><? echo "<font face=\"$font\" size=\"$size\">"; ?><? echo "$username"; ?>&nbsp;</td>
</tr>
<tr>
	<td width="120"><? echo "<font face=\"$font\" size=\"$size\" color=\"$color\">"; ?>Name:</td>
	<td width="330"><? echo "<font face=\"$font\" size=\"$size\">"; ?><? echo "$name"; ?>&nbsp;</td>
</tr>
<tr>
	<td><? echo "<font face=\"$font\" size=\"$size\" color=\"$color\">"; ?>Age:</td>
	<td><? echo "<font face=\"$font\" size=\"$size\">"; ?><? echo "$age"; ?>&nbsp;</td>
</tr>
<tr>
	<td><? echo "<font face=\"$font\" size=\"$size\" color=\"$color\">"; ?>Sex:</td>
	<td><? echo "<font face=\"$font\" size=\"$size\">"; ?><? echo "$sex"; ?>&nbsp;
</td>
</tr>
<tr>
	<td><? echo "<font face=\"$font\" size=\"$size\" color=\"$color\">"; ?>Email:</td>
	<td><? echo "<font face=\"$font\" size=\"$size\">"; ?><a href="mailto:<? echo "$email1"; ?>"><? echo "$email1"; ?></a>&nbsp;</td>
</tr>
<tr>
	<td><? echo "<font face=\"$font\" size=\"$size\" color=\"$color\">"; ?>City:</td>
	<td><? echo "<font face=\"$font\" size=\"$size\">"; ?><? echo "$city"; ?>&nbsp;</td>
</tr>
<tr>
	<td><? echo "<font face=\"$font\" size=\"$size\" color=\"$color\">"; ?>Country:</td>
	<td><? echo "<font face=\"$font\" size=\"$size\">"; ?><? echo "$country"; ?>&nbsp;</td>
</tr>
<tr>
	<td><? echo "<font face=\"$font\" size=\"$size\" color=\"$color\">"; ?>Web Site URL:</td>
	<td><? echo "<font face=\"$font\" size=\"$size\">"; ?><? echo "<a href=\"$url\" target=\"new\">$url</a>"; ?>&nbsp;</td>
</tr>
<tr>
	<td valign="top"><? echo "<font face=\"$font\" size=\"$size\" color=\"$color\">"; ?>About Me:</td>
	<td><? echo "<font face=\"$font\" size=\"$size\">"; ?><? echo "$descrip"; ?>&nbsp;
</td>
</tr>
</table>
</center>

</body>
</html>