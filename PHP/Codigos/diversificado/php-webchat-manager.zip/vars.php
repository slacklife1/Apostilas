<?
$title = "PHP Chat";
$bgcolor = "#F8F8F8";
$bordercolor = "#A8ACA8";
$text = "black";
$link = "black";
$vlink = "black";
$alink = "black";
$font = "verdana";
$size = "1";
$color = "black";
$myemail = "";
$myurl = "";
$time = "8";
$sm = "";
?>