<?

if (file_exists("vars.php")):
	include("vars.php");
endif;	

?>

<HTML>
<HEAD>
	<meta http-equiv="refresh" content="10; url=users.php">
	<TITLE><? echo "$title"; ?></TITLE>
	
<style TYPE="text/css">
<!--
A:link {text-decoration: none; color:$link; }
A:visited {text-decoration: none; color:$link; }
A:hover {text-decoration: none; color:$link; }
A:active {text-decoration: none; color:$link; }
-->
</style>		
	
</HEAD>

<?
echo "<body bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">";
echo "<font face=\"$font\" size=\"$size\">

<table bgcolor=\"$bgcolor\" border=\"1\" cellspacing=\"0\" cellpadding=\"2\" bordercolor=\"$bordercolor\" bordercolorlight=\"$bordercolor\" bordercolordark=\"$bordercolor\">
<tr>
	<td>
<font face=\"$font\" size=\"$size\" color=\"$color\"><b>Users in Chat</b>
	</td>
</tr>";

exec("find userlist/ -amin 1 -o -amin 0",$retAr);
$numusers = sizeof($retAr);
for ($i=0;$i<$numusers;$i++)

	if ($retAr[$i] != ""): echo "<tr><td><font face=\"$font\" size=\"$size\">".ereg_replace("userlist/","",$retAr[$i])."</td></tr>"; endif;

?>

</table>


</BODY>
</HTML>