<HTML>
<HEAD>
	<TITLE><? echo "$title"; ?></TITLE>
</HEAD>

<br>
<center>


<?
echo "
<body bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">
<font face=\"$font\" size=\"$size\">

<table border=\"1\" width=\"400\" cellspacing=\"0\" cellpadding=\"10\" bordercolor=\"$bordercolor\" bordercolorlight=\"$bordercolor\" bordercolordark=\"$bordercolor\">
<tr>
	<td height=\"300\" valign=\"top\">
	<font face=\"$font\" size=\"$size\">";
?>
