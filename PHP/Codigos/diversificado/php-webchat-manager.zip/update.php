<?

if (file_exists("vars.php")):
	include("vars.php");
endif;	

if (file_exists("header.php")):
	include("header.php");
endif;	

?>

<?

if ($option == "update" || $option == "delete"):

		if (file_exists("users/$username.php")):
		
			include("users/$username.php");
		
			if ($c == "n"):
			else:
				$uid = crypt($password, "salt");
			endif;
	
			if ($uid == "$passwd"):
	
				if ($option == "update"):

					if ($username != "$username2" && file_exists("users/$username2.php")):
				
						echo "<font color=$color><B>Oops!</b></font>
						<P>That username is already taken.
						<BR>Please try again
						<P><FORM><INPUT TYPE=BUTTON VALUE=\"Go Back\" onClick=\"history.go(-1)\"></form>";
				
					else:
	
						$fileMessage = "<?\n";
						$fileMessage .="\$username = \"$username2\";\n";
					
						if ($new_pass == ""):
							$fileMessage .="\$passwd = \"$uid\";\n";
						else:
							$passwd = crypt($new_pass, "salt");
							$fileMessage .="\$passwd = \"$passwd\";\n";
						endif;

						$name2 = ereg_replace("\"","&quot;",$name2);
						$city2 = ereg_replace("\"","&quot;",$city2);
						$country2 = ereg_replace("\"","&quot;",$country2);
						$descrip2 = ereg_replace("\"","&quot;",$descrip2);
					
						$fileMessage .="\$name = \"$name2\";\n";
						$fileMessage .="\$age = \"$age2\";\n";
						$fileMessage .="\$sex = \"$sex2\";\n";
						$fileMessage .="\$email = \"$email2\";\n";
						$fileMessage .="\$email1 = \"$email12\";\n";
						$fileMessage .="\$city = \"$city2\";\n";
						$fileMessage .="\$country = \"$country2\";\n";
						$fileMessage .="\$url = \"$url2\";\n";
						$fileMessage .="\$descrip = \"$descrip2\";\n";
						$fileMessage .="?>";

						exec("rm -rf users/$username.php");

						$cartFile = fopen("users/$username2.php","w");
						fputs($cartFile,$fileMessage);
						fclose($cartFile);
								
						echo "<center><font color=\"$color\"><b>Success!.</b></font>
						<P>Thank you. Your profile has been updated.
					
						<P><form method=\"post\" action=\"login.php\">
						<input type=\"hidden\" name=\"option\" value=\"chat\">
						<input type=\"hidden\" name=\"username\" value=\"$username2\">
						<input type=\"hidden\" name=\"uid\" value=\"$passwd\">
						<input type=\"hidden\" name=\"c\" value=\"n\">
						<input type=\"submit\" value=\"Enter Chat\">
						</form></center>";

					endif;
					
				endif;
	
				if ($option == "delete"):	
	
					exec("rm -rf users/$username.php");
				
					echo "<center><font color=\"$color\"><b>Success!</b></font>
					<P>Thank you. This username has been removed from the system.";
					
				endif;
	
			else:
		
				echo "<font color=$color><B>Oops!</b></font>
				<P>Im sorry your password was incorrect. Please try again.";
		
			endif;	
	
		else:
		
			echo "<font color=$color><B>Oops!</b></font>
				
			<P>I'm sorry but it appears that your username is not in our database. 
			<p>Please <a href=\"index.php\">try again</a> or <a href=\"register.php\">register</a> a name.";
		
		endif;
				
	else:	
		
		echo "<font color=\"$color\"><b>Edit Option</b></font>
	
		<P><form method=\"post\" action=\"update.php\">
		<input type=\"hidden\" name=\"c\" value=\"n\">
		<input type=\"hidden\" name=\"uid\" value=\"$uid\">
		<input type=\"hidden\" name=\"username\" value=\"$username\">
		<input type=\"hidden\" name=\"email\" value=\"$email\">
		
		<input type=\"radio\" name=\"option\" value=\"update\" checked> Update Profile 
		<input type=\"radio\" name=\"option\" value=\"delete\"> Delete this username
		
		<P><font color=\"$color\"><b>Edit Profile</b></font>
		
		<P>To change your password enter a new one below:
		
		<P><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		<td width=\"120\"><font face=\"$font\" size=\"$size\">Username :</td>
		<td width=\"200\"><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"username2\" size=\"30\" maxlength=\"30\" value=\"$username\"></td>
		</tr>
		<tr>
		<td width=\"120\"><font face=\"$font\" size=\"$size\">Email :</td>
		<td width=\"200\"><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"email2\" size=\"30\" maxlength=\"30\" value=\"$email\"></td>
		</tr>
		<tr>
		<td width=\"120\"><font face=\"$font\" size=\"$size\">New Password :</td>
		<td width=\"200\"><font face=\"$font\" size=\"$size\"><input type=\"text\" 	name=\"new_pass\" size=\"30\" maxlength=\"30\"></td>
		</tr>
		</table>
		
		<P><font color=\"$color\"><b>Other details can be edited below.</b></font>
		
		<P><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		<td width=\"120\"><font face=\"$font\" size=\"$size\">Name :</td>
		<td width=\"200\"><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"name2\" size=\"30\" maxlength=\"30\" value=\"$name\"></td>
		</tr>
		<tr>
		<td><font face=\"$font\" size=\"$size\">Age:</td>
		<td><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"age2\" size=\"30\" maxlength=\"30\" value=\"$age\"></td>
		</tr>
		<tr>
		<td><font face=\"$font\" size=\"$size\">Sex:</td>
		<td><font face=\"$font\" size=\"$size\">
		<input type=\"radio\" name=\"sex2\" value=\"Male\"";
		if ($sex == "Male"): echo " checked"; endif;
		echo "> Male <input type=\"radio\" name=\"sex2\" value=\"Female\"";
		if ($sex == "Female"): echo " checked"; endif;
		echo "> Female 
		</td>
		</tr>
		<tr>
		<td><font face=\"$font\" size=\"$size\">Email:</td>
		<td><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"email12\" size=\"30\" maxlength=\"30\" value=\"$email1\"></td>
		</tr>
		<tr>
		<td><font face=\"$font\" size=\"$size\">City:</td>
		<td><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"city2\" size=\"30\" maxlength=\"30\" value=\"$city\"></td>
		</tr>
		<tr>
		<td><font face=\"$font\" size=\"$size\">Country:</td>
		<td><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"country2\" size=\"30\" maxlength=\"30\" value=\"$country\"></td>
		</tr>
		<tr>
		<td><font face=\"$font\" size=\"$size\">Web Site URL:</td>
		<td><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"url2\" size=\"30\" maxlength=\"50\" value=\"$url\"></td>
		</tr>
		<tr>
		<td valign=\"top\"><br><font face=\"$font\" size=\"$size\">About Yourself:</td>
		<td><font face=\"$font\" size=\"$size\">
		<textarea name=\"descrip2\" cols=\"26\" rows=\"6\" wrap=\"PHYSICAL\">$descrip</textarea>
		</td>
		</tr>
		<tr>
		<td colspan=\"2\">
		<br><center><input type=\"submit\" value=\"Save Changes\"> <input 	type=\"reset\"></center>
		</td></tr>
		</table>
	</form>";

endif;

?>

<? 

if (file_exists("footer.php")):
	include("footer.php");
endif;	

?>