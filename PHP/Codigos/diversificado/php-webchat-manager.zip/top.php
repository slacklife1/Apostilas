<?

if (file_exists("vars.php")):
	include("vars.php");
endif;	

?>

<HTML>
<HEAD>
	<TITLE><? echo "$title"; ?></TITLE>
	
<style TYPE="text/css">
<!--
A:link {text-decoration: none; color:$link; }
A:visited {text-decoration: none; color:$link; }
A:hover {text-decoration: none; color:$link; }
A:active {text-decoration: none; color:$link; }
-->
</style>		
	
</HEAD>

<?
echo "<body bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">";
echo "<font face=\"$font\" size=\"$size\">";

echo "<a href=\"main.php\" target=\"main\"><b>Reload Chat Window</b></a> | <a href=\"login.php?option=edit&username=$username&uid=$uid&c=n\" target=\"_top\"><b><b>Edit Profile</b></b></a> | <a href=\"login.php?option=logout&username=$username&uid=$uid&c=n\" target=\"_top\"><b><b>Log Out</b></b></a>";

?>

</BODY>
</HTML>