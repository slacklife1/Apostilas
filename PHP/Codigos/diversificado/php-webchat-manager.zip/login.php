<?

if (file_exists("vars.php")):
	include("vars.php");
endif;	


if (file_exists("users/$username.php")):

	include("users/$username.php");

	if ($option == "chat" || $option == "edit" || $option == "logout"):

		if ($c == "n"):
		else:
			$uid = crypt($password, "salt");
		endif;
	
		if ($uid == "$passwd"):

			// Edit Profile
	
			if ($option == "edit"):
	
				include("update.php");
		
			endif;
	
			// Chat
	
			if ($option == "chat"):
			
				if (!file_exists("text.php")):
					exec("touch text.php");
				endif;
		
				$date = date("h:ia d M");
			
				$filename = "text.php";
				$fileAr= file($filename);
				exec("cat /dev/null > $filename");
				$fd = fopen( $filename, "a+" );
				$filemessage = "<font color=$color><B><a 	href=\"javascript:launcher('profile.php?username=$username');\">$username</a> entered at 	$date</b></font><br><hr size=1  	noshade>\n";
				fputs($fd,$filemessage);
				
				$numLines = 20;
				for ($i=0;$i<$numLines;$i++) {
				fputs($fd,$fileAr[$i]);
				}
				fclose( $fd );
				
				touch("userlist/".$username);
				
echo "<HTML>
<HEAD>
<TITLE>$title</TITLE>
</HEAD>

<!-- frames -->
<frameset  cols=\"85%,*\">

<!-- frames -->
<frameset  rows=\"10%,*,10%\">
    <frame name=\"top\" src=\"top.php?username=$username&uid=$uid\" marginwidth=\"10\" 	marginheight=\"10\" scrolling=\"no\" frameborder=\"no\">
    <frame name=\"main\" src=\"main.php?username=$username\" marginwidth=\"10\" marginheight=\"10\" scrolling=\"auto\" frameborder=\"no\">
    <frame name=\"post\" src=\"send.php?username=$username&uid=$uid\" marginwidth=\"10\" marginheight=\"10\" scrolling=\"no\" frameborder=\"no\">
</frameset>

<frame name=\"right\" src=\"users.php\" marginwidth=\"10\" marginheight=\"10\" scrolling=\"auto\" frameborder=\"no\">
</frameset>


</HTML>";
			
			endif;
	
			// Log Out
	
			if ($option == "logout"):
			
				$date = date("h:ia d M");
			
				$filename = "text.php";
				$fileAr= file($filename);
				exec("cat /dev/null > $filename");
				$fd = fopen( $filename, "a+" );
				$filemessage = "<font color=$color><B>$username left at $date</b></font><br><hr size=1 	noshade>\n";
				fputs($fd,$filemessage);
				
				$numLines = 20;
				for ($i=0;$i<$numLines;$i++) {
					fputs($fd,$fileAr[$i]);
				}
				fclose( $fd );

				exec("rm -rf userlist/$username");
				
				Header("Location: index.php\n\n");
				
			endif;

		else:

			include("header.php");
		
			echo "<font color=$color><B>Oops!</b></font>
		
			<P>Im sorry your password was incorrect. Please try again.";
		
			echo "<form method=\"post\" action=\"login.php\">
			<input type=\"hidden\" name=\"username\" value=\"$username\">
			<P><input type=\"password\" name=\"password\" size=\"25\">
			<input type=\"hidden\" name=\"option\" value=\"$option\">
			<P><input type=\"submit\" value=\"Enter Forum\"></form>";
			
			include("footer.php");

		endif;

	endif;

	if ($option == "lostpasswd"):

	include("header.php");

	include("users/$username.php");

	$passwd = date("sh");
	
	$from = "$title <$fromemail>";
	$subject = "Your Chat Forum Access Details";
	$body = "Your access details are as follows:
	
	User: $username
	Pass: $passwd
	
	We recommend that you go to $myurl, 
	select \"Edit Profile\" and change your password.
	
	Please retain this email for your future reference.\n";
	
	$to = "$email";
	
	mail($to,$subject,$body,"FROM: ".$from);
	
	echo "<font color=$color><B>Success!</b></font>
	<P>Your password has been emailed to <b>$email</b>.
	<P>Please check your email and then
	<a href=\"index.php?username=$username\">login here</a>.";

	$passwd = crypt($passwd, "salt");

	$fileMessage = "<?\n";
	$fileMessage .="\$username = \"$username\";\n";
	$fileMessage .="\$user = \"$id\";\n";
	$fileMessage .="\$passwd = \"$passwd\";\n";
	$fileMessage .="\$pass = \"$new_pass\";\n";
	$fileMessage .="\$name = \"$name\";\n";
	$fileMessage .="\$age = \"$age\";\n";
	$fileMessage .="\$sex = \"$sex\";\n";
	$fileMessage .="\$email = \"$email\";\n";
	$fileMessage .="\$email1 = \"$email1\";\n";
	$fileMessage .="\$city = \"$city\";\n";
	$fileMessage .="\$country = \"$country\";\n";
	$fileMessage .="\$url = \"$url\";\n";
	$fileMessage .="\$descrip = \"$descrip\";\n";
	$fileMessage .="?>";
	$cartFile = fopen("users/$username.php","w");
	fputs($cartFile,$fileMessage);
	fclose($cartFile);
	
	endif;

else:

	include("header.php");		

	echo "<font color=$color><B>Oops!</b></font>
	
	<P>I'm sorry but it appears that your username is not in our database. 
	<p>Please <a href=\"index.php\">try again</a> or <a href=\"register.php\">register</a> a name.";
	
	include("footer.php");
	
endif;

?>