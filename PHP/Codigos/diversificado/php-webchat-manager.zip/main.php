<?

if (file_exists("vars.php")):
	include("vars.php");
endif;	

?>

<?

touch("userlist/".$username);

if ($msg == "post"):

	if ($chat == ""):
	else:

		if (!file_exists("users/$username.php")):
			echo "<font face=\"$font\" size=\"$size\"><b>Your username no longer exists!</b><P>";
		else:
			include("users/$username.php");
		endif;
	
		if ($uid == ""):
		
			echo "<BR><BR><font face=\"$font\" size=\"$size\"><b>I'm sorry, your password was 	incorrect!</b><P>";
		
		else:
			
			if ($uid == "$passwd"):
			
				$chat = ereg_replace("\"","&quot;",$chat);
				$chat = ereg_replace("<","&lt;",$chat);
				$chat = ereg_replace(">","&gt;",$chat);
				
				$filename = "text.php";
				$fileAr= file($filename);
				exec("cat /dev/null > $filename");
				$fd = fopen( $filename, "w+" );
				$filemessage = "<a 	href=\"javascript:launcher('profile.php?username=$username');\"><B>$username</B></a> : ";
				$filemessage .="<font color=\"$fcolor\">$chat</font><BR><hr size=1 noshade>\n";
				fputs($fd,$filemessage);
				
				$numLines = 20;
				for ($i=0;$i<$numLines;$i++) {
					fputs($fd,$fileAr[$i]);
				}
				fclose( $fd );
				
			endif;
			
		endif;

	endif;
		
endif;

?>

<HTML>
<HEAD>
	<TITLE><? echo "$title"; ?></TITLE>
	<META HTTP-EQUIV="Refresh" CONTENT="<? echo "$time"; ?>; URL=main.php?username=<? echo "$username"; ?>">
	
<style TYPE="text/css">
<!--
A:link {text-decoration: none; color:$link; }
A:visited {text-decoration: none; color:$link; }
A:hover {text-decoration: none; color:$link; }
A:active {text-decoration: none; color:$link; }
-->
</style>	

<SCRIPT LANGUAGE='JavaScript'>
<!-- //
function launcher(myUrl) {
myTarget = 'viewprofile';
myArgs = 'width=500,height=350,location=0,menubar=0,resizable=1,scrollbars=1,status=0,titlebar=1,toolbar=0,hotkeys=0,screenx=0,screeny=0,left=0,top=0,dependent=yes';
window.open( myUrl, myTarget, myArgs );
}
// -->
</SCRIPT>

</HEAD>

<?
echo "<body bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">";
echo "<font face=\"$font\" size=\"$size\">";
?>	

<table border="0" cellspacing="0" cellpadding="0">
<tr>
	<td width="400">
	<? echo "<font face=\"$font\" size=\"$size\">"; ?><? $date = date("h:ia d M"); echo "Current time is $date"; ?>
	</td>
	<td>
	<? echo "<font face=\"$font\" size=\"$size\">"; ?>Click name to view users profile
	</td>
</tr>
</table>

<HR size="1" noshade><br>

<?
if (file_exists("text.php")):
	include("text.php");
endif;
?>

</BODY>
</HTML>
