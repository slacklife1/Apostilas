<?

if (file_exists("vars.php")):
	include("vars.php");
endif;	

if (file_exists("header.php")):
	include("header.php");
endif;	

?>

<? echo "<font face=\"$font\" size=\"$size\">"; ?>
<font color="<? echo "$color"; ?>"><b>Welcome to the <? echo "$title"; ?> Room!</b></font>
<P>Existing users login below.

<p><table border="0" cellspacing="0" cellpadding="0">
<tr>
<form method="post" action="login.php">
<td width="220">
<? echo "<font face=\"$font\" size=\"$size\">"; ?>
<font color="<? echo "$color"; ?>"><b>User Name:</b></font>
<BR><input type="text" name="username" size="25" value="<? echo "$username"; ?>">
<BR><font color="<? echo "$color"; ?>"><b>Password:</b></font>
<BR><input type="password" name="password" size="25">
</td>
<td width="200">
<? echo "<font face=\"$font\" size=\"$size\">"; ?>
<input type="Radio" name="option" value="chat" checked> Enter Chat
<BR><input type="radio" name="option" value="edit"> Edit Profile
</td></tr></table>
<P><input type="submit" value=" Enter Chat "></form>

<P>New users <a href="register.php">click here</a> to register.

<P><hr size="1" noshade width="100%" color="black">

<P>Lost your password? Enter your username below.

<P><form method="post" action="login.php">
<input type="hidden" name="option" value="lostpasswd">
<input type="text" name="username" size="25"> 
<input type="submit" value="Send">
</form>

<? 

if (file_exists("footer.php")):
	include("footer.php");
endif;	

?>