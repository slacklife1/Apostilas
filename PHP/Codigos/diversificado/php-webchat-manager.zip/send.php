<?

if (file_exists("vars.php")):
	include("vars.php");
endif;	

?>

<HTML>
<HEAD>
	<TITLE><? echo "$title"; ?></TITLE>
</HEAD>

<?
echo "<body bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">";
echo "<font face=\"$font\" size=\"$size\">";
?>

<form method="post" action="main.php" target="main" onsubmit="this.chat.value=this.chatvis.value;this.chatvis.value='';this.chatvis.focus();">
<input type="hidden" name="username" value="<? echo "$username"; ?>">
<input type="hidden" name="uid" value="<? echo "$uid"; ?>">
<input type="hidden" name="msg" value="post">
<input type="hidden" name="chat" value="">
<input name="chatvis" type="text" size="50" maxlength="300"> 

<select name="fcolor">

<?

$cartFile = File("colors.txt");
$length = sizeof($cartFile);
$i = 0;
while ($i < $length):
$tok = strtok($cartFile[$i],"|");
$code = $tok;
$tok = strtok("|");
$color = $tok;

echo "<option value=\"$code\">$color";
$i++;
endwhile;

?>

<select> 

<input type="submit" value="Send">
</form>

</BODY>
</HTML>
