<?

if (file_exists("vars.php")):
	include("vars.php");
endif;

if (file_exists("header.php")):
	include("header.php");
endif;

?>

<?

if ($register == "yes"):

	$name = ereg_replace("\"","&quot;",$name);
	$city = ereg_replace("\"","&quot;",$city);
	$country = ereg_replace("\"","&quot;",$country);
	$descrip = ereg_replace("\"","&quot;",$descrip);
	
	if ($username == "" || $email == ""):
	
		echo "<font color=$color><B>Oops!</b></font>
		<P>Please complete the following fields:
		
		<form method=\"post\" action=\"register.php\">
		<input type=\"hidden\" name=\"register\" value=\"yes\"><P>";
		
		if ($username == ""):
		
			echo "Please choose a username:
			<input type=\"text\" name=\"username\" size=\"30\" maxlength=\"30\"><BR>";
		else:
				echo "<input type=\"hidden\" name=\"username\" value=\"$username\">";
		endif;
		
		if ($email == ""):
		
			echo "Please enter your email address:
			<BR><input type=\"text\" name=\"email\" size=\"30\" maxlength=\"30\"><BR>";
	
		else:
	
			echo "<input type=\"hidden\" name=\"email\" value=\"$email\">";
	
		endif;
		
		echo "<input type=\"hidden\" name=\"name\" value=\"$name\">
		<input type=\"hidden\" name=\"age\" value=\"$age\">
		<input type=\"hidden\" name=\"sex\" value=\"$sex\">
		<input type=\"hidden\" name=\"email1\" value=\"$email1\">
		<input type=\"hidden\" name=\"city\" value=\"$city\">
		<input type=\"hidden\" name=\"country\" value=\"$country\">
		<input type=\"hidden\" name=\"url\" value=\"$url\">
		<input type=\"hidden\" name=\"descrip\" value=\"$descrip\">
		<P><input type=\"submit\" value=\"Register Now\">
		</form>";
		
	else:

		$username_check = "$username";
			
		$username_check = ereg_replace("\"","",$username_check);
		$username_check = ereg_replace("\"","",$username_check);
		$username_check = ereg_replace("\*","",$username_check);
		$username_check = ereg_replace(" ","",$username_check);
		
		if (file_exists("users/$username.php") || $username_check != "$username"):
		
			echo "<font color=$color><B>Oops!</b></font><BR>";
		
			if (file_exists("users/$username.php")):
				echo "<BR>I'm sorry, that user name is already taken.<BR>Please choose another one.";
			endif;
				
			if ($username_check != "$username"):
				echo "<BR>I'm sorry, the username you have chosen contains characters you cannot use.<BR>Please do not include spaces, double quotes or stars.";
			endif;
		
			echo "<form method=\"post\" action=\"register.php\">
			<input type=\"hidden\" name=\"register\" value=\"yes\">
			<BR><input type=\"text\" name=\"username\" size=\"30\" maxlength=\"30\">";
				
			echo "<input type=\"hidden\" name=\"email\" value=\"$email\">
			<input type=\"hidden\" name=\"name\" value=\"$name\">
			<input type=\"hidden\" name=\"age\" value=\"$age\">
			<input type=\"hidden\" name=\"sex\" value=\"$sex\">
			<input type=\"hidden\" name=\"email1\" value=\"$email1\">
			<input type=\"hidden\" name=\"city\" value=\"$city\">
			<input type=\"hidden\" name=\"country\" value=\"$country\">
			<input type=\"hidden\" name=\"url\" value=\"$url\">
			<input type=\"hidden\" name=\"descrip\" value=\"$descrip\">
			<P><input type=\"submit\" value=\"Register Now\">
			</form>";
		
		else:
		
			$passwd = date("sh");
			$passwd1 = "$passwd";
				
			$passwd = crypt($passwd, "salt");
				
			if ($url == "http://"):
				$url = "";
			endif;
		
			$fileMessage = "<?\n";
			$fileMessage .="\$username = \"$username\";\n";
			$fileMessage .="\$passwd = \"$passwd\";\n";
			$fileMessage .="\$name = \"$name\";\n";
			$fileMessage .="\$age = \"$age\";\n";
			$fileMessage .="\$sex = \"$sex\";\n";
			$fileMessage .="\$email = \"$email\";\n";
			$fileMessage .="\$email1 = \"$email1\";\n";
			$fileMessage .="\$city = \"$city\";\n";
			$fileMessage .="\$country = \"$country\";\n";
			$fileMessage .="\$url = \"$url\";\n";
			$fileMessage .="\$descrip = \"$descrip\";\n";
			$fileMessage .="?>";
			$cartFile = fopen("users/$username.php","w+");
			fputs($cartFile,$fileMessage);
			fclose($cartFile);
		
			$from = "$title <$fromemail>";
			$subject = "Your Chat Forum Access Details";
			$body = "Your access details are as follows:
			
			User: $username
			Pass: $passwd1
			
			We recommend that you go to $myurl, 
			select \"Edit Profile\" and change your password.
			
			Please retain this email for your future reference.
			";
	
			$to = "$email";
			
			mail($to,$subject,$body,"FROM: ".$from);
			
			echo "<center><font color=$color><B>Sucess!</b></font>
			<P>Your chosen name was successfully registered and your password has been emailed to
			<P><b>$email</b>.
			<P>Please check your email and then <a href=\"index.php?username=$username\">login here</a>.</center><br><br><br>";
		
		endif;
			
	endif;

else:

	echo "<P>To use the $title you must first register.
	
	<P><font color=\"$color\"><B>Registration</B></font>
	
	<form method=\"post\" action=\"register.php\">
	<input type=\"hidden\" name=\"register\" value=\"yes\">
	<P>Please choose a username (no spaces allowed):
	<BR><input type=\"text\" name=\"username\" size=\"30\" maxlength=\"30\">
	<BR>Please enter your email address:
	<BR><input type=\"text\" name=\"email\" size=\"30\" maxlength=\"30\">
	
	<P>Once you have completed registration your password to access the Chat Forum will be emailed to you.
	
	<P><font color=\"$color\"><B>Additional Profile Info</B></font>
	
	<P><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
	<tr>
		<td width=\"120\"><font face=\"$font\" size=\"$size\">Name :</td>
		<td width=\"200\"><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"name\" size=\"30\" maxlength=\"30\"></td>
	</tr>
	<tr>
		<td><font face=\"$font\" size=\"$size\">Age:</td>
		<td><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"age\" size=\"30\" maxlength=\"30\"></td>
	</tr>
	<tr>
		<td><font face=\"$font\" size=\"$size\">Sex:</td>
		<td><font face=\"$font\" size=\"$size\">
	<input type=\"radio\" name=\"sex\" value=\"Male\" checked> Male <input type=\"radio\" name=\"sex\" value=\"Female\"> Female 
	</td>
	</tr>
	<tr>
		<td><font face=\"$font\" size=\"$size\">Email:</td>
		<td><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"email1\" size=\"30\" maxlength=\"30\"></td>
	</tr>
	<tr>
		<td><font face=\"$font\" size=\"$size\">City:</td>
		<td><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"city\" size=\"30\" maxlength=\"30\"></td>
	</tr>
	<tr>
		<td><font face=\"$font\" size=\"$size\">Country:</td>
		<td><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"country\" size=\"30\" maxlength=\"30\"></td>
	</tr>
	<tr>
		<td><font face=\"$font\" size=\"$size\">Web Site URL:</td>
		<td><font face=\"$font\" size=\"$size\"><input type=\"text\" name=\"url\" size=\"30\" maxlength=\"50\" value=\"http://\"></td>
	</tr>
	<tr>
		<td valign=\"top\"><br><font face=\"$font\" size=\"$size\">About Yourself:</td>
		<td><font face=\"$font\" size=\"$size\">
	<textarea name=\"descrip\" cols=\"26\" rows=\"6\" wrap=\"PHYSICAL\"></textarea>
	</td>
	</tr>
	</table>
	<P><center><input type=\"submit\" value=\"Register Now!\"></center></form>";

endif;

?>

<? 

if (file_exists("footer.php")):
	include("footer.php");
endif;	

?>