<html>
<head>
<title>Only Shout - By OnlyPHP.Com</title>
<STYLE type = "text/css">
<!-- 
a:link  {
	color : #ff9900;
	text-decoration : none;
}

a:visited  {
	color : #ff9900;
	text-decoration : none;
}

a:active  {
	color : #ff9900;
	text-decoration : none;
}

a:hover  {
	color : #ffA619;
	text-decoration : none;
}
.main
{
font-size: 11px ;
font-family:Verdana , Tahoma;
	text-decoration : none;
}
input {
border-left: 1px solid #DEDEDE; border-right: 1px solid #DEDEDE; border-top: 1px solid #DEDEDE; border-bottom: 1px solid #DEDEDE;
font-family: Verdana, Serif; font-size: 10; font-weight: 100; font-style: normal; text-decoration: none; text-transform: none;
color: #E47804; background: #FFFFFF;
}
#txt
{width:120px;
}
-->
</STYLE>
</head>
<body topmargin=0 leftmargin=0 marginheight=0 marginwidth=0>
<table width=124 border=0 cellspacing=1 cellpadding=1 bgcolor=#9CADB5><tr><td>
<table width=120 border=0 bgcolor="#ECECEC">
<tr><td colspan=2 bgcolor="#ECECEC" class=main><center><font color=#16588B><strong>:: Only Shout ::</font></strong><hr color=#16588B width=110> </center><br><?php include("onlyshout.txt"); ?></td></tr>
<tr><td><table border=0 cellspacing=1 cellpadding=1 bgcolor=#9CADB5><tr><td><table bgcolor=#F5F5F5>
<tr><td colspan=2 class=main><center><strong>Shout !</strong></center></td></tr>
<tr><td><table border=0><tr><td class=main>
<form method="POST" action="shout.php">
Name :</td><td><input size="15" maxlength="15" type="text" name="name"></td></tr><tr><td class=main>
Message :</td><td><input size="15" maxlength="55" type="text" name="message"></td></tr><tr><td class=main>
Url :</td><td><input size="15" maxlength="29" type="text" name="url" value="http://www."></td></tr><tr><td class=main>
Email :</td><td><input size="15" maxlength="25" type="text" name="email" value="your@mail.com"></td></tr><tr><td colspan=2 class=main>
<center>
<input type="submit" value="Shout">&nbsp;&nbsp;&nbsp;<input type="reset" value="Reset"><br>
<a href="#" onClick="javascript:window.open('help.php','smilies','toolbar=0,location=0,directories=0,menuBar=0,scrollbars=1,resizable=1,width=200,height=200,left=50,top=50')"><strong>Smilies?</strong></a> - <a href=javascript:location.reload()><strong>Reload</strong></a>
</center>
</td></tr><tr><td colspan=2 class=main><center><a href=http://www.onlyphp.com/ target=_blank>Only PHP</a></center></table>
</form></tr></td></table>
</td></tr></table></body></html>
