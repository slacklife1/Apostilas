<?php
// Thank You For Downloading Only Shout - ShoutBox
// Coded By : Umut Kale - www.onlyphp.com
// The data file where messages are stored.
$dataf = "onlyshout.txt";

// Max length must be edited in onlyshout.php also.
$length = 55;

// Number of messages shown.
$comments = 12;

//------------------------------
//------------------------------ 
//-------- Do Not Edit ----------
// ------------------------------
// ------------------------------

$textsize = 4;
if (!$name)
{ $name = "||"; }
else $name .= ":";

$name = preg_replace("/>/","&gt;",$name); 
$name = preg_replace("/</","&lt;",$name);
$message = preg_replace("/>/","&gt;",$message); 
$message = preg_replace("/</","&lt;",$message);
$message = str_replace("ASSHOLE","****",$message);
$message = str_replace("FUCK","****",$message);
$message = str_replace("fuck","****",$message);
$message = str_replace("bitch","****",$message);
$message = str_replace("asshole","****",$message);
$message = str_replace("cunt","****",$message);
$message = str_replace("bullshit","****",$message);
$message = str_replace("shit","****",$message);
$message = str_replace(":)","<img src='smile.gif'>",$message);
$message = str_replace(":8","<img src='smile-2.gif'>",$message);
$message = str_replace(":wacko:","<img src='wacko.gif'>",$message);
$message = str_replace(":huh:","<img src='unsure.gif'>",$message);
$message = str_replace(":P","<img src='toung.gif'>",$message);
$message = str_replace(":suspicious:","<img src='suspicious.gif'>",$message);
$message = str_replace(":hehe:","<img src='wink.gif'>",$message);
$message = str_replace(":worried:","<img src='worried.gif'>",$message);
$message = str_replace(":eek:","<img src='weird.gif'>",$message);
$message = str_replace(":(","<img src='sad.gif'>",$message);
$message = str_replace(":sad:","<img src='sad-2.gif'>",$message);
$message = str_replace(":x","<img src='sick.gif'>",$message);
$message = str_replace(":rolleyes:","<img src='rolleyes.gif'>",$message);
$message = str_replace(":push:","<img src='push.gif'>",$message);
$message = str_replace(":0","<img src='oh.gif'>",$message);
$message = str_replace(":o","<img src='amazed.gif'>",$message);
$message = str_replace("8()","<img src='nuts.gif'>",$message);
$message = str_replace(":|","<img src='notrust.gif'>",$message);
$message = str_replace(":mad:","<img src='mad.gif'>",$message);
$message = str_replace(":lol:","<img src='laugh.gif'>",$message);
$message = str_replace(":huh:","<img src='huh.gif'>",$message);
$message = str_replace(":blush:","<img src='embarrest.gif'>",$message);
$message = str_replace(":cry:","<img src='crying.gif'>",$message);
$message = str_replace(":cool:","<img src='cool.gif'>",$message);
$message = str_replace(":confused:","<img src='confused.gif'>",$message);
$message = str_replace(":cheese:","<img src='cheesy.gif'>",$message);
$message = str_replace(":blink:","<img src='blink.gif'>",$message);
$message = str_replace(":big:","<img src='bigsmile.gif'>",$message);
$message = str_replace(":amuse:","<img src='amuse.gif'>",$message);
	$message = stripslashes($message);
$wrap = intval((35)/($textsize-2))+1;
$message = wordwrap($message, $wrap, ' ', 1);
$comfile = file($dataf);if ($message != "") {$df = fopen ($dataf, "w");$message = stripslashes($message);fwrite ($df, "<i><a href=mailto:$email>@</a> <a href=$url target=_blank>$name</a></i> $message\n<br>");for ($i = 0; $i < $comments; $i++) {fwrite ($df, $comfile[$i]);}fclose($df);}
Header("Location: $HTTP_REFERER");
?>
