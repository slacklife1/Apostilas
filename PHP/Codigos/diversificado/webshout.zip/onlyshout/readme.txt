Installation : 

1.  Upload onlyshout.txt file to your server and chmod it to 777

2. To use this script in .php files use : 
       <?php include("onlyshout.php"); ?>

    To use this script in a html page use : 
      <iframe src=onlyshout.php width=185 height=250 frameborder=0 scrolling=yes></iframe>
(Make necessary width - height changes which applies to your page)
   
   To use it in a simple page just use : 
         http://www.yourdomain.com/onlyshout.php

3.  To make max length , comment changes open shout.php and edit the variables if necessary.

4. Updates : Smilies added ,
                  Bad word sensor added , 
                  A little bug fixed.

Any Questions / Comments ?
Please don't hestitate to contact us at :
admin@onlywebmasters.com


Our Sites :
www.onlyphp.com
www.onlywebmasters.com
www.onlycgi.com
www.onlysubmission.com
www.onlyforums.com
www.desro.com
www.webmaster-topsites.com