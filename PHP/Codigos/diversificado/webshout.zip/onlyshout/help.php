<html>
<head>
<title>OnlyShout - Smilies Help</title>
<STYLE type = "text/css">
<!-- 
a:link  {
	color : #ff9900;
	text-decoration : none;
}
a:visited  {
	color : #ff9900;
	text-decoration : none;
}
a:active  {
	color : #ff9900;
	text-decoration : none;
}
a:hover  {
	color : #ffA619;
	text-decoration : none;
}
.main
{
font-size: 11px ;
font-family:Verdana , Tahoma;
	text-decoration : none;
}
input {
border-left: 1px solid #DEDEDE; border-right: 1px solid #DEDEDE; border-top: 1px solid #DEDEDE; border-bottom: 1px solid #DEDEDE;
font-family: Verdana, Serif; font-size: 10; font-weight: 100; font-style: normal; text-decoration: none; text-transform: none;
color: #E47804; background: #FFFFFF;
}
#txt
{width:120px;
}
-->
</STYLE>
</head>
<body topmargin=0 leftmargin=0 marginheight=0 marginwidth=0>
<table width="164" border="0" bgcolor=#000020 align="center" cellpadding="1" cellspacing="1" >
<tr><td>
<table width=160 bgcolor="#EFEBEF" cellspacing=2 cellpadding=2>
<tr><td bgcolor="#EFEBEF" class=main>Smilie Codes while posting a message : <br><i>Example : If you want to view <img src='smile.gif'> just type :)</i></td></tr><td align=center>
<table width=80><tr><td width=100% class=main>
<p><br>
<img src='smile.gif'>  :) <br>
<img src='smile-2.gif'>  8)<br>
<img src='wacko.gif'>  :wacko:<br>
<img src='unsure.gif'>  :huh:<br>
<img src='toung.gif'>  :P<br>
<img src='suspicious.gif'>  :suspicious:<br>  
<img src='wink.gif'>  :hehe:<br>
<img src='worried.gif'>  :worried:<br>
<img src='weird.gif'>  :eek:<br>
<img src='sad.gif'>  :(<br>
<img src='sad-2.gif'>  :sad:<br>
<img src='sick.gif'>  :X<br>
<img src='rolleyes.gif'>  :rolleyes:<br>
<img src='push.gif'>  :push:<br>
<img src='oh.gif'>  :0<br>
<img src='amazed.gif'> :o<br> 
<img src='nuts.gif'>  8()<br>
<img src='notrust.gif'>  :|<br>
<img src='mad.gif'>  :mad:<br>
<img src='laugh.gif'>  :lol:<br>
<img src='huh.gif'>  :huh:<br>
<img src='embarrest.gif'> :blush:<br>  
<img src='crying.gif'>  :cry:<br>
<img src='cool.gif'>  :cool:<br>
<img src='confused.gif'> :confused: <br>
<img src='cheesy.gif'>  :cheese:<br>
<img src='blink.gif'>  :blink:<br>
<img src='bigsmile.gif'>  :big:<br>
<img src='amuse.gif'>  :amuse:<br>
</td></tr>

</td></tr>
</table>
</tr></td></table>
</td></tr></table>
