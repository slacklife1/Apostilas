/*
EasyLetter 1.1
This script is part of Onlinetools 
http://www.onlinetools.org/easyletter/
for technical info contact Chris (info@onlinetools.org)
(c) Chris Heilmann
free of use with these lines included!  

// DEBUGGED 01.05.01, please upgrade older Versions

*/

A newsletter for your page - EasyLetter creates a massmail / mailinglist in PHP

Did you ever want to offer a newsletter for your page, but you don't want to add the
emails by hand? With Easyletter you have a full newsletter script in one document! 
Users can subscribe/unsubscribe from the letter and by adding a password you get a
Form where you simply enter your email, and it will be sent to all subscribed
users. People who apply for the first time get a welcome email.

Usage

Easyletter is one big PHP script. In the first lines you can define all the general
settings and displayed messages. The variables are:

$pass="";
The password you need to add to the url for getting the email form
$filelocation="subscribers.txt";
The name of the textfile that contains the subscriber data.
$lettername="Onlinetools.org Newsletter";
Title of the newsletter, will be displayed in the FROM field of the mailclient
$youremail="info@onlinetools.org";
Your email, will be the reply-to mail
$welcomemessage
Welcome message displayed above the form for subscribing/unsubscribing

$sorrysignmessage
Sorrymessage for failed subscription, will be followed by the email!

$subscribemessage
Subscribe message, will be displayed when subscribing

$subscribemail
Subscribemail, will be sent when someone subscribes.

$unsubscribemessage
Unsubscribemessage for deletion, will be followed by the email!

$failedunsubscriptionmessage
Unsubscribemessage for failed deletion, will be followed by the email!

When you defined the variables, create a blank file with the filename defined in $filelocation and chmod that one to 777.

Put the code in your newsletter html page and you are all set. To send an email, simply call the page with a ?pw=yourpassword attached to its url.
The newsletter on this page was done with this script.

Easyletter is a PHP sourcecode and a read_me file in one small zip. The code is highly documented, so tweaking it for your purposes should't be a problem. 
