<?
$smsto="number@yourmobileserviceprovider.com";
$subject="SITESMS";
?>
<html>

        <head>
                <meta http-equiv="content-type" content="text/html;charset=windows-1251">
		<title>contact me / send sms</title>
		<script Language="JavaScript"><!--

var s=0;
var str='/send';

function len(F)
{
  F.counter.value = F.message.value.length+1;
}

//--></script>
	</head>

        <body bgcolor="#336699" leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" link="white" text="black" vlink="white">
                <div align="center">
			<table border="0" cellpadding="0" cellspacing="5" width="100%">
				<tr>
					<td><? if ($action==send) {
$fromemail="a@a.kg";
$bodytext="$message";
$body="$bodytext";
mail($smsto, $subject, $body, "From: $fromemail
X-Mailer: PHP/" . phpversion());
echo"<p class=text1><i>Thanx, your message have been sent! You can send one more :)</i></p>";
}
?>
						<form method="POST" onsubmit="return Sub1()" name="Form1" align=center action='<? echo"sms.php?action=send";?>'>
							<p>Almost every mobile service provider has sms service with such feature as redirection of your emial to sms. It looks like that: 7538425@yourserviceprovider.com, where 7538425 if yours mobile phone number. So if you'll send email to that address, you'll receive it as sms on your mobile phone! </p>
							<p>Open source and edit line 3. You can add new fileds such as name and email and receive them in message body too!</p>
							<table border=0 cellspacing=2 cellpadding=0>
								<tr>
									<td>
										<p class="text1"><b>Message:</b></p>
									</td>
									<td valign="top" align=left><textarea id=input2 name=message rows=5 cols=18 wrap=no onkeypress="len(Form1)"></textarea></td>
								</tr>
								<tr>
									<td>
										<p class="text1"><b>Length:</b></p>
									</td>
									<td valign="top" align=left><input id=input2 type=text name="counter" size=4 value="0" onfocus="Form1.message.focus();"></td>
								</tr>
								<tr>
									<td valign="top" align=left></td>
									<td valign="top" align=left><INPUT TYPE="image" ID="img_send" SRC="../../images/contact/send_btn.gif" width="84" height="15" border="0" name="Ok" value="��������� (Send)"></td>
								</tr>
							</table>
							<p class="text2"><b>please be atentive - max length of the message is <i>160</i> chars</b></p>
						</form>
					</td>
				</tr>
			</table>
		</div>
        </body>

</html>