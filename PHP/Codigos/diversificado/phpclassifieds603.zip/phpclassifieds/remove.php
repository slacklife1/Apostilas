<?
session_start( );
session_destroy(); 
 
  require("config/header.inc.php");
  require("config/config.inc.php");
  if (!$special_mode)
{ print("$menu_ordinary<p>"); }
print("<h2>$name_of_site</h2>");

?>
<font class="text"><? echo $la_session_remove ?></font>
<?
require("config/footer.inc.php");
?>

