<?
session_start( );
require("config/config.inc.php");
require("config/header.inc.php");
if (!$simple_structure)
{
	require("check.php");
}
?>
<script LANGUAGE="JavaScript">
function openWin(URL) {
aWindow=window.open(URL,"Stort_bilde","toolbar=no,width=400,status=no,scrollbars=yes,resize=yes,menubars=no");
}
</script>
<?
if ($userid AND $pass AND !$submit)
{
 $sql_select = "select name,adressfield1,adressfield2,adressfield3,phone,email,pass,country,hide_email,custom_1 from $usr_tbl where userid = '$userid' and pass = '$pass'";
 $result = mysql_query ($sql_select);
 $row = mysql_fetch_array($result);
 $name = $row["name"];
 $adressfield1 = $row["adressfield1"];
 $adressfield2 = $row["adressfield2"];
 $adressfield3 = $row["adressfield3"];
 $phone = $row["phone"];
 $email = $row["email"];
 $mode = "update";
}


if (!$special_mode) { print("$menu_ordinary<p>"); }

print("<p><h2>$name_of_site</h2>");
if (!$submit AND !$mode) {
print("<font class='text'>$welcom_message_user_reg</font><br>"); }
elseif ($mode==update)
{
print("<font class='text'>$welcom_message_change</font><br>");
if ($mode) { $pass_two = $pass; }
} 


if ($submit) 
{

	if (!$pass || !$name || !$email || !$pass_two)
	{
			
			print("<ol>");
			print("<li><font color='red'>$lang_required_fields_missing</font></li>");
			
			
			if ($debug)
			{
					print("pass: $pass - name: $name - email $email - pass_two $pass_two");
			}
			
			if ($pass <> $pass_two)
			{			
				print("<li><font color='red'>$lang_no_match_password</font></li>");
			}
			print("</ol>");
			require("html_add_user.php");
			
			
	}
	
	else
	{
		// If all fields contains charachters, continue the insert
		
		if ($mode <> 'update')
		{
			
			$name = strip_tags ("$name");
 			$adressfield1 = strip_tags ("$adressfield1");
 			$adressfield2 = strip_tags ("$adressfield2");
 			$adressfield3 = strip_tags ("$adressfield3");
 			$phone = strip_tags ("$phone");
 			$email = strip_tags ("$email");
 			$hide_email = strip_tags ("$hide_email");
 			$pass = strip_tags ("$pass");
 			$emelding = strip_tags ("$emelding");
 			$country = strip_tags ("$country");
 			$custom1 = strip_tags ("$custom1");
		 	
		 	
		 	$sql_insert = "insert into $usr_tbl (name,adressfield1,adressfield2,adressfield3,phone,email,pass,emelding,country, hide_email, custom_1) values ('$name','$adressfield1','$adressfield2','$adressfield3','$phone','$email','$pass', '$emelding', '$country', '$hide_email', '$custom_1')";
  	 		$result = mysql_query ($sql_insert);
		}
		else
		{
					$name = strip_tags ("$name");
 			$adressfield1 = strip_tags ("$adressfield1");
 			$adressfield2 = strip_tags ("$adressfield2");
 			$adressfield3 = strip_tags ("$adressfield3");
 			$phone = strip_tags ("$phone");
 			$email = strip_tags ("$email");
 			$hide_email = strip_tags ("$hide_email");
 			$pass = strip_tags ("$pass");
 			$emelding = strip_tags ("$emelding");
 			$country = strip_tags ("$country");
 			$custom1 = strip_tags ("$custom1");
		 	
		 	$sql_update = "update $usr_tbl set name='$name',adressfield1='$adressfield1',adressfield2='$adressfield2',adressfield3='$adressfield3',phone='$phone',email='$email', hide_email='$hide_email' where userid = '$userid'";
  	 		$result = mysql_query ($sql_update);
		}

		if ($mode <> 'update')
		{
		 	 $reg = mysql_insert_id();													
			 $userid = $reg;
			 require("config/config.inc.php");												
			 session_register("userid","pass");
		
		
														
		// setup variables
		$sendto = "$email";
		$from = "$from_adress";
		$subject = "$subjectfield_email";
		$message = "$messagefield_email";
		$headers = "From: $from\r\n";
		// send e-mail
		mail($sendto, $subject, $message, $headers);
		
		print("<font class='text'>$registered_user</font><br>");
		require("categories_listbox_select_main.php");
		}
		else
		{
		print("$updated_user");
		//session_register("userid","pass");
		}


	}
	
}
else
{
	// If not submit, show html_ad_user.php
	require("html_add_user.php");
} 



require("config/footer.inc.php");
?>	