<?

$sql_delete = "delete from $ads_tbl where siteid = $siteid";
   
                                      
$result = mysql_query ($sql_delete);

if($debug)
{
print("$sql_delete");
}

?>