<?
require("config/config.inc.php");
$sql_links = "select * from $ads_tbl";
$sql_result = mysql_query ($sql_links);
$antall =  mysql_num_rows($sql_result);

for ($i=0; $i<$antall; $i++)
{
			
		$myrow = mysql_fetch_array($sql_result);
		$siteid = $myrow["siteid"];
		$sites_userid = $myrow["sites_userid"];

		$sql2 = mysql_query ("select userid from $usr_tbl where userid = $sites_userid");
		$ant = mysql_num_rows($sql2);
		
		if ($ant == 0)
		{
			print("delete $siteid with userid $sites_userid and siteid $siteid<br>");
			$result123=MYSQL_QUERY("delete from $ads_tbl where siteid=$siteid");
		}
	
}
?>