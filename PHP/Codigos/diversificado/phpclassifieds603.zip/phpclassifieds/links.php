<?

if (!$order)
{
	$order = "siteid desc";
}

if (!$tall | $tall==1) { $fra=0;   $til=$number_of_ads_per_page;   }
else
{
	$fra = ($tall * $number_of_ads_per_page) - $number_of_ads_per_page;	
	$til = ($number_of_ads_per_page);
}

if ($latestmode)
{
 $sql_string = "select * from $ads_tbl, $cat_tbl, $usr_tbl where catid=sitecatid AND ad_username = $usr_tbl.email order by siteid desc limit 30";
 print("<h3>$la_view_l</h3>");
}
elseif ($latestfrontpage)
{
 $sql_string = "select * from $ads_tbl, $cat_tbl, $usr_tbl where catid=sitecatid AND ad_username = $usr_tbl.email order by siteid desc limit 10";
 print("<h3>$la_view_l</h3>");
}
elseif ($searchword AND !$adv)
{
 if (!$catid) { $catid = '%%'; }
 $sql_string = "select * from $ads_tbl, $cat_tbl where catid=sitecatid AND (sitetitle like '%$searchword%' or catname like '%$searchword%' or sitedescription like '%$searchword%') AND catfatherid like '$catid' order by $order limit $fra, $til";
 print("<h3>$la_search_result</h3>");
}
elseif ($mostviewed)
{
 $sql_string = "select * from $ads_tbl, $cat_tbl, $usr_tbl where catid=sitecatid AND ad_username = $usr_tbl.email order by sitehits desc limit 30";
 print("<h3>$la_most_viewed</h3>");
}
elseif ($adv)
{

 
 $sql = "select ad_username from $ads_tbl where siteid = $siteid";
 $sql_resultads = mysql_query ($sql);
 $num_ads =  mysql_num_rows($sql_resultads);
 
 for ($i=0; $i<$num_ads; $i++)
 {
      $row = mysql_fetch_array($sql_resultads);
      $ad_username = $row["ad_username"];
 }
 
 if (!$catid) { $catid = '%%'; }
 if (!$searchword) { $searchword = '%%'; }
 if (!$s_userid) { $s_userid = '%%'; }
 if (!$s_email) { $s_email = '%%'; }
 $sql_string = "select * from $ads_tbl, $cat_tbl where catid=sitecatid AND (sitetitle like '%$searchword%' or catname like '%$searchword%' or sitedescription like '%$searchword%') AND catfatherid like '$catid' AND $ads_tbl.ad_username = '$ad_username' order by $order limit $fra, $til";
 print("<h3>$la_search</h3>");
}
else
{
 $sql_string = "select * from $ads_tbl, $cat_tbl, $usr_tbl where catid=sitecatid AND sitecatid='$kid' AND ad_username = $usr_tbl.email order by $order limit $fra, $til";
}

$sql_resultads = mysql_query ($sql_string);
$num_ads =  mysql_num_rows($sql_resultads);
$color = "#eeeeee";

//----- Remove Toolbar if no results


if ($kid AND $num_ads>0)
{
	$catname = urlencode($catname);
	
	
	$filename = "templates/links_headrow.html";
	$fd = fopen ($filename, "r");
	$file= fread ($fd, filesize ($filename));
	$file = str_replace("{CATEGORYNAME}", "$category", $file);
	$file = str_replace("{TOTAL_ADS}", "$total", $file);
	if (!$latestfrontpage AND !$latestmode AND !$searchmode AND !$mostviewed AND !$adv) { $file = str_replace("{CATEGORY_URL}", "<a href=\"index.php?kid=$kid&catname=$catname&order=catname&searchword=$searchword&s_userid=$s_userid&adv=$adv&siteid=$siteid\">", $file); }
	else { $file = str_replace("{CATEGORY_URL}", "", $file); }
  	$file = str_replace("{/CATEGORY_URL}", "</a>", $file);
  	if (!$latestfrontpage AND !$latestmode AND !$searchmode AND !$mostviewed AND !$adv) { $file = str_replace("{AD_URL}", "<a href=\"index.php?kid=$kid&catname=$catname&tall=$tall&order=sitetitle&searchword=$searchword&s_userid=$s_userid&adv=$adv&siteid=$siteid\">", $file); }
  	else { $file = str_replace("{AD_URL}", "", $file); }
	$file = str_replace("{AD_URL}", "<a href=\"?kid=$kid&catname=$catname&tall=$tall&order=sitetitle&searchword=$searchword&s_userid=$s_userid&adv=$adv&siteid=$siteid\">", $file);
	$file = str_replace("{/AD_URL}", "</a>", $file);
	$file = str_replace("{ADTITLE}", "$title", $file);
	$file = str_replace("{CUSTOM_FIELD1}", "$custom_field_1_text", $file);
	$file = str_replace("{CUSTOM_FIELD2}", "$custom_field_2_text", $file);
	$file = str_replace("{CUSTOM_FIELD3}", "$custom_field_3_text", $file);
	$file = str_replace("{CUSTOM_FIELD4}", "$custom_field_4_text", $file);
	$file = str_replace("{CUSTOM_FIELD5}", "$custom_field_5_text", $file);
	$file = str_replace("{CUSTOM_FIELD6}", "$custom_field_6_text", $file);
	$file = str_replace("{CUSTOM_FIELD7}", "$custom_field_7_text", $file);
	$file = str_replace("{CUSTOM_FIELD8}", "$custom_field_8_text", $file);
  if (!$latestfrontpage AND !$latestmode AND !$searchmode AND !$mostviewed AND !$adv) { $file = str_replace("{DATE_URL}", "<a href=\"?kid=$kid&catname=$catname&tall=$tall&order=siteid&searchword=$searchword&s_userid=$s_userid&adv=$adv&siteid=$siteid\">", $file); }
  else { $file = str_replace("{DATE_URL}", "", $file); }
	$file = str_replace("{/DATE_URL}", "</a>", $file);
  $file = str_replace("{DATEADDED}", "$date_added", $file);
  $file = str_replace("{YESNOPICTURE}", "$picture_text", $file);

	print($file);

}

if ($kid AND $num_ads == 0)
{
	
	if (!$simple_structure)
	{
		$sql_categories = mysql_query("select * from $cat_tbl where catfatherid <> 0 AND catid = $kid"); 
		$subcats = mysql_num_rows($sql_categories); 
		
		if ($subcats)
		{
			print "$la_no_ads";
		}
		
	}
}




for ($i=0; $i<$num_ads; $i++)
{
      $row = mysql_fetch_array($sql_resultads);
      $siteid = $row["siteid"];
      $sitetitle = $row["sitetitle"];
      $sitedescription = $row["sitedescription"];
      $siteurl = $row["siteurl"];
      $sitedate = $row["sitedate"]; 
      $sitehits = $row["sitehits"];
      $sitevotes = $row["sitevotes"];
      $name = $row["name"];
      $phone = $row["phone"];
      $email = $row["email"];
      $sitevotes = $row["sitevotes"];
      $adressfield1 = $row["adressfield1"];
      $adressfield2 = $row["adressfield2"];
      $catname = $row["catname"];
      $datestamp = $row["datestamp"];
      $year=substr($row[datestamp],0,4);
      $month=substr($row[datestamp],4,2);
      $day=substr($row[datestamp],6,2);
      $regdate = "$day.$month.$year";
      $custom_field_1 = $row["custom_field_1"];
      $custom_field_2 = $row["custom_field_2"];
      $custom_field_3 = $row["custom_field_3"];
      $custom_field_4 = $row["custom_field_4"];
      $custom_field_5 = $row["custom_field_5"];
      $custom_field_6 = $row["custom_field_6"];
      $custom_field_7 = $row["custom_field_7"];
      $custom_field_8 = $row["custom_field_8"];
      $picture = $row["picture"];
      $img_stored = $row["img_stored"];
				
																
if ($color == "#eeeeee")
{
		$color = "#FFFFFF";
}
elseif ($color== "#FFFFFF")
{
 		$color = "#eeeeee";
}

// -----

if ($picture)
{
	 $p = $yes;
}
elseif ($img_stored <> '') 
{ 
 $p = $yes; 
}
else 
{ 
	$p = $no; 
}



	$filename = "templates/links.html";
	$fd = fopen ($filename, "r");
	$file= fread ($fd, filesize ($filename));
	$file = str_replace("{CATEGORYNAME}", "$catname", $file);
	$file = str_replace("{AD_URL}", "<a href=\"detail.php?siteid=$siteid\">", $file);
	$file = str_replace("{/AD_URL}", "</a>", $file);
	$file = str_replace("{TITLE}", "$sitetitle", $file);
	$file = str_replace("{CUSTOM_FIELD1}", "$custom_field_1", $file);
	$file = str_replace("{CUSTOM_FIELD2}", "$custom_field_2", $file);
	$file = str_replace("{CUSTOM_FIELD3}", "$custom_field_3", $file);
	$file = str_replace("{CUSTOM_FIELD4}", "$custom_field_4", $file);
	$file = str_replace("{CUSTOM_FIELD5}", "$custom_field_5", $file);
	$file = str_replace("{CUSTOM_FIELD6}", "$custom_field_6", $file);
	$file = str_replace("{CUSTOM_FIELD7}", "$custom_field_7", $file);
	$file = str_replace("{CUSTOM_FIELD8}", "$custom_field_8", $file);
	$file = str_replace("{REGDATE}", "$regdate", $file);
	$file = str_replace("{IMAGEYESNO}", "$p", $file);
	$file = str_replace("{COLOR}", "$color", $file);	
	
	print("$file");



}

if ($kid)
{
	//print("</table>");
}
// Previos and next link generator
print ("<tr><td><p><font face='Verdana' size='1'>");
if (!$latestmode)
{
 $sql_links = "select * from $cat_tbl, $ads_tbl, $usr_tbl where catid=sitecatid AND sitecatid='$kid' AND sites_userid = $usr_tbl.userid order by $order";
 $sql_result = mysql_query ($sql_links);
 $num_links =  mysql_num_rows($sql_result);


 if ($tall>1)
 {
 	 	$tallet = $tall - 1;
		print("&nbsp;<a href='?kid=$kid&catname=$catname&tall=$tallet&searchword=$searchword'><b>$previous_ads</b></a>&nbsp;");
 }
 if ($num_links>$number_of_ads_per_page)
 {
	if (!$tall)
	{
	 	 $tallet = $tall + 2;
		 print("<a href='?kid=$kid&catname=$catname&tall=$tallet&searchword=$searchword'><b>$next_ads</b></a>&nbsp;");
	}	
	else
	{
	 		$tallet = $tall + 1;
			print("<a href='?kid=$kid&catname=$catname&tall=$tallet&searchword=$searchword'><b>$next_ads</b></a>&nbsp;");
			
	}
 }
}
print ("</td></tr></font>");
if ($kid) 
{ 
print("</table>"); 
} 
 
?>