<?
session_start( );
include_once("config/header.inc.php");
include_once("config/config.inc.php");
if (!$special_mode) { print("$menu_ordinary<p>"); }
print("<h2>$name_of_site</h2>");
print "<table border='1' cellpadding='2' width='100%' bgcolor='#DDDDDD' bordercolordark='#FFFFFF'>";
print "<tr>";
print "<td><font face='Verdana' size='1'><b>$la_admmenu</b></font></td>";
print "<td>&nbsp;</td>";
print "<td align='right'><font face='Verdana' size='1'>$la_logged_in: $valid_user</font></td>";
print "</tr>";
print "<tr>";
print "<td><a href='member.php'><font face='Verdana' size='1'><b>$la_admin_frontpage</b></font></a></td>";
print "<td><a href='change.php'><font face='Verdana' size='1'><b>$change_user</b></font></a></td>";
print "<td><a href='pass.php'><font face='Verdana' size='1'><b>$la_change_pass</b></font></a></td>";
print "</tr>";
print "</table>";
?>

<?

print("<table><tr><td>");
if (!$submit)
{
 require_once("functions.php");
 check_valid_user();
}


// ## Some default code that can be useful
$dagens_dato = date("d.m.Y");
$dy =  date("d");
$mn =  date("m");
$yr = date("Y");
$expiredate = strftime("%d.%m.%Y", mktime(0,0,0,$mn,$dy+$delete_after_x_days,$yr));

if ($submit)
{ 
 	  $sitetitle = strip_tags ("$sitetitle");
 		$sitedescription = strip_tags ("$sitedescription");
 		$custom_field_1 = strip_tags ("$custom_field_1");
 		$custom_field_2 = strip_tags ("$custom_field_2");
 		$custom_field_3 = strip_tags ("$custom_field_3");
 		$custom_field_4 = strip_tags ("$custom_field_4");
 		$custom_field_5 = strip_tags ("$custom_field_5");
 		$custom_field_6 = strip_tags ("$custom_field_6");
 		$custom_field_7 = strip_tags ("$custom_field_7");
 		$custom_field_8 = strip_tags ("$custom_field_8");
 		$f1 = strip_tags ("$f1");
 		$f2 = strip_tags ("$f2");
		$f3 = strip_tags ("$f3");
		$f4 = strip_tags ("$f4");
		$f5 = strip_tags ("$f5");
		$f6 = strip_tags ("$f6");
		$f7 = strip_tags ("$f7");
		$f8 = strip_tags ("$f8");
		$f9 = strip_tags ("$f9");
		$f10 = strip_tags ("$f10");
		$f11 = strip_tags ("$f11");
		$f12 = strip_tags ("$f12");
		$f13 = strip_tags ("$f13");
		$f14 = strip_tags ("$f14");
		$f15 = strip_tags ("$f15");
		
		
		
			 // A field is not filled out, wich one ?
			 print("<ol>");
 			 if (!$sitetitle)
			 {
					print("<font class='text'><li><font color='red'>$la_error_msg1</font></li></font>");
					$error = 1;
			 
			 }
			 if (!$sitedescription)
			 {
		 	 		print("<font class='text'><li><font color='red'>$la_error_msg2</font></li></font>");
					$error = 1;
			 }
			 
			 if ($f1_mandatory == 'on' AND $f1 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f2_mandatory == 'on' AND $f2 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f3_mandatory == 'on' AND $f3 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f4_mandatory == 'on' AND $f4 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f5_mandatory == 'on' AND $f5 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f6_mandatory == 'on' AND $f6 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f7_mandatory == 'on' AND $f7 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f8_mandatory == 'on' AND $f8 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f9_mandatory == 'on' AND $f9 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f10_mandatory == 'on' AND $f10 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f11_mandatory == 'on' AND $f11 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f12_mandatory == 'on' AND $f12 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f13_mandatory == 'on' AND $f13 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f14_mandatory == 'on' AND $f14 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 if ($f15_mandatory == 'on' AND $f15 == '')
			 {
			 		print("<font class='text'><li><font color='red'>$err_add</font></li></font>");
					$error = 1;
			 }
			 
			 
			 
			 if (!$sitecatid)
			 {
		 	 		print("<font class='text'><li><font color='red'>$la_error_msg3</font></li></font>");
					$error = 1;
			 }
			 
			 
			 print("</ol>");
			 

		
		
		if (!$error)
		{	 
			 		 
			 // Insert or Update, that is the question ... 
			 if ($siteid)
			 {
			 		$mode = "update";
			 		$sql_update = "update $ads_tbl set sitetitle='$sitetitle',sitedate='$dagens_dato', expiredate='$expiredate', sitedescription='$sitedescription',siteurl='$siteur',sitecatid=$sitecatid,sitehits='$sitehits',sitevotes='$sitevotes', custom_field_1='$custom_field_1', custom_field_2='$custom_field_2', custom_field_3='$custom_field_3', custom_field_4='$custom_field_4', custom_field_5='$custom_field_5', custom_field_6='$custom_field_6', custom_field_7='$custom_field_7', custom_field_8='$custom_field_8', f1='$f1',f2='$f2',f3='$f3',f4='$f4',f5='$f5',f6='$f6',f7='$f7',f8='$f8',f9='$f9',f10='$f10',f11='$f11',f12='$f12',f13='$f13',f14='$f14',f15='$f15' where siteid = '$siteid'";
					$result = mysql_query ($sql_update);
					
			 }
			 else
			 {
			 		if ($auto)
					{
					 	 include("update.php");
					}
					$mode = "insert";
					$sql_insert = "insert into $ads_tbl (
								 ad_username,
								 sitetitle,
								 sitedescription,
								 siteurl,
                 sitedate,
                 expiredate,
                 sitecatid,
                 sitehits,
                 sitevotes,
                 sites_userid,
                 sites_pass,
                 custom_field_1,
                 custom_field_2,
                 custom_field_3,
                 custom_field_4,
                 custom_field_5,
                 custom_field_6,
                 custom_field_7,
                 custom_field_8,
								 f1,
 								 f2,
								 f3,
								 f4,
								 f5,
								 f6,
								 f7,
								 f8,
								 f9,
								 f10,
								 f11,
								 f12,
								 f13,
								 f14,
								 f15
								 )
                 values
                 (
								 '$valid_user',
                 '$sitetitle',
                 '$sitedescription',
                 '$siteurl',
                 '$dagens_dato',
                 '$expiredate',
                 '$sitecatid',
                 '$sitehits',
                 '$sitevotes',
                 '$userid',
                 '$pass',
                 '$custom_field_1',
                 '$custom_field_2',
                 '$custom_field_3',
                 '$custom_field_4',
                 '$custom_field_5',
                 '$custom_field_6',
                 '$custom_field_7',
                 '$custom_field_8',
								 '$f1',
 								 '$f2',
								 '$f3',
								 '$f4',
								 '$f5',
								 '$f6',
								 '$f7',
								 '$f8',
								 '$f9',
								 '$f10',
								 '$f11',
								 '$f12',
								 '$f13',
								 '$f14',
								 '$f15')";
                 
								 $result = mysql_query ($sql_insert);
								 $adid = mysql_insert_id(); 
	     					 //print "$sql_insert";		 
					}// Insert or Update resolved
		
 		
	
	if ($picture_upload_enable)
	{
	 	 if (!$adid)
		 {
		 		$adid = $siteid;
		 }
	 	 if ($fileimg_upload == 1)
	 	 {
 	 	 		$url_forward = "upload_file.php?pictures_siteid=$adid";
	 	 }
	 	 else
   	 {
    		$url_forward = "upload_new.php?pictures_siteid=$adid";
   	 }
		
		 print "<font class='text'><b>Pictureupload?</b><br>You can now choose to upload a picture to your ad.<br>";
		 print "Choose:<br><a href='$url_forward'>I want to upload a picture</a><br>";
		 print "<a href='index.php'>Return to frontpage</a><br>";
		 print "<a href='member.php'>Add Another ad</a><br>";
	} // End picture upload            
	

	require("config/config.inc.php");
	$sendto = "$from_adress";
	$from = "$from_adress";
	$subject = "$admin_new_ad_subject";
	$message = "$admin_new_ad";
	$headers = "From: $from\r\n";
	// send e-mail
	mail($sendto, $subject, $message, $headers);
} // End of Valid data, but still submitted info
 // End of submit information
}
if (!$submit OR ($submit AND $error))
{


 if ($siteid)
 {
 		$result = mysql_query ("select * from $ads_tbl,$cat_tbl where siteid = $siteid AND sitecatid=catid"); 
 						$row = mysql_fetch_array($result);
        		$siteid = $row["siteid"];
						
        		$sitetitle = $row["sitetitle"];
        		$sitedescription = $row["sitedescription"];
        		$siteurl = $row["siteurl"];
        		$sitedate = $row["sitedate"];
        		$sitecatid = $row["sitecatid"];
						$catid = $sitecatid;
        		$sitehits = $row["sitehits"];
        		$sitevotes = $row["sitevotes"];
        		$custom_field_1 = $row["custom_field_1"];
        		$custom_field_2 = $row["custom_field_2"];
        		$custom_field_3 = $row["custom_field_3"];
        		$custom_field_4 = $row["custom_field_4"];
        		$custom_field_5 = $row["custom_field_5"];
        		$custom_field_6 = $row["custom_field_6"];
        		$custom_field_7 = $row["custom_field_7"];
        		$custom_field_8 = $row["custom_field_8"];
						$cattpl = $row["cattpl"];
						
						
						while ($counter < 15)
						{
						 $counter = $counter + 1; 
						 $fieldnumber = "f" . $counter;
						 $fieldid[$counter] = $row["$fieldnumber"];
						}
						
 }
 
?>
<form method="post" action="<?php echo $PHP_SELF?>">
<input type="hidden" name="siteid" value="<? echo $siteid ?>">
<input type="hidden" name="catid" value="<? echo $catid ?>">
<table border="0" cellpadding="1" cellspacing="1" width="100%">
  <tr>
    <td width="50%" valign="top"><font face="Verdana" size="1"><? echo $title ?></td>
    <td width="50%" valign="top"><font face=Arial,Helvetica>
<input type="text" name="sitetitle" size="29" maxlength="29" class="tekstfelt" value="<?php echo $sitetitle ?>">


      </font>

    </td>
  </tr>
  
  
  

    <tr>
    <td width="50%" valign="top"><font face="Verdana" size="1"><? echo $description ?></td>
    <td width="50%" valign="top"><font face=Arial,Helvetica><textarea rows="4" name="sitedescription" cols="28"><?php echo $sitedescription ?></textarea>


      </font>

    </td>
  </tr>


      <tr>
    <font face=Arial,Helvetica>
<td width="50%" valign="top"><font face="Verdana" size="1"><?php echo $category ?></td>
<td width="50%" valign="top"><font face=Arial,Helvetica>
<? 
include("dropaddad.php");
?>


      </font>

</td>


      </font>

  </tr>

<?


if ($custom_field_1_text)
{
  print("<tr>");
  print("<tr>");
  print("<td width=\"50%\" valign=\"top\"><font face='Verdana' size='1'>$custom_field_1_text</td>");
  print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  print("<input type=\"text\" name=\"$field1\" size=\"29\" class='tekstfelt' value=\"$custom_field_1\">");
  print("</font>");
  print("</td>");
  print("</tr>");
}
?>

<?
// If we have defined extra fields in config, print them...
if ($custom_field_2_text)
{
  print("<tr>");
  print("<tr>");
  print("<td width=\"50%\" valign=\"top\"><font face='Verdana' size='1'>$custom_field_2_text</td>");
  print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  print("<input type=\"text\" name=\"$field2\" size=\"29\" class='tekstfelt' value=\"$custom_field_2\">");
  print("</font>");
  print("</td>");
  print("</tr>");
}
?>

<?
// If we have defined extra fields in config, print them...
if ($custom_field_3_text)
{
  print("<tr>");
  print("<tr>");
  print("<td width=\"50%\" valign=\"top\"><font face='Verdana' size='1'>$custom_field_3_text</td>");
  print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  print("<input type=\"text\" name=\"$field3\" size=\"29\" class='tekstfelt' value=\"$custom_field_3\">");
  print("</font>");
  print("</td>");
  print("</tr>");
}
?>

<?
// If we have defined extra fields in config, print them...
if ($custom_field_4_text)
{
  print("<tr>");
  print("<tr>");
  print("<td width=\"50%\" valign=\"top\"><font face='Verdana' size='1'>$custom_field_4_text</td>");
  print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  print("<input type=\"text\" name=\"$field4\" size=\"29\" class='tekstfelt' value=\"$custom_field_4\">");
  print("</font>");
  print("</td>");
  print("</tr>");
}
?>

<?
// If we have defined extra fields in config, print them...
if ($custom_field_5_text)
{
  print("<tr>");
  print("<tr>");
  print("<td width=\"50%\" valign=\"top\"><font face='Verdana' size='1'>$custom_field_5_text</td>");
  print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  print("<input type=\"text\" name=\"$field5\" size=\"29\" class='tekstfelt' value=\"$custom_field_5\">");
  print("</font>");
  print("</td>");
  print("</tr>");
}
?>

<?
// If we have defined extra fields in config, print them...
if ($custom_field_6_text)
{
  print("<tr>");
  print("<tr>");
  print("<td width=\"50%\" valign=\"top\"><font face='Verdana' size='1'>$custom_field_6_text</td>");
  print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  print("<input type=\"text\" name=\"$field6\" size=\"29\" class='tekstfelt' value=\"$custom_field_6\">");
  print("</font>");
  print("</td>");
  print("</tr>");
}
?>

<?
// If we have defined extra fields in config, print them...
if ($custom_field_7_text)
{
  print("<tr>");
  print("<tr>");
  print("<td width=\"50%\" valign=\"top\"><font face='Verdana' size='1'>$custom_field_7_text</td>");
  print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  print("<input type=\"text\" name=\"$field7\" size=\"29\" class='tekstfelt' value=\"$custom_field_7\">");
  print("</font>");
  print("</td>");
  print("</tr>");
}
?>

<?
// If we have defined extra fields in config, print them...
if ($custom_field_8_text)
{
  print("<tr>");
  print("<tr>");
  print("<td width=\"50%\" valign=\"top\"><font face='Verdana' size='1'>$custom_field_8_text</td>");
  print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  print("<input type=\"text\" name=\"$field8\" size=\"29\" class='tekstfelt' value=\"$custom_field_8\">");
  print("</font>");
  print("</td>");
  print("</tr>");
}

$result_1 = mysql_query ("select cattpl from $cat_tbl where catid = '$catid'"); 
$row_cat = mysql_fetch_array($result_1);
$cattpl_cat = $row_cat["cattpl"];

$string = "select * from template where name = '$cattpl_cat'";
$result = mysql_query ($string);
$row = mysql_fetch_array($result); 

while ($field < 15)
{
 
 $field = $field + 1;
 $fieldname = "f" . $field;
 $tmpfield1 = "f" . $field . "_caption";
 $tmpfield2 = "f" . $field . "_type";
 $tmpfield3 = "f" . $field . "_mandatory";
 $tmpfield4 = "f" . $field . "_length";
 $tmpfield5 = "f" . $field . "_filename";
 
 $caption = $row["$tmpfield1"];
 $type = $row["$tmpfield2"];
 $mandatory = $row["$tmpfield3"];
 $length = $row["$tmpfield4"];
 $filen = $row["$tmpfield5"];
 print "<input type='hidden' name='$tmpfield3' value='$mandatory'>";

 if ($caption <> '')
 {
 print("<tr>");
 print("<tr>");
 print("<td width=\"50%\" valign=\"top\"><font face='Verdana' size='1'>$caption</td>");
 print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
 if ($type == 'Option')
 {
	$options = file("options/$filen");
	$num_options =  count($options);
	for ($i=0; $i<$num_options; $i++)
	{			 	 
		
		print "<input type='radio' value='$options[$i]' name='$fieldname'";
		if (trim($fieldid[$field]) == trim($options[$i])) { print " checked";  } 
		print ">$options[$i]";
		print "&nbsp;&nbsp;&nbsp;";		
	}
 }
 if ($type == 'Text')
 {
 	print("<input type=\"text\" name=\"$fieldname\" size=\"$length\" maxlength=\"$length\" class='tekstfelt' value=\"$fieldid[$field]\">");
 }
 
 if ($type == 'Textarea')
 {
 	$cols = $length - 1;
 	print("<textarea rows=\"4\" cols=\"$cols\" name=\"$fieldname\" maxlength=\"$length\" class='tekstfelt'\">$fieldid[$field]</textarea>");
 }
 
 
 if ($type == 'Checkbox')
 {
 	$options = file("options/$filen");
	$num_options =  count($options);
	for ($i=0; $i<$num_options; $i++)
	{			 	 
		
		print "<input type='checkbox' value='$options[$i]' name='$fieldname'";
		if (trim($fieldid[$field]) == trim($options[$i])) { print " checked";  } 
		print ">$options[$i]";
		print "&nbsp;&nbsp;&nbsp;";		
	}
 }
 
 
 
 if ($type == 'Dropdown')
 {
  $options = file("options/$filen");
	$num_options =  count($options);

	print "<select size='1' name='$fieldname'>";
	print "<option selected>$options[$i]";				 
	for ($i=0; $i<$num_options; $i++)
	{			 	 
		print "<option value='$options[$i]' ";
		
		if ($age == $options[$i])
		{
			print "selected";
		}
		
		print ">$options[$i]</option>";
	}
	print "</select>&nbsp;&nbsp;&nbsp;";
	
	
	
 }
 
 
  
 
 print("</font>");
 print("</td>");
 print("</tr>");
 $caption1 = '';
 }
}


?>
<tr><td></td>
</tr>

<tr>
<td>
</td>
<td>
<?
print("<input type='submit' name='submit' class='tekstfelt' value='$submit_button'><p>");
print("</form>");
?>
</td>
</tr>
</table> 
<?
}
?>      
</td></tr></table>
<?

include_once("config/footer.inc.php"); ?>