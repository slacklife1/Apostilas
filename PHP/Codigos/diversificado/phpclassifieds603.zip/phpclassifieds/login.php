<?
session_start( );

require("config/header.inc.php");
require("config/config.inc.php");
if (!$special_mode)
{ print("$menu_ordinary<p>"); }
print("<h2>$name_of_site</h2>");
$fix2 = 1;
?>


<p>
<form method="post" action="member.php">

<table>
<tr>
		<td>
				<font class='text'><? echo $userid_text ?>
	  </td>
		<td>
				<input type="text" class="tekstfelt" name="userid" value="<? echo $userid ?>">
		</td>
</tr>
<tr>
		<td>
				<font class='text'><? echo $add_user_pass ?>
		</td>
		<td>
				<input type="password" class="tekstfelt" name="pass" value="<? echo $pass ?>"><br>
				
		</td>
</tr>
<tr>
		<td colspan=2>
				<input type="submit" value="Login">
		</td>
</tr>
</table>

<font class='text'>
<!--
<p><font size="1" face="Verdana"><input type="checkbox" name="husk_meg" value="1" checked>Husk
brukernavn/passord (hvis du er p� offentlig sted hvor mange personer bruker
samme maskin, fjern avmerkingen).
-->
</form>
<a href="add_user.php"><? echo $la_add_user_session ?></a><br>
<a href="remove.php"><? echo $la_remove_session ?></a>

<p>


<p><br><p><br><p>
<font class='text'><p><? echo $la_forgotten_password ?></font>

<p>
<form method="post" action="member_login.php">
<font class='text'><? echo $add_user_email ?> : <br><input type="text" name="ep" class="tekstfelt"><br>
<input type="submit" value="Send">
</form>

<?

if ($ep)
{
require("config/config.inc.php");
$sql_select = "select pass, email, userid from $usr_tbl where email = '$ep'";
$result = mysql_query ($sql_select);

  $antall =  mysql_num_rows($result);

if ($antall > 5)
{
	print ("<font class='text' color='red'>$la_to_many_hits</font>");
}

else
{

 
while ($row = mysql_fetch_array($result))
        {


        $userid = $row["userid"];
        $pass = $row["pass"];
        $email = $row["email"];
	$sisteid = $row["userid"];
require("config/config.inc.php");
// setup variables

		// setup variables
		$sendto = "$email";
		$from = "$from_adress";
		$subject = "$subjectfield_email";
		$message = "$messagefield_email";



		$headers = "From: $from\r\n";
		// send e-mail
		mail($sendto, $subject, $message, $headers);

print("<font class='text'>$la_email_forgotten_password<br></font>");

	}


}
}
require("config/footer.inc.php");
?>