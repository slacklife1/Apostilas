<?
session_start();
include_once("config/header.inc.php");
include_once("config/config.inc.php");
include_once("functions.php");
if (!$special_mode)
{ print("$menu_ordinary<p>"); }
print("<h2>$name_of_site</h2>");
check_valid_user();
print "<table border='1' cellpadding='2' width='100%' bgcolor='#DDDDDD' bordercolordark='#FFFFFF'>";
print "<tr>";
print "<td><font face='Verdana' size='1'><b>$la_admmenu</b></font></td>";
print "<td>&nbsp;</td>";
print "<td align='right'><font face='Verdana' size='1'>$la_logged_in: $valid_user</font></td>";
print "</tr>";
print "<tr>";
print "<td><a href='member.php'><font face='Verdana' size='1'><b>$la_admin_frontpage</b></font></a></td>";
print "<td><a href='change.php'><font face='Verdana' size='1'><b>$change_user</b></font></a></td>";
print "<td><a href='pass.php'><font face='Verdana' size='1'><b>$la_change_pass</b></font></a></td>";
print "</tr>";
print "</table>";
if ($submit)
{
 	 					$sql_update = "update $usr_tbl set usr_1='$usr_1',usr_2='$usr_2',usr_3='$usr_3',usr_4='$usr_4',usr_5='$usr_5',hide_email='$hide_email',emelding='$emelding' where email = '$valid_user'";
						$result = mysql_query($sql_update);
						//print "$sql_update";
}



$result = mysql_query ("select * from $usr_tbl where email = '$valid_user'");
$row = mysql_fetch_array($result);
$userid = $row["email"];
$name = $row["name"];
$email = $row["email"];
$registered  = $row["registered"];
$num_ads = $row["num_ads"];
$hide_email = $row["hide_email"];
$emelding = $row["emelding"];
$usr_1 = $row["usr_1"];
$usr_2 = $row["usr_2"];
$usr_3 = $row["usr_3"];
$usr_4 = $row["usr_4"];
$usr_5t = $row["usr_5"];
?>

<form method=post action="change.php">
 <table width="100%" cellspacing="0">
	 <?
	 if ($usr_1_text)
	 {
   	print("<tr>");
		print("<tr>");
  	print("<td width=\"50%\" valign=\"top\"><font class='text'>$usr_1_text</td>");
  	print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  	print("<input type=\"text\" name=\"usr_1\" size=\"29\" class='tekstfelt' value=\"$usr_1\">");
  	print("</font>");
  	print("</td>");
  	print("</tr>");
	 }
		?>
		
	 <?
	 if ($usr_2_text)
	 {
   	print("<tr>");
		print("<tr>");
  	print("<td width=\"50%\" valign=\"top\"><font class='text'>$usr_2_text</td>");
  	print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  	print("<input type=\"text\" name=\"usr_2\" size=\"29\" class='tekstfelt' value=\"$usr_2\">");
  	print("</font>");
  	print("</td>");
  	print("</tr>");
	 }
		?>
		
		<?
	 if ($usr_3_text)
	 {
   	print("<tr>");
		print("<tr>");
  	print("<td width=\"50%\" valign=\"top\"><font class='text'>$usr_3_text</td>");
  	print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  	print("<input type=\"text\" name=\"usr_3\" size=\"29\" class='tekstfelt' value=\"$usr_3\">");
  	print("</font>");
  	print("</td>");
  	print("</tr>");
	 }
		?>
		
		<?
	 if ($usr_4_text)
	 {
   	print("<tr>");
		print("<tr>");
  	print("<td width=\"50%\" valign=\"top\"><font class='text'>$usr_4_text</td>");
  	print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  	print("<input type=\"text\" name=\"usr_4\" size=\"29\" class='tekstfelt' value=\"$usr_4\">");
  	print("</font>");
  	print("</td>");
  	print("</tr>");
	 }
		?>
		
		<?
	 if ($usr_5_text)
	 {
   	print("<tr>");
		print("<tr>");
  	print("<td width=\"50%\" valign=\"top\"><font class='text'>$usr_5_text</td>");
  	print("<td width=\"50%\" valign=\"top\"><font face=Arial,Helvetica>");
  	print("<input type=\"text\" name=\"usr_5\" size=\"29\" class='tekstfelt' value=\"$usr_5\">");
  	print("</font>");
  	print("</td>");
  	print("</tr>");
	 }
		?>
	 
	 
	 	 <td valign=top><font class='text'><? echo $la_news ?></font></td>
	 	 <td><font class='text'><input type="checkbox" name="emelding" value="1"><? echo $la_no_email_please ?></font><br>
		 <font class='text'><input type="checkbox" name="hide_email" value="1"><? echo $la_hide_email ?></font></td>
	 </tr>
	 <tr>
     <td colspan=2 align=left>
     <input type=submit name=submit value="<? echo $la_change_info ?>"></td></tr>
 </table></form>
<?
include_once("config/footer.inc.php");
?>
