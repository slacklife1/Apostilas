<?
session_start( );

require("config/header.inc.php");
require("config/config.inc.php");
?>

<?
if (!$special_mode)
{ print("$menu_ordinary<p>"); }
print("<h2>$name_of_site</h2>");

srand ((double) microtime() * 1000000);
$new_pass = rand(900,9000);

$result = mysql_query ("update $usr_tbl set password_enc = password('$new_pass') where email = '$email'");
if ($result)
{
 	 echo $la_forgot;
	 $sendto = $email;
	 $from = $from_adress;
	 $subject = $la_forgot_mail_subject;
	 $message = "$la_forgot_mail_msg1 $new_pass. $la_forgot_mail_msg2 $la_forgot_mail_msg3";

	 $headers = "From: $from\r\n";
	 // send e-mail
	 mail($sendto, $subject, $message, $headers);

	 
}
else
{
 print "Email address not found!";
}



require("config/footer.inc.php");
?>