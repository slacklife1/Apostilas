<?
session_start( );

require("config/header.inc.php");
require("config/config.inc.php");
if (!$special_mode)
{ print("$menu_ordinary<p>"); }
print("<h2>$name_of_site</h2>");
$fix2 = 1;

if ($submit)
{
 	 
	 
	 $sql = "select * from $usr_tbl where userid = '$username' AND pass = '$password'";
	 $result_check = mysql_query ($sql);
	 $num_check =  mysql_num_rows($result_check);
	 $old = 1;
	 
	 // Check to see if we use old login, and if they exist there
	 if (!$num_check)
	 {
	 		 	 $old = 0;
				 $sql = "select * from $usr_tbl where email = '$username' AND password_enc = password('$password')";
				
				 $result_check = mysql_query ($sql);
				 $num_check =  mysql_num_rows($result_check);
	 }
	 
	 if ($num_check)
	 { 
	 	 		 $valid_user = $username;	 
				 session_register("valid_user");
				 echo $la_login_success;
				 echo $valid_user;
				 echo $la_login_success2;
 				 echo "<Script language=\"javascript\">window.location=\"member.php\"</script>"; 
	 }
	 else
	 {
	 		 	 // User with that username/id and password not found
				 echo $la_not_authorized_member;
	 }
}

if ($logout)
{
 	 session_unregister("valid_user");
	 session_destroy();
}
?>


<p>
<form method="post" action="member_login.php">

<table>
<tr>
		<td>
				<font class='text'><? echo $userid_text ?>
	  </td>
		<td>
				<input type="text" class="tekstfelt" name="username" value="<? echo $username ?>">
		</td>
</tr>
<tr>
		<td>
				<font class='text'><? echo $add_user_pass ?>
		</td>
		<td>
				<input type="password" class="tekstfelt" name="password" value="<? echo $password ?>"><br>
				
		</td>
</tr>
<tr>
		<td colspan=2>
				<input type="submit" name="submit" value="Login">
		</td>
</tr>
</table>

<font class='text'>
</form>
<a href="register.php"><? echo $la_add_user_session ?></a><br>


<p>


<p><br><p><br><p>
<font class='text'><p><? echo $la_forgotten_password ?></font>

<p>
<form method="post" action="forgot.php">
<font class='text'><? echo $add_user_email ?> : <br><input type="text" name="email" class="tekstfelt"><br>
<input type="submit" value="Send">
</form>

<?


require("config/footer.inc.php");
?>