<?php

/*************************************************************************\

  PHP 'ini' file generator
  Copyright (C) 2001 - Paul Gareau <paul@xhawk.net>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

\*************************************************************************/

$app_name = 'iniread';
$ary_file_name[] = 'contest.php';
$ary_file_name[] = 'theme.inc.php';

// save variables to file
////////////////////////////

if($form_submit)
{
    $fp = @fopen($file_name, 'w')
          or die("Could not open <b>$file_name</b> for writing!");

    fwrite($fp, "<?\n\n");
    fwrite($fp, stripslashes($other)."\n");
    $num_vars = count($var_name);

    for($line=0; $line<$num_vars; $line++)
    {
        fwrite($fp, $var_name[$line]."\t= ");

        $var_val[$line] = ereg_replace("\r\n", " ", $var_val[$line]);

        if(! is_numeric($var_val[$line]) && ereg("^[^\"\']{1,1}|^$", $var_val[$line]))
            fwrite($fp, "\"".stripslashes($var_val[$line])."\";");
        else
            fwrite($fp, stripslashes($var_val[$line]).";");

        if($var_cmt[$line])
            fwrite($fp, "\t//".str_replace(";", "", stripslashes($var_cmt[$line])));

        fwrite($fp, "\n");
    }
    fwrite($fp, "\n?>");
    fclose($fp);
    $msg = "Config file <b>$file_name</b> written!";
}

echo "<html>\n";
echo "<head><title>$app_name</title></head>\n";
echo "<style>\n";
echo "td    {font-family: tahoma; font-size: 13}\n";
echo "body  {font-family: tahoma}\n";
echo "input {font-family: courier}\n";
echo "</style>\n";
echo "<body><h1>$app_name</h1>\n";
echo $msg;

if($file_name)
{
    // read variables + data into arrays
    ///////////////////////////////////////

    $ary_file = file($file_name);
    $num_lines = count($ary_file);
    $var_line = 0;

    for($file_line=0; $file_line<$num_lines; $file_line++)
    {
        $line_content = $ary_file[$file_line];

        if(ereg('^\$.+;', $line_content))
        {
            $eq_pos = strpos($line_content, '=');
            $sc_pos = strrpos($line_content, ';');
            $cmt_pos = strpos($line_content, '//', $sc_pos);
            $ary_parsed[$var_line][0] = trim(substr($line_content, 0, $eq_pos));
            $ary_parsed[$var_line][1] = trim(substr($line_content, $eq_pos+1, $sc_pos-$eq_pos-1));

            if($cmt_pos)
                $ary_parsed[$var_line][2] = trim(substr($line_content, $cmt_pos+2, strlen($line_content)-$cmt_pos));

            $var_line++;
        }
        elseif(ereg("[^(\n|<\?|\?>)]", $line_content))
            $ary_other[] = $line_content;
    }

    // print edit form
    /////////////////////

    $num_vars = count($ary_parsed);
    $num_xtra = count($ary_other);

    echo "<form action='$PHP_SELF' method='POST'>\n";
    echo "<input type='hidden' name='file_name' value='$file_name'>\n";
    echo "<table border=0 cellpadding=2 cellspacing=2>\n";
    echo "<tr bgcolor='#BBCCDD'>\n<td><b>Variable</b></td><td><b>Value</b></td><td><b>Comment</b></td></tr>\n";

    for($row=0; $row<$num_vars; $row++)
    {
        $var_orig = $ary_parsed[$row][0];
        $var_name = $ary_parsed[$row][0];
        $var_name = str_replace("_", " ", ucfirst(str_replace("\$", "", $ary_parsed[$row][0])));
        $var_val = $ary_parsed[$row][1];
        $use_textarea = (! is_numeric($var_val)) ? 1 : 0;
        $var_cmt = $ary_parsed[$row][2];
        $bgcolor = ($row % 2) ? '#EEEEEE' : '#DDDDDD';

        echo "<tr bgcolor='$bgcolor'><td valign='top'>$var_name<input type='hidden' name='var_name[]' value='$var_orig'></td><td valign='top'>\n";

        if($use_textarea)
            echo "<textarea rows=4 cols=30 name='var_val[]' wrap='virtual'>$var_val</textarea>\n";
        else
            echo "<input type='text' size=30 name='var_val[]' value='$var_val'>\n";

        echo "</td><td valign='top'><input type='text' size=40 name='var_cmt[]' value='$var_cmt'></td></tr>\n";
    }

    // print non variables in a text area
    ////////////////////////////////////////

    if($num_xtra)
    {
        echo "<tr bgcolor='#DDDDDD'><td colspan=3>";
        echo "<textarea rows=5 cols=80 name='other'  style='width: 100%' wrap='virtual'>";

        for($row=0; $row<$num_xtra; $row++)
            echo $ary_other[$row];

        echo "</textarea></td></tr>";
    }

    echo "<tr bgcolor='#CCCCCC' colspan=3><td colspan=3>\n";
    echo "<input type='submit' name='form_submit' value='   Save   '>\n";
    echo "<input type='reset' value='  Reset  '>\n";
    echo "</td></tr></table></form>\n";
}

// print drop down file list
///////////////////////////////

$num_files = count($ary_file_name);
echo "Select a file:<br>";
echo "<form action='$PHP_SELF' method='POST'>\n<select name='file_name'>\n";

for($file=0; $file<$num_files; $file++)
    echo "<option value='$ary_file_name[$file]'>$ary_file_name[$file]\n";

echo "</select><input type='submit' value='Open'></form>\n";
echo "<br></body></html>\n";

?>
