<?

function check_valid_user()
// see if somebody is logged in and notify them if not
{
  global $valid_user;
  if (session_is_registered("valid_user"))
  {
      //echo "Logged in as $valid_user.";
      echo "<br>";
  }
  else
  {
     // they are not logged in 
     echo "You are not logged in. <a href='member_login.php'>Login</a><br>";
		 exit;
  }  
}		
		
function find ($year, $month, $day, $numdays)
{
 		global $expire_date;
		global $forskjell;

	 	$dagens_dato = mktime (date("H"),date("i"),date("s"),$mn,$dy,$yr);
		$dagens_dato_konv = date ("d.m.Y", mktime(date("H"),date("i"),date("s"),date("m"),date("d"),date("Y")) );
		$slettedato = mktime (date("H"),date("i"),date("s"),$month,$day+$numdays,$year);
		$slettedato_konv = date ("d.m.Y", mktime(date("H"),date("i"),date("s"),$month,$day+$numdays,$year) );

		$forskjell_1 = ($slettedato) - ($dagens_dato);
		$forskjell = $forskjell_1 /86400;
		$expire_date = $slettedato_konv; 
		
		//return $forskjell;
		return $expire_date;
}		

function ads_latest_sevend_days()
{
 		// Make a mysql timestamp to compare
		$y = date("Y");
		$m = date("m");
		$d = date("d");
		$mysql_timestamp_date = "$y$m$d";
			
} 



function delete_user($email)
{

			global $userid;
			global $usr_tbl;
			global $ads_tbl;
			global $pic_tbl;
			global $debug;
			global $la_users_deleted;
			
			$sql_links = "select * from $ads_tbl where ad_username = '$email'";
			if ($debug) { print("$sql_links"); }
			$sql_result = mysql_query ($sql_links);
			
			
              		while ($row = mysql_fetch_array($sql_result))
        		{
  
                  		
                  		$picture = $row["picture"];
            			$img_stored = $row["img_stored"];
            			$siteid = $row["siteid"];
				
				if ($img_stored <> 0)
				{ 
					if (file_exists("images/$img_stored"))
					{
			 	 		unlink ("images/$img_stored");
						if ($debug) { print("<p>Image file $img_stored deleted!</p>"); } 
						//print "<p>Image $img_stored deleted<p>";
					}
				}
			
				if ($picture <> 0)
				{
			  		$r4 = "delete from $pic_tbl where pictures_siteid=$siteid";
					$result4=MYSQL_QUERY($r4);
					if ($debug) { print ("<p>Pictures attached to ad $siteid deleted from MySql with
							 mysql query: $r4</p>"); }
				}
				
				print "Deleted ";		
				$r6 = "delete from $ads_tbl where siteid=$siteid";
				
				$result6=MYSQL_QUERY($r6);
				
				if ($debug) { print("<p>Deleted $siteid with sql: $r6</p>"); };
							
			}
			
			$result=MYSQL_QUERY("delete from $usr_tbl where email='$email'");

			
			if ($result)
			{
			print("<tr><td><font face='Verdana' size='1'>$la_users_deleted</font></td></tr>");
			}
			else
			{
			print("<tr><td>Error. Could not delete.</td></tr>");
			}
			
}

function delete_ads($adid)
{

			global $userid;
			global $usr_tbl;
			global $ads_tbl;
			global $pic_tbl;
			global $debug;
			global $la_ads_deleted;
			global $full_path_to_public_program;
			
			
			$sql_links = "select * from $ads_tbl where siteid = $adid";
			if ($debug) { print("$sql_links");  }
			$sql_result = mysql_query ($sql_links);
			      
        		while ($row = mysql_fetch_array($sql_result))
        		{
  			
                 	$picture = $row["picture"];
									$img_stored = $row["img_stored"];
									$picture = $row["picture"];
									print "$img_stored";
					 }
			
			if ($img_stored <> '')
			{ 
					
				if (file_exists("$full_path_to_public_program/images/$img_stored"))
				{
			 	 	 
			 	 	 unlink ("$full_path_to_public_program/images/$img_stored");
					 if ($debug) { 
					 print("<p>Image deleted (file): $img_stored</p>"); }
					 print "Deleted $img_stored<br>";
				}
			}
			
			if ($picture <> 0)
			{
			  $result4=MYSQL_QUERY("delete from $pic_tbl where id=$picture");
				if ($result4)
				{ if ($debug) { print("<p>Image deleted from mysql: $picture</p>"); }}
			}
			
			
			$result2=MYSQL_QUERY("delete from $ads_tbl where siteid = $adid");
			if ($result2)
				{ print("<p>&nbsp;$la_ads_deleted: $adid</p>"); }
			
}
?>		