<?

//####################################################
// CATCOL.PHP
// This file is responsible to displaying catagories
// and sub-dirs.
//####################################################

if ($catname)
{
 	 print("<h2>$catname</h2>");
}

if ($kid==0) { $where_clause = "where catfatherid = 0"; }
else { $where_clause = "where catfatherid=$kid";  }
				

function column()
{				
				print("<table border='0' width='100%'><tr><td valign=top>");
 				global $cat_tbl;
				global $where_clause;
				global $categories_per_column;
				global $file;
				global $ccatid;
				global $cantall;
				global $frontpage; 


				$sql = "select * from $cat_tbl $where_clause order by catname";
				$result = mysql_query ("$sql");
				$catcounter =  mysql_num_rows($result);

				for ($i=0; $i<$catcounter; $i++)
	 			{   
   	       				$row = mysql_fetch_array($result);
           				$catid = $row["catid"];
           				$catfatherid = $row["catfatherid"];
           				$catname = $row["catname"];
           				$catdescription = $row["catdescription"];
           				$total = $row["total"];
           				$catimage = $row["catimage"];
					$catno = $catno + 1;
				 
					
					$filename = "templates/cat.html";
					$fd = fopen ($filename, "r");
					$file= fread ($fd, filesize ($filename));
					$file = str_replace("{IMAGE}", "<img src=\"catimages/$catimage\">", $file);
					$file = str_replace("{CATEGORYNAME}", "$catname", $file);
					$file = str_replace("{TOTAL_ADS}", "$total", $file);
					$catname = urlencode($catname);
					//$file = str_replace("{URL}", "<a href='index.php?kid=$catid&catname=$catname'>", $file);
   					// Hack
   					if ($frontpage == '2')      { $file = str_replace("{URL}", "<a href='add_ad.php?catid=$catid&catfatherid=$catfatherid'>", $file); }
 					else  { $file = str_replace("{URL}", "<a href='index.php?kid=$catid&catname=$catname'>", $file); }
					$file = str_replace("{/URL}", "</a>", $file);
					if (!$frontpage) { $file = str_replace("{CATDESCRIPTION}", "$catdescription", $file); }
					else { $file = str_replace("{CATDESCRIPTION}", " ", $file); } 
					print($file);
					
					if ($catno == $categories_per_column)
					{
								print("</td><td valign=top>");
								$catno = 0;
					}		
	
	 	 		}		
				print("</td></tr></table>");

}									
column(); 

?>
