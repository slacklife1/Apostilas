<?
session_start();
require("config/header.inc.php");
require("config/config.inc.php");
require("functions.php");
if (!$special_mode)
{ print("$menu_ordinary<p>"); }
print("<h2>$name_of_site</h2>");
print "<font class='text'>$la_member_area_welcome</font><p>";
print "<table border='1' cellpadding='2' width='100%' bgcolor='#DDDDDD' bordercolordark='#FFFFFF'>";
print "<tr>";
print "<td><font face='Verdana' size='1'><b>$la_admmenu</b></font></td>";
print "<td>&nbsp;</td>";
print "<td align='right'><font face='Verdana' size='1'>$la_logged_in: $valid_user</font></td>";
print "</tr>";
print "<tr>";
print "<td><a href='member.php'><font face='Verdana' size='1'><b>$la_admin_frontpage</b></font></a></td>";
print "<td><a href='change.php'><font face='Verdana' size='1'><b>$change_user</b></font></a></td>";
print "<td><a href='pass.php'><font face='Verdana' size='1'><b>$la_change_pass</b></font></a></td>";
print "</tr>";
print "</table>";
?>


<?

check_valid_user();
?>

<form method="post" action="pass.php">

<table>
<tr>
		<td>
				<font class='text'><? echo $la_new_pass1 ?>
	  </td>
		<td>
				<input type="text" class="tekstfelt" name="n_pass1">
		</td>
</tr>

<tr>
		<td>
				<font class='text'><? echo $la_new_pass2 ?>
	  </td>
		<td>
				<input type="text" class="tekstfelt" name="n_pass2">
		</td>
</tr>

<tr>
		<td colspan=2>
				<font class='text' class="tekstfelt"><button type="submit" name="submit"><? echo $la_change_pass ?></button>
	  </td>

</tr>

</table>

<?

if ($submit)
{
 	 if ($n_pass1 == $n_pass2)
	 {
	 		$result = mysql_query ("update $usr_tbl set password_enc = password('$n_pass1') where email = '$valid_user'");
			if ($result)
			{
 	 		 	 print $la_pass_success;
	 			 $sendto = "$email";
	 			 $from = "$from_adress";
	 			 $subject = "$subjectfield_email";
	 			 $message = "$messagefield_email $new_pass";

				 $headers = "From: $from\r\n";
	 			 // send e-mail
	 			 mail($sendto, $subject, $message, $headers);
			}
	 }
	 else
	 {
	 		 print "Passwords do not match !";
	 }
}
require("config/footer.inc.php");
?>