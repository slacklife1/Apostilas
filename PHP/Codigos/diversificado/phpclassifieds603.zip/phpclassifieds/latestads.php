<?
require("config/header.inc.php");
require("config/config.inc.php");
print("$menu_ordinary<p>");
print("<h2>$name_of_site</h2>");
$latestmode = 1;
$kid = '1';
require("links.php");
require("config/footer.inc.php");
?>