<?
if (file_exists("config/config.inc.php")) 
{ 
	include("config/config.inc.php");
	
	
	$sql_categories = mysql_query("select * from $cat_tbl where catfatherid <> 0"); 
	$num_subcats = mysql_num_rows($sql_categories); 
	if ($num_subcats == 0)
	{
		print("<font color=red><b>Notice to admin:</b><br>You have selected (its default) to have an advance structure that requires Main categories And Sub categories. In a such environment, you must create a subdir below the main dir you see on your frontpage in order to post ads ! If you would like your users to add their ads in one of the Main dir that you see on the frontpage, you MUST select a Simple structure from admin area. You can not add ads before you have created a subdir from the admin area !</font>");
	}
	
}
	
?>