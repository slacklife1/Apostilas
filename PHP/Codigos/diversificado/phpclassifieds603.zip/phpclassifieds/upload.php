<?
require("config.php");
require("header.php");

print("<p><h2>$name_of_site</h2>");
print "<table border='1' cellpadding='2' width='100%' bgcolor='#DDDDDD' bordercolordark='#FFFFFF'>";
print "<tr>";
print "<td><font face='Verdana' size='1'><b>Administration menu</b></font></td>";
print "<td>&nbsp;</td>";
print "<td align='right'><font face='Verdana' size='1'>Logged in as: $valid_user</font></td>";
print "</tr>";
print "<tr>";
print "<td><a href='member.php'><font face='Verdana' size='1'><b>Admin frontpage</b></font></a></td>";
print "<td><a href='change.php'><font face='Verdana' size='1'><b>$change_user</b></font></a></td>";
print "<td><a href='pass.php'><font face='Verdana' size='1'><b>Change password</b></font></a></td>";
print "</tr>";
print "</table>";
print ("<table>");


     if ($form_data_size==0)
     {
         
         echo $la_upload_error1;
         
     }

    elseif ($form_data_size>$piclimit)
    {
         echo $la_upload_error2;
    }





     else
     {

       $data = addslashes(fread(fopen($form_data,  "r"), filesize($form_data)));

       $result=MYSQL_QUERY( "INSERT INTO $pic_tbl (pictures_siteid,bin_data,filename,filesize,filetype) ".
                 "VALUES ('$pictures_siteid','$data','$form_data_name','$form_data_size','$form_data_type')");

       $id = mysql_insert_id();
       $result1=MYSQL_QUERY( "UPDATE $ads_tbl set picture = $id where siteid=$pictures_siteid");
       MYSQL_CLOSE();

    }
?>
<p>
<? echo $la_upload_success ?>
<? print("<p><a href='large_picture.php?id=$id'><img src='get.php?id=$id' width=\"106\" height=\"68\" align=\"left\" alt='Large picture'></a>"); ?>
<p><p><p><p>
</table>

<?
require("footer.php");
?>