<?
session_start();
require("config/header.inc.php");
require("config/config.inc.php");

if (!$special_mode)
{
	print("<p>$menu_ordinary");
}
require ("link_title.php");


if (!$kid AND !$special_mode)
{
 print("<h2>$name_of_site</h2>");
 print("<font size='4'><p>$welcome_message</p></font>");
}

?>
<p>

<?
include("catcol.php");
$frontpage=1; 
include("links.php");

if (!$kid AND $latest)
{
     require ("latest.php");
}

print("<p>");
if ($auto)
{
 include("update.php");
}
require("config/footer.inc.php");


?>

