<?
require("config/config.inc.php");

$result1 = mysql_query("ALTER TABLE $ads_tbl 
ADD f1 VARCHAR (50) ,
ADD f2 VARCHAR (50) ,
ADD f3 VARCHAR (50) ,
ADD f4 VARCHAR (50) ,
ADD f5 VARCHAR (50) ,
ADD f6 VARCHAR (50) ,
ADD f7 VARCHAR (50) ,
ADD f8 VARCHAR (50) ,
ADD f9 VARCHAR (50) ,
ADD f10 VARCHAR (50) ,
ADD f11 VARCHAR (50) ,
ADD f12 VARCHAR (50) ,
ADD f13 VARCHAR (50) ,
ADD f14 VARCHAR (50) ,
ADD f15 VARCHAR (50)
");
// End of ALTER

$result2 = mysql_query("CREATE TABLE template (
   tplid int(11) NOT NULL auto_increment,
   name varchar(50),
   f1_caption varchar(50),
   f1_type varchar(50),
   f1_mandatory char(3),
   f1_length varchar(5),
   f1_filename varchar(50),
   f2_caption varchar(50),
   f2_type varchar(50),
   f2_mandatory char(3),
   f2_length varchar(5),
   f2_filename varchar(50),
   f3_caption varchar(50),
   f3_type varchar(50),
   f3_mandatory char(3),
   f3_length varchar(5),
   f3_filename varchar(50),
   f4_caption varchar(50),
   f4_type varchar(50),
   f4_mandatory char(3),
   f4_length varchar(5),
   f4_filename varchar(50),
   f5_caption varchar(50),
   f5_type varchar(50),
   f5_mandatory char(3),
   f5_length varchar(5),
   f5_filename varchar(50),
   f6_caption varchar(50),
   f6_type varchar(50),
   f6_mandatory char(3),
   f6_length varchar(5),
   f6_filename varchar(50),
   f7_caption varchar(50),
   f7_type varchar(50),
   f7_mandatory char(3),
   f7_length varchar(5),
   f7_filename varchar(50),
   f8_caption varchar(50),
   f8_type varchar(50),
   f8_mandatory char(3),
   f8_length varchar(5),
   f8_filename varchar(50),
   f9_caption varchar(50),
   f9_type varchar(50),
   f9_mandatory char(3),
   f9_length varchar(5),
   f9_filename varchar(50),
   f10_caption varchar(50),
   f10_type varchar(50),
   f10_mandatory char(3),
   f10_length varchar(5),
   f10_filename varchar(50),
   f11_caption varchar(50),
   f11_type varchar(50),
   f11_mandatory char(3),
   f11_length varchar(5),
   f11_filename varchar(50),
   f12_caption varchar(50),
   f12_type varchar(50),
   f12_mandatory char(3),
   f12_length varchar(5),
   f12_filename varchar(50),
   f13_caption varchar(50),
   f13_type varchar(50),
   f13_mandatory char(3),
   f13_length varchar(5),
   f13_filename varchar(50),
   f14_caption varchar(50),
   f14_type varchar(50),
   f14_mandatory char(3),
   f14_length varchar(5),
   f14_filename varchar(50),
   f15_caption varchar(50),
   f15_type varchar(50),
   f15_mandatory char(3),
   f15_length varchar(5),
   f15_filename varchar(50),
   PRIMARY KEY (tplid)
);
 
"); 
// End of result2

$result3 = mysql_query("INSERT INTO template (tplid, name, f1_caption, f1_type, f1_mandatory, f1_length, f2_caption, f2_type, f2_mandatory, f2_length, f3_caption, f3_type, f3_mandatory, f3_length, f4_caption, f4_type, f4_mandatory, f4_length, f5_caption, f5_type, f5_mandatory, f5_length, f6_caption, f6_type, f6_mandatory, f6_length, f7_caption, f7_type, f7_mandatory, f7_length, f8_caption, f8_type, f8_mandatory, f8_length, f9_caption, f9_type, f9_mandatory, f9_length, f10_caption, f10_type, f10_mandatory, f10_length, f11_caption, f11_type, f11_mandatory, f11_length, f12_caption, f12_type, f12_mandatory, f12_length, f13_caption, f13_type, f13_mandatory, f13_length, f14_caption, f14_type, f14_mandatory, f14_length, f15_caption, f15_type, f15_mandatory, f15_length) VALUES ('', '-', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '') ");
// End of result3

$result4 = mysql_query("ALTER TABLE $usr_tbl ADD usr_1 VARCHAR (150) , ADD usr_2 VARCHAR (150) , ADD usr_3 VARCHAR (150) , ADD usr_4 VARCHAR (150) , ADD usr_5 VARCHAR (150)
"); 
// End of result 4 


$result5 = mysql_query("ALTER TABLE $usr_tbl CHANGE userid userid INT (11) not null");
$result6 = mysql_query("ALTER TABLE $usr_tbl DROP PRIMARY KEY");
$result7 = mysql_query("ALTER TABLE $ads_tbl ADD ad_username CHAR (50)"); 
$result8 = mysql_query("ALTER TABLE $usr_tbl CHANGE email email CHAR (50) not null");
$result9 = mysql_query("ALTER TABLE $usr_tbl DROP PRIMARY KEY, ADD PRIMARY KEY(email)");
$result10 =mysql_query("ALTER TABLE $cat_tbl ADD cattpl varchar(50), ADD allowads char(2), ADD catfullname varchar(150)"); 
$result11 = mysql_query("ALTER TABLE $usr_tbl ADD password_enc CHAR (30)"); 

/*
print "Result1: $result1<br>"; 
print "Result2: $result2<br>"; 
print "Result3: $result3<br>"; 
print "Result4: $result4<br>"; 
print "Result5: $result5<br>"; 
print "Result6: $result6<br>"; 
print "Result7: $result7<br>"; 
print "Result8: $result8<br>"; 
print "Result9: $result9<br>"; 
print "Result10: $result10<br>";
print "Result11: $result11<br>";  
*/
?>