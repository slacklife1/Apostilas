<? mysql_connect ("localhost","phpclass603","phpclass603_beta");
mysql_select_db ("phpclass603");

$datab='phpclass603';

$dbusr='phpclass603';

$dbpass='phpclass603_beta';

$dbhost='localhost';

?>