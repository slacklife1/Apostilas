
<SCRIPT LANGUAGE="JavaScript">
<!--
function valid(form) {
  var title_tag = form.sitetitle.value;  
  var sitedescription_tag = form.sitedescription.value;  
	var sitecatid_tag = form.sitecatid.value;  
 	var custom_field_1_tag = parseInt(form.custom_field_1.value);

	if (!title_tag) 
	{
   alert("<? echo $la_error_msg1 ?>");
	 return false;
	}
	if (!sitedescription_tag)
	{
	 alert("<? echo $la_error_msg2 ?>");
	 return false;
	}
	if (sitecatid_tag == 0)
	{
	 alert("<? echo $la_error_msg3 ?>");
	 return false;
	}
	if (!custom_field_1_tag > 0)
	{
	 alert("<? echo $la_error_msg4 ?>");
	 return false;
	}
return true;
}

// -->
</SCRIPT>
