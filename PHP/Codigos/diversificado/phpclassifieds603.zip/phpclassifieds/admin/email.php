<? require("admheader.php"); ?>
<!-- Table menu -->
<table border="1" cellpadding="3" cellspacing="0" width="100%">
<tr>
		<td bgcolor="lightgrey">
				<font color="black" face="Tahoma,Arial,Helvetica" size="2">
				&nbsp; Email all members</font>
		</td>
</tr>
   
<tr bgcolor="white">
		<td width="100%">
				<font face='Verdana' size='1'>
				<?
				if ($submit AND $email_activated)
				{
				 	 $sql_email = "select distinct name,email from $usr_tbl where emelding = 0 AND email <> ''";
					 $result = mysql_query ($sql_email);
					 $num_email =  mysql_num_rows($result);

        while ($row = mysql_fetch_array($result))
        {
				 		$name = $row["name"];
        		$email = $row["email"];
       			$sendto = "$email";
						$from = "$from_adress";
						$subject = "$title_field";
						$message = "$beskjed";
						$headers = "From: $from\r\n";
						// send e-mail
						mail($sendto, $subject, $message, $headers);
						$count = $count +1;
						print ("<font class='text'>$count: <b>$name</b> - <b>$email</b></font><br>");
        }
				?>
				<font class='text'><? echo $la_email_sent_message ?></font>
				<?
				}
				else
				{
				?>
				<form method="post" action="<?php echo $PHP_SELF?>">
				<table border="0" cellspacing="1" width="80%">
				<tr>
    				<td width="100%">
       			<?

							$sql_email = "select distinct name,email from $usr_tbl where emelding = 0 AND email <> ''";
							$result = mysql_query ($sql_email);
							$num_email =  mysql_num_rows($result);
							print("<select size=1 name=members>");
							print("<option selected>See all members</option>");
							while ($row = mysql_fetch_array($result))
        			{
							 			$name = $row["name"];
        						$email = $row["email"];
										print("<option>$name [$email]</option>");
							}
							print("</select>");     
   						
							if (!$email_activated)
							{
							 	 print("<br><font size='1' face='verdana' color='red'>Email-send is not acivated in config. Email 
								 will not be sent.</font>");
							}
							?>    
    
    					<font size="1" face="Verdana">
							<? print("$num_email $la_email_main_msg"); ?></font>
							<p><p>
      				<table border="0" cellspacing="1" width="100%">
        			<tr>
          				<td width="50%" valign="top"><font size="1" face="Verdana"><? echo $lang_email_members_title ?></font></td>
          				<td width="50%" valign="top"><font size="1" face="Verdana"><input type="text" name="title_field" size="42" style="font-size: 8pt; font-family: Verdana"></font></td>
        			</tr>
        			<tr>
          				<td width="50%" valign="top"><font size="1" face="Verdana"><? echo $add_user_email ?></font></td>
          				<td width="50%" valign="top"><font size="1" face="Verdana"><? echo $from_adress ?></font></td>
        			</tr>
        			<tr>
          				<td width="50%" valign="top"><font size="1" face="Verdana"><? echo $lang_email_members_message ?></font></td>
          				<td width="50%" valign="top"><textarea rows="8" name="beskjed" cols="42" style="font-size: 8pt; font-family: Verdana"></textarea></td>
        			</tr>
      				</table>
      				<font size="1" face="Verdana"><input type="submit" value="Submit" name="submit" style="font-size: 8pt; font-family: Verdana"></font>
					</td>
  		</tr>
			</table>
			</form>
			<?
			}
			?>
		</font>
	 </td>
</tr>
</table>
<!-- END Table menu -->
<? require("admfooter.php"); ?>