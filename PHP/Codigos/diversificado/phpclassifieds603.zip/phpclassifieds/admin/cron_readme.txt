To run this program automatically, set up a cron job that runs
this command each day or so...:

lynx -source http://www.yourdomain/update.php > /dev/null 2>&1