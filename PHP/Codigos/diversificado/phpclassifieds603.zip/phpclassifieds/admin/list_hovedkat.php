<select style="FONT-SIZE: 8pt" size="1" name="catid">
                     <option value="0" selected>All categories</option>

<?

require("config.php");
require ($full_path_to_db);

$sql_select = "select * from categories where catfatherid = 0 order by catname";
$result = mysql_query ($sql_select);

while ($row = mysql_fetch_array($result)) {

        $catid = $row["catid"];
        $catfatherid = $row["catfatherid"];
        $catname = $row["catname"];
        $catdescription = $row["catdescription"];
	 
 
print("<option value='$catid'>");
	print("$catname");

print("</option>");



};





?>
</select>
