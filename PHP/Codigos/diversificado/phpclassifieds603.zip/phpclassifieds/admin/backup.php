<?
##########################################################################
## BACKUP.PHP
##########################################################################

require("admheader.php"); 
?>
<!-- Table menu -->
<table border="1" cellpadding="3" cellspacing="0" width="100%">
<tr>
		<td bgcolor="lightgrey">
				<font color="black" face="Tahoma,Arial,Helvetica" size="2">
				&nbsp; Menu</font>
		</td>
</tr>
   
<tr bgcolor="white">
		<td width="100%">
				<font face='Verdana' size='1'>
<?
echo $la_backup;
?>


<? 
$backupdir_perm = fileperms("backup/");
if ($backupdir_perm == 16895) 
{
	print("$la_permissions: <a href='backup.php?backup=1'><b>$la_start_bak</b></a>");
}
else
{
	print("<font color=red><b>$la_perm_error1:</b><br>$la_perm_error2</font>");
}
?>
<?

//------   Backup of config files ---------
if ($backup == 1)
{
 $date = date(d.m.Y);
 if (!file_exists("backup/$date")) 
 {
 		mkdir ("backup/$date", 0777);
 }
 
 if ( copy ("$full_path_to_public_program/config/config.inc.php", "$full_path_to_public_program/admin/backup/$date/config.inc.php") )
{
	chmod ("backup/$date/config.inc.php", 0777); 
	print "<br>Config.inc.php is copied !<br>";
}
else
{
	print "<font color=red>Config.inc.php NOT copied!</font><br>";
}

if ( copy ("$full_path_to_public_program/config/header.inc.php", "$full_path_to_public_program/admin/backup/$date/header.inc.php") )
{
  chmod ("backup/$date/header.inc.php", 0777); 
	print "Header.inc.php is copied!<br>";
}
else
{
	print "<font color=red>Header.inc.php NOT copied!</font><br>";
}

if ( copy ("$full_path_to_public_program/config/footer.inc.php", "$full_path_to_public_program/admin/backup//$date/footer.inc.php") )
{
	chmod ("backup/$date/footer.inc.php", 0777); 
	print "Footer.inc.php is copied!<br>";
}
else
{
	print "<font color=red>Footer.inc.php NOT copied!</font><br>";
}

if ( copy ("$full_path_to_public_program/admin/db.php", "$full_path_to_public_program/admin/backup/$date/db.php") )
{
	chmod ("backup/$date/db.php", 0777); 
	print "Db.php is copied!<br>";
}
else
{
	print "<font color=red>Db.php NOT copied!</font><br>";
}



 
 $backup_cat = "mysqldump --opt -c  -full -h $dbhost  -u $dbusr -p$dbpass $datab $cat_tbl >  backup/$date/$cat_tbl.sql";
 //print "<p>" . $backup_cat . "<p>";
 $exec=passthru($backup_cat, $ret_cat);

 $backup_ads = "mysqldump --opt -c  -full -h $dbhost  -u $dbusr -p$dbpass $datab $ads_tbl >  backup/$date/$ads_tbl.sql";
 //print "<p>" . $backup_ads . "<p>";
 $exec=passthru($backup_ads, $ret_ads);
 
 $backup_usr = "mysqldump --opt -c  -full -h $dbhost  -u $dbusr -p$dbpass $datab $usr_tbl >  backup/$date/$usr_tbl.sql";
 //print "<p>" . $backup_usr . "<p>";
 $exec=passthru($backup_usr, $ret_usr);
 
 $backup_Config = "mysqldump --opt -c  -full -h $dbhost  -u $dbusr -p$dbpass $datab Config >  backup/$date/Config.sql";
 //print "<p>" . $backup_Config . "<p>";
 $exec=passthru($backup_Config, $ret_Config);

 $backup_pic = "mysqldump --opt -c  -full -h $dbhost  -u $dbusr -p$dbpass $datab $pic_tbl >  backup/$date/$pic_tbl.sql";
 //print "<p>" . $backup_pic . "<p>";
 $exec=passthru($backup_pic, $ret_pic);
 
 print "<p>";
 chmod ("backup/$date/$cat_tbl.sql", 0777);
 chmod ("backup/$date/$ads_tbl.sql", 0777);
 chmod ("backup/$date/$usr_tbl.sql", 0777);
 chmod ("backup/$date/Config.sql", 0777); 
 chmod ("backup/$date/$pic_tbl.sql", 0777); 
 
 
 //------   Backup of SQL ---------	
 if ($ret_cat==0) 
 { print("<a href='backup/$date/$cat_tbl.sql'>Category table backed up</a><br>"); }
 else { print "<font color=red>Error: Category table</font><br>"; }

 if ($ret_ads==0) 
 { print("<a href='backup/$date/$ads_tbl.sql'>Ad table backed up</a><br>"); }
 else { print "<font color=red>Error: Ad table</font><br>"; }
 
 if ($ret_usr==0) 
 { print("<a href='backup/$date/$usr_tbl.sql'>User table backed up</a><br>"); }
 else { print "<font color=red>Error: User table</font><br>"; }
 
 if ($ret_Config==0) 
 { print("<a href='backup/$date/Config.sql'>Config table backed up</a><br>"); }
 else { print "<font color=red>Error: Config table</font><br>"; }

  
 if ($ret_pic==0) 
 { print("<a href='backup/$date/$pic_tbl.sql'>Picture table backed up</a><br>"); }
 else { print "<font color=red>Error: Picture table</font><br>"; } 

// End of backup
}

print "<p><p><b>$la_del_back:</b><br>";
if ($delete AND $delcatname)
{
 	 $c_del = unlink("backup/$delcatname/$cat_tbl.sql");
	 $a_del = unlink("backup/$delcatname/$ads_tbl.sql");
 	 $u_del = unlink("backup/$delcatname/$usr_tbl.sql");
 	 $c_del = unlink("backup/$delcatname/Config.sql");
 	 $p_del = unlink("backup/$delcatname/$pic_tbl.sql");
	 $c_del = unlink("backup/$delcatname/db.php");
	 $a_del = unlink("backup/$delcatname/config.inc.php");
 	 $u_del = unlink("backup/$delcatname/header.inc.php");
 	 $c_del = unlink("backup/$delcatname/footer.inc.php");

	 
	 
	 $cat_del = rmdir("backup/$delcatname");
	 
	 if ($cat_del == 1)
	 {
	 		print "$delcatname $la_bak_deleted";
	 }
	 else
	 {
	 		print "$la_bak_error $delcatname !";
	 }
	  
	 
}


print "<form method='post' action='$PHP_SELF'>";
print "<select name='delcatname'>";
$dir = opendir("backup/");
while ($file = readdir($dir))
{
	if ($file <> "." AND $file <> "..")
	echo "<option>$file</option>";
}
print "</select>  <input type='submit' name='delete' value='$la_del_back'></form>";
closedir($dir);
?>
</font><p>
	 </td>
</tr>
</table>
<!-- END Table menu -->
<?
include("admfooter.php");
?>