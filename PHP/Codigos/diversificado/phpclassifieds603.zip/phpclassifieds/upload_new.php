<?
session_start();
require("config/header.inc.php");
require("config/config.inc.php");
require("functions.php");
if (!$special_mode)
{ print("$menu_ordinary<p>"); }
print("<h2>$name_of_site</h2>");
print "<table border='1' cellpadding='2' width='100%' bgcolor='#DDDDDD' bordercolordark='#FFFFFF'>";
print "<tr>";
print "<td><font face='Verdana' size='1'><b>$la_admin_mnu</b></font></td>";
print "<td>&nbsp;</td>";
print "<td align='right'><font face='Verdana' size='1'>$la_logged_in : $valid_user</font></td>";
print "</tr>";
print "<tr>";
print "<td><a href='member.php'><font face='Verdana' size='1'><b>$la_admin</b></font></a></td>";
print "<td><a href='change.php'><font face='Verdana' size='1'><b>$change_user</b></font></a></td>";
print "<td><a href='pass.php'><font face='Verdana' size='1'><b>$la_change_pass</b></font></a></td>";
print "</tr>";
print "</table>";
check_valid_user();
?>
<h2><? echo $la_pic_upload ?></h2>
<font class='text'><? echo $upload_picture_text; ?></font>
<table><td><tr>


<form method="post" action="upload_new.php" enctype="multipart/form-data">
<INPUT TYPE="hidden" name="pictures_siteid" value="<? echo $pictures_siteid ?>">
<INPUT TYPE="hidden" name="MAX_FILE_SIZE" value="<? echo $piclimit ?>">
<? echo $la_filename ?><br><input type="file" name="form_data" size="40"><br>
<input type="submit" name="submit" value="<? echo $la_upload_button ?>">


<?

if ($submit AND ($form_data_size <> 0))
{
 	 		if ($form_data_size < $piclimit)
			{
 			 	 		
				$data = addslashes(fread(fopen($form_data,  "r"), filesize($form_data)));

			 require("config/config.inc.php");
	 		 require("admin/db.php");
       $result=MYSQL_QUERY( "INSERT INTO $pic_tbl (pictures_siteid,bin_data,filename,filesize,filetype) ".
                 "VALUES ('$pictures_siteid','$data','$form_data_name','$form_data_size','$form_data_type')");
			 $id = mysql_insert_id();
			 $result1=MYSQL_QUERY("UPDATE $ads_tbl set picture = $id where siteid=$pictures_siteid");
						 
			 
			 print("<p><p>$la_upload_success");
			 print "<br><a href='member.php'>$la_add_another</a><br>";
			 print("<p><a href='large_picture.php?id=$id'><img src='get.php?id=$id' width=\"106\" height=\"68\" align=\"left\" alt='Large picture'></a><p><p><p>"); 
			 
			 
         
     }

     elseif ($form_data_size > $limit)
     {
        print("<p><p>$la_upload_error2");
     }


}
print("</tr></td></table>");
require("config/footer.inc.php");
?>



