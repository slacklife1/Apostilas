<?
require("config/config.inc.php");

$latestfrontpage = 1;
$kid = '1';
require("links.php");
?>

