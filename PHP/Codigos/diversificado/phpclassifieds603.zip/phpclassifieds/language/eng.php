<?
   $demo = 0;
   $home = "Home";
   $menu_ordinary = "<p><a href = 'index.php'>Frontpage</a> | 
   <a href = 'register.php'>Add user</a> |
   <a href = 'member_login.php'>Add ad</a> |
   <a href = 'member_login.php'>Member login</a> | <a href = 'picturebrowse.php'>Browse pictures</a> | <a href = 'latestads.php'>Latest 30</a> | <a href = 'mostviewed.php'>Top 30</a> | <a href = 'search.php'>Search</a> | <a href = 'latestwap.php'>WAP</a>";
   
   $register = "Register";
   $title = "Title";
   $description = "Description";
   $category = "Category";
   $registered_site = "Added successfully";
   $updated_site = "It is updated";
   $submit_button = "Register";
   $delete_button = "Delete";
   $date_added = "Added";
   $hits_text = "Hits";
   $modify = "Modify";
   $check = "Check";
   $choose_cat = "Choose category";
   $mod = "Modify";
   $add_cat_title = "Name";
   $add_cat_submit = "Add / Update";
   $add_cat_father = "this is a category below: ";
   $add_cat_description = "Description";
   $top_level_message = "Top level cat";
   $deleted = "Deleted successfully";
   $list_message = "This is the admin screen. From here you can choose to add new categories, delete users and ads, set configuration options, make backup and much more.";
   $list_message_category = "Category Maintanance";
   $list_message_link = "Add site";
   $add_cat_help = "<small>From here, you can create, modify or delete any categories in your database. If you want to register
   a new top level category, just type in the <b>name</b> of the category in the name field, type a <b>description</b> if you want, and then
   press <b>Add/update</b> button.<p> If you want to create a sub category below a higher level category, do as above,
   but now choose what category it should be a sub category of.<p>If you would like to change name of current category, or
   change what category this category is sub of, select cat from the first drop down box that says <b>Choose category</b> (modify).<p></small>";
   $add_user_name = "Your name";
   $add_user_adressfield1 = "Address1";
   $add_user_adressfield2 = "Address2";
   $add_user_adressfield3 = "Address3";
   $add_user_phone = "Phone";
   $add_user_email = "Email";
   $add_user_pass  = "Password";
   $userid_text = "Userid";
   $updated_user  = "Your registration data is updated. You may now return <a href='member.php?submit=1'>to your ads</a>.";
   $registered_user = "<h3>Registered</h3><p>You are now a registered user, and you will recieve an email with all the info.<p>Userid: $userid<br>Password: $pass<p>";
   $picture_text = "Pic.";
   $general_details = "General details";
   $sold_by_text = "Sold by";
   $location_text = "Location";
   $ad_details_text = "Ad details";
   $ad_views = "Ad views";
   $ad_expire = "Ad expires";
   $upload_picture_text = "You can now upload a picture to your ad.";
   $filename = "Filename";
   $la_upload_success = "<b>Picture has been uploaded.</b><br>
   You can see the picture on you ad by going to you ad. Go to <a href='index.php'>frontpage</a>.";
   $yes = "Yes";
   $no = "No";
   $days = "days";
   $welcome_message = "Welcom to PHP Classified, the best classified collections in the entire world! To add your ad,
   please <a href='register.php'>register</a> free, or <a href='member_login.php'>login</a> to your members-area. You can also do a <a href='search.php'>search</a>.";
   $welcom_message_user_reg = "Here you can register for free. Please fill out all fields, some of them will be shown
   on your ads.";
   $subjectfield_email = "PHP Classifieds - New user";
   $change_user = "Change my information";
 
   $next_ads = "Next $number_of_ads_per_page"; 
   $previous_ads = "Previous $number_of_ads_per_page";  
   $admin_new_ad = "New Classified added!\n Go to http://$url/detail.php?siteid=$adid to
   check, or go to http://$url/admin to delete.\n
   Regards, \r PHP Classifieds\n";
	 $admin_new_ad_subject = "New ad added";
   $messagefield_email = "Hi $name  \n
	 We have added you at http://$url/. \r
	 You can log into your control panel.\n

	 VITALE DATA\r
	 -------------------------------------------------------------------\r
	 Username: $email\r
	 Password: $passwd\n
	 
	 Log in at:\r
	 http://$url/member_login.php\r
	 -------------------------------------------------------------------\r
	 Thanks for the visit! \n

	 Regards\n
	 PHP Classifieds\nhttp://$url//\n\n";

	 // add_ad.php and included files
	 $la_not_authorized = "You are not authorized...";
	 $la_log_out = "Log out";
	 $la_delete_ad_afterwards = "If you wish to delete your ad, push delete below.";
	 $la_no_email_pleas = "I do not want important information about our site.";
	 
	 // member.php
	 $la_not_authorized_member = "<font class='text'><p><b>Wrong userid or password</b>.<br>Unforunately, 
	 we didn�t find any users with the info you gave. If you are unsure of your real username or password, 
	 you might go to  <a href='member_login.php'>member login page</a>, and supply your email address to 
	 recieve registered information. </font>";

	 $la_forgotten_password = "<p><b>Forgotten password?</b><br> If you have forgotten your userid and/or 
	 password, you can get an email with this info. If you have registered using a valid email address, 
	 and enter the same emailaddress below, you will soon get it sent to you.";
 	 $la_remove_session = "Click here to remove session informaion.";
	 $la_email_forgotten_password = "Email sent to: $sendto";
	 $la_to_many_hits = "To many records. Please contact <a href='mailto:$from_adress'>$from_adress</a> to solve this.";
	 $welcom_message_change = "From here you can change userinformation that is registered earlier.";
	 $la_conditions = "Read conditions";
	 $la_add_user_session = "New user? Register first.";
	 // remove.php
	 $la_session_remove = "<h2>Session info</h2><p>We have now removed information stored in your browser.<p>";

	 // detail.php
	 $la_similar = "More ads in this cat";
	 $la_contact_sale = "Contact salesperson";
	 $la_edit = "Edit ad";
	 $la_delete = "Delete";
	 $la_large_picture_close = "Close window";
	 $la_similar_ads = "Ads from this seller";
	 
	 // kontakt.php
	 $la_sent_message = "We have now sent a message to $name.<p> Return to <a href='index.php'>frontpage</a>.";
	 $la_main_message = "Here you can get in touch with name:"; 
	 $la_main_message2 = " and with emailaddress";
	 $la_email = "Ad interest";
	 $la_email_body = "Hi $name\n\n$navn has the following message for you:\n\n$beskjed\n\nEmailaddress: $epost";

	 // email.php
	 $la_email_main_msg = "users have accepted to recieve email from you.
	 From here you can email all these people. <i>Please notice that if you have many people on your list,
	 this can be a problem tha not all will get their email due to timeout in php. This often occur if script in browser uses
	 more than 30 sek to complete. A thumb rule is that 1200 users take 5-6 sec.</i>";
	 $lang_email_members_title = "Subject";
	 $la_email_sent_message = "We have now sent to <b>$count</b> users.";
	 $lang_email_members_message = "Message";

	 // Validate
	 $lang_required_fields_missing = "Required fields not filled in.";

	 // categories_listbox_select_main
	 $la_cat_next = "Next";
 	 $la_cat_prev = "Previous";


	 // change.php
	 $la_change_user = "If you wish to delete yourselves and all related ads, push delete.";

	 // member.php
	 $la_member_area_welcome = "Welcome to yuor member area. From here you can change
	 registered userinfo, and edit, or add your ads.";
	 $changedelete = "Change or delete";
	 $la_new_ad_info = "If you whish to add a new ad attached with your userinformation registered earlier, please select under wich main category this ad will be placed under.";

	 // admin: index.php
	 $la_view = "View";

	 // add_ad.php
	 $la_error_msg1 = "You must type in a title.";
	 $la_error_msg2 = "Please fill in a description.";
	 $la_error_msg3 = "You must choose an category to add you ad into.";
	 $la_error_msg4 = "You forgot the price field. It must only be a integer like 100000, at least larger than 0";
	 $la_error_msg5 = "You must type in a name.";
	 $la_error_msg6 = "You must type in a street-address.";
	 $la_error_msg7 = "You must type in a post-address.";
	 $la_error_msg8 = "You must type in a email address.";
	 $la_error_msg9 = "You must type in a selected password.";
	 
	 // Upload.php
	 $la_upload_error1 = "<b>Error:</b><br>The picture you tried to upload is 0 kb
	 in size. <p>Please use the form to try again.";
	 
	 $la_upload_error2 = "<b>Error:</b><br>Picture you tried to upload, is to large (>30kb).
	 Try to compress the image and try again above.<p>";

	 // ADD_USER.PHP
	 $la_no_email_please = "I do not want email newsletter.";
	 $la_country = "Country";
	 $la_descr = "*Please enter the details of your company activities:";
	 $la_already_reg = "You are already registered. Goto <a href='member_login.php'>login screen</a>.";
	 
	 
	 // PICTUREBROWSE.PHP
	 $la_picture_gallery = "Picturegallery";
	 $la_picute_gallery_text = "Here you can browse all our pictureads. Click the picture to see the ad.";
	 
	 // ADD_USER.PHP
	 $lang_no_match_password = "The two password typed does not match eachother.";
	 
	 // CONTAKT.PHP
	 $la_kontakt = "Contact owner";
	 
	 // TELL-A-FRIEND
	 $la_tell_a_friend = "Tell-a-friend";
	 $la_message_sent = "Message is sent to";
	 $la_message_subject = "A tip from a friend regarding an ad";
	 $la_message_msg = "whished to tell you about this ad"; // EMAIL ...whished
	 $la_message_comment = "Below is comments from sender";
	 $la_sent_from = "Sent from";
	 $la_tell_error = "Error, senders emailadress not filled out";
	 $la_tell_welcome = "Here you can tip a friend by filling out their emailaddress and your own emailaddress with comments if you want.";
	 $la_reciever = "Receiver";
	 $la_sender = "Sender";
	 $la_close = "Close window";
	 
	 // SEARCH.PHP
	 $la_search_result = "Searchresults (if any)";
	 $la_view_l = "Latest ads";
	 $la_most_viewed = "Most viewed ads";
	 $la_search = "Search";
	 $la_s_category = " in category";
	 $la_s_num_res = " and show "; 
	 $la_s_num_res2 = " results on page";
	 $la_find_ads = "and find ads posted by the";
	 $la_find_ads2 = "userid or by his/her email";
	 $la_advanced = "Advanced search";
	 
	 // LIST_USERS.PHP
	 $la_users_deleted = "The user was deleted along with all ads.";
	 
	 // FUNCTIONS.PHP
	 $la_ads_deleted = "Ad deleted along with images.";

	 // WAP
	 $la_wap = "<small>You can see the latest 10 ads by visiting a WAP phone. Visit $url/wap/index.wml in your phonebrowser to get access. If you do not have WAP, you can test it (virtual) by visiting  <a href=\"http://www.gelon.net/\">wapalizer</a>.</small>";
	 
	 
	 // V. 602
	 // ---------------------------
	 
	 // html_add_ad.php
	 $la_hide_email = "Hide my email address (will show contact form instead)";
	 
	 // LINKS.PHP
	 $la_no_ads = "No Ads in this directory. Return to <a href='index.php'>frontpage</a>.";
	 
	 // MEMBER_LOGIN.PHP
	 $la_login_success = "You are now logged inn as "; 
	 $la_login_success2 = ". Click <a href='member.php'>here</a> to continue" .
	 											" into your administration area.";
	 
	 // V.603
	 // ----------------------------
	 
	 
	 // register.php
	 $la_error_msg20 = "That emailaddress is already in use. Please choose another one";
	 $la_error_msg21 = "Emailaddress contains illegal characters. Try again.";
	 $la_error_msg22 = "Passwords supplied do not match, try again.";
	 
	 $la_successreg = "Registration successfull";
	 $la_successreg2 = "You are now a registered user at our site, and you can now add ads from your control panel.";
	 $la_successreg3 = "Click here to continue";
	 
	 $la_why = "Why should you use us for your ads ?<ul><li>Free posting of ads <li>Control panel with easy access to add new ads<li>User statistics on ads</ul>";
	 $la_mailaddress = "Emailaddress";
	 $la_fullname = "Full name";
	 $la_pass1 = "Password (between 6 and 20 chars)"; 
	 $la_pass2 = "Confirm password";
	 $la_ne = "News / Hide mail";
	 $la_reg = "Register";
	 
	 // member.php
	 $la_admmenu = "Administration menu";
	 $la_logged_in = "Logged in as";
	 $la_admin_frontpage = "Admin frontpage";
	 $la_change_pass = "Change password";

	// backup.php
	$la_backup = "Here you can make a backup. Sql dump will only work with correct set-up 
	mysqldump client. It will run a mysqldump. The backup will be done to 
	the 'Backup/Todays date' directory, REMEMBER to make the backup dir 
	world writeable in order to use this tool<p><b>Note:</b> Do not consider this as bulletproof, 100% secure backup, just use this as an additional help to recreate your data. You SHOULD also use other, more secure methods. <p>";
	$la_permissions = "Permissions are set correct";
	$la_start_bak = "Start backup";
	$la_perm_error1 = "Error";
	$la_perm_error2 = "Backupdir is not set to chmod 777 (writeable)";
	$la_down1 = "Download customer.sql";
	$la_down2 = "Download invoice.sql";
	$la_down3 = "Download lineorder.sql";
	$la_down4 = "Download product.sql";
	$la_down1_err = "Error: customer table not copied!";
	$la_down2_err = "Error: invoice table not copied!"; 
	$la_down3_err = "Error: lineorder table not copied!";
	$la_down4_err = "Error: product table not copied!";
	$la_del_back = "Delete backup";
	$la_bak_deleted = "has been deleted !";
	$la_bak_error = "An error occured, could not delete";
	
	// add_ad.php
	$err_add = "Error: A field is not completed!";
	$la_pic_upl = "<b>Pictureupload?</b><br>You can now choose to upload a picture to your ad.";
	$la_choose = "Choose:";
	$la_i_want = "I want to upload a picture";
	$la_ret = "Return to frontpage";
	$la_add_an = "Add another ad";
	
	// upload_new.php
	$ad_add_another = "Add another ad";
	$la_upload_button = "Upload";
	$la_filename = "Filename:";
	$la_pic_upload = "Picture Upload";
	$la_change_pass = "Change password";
	$la_admin = "Admin frontpage";
	$la_logged_in = "Logged in as";
	$la_admin_menu = "Administration menu";
	
	// forgot.php
	$la_forgot = "<b>Forgotten password</b><br>Your new, temporary password is now sent to $email";
	$la_forgot_mail_subject = "Forgotten password";
	$la_forgot_mail_msg1 = "Your new temporary password is";
	$la_forgot_mail_msg2 = "Please change this as soon as you login, since it is to simple to be secure.";
	$la_forgot_mail_msg3 = "\n\nRegards, \n$name_of_site\n$url\n";
	
	// pass.php
	$la_new_pass1 = "New password";
	$la_new_pass2 = "New password (confirm)";
	$la_change_pass = "Change password";
	$la_pass_success = "Password is now changed";
	
	// change.php
	$la_news = "News / Hide mail:";
	$la_change_info = "Save";
?>