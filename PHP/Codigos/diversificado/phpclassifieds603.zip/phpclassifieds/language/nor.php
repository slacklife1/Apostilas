<?
   $demo = "";
   $home = "Hjem";
   $menu_ordinary = "<p><small><a href = 'index.php'>Forside</a> | 
   <a href = 'register.php'>Ny bruker</a> |
   <a href = 'member_login.php'>Ny annonse</a> |
   <a href = 'member_login.php'>Innlogging</a> | <a href = 'picturebrowse.php'>Bildearkiv</a> | <a href = 'latestads.php'>Siste 30</a> | <a href = 'mostviewed.php'>Topp 30</a> | <a href = 'search.php'>S�k</a> | <a href = 'latestwap.php'>WAP</a></small>";
       
   $register = "Registrer";
   $title = "Tittel";
   $description = "Beskrivelse";
   $category = "Kategori";
   $registered_site = "Lagt inn";
   $updated_site = "Oppdatert";
   $submit_button = "Registrer";
   $delete_button = "Slett";
   $date_added = "Lagt inn";
   $hits_text = "Treff";
   $modify = "Forandre";
   $check = "Sjekk";
   $choose_cat = "Velg kategori";
   $mod = "Forandre";
   $add_cat_title = "Navn";
   $add_cat_submit = "Legg til / Oppdater";
   $add_cat_father = "er en kategori under: ";
   $add_cat_description = "Description";
   $top_level_message = "Top level cat";
   $deleted = "Deleted successfully";
   $list_message = "This is the admin screen. From here you can choose to add new categories or links, or just display all
   links in checked category.";
   $list_message_category = "Category Maintanance";
   $list_message_link = "Add site";
   $add_cat_help = "<small>From here, you can create, modify or delete any categories in your database. If you want to register
   a new top level category, just type in the <b>name</b> of the category in the name field, type a <b>description</b> if you want, and then
   press <b>Add/update</b> button.<p> If you want to create a sub category below a higher level category, do as above,
   but now choose what category it should be a sub category of.<p>If you would like to change name of current category, or
   change what category this category is sub of, select cat from the first drop down box that says <b>Choose category</b> (modify).<p></small>";
   $add_user_name = "Navn";
   $add_user_adressfield1 = "Gateadresse";
   $add_user_adressfield2 = "Postadresse";
   $add_user_adressfield3 = "Adress3";
   $add_user_phone = "Tlf";
   $add_user_email = "Epost";
   $add_user_pass  = "Passord";
   $userid_text = "Brukerid";
   $updated_user  = "Informasjonen er oppdatert. Du kan returnere <a href='member.php?submit=1'>til dine annonser</a>.";
   $registered_user = "<h3>Registrert</h3><p>Du er n� en registrert bruker, og du vil motta en epost med innloggingsinfo.<p>Brukerid: $userid<br>Passord: $pass<p>";
   $picture_text = "Bilde";
   $general_details = "Generelle detaljer";
   $sold_by_text = "Selges av";
   $location_text = "Sted";
   $ad_details_text = "Annonsedetaljer";
   $ad_views = "Annonsevisninger";
   $ad_expire = "Annonse slettes";
   $upload_picture_text = "Du kan n� laste opp et bilde til din annonse..";
   $filename = "Filnavn";
   $la_upload_success = "<b>Bilde har blitt lastet opp.</b><br><a href='index.php'>G� til forside</a>.";
   $yes = "Ja";
   $no = "Nei";
   $days = "dager";
   $welcome_message = "<small>Velkommen til Butikktilbud. Her kan du gratis legge inn ubegrenset med annonser tilknyttet bilder. For � starte innleggingen, <a href='register.php'>registrer</a> deg gratis, eller <a href='member_login.php'>logg inn</a> til ditt medlemsomr�det.</small>";
   $welcom_message_user_reg = "Her kan du registrere deg gratis. Fyll ut alle feltene, da noen av disse vil bli vist p� alle dine annonser.";
   $subjectfield_email = "Ny bruker";
   $change_user = "Forandre min info";
 
   $next_ads = "Neste $number_of_ads_per_page"; 
   $previous_ads = "Forrige $number_of_ads_per_page";  
   $admin_new_ad = "Ny annonse lagt inn!\n G� til http://$url/detail.php?siteid=$adid for � se annonsen, eller g� til http://$url/admin for � slette.\n
   Regards, \r PHP Classifieds\n";
	 $admin_new_ad_subject = "Ny annonse";
   $messagefield_email = "Hei $navn1  \n
	 Vi har lagt deg inn p� http://$url/. \r
	 Du kan n� logge deg inn i ditt kontrollpanel.\n

	 VITALE DATA\r
	 -------------------------------------------------------------------\r
	 Brukerid: $email\r
	 Passord: $passwd\n
	 
	 Kontrollpanel:\r
	 http://$url/member_login.php\r
	 -------------------------------------------------------------------\r
	 Takk for bes�ket! \n

	 Med hilsen\n
	 Butikktilbud\nhttp://$url\n\n";

	 // add_ad.php and included files
	 $la_not_authorized = "Du er ikke autorisert...";
	 $la_log_out = "Logge ut";
	 $la_delete_ad_afterwards = "Hvis du �nsker � slette annonsen, klikk knappen nedenfor.";
	 $la_no_email_pleas = "Jeg vil ikke ha viktige meldinger eller nyheter fra A4 Bil.";
	 
	 	 // member.php
	 $la_not_authorized_member = "<font class='text'><p><b>Feil brukerid eller passord</b>.<br> Dersom du er usikker, g� til <a href='member_login.php'>innloggingsbildet</a>, og oppgi din epostadresse. </font>";

	 $la_forgotten_password = "<p><b>Glemt passord?</b><br>Oppgi din epostadresse, og vi vil straks sende deg en epost med nytt, midlertidig passord";
	 $la_email_forgotten_password = "Epost sendt til: $sendto";
	 $la_conditions = "Les betingelser";
	 $la_add_user_session = "Ny bruker? Registrer deg f�rst";

	 // detail.php
	 $la_similar = "Flere annonser i denne kategori";
	 $la_contact_sale = "Kontakt selger";
	 $la_edit = "Rediger annonse";
	 $la_delete = "Slett";
	 $la_large_picture_close = "Lukk vindu";
	 $la_similar_ads = "Annonser fra denne selger";
	 
	 // kontakt.php
	 $la_sent_message = "Du har n� sendt en melding til $name.<p>Returner til <a href='index.php'>forsiden</a>.";
	 $la_main_message = "Her kan du komme i kontakt med "; 
	 $la_main_message2 = " med epostadresse ";
	 $la_email = "Annonseinteresse";
	 $la_email_body = "Hei $name\n\n$navn har f�lgende beskjed til deg :\n\n$beskjed\n\nEpostadresse: $epost";

	 // Validate
	 $lang_required_fields_missing = "P�krevde felter ikke utfyllt";

	 // categories_listbox_select_main
	 $la_cat_next = "Neste";
 	 $la_cat_prev = "Forrige";


	 // change.php
	 $la_change_user = "Hvis du �nsker � slette deg selv, med tilh�rende annonser.";

	 // member.php
	 $la_member_area_welcome = "Velkommen til ditt medlemsomr�det. Fra her kan du endre registrerte brukerdata, og endre eller legge til nye annonser";
	 $changedelete = "Forandre eller Slette";
	 $la_new_ad_info = "Hvis du �nsker � legge inn en ny annonse, vennligst velg en kategori nedenfor.";

	 // add_ad.php
	 $la_error_msg1 = "Du m� fylle inn en tittel.";
	 $la_error_msg2 = "Beskrivelse mangler.";
	 $la_error_msg3 = "Ingen �nsket kategori";
	 $la_error_msg4 = "";
	 $la_error_msg5 = "Du m� skrive inn et navn.";
	 $la_error_msg6 = "Gateadresse.";
	 $la_error_msg7 = "Postadresse.";
	 $la_error_msg8 = "Epostadresse.";
	 $la_error_msg9 = "Passord.";
	 
	 // Upload.php
	 $la_upload_error1 = "<b>Error:</b><br>The picture you tried to upload is 0 kb
	 in size. <p>Please use the form to try again.";
	 
	 $la_upload_error2 = "<b>Error:</b><br>Picture you tried to upload, is to large (>30kb).
	 Try to compress the image and try again above.<p>";

	 // ADD_USER.PHP
	 $la_no_email_please = "Jeg vil ikke ha nyhetsbrev.";
	 $la_country = "Land";
	 $la_descr = "*Please enter the details of your company activities:";
	 $la_already_reg = "Du er allerede registrert. G� til <a href='member_login.php'>innlogging</a>.";
	 
	 
	 // PICTUREBROWSE.PHP
	 $la_picture_gallery = "Bildegalleri";
	 $la_picute_gallery_text = "Her kan du bla i alle bilder i v�r database. Klikk et bilde for � se annonsen bak.";
	 
	 // ADD_USER.PHP
	 $lang_no_match_password = "De to passordene stemmer ikke overens.";
	 
	 // CONTAKT.PHP
	 $la_kontakt = "Kontakt eier";
	 
	 // TELL-A-FRIEND
	 $la_tell_a_friend = "Fortell-en-venn";
	 $la_message_sent = "Melding sendt til";
	 $la_message_subject = "Et nettips fra en venn";
	 $la_message_msg = "�nsket � fortelle deg om denne annonse"; // EMAIL ...whished
	 $la_message_comment = "Nedenfor er kommentar fra sender:";
	 $la_sent_from = "Sendt fra";
	 $la_tell_error = "Feil, senders epostadresse ikke utfyllt";
	 $la_tell_welcome = "Her kan du tipse en venn ved � fylle ut deres epostadresse, og din egen, sammen med en kort kommentar, hvis du vil.";
	 $la_reciever = "Mottaker";
	 $la_sender = "Sender";
	 $la_close = "Lukk vindu";
	 
	 // SEARCH.PHP
	 $la_search_result = "S�keresultat (hvis noen)";
	 $la_view_l = "Siste annonser";
	 $la_most_viewed = "Mest sett";
	 $la_search = "S�k";
	 $la_s_category = " i kategori";
	 $la_s_num_res = " og vis "; 
	 $la_s_num_res2 = " resultater per side";
	 $la_find_ads = "og finn annonser lagt inn av";
	 $la_find_ads2 = "brukerid og/eller epostadresse";
	 $la_advanced = "Avansert s�k";
	 
 
	 // FUNCTIONS.PHP
	 $la_ads_deleted = "Annonse med bilde slettet.";

	 // WAP
	 $la_wap = "<small>Du kan se siste 10 tilbud ved � bes�ke oss via WAP mobiltelefon. Bes�k $url/wap/index.wml i din mobilnettleser for � f� tilgang. Hvis du ikke har WAP, og �nsker � teste tjenesten, bes�k <a href=\"http://www.gelon.net/\">wapalizer</a> for simulert mobiltelefon.</small>";
	 
	 
	 // V. 602
	 // ---------------------------
	 
	 // html_add_ad.php
	 $la_hide_email = "Skjul min epostadresse (vil vise kontaktskjema i stedet)";
	 
	 // LINKS.PHP
	 $la_no_ads = "Ingen annonser i denne katalog. Returner til <a href='index.php'>forsiden</a>.";
	 
	 // MEMBER_LOGIN.PHP
	 $la_login_success = "Du er n� logget inn som "; 
	 $la_login_success2 = ". Klikk <a href='member.php'>her</a> for � fortsette" .
	 											" inn p� ditt medlemsomr�det.";
	 
	 // V.603
	 // ----------------------------
	 
	 
	 // register.php
	 $la_error_msg20 = "Epostadressen er allerede i bruk.";
	 $la_error_msg21 = "Epostadressen innehold ulovlige tegn.";
	 $la_error_msg22 = "Passord oppgitt stemte ikke overens.";
	 $la_successreg = "Registrering vellykket";
	 $la_successreg2 = "Du er n� en registrert bruker, og kan legge inn annonser fra ditt kontrollpanel.";
	 $la_successreg3 = "Klikk her for � fortsette";
	 
	 $la_why = "Hvorfor skulle du bruke v�rt annonsesystem? <ul><li>Gratis publisering <li>Kontrollpanel<li>Statistikk</ul>";
	 $la_mailaddress = "Epostadresse";
	 $la_fullname = "Fullt navn";
	 $la_pass1 = "Passord (mellom 6 og 20 tegn)"; 
	 $la_pass2 = "Bekreft passord";
	 $la_ne = "Nyheter / Skjul adr.";
	 $la_reg = "Registrer";
	 
	 // member.php
	 $la_admmenu = "Administrasjosmeny";
	 $la_logged_in = "Logget inn som";
	 $la_admin_frontpage = "Forside";
	 $la_change_pass = "Endre passord";

	// backup.php
	$la_backup = "Here you can make a backup. Sql dump will only work with correct set-up 
	mysqldump client. It will run a mysqldump. The backup will be done to 
	the 'Backup/Todays date' directory, REMEMBER to make the backup dir 
	world writeable in order to use this tool<p><b>Note:</b> Do not consider this as bulletproof, 100% secure backup, just use this as an additional help to recreate your data. You SHOULD also use other, more secure methods. <p>";
	$la_permissions = "Permissions are set correct";
	$la_start_bak = "Start backup";
	$la_perm_error1 = "Error";
	$la_perm_error2 = "Backupdir is not set to chmod 777 (writeable)";
	$la_down1 = "Download customer.sql";
	$la_down2 = "Download invoice.sql";
	$la_down3 = "Download lineorder.sql";
	$la_down4 = "Download product.sql";
	$la_down1_err = "Error: customer table not copied!";
	$la_down2_err = "Error: invoice table not copied!"; 
	$la_down3_err = "Error: lineorder table not copied!";
	$la_down4_err = "Error: product table not copied!";
	$la_del_back = "Delete backup";
	$la_bak_deleted = "has been deleted !";
	$la_bak_error = "An error occured, could not delete";
	
	// add_ad.php
	$err_add = "Feil: Et felt er ikke fullf�rt!";
	$la_pic_upl = "<b>Bildeopplastning?</b><br>Du kan n� knytte et bilde til din annonse.";
	$la_choose = "Velg:";
	$la_i_want = "Jeg vil laste opp bilde";
	$la_ret = "Returner til forsiden";
	$la_add_an = "Legg inn enda et tilbud";
	
	// upload_new.php
	$ad_add_another = "Ny annonse";
	$la_upload_button = "Last opp";
	$la_filename = "Filnavn:";
	$la_pic_upload = "Bildeopplastning";
	$la_change_pass = "Endre passord";
	$la_admin = "Admin forside";
	$la_logged_in = "Logget inn som";
	$la_admin_menu = "Administrasjonsmeny";
	
	// forgot.php
	$la_forgot = "<b>Glemt passord</b><br>Ditt nye, midlertidige passord er n� sendt til $email";
	$la_forgot_mail_subject = "Glemt passord";
	$la_forgot_mail_msg1 = "Ditt nye midlertidige passord er:";
	$la_forgot_mail_msg2 = "Vennligst forandre dette s� snart du er logget inn, siden dette passord er alt for enkelt til � v�re sikkert";
	$la_forgot_mail_msg3 = "\n\nHilsen, \n$name_of_site\n$url\n";
	
		// pass.php
	$la_new_pass1 = "Nytt passord";
	$la_new_pass2 = "Nytt passord (bekreft)";
	$la_change_pass = "Forandre passord";
	$la_pass_success = "Passord er endret";
	
	// change.php
	$la_news = "Nyheter/skjul epostadr:";
		$la_change_info = "Lagre";
?>