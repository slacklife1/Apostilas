<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 27th.May,2002                                                           **
  //******************************************************************************************
 
  $title    = "phpNewsManager $newman_ver";
  include ("colors.php");
  include "functions.php";

function ShowMain()
 {
  global $color01,$color02,$color03,$color04,$color05,$PHP_SELF;
  global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
  ?>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD WIDTH=20>
    <A HREF="news.php?action=add"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Post news"></A>
   </TD>
   <TD>
    <A HREF="news.php?action=add"><?echo _ADDNEWS?></A>
   </TD>
   <TD ALIGN=RIGHT>
    <?
     $res = mysql_query("SELECT * from $db_pnews order by datum desc");
     $num = mysql_num_rows($res);
     echo "Submited news: ".$num;
    ?>
   </TD>
  </TR>
 </TABLE>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=1>
  <TR BGCOLOR=#<?echo $color02;?> CLASS=MojText>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _OPTIONS;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _NEWSHEADLINE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _AUTHOR;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _DATE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _SECTION;?></FONT></TD>
  </TR>  
    <?php
    $res = mysql_query("SELECT * from $db_pnews order by datum desc limit 50");
    while ($ar = mysql_fetch_array($res))
     {
      $datum = formatTimestamp($ar[datum]);

      $res2 = mysql_query("SELECT * FROM $db_topic where id='$ar[category]'"); 
      $ar2 = mysql_fetch_array($res2);
      if(mysql_num_rows($res2) <> 0)
       {
      echo "
 	 <TR CLASS=MojText>
 	  <TD WIDTH=90><A HREF=?action=open&id=$ar[id]><IMG SRC=gfx/ofolder15.gif BORDER=0></A> <A HREF=?action=edit&id=$ar[id]><IMG SRC=gfx/notes16.gif BORDER=0></A> <A HREF=?action=delete&id=$ar[id]><IMG SRC=gfx/trash.gif BORDER=0></A><A HREF=\"?action=submit&id=$ar[id]\"><IMG SRC=\"gfx/survey.gif\" BORDER=0></A></TD> 
	  <TD>$ar[headline]</TD>
  	  <TD ALIGN=RIGHT VALIGN=TOP>$ar[author]</TD>
  	  <TD ALIGN=RIGHT WIDTH=100 VALIGN=TOP>$datum</TD>
  	  <TD ALIGN=RIGHT VALIGN=TOP><IMG SRC=http://www.skinbase.org/topic/$ar2[topicimage] ALT=\"$ar2[topictext]\" WIDTH=20></TD>
 	 </TR> ";
        }
    }
  echo "</TABLE>";
 }

function OpenNews()
 {
  global $color01,$color02,$color03,$color04,$color05;
  global $id,$PHP_SELF;
  global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
  ?>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD WIDTH=20>
    <A HREF="<?echo $PHP_SELF;?>?action=add"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="<?echo _ADDNEWS;?>"></A>
   </TD>
   <TD>
    <A HREF="news.php?action=add"><?echo _ADDNEWS;?></A>
   </TD>
   <TD ALIGN=RIGHT>
    <?
     $res = mysql_query("SELECT * from $db_pnews order by datum desc limit 40");
     $num = mysql_num_rows($res);
     echo "Submited news: ".$num;
    ?>
   </TD>
  </TR>
 </TABLE>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=1>
  <TR BGCOLOR=#<?echo $color02;?> CLASS=MojText>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _OPTIONS;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _NEWSHEADLINE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _AUTHOR;?></FONT></TD>
   <TD><FONT WIDTH=100 COLOR=#<?echo $color05;?>><?echo _DATE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _SECTION;?></FONT></TD>
  </TR>  
    <?php
    $res = mysql_query("SELECT * from $db_pnews order by datum desc");
    while ($ar = mysql_fetch_array($res))
     {
      $res2 = mysql_query("SELECT * FROM $db_topic where topicname='$ar[category]'"); 
      $ar2 = mysql_fetch_array($res2);
      $datum = formatTimestamp($ar[datum]);
      if(mysql_num_rows($res2) <> 0)
       {
      echo "
 	 <TR CLASS=MojText>
 	  <TD WIDTH=90><A HREF=?action=open&id=$ar[id]><IMG SRC=gfx/ofolder15.gif BORDER=0></A> <A HREF=?action=edit&id=$ar[id]><IMG SRC=gfx/notes16.gif BORDER=0></A> <A HREF=?action=delete&id=$ar[id]><IMG SRC=gfx/trash.gif BORDER=0></A></TD> 
	  <TD>$ar[headline]</TD>
  	  <TD >$ar[author]</TD>
  	  <TD WIDTH=100>$datum</TD>
  	  <TD><IMG SRC=\"http://www.skinbase.org/topic/$ar2[topicimage]\" ALT=\"$ar2[topictext]\" WIDTH=20></TD>
 	 </TR> ";
      if ($id == $ar[id]) {echo "<TR><TD></TD><TD COLSPAN=3 Class=MojText BGCOLOR=$color04>$ar[preview]</TD></TR> ";} 
     }
   }

 echo "</TABLE>";
 }


function EditNews()
{
 global $color01,$color02,$color03,$color04;
 global $id,$confirm,$headline,$message,$section,$preview,$login,$time,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("pnews_edit") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm <> "true") 
   {
    $res = mysql_query("SELECT * from $db_pnews where id='$id'");
    $ar = mysql_fetch_array($res);

    $ar[headline] = ereg_replace( "&quot;","\"",$ar[headline]);
    $ar[headline] = ereg_replace( "&acute;","'",$ar[headline]);

    $ar[tekst] = ereg_replace( "<BR>","\n",$ar[tekst]);
    $ar[tekst] = ereg_replace( "&quot;","\"",$ar[tekst]);
    $ar[tekst] = ereg_replace( "&acute","'",$ar[tekst]);

    $ar[preview] = ereg_replace( "<BR>","\n",$ar[preview]);
    $ar[preview] = ereg_replace( "&quot;","\"",$ar[preview]);
    $ar[preview] = ereg_replace( "&acute;","'",$ar[preview]);

    ?>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A> :<BR>
    <FONT SIZE=5 FACE=Arial><B><?echo _MODIFYPNEWS;?><B></FONT><BR>
    <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
     <TR>
      <TD CLass=MojText>
       <FORM ACTION="" METHOD="POST">
        <?echo _NEWSHEADLINE;?><BR>
        <INPUT TYPE="text" NAME="headline" SIZE=60 VALUE="<?echo $ar[headline];?>"><BR>
        <?echo _SECTION;?>:<BR>
        <select name=section>
        <?php
         $res2 = mysql_query("SELECT * FROM $db_topic"); 
         while ($ar2 = mysql_fetch_array($res2))
          {
           print "<option name=section value=\"$ar2[topicname]\" ";
           if ($ar2[topicname] == $ar[category]) { print "selected";}
           print ">$ar2[topictext]</option>";
          }
        ?>
        </select><BR>
        <?echo _PREVIEW;?><BR>
        <TEXTAREA NAME=preview COLS=60 ROWS=6><?echo "$ar[preview]";?></TEXTAREA><BR>
        <?echo _MESSAGE;?><BR>
        <TEXTAREA NAME=message COLS=60 ROWS=10><?echo "$ar[tekst]";?></TEXTAREA>
        <input type="hidden" name="action" value="edit"><BR><BR>
        <input type="hidden" name="confirm" value="true">
        <input type="hidden" name="id" value="<?echo $id;?>">
        <input type="hidden" name="time" values="<?echo $ar[datum];?>">
        <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
        </FORM>
       </TD>
      </TR>
    </TABLE> 
   <?
  }
 if ($confirm == "true") 
   {
    $message = ereg_replace( "\n", "<BR>",$message);
    /*$message = ereg_replace( "\"", "&quot;",$message);*/
    $message = ereg_replace( "'", "&acute",$message);

    /*$headline = ereg_replace( "\"", "&quot;",$headline);*/
    $headline = ereg_replace( "\n", " ",$headline);
    $headline = ereg_replace( "'", "&acute;",$headline);

    $preview = ereg_replace( "\n", "<BR>",$preview);
    /*$preview = ereg_replace( "\"", "&quot;",$preview);*/
    $preview = ereg_replace( "'", "&acute;",$preview);
    $res2 = mysql_query("SELECT datum FROM $db_pnews WHERE id=$id");
    $mr= mysql_fetch_array($res2);
    $res = mysql_query("UPDATE $db_pnews SET headline='$headline', category='$section', preview='$preview', tekst='$message', datum='$mr[datum]' WHERE id='$id'"); 
    ShowMain();
   } 
 }

function DeleteNews()
 {
 global $color01,$color02,$color03,$color04,$color05;
 global $id,$confirm,$preview,$headline,$message,$section,$login,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("pnews_del") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm == "true") {$res = mysql_query("DELETE FROM $db_pnews where id='$id'"); ShowMain();exit();}
 if ($confirm == "false"){ShowMain();}
 if ($confirm == "")
  {
?>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD WIDTH=20>
    <A HREF="news.php?action=add"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="<?echo _ADDNEWS;?>"></A>
   </TD>
   <TD>
    <A HREF="news.php?action=add"><?echo _ADDNEWS;?></A>
   </TD>
   <TD ALIGN=RIGHT>
    <?
     $res = mysql_query("SELECT * from $db_pnews order by datum desc");
     $num = mysql_num_rows($res);
     echo "<?echo _WAITTINGNEWS;?>: ".$num;
    ?>
   </TD>
  </TR>
 </TABLE>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=1>
  <TR BGCOLOR=#<?echo $color02;?> CLASS=MojText>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _NEWSHEADLINE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _AUTHOR;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _DATE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _SECTION;?></FONT></TD>
  </TR>  
  <?php
    $res = mysql_query("SELECT * from $db_pnews where id='$id'");
    $ar = mysql_fetch_array($res);
    echo "
 	 <TR CLASS=MojText>
	  <TD>$ar[headline]</TD>
  	  <TD>$ar[author]</TD>
  	  <TD>$ar[datum]</TD>
  	  <TD>$ar[category]</TD>
 	 </TR> 
 	 <TR><TD COLSPAN=4 Class=MojText>$ar[preview]</TD></TR></TABLE>";
?>  
<TABLE CELLSPACING=2 CELLPADDING=2><TR><TD VALIGN=TOP>
 <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="image" SRC="gfx/survey.gif" ALT="<?echo _KEEPIT;?>" BORDER=0 WIDTH=24 HEIGHT=24><BR>
  <INPUT TYPE="hidden" name="action" value="delete">
  <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
  <INPUT TYPE="hidden" name="info" value="<?echo $info;?>">
  <INPUT TYPE="hidden" name="confirm" value="false"></FORM>
</TD><TD VALIGN=TOP>
  <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="image" SRC="gfx/trash.gif" ALT="<?echo _DELETEIT;?>" BORDER=0 WIDTH=16 HEIGHT=16><BR>
  <INPUT TYPE="hidden" name="action" value="delete">
  <INPUT TYPE="hidden" name="info" value="<?echo $info;?>">
  <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
  <INPUT TYPE="hidden" name="confirm" value="true">
  </FORM>
</TD></TR></TABLE>
<?
 }
 }

function SubmitNews()
 {
  global $color01,$color02,$color03,$color04;
  global $id,$login,$headline,$message,$section,$info,$preview,$PHP_SELF;
  global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("pnews_add") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

  
  $res=mysql_query("SELECT * from $db_pnews where id=$id") or die("myError0");;
  $ar=mysql_fetch_array($res);  
  $num=mysql_num_rows($res);
  if($num==1)
  {
   mysql_query("INSERT INTO $db_news VALUES(0,'$ar[headline]','$ar[author]','$ar[category]','$ar[picture]',CURRENT_TIMESTAMP,'$ar[preview]','$ar[tekst]','uk',0)") or die("myError1");
  }
  ShowMain();
 }


?>

 <?include ("header.php");
  if ($psw == TRUE)
   {
    if ($action == "")       { ShowMain();   }
    if ($action == "edit")   { EditNews();   }
    if ($action == "delete") { DeleteNews(); }
    if ($action == "submit") { SubmitNews();    }
    if ($action == "open")   { OpenNews();   }
    if ($action == "logout") { Logout();     }
   }
  include ("footer.php");
 ?>
