<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 27th.May,2002                                                           **
  //******************************************************************************************
  
  $title  = "phpNewsManager $newman_ver";
  $makejs = "partners";
  include "colors.php";
  include "functions.php";
  include "header.php";

function ShowMain()
{
 global $color01,$color02,$color03,$color04,$color05;
 global $page,$partners_path;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 $res = mysql_query("SELECT * from $db_partners order by id desc");
 $num = mysql_num_rows($res);

  $m=0;
  if (empty($page)) {$page=1;}    
  $hits=50;
  $stw2 = ($num/$hits);
  $stw2 = (int) $stw2;
  if ($num%$hits > 0) {$stw2++;}
  $np = $page+1;
  $pp = $page-1;
  if ($page == 1) { $pp=1; }
  if ($np > $stw2) { $np = $stw2;} 
    
  $sp=($page-1)*$hits;
  $ep=($page-1)*$hits+$hits;


  ?>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD WIDTH=20>
    <IMG SRC="gfx/docman.gif" BORDER=0 ALT="Submit">
   </TD>
   <TD>
    <A HREF="?action=add"><?echo _ADDPARTNERS;?></A> | <A HREF="?action=upload"><?echo _UPLOADLOGO;?></A>
   </TD>
   <TD>
    <?echo _SELECTPAGE;?>: <?for ($i=1;$i<=$stw2;$i++) {if($page==$i){echo "<B>$i</B>";} else{echo " <A HREF=\"?page=$i\">$i</A> ";}}?>
   </TD>
   <TD ALIGN=RIGHT>
    <?echo _OURPARTNERS.": ".$num;?>
   </TD>
  </TR>
 </TABLE>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=1>
  <TR BGCOLOR=#<?echo $color02;?> CLASS=MojText>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _OPTIONS;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _NAME;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _LINK;?></FONT></TD>
   <TD><FONT WIDTH=20 COLOR=#<?echo $color05;?>><?echo _IN;?></FONT></TD>
   <TD><FONT WIDTH=20 COLOR=#<?echo $color05;?>><?echo _OUT;?></FONT></TD>
   <TD><FONT WIDTH=20 COLOR=#<?echo $color05;?>><?echo _AFFILIATES;?></FONT></TD>
   <TD><FONT WIDTH=20 COLOR=#<?echo $color05;?>><?echo _GFX;?></FONT></TD>
  </TR>  
<?
    while ($ar = mysql_fetch_array($res))
     {
      $m++;
      if($m>$sp and $m<$ep)
       {      
        $res2 = mysql_query("SELECT * from $db_partners order by id desc");
        $ar2 = mysql_fetch_array($res2);
        if(mysql_num_rows($res2) <> 0)
         {
          //ereg ("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $ar[date], $dated);
          //$ar[date] = "$dated[3]-$dated[2]-$dated[1]";
          if ($ar[main]==0){$main = "No";}else{$main = "Yes";}
	  if ($ar[gfx]==0){$gfx = "No";}else{$gfx = "Yes";}          
          echo "
 	   <TR CLASS=MojText>
 	   <TD WIDTH=80><A HREF=?action=edit&id=$ar[id]><IMG SRC=gfx/notes16.gif BORDER=0></A> <A HREF=?action=delete&id=$ar[id]><IMG SRC=gfx/trash.gif BORDER=0></A></TD> 
	   <TD>$ar[name]</TD>
  	   <TD ALIGN=RIGHT VALIGN=TOP>$ar[link]</TD>
  	   <TD ALIGN=RIGHT VALIGN=TOP>$ar[clicks]</TD>
  	   <TD ALIGN=RIGHT VALIGN=TOP>$ar[out]</TD>
  	   <TD ALIGN=RIGHT VALIGN=TOP>$main</TD>
  	   <TD ALIGN=RIGHT VALIGN=TOP>$gfx</TD>
 	   </TR> ";
         }
  }
 }
 echo "</TABLE>";
 if(!file_exists($partners_path)){echo "<BR><BR><CENTER><FONT SIZE=3 FACE=ARIAL><B>ERROR: CHECK YOUR \$partners_path VARIABLE IN db.inc.php FILE !!!</B></FONT></CENTER><BR><BR>";}
 echo "<CENTER><A HREF=\"?page=$pp\">"._PREVIOUS."</A> <--|--> <A HREF=\"?page=$np\">"._NEXT."</A></CENTER>";
}

function EditPartners()
{
 global $color01,$color02,$color03,$color04;
 global $id,$confirm,$question,$answers,$login,$afil,$gfx;
 global $link,$name,$desc,$picture,$description,$partners_path,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("partner_edit") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm <> "true") 
   {
    $res = mysql_query("SELECT * from $db_partners where id='$id'");
    $ar = mysql_fetch_array($res);

    $description = ereg_replace( "&quot;","\"",$ar[description]);
    $description = ereg_replace( "&acute","'",$desccription);
    ?>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A><BR>
    <FONT SIZE=5 FACE=Arial><B><?echo _MODIFYPARTNERS;?><B></FONT><BR>
    <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
     <TR>
      <TD CLass=MojText>
       <FORM ACTION="" METHOD="POST" NAME="forma">
        <?echo _NAME;?><BR>
        <INPUT TYPE="text" NAME="name" SIZE=60 VALUE="<?echo $ar[name];?>"><BR>
        <?echo _LINK;?><BR>
        <INPUT TYPE="text" NAME="link" SIZE=60 VALUE="<?echo $ar[link];?>"><BR>
        <?echo _IMAGE;?><BR>
       <select name="picture" size=8 onClick="Swap();">
       <?
        $d = dir($partners_path);
        $x=0;
	while($entry=$d->read()) {$x++;if ($x > 2) 
	{
	 echo "<option value=\"$entry\""; if ($entry == $ar[picture]){echo " selected ";};echo ">$entry</option>";}
	}
        $d->close();
       ?>
       </SELECT>
       <P><IMG NAME="button" SRC="http://www.skinbase.org/gfx/partners/<?echo $ar[picture];?>" WIDTH=88 HEIGHT=31 BORDER=0></A></P>
       <BR>
       <?echo _DESCRIPTION;?><BR>
       <TEXTAREA NAME="description"><?echo $ar[description];?></TEXTAREA>
       <BR><BR>
	<?echo _AFFILIATES;?><BR>
	<select name="afil">
	 <option value="0" <?if($ar[main]==0) {echo " selected ";};?>> no</option>
	 <option value="1" <?if($ar[main]==1) {echo " selected ";};?>> yes</option>
	</select><BR>

	<?echo _GFX;?><BR>
	<select name="gfx">
	 <option value="0" <?if($ar[gfx]==0) {echo " selected ";};?>> no</option>
	 <option value="1" <?if($ar[gfx]==1) {echo " selected ";};?>> yes</option>
	</select><BR>
	
	<BR>
        <input type="hidden" name="action" value="edit"><BR><BR>
        <input type="hidden" name="confirm" value="true">
        <input type="hidden" name="id" value="<?echo $id;?>">
        <INPUT TYPE="submit" VALUE="Edit">
        </FORM>
       </TD>
      </TR>
    </TABLE> 
   <?
  }
 if ($confirm == "true") 
   {
    $description = ereg_replace( "\"","&quot;",$description);
    $description = ereg_replace( "'","&acute",$description);

    $res = mysql_query("UPDATE $db_partners SET name='$name',picture='$picture', link='$link',description='$description', main='$afil', gfx='$gfx' WHERE id=$id") or die("err"); 
    ShowMain();
   } 
}

function AddPartners()
{
 global $color01,$color02,$color03,$color04,$PHP_SELF;
 global $id,$name,$link,$picture,$desc,$login,$action,$confirm,$partners_path,$afil,$gfx;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("partner_add") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm <> "true") 
   {
    ?>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A><BR>
    <FONT SIZE=5 FACE=Arial><B><?echo _ADDPARTNERS;?><B></FONT><BR>
    <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
     <TR>
      <TD CLass=MojText>
        <FORM METHOD=POST ACTION="" NAME="forma">
        <?echo _NAME;?><BR>
        <INPUT TYPE="text" NAME="name" SIZE=60><BR>
        <?echo _LINK;?><BR>
        <INPUT TYPE="text" NAME="link" SIZE=60><BR>
        <?echo _IMAGE;?><BR>
       <select name="picture" size=8 onClick="Swap();">
       <?
        $d = dir($partners_path);
        $x=0;
	while($entry=$d->read()) {$x++;if ($x > 2) {echo "<option value=\"$entry\""; if ($entry == $ar[topicimage]){echo " selected ";};echo ">$entry</option>";}}
        $d->close();
       ?>
       </SELECT>
       <P>
      <IMG NAME="button" SRC="http://www.skinbase.org/gfx/partners/linkus.jpg" WIDTH=88 HEIGHT=31 BORDER=0></A>
      </P>
      <BR>
      <?echo _DESCRIPTION;?><BR>
      <TEXTAREA NAME="desc"></TEXTAREA>
      <BR>
      <BR>

	<?echo _AFFILIATES;?><BR>
	<select name="afil">
	 <option value="0"> no</option>
	 <option value="1"> yes</option>
	</select><BR>

	<?echo _GFX;?><BR>
	<select name="gfx">
	 <option value="0"> no</option>
	 <option value="1"> yes</option>
	</select><BR>
	
	<BR>
        <input type="hidden" name="action" value="add"><BR><BR>
        <input type="hidden" name="confirm" value="true">
        <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
        </FORM>
       </TD>
      </TR>
    </TABLE> 
   <?
  }
 if ($confirm == "true") 
   {
    $desc = ereg_replace( "\"","&quot;",$desc);
    $desc = ereg_replace( "'","&acute",$desc);

    $res = mysql_query("INSERT INTO $db_partners VALUES (0,'$name','$link','$picture','$desc',0,0,'$afil','$gfx')") or die("mysql error"); 
    ShowMain();
   } 
}


function DeletePartners()
 {
 global $color01,$color02,$color03,$color04,$color05;
 global $id,$confirm,$question,$answers,$login,$partners_path,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("partner_del") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}


 if ($confirm == "true") 
  {
   $get = mysql_query("SELECT * FROM $db_partners where id='$id'");
   $ds = mysql_fetch_array($get);
   $res = mysql_query("DELETE FROM $db_partners where id='$id'"); ShowMain();include("footer.php");exit();
  }
 
 if ($confirm == "false"){ShowMain();}
 
 if ($confirm == "")
  {
?>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD WIDTH=20>
    <A HREF="<?echo $PHP_SELF;?>"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Main Menu"></A>
   </TD>
   <TD>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A>
   </TD>
   <TD ALIGN=RIGHT>
    <?
     $res = mysql_query("SELECT id from $db_partners");
     $num = mysql_num_rows($res);
     echo _OURPARTNERS.": ".$num;
    ?>
   </TD>
  </TR>
 </TABLE>
<BR>
<TABLE CELLSPACING=2 CELLPADDING=2><TR><TD VALIGN=TOP CLASS=MojText>
<?
   $res = mysql_query("SELECT * from $db_partners where id='$id'");
   $ar = mysql_fetch_array($res);
   echo "Name: $ar[name]<BR>";
   echo "Link : $ar[link]<BR>";
?>
</TD></TR></TABLE>
<TABLE CELLSPACING=2 CELLPADDING=2><TR><TD VALIGN=TOP>
 <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="image" SRC="gfx/survey.gif" ALT="<?echo _KEEPIT;?>" BORDER=0 WIDTH=24 HEIGHT=24><BR>
  <INPUT TYPE="hidden" name="action" value="delete">
  <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
  <INPUT TYPE="hidden" name="confirm" value="false"></FORM>
</TD><TD VALIGN=TOP>
  <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="image" SRC="gfx/trash.gif" ALT="<?echo _DELETEIT;?>" BORDER=0 WIDTH=16 HEIGHT=16><BR>
  <INPUT TYPE="hidden" name="action" value="delete">
  <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
  <INPUT TYPE="hidden" name="confirm" value="true">
  </FORM>
</TD></TR></TABLE>
<?
 }
 }

function UploadPicture()
{
 global $login,$action,$filename,$filename_name,$check,$partners_path,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("partner_ul") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}


if ($check <> "UploadSkin")
 {?>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A><BR>
    <FONT SIZE=5 FACE=Arial><B><?echo _ADDPARTNERS;?><B></FONT><BR>
    <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
     <TR>
      <TD CLass=MojText>
       <FORM ENCTYPE="multipart/form-data" METHOD=POST ACTION="">
       <?echo _IMAGE;?>:<BR><INPUT TYPE="FILE" NAME="filename" size="50"><BR>
       <input type="hidden" name="action" value="upload"><BR>
       <input type="hidden" name="check" value="UploadSkin"><BR>
       <INPUT TYPE=SUBMIT VALUE="<?echo _SUBMIT;?>">
       </FORM>
      </TD>
     </TR>
    </TABLE>
  <?}

 if ($check == "UploadSkin")
{
  $newfile = "$partners_path/$filename_name";
  if (!copy($filename,$newfile)) {"Error Uploading File.";}
  echo _SUCCESS;
} 
}
  if ($psw == TRUE)
   {
    if ($action == "")       { ShowMain();       }
    if ($action == "edit")   { EditPartners();   }
    if ($action == "add")    { AddPartners();    }
    if ($action == "delete") { DeletePartners(); }
    if ($action == "upload") { UploadPicture();  }
    if ($action == "logout") { Logout();         }
   }
  include ("footer.php");
 ?>
