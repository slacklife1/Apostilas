<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 27th.May,2002                                                           **
  //******************************************************************************************

  $title = "phpNewsManager $newman_ver";
  $makejs = "category";
  include "colors.php";
  include "functions.php";
  include "header.php";
 
function ShowMain()
{
 global $color01,$color02,$color03,$color04,$color05,$login;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
 ?>
 
 <A HREF="?action=add"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Post news"><?echo _ADDCATEGORY;?></A> | <A HREF="?action=upload"><?echo _UPLOADLOGO;?></A>

 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=1>
  <TR BGCOLOR=#<?echo $color02;?> CLASS=MojText>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _OPTIONS;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _IMAGE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _NAME;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _NUMBER;?></FONT></TD>
  </TR CLASS=MojText>  
    <?php
    $res = mysql_query("SELECT * from $db_topic");
    while ($ar = mysql_fetch_array($res))
     {
      $res2 = mysql_query("SELECT * from $db_news where category = $ar[id]");
      $num = mysql_num_rows($res2);

      echo "
   	    <TR CLASS=MojText>
 	    <TD WIDTH=80 VALIGN=TOP>
 	     <A HREF=?action=edit&id=$ar[id]><IMG SRC=gfx/notes16.gif BORDER=0></A> 
 	     <A HREF=?action=delete&id=$ar[id]><IMG SRC=gfx/trash.gif BORDER=0></A>
 	    </TD> 
	    <TD VALIGN=TOP WIDTH=100><IMG HEIGHT=26 SRC=\"./topic/$ar[topicimage]\"></TD>
	    <TD VALIGN=TOP>$ar[topictext]</TD>
	    <TD VALIGN=TOP>$num</TD>
 	 </TR> ";
   }
 echo "</TABLE>";
}

function EditCategory()
{
 global $color01,$color02,$color03,$color04;
 global $id,$topicimage,$topictext,$confirm,$topic_path,$login,$picture,$topic_path,$topic_url,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("cat_edit") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm <> "true") 
  {
   $res = mysql_query("SELECT * from $db_topic where id='$id'");
   $ar = mysql_fetch_array($res);
   $ar[topictext] = ereg_replace( "&quot;","\"",$ar[topictext]);
   $ar[topictext] = ereg_replace( "&acute;","'",$ar[topictext]);
   ?>
   <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A><BR>
   <FONT SIZE=5 FACE=Arial><B><?echo _EDITCATEGORY;?><B></FONT><BR>
   <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
    <TR>
     <TD Class=MojText>
      <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST" NAME="forma">
       <?echo _CATEGORYNAME;?>:<BR>
       <INPUT TYPE="text" NAME="topictext" value="<?echo $ar[topictext];?>" SIZE=60><BR>
        <?echo _IMAGE;?><BR>
       <select name="picture" size=8 onClick="Swap();">
       <?
        $d = dir($topic_path);
        $x=0;
	while($entry=$d->read()) {$x++;if ($x > 2) 
	{
	 echo "<option value=\"$entry\""; if ($entry == $ar[topicimage]){echo " selected ";};echo ">$entry</option>";}
	}
        $d->close();
       ?>
       </SELECT>
      <P>
      <IMG NAME="button" SRC="http://www.skinbase.org/gfx/topic/<?echo $ar[topicimage];?>" BORDER=0></A>
      </P>

       <input type="hidden" name="id" value="<?echo $id;?>">
       <input type="hidden" name="action" value="edit">
       <input type="hidden" name="confirm" value="true">
       <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
      </FORM>
     </TD>
    </TR>
   </TABLE> 
   <?
  }
 if ($confirm == "true") 
  {
   $topictext = ereg_replace( "'", "&acute;",$topictext);
   $topictext = ereg_replace( "\"", "&quot;",$topictext);
   $res = mysql_query("UPDATE $db_topic SET topicimage='$picture', topictext='$topictext' WHERE id='$id'") or die ("<B>Error4:</B> Invalid query"); 
   ShowMain();
  } 
}

function DeleteCategory()
 {
 global $color01,$color02,$color03,$color04,$color05;
 global $id,$topicimage,$topictext,$confirm,$topic_path,$login,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("cat_del") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm == "true") {$res = mysql_query("DELETE FROM $db_topic where id='$id'"); ShowMain();exit();}
 if ($confirm == "false"){ShowMain();}
 if ($confirm == "")
  {
?>
 <A HREF="<?echo $PHP_SELF;?>?action=add"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Post news"><?echo _ADDCATEGORY;?></A>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=1>
  <TR BGCOLOR=#<?echo $color02;?> CLASS=MojText>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _IMAGE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _NAME;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _NUMBER;?></FONT></TD>
  </TR>  
    <?php
    $res = mysql_query("SELECT * from $db_topic where id='$id'");
    $ar = mysql_fetch_array($res);
    echo "
  	    <TR CLASS=MojText>
	    <TD VALIGN=TOP WIDTH=100><IMG SRC=\"topic/$ar[topicimage]\"></TD>
	    <TD VALIGN=TOP><FONT SIZE=3>$ar[topictext]</FONT></TD>
	    <TD VALIGN=TOP>$num</TD>
 	 </TR> ";
  echo "</TABLE>";
?>  
<TABLE CELLSPACING=2 CELLPADDING=2><TR><TD VALIGN=TOP>
 <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="image" SRC="gfx/survey.gif" ALT="<?echo _KEEPIT;?>" BORDER=0 WIDTH=24 HEIGHT=24><BR>
  <INPUT TYPE="hidden" name="action" value="delete">
  <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
  <INPUT TYPE="hidden" name="confirm" value="false"></FORM>
</TD><TD VALIGN=TOP>
  <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="image" SRC="gfx/trash.gif" ALT="<?echo _DELETEIT;?>" BORDER=0 WIDTH=16 HEIGHT=16><BR>
  <INPUT TYPE="hidden" name="action" value="delete">
  <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
  <INPUT TYPE="hidden" name="confirm" value="true">
  </FORM>
</TD></TR></TABLE>
<?
 }
 }

// ************ ADD CATEGORY **************
function AddCategory()
{
 global $color01,$color02,$color03,$color04;
 global $topicimage,$topictext,$login,$topic_path,$picture,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
 
 // CHECK PRIVILEGIES
 if(CheckPriv("cat_add") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($topictext <> "")
  {
   $res2 = mysql_query("SELECT * FROM $db_topic WHERE topictext = '$topictext'");
   if(mysql_num_rows($res2)==0) {$res = mysql_query("INSERT INTO $db_topic VALUES(0,'$picture','$topictext','0')") or die ("<B>Error5:</B> Invalid Query");}
   ShowMain();
   return 0;
  }
 if ($topictext == "")
  { 
   ?>
   <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A> :<BR>
   <FONT SIZE=5 FACE=Arial><B><?echo _ADDCATEGORY;?><B></FONT><BR>
   <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
    <TR>
     <TD CLass=MojText>
      <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST" NAME="forma">
       <?echo _CATEGORYNAME;?>:<BR>
       <INPUT TYPE="text" NAME="topictext" value="<?echo $topictext;?>" SIZE=60><BR>
        <?echo _IMAGE;?><BR>
       <select name="picture" size=8 onClick="Swap();">
       <?
        $d = dir($topic_path);
        $x=0;
	while($entry=$d->read()) {$x++;if ($x > 2) {echo "<option value=\"$entry\""; if ($entry == $ar[topicimage]){echo " selected ";};echo ">$entry</option>";}}
        $d->close();
       ?>
       </SELECT>
       <P>
      <IMG NAME="button" SRC="http://www.skinbase.org/gfx/partners/linkus.jpg" BORDER=0></A>
      </P>
      <BR>
       <input type="hidden" name="action" value="add"><BR><BR>
       <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
      </FORM>
     </TD>
    </TR>
   </TABLE> 
  <?
 } 
}


function UploadPicture()
{
 global $login,$action,$filename,$filename_name,$check,$topic_path,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("cat_ul") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}


if ($check <> "UploadSkin")
 {?>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A><BR>
    <FONT SIZE=5 FACE=Arial><B><?echo _UPLOADPICTURE;?><B></FONT><BR>
    <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
     <TR>
      <TD CLass=MojText>
       <FORM ENCTYPE="multipart/form-data" METHOD=POST ACTION="<?echo $PHP_SELF;?>">
       <?echo _IMAGE;?>:<BR><INPUT TYPE="FILE" NAME="filename" size="50"><BR>
       <input type="hidden" name="action" value="upload"><BR>
       <input type="hidden" name="check" value="UploadSkin"><BR>
       <INPUT TYPE=SUBMIT VALUE="<?echo _SUBMIT;?>">
       </FORM>
      </TD>
     </TR>
    </TABLE>
  <?}

 if ($check == "UploadSkin")
 {
  $newfile = "$topic_path/$filename_name";
  if (!copy($filename,$newfile)) {"Error Uploading File.";}
  echo _SUCCESS;
 } 
}

if ($psw == 1)
 {
  if ($action == "")       { ShowMain();       }
  if ($action == "edit")   { EditCategory();   }
  if ($action == "delete") { DeleteCategory(); }
  if ($action == "add")    { AddCategory();    }
  if ($action == "upload") { UploadPicture();  }
 }
include ("footer.php");
?>
