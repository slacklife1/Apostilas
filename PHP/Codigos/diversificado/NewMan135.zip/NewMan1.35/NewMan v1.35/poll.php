<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 11th.June,2002                                                           **
  //******************************************************************************************
  
  $title    = "phpNewsManager $newman_ver";
  include ("colors.php");
  include "functions.php";

function ShowMain()
 {
  global $color01,$color02,$color03,$color04,$color05;
  global $page,$PHP_SELF,$id,$db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged;
  global $db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

  $res = mysql_query("SELECT * from $db_weekQ order by id desc");
  $num = mysql_num_rows($res);

  $m=0;
  if (empty($page)) {$page=1;}    
  $hits=50;
  $stw2 = ($num/$hits);
  $stw2 = (int) $stw2;
  if ($num%$hits > 0) {$stw2++;}
  $np = $page+1;
  $pp = $page-1;
  if ($page == 1) { $pp=1; }
  if ($np > $stw2) { $np = $stw2;} 
    
  $sp=($page-1)*$hits;
  $ep=($page-1)*$hits+$hits;


  ?>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD WIDTH=20>
    <IMG SRC="gfx/docman.gif" BORDER=0 ALT="<?echo _ADDWEEKLYPOLL;?>">
   </TD>
   <TD>
    <A HREF="<?echo $PHP_SELF;?>?action=add"><?echo _ADDWEEKLYPOLL;?></A>
   </TD>
   <TD>
    <?echo _SELECTPAGE;?>: <?for ($i=1;$i<=$stw2;$i++) {if($page==$i){echo "<B>$i</B>";} else{echo " <A HREF=\"?page=$i\">$i</A> ";}}?>
   </TD>
   <TD ALIGN=RIGHT>
    <?
     echo _SUBMITEDPOLLS.": ".$num;
    ?>
   </TD>
  </TR>
 </TABLE>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=1 CLASS=MojText>
  <TR BGCOLOR=#<?echo $color02;?>>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _OPTIONS;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _QUESTION;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _AUTHOR;?></FONT></TD>
  </TR>  
<?
    while ($ar = mysql_fetch_array($res))
     {
      $m++;
      if($m>$sp and $m<$ep)
      {      
       $res2 = mysql_query("SELECT * from $db_weekQ order by id desc");
       $ar2 = mysql_fetch_array($res2);
       if(mysql_num_rows($res2) <> 0)
       {
        echo "
 	<TR>
 	<TD WIDTH=80><A HREF=?action=open&id=$ar[id]><IMG SRC=gfx/ofolder15.gif BORDER=0></A> <A HREF=?action=edit&id=$ar[id]><IMG SRC=gfx/notes16.gif BORDER=0></A> <A HREF=?action=delete&id=$ar[id]><IMG SRC=gfx/trash.gif BORDER=0></A></TD> 
        <TD>$ar[question]</TD>
  	<TD ALIGN=RIGHT VALIGN=TOP>$ar[author]</TD>
 	</TR> ";
	if ($id == $ar[id])
	{
	 echo "<TR><TD COLSPAN=3 STYLE=\"padding-left:90px;\">";
	 $myvote = mysql_query("select count(*) as suma from $db_weekA where wid=$id");
         $myvres = mysql_fetch_array($myvote);
	 echo _ANSWERS.":<BR>";
         $gres = mysql_query("SELECT * FROM $db_weekQ where id=$id"); 
         $gar = mysql_fetch_array($gres);
         $odg = explode (":", $gar[2]);
         while ( list ($key,$values)= each($odg))
         {
          $myres = mysql_query("select count(*) as vote from $db_weekA where wid=$id and answer=$key;");
          $myar  = mysql_fetch_array($myres);
          echo "$values: $myar[vote] ";
          if($myar[vote] <> 0 and $myvres[suma] <> 0) {$procent = $myar[vote]/$myvres[suma]*100;} else {$procent=0;}
          printf (" [%.2f",$procent);
          echo "%]<BR>";
         }
        echo "</TD></TR>";
       }
      }
     }
  }
  echo "</TABLE>";
  echo "<CENTER><A HREF=\"?page=$pp\">"._PREVIOUS."</A> <--|--> <A HREF=\"?page=$np\">"._NEXT."</A></CENTER>";
 }

function EditPoll()
{
 global $color01,$color02,$color03,$color04;
 global $id,$confirm,$question,$answers,$login,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("wp_edit") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm <> "true") 
   {
    $res = mysql_query("SELECT * from $db_weekQ where id='$id'");
    $ar = mysql_fetch_array($res);

    $ar[question] = ereg_replace( "&quot;","\"",$ar[question]);
    $ar[question] = ereg_replace( "&acute","'",$ar[question]);

    $ar[answer] = ereg_replace( "&quot;","\"",$ar[answer]);
    $ar[answer] = ereg_replace( "&acute","'",$ar[answer]);
    ?>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A><BR>
    <FONT SIZE=5 FACE=Arial><B><?echo _EDITWEEKLYPOLL;?><B></FONT><BR>
    <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
     <TR>
      <TD CLass=MojText>
       <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
        <?echo _QUESTION;?><BR>
        <INPUT TYPE="text" NAME="question" SIZE=60 VALUE="<?echo $ar[question];?>"><BR>
        <?echo _ANSWERS;?> [<SMALL><?echo _SEPERATEANSWERSWITH;?> :</SMALL>]<BR>
        <INPUT TYPE="text" NAME="answers" SIZE=60 VALUE="<?echo $ar[answers];?>"><BR>
        <input type="hidden" name="action" value="edit"><BR><BR>
        <input type="hidden" name="confirm" value="true">
        <input type="hidden" name="id" value="<?echo $id;?>">
        <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
        </FORM>
       </TD>
      </TR>
    </TABLE> 
   <?
  }
 if ($confirm == "true") 
   {
    $question = ereg_replace( "\"","&quot;",$question);
    $question = ereg_replace( "'","&acute",$question);

    $answers = ereg_replace( "\"","&quot;",$answers);
    $answers = ereg_replace( "'","&acute;",$answers);

    $res = mysql_query("UPDATE $db_weekQ SET question='$question', answers='$answers' WHERE id=$id"); 
    ShowMain();
   } 
}

function AddPoll()
{
 global $color01,$color02,$color03,$color04;
 global $id,$confirm,$question,$answers,$login,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("wp_add") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm <> "true") 
   {
    ?>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A><BR>
    <FONT SIZE=5 FACE=Arial><B><?echo _ADDWEEKLYPOLL;?><B></FONT><BR>
    <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
     <TR>
      <TD CLass=MojText>
       <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
        <?echo _QUESTION;?><BR>
        <INPUT TYPE="text" NAME="question" SIZE=60><BR>
        <?echo _ANSWERS;?> [<SMALL><?echo _SEPERATEANSWERSWITH;?> :</SMALL>]<BR>
        <INPUT TYPE="text" NAME="answers" SIZE=60><BR>
        <input type="hidden" name="action" value="add"><BR><BR>
        <input type="hidden" name="confirm" value="true">
        <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
        </FORM>
       </TD>
      </TR>
    </TABLE> 
   <?
  }
 if ($confirm == "true") 
   {
    $question = ereg_replace( "\"","&quot;",$question);
    $question = ereg_replace( "'","&acute",$question);

    $answers = ereg_replace( "\"","&quot;",$answers);
    $answers = ereg_replace( "'","&acute",$answers);

    $res = mysql_query("INSERT INTO $db_weekQ VALUES (0,'$question','$answers','$login')") or die("mysql error"); 
    ShowMain();
   } 
}


function DeletePoll()
 {
 global $color01,$color02,$color03,$color04,$color05;
 global $id,$confirm,$question,$answers,$login,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("wp_del") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm == "true") 
  {
   $get = mysql_query("SELECT * FROM $db_weekQ where id='$id'");
   $ds = mysql_fetch_array($get);
   $res = mysql_query("DELETE FROM $db_weekQ where id='$id'"); ShowMain();include("footer.php");exit();
  }
 
 if ($confirm == "false"){ShowMain();}
 
 if ($confirm == "")
  {
?>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD WIDTH=20>
    <A HREF="<?echo $PHP_SELF;?>"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="<?echo _MAINMENU;?>"></A>
   </TD>
   <TD>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A>
   </TD>
   <TD ALIGN=RIGHT>
    <?
     $res = mysql_query("SELECT id from $db_weekQ");
     $num = mysql_num_rows($res);
     echo _SUBMITEDPOLLS.": ".$num;
    ?>
   </TD>
  </TR>
 </TABLE>
<BR>
<TABLE CELLSPACING=2 CELLPADDING=2><TR><TD VALIGN=TOP CLASS=MojText>
<?
   $res = mysql_query("SELECT * from $db_weekQ where id='$id'");
   $ar = mysql_fetch_array($res);
   echo "Question: $ar[question]<BR>";
   echo "Answers : $ar[answers]<BR>";
?>
</TD></TR></TABLE>
<TABLE CELLSPACING=2 CELLPADDING=2><TR><TD VALIGN=TOP>
 <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="image" SRC="gfx/survey.gif" ALT="<?echo _KEEPIT;?>" BORDER=0 WIDTH=24 HEIGHT=24><BR>
  <INPUT TYPE="hidden" name="action" value="delete">
  <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
  <INPUT TYPE="hidden" name="confirm" value="false"></FORM>
</TD><TD VALIGN=TOP>
  <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="image" SRC="gfx/trash.gif" ALT="<?echo _DELETEIT;?>" BORDER=0 WIDTH=16 HEIGHT=16><BR>
  <INPUT TYPE="hidden" name="action" value="delete">
  <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
  <INPUT TYPE="hidden" name="confirm" value="true">
  </FORM>
</TD></TR></TABLE>
<?
 }
 }
?>

<?include ("header.php");
  if ($psw == TRUE)
   {
    if ($action == "")       { ShowMain();   }
    if ($action == "edit")   { EditPoll();   }
    if ($action == "add")    { AddPoll();    }
    if ($action == "delete") { DeletePoll(); }
    if ($action == "open")   { ShowMain();   }
    if ($action == "logout") { Logout();     }
   }
  include ("footer.php");
 ?>
