<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 27th.May,2002                                                           **
  //******************************************************************************************

 $logo = "gfx/logos.jpg";

 $color01     = "000000";
 $color02     = "9EC5E4"; // ZGORNJI SPODNJI OKVIR
 $color03     = "888899"; // TEXT ZGORAJ IN V OKVIRJIH
 $color04     = "CCCCDD"; // BARVA OKVIRJA
 $color05     = "000000"; // FONT COLOR V BOXIH
 $color06     = "FEFEFF"; // OZADJE
 $color_text  = "000000";
 $color_link  = "0E2544";
 $color_vlink = "0E2544";
 $color_alink = "0E2544";
 $color_back  = "ffffff";
?>