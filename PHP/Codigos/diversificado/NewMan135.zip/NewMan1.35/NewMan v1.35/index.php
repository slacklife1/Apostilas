<?php
  //******************************************************************************************
  //** phpNewsManager                                                                       **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 7th.June,2002                                                           **
  //******************************************************************************************

// LOGOUT FUNCTION
if ($action == "Logout")
{
 $info = "0:0";
 setcookie("nm_user","$info",time()+15552000); // 6 mo is 15552000
 $nm_user = "";
 header ("Location: index.php"); 
}

  $title    = "phpNewsManager $newman_ver";
  include ("colors.php");
  include "functions.php";
  include("header.php");

if ($psw == TRUE)
{
 ?>
 <TABLE WIDTH=630 HEIGHT=100% CELLSPACING=0 CELLPADDING=0 BORDER=0>
  <TR>
   <TD CLASS=MojText VALIGN=TOP>

     <TABLE WIDTH=99% CELLSPACING=1 CELLPADDING=5 CLASS=MojText>
      <TR VALIGN=TOP>
       <TD WIDTH=90% VALIGN=TOP>
        <FONT FACE=ARIAL SIZE=2>
        <STRONG><?echo _STATISTICS;?></STRONG><BR><BR>
        <?
            $res1 = mysql_query("SELECT count(*) from $db_news") or die("error1");
            $ar1 = mysql_fetch_array($res1);
            $res2 = mysql_query("SELECT count(*) from $db_news_comments") or die("error2");
            $ar2 = mysql_fetch_array($res2);
            $res3 = mysql_query("SELECT count(*) from $db_weekQ") or die("error3");
            $ar3 = mysql_fetch_array($res3);
            $res4 = mysql_query("SELECT count(*) from $db_weekA") or die("error4");
            $ar4 = mysql_fetch_array($res4);
            $res5 = mysql_query("SELECT count(*) from $db_pnews") or die(myError());
            $ar5 = mysql_fetch_array($res5);
            $res6 = mysql_query("SELECT count(*) from $db_users") or die(myError());
            $ar6 = mysql_fetch_array($res6);

         if(empty($ar1[0])) {$ar1[0]=0;}
         if(empty($ar2[0])) {$ar2[0]=0;}
         if(empty($ar3[0])) {$ar3[0]=0;}
         if(empty($ar4[0])) {$ar4[0]=0;}
         if(empty($ar5[0])) {$ar5[0]=0;}
         if(empty($ar6[0])) {$ar6[0]=0;}

         $nfo = mysql_query("SELECT info FROM $db_admin where uname='$login'") or die(myError());;
         $inf=mysql_fetch_array($nfo);
         $lst = explode("#", $inf[0]);
           ?>
        <BR>
           <TABLE CLASS=MojText2 CELLSPACING=1 CELLPADDING=5 BGCOLOR=#DDDDDD ALIGN=CENTER>
        <TR BGCOLOR=#EEEEEE><TD><?echo _STATISTICS;?></TD><TD><?echo _ACTUAL;?></TD><TD><?echo _LASTVISIT;?></TD><TD><?echo _NEW;?></TD></TR>

           <TR BGCOLOR=#FFFFFF><TD><?echo _ONLINENEWS;?>:</TD><TD ALIGN=RIGHT> <B><?echo $ar1[0];?></B></TD><TD ALIGN=RIGHT><B><?echo $lst[0];?></B></TD><TD ALIGN=RIGHT><B><?echo $ar1[0]-$lst[0];?></B></TD></TR>
           <TR BGCOLOR=#FFFFFF><TD><?echo _NEWSCOMMENTS;?>:</TD><TD ALIGN=RIGHT> <B><?echo $ar2[0];?></B></TD><TD ALIGN=RIGHT><B><?echo $lst[1];?></B></TD><TD ALIGN=RIGHT><B><?echo $ar2[0]-$lst[1];?></B></TD></TR>
           <TR BGCOLOR=#FFFFFF><TD><?echo _WEEKLYPOLLQ;?>:</TD><TD ALIGN=RIGHT> <B><?echo $ar3[0];?></B></TD><TD ALIGN=RIGHT><B><?echo $lst[2];?></B></TD><TD ALIGN=RIGHT><B><?echo $ar3[0]-$lst[2];?></B></TD></TR>
           <TR BGCOLOR=#FFFFFF><TD><?echo _WEEKLYPOLLA;?>:</TD><TD ALIGN=RIGHT> <B><?echo $ar4[0];?></B></TD><TD ALIGN=RIGHT><B><?echo $lst[3];?></B></TD><TD ALIGN=RIGHT><B><?echo $ar4[0]-$lst[3];?></B></TD></TR>
           <TR BGCOLOR=#FFFFFF><TD><?echo _PUBLICNEWS;?>:</TD><TD ALIGN=RIGHT> <B><?echo $ar5[0];?></B></TD><TD ALIGN=RIGHT><B><?echo $lst[4];?></B></TD><TD ALIGN=RIGHT><B><?echo $ar5[0]-$lst[4];?></B></TD></TR>
           <TR BGCOLOR=#FFFFFF><TD><?echo _REGISTEREDUSERS;?>:</TD><TD ALIGN=RIGHT> <B><?echo $ar5[0];?></B></TD><TD ALIGN=RIGHT><B><?echo $lst[5];?></B></TD><TD ALIGN=RIGHT><B><?echo $ar6[0]-$lst[5];?></B></TD></TR>
        </TABLE>
        <BR>
        </FONT>
       </TD>
      </TR>
     </TABLE>

     <?mysql_query("UPDATE $db_admin SET info='$ar1[0]#$ar2[0]#$ar3[0]#$ar4[0]#$ar5[0]#$ar6[0]' where uname='$login'");?>

   </TD>
  </TR>
 </TABLE>
 <?
  }
  include ("footer.php");
 ?>