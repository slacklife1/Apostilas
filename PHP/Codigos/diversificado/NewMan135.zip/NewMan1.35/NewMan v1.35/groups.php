<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 27th.May,2002                                                           **
  //******************************************************************************************

  $title    = "phpNewsManager $newman_ver";
  include ("colors.php");
  include "functions.php";

function ShowMain()
 {
  global $color01,$color02,$color03,$color04,$color05,$PHP_SELF;
  global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
  ?>
 <TABLE WIDTH=630 ALIGN=CENTER CELLSPACING=2 CELLPADDING=1 CLASS=MojText>
  <TR>
   <TD WIDTH=20>
    <A HREF="<?echo $PHP_SELF;?>?action=add"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="<?echo _ADDGROUP;?>"></A>
   </TD>
   <TD>
    <A HREF="?action=add"><?echo _ADDGROUP;?></A>
   </TD>
   <TD ALIGN=RIGHT>
    <?
     $res = mysql_query("SELECT * from $db_groups") or die("<B>Error ".mysql_error_num()."</B>:".mysql_error());
     $num = mysql_num_rows($res);
     echo _REGISTEREDUSERS.": ".$num;
    ?>
   </TD>
  </TR>
 </TABLE>
 <TABLE WIDTH=630 ALIGN=CENTER CELLSPACING=2 CELLPADDING=1>
  <TR BGCOLOR=#<?echo $color02;?> CLASS=MojText>
   <TD WIDTH=60><FONT COLOR=#<?echo $color05;?>><?echo _OPTIONS;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _GROUPNAME;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _USERS;?></FONT></TD>
  </TR>  
  <?
   $res = mysql_query("SELECT * from $db_groups") or die(myError());
   while ($ar = mysql_fetch_array($res))
   {
    $res2 = mysql_query("SELECT count(*) as num from $db_admin where priv='$ar[id]'") or die("<B>Error:</B>".mysql_error());
    $ar2 = mysql_fetch_array($res2);
    echo "
 	 <TR CLASS=MojText>
 	  <TD><A HREF=?action=edit&id=$ar[id]><IMG SRC=gfx/notes16.gif BORDER=0></A> <A HREF=?action=delete&id=$ar[id]><IMG SRC=gfx/trash.gif BORDER=0></A></TD> 
  	  <TD VALIGN=TOP>$ar[name]</TD>
  	  <TD VALIGN=TOP>$ar2[num]</TD>
 	 </TR> ";
  }
 echo "</TABLE>";
}

function EditGroup()
{
 global $color01,$color02,$color03,$color04;
 global $id,$confirm,$login,$PHP_SELF;
 global $news_add,$news_edit,$news_del,$grp_name,$desc,$admin_add,$admin_edit,$admin_del;
 global $pnews_add,$pnews_edit,$pnews_del,$pnews_submit,$cat_add,$cat_ul,$cat_edit,$cat_del,$users_add;
 global $users_edit,$users_del,$partner_add,$partner_edit,$partner_del,$partner_ul,$wp_add,$wp_edit,$wp_del;
 global $groups_add,$groups_edit,$groups_del,$smiley_add,$smiley_edit,$smiley_del,$smiley_ul,$rss_edit;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("group_edit") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm <> "true") 
   {
    $res = mysql_query("SELECT * from $db_groups where id='$id'");
    $ar = mysql_fetch_array($res);
    ?>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A> :<BR>
    <FONT SIZE=5 FACE=Arial><B><?echo _EDITUSER;?><B></FONT><BR>
    <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
     <TR>
      <TD Class=MojText>

      <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
        <?echo _GROUPNAME;?><BR>
        <INPUT TYPE="text" NAME="grp_name" VALUE="<?echo $ar[1];?>" SIZE=40"><BR>
        <?echo _INFO;?><BR>
        <INPUT TYPE="text" NAME="desc" VALUE="<?echo $ar[2];?>" SIZE=40><BR>
        <?echo _SELECT;?>:<BR>
        <TABLE CELLSPACING=2 CELLPADDING=2 CLASS=MojText BGCOLOR=#9999AA>
         <TR BGCOLOR=#888899>
          <TD><?echo _MODIFY;?></TD>
          <TD><?echo _ADD;?></TD>
          <TD><?echo _EDIT;?></TD>
          <TD><?echo _DELETE;?></TD>
          <TD><?echo _SUBMIT;?>/<?echo _UPLOAD;?></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _NEWS;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="news_add"   VALUE="1" <?if ($ar[news_add]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="news_edit"  VALUE="1" <?if ($ar[news_edit]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="news_del"   VALUE="1" <?if ($ar[news_del]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _ADMIN;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=admin_add   VALUE="1" <?if ($ar[admin_add]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=admin_edit  VALUE="1" <?if ($ar[admin_edit]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=admin_del   VALUE="1" <?if ($ar[admin_del]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _PUBLICNEWS;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=pnews_add   VALUE="1" <?if ($ar[pnews_add]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=pnews_edit  VALUE="1" <?if ($ar[pnews_edit]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=pnews_del   VALUE="1" <?if ($ar[pnews_del]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=pnews_submit VALUE="1" <?if ($ar[pnews_submit ]==1){echo "CHECKED";}?>></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _CATEGORY;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="cat_add"   VALUE="1" <?if ($ar[cat_add]==1) {echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="cat_edit"  VALUE="1" <?if ($ar[cat_edit]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="cat_del"   VALUE="1" <?if ($ar[cat_del]==1) {echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="cat_ul"    VALUE="1" <?if ($ar[cat_ul]==1)  {echo "CHECKED";}?>></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _USERS;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="users_add"   VALUE="1" <?if ($ar[users_add]==1) {echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="users_edit"  VALUE="1" <?if ($ar[users_edit]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="users_del"   VALUE="1" <?if ($ar[users_del]==1) {echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _PARTNERS;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=partner_add   VALUE="1" <?if ($ar[partner_add]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=partner_edit  VALUE="1" <?if ($ar[partner_edit]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=partner_del   VALUE="1" <?if ($ar[partner_del]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=partner_ul   VALUE="1" <?if ($ar[partner_ul]==1){echo "CHECKED";}?>></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _WEEKLYPOLL;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=wp_add   VALUE="1" <?if ($ar[wp_add]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=wp_edit  VALUE="1" <?if ($ar[wp_edit]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=wp_del   VALUE="1" <?if ($ar[wp_del]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _GROUPS;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=groups_add   VALUE="1" <?if ($ar[group_add]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=groups_edit  VALUE="1" <?if ($ar[group_edit]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=groups_del   VALUE="1" <?if ($ar[group_del]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _SMILEYS;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="smiley_add"   VALUE="1" <?if ($ar[smiley_add]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="smiley_edit"  VALUE="1" <?if ($ar[smiley_edit]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="smiley_del"   VALUE="1" <?if ($ar[smiley_del]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="smiley_ul"   VALUE="1" <?if ($ar[smiley_ul]==1){echo "CHECKED";}?>></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _RSS;?></TD>
          <TD ALIGN=CENTER></TD>
          <TD ALIGN=CENTER><input type="checkbox" name="rss_edit"  VALUE="1" <?if ($ar[rss_edit]==1){echo "CHECKED";}?>></TD>
          <TD ALIGN=CENTER></TD>
          <TD ALIGN=CENTER></TD>
         </TR>

        </TABLE>
        <BR>
        <input type="hidden" name="action" value="edit"><BR><BR>
        <input type="hidden" name="confirm" value="true">
        <input type="hidden" name="id" value="<?echo $id;?>">
        <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
        </FORM>
 
       </TD>
      </TR>
    </TABLE> 
   <?
  }
 if ($confirm == "true") 
   {
    $res = mysql_query("UPDATE $db_groups SET name='$grp_name', description='$desc', news_add='$news_add', news_edit='$news_edit', news_del='$news_del', admin_add='$admin_add', admin_edit='$admin_edit', admin_del='$admin_del', pnews_add='$pnews_add', pnews_edit='$pnews_edit', pnews_del='$pnews_del', pnews_submit='$pnews_submit', cat_add='$cat_add', cat_edit='$cat_edit', cat_del='$cat_del', cat_ul='$cat_ul',users_add='$users_add', users_edit='$users_edit', users_del='$users_del', partner_add='$partner_add', partner_edit='$partner_edit', partner_del='$partner_del', partner_ul='$partner_ul',wp_add='$wp_add', wp_edit='$wp_edit', wp_del='$wp_del', group_add='$groups_add', group_edit='$groups_edit', group_del='$groups_del', smiley_add='$smiley_add', smiley_edit='$smiley_edit', smiley_del='$smiley_del', smiley_ul='$smiley_ul', rss_edit='$rss_edit' WHERE id='$id'") or die ("<B>Error:</B>".mysql_error()); 
    ShowMain();
   } 
 }

function DeleteGroup()
{
 global $color01,$color02,$color03,$color04,$color05;
 global $id,$confirm,$preview,$headline,$message,$section,$login,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("group_del") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}


 if ($confirm == "true") {$res = mysql_query("DELETE FROM $db_groups where id='$id'"); ShowMain();exit();}
 if ($confirm == "false"){ShowMain();}
 if ($confirm == "")
  {
   ?>
   <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
    <TR>
     <TD WIDTH=20>
      <A HREF="<?echo $PHP_SELF;?>"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="<?echo _ADDGROUP;?>"></A>
     </TD>
     <TD>
      <A HREF="<?echo $PHP_SELF;?>?action=add"><?echo _ADDGROUP;?></A>
     </TD>
     <TD ALIGN=RIGHT>
      <?
       $res = mysql_query("SELECT * from $db_groups");
       $num = mysql_num_rows($res);
       echo _REGISTEREDUSERS.": ".$num;
      ?>
     </TD>
    </TR>
   </TABLE>
   <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=1>
    <TR BGCOLOR=#<?echo $color02;?> CLASS=MojText>
     <TD><FONT COLOR=#<?echo $color05;?>><?echo _NAME;?></FONT></TD>
     <TD><FONT COLOR=#<?echo $color05;?>><?echo _PRIVILEGES;?></FONT></TD>
    </TR>  
    <?php
    $res = mysql_query("SELECT * from $db_groups where id='$id'");
    while ($ar = mysql_fetch_array($res))
     {
      echo "
 	 <TR CLASS=MojText>
  	  <TD VALIGN=TOP>$ar[name]</TD>
  	  <TD VALIGN=TOP ALIGN=RIGHT>$ar[name]</TD>
 	 </TR> ";
    }
  echo "</TABLE><BR><BR>";
?>  
<TABLE CELLSPACING=2 CELLPADDING=2>
 <TR>
  <TD VALIGN=TOP>
   <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
   <INPUT TYPE="image" SRC="gfx/survey.gif" ALT="<?echo _KEEPIT;?>" BORDER=0 WIDTH=24 HEIGHT=24><BR>
   <INPUT TYPE="hidden" name="action" value="delete">
   <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
   <INPUT TYPE="hidden" name="confirm" value="false"></FORM>
  </TD>
  <TD VALIGN=TOP>
   <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
    <INPUT TYPE="image" SRC="gfx/trash.gif" ALT="<?echo _DELETEIT;?>" BORDER=0 WIDTH=16 HEIGHT=16><BR>
    <INPUT TYPE="hidden" name="action" value="delete">
    <INPUT TYPE="hidden" name="info" value="<?echo $info;?>">
    <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
    <INPUT TYPE="hidden" name="confirm" value="true">
   </FORM>
  </TD>
 </TR>
</TABLE>
<?}}

function AddGroup()
{
 global $color01,$color02,$color03,$color04;
 global $id,$login,$confirm,$PHP_SELF;
 global $news_add,$news_edit,$news_del,$grp_name,$desc,$admin_add,$admin_edit,$admin_del;
 global $pnews_add,$pnews_edit,$pnews_del,$pnews_submit,$cat_add,$cat_edit,$cat_del,$cat_ul,$users_add;
 global $users_edit,$users_del,$partner_add,$partner_edit,$partner_del,$partner_ul,$wp_add,$wp_edit,$wp_del;
 global $groups_add,$groups_edit,$groups_del,$smiley_add,$smiley_edit,$smiley_ul,$smiley_del,$rss_edit;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
 
 // CHECK PRIVILEGIES
 if(CheckPriv("group_add") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

  
 if ($confirm == "true") 
   {
    $res2 = mysql_query("SELECT * FROM $db_groups WHERE name='$grp_name'");
    if(mysql_num_rows($res2)<1) {$res = mysql_query("INSERT INTO $db_groups VALUES(0,'$grp_name','$desc','$news_add','$news_edit','$news_del','$news_ul','$admin_add','$admin_edit','$admin_del','$pnews_add','$pnews_edit','$pnews_del','$pnews_submit','$cat_add','$cat_edit','$cat_del','$cat_ul','$users_add','$users_edit','$users_del','$partner_add','$partner_edit','$partner_del','$partner_ul','$wp_add','$wp_edit','$wp_del','$groups_add','$groups_edit','$groups_del','$smiley_add','$smiley_edit','$smiley_del','$smiley_ul','$rss_edit')") or die ("<B>Error (279):</B>".mysql_error());}
    ShowMain();
   }
  if ($confirm <> "true")
   { 
    $res = mysql_query("SELECT * from $db_groups where id='$id'");
    $ar = mysql_fetch_array($res);
    ?>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A> :<BR>
    <FONT SIZE=5 FACE=Arial><B><?echo _ADDGROUP;?><B></FONT><BR>
    <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
     <TR>
      <TD Class=MojText>
       <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
        <?echo _GROUPNAME;?>:<BR>
        <INPUT TYPE="text" NAME="grp_name" SIZE=40"><BR>
        <?echo _INFO;?><BR>
        <INPUT TYPE="text" NAME="desc" SIZE=40><BR>
        <?echo _SELECT;?>:<BR>
        <TABLE CELLSPACING=2 CELLPADDING=2 CLASS=MojText BGCOLOR=#9999AA>
         <TR BGCOLOR=#888899>
          <TD><?echo _MODIFY;?></TD>
          <TD><?echo _ADD;?></TD>
          <TD><?echo _EDIT;?></TD>
          <TD><?echo _DELETE;?></TD>
          <TD><?echo _SUBMIT;?>/<?echo _UPLOAD;?></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _NEWS;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=news_add   VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=news_edit  VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=news_del   VALUE="1"></TD>
          <TD ALIGN=CENTER></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _ADMIN;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=admin_add   VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=admin_edit  VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=admin_del   VALUE="1"></TD>
          <TD ALIGN=CENTER></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _PUBLICNEWS;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=pnews_add   VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=pnews_edit  VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=pnews_del   VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=pnews_submit   VALUE="1"></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _CATEGORY;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=cat_add   VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=cat_edit  VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=cat_del   VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=cat_ul    VALUE="1"></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _USERS;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=users_add   VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=users_edit  VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=users_del   VALUE="1"></TD>
          <TD ALIGN=CENTER></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _PARTNERS;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=partner_add   VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=partner_edit  VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=partner_del   VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=partner_ul   VALUE="1"></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _WEEKLYPOLL;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=wp_add   VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=wp_edit  VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=wp_del   VALUE="1"></TD>
          <TD ALIGN=CENTER></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _GROUPS;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=groups_add   VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=groups_edit  VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=groups_del   VALUE="1"></TD>
          <TD ALIGN=CENTER></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _SMILEYS;?></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=smiley_add   VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=smiley_edit  VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=smiley_del   VALUE="1"></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=smiley_ul    VALUE="1"></TD>
         </TR>

         <TR BGCOLOR=#FFFFFF>
          <TD><?echo _RSS;?></TD>
          <TD ALIGN=CENTER></TD>
          <TD ALIGN=CENTER><input type="checkbox" name=rss_edit  VALUE="1"></TD>
          <TD ALIGN=CENTER></TD>
          <TD ALIGN=CENTER></TD>
         </TR>
        </TABLE>
        <BR>
        <input type="hidden" name="action" value="add"><BR><BR>
        <input type="hidden" name="confirm" value="true">
        <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
        </FORM>
       </TD>
      </TR>
    </TABLE> 
 </TABLE> 
 <?
 }}


?>

 <?include ("header.php");
  if ($psw == TRUE)
   {
    if ($action == "")       { ShowMain();   }
    if ($action == "edit")   { EditGroup();   }
    if ($action == "delete") { DeleteGroup(); }
    if ($action == "add")    { AddGroup();    }
   }
  include ("footer.php");
 ?>
