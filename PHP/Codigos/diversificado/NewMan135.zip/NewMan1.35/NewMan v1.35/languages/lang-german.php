<?php
  //******************************************************************************************
  //**                                                                                                           **
  //** phpNewsManager v1.30                                                                        **
  //** contact: gregor@klevze.si                                                                     **
  //** Last edited: 10th.June,2002                                                                   **
  //**                                                                                                            **
  //** Language module: German                                                                   **
  //******************************************************************************************

define("_CHARSET","ISO-8859-1");
define("_STATISTICS","Statistik");
define("_ACTUAL","Momentan");
define("_LASTVISIT","Beim letzten Besuch");
define("_NEW","Neu");
define("_ONLINENEWS","Ver�ffentlichte News-Artikel");
define("_WEEKLYPOLLQ","W�chentl. Umfrage: (Fragen)");
define("_WEEKLYPOLLA","W�chentl. Umfrage: (Antworten)");
define("_PUBLICNEWS","�bermittelte News-Artikel");
define("_REGISTEREDUSERS","Registrierte Benutzer");
define("_NEWSCOMMENTS","News Kommentare");
define("_ADDNEWS","News-Artikel schreiben");
define("_SUBMITEDNEWS","�bermittelte News-Artikel");
define("_OPTIONS","Optionen");
define("_NEWSHEADLINE","News Titel");
define("_AUTHOR","Autor");
define("_DATE","Datum");
define("_SECTION","Sektion");
define("_PREVIEW","Vorschau");
define("_MESSAGE","Inhalt");
define("_SUBMIT","Senden");
define("_HOME","Startseite");
define("_NEWSMANAGER","News Men�");
define("_MODIFYNEWS","News �ndern");
define("_ADDNEWS","News-Artikel hinzuf�gen");
define("_ADDPARTNERS","Partner hinzuf�gen");
define("_UPLOADLOGO","Logo hochladen");
define("_IMAGE","Bild");
define("_NAME","Name");
define("_NUMBER","#");define("_","#");
define("_CATEGORYNAME","Name der Kategorie");
define("_MAINMENU","Hauptmen�");
define("_KEEPIT","Behalten!");
define("_DELETEIT","L�schen!");
define("_EDITCATEGORY","Kategorie editieren");
define("_UPLOADPICTURE","Bild hochladen");
define("_ADDCATEGORY","Kategorie hinzuf�gen");
define("_OURPARTNERS","Unsere Partner");
define("_SELECTPAGE","Seite ausw�hlen");
define("_LINK","Link");
define("_IN","In");
define("_OUT","Out");
define("_AFFILIATES","angeschlossene Partner");
define("_GFX","Grafiken");
define("_PREVIOUS","Zur�ck");
define("_NEXT","N�chste");
define("_DESCRIPTION","Beschreibung");
define("_MODIFYPARTNERS","Partnerdaten editieren");
define("_RSSSETTINGS","RSS Einstellungen");
define("_NAMEOFRSSFILE","Name der RSS Datei");
define("_NUMBEROFNEWS","Nummer des Newsartikels");
define("_RSSTITLE","RSS Titel");
define("_RSSLINK","RSS Link");
define("_RSSDESCRIPTION","RSS Beschreibung");
define("_AUTOCREATERSS","Nach jeder News-�nderung automatisch eine RSS-Datei erzeugen");
define("_OPTIMIZED","optimiert");
define("_OPTIMIZEDATABASE","Datenbank optimieren");
define("_ADDSMILEY","Smiley hinzuf�gen");
define("_UPLOADSMILEY","Smiley hochladen");
define("_SMILEYEMOTION","Emotion");
define("_SMILEYEDITOR","Smiley Editor");
define("_SMILEYCODE","Code");
define("_EDITSMILEY","Smiley editieren");
define("_DELETESMILEY","Smiley l�schen");
define("_NEWS","Alle Newsartikel");
define("_CATEGORY","Kategorien");
define("_PARTNERS","Partner");
define("_WEEKLYPOLL","W�chentl. Umfrage");
define("_SMILEYS","Smileys");
define("_BROWSENEWS","News nach Kategorien geordnet anzeigen");
define("_GROUPS","Gruppen");
define("_ADMINS","Administratoren");
define("_USERS","Benutzer");
define("_USERINFO","Benutzer Info");
define("_ADMINISTRATION","Administration");
define("_YOULOGOUT","Logout erfolgreich.");
define("_LOGIN","Einloggen");
define("_PASSWORD","Passwort");
define("_USERNAME","Benutzername");
define("_WEBCONTROLPANEL","Web Kontrollkonsole");
define("_ADDUSER","Benutzer hinzuf�gen");
define("_EMAIL","Email");
define("_PRIVILEGES","Rechte");
define("_EMAIL","Email");
define("_EDITUSER","Benutzer editieren");
define("_DELETEUSER","Benutzer l�schen");
define("_INFO","Info");
define("_ADDGROUP","Gruppe hinzuf�gen");
define("_ADMIN","Administrator");
define("_RSS","RSS");
define("_MODIFY","�ndern");
define("_ADD","Hinzuf�gen");
define("_EDIT","Editieren");
define("_DELETE","L�schen");
define("_UPLOAD","Hochladen");
define("_GROUPNAME","Gruppenname");
define("_SELECT","Ausw�hlen");
define("_ADDWEEKLYPOLL","Umfrage hinzuf�gen");
define("_SUBMITEDPOLLS","�bermittelte Umfragen");
define("_QUESTION","Frage");
define("_ANSWERS","Antwort");
define("_SEPERATEANSWERSWITH","Antworten trennen mit");
define("_EDITWEEKLYPOLL","Umfrage editieren");
define("_SUCCESS","Erfolgreich");
define("_DELETENEWS","Newsartikel l�schen");
define("_NOTENOUGHPRIV","Erforderliche Berechtigung nicht vorhanden!");
define("_LANGUAGE","Sprache");
define("_CONTENT","Inhalt");
?>