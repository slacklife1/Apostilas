<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 10th.June,2002                                                          **
  //**                                                                                      **
  //** Language module: English                                                             **
  //******************************************************************************************

define("_CHARSET","ISO-8859-1");
define("_STATISTICS","Statestik");
define("_ACTUAL","Faktisk");
define("_LASTVISIT","Senast bes�kt");
define("_NEW","New");
define("_ONLINENEWS","Nyheter Online");
define("_WEEKLYPOLLQ","Vecko Fr�geank�t");
define("_WEEKLYPOLLA","Vecko Svarank�t");
define("_PUBLICNEWS","Publika Nyheter");
define("_REGISTEREDUSERS","Registrerade anv�ndare");
define("_NEWSCOMMENTS","Nyhetskommentarer");
define("_ADDNEWS","L�gg till nyheter");
define("_SUBMITEDNEWS","Inskickade nyheter");
define("_OPTIONS","Valm�jligheter");
define("_NEWSHEADLINE","Huvudnyher");
define("_AUTHOR","F�rfattare");
define("_DATE","Datum");
define("_SECTION","Avdelning");
define("_PREVIEW","F�rhandsgranska");
define("_MESSAGE","Meddelande");
define("_SUBMIT","Skicka in");
define("_HOME","Hem");
define("_NEWSMANAGER","Nyhetsmeny");
define("_MODIFYNEWS","Modifiera Nyhet");
define("_ADDNEWS","L�gg till Nyhet");
define("_ADDPARTNERS","L�gg till Partner");
define("_UPLOADLOGO","Ladda upp Logo");
define("_IMAGE","Bild");
define("_NAME","Namn");
define("_NUMBER","#");define("_","#");
define("_CATEGORYNAME","Kategorinamn");
define("_MAINMENU","Huvudmeny");
define("_KEEPIT","Spara det!");
define("_DELETEIT","Kasta det!");
define("_EDITCATEGORY","�ndra Kategori");
define("_UPLOADPICTURE","Ladda upp bild");
define("_ADDCATEGORY","L�gg till kategori");
define("_OURPARTNERS","V�ra Partners");
define("_SELECTPAGE","V�lj sida");
define("_LINK","L�nk");
define("_IN","In");
define("_OUT","Ut");
define("_AFFILIATES","Affiliates");
define("_GFX","Gfx");
define("_PREVIOUS","F�reg�ende");
define("_NEXT","Next");
define("_DESCRIPTION","Beskrivning");
define("_MODIFYPARTNERS","�ndra Partners");
define("_RSSSETTINGS","RSS Inst�llningar");
define("_NAMEOFRSSFILE","RSS filens namn");
define("_NUMBEROFNEWS","Number of news");
define("_RSSTITLE","RSS Titel");
define("_RSSLINK","RSS L�nk");
define("_RSSDESCRIPTION","RSS Beskrivning");
define("_AUTOCREATERSS","Skapa en RSS fil automatiskt efter varje nyhets�ndring");
define("_OPTIMIZED","Optimerad");
define("_OPTIMIZEDATABASE","Optimera Databas");
define("_ADDSMILEY","L�gg till Smiley");
define("_UPLOADSMILEY","Ladda upp Smiley");
define("_SMILEYEMOTION","K�nsla");
define("_SMILEYEDITOR","Smiley Editor");
define("_SMILEYCODE","Kod");
define("_EDITSMILEY","Editera Smiley");
define("_DELETESMILEY","Ta bort Smiley");
define("_NEWS","Nyheter");
define("_CATEGORY","Kategori");
define("_PARTNERS","Partners");
define("_WEEKLYPOLL","Weekly Poll");
define("_SMILEYS","Smileys");
define("_BROWSENEWS","Browse News");
define("_GROUPS","Groups");
define("_ADMINS","Admins");
define("_USERS","Users");
define("_USERINFO","User Info");
define("_ADMINISTRATION","Administration");
define("_YOULOGOUT","You have just logout.");
define("_LOGIN","Login");
define("_PASSWORD","Password");
define("_USERNAME","Username");
define("_WEBCONTROLPANEL","WEB CONTROL PANEL");
define("_ADDUSER","Add User");
define("_EMAIL","Email");
define("_PRIVILEGES","Privileges");
define("_EMAIL","Email");
define("_EDITUSER","Edit User");
define("_DELETEUSER","Delete User");
define("_INFO","Info");
define("_ADDGROUP","Add Group");
define("_ADMIN","Admin");
define("_RSS","RSS");
define("_MODIFY","Modify");
define("_ADD","Add");
define("_EDIT","Edit");
define("_DELETE","Delete");
define("_UPLOAD","Upload");
define("_GROUPNAME","Groupname");
define("_SELECT","Select");
define("_ADDWEEKLYPOLL","Add Weekly Poll");
define("_SUBMITEDPOLLS","Submited Polls");
define("_QUESTION","Question");
define("_ANSWERS","Answer");
define("_SEPERATEANSWERSWITH","Seperate answers with");
define("_EDITWEEKLYPOLL","Edit Weekly Poll");
define("_SUCCESS","Success");
define("_DELETENEWS","Delete News");
define("_NOTENOUGHPRIV","You dont have enough permissions!");
define("_LANGUAGE","Language");
define("_CONTENT","Content");
?>