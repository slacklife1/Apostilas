<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 10th.June,2002                                                          **
  //**                                                                                      **
  //** Language module: English                                                             **
  //******************************************************************************************

define("_CHARSET","ISO-8859-1");
define("_STATISTICS","Statistics");
define("_ACTUAL","Actual");
define("_LASTVISIT","Last visit");
define("_NEW","New");
define("_ONLINENEWS","Online News");
define("_WEEKLYPOLLQ","Weekly Poll Questions");
define("_WEEKLYPOLLA","Weekly Poll Answers");
define("_PUBLICNEWS","Public News");
define("_REGISTEREDUSERS","Registered users");
define("_NEWSCOMMENTS","News comments");
define("_ADDNEWS","Add news");
define("_SUBMITEDNEWS","Submited news");
define("_OPTIONS","Options");
define("_NEWSHEADLINE","News Headline");
define("_AUTHOR","Author");
define("_DATE","Date");
define("_SECTION","Section");
define("_PREVIEW","Preview");
define("_MESSAGE","Message");
define("_SUBMIT","Submit");
define("_HOME","Home");
define("_NEWSMANAGER","News Menu");
define("_MODIFYNEWS","Modify News");
define("_ADDNEWS","Add News");
define("_ADDPARTNERS","Add Partner");
define("_UPLOADLOGO","Upload Logo");
define("_IMAGE","Image");
define("_NAME","Name");
define("_NUMBER","#");define("_","#");
define("_CATEGORYNAME","Category Name");
define("_MAINMENU","Main Menu");
define("_KEEPIT","Keep It!");
define("_DELETEIT","Delete It!");
define("_EDITCATEGORY","Edit Category");
define("_UPLOADPICTURE","Upload Picture");
define("_ADDCATEGORY","Add Category");
define("_OURPARTNERS","Our Partners");
define("_SELECTPAGE","Select Page");
define("_LINK","Link");
define("_IN","In");
define("_OUT","Out");
define("_AFFILIATES","Affiliates");
define("_GFX","Gfx");
define("_PREVIOUS","Previous");
define("_NEXT","Next");
define("_DESCRIPTION","Description");
define("_MODIFYPARTNERS","Modify Partners");
define("_RSSSETTINGS","RSS Settings");
define("_NAMEOFRSSFILE","Name of RSS file");
define("_NUMBEROFNEWS","Number of news");
define("_RSSTITLE","RSS Title");
define("_RSSLINK","RSS Link");
define("_RSSDESCRIPTION","RSS Description");
define("_AUTOCREATERSS","Automaticly create RSS file, after each news modification");
define("_OPTIMIZED","Optimized");
define("_OPTIMIZEDATABASE","Optimize Database");
define("_ADDSMILEY","Add Smiley");
define("_UPLOADSMILEY","Upload Smiley");
define("_SMILEYEMOTION","Emotion");
define("_SMILEYEDITOR","Smiley Editor");
define("_SMILEYCODE","Code");
define("_EDITSMILEY","Edit Smiley");
define("_DELETESMILEY","Delete Smiley");
define("_NEWS","News");
define("_CATEGORY","Category");
define("_PARTNERS","Partners");
define("_WEEKLYPOLL","Weekly Poll");
define("_SMILEYS","Smileys");
define("_BROWSENEWS","Browse News");
define("_GROUPS","Groups");
define("_ADMINS","Admins");
define("_USERS","Users");
define("_USERINFO","User Info");
define("_ADMINISTRATION","Administration");
define("_YOULOGOUT","You have just logout.");
define("_LOGIN","Login");
define("_PASSWORD","Password");
define("_USERNAME","Username");
define("_WEBCONTROLPANEL","WEB CONTROL PANEL");
define("_ADDUSER","Add User");
define("_EMAIL","Email");
define("_PRIVILEGES","Privileges");
define("_EMAIL","Email");
define("_EDITUSER","Edit User");
define("_DELETEUSER","Delete User");
define("_INFO","Info");
define("_ADDGROUP","Add Group");
define("_ADMIN","Admin");
define("_RSS","RSS");
define("_MODIFY","Modify");
define("_ADD","Add");
define("_EDIT","Edit");
define("_DELETE","Delete");
define("_UPLOAD","Upload");
define("_GROUPNAME","Groupname");
define("_SELECT","Select");
define("_ADDWEEKLYPOLL","Add Weekly Poll");
define("_SUBMITEDPOLLS","Submited Polls");
define("_QUESTION","Question");
define("_ANSWERS","Answer");
define("_SEPERATEANSWERSWITH","Seperate answers with");
define("_EDITWEEKLYPOLL","Edit Weekly Poll");
define("_SUCCESS","Success");
define("_DELETENEWS","Delete News");
define("_NOTENOUGHPRIV","You dont have enough permissions!");
define("_LANGUAGE","Language");
define("_CONTENT","Content");
?>