<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 10th.June,2002                                                          **
  //**                                                                                      **
  //** Language module: English                                                             **
  //******************************************************************************************

define("_CHARSET","windows-1250");
define("_STATISTICS","Statistika");
define("_ACTUAL","Trenutno");
define("_LASTVISIT","Zadnji obisk");
define("_NEW","Novo");
define("_ONLINENEWS","Novic");
define("_WEEKLYPOLLQ","Anket");
define("_WEEKLYPOLLA","Odgovorov na ankete");
define("_PUBLICNEWS","Javne novice");
define("_REGISTEREDUSERS","Registriranih uporabnikov");
define("_NEWSCOMMENTS","Komentarjev");
define("_ADDNEWS","Dodaj novico");
define("_SUBMITEDNEWS","Novic");
define("_OPTIONS","Opcije");
define("_NEWSHEADLINE","Naslov");
define("_AUTHOR","Avtor");
define("_DATE","Datum");
define("_SECTION","Skupina");
define("_PREVIEW","Povzetek");
define("_MESSAGE","Novica");
define("_SUBMIT","Potrdi");
define("_HOME","Domov");
define("_NEWSMANAGER","Meni");
define("_MODIFYNEWS","Uredi novico");
define("_ADDPARTNERS","Dodaj partnerja");
define("_UPLOADLOGO","Dodaj logotip");
define("_IMAGE","Slika");
define("_NAME","Ime");
define("_NUMBER","#");define("_","#");
define("_CATEGORYNAME","Ime skupine");
define("_MAINMENU","Osnovni meni");
define("_KEEPIT","Obdr�i!");
define("_DELETEIT","Izbri�i!");
define("_EDITCATEGORY","Spremeni skupino");
define("_UPLOADPICTURE","Dodaj sliko");
define("_ADDCATEGORY","Dodaj skupino");
define("_OURPARTNERS","Na�i partnerji");
define("_SELECTPAGE","Izberi stran");
define("_LINK","Povezava");
define("_IN","Not");
define("_OUT","Ven");
define("_AFFILIATES","Partnerji");
define("_GFX","Gfx");
define("_PREVIOUS","Prej�na");
define("_NEXT","Naslednja");
define("_DESCRIPTION","Opis");
define("_MODIFYPARTNERS","Uredi partnerje");
define("_RSSSETTINGS","RSS nastavitve");
define("_NAMEOFRSSFILE","Ime RSS datoteke");
define("_NUMBEROFNEWS","�tevilo novic");
define("_RSSTITLE","RSS naslov");
define("_RSSLINK","RSS povezava");
define("_RSSDESCRIPTION","RSS opis");
define("_AUTOCREATERSS","Ustvari RSS datoteko po vsaki spremembi v novicah.");
define("_OPTIMIZED","Optimizirano");
define("_OPTIMIZEDATABASE","Optimiziraj bazo");
define("_ADDSMILEY","Dodaj sme�kota");
define("_UPLOADSMILEY","Dodaj sliko");
define("_SMILEYEMOTION","�ustvo");
define("_SMILEYEDITOR","Editor");
define("_SMILEYCODE","Koda");
define("_EDITSMILEY","Spremeni");
define("_DELETESMILEY","Izbri�i");
define("_NEWS","Novice");
define("_CATEGORY","Skupina");
define("_PARTNERS","Partnerji");
define("_WEEKLYPOLL","Anketa");
define("_SMILEYS","Sme�koti");
define("_BROWSENEWS","Pregled novic");
define("_GROUPS","Skupine");
define("_ADMINS","Administratorji");
define("_USERS","Uporabniku");
define("_USERINFO","Informacije");
define("_ADMINISTRATION","Administracija");
define("_YOULOGOUT","Pravkar ste se odjavili.");
define("_LOGIN","Prijava");
define("_PASSWORD","Geslo");
define("_USERNAME","Uporabni�ko ime");
define("_WEBCONTROLPANEL","WEB CONTROL PANEL");
define("_ADDUSER","Dodaj uporabnika");
define("_EMAIL","Email");
define("_PRIVILEGES","Privilegiji");
define("_EMAIL","Email");
define("_EDITUSER","Spremeni uporabnika");
define("_DELETEUSER","Izbir�i uporabnika");
define("_INFO","Info");
define("_ADDGROUP","Dodaj skupino");
define("_ADMIN","Administrator");
define("_RSS","RSS");
define("_MODIFY","Uredi");
define("_ADD","Dodajanje");
define("_EDIT","Spreminjanje");
define("_DELETE","Brisanje");
define("_UPLOAD","Upload");
define("_GROUPNAME","Ime skupine");
define("_SELECT","Izberi");
define("_ADDWEEKLYPOLL","Dodaj anketo");
define("_SUBMITEDPOLLS","Anket v arhivu");
define("_QUESTION","Vpra�anje");
define("_ANSWERS","Odgovor");
define("_SEPERATEANSWERSWITH","Lo�ite jih z");
define("_EDITWEEKLYPOLL","Spremeni anketo");
define("_SUCCESS","Uspe�no");
define("_DELETENEWS","Bri�i novico");
define("_NOTENOUGHPRIV","Nimate dovoljena za dostop do teh strani!");
define("_LANGUAGE","Jezik");
define("_CONTENT","Vsebina");
?>