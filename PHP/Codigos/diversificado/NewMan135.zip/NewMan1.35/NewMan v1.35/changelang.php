<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 11th.June,2002                                                           **
  //******************************************************************************************

 extract ($HTTP_POST_VARS, EXTR_PREFIX_SAME,"wddx");
 extract ($HTTP_GET_VARS, EXTR_PREFIX_SAME,"wddx");
 //$info = base64_encode("$language");
 setcookie("clang","$language",time()+15552000); // 6 mo is 15552000
 header ("Location: index.php"); 
?>
