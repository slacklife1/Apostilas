<?php
  //******************************************************************************************
  //** phpNewsManager                                                                       **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 7th.June,2002                                                           **
  //******************************************************************************************

  extract ($HTTP_POST_VARS, EXTR_PREFIX_SAME,"wddx");
  extract ($HTTP_GET_VARS, EXTR_PREFIX_SAME,"wddx");
  extract ($HTTP_COOKIE_VARS, EXTR_PREFIX_SAME,"wddx");

  $newman_ver = "v1.35";
  $site_title = "phpNewsManager $newman_ver";

  include ("db.inc.php");  
  if(empty($clang)) {$clang = "lang-english.php";}
  include ("languages/$clang");
  mysql_connect("$db_server","$db_uname","$db_pass");
  mysql_select_db($db_name); 

function CheckLogin()
{
 global $nm_user,$action,$login,$pass,$db_admin;

 $info = base64_decode("$nm_user");
 $info = explode(":", $info);
 if ($action == "Login") { $info[0] = $login; $info[1] = $pass; }
 $result = mysql_query("select * from $db_admin where uname='$info[0]' and passwd='$info[1]'") or die ("<B>Error 36:</B>".mysql_query());
 $num = mysql_num_rows($result);
 if($num == 1) {$passek=1;} else {$passek=0;}
 return $passek;
}

function unhtmlentities ($string)
{
 $trans_tbl = get_html_translation_table (HTML_ENTITIES);
 $trans_tbl = array_flip ($trans_tbl);
 return strtr ($string, $trans_tbl);
}

function ShowLogin()
{ 
 ?>
  <FORM ACTION="login.php" METHOD=POST>
  <?echo _USERNAME;?><BR>
  <INPUT TYPE="text" NAME="login" SIZE=12><BR>
  <?echo _PASSWORD;?><BR>
  <INPUT TYPE="password" NAME="pass" SIZE=12><BR>
  <INPUT TYPE="hidden" NAME="action" VALUE="login">
  <INPUT TYPE="submit" Value="<?echo _LOGIN;?>">
  </FORM> 
  /*For demo use this:<BR>
  // FOR ONLINE DEMO
  USERNAME: demo<BR>
  PASSWORD: demo<BR>
  <BR>
  Front end demo available at:<BR>
  <A HREF="http://skintech.skinbase.org/newman/demo/myPage/" target="_new">Layout 1</A><BR>
  <A HREF="http://skintech.skinbase.org/newman/demo/myPage2/" target="_new">Layout 2</A><BR>
  */
 <?
}

function Logout()
{
 global $color01,$color02,$color03,$color04;
 ?>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
  <TR>
   <TD CLASS=MojText ALIGN=CENTER>
    <?echo _YOULOGOUT;?>
   </TD>
  </TR>
 </TABLE>
 <?
}

function formatTimestamp($time)
 {
  global $datetime;
  ereg ("([0-9]{4})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})", $time, $datetime);
  $datetime = date("d M Y", mktime($datetime[4],$datetime[5],$datetime[6],$datetime[2],$datetime[3],$datetime[1]));
  return($datetime);
}

function myError()
{
 echo "<B>Error:</B>".mysql_error();
}

function CheckPriv($myTable)
{
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
 global $login;
 
 $chu = mysql_query("SELECT priv from $db_admin where uname='$login'");
 $usr = mysql_fetch_array($chu);
 $chk = mysql_query("SELECT * from $db_groups where id='$usr[priv]'");
 $prv = mysql_fetch_array($chk);
 return $prv[$myTable];
}

function makeRSS()
{
 global $db_news, $rss_path;
  
 $resn = mysql_query("SELECT * FROM rss;");
 $arn = mysql_fetch_array($resn);
 if($arn[auto]==1)
 {
  $query = "SELECT * from $db_news order by datum desc, id desc LIMIT $arn[number]";
  $fps = fopen($rss_path."/$arn[filename]","w");
  flock($fps,LOCK_EX);
  fwrite($fps,"<?xml version=\"1.0\"?>\n");
  fwrite($fps,"<rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\" xmlns=\"http://purl.org/rss/1.0/\">\n");
  fwrite($fps,"<channel rdf:about=\"http://www.skinbase.org/news.rss\">\n");
  fwrite($fps,"<title>$arn[title]</title>\n");
  fwrite($fps,"<link>$arn[link]</link>\n");
  fwrite($fps,"<description>$arn[description]</description>\n");
  fwrite($fps,"<items>\n");
  fwrite($fps," <rdf:Seq>\n");
  $res = mysql_query($query) or die("<B>Error:</B>".mysql_error());
  while ($ar = mysql_fetch_array($res))
  {
   fwrite($fps,"<rdf:li resource=\"$arn[link]/news.php?id=$ar[id]\" />\n");
  }
  fwrite($fps,"</rdf:Seq>\n");
  fwrite($fps,"</items>\n");
  fwrite($fps,"</channel>\n");
  $res = mysql_query($query) or die("<B>Error:</B>".mysql_error());
  while ($ar = mysql_fetch_array($res))
  {
   fwrite($fps,"<item rdf:about=\"http://www.skinbase.org/news.php?id=$ar[id]\">\n");
   fwrite($fps,"<title>$ar[headline]</title>\n");
   fwrite($fps,"<link>http://www.skinbase.org/news.php?id=$ar[id]</link>\n");
   fwrite($fps,"<description>$ar[preview]</description>\n");
   fwrite($fps,"</item>\n");
  }
  fwrite($fps,"</rdf:RDF>\n");
  //flock($fps,4);
  fclose($fps);
 }
}

function MakeJS($myPath,$myURL)
{
 if(file_exists($myPath))
 {
  ?>
  <SCRIPT LANGUAGE="JavaScript">
  <!-- Beginning of JavaScript -
  <?
  $d = dir($myPath);
  $x=0;$y=0;
  while($entry=$d->read()) 
  {
   $x++;
   if ($x > 2)
   {
    $y++;
    echo "Image".$y." = new Image(100,100)\n";
    echo "Image".$y.".src = \"$myURL/$entry\"\n";
   }
  }
  $d->close();
  ?>
  function Swap()
  {
   x = forma.picture.selectedIndex;
   <?
   $y++;
   for($z=0;$z<$y;$z++)
   {
    $f = $z+1;
    echo "if (x == ".$z.") {document.button.src = Image".$f.".src; return true;}\n";
   }
   ?>
  }
  // - End of JavaScript - -->
  </SCRIPT>
<?
 }
}
?>