<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 27th.May,2002                                                           **
  //******************************************************************************************

  $title    = "phpNewsManager $newman_ver";
  include ("colors.php");
  include "functions.php";

Function ShowGroups()
{
 global $color01,$color02,$color03,$color04,$color05;
 global $site_title;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

?>
<BR>
<TABLE WIDTH=630 BORDER=0 CELLSPACING=0 CELLPADDING=2 BGCOLOR=#<?echo $color02;?> ALIGN=CENTER>
 <TR> 
 <TD WIDTH=100% BGCOLOR=#<?echo $color02;?> CLASS=MojText>
 <FONT COLOR=white FACE=Arial SIZE=2 COLOR=#<?echo $color05;?>>
  <B><?echo $site_title;?></B>
  </FONT>
 </TD>
</TR>
</TABLE>
<BR>

<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=1 WIDTH=630 ALIGN=CENTER >
 <TR>
  <TD CLASS=MojText VALIGN=TOP>
    <?php
     $res = mysql_query("SELECT * FROM $db_topic ORDER BY topictext"); 
     print "<TABLE WIDTH=630><TR>";
     while ($ar = mysql_fetch_array($res))
      {
       $x++;
       print "<TD ALIGN=CENTER HEIGHT=100><A HREF=\"?action=category&id=$ar[id]\"><IMG SRC=topic/$ar[topicimage] ALT=$ar[topictext] BORDER=0></A></TD>";
       if ($x == 5) { print "</TR><TR>";$x=0;} 
      }
    ?>
   </TR></TABLE>
  </TD>
 </TR>
</TABLE>
<?
}

Function DisplayGroup()
{
 global $color01,$color02,$color03,$color04,$color05;
 global $id,$site_title,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 $res = mysql_query("SELECT * FROM $db_topic where id='$id'"); 
 $tp = mysql_fetch_array($res)
?>
<BR>
<TABLE WIDTH=99% BORDER=0 CELLSPACING=0 CELLPADDING=2 BGCOLOR=#<?echo $color02;?> ALIGN=CENTER>
 <TR> 
 <TD WIDTH=100% BGCOLOR=#<?echo $color02;?> CLASS=MojText>
 <FONT FACE=Arial SIZE=2 COLOR=#<?echo $color05;?>>
  <B><A HREF="<?echo $PHP_SELF;?>"><FONT COLOR=#<?echo $color05;?>><?echo $site_title;?></FONT></A></B> | <?php echo $tp[topictext];?>
  </FONT>
 </TD>
</TR>
</TABLE>
<BR>

<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=1 WIDTH=95% ALIGN=CENTER>
 <TR>
  <TD CLASS=MojText VALIGN=TOP>
   <IMG SRC=topic/<?php echo "$tp[topicimage] ALT=$tp[topictext]";?> BORDER=0><BR><BR>
   <?php
    if ($category <> "")
     {
      print "<IMG SRC=topic/$ar[topicimage] ALT=$ar[topictext] BORDER=0><FONT SIZE=4 FACE=Arial>$ar[topictext]</FONT><BR><HR COLOR=#<?echo $color01;?> SIZE=2>";
     }
    $res = mysql_query("SELECT * FROM $db_news where category='$id' ORDER BY datum DESC"); 
    while ($ar = mysql_fetch_array($res))
     { 
      ereg ("([0-9]{4})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})", $ar[datum], $datetime);
      $datum = date("M jS ", mktime($datetime[4],$datetime[5],$datetime[6],$datetime[2],$datetime[3],$datetime[1]));
      $x++;
      print "$x.<A HREF=?action=shownews&category=$category&id=$id&topicid=$ar[id]>$ar[headline] / <SMALL>$datum</SMALL> <BR></A>";
     }
   ?>
  </TD>
 </TR>
</TABLE>
<?
}

Function ShowNews()
{
 global $color01,$color02,$color03,$color04,$color05;
 global $id,$topicid,$category,$site_title,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 $res = mysql_query("SELECT * FROM $db_topic where id='$id'"); 
 $tp = mysql_fetch_array($res)
?>

<BR>
<TABLE WIDTH=99% BORDER=0 CELLSPACING=0 CELLPADDING=2 BGCOLOR=#<?echo $color02;?> ALIGN=CENTER>
 <TR> 
 <TD WIDTH=100% BGCOLOR=#<?echo $color02;?> CLASS=MojText>
 <FONT COLOR=#<?echo $color05;?> FACE=Arial SIZE=2>
  <B><A HREF="<?echo $PHP_SELF;?>"><FONT <FONT COLOR=#<?echo $color05;?>><?echo $site_title;?></FONT></A></B> | <A HREF="?action=category&id=<?echo $id;?>"><FONT <FONT COLOR=#<?echo $color05;?>><?php echo $tp[topictext];?></FONT></A>
  </FONT>
 </TD>
</TR>
</TABLE>
<BR>

<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=1 WIDTH=95% ALIGN=CENTER>
 <TR>
  <TD CLASS=MojText VALIGN=TOP>
   <IMG SRC=topic/<?php echo "$tp[topicimage] ALT=$tp[topictext]";?> BORDER=0><BR><BR>
   <HR SIZE=1 COLOR=#<?echo $color01;?>>
    <?php
     $res = mysql_query("SELECT * FROM $db_news where id='$topicid'"); 
     while ($ar = mysql_fetch_array($res))
      { 
       $res2 = mysql_query("SELECT email FROM $db_admin WHERE uname='$ar[author]'");
       $ar2 =  mysql_fetch_array($res2);
       $res3 = mysql_query("SELECT topicimage FROM $db_topic where id='$ar[category]'"); 
       $ar3 = mysql_fetch_array($res3);

       $datum = formatTimestamp($ar[datum]);
       ?>
        <TABLE WIDTH=100% CELLSPACING=1 CELLPADDING=3>
         <TR>
          <TD CLASS=MojText>
           <FONT SIZE=4><?echo $ar[headline];?></FONT><BR>
           <I>Posted by <A HREF="mailto:<?echo $ar2[email];?>"><?echo $ar[author];?></A> on <?echo $datum;?></I> 
	   <BR><BR>
          </TD>
         </TR>
         <TR>
          <TD BGCOLOR=#<?echo $color04;?> CLASS=MojText>
           <?echo $ar[preview];?><BR><BR><?echo $ar[tekst];?><BR><BR>
          </TD>
         </TR>
        </TABLE><BR>
  <?  } ?>
  </TD>
 </TR>
</TABLE>
<?
}


?>

<?
 include("header.php");

 if ($action == "")         {ShowGroups();}
 if ($action == "category") {DisplayGroup();}
 if ($action == "shownews") {ShowNews();}

 include("footer.php");

?>

