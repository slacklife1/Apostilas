<HTML>
<HEAD>
 <TITLE>phpNewsManager Installation Script</TITLE> 
 <LINK REL="stylesheet" TYPE="text/css" HREF="../MojStil.css">
</HEAD>
<BODY>

<?
extract ($HTTP_POST_VARS, EXTR_PREFIX_SAME,"wddx");
extract ($HTTP_GET_VARS, EXTR_PREFIX_SAME,"wddx");
if(empty($action))
{
?>
 <TABLE CLASS=MojText>
  <TR>
   <TD>
    <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
     Server:<BR>
     <INPUT TYPE="text" NAME="db_server" value="localhost" SIZE=40><BR>
     Username:<BR>
     <INPUT TYPE="text" NAME="db_uname" value="" SIZE=40><BR>
     Password:<BR>
     <INPUT TYPE="password" NAME="db_pass" value="" SIZE=40><BR>
     Database Name:<BR>
     <INPUT TYPE="text" NAME="db_name" value="newman" SIZE=40><BR>
     <INPUT TYPE="hidden" NAME="action" value="step2" SIZE=40><BR>
     <INPUT TYPE="Submit">
    </FORM>
     FILE <B>db.inc.php</B> MUST HAVE PERMISSION SET TO MODE 666 !!!<BR>
   </TD>
  </TR>
 </TABLE>
<?
}
?>



<?
if($action == "step2")
{
 $link = mysql_connect($db_server, $db_uname, $db_pass) or die("Could not connect");

 if(!mysql_select_db($db_name)) 
 {
  mysql_create_db("$db_name");
  mysql_select_db($db_name);
 }
 
?>
 <TABLE CLASS=MojText>
  <TR>
   <TD>
    <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
     Administrators:<BR>
     <INPUT TYPE="text" NAME="db_admin" value="admin" SIZE=40><BR>
     Groups:<BR>
     <INPUT TYPE="text" NAME="db_groups" value="groups" SIZE=40><BR>
     News:<BR>
     <INPUT TYPE="text" NAME="db_news" value="news" SIZE=40><BR>
     Comments for news:<BR>
     <INPUT TYPE="text" NAME="db_news_comments" value="news_comments" SIZE=40><BR>
     Log for news:<BR>
     <INPUT TYPE="text" NAME="db_news_logged" value="news_logged" SIZE=40><BR>
     Partners,Links:<BR>
     <INPUT TYPE="text" NAME="db_partners" value="partners" SIZE=40><BR>
     Public News:<BR>
     <INPUT TYPE="text" NAME="db_pnews" value="pnews" SIZE=40><BR>
     Smileys:<BR>
     <INPUT TYPE="text" NAME="db_smileys" value="smileys" SIZE=40><BR>
     Topic:<BR>
     <INPUT TYPE="text" NAME="db_topic" value="topic" SIZE=40><BR>
     Users:<BR>
     <INPUT TYPE="text" NAME="db_users" value="users" SIZE=40><BR>
     Weekly Poll - Questions:<BR>
     <INPUT TYPE="text" NAME="db_weekQ" value="weekQ" SIZE=40><BR>
     Weekly Poll - Answers:<BR>
     <INPUT TYPE="text" NAME="db_weekA" value="WeekA" SIZE=40><BR>
     RSS:<BR>
     <INPUT TYPE="text" NAME="db_rss" value="rss" SIZE=40><BR>
     <BR><BR>

     <B>Paths & Folders</B><BR>
     <?
      $cwd = getcwd();
      $smiley_path  =  "$cwd/gfx/smileys";
      $partner_path =  "$cwd/gfx/partners";
      $rss_path     =  "$cwd/rss";
      $topic_path   =  "$cwd/topic";
     ?>
     Smileys Path:<BR>
     <INPUT TYPE="text" NAME="smileys_path" VALUE="<?echo $smiley_path;?>" SIZE=40><BR>
     Smileys URL:<BR>
     <INPUT TYPE="text" NAME="smileys_url" VALUE="./gfx/smileys/" SIZE=40><BR>
     Partners Path:<BR>
     <INPUT TYPE="text" NAME="partners_path" VALUE="<?echo $partner_path;?>" SIZE=40><BR>
     Partners URL:<BR>
     <INPUT TYPE="text" NAME="partners_url" VALUE="./gfx/partners/" SIZE=40><BR>
     Topic Path:<BR>
     <INPUT TYPE="text" NAME="topic_path" VALUE="<?echo $topic_path;?>" SIZE=40><BR>
     RSS Path:<BR>
     <INPUT TYPE="text" NAME="rss_path" VALUE="<?echo $rss_path;?>" SIZE=40><BR>
     Topic URL:<BR>
     <INPUT TYPE="text" NAME="topic_url" VALUE="./topic" SIZE=40><BR>
     <?
      if(!file_exists($smiley_path)) {echo "<FONT COLOR=RED><B>Smiley path doesn't exists!</B></FONT><BR>";}
      if(!file_exists($partner_path)) {echo "<FONT COLOR=RED><B>Partner path doesn't exists!</B></FONT><BR>";}
      if(!file_exists($rss_path)) {echo "<FONT COLOR=RED><B>RSS path doesn't exists!</B></FONT><BR>";}
      if(!file_exists($topic_path)) {echo "<FONT COLOR=RED><B>Topic path doesn't exists!</B></FONT><BR>";}
     ?>
     <BR><BR>

     <B>Personal Data</B><BR>
     Admin username:<BR>
     <INPUT TYPE="text" NAME="admin_uname" SIZE=40><BR>
     Admin password:<BR>
     <INPUT TYPE="text" NAME="admin_pass" SIZE=40><BR>
     Admin Real Name:<BR>
     <INPUT TYPE="text" NAME="admin_name" SIZE=40><BR>
     Admin Email:<BR>
     <INPUT TYPE="text" NAME="admin_email" SIZE=40><BR>
   
     <BR>
     <INPUT TYPE="hidden" NAME="action" value="step3" SIZE=40>
     <INPUT TYPE="hidden" NAME="db_server" value="<?echo $db_server;?>">
     <INPUT TYPE="hidden" NAME="db_uname" value="<?echo $db_uname;?>">
     <INPUT TYPE="hidden" NAME="db_pass" value="<?echo $db_pass;?>" >
     <INPUT TYPE="hidden" NAME="db_name" value="<?echo $db_name;?>">

     <INPUT TYPE="Submit">
    </FORM>
   </TD>
  </TR>
 </TABLE>
<?
 mysql_close($link);
}
?>

<?
if($action == "step3")
{
 $link = mysql_connect($db_server, $db_uname, $db_pass) or die("Could not connect");
 mysql_select_db($db_name);
 echo "Creating Tables:<BR>";
 echo "$db_admin ...";
 mysql_query ("CREATE TABLE $db_admin (id int(11) DEFAULT '0' NOT NULL auto_increment,uname varchar(30),passwd varchar(30),name varchar(120),email varchar(80),priv int(11),info tinytext NOT NULL,PRIMARY KEY (id));");
 echo mysql_error()."<BR>$db_groups...";
 mysql_query ("CREATE TABLE $db_groups (id int(11) DEFAULT '0' NOT NULL auto_increment,name tinytext NOT NULL,description text NOT NULL,news_add tinyint(4) DEFAULT '0' NOT NULL,news_edit tinyint(4) DEFAULT '0' NOT NULL,news_del tinyint(4) DEFAULT '0' NOT NULL,news_ul tinyint(4) DEFAULT '0' NOT NULL,admin_add tinyint(4) DEFAULT '0' NOT NULL,admin_edit tinyint(4) DEFAULT '0' NOT NULL,admin_del tinyint(4) DEFAULT '0' NOT NULL,pnews_add tinyint(4) DEFAULT '0' NOT NULL,pnews_edit tinyint(4) DEFAULT '0' NOT NULL,pnews_del tinyint(4) DEFAULT '0' NOT NULL,pnews_submit tinyint(4) DEFAULT '0' NOT NULL,cat_add tinyint(4) DEFAULT '0' NOT NULL,cat_edit tinyint(4) DEFAULT '0' NOT NULL,cat_del tinyint(4) DEFAULT '0' NOT NULL,cat_ul tinyint(4) DEFAULT '0' NOT NULL,users_add tinyint(4) DEFAULT '0' NOT NULL,users_edit tinyint(4) DEFAULT '0' NOT NULL,users_del tinyint(4) DEFAULT '0' NOT NULL,partner_add tinyint(4) DEFAULT '0' NOT NULL,partner_edit tinyint(4) DEFAULT '0' NOT NULL,partner_del tinyint(4) DEFAULT '0' NOT NULL,partner_ul tinyint(4) DEFAULT '0' NOT NULL,wp_add tinyint(4) DEFAULT '0' NOT NULL,wp_edit tinyint(4) DEFAULT '0' NOT NULL,wp_del tinyint(4) DEFAULT '0' NOT NULL,group_add tinyint(4) DEFAULT '0' NOT NULL,group_edit tinyint(4) DEFAULT '0' NOT NULL,group_del tinyint(4) DEFAULT '0' NOT NULL,smiley_add tinyint(4) DEFAULT '0' NOT NULL,smiley_edit tinyint(4) DEFAULT '0' NOT NULL,smiley_del tinyint(4) DEFAULT '0' NOT NULL,smiley_ul tinyint(4) DEFAULT '0' NOT NULL, rss_edit tinyint(4) DEFAULT '0' NOT NULL, PRIMARY KEY (id));");
 echo mysql_error()."<BR>$db_news_comments...";
 mysql_query ("CREATE TABLE $db_news_comments (id int(11) DEFAULT '0' NOT NULL auto_increment,nid int(11) DEFAULT '0' NOT NULL,author varchar(30) NOT NULL,datum timestamp(14),tekst text NOT NULL,UNIQUE id (id));");
 echo mysql_error()."<BR>$db_news_logged...";
 mysql_query ("CREATE TABLE $db_news_logged (id int(11) DEFAULT '0' NOT NULL auto_increment,nid int(11) DEFAULT '0' NOT NULL,ip varchar(250) NOT NULL,PRIMARY KEY (id));");
 echo mysql_error()."<BR>$db_partners...";
 mysql_query ("CREATE TABLE $db_partners (id int(11) DEFAULT '0' NOT NULL auto_increment,name tinytext,link tinytext,picture tinytext,description text,clicks int(11),out int(11),main int(1),gfx int(1),PRIMARY KEY (id));");
 echo mysql_error()."<BR>$db_pnews...";
 mysql_query ("CREATE TABLE $db_pnews (id int(11) DEFAULT '0' NOT NULL auto_increment,headline varchar(80),author varchar(80),category varchar(80),picture varchar(120),datum timestamp(14),preview text,tekst text,lang varchar(10), PRIMARY KEY (id));");
 echo mysql_error()."<BR>$db_smileys...";
 mysql_query ("CREATE TABLE $db_smileys (id int(11) DEFAULT '0' NOT NULL auto_increment,code varchar(50), smile varchar(100),emotion varchar(75),PRIMARY KEY (id));");
 echo mysql_error()."<BR>$db_news...";
 mysql_query ("CREATE TABLE $db_news (id int(11) DEFAULT '0' NOT NULL auto_increment,headline varchar(80),author varchar(80),category varchar(80),picture varchar(120),datum timestamp(14),preview text,tekst text,lang varchar(10),views int(11),PRIMARY KEY (id));");
 echo mysql_error()."<BR>$db_topic...";
 mysql_query ("CREATE TABLE $db_topic (id int(11) DEFAULT '0' NOT NULL auto_increment,topicimage varchar(80),topictext varchar(255),counter int(11),PRIMARY KEY (id));");
 echo mysql_error()."<BR>$db_users...";
 mysql_query ("CREATE TABLE $db_users (id int(11) DEFAULT '0' NOT NULL auto_increment,uname varchar(30),passwd varchar(30),email varchar(80),info tinytext,name tinytext,PRIMARY KEY (id));");
 echo mysql_error()."<BR>$db_weekA...";
 mysql_query ("CREATE TABLE $db_weekA (id int(11) DEFAULT '0' NOT NULL auto_increment,wid int(11),answer int(11),PRIMARY KEY (id));");
 echo mysql_error()."<BR>$db_weekQ...";
 mysql_query ("CREATE TABLE $db_weekQ (id int(11) DEFAULT '0' NOT NULL auto_increment,question text,answers varchar(255),author varchar(120),PRIMARY KEY (id));");
 echo mysql_error()."<BR>";
 mysql_query ("CREATE TABLE rss (filename tinytext NOT NULL, number int(11) NOT NULL default '10', title tinytext NOT NULL,link tinytext NOT NULL, description tinytext NOT NULL, auto tinyint(4) NOT NULL default '0');");
 echo mysql_error()."<BR>";

 echo "Filling Data into Tables:<BR>";
 mysql_query ("INSERT INTO rss VALUES ('news.rss', 10, 'Name', 'http://www.mydomain.com', 'My Description', 1);");
 echo ".";
 mysql_query ("INSERT INTO $db_admin VALUES (3, '$admin_uname', '$admin_pass', '$admin_name', '$admin_email', 1, '');");
 echo ".";
 mysql_query ("INSERT INTO $db_groups VALUES (1, 'Full Admin', 'All function can be accessed', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1','1','1','1','1','1','1','1','1','1','1');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (37, ':x', 's026.gif', 'Sick');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (35, ':(', 's024.gif', 'Sad');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (34, ':-(', 's024.gif', 'Sad');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (29, '(o)', 's020.gif', 'Moon');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (30, '}:|', 's021.gif', 'Ninja');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (33, ':sad:', 's024.gif', 'Sad');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (32, ':brb', 's023.gif', 'Running');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (31, ':,', 's022.gif', 'OhWell');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (27, 'LOL', 's019.gif', 'LOL');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (26, 'lol', 's019.gif', 'LOL');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (28, ':moon', 's020.gif', 'Moon');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (24, ':|', 's017.gif', 'Impartial');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (23, ':-)', 's016.gif', 'Happy');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (22, ':smile:', 's016.gif', 'Happy');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (20, ':grin:', 's015.gif', 'Grin');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (21, ':)', 's016.gif', 'Happy');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (19, ':-D', 's015.gif', 'Grin');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (18, ':D', 's015.gif', 'Grin');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (14, '{:p', 's011.gif', 'Fool');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (13, ':evil', 's010.gif', 'Evil');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (16, ':grave', 's013.gif', 'gRAVE');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (12, '}:D', 's010.gif', 'Evil');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (11, ':O', 's009.gif', 'Embarassed');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (9, ':devil', 's007.gif', 'Devil');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (8, ':cry', 's006.gif', 'Cry');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (7, 'B)', 's005.gif', 'Cool');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (6, '8)', 's005.gif', 'Cool');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (4, ':9', 's003.gif', 'Cheesy');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (3, '}:(', 's002.gif', 'Angry');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (2, ':o', 's001.gif', 'Amazed');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (1, '8O', 's001.gif', 'Amazed');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (38, ':zzz', 's027.gif', 'Sleepy');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (39, '==~', 's028.gif', 'Smoker');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (40, ':smoke', 's028.gif', 'Smoker');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (41, ':p', 's029.gif', 'Tongue');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (42, ':P', 's029.gif', 'Tongue');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (43, ';)', 's030.gif', 'Wink');");
 echo ".";
 mysql_query ("INSERT INTO $db_smileys VALUES (44, '}:?', 's031.gif', 'What');");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (1, 'linux.gif', 'Linux', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (2, 'amd.gif', 'AMD', 0);"); 
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (3, 'aol.jpg', 'America Online', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (4, 'caldera.gif', 'Caldera Systems', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (5, 'mac.gif', 'Apple / Mac', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (6, 'beos.gif', 'BeOS', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (7, 'compaq.gif', 'Compaq', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (8, 'corel.gif', 'Corel', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (9, 'debian.gif', 'Debian', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (10, 'skinbase.jpg', 'Skinbase', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (11, 'freebsd.gif', 'FreeBSD', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (12, 'gimp.gif', 'GIMP', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (13, 'gnome.gif', 'GNOME', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (14, 'gnu.jpg', 'GNU / GPL', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (15, 'hp.gif', 'Hewlett Packard', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (16, 'ibm.gif', 'IBM', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (17, 'intel.gif', 'Intel', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (18, 'java.gif', 'Java', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (19, 'kde.gif', 'KDE', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (20, 'mandrake.gif', 'Mandrake', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (21, 'microsoft.gif', 'Microsoft', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (22, 'mozilla.gif', 'Mozilla', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (23, 'netscape.gif', 'Netscape', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (24, 'perl.gif', 'Perl', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (25, 'redhat.gif', 'Red Hat', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (26, 'sgi.gif', 'Silicon Graphics', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (27, 'sun.gif', 'Sun Microsystems', 0);");
 echo "."; 
 mysql_query ("INSERT INTO $db_topic VALUES (28, 'suse.gif', 'SuSE', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (29, 'x.jpg', 'X Window', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (30, 'windows.jpg', 'Windows 95/98/NT', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (31, 'amiga.gif', 'Amiga', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (32, 'other.jpg', 'Other', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (33, 'mp3.gif', 'MP3', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (34, 'winme.gif', 'Windows ME', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (35, 'cellphone.gif', 'Telecomunications', 0);");
 echo ".";
 mysql_query ("INSERT INTO $db_topic VALUES (36, 'nvidialogo.gif', 'nVIDIA', 0);");
 echo ".<BR>Done.<BR>";


 $fp = fopen("db.inc.php","w");
 fwrite($fp,"<?\n");
 fwrite($fp,"\$db_server = \"$db_server\";\n");
 fwrite($fp,"\$db_uname  = \"$db_uname\";\n");
 fwrite($fp,"\$db_pass   = \"$db_pass\";\n");
 fwrite($fp,"\$db_name   = \"$db_name\";\n");
 fwrite($fp,"\$db_admin  = \"$db_admin\";\n");
 fwrite($fp,"\$db_groups = \"$db_groups\";\n");
 fwrite($fp,"\$db_news   = \"$db_news\";\n");
 fwrite($fp,"\$db_news_comments = \"$db_news_comments\";\n");
 fwrite($fp,"\$db_news_logged = \"$db_news_logged\";\n");
 fwrite($fp,"\$db_partners = \"$db_partners\";\n");
 fwrite($fp,"\$db_pnews  = \"$db_pnews\";\n");
 fwrite($fp,"\$db_smileys = \"$db_smileys\";\n");
 fwrite($fp,"\$db_topic  = \"$db_topic\";\n");
 fwrite($fp,"\$db_users  = \"$db_users\";\n");
 fwrite($fp,"\$db_weekQ  = \"$db_weekQ\";\n");
 fwrite($fp,"\$db_weekA  = \"$db_weekA\";\n");
 fwrite($fp,"\$db_rss  = \"$db_rss\";\n");
 fwrite($fp,"\$smileys_path  = \"$smileys_path\";\n");
 fwrite($fp,"\$partners_path = \"$partners_path\";\n");
 fwrite($fp,"\$rss_path = \"$rss_path\";\n");
 fwrite($fp,"\$topic_path = \"$topic_path\";\n");
 fwrite($fp,"\$topic_url = \"$topic_url\";\n");
 fwrite($fp,"\$smiley_url = \"$smileys_url\";\n");
 fwrite($fp,"\$partners_url = \"$partners_url\";\n");

 fwrite($fp,"?>");
 fclose($fp);

 mysql_close($link);
}
?>

</BODY>
</HTML>