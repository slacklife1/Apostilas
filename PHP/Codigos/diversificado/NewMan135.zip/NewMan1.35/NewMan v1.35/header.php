<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 27th.May,2002                                                           **
  //******************************************************************************************
?>
<HTML>
 <HEAD>
  <TITLE><?echo $title;?></TITLE>
  <LINK REL="stylesheet" TYPE="text/css" HREF="MojStil.css">
  <META http-equiv="Content-Type" content="text/html; charset=<?echo _CHARSET;?>">
  <?
   if($makejs == "category") {MakeJS($topic_path,$topic_url);}
   if($makejs == "partners") {MakeJS($partners_path,$partners_url);}
   if($makejs == "smileys")  {MakeJS($smileys_path,$smiley_url);}
  ?>
 </HEAD>
 <BODY TOPMARGIN=0 LEFTMARGIN=0 TEXT=#<?echo $color_text;?> BGCOLOR=#<?echo $color_back;?> LINK=#<?echo $color_link;?> ALINK=#<?echo $color_alink;?> VLINK=#<?echo $color_vlink;?> BACKGROUND="gfx/background.gif">
<TABLE WIDTH="796" CELLSPACING="0" CELLPADDING="0" BORDER="0" HEIGHT="65" CLASS="MojText">
 <TR BGCOLOR="#9EC5E4">
  <TD>
   <A HREF="index.php"><IMG SRC="<?echo $logo;?>" BORDER="0" WIDTH="280"></A><BR>
  </TD>
  <TD VALIGN="BOTTOM" ALIGN="RIGHT">
   <FONT SIZE="4" COLOR="#8EB5D4" FACE="Tahoma"><?echo _WEBCONTROLPANEL;?></FONT> 
  </TD>
 </TR>
 <TR>
  <TD COLSPAN=2 HEIGHT=1 BGCOLOR=#000000>
  </TD>
 </TR>
</TABLE>

<TABLE BORDER="0" WIDTH="795" HEIGHT="100%" CELLSPACING="0" CELLPADDING="1" BORDER="0" BACKGROUND="/gfx/tile.gif" CLASS=MojText>
 <TR>
  <TD WIDTH="160" ALIGN="CENTER" VALIGN="TOP">

   <TABLE WIDTH=141 ALIGN=CENTER CELLSPACING=0 CELLPADDING=0 CLASS=MojText>
    <TR>
     <TD BACKGROUND="gfx/menu1.jpg" WIDTH=141 HEIGHT=36>
      <SPAN STYLE="padding-left:5px; font-family:arial; font-size:12px; font-weight:bold;"><?echo _USERINFO;?></FONT>
     </TD>
    </TR>
    <TR>
     <TD CLASS=BoxText BACKGROUND="gfx/menu2.jpg">
      <?
      $psw = CheckLogin();
      $info = base64_decode("$nm_user");
      $info = explode(":", $info);
      if ($action=="Login") { $info[0]=$login;}      
      $login = $info[0];
      if ($psw == 0) { ShowLogin();}
      else
       {
        $res = mysql_query("SELECT * from $db_admin where uname='$login'") or die ("<B>Error 87:</B>".mysql_query());;
        $ar = mysql_fetch_array($res);
        echo _USERNAME.": <B>".$ar[uname]."</B><BR>";
	?>
	<A HREF="index.php?action=Logout"><IMG SRC="./gfx/logout.jpg" BORDER=0 ALT="Logout"></A><?
       }
      ?>
     </TD>
    </TR>
    <TR>
     <TD>
      <IMG SRC="gfx/menu3.jpg"><BR>
     </TD>
    </TR>
   </TABLE>
   <BR>
   <?if ($psw <> 0) { 
   ?>
   <TABLE WIDTH=141 ALIGN=CENTER CELLSPACING=0 CELLPADDING=0 CLASS=MojText>
    <TR>
     <TD BACKGROUND="gfx/menu1.jpg" WIDTH=141 HEIGHT=36>
      <SPAN STYLE="padding-left:5px; font-family:arial; font-size:12px; font-weight:bold;"><?echo _CONTENT;?></FONT>
     </TD>
    </TR>
    <TR>
     <TD CLASS="BoxText" BACKGROUND="gfx/menu2.jpg">
      <A HREF="news.php"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Modify News"><?echo _NEWS;?></A><BR>
      <A HREF="category.php"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Modify categories"><?echo _CATEGORY;?></A><BR>
      <A HREF="partners.php"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Modify partners"><?echo _PARTNERS;?></A><BR>
      <A HREF="poll.php"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Weekly Poll"><?echo _WEEKLYPOLL;?></A><BR>
      <A HREF="pnews.php"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Modify Public News"><?echo _PUBLICNEWS;?></A><BR>
      <A HREF="smileys.php"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Smileys"><?echo _SMILEYS;?></A><BR>
      <A HREF="index.php"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Modify News"><?echo _STATISTICS;?></A><BR>
      <A HREF="browse.php"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Watch news"><?echo _BROWSENEWS;?></A><BR>
     </TD>
    </TR>
    <TR>
     <TD><IMG SRC="gfx/menu3.jpg"><BR></TD>
    </TR>
   </TABLE>
   <BR>
   <TABLE WIDTH=141 ALIGN=CENTER CELLSPACING=0 CELLPADDING=0 CLASS=MojText>
    <TR>
     <TD BACKGROUND="gfx/menu1.jpg" WIDTH=141 HEIGHT=36>
      <SPAN STYLE="padding-left:5px; font-family:arial; font-size:12px; font-weight:bold;"><?echo _ADMINISTRATION;?></FONT>
     </TD>
    </TR>
    <TR>
     <TD CLASS=BoxText BACKGROUND="gfx/menu2.jpg">
      <A HREF="groups.php"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Modify News"><?echo _GROUPS;?></A><BR>
      <A HREF="admin.php"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Modify categories"><?echo _ADMINS;?></A><BR>
      <A HREF="user.php"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Modify categories"><?echo _USERS;?></A><BR>
      <A HREF="rssMan.php"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Modify categories"><?echo _RSSSETTINGS;?></A><BR>
      <A HREF="optimize.php"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Modify categories"><?echo _OPTIMIZEDATABASE;?></A><BR>
     </TD>
    </TR>
    <TR>
     <TD><IMG SRC="gfx/menu3.jpg"><BR></TD>
    </TR>
   </TABLE>
   <BR>
   <TABLE WIDTH=141 ALIGN=CENTER CELLSPACING=0 CELLPADDING=0 CLASS=MojText>
    <TR>
     <TD BACKGROUND="gfx/menu1.jpg" WIDTH=141 HEIGHT=36>
      <SPAN STYLE="padding-left:5px; font-family:arial; font-size:12px; font-weight:bold;"><?echo _LANGUAGE;?></FONT>
     </TD>
    </TR>
    <TR>
     <TD CLASS=BoxText BACKGROUND="gfx/menu2.jpg">
      <FORM ACTION="changelang.php" METHOD=POST>
       <SELECT NAME="language" CLASS="text" STYLE="width:120px;">
        <?
        if ($handle = opendir('./languages')) 
        {
         while (false !== ($file = readdir($handle))) 
         { 
          if ($file != "." && $file != "..") 
          {         
           echo "<OPTION NAME=\"language\" VALUE=\"$file\" ";
           if ($clang == $file) { echo "selected";}
           $dfile = substr($file,5);
           $dfile = ereg_replace(".php","",$dfile);
           echo ">$dfile</option>";
          }
         }
         closedir($handle); 
        }
        ?>
       </SELECT><BR>
       <INPUT TYPE="hidden" ACTION="changelang" VALUE="true"?>
       <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
      </FORM>
     </TD>
    </TR>
    <TR>
     <TD><IMG SRC="gfx/menu3.jpg"><BR></TD>
    </TR>
   </TABLE>
   <?
   }?>
  </TD>
  <TD WIDTH=635 VALIGN=TOP Class=mojText BGCOLOR=#<?echo $color06;?>>
