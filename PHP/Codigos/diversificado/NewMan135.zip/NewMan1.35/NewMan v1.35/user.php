<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 27th.May,2002                                                           **
  //******************************************************************************************

  $title    = "phpNewsManager $newman_ver";
  include ("colors.php");
  include "functions.php";

function ShowMain()
 {
  global $color01,$color02,$color03,$color04,$color05,$PHP_SELF;
  global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

  ?>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD WIDTH=20>
    <A HREF="<?echo $PHP_SELF;?>?action=add"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="<?echo _ADDUSER;?>"></A>
   </TD>
   <TD>
    <A HREF="<?echo $PHP_SELF;?>?action=add"><?echo _ADDUSER;?></A>
   </TD>
   <TD ALIGN=RIGHT>
    <?
     $res = mysql_query("SELECT * from $db_users");
     $num = mysql_num_rows($res);
     echo _REGISTEREDUSERS.": ".$num;
    ?>
   </TD>
  </TR>
 </TABLE>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=1>
  <TR BGCOLOR=#<?echo $color02;?> CLASS=MojText>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _OPTIONS;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _USERNAME;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _NAME;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _EMAIL;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _INFO;?></TD>
  </TR>  
    <?php
    $res = mysql_query("SELECT * from $db_users");
    while ($ar = mysql_fetch_array($res))
     {
      echo "
 	 <TR CLASS=MojText>
 	  <TD><A HREF=?action=edit&id=$ar[id]><IMG SRC=gfx/notes16.gif BORDER=0></A> <A HREF=?action=delete&id=$ar[id]><IMG SRC=gfx/trash.gif BORDER=0></A></TD> 
	  <TD>$ar[uname]</TD>
  	  <TD VALIGN=TOP>$ar[name]</TD>
  	  <TD VALIGN=TOP>$ar[email]</TD>
  	  <TD VALIGN=TOP ALIGN=RIGHT>$ar[info]</TD>
 	 </TR> ";
    }
  echo "</TABLE>";
 }

function EditUser()
{
 global $color01,$color02,$color03,$color04;
 global $id,$confirm,$username,$password,$name,$infek,$login,$email,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("users_edit") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm <> "true") 
   {
    $res = mysql_query("SELECT * from $db_users where id='$id'");
    $ar = mysql_fetch_array($res);
    ?>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A> :<BR>
    <FONT SIZE=5 FACE=Arial><B><?echo _EDITUSER;?><B></FONT><BR>
    <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
     <TR>
      <TD Class=MojText>
       <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
        <?echo _USERNAME;?><BR>
        <INPUT TYPE="text" NAME="username" SIZE=40 VALUE="<?echo $ar[uname];?>"><BR>
        <?echo _PASSWORD;?>:<BR>
        <INPUT TYPE="password" NAME="password" SIZE=40 VALUE="<?echo $ar[passwd];?>"><BR>
        <?echo _NAME;?><BR>
        <INPUT TYPE="text" NAME="name" SIZE=40 VALUE="<?echo $ar[name];?>"><BR>
        <?echo _EMAIL;?><BR>
        <INPUT TYPE="text" NAME="email" SIZE=40 VALUE="<?echo $ar[email];?>"><BR>
        <?echo _INFO;?><BR>
        <INPUT TYPE="text" NAME="infek" SIZE=40 VALUE="<?echo $ar[info];?>"><BR>
        <input type="hidden" name="action" value="edit"><BR><BR>
        <input type="hidden" name="confirm" value="true">
        <input type="hidden" name="id" value="<?echo $id;?>">
        <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
        </FORM>
       </TD>
      </TR>
    </TABLE> 
   <?
  }
 if ($confirm == "true") 
   {
    $res = mysql_query("UPDATE $db_users SET uname='$username', passwd='$password', name='$name', email='$email', info='$infek' WHERE id='$id'") or die ("<B>Error:</B>".mysql_error()); 
    ShowMain();
   } 
 }

function DeleteUser()
{
 global $color01,$color02,$color03,$color04,$color05;
 global $id,$confirm,$preview,$headline,$message,$section,$login,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("users_del") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm == "true") {$res = mysql_query("DELETE FROM $db_users where id='$id'"); ShowMain();exit();}
 if ($confirm == "false"){ShowMain();}
 if ($confirm == "")
  {
   ?>
   <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
    <TR>
     <TD WIDTH=20>
      <A HREF="<?echo $PHP_SELF;?>"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="<?echo _MAINMENU;?>"></A>
     </TD>
     <TD>
      <?echo _DELETEUSER;?>
     </TD>
     <TD ALIGN=RIGHT>
      <?
       $res = mysql_query("SELECT * from $db_users");
       $num = mysql_num_rows($res);
       echo _REGISTEREDUSERS.": ".$num;
      ?>
     </TD>
    </TR>
   </TABLE>
   <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=1>
    <TR BGCOLOR=#<?echo $color02;?> CLASS=MojText>
     <TD><FONT COLOR=#<?echo $color05;?>><?echo _USERNAME;?></FONT></TD>
     <TD><FONT COLOR=#<?echo $color05;?>><?echo _NAME;?></FONT></TD>
     <TD><FONT COLOR=#<?echo $color05;?>><?echo _EMAIL;?></FONT></TD>
    </TR>  
    <?php
    $res = mysql_query("SELECT * from $db_users where id='$id'");
    while ($ar = mysql_fetch_array($res))
     {
      echo "
 	 <TR CLASS=MojText>
	  <TD>$ar[uname]</TD>
  	  <TD VALIGN=TOP>$ar[name]</TD>
  	  <TD VALIGN=TOP>$ar[email]</TD>
 	 </TR> ";
    }
  echo "</TABLE><BR><BR>";
?>  
<TABLE CELLSPACING=2 CELLPADDING=2>
 <TR>
  <TD VALIGN=TOP>
   <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
   <INPUT TYPE="image" SRC="gfx/survey.gif" ALT="<?echo _KEEPIT;?>" BORDER=0 WIDTH=24 HEIGHT=24><BR>
   <INPUT TYPE="hidden" name="action" value="delete">
   <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
   <INPUT TYPE="hidden" name="confirm" value="false"></FORM>
  </TD>
  <TD VALIGN=TOP>
   <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
    <INPUT TYPE="image" SRC="gfx/trash.gif" ALT="<?echo _DELETEIT;?>" BORDER=0 WIDTH=16 HEIGHT=16><BR>
    <INPUT TYPE="hidden" name="action" value="delete">
    <INPUT TYPE="hidden" name="info" value="<?echo $info;?>">
    <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
    <INPUT TYPE="hidden" name="confirm" value="true">
   </FORM>
  </TD>
 </TR>
</TABLE>
<?}}

function AddUser()
{
 global $color01,$color02,$color03,$color04;
 global $id,$login,$a_username,$a_password,$a_name,$a_email,$a_infek,$confirm,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("users_add") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}
  
 if ($confirm == "true") 
   {
    $res2 = mysql_query("SELECT * FROM $db_users WHERE uname='$a_username'");
    if(mysql_num_rows($res2)<1) {$res = mysql_query("INSERT INTO $db_users VALUES(0,'$a_username','$a_password','$a_email','$a_infek','$a_name')") or die ("<B>Error:</B>".mysql_error());}
    ShowMain();
   }
  if ($confirm <> "true")
   { 
    $res = mysql_query("SELECT * from $db_users where id='$id'");
    $ar = mysql_fetch_array($res);
    ?>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A><BR>
    <FONT SIZE=5 FACE=Arial><B><?echo _ADDUSER;?><B></FONT><BR>
    <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
     <TR>
      <TD Class=MojText>
       <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
        <?echo _USERNAME;?><BR>
        <INPUT TYPE="text" NAME="a_username" SIZE=40"><BR>
        <?echo _PASSWORD;?><BR>
        <INPUT TYPE="password" NAME="a_password" SIZE=40"><BR>
        <?echo _NAME;?><BR>
        <INPUT TYPE="text" NAME="a_name" SIZE=40><BR>
        <?echo _EMAIL;?><BR>
        <INPUT TYPE="text" NAME="a_email" SIZE=40><BR>
        <?echo _INFO;?><BR>
        <INPUT TYPE="text" NAME="a_infek" SIZE=40><BR>
        <input type="hidden" name="action" value="add"><BR><BR>
        <input type="hidden" name="confirm" value="true">
        <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
        </FORM>
       </TD>
      </TR>
    </TABLE> 
 </TABLE> 
 <?
 }}


?>

 <?include ("header.php");
  if ($psw == TRUE)
   {
    if ($action == "")       { ShowMain();   }
    if ($action == "edit")   { EditUser();   }
    if ($action == "delete") { DeleteUser(); }
    if ($action == "add")    { AddUser();    }
   }
  include ("footer.php");
 ?>
