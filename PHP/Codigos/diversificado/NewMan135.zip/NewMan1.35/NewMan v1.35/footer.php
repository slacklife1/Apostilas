</TD>
</TR>
</TABLE>
<TABLE WIDTH="796" CELLSPACING="0" CELLPADDING="0" BORDER="0">
 <TR><TD BGCOLOR="#000000" HEIGHT="1"></TD></TR>
 <TR>
  <TD CLASS="SmallT" BGCOLOR="#9EC5E4" ALIGN="CENTER">
   Powered by phpNewMan Version <?echo $newman_ver;?><BR>
   Copyright &copy; 2000 - 2002 The <A HREF="http://skintech.skinbase.org">SkinTech</A> Group 
  </TD>
 </TR>
</TABLE>
</BODY>
</HTML>