<?php
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 27th.May,2002                                                           **
  //******************************************************************************************

  $title    = "phpNewsManager $newman_ver";
  $makejs = "smileys";
  include "colors.php";
  include "functions.php";
  include "header.php";
 
function ShowMain()
{
 global $color01,$color02,$color03,$color04,$color05,$login,$smiley_url,$smileys_path,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA,$db_smileys;
 ?>
 
 <A HREF="<?echo $PHP_SELF;?>?action=add"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="Add"><?echo _ADDSMILEY;?></A> | <A HREF="<?echo $PHP_SELF;?>?action=upload"><?echo _UPLOADSMILEY;?></A>

 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=1>
  <TR BGCOLOR=#<?echo $color02;?> CLASS=MojText>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _OPTIONS;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _IMAGE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _NAME;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _SMILEYEMOTION;?></FONT></TD>
  </TR CLASS=MojText>  
   <?
    $res = mysql_query("SELECT * from $db_smileys");
    while ($ar = mysql_fetch_array($res))
     {
      echo "
   	    <TR CLASS=MojText>
 	    <TD WIDTH=80 VALIGN=TOP>
 	     <A HREF=?action=edit&id=$ar[id]><IMG SRC=gfx/notes16.gif BORDER=0></A> 
 	     <A HREF=?action=delete&id=$ar[id]><IMG SRC=gfx/trash.gif BORDER=0></A>
 	    </TD> 
	    <TD VALIGN=TOP WIDTH=100><IMG SRC=\"$smiley_url/$ar[smile]\"></TD>
	    <TD VALIGN=TOP>$ar[code]</TD>
	    <TD VALIGN=TOP>$ar[emotion]</TD>
 	 </TR> ";
   }
 echo "</TABLE>";

 if(!file_exists($smileys_path))
 {
  echo "<BR><BR><CENTER><FONT SIZE=3 FACE=ARIAL><B>ERROR: CHECK YOUR \$smileys_path VARIABLE IN db.inc.php FILE !!!</B></FONT></CENTER><BR><BR>";
 }


}

function EditSmiley()
{
 global $color01,$color02,$color03,$color04;
 global $code,$smile,$emotion,$id,$confirm,$smileys_path,$login,$picture,$smiley_url,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA,$db_smileys;

 // CHECK PRIVILEGIES
 if(CheckPriv("smiley_edit") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm <> "true") 
  {
   $res = mysql_query("SELECT * from $db_smileys where id='$id'");
   $ar = mysql_fetch_array($res);
   ?>
   <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A><BR>
   <FONT SIZE=5 FACE=Arial><B><?echo _EDITSMILEY;?><B></FONT><BR>
   <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
    <TR>
     <TD Class=MojText>
      <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST" NAME="forma">
       <?echo _SMILEYCODE;?>:<BR>
       <INPUT TYPE="text" NAME="code" VALUE="<?echo $ar[code];?>" SIZE=5><BR>
       <?echo _SMILEYEMOTION;?>:<BR>
       <INPUT TYPE="text" NAME="emotion" VALUE="<?echo $ar[emotion];?>" SIZE=40><BR>
       <?echo _IMAGE;?><BR>
       <select name="picture" size=8 onClick="Swap();">
       <?
        $d = dir($smileys_path);
        $x=0;
	while($entry=$d->read()) {$x++;if ($x > 2) 
	{
	 echo "<option value=\"$entry\""; if ($entry == $ar[smile]){echo " selected ";};echo ">$entry</option>";}
	}
        $d->close();
       ?>
       </SELECT>
       <P>
      <IMG NAME="button" SRC="<?echo "$smiley_url/$ar[smile]";?>" BORDER=0></A>
      </P>

       <input type="hidden" name="id" value="<?echo $id;?>">
       <input type="hidden" name="action" value="edit">
       <input type="hidden" name="confirm" value="true">
       <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
      </FORM>
     </TD>
    </TR>
   </TABLE> 
   <?
  }
 if ($confirm == "true") 
  {
   $res = mysql_query("UPDATE $db_smileys SET smile='$picture', code='$code', emotion='$emotion' WHERE id='$id'") or die ("<B>Error4:</B> Invalid query"); 
   ShowMain();
  } 
}

function DeleteSmiley()
 {
 global $color01,$color02,$color03,$color04,$color05;
 global $id,$smile,$code,$confirm,$smileys_path,$smiley_url,$login,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA,$db_smileys;

 // CHECK PRIVILEGIES
 if(CheckPriv("smiley_del") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm == "true") {$res = mysql_query("DELETE FROM $db_smileys where id='$id'"); ShowMain();exit();}
 if ($confirm == "false"){ShowMain();}
 if ($confirm == "")
  {
?>
  <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A><BR>
   <FONT SIZE=5 FACE=Arial><B><?echo _DELETESMILEY;?><B></FONT><BR>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=1>
  <TR BGCOLOR=#<?echo $color02;?> CLASS=MojText>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _IMAGE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _NAME;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _SMILEYEMOTION;?></FONT></TD>
  </TR>  
    <?php
    $res = mysql_query("SELECT * from $db_smileys where id='$id'");
    $ar = mysql_fetch_array($res);
    echo "
  	    <TR CLASS=MojText>
	    <TD VALIGN=TOP WIDTH=100><IMG SRC=\"$smiley_url/$ar[smile]\"></TD>
	    <TD VALIGN=TOP><FONT SIZE=3>$ar[code]</FONT></TD>
	    <TD VALIGN=TOP>$ar[emotion]</TD>
 	 </TR> ";
  echo "</TABLE>";
?>  
<TABLE CELLSPACING=2 CELLPADDING=2><TR><TD VALIGN=TOP>
 <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="image" SRC="gfx/survey.gif" ALT="<?echo _KEEPIT;?>" BORDER=0 WIDTH=24 HEIGHT=24><BR>
  <INPUT TYPE="hidden" name="action" value="delete">
  <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
  <INPUT TYPE="hidden" name="confirm" value="false"></FORM>
</TD><TD VALIGN=TOP>
  <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="image" SRC="gfx/trash.gif" ALT="<?echo _DELETEIT;?>" BORDER=0 WIDTH=16 HEIGHT=16><BR>
  <INPUT TYPE="hidden" name="action" value="delete">
  <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
  <INPUT TYPE="hidden" name="confirm" value="true">
  </FORM>
</TD></TR></TABLE>
<?
 }
 }

// ************ ADD CATEGORY **************
function AddSmiley()
{
 global $color01,$color02,$color03,$color04;
 global $code,$smile,$emotion,$login,$smileys_path,$picture,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA,$db_smileys;
 
 // CHECK PRIVILEGIES
 if(CheckPriv("smiley_add") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($code <> "")
  {
   $res2 = mysql_query("SELECT * FROM $db_smileys WHERE code = '$code'");
   if(mysql_num_rows($res2)==0) {$res = mysql_query("INSERT INTO $db_smileys VALUES(0,'$code','$picture','$emotion')") or die ("<B>Error5:</B> Invalid Query");}
   ShowMain();
   return 0;
  }
 if ($code == "")
  { 
   ?>
   <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A><BR>
   <FONT SIZE=5 FACE=Arial><B><?echo _ADDSMILEY;?><B></FONT><BR>
   <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
    <TR>
     <TD CLass=MojText>
      <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST" NAME="forma">
       <?echo _SMILEYCODE;?>:<BR>
       <INPUT TYPE="text" NAME="code" SIZE=5><BR>
       <?echo _SMILEYEMOTION;?>:<BR>
       <INPUT TYPE="text" NAME="emotion" SIZE=40><BR>
        <?echo _IMAGE;?><BR>
       <select name="picture" size=8 onClick="Swap();">
       <?
        $d = dir($smileys_path);
        $x=0;
	while($entry=$d->read()) {$x++;if ($x > 2) {echo "<option value=\"$entry\""; if ($entry == $ar[topicimage]){echo " selected ";};echo ">$entry</option>";}}
        $d->close();
       ?>
       </SELECT>
       
       <P>
      <IMG NAME="button" SRC="http://www.skinbase.org/gfx/partners/linkus.jpg" BORDER=0></A>
      </P>
      <BR>
       <input type="hidden" name="action" value="add"><BR><BR>
       <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
      </FORM>
     </TD>
    </TR>
   </TABLE> 
  <?
 } 
}

function UploadPicture()
{
 global $login,$action,$filename,$filename_name,$check,$smileys_path,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA,$db_smileys;

 // CHECK PRIVILEGIES
 if(CheckPriv("smiley_ul") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}


if ($check <> "UploadSkin")
 {?>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A><BR>
    <FONT SIZE=5 FACE=Arial><B><?echo _UPLOADSMILEY;?><B></FONT><BR>
    <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0>
     <TR>
      <TD CLass=MojText>
       <FORM ENCTYPE="multipart/form-data" METHOD=POST ACTION="<?echo $PHP_SELF;?>">
       <?echo _IMAGE;?>:<BR><INPUT TYPE="FILE" NAME="filename" size="50"><BR>
       <input type="hidden" name="action" value="upload"><BR>
       <input type="hidden" name="check" value="UploadSkin"><BR>
       <INPUT TYPE=SUBMIT VALUE="<?echo _SUBMIT;?>">
       </FORM>
      </TD>
     </TR>
    </TABLE>
  <?}

 if ($check == "UploadSkin")
 {
  $newfile = "$smileys_path/$filename_name";
  if (!copy($filename,$newfile)) {"Error Uploading File.";}
  echo _SUCESS;
 } 
}

// MAIN CODE STARTS HERE
if ($psw == 1)
{
 if ($action == "")       { ShowMain();      }
 if ($action == "edit")   { EditSmiley();    }
 if ($action == "delete") { DeleteSmiley();  }
 if ($action == "add")    { AddSmiley();     }
 if ($action == "upload") { UploadPicture(); }
}
include "footer.php";
?>
