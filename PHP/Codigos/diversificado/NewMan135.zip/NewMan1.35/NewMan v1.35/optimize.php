<?
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 10th.June,2002                                                          **
  //******************************************************************************************

  $title    = "phpNewsManager $newman_ver";
  include ("colors.php");
  include "functions.php";
  include ("header.php");
 ?>

 
  <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
   <TR>
   <TD WIDTH=20>
    <IMG SRC="gfx/docman.gif" BORDER=0 ALT="RSS">
   </TD>
   <TD>
    <?echo _OPTIMIZEDATABASE;?></A>
   </TD>
  </TR>
 </TABLE>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD>
    <?
     $result = mysql_list_tables($db_name);
     while ($row = mysql_fetch_row($result)) 
     {
      $result1 = mysql_query("OPTIMIZE TABLE $row[0];");
      echo ("<LI><B>$row[0]</B> "._OPTIMIZED."<BR>");
     }
     mysql_free_result($result);
     ?>
   </TD>
  </TR>
 </TABLE>
   
 <?include ("footer.php");?>
