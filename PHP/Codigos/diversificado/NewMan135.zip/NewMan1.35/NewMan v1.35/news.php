<?php
  //******************************************************************************************
  //** phpNewsManager                                                                       **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 7th.June,2002                                                           **
  //******************************************************************************************
  
  $title    = "phpNewsManager $newman_ver";
  include ("colors.php");
  include "functions.php";
 

function ShowMain()
 {
  global $color01,$color02,$color03,$color04,$color05,$id,$action;
  global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
  ?>
  <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
   <TR>
   <TD WIDTH=20>
    <A HREF="news.php?action=add"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="<?echo _ADDNEWS;?>"></A>
   </TD>
   <TD>
    <A HREF="<?echo $PHP_SELF;?>?action=add"><?echo _ADDNEWS;?></A>
   </TD>
   <TD ALIGN=RIGHT>
    <?
     $res = mysql_query("SELECT * from $db_news order by datum desc") or die("<B>Error:</B>".mysql_error());
     $num = mysql_num_rows($res);
     echo _SUBMITEDNEWS.": ".$num;
    ?>
   </TD>
  </TR>
 </TABLE>
 <TABLE WIDTH="630" CELLSPACING="2" CELLPADDING="1" CLASS="MojText">
  <TR BGCOLOR="#<?echo $color02;?>" CLASS="MojText">
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _OPTIONS;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _NEWSHEADLINE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _AUTHOR;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _DATE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _SECTION;?></FONT></TD>
  </TR>  
  <?
   while ($ar = mysql_fetch_array($res))
   {
    $datum = formatTimestamp($ar[datum]);
    $res2 = mysql_query("SELECT * FROM $db_topic where id='$ar[category]'") or die("<B>Error:</B>".mysql_error());
    $ar2 = mysql_fetch_array($res2);
    echo "
    <TR CLASS=MojText>
     <TD WIDTH=70><A HREF=?action=open&id=$ar[id]><IMG SRC=gfx/ofolder15.gif BORDER=0></A> <A HREF=?action=edit&id=$ar[id]><IMG SRC=gfx/notes16.gif BORDER=0></A> <A HREF=?action=delete&id=$ar[id]><IMG SRC=gfx/trash.gif BORDER=0></A></TD> 
     <TD>$ar[headline]</TD>
     <TD ALIGN=RIGHT VALIGN=TOP>$ar[author]</TD>
     <TD ALIGN=RIGHT WIDTH=70 VALIGN=TOP>$datum</TD>
     <TD ALIGN=RIGHT WIDTH=30 VALIGN=TOP><IMG SRC=topic/$ar2[topicimage] ALT=\"$ar2[topictext]\" WIDTH=20></TD>
    </TR>";
    if ($action == "open" & $id == $ar[id]) {echo "<TR BGCOLOR=#EEEEEE><TD STYLE=\"padding-left:120px;\" COLSPAN=5 Class=MojText>$ar[preview]</TD></TR>";}
   }
  echo "</TABLE>";
 }

function EditNews()
{
 global $color01,$color02,$color03,$color04;
 global $id,$confirm,$headline,$message,$section,$preview,$login,$PHP_SELF;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 if(CheckPriv("news_edit") == 1)
 {
  if ($confirm == "true") 
  {
   $message = htmlentities($message);
   $headline = htmlentities($headline);
   $preview = htmlentities($preview);
   $res = mysql_query("SELECT datum FROM $db_news WHERE id='$id'");
   $ar = mysql_fetch_array($res);
   
   mysql_query("UPDATE $db_news SET headline='$headline', datum='$ar[datum]', category='$section', preview='$preview', tekst='$message' WHERE id='$id'") or die("<B>Error:</B>".mysql_error());
   makeRSS();
   ShowMain();
  } 
  else
  {
   $res = mysql_query("SELECT * from $db_news where id='$id'") or die("<B>Error:</B>".mysql_error());
   $ar = mysql_fetch_array($res);

   $ar[tekst]    = unhtmlentities($ar[tekst]);
   $ar[preview]  = unhtmlentities($ar[preview]);
   $ar[headline] = ereg_replace( "&quot;","'",$ar[headline]);
   $ar[headline] = ereg_replace( "&acute;","'",$ar[headline]);
   ?>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A>  </TD>
     <TD ALIGN=RIGHT>
    <?
     $res = mysql_query("SELECT * from $db_news order by datum desc") or die("<B>Error:</B>".mysql_error());
     $num = mysql_num_rows($res);
     echo _SUBMITEDNEWS.": ".$num;
    ?>
   </TD>
  </TR>
 </TABLE>

   <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
    <TR>
     <TD>
      <IMG SRC="gfx/big_edit.gif"><FONT SIZE=3 FACE=Arial><B><?echo _MODIFYNEWS;?><B></FONT><BR>
     </TD>
    <TR>
     <TD>
      <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
       <?echo _NEWSHEADLINE;?><BR>
       <INPUT TYPE="text" NAME="headline" SIZE=60 VALUE="<?echo $ar[headline];?>" CLASS="text"><BR>
        <?echo _SECTION;?>:<BR>
        <select name=section  CLASS="text">
         <?
         $res2 = mysql_query("SELECT * FROM $db_topic") or die("<B>Error:</B>".mysql_error());
         while ($ar2 = mysql_fetch_array($res2))
          {
           echo "<option name=section value=$ar2[0] ";
           if ($ar2[id] == $ar[category]) { echo "selected";}
           echo ">$ar2[topictext]</option>";
          }
        ?>
        </select><BR>
        <?echo _PREVIEW;?><BR>
        <TEXTAREA NAME=preview COLS=60 ROWS=6 CLASS="textarea"><?echo "$ar[preview]";?></TEXTAREA><BR>
        <?echo _MESSAGE;?><BR>
        <TEXTAREA NAME=message COLS=60 ROWS=10 CLASS="textarea"><?echo "$ar[tekst]";?></TEXTAREA>
        <input type="hidden" name="action" value="edit"><BR><BR>
        <input type="hidden" name="confirm" value="true">
        <input type="hidden" name="id" value="<?echo $id;?>">
        <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
        </FORM>
       </TD>
      </TR>
    </TABLE> 
   <?
  }
 }
}

function DeleteNews()
 {
 global $color01,$color02,$color03,$color04,$color05;
 global $id,$confirm,$preview,$headline,$message,$section,$login,$PHP_NEWS;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("news_del") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($confirm == "true") {$res = mysql_query("DELETE FROM $db_news where id='$id'") or die("<B>Error:</B>".mysql_error()); ShowMain();makeRSS();exit();}
 if ($confirm == "false"){ShowMain();}
 if ($confirm == "")
  {
?>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD WIDTH=20>
    <A HREF="<?echo $PHP_SELF;?>"><IMG SRC="gfx/docman.gif" BORDER=0 ALT="<?echo _MAINMENU;?>"></A>
   </TD>
   <TD>
    <A HREF="<?echo $PHP_SELF;?>"><?echo _MAINMENU;?></A>
   </TD>
   <TD ALIGN=RIGHT>
    <?
     $res = mysql_query("SELECT * from $db_news order by datum desc") or die("<B>Error:</B>".mysql_error());
     $num = mysql_num_rows($res);
     echo _SUBMITEDNEWS.": ".$num;
    ?>
   </TD>
  </TR>
 </TABLE>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=1>
  <TR BGCOLOR=#<?echo $color02;?> CLASS=MojText>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _NEWSHEADLINE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _AUTHOR;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _DATE;?></FONT></TD>
   <TD><FONT COLOR=#<?echo $color05;?>><?echo _SECTION;?></FONT></TD>
  </TR>  
  <?php
    $res = mysql_query("SELECT * from $db_news where id='$id'") or die("<B>Error:</B>".mysql_error());
    $ar = mysql_fetch_array($res);
    $datum = formatTimestamp($ar[datum]);
    $res2 = mysql_query("SELECT * FROM $db_topic where id='$ar[category]'") or die("<B>Error:</B>".mysql_error());
    $ar2 = mysql_fetch_array($res2);

    echo "
 	 <TR CLASS=MojText>
	  <TD>$ar[headline]</TD>
  	  <TD>$ar[author]</TD>
  	  <TD>$datum</TD>
  	  <TD ALIGN=RIGHT VALIGN=TOP><IMG SRC=topic/$ar2[topicimage] ALT=\"$ar2[topictext]\" WIDTH=20></TD>
 	 </TR> 
 	 <TR><TD COLSPAN=4 Class=MojText>$ar[preview]</TD></TR></TABLE>";
?>  
<TABLE CELLSPACING=2 CELLPADDING=2><TR><TD VALIGN=TOP>
 <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="image" SRC="gfx/survey.gif" ALT="<?echo _KEEPIT;?>" BORDER=0 WIDTH=24 HEIGHT=24><BR>
  <INPUT TYPE="hidden" name="action" value="delete">
  <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
  <INPUT TYPE="hidden" name="info" value="<?echo $info;?>">
  <INPUT TYPE="hidden" name="confirm" value="false"></FORM>
</TD><TD VALIGN=TOP>
  <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="image" SRC="gfx/trash.gif" ALT="<?echo _DELETEIT;?>" BORDER=0 WIDTH=16 HEIGHT=16><BR>
  <INPUT TYPE="hidden" name="action" value="delete">
  <INPUT TYPE="hidden" name="info" value="<?echo $info;?>">
  <INPUT TYPE="hidden" name="id" value="<?echo $id;?>">
  <INPUT TYPE="hidden" name="confirm" value="true">
  </FORM>
</TD></TR></TABLE>
<?
 }
 }

function AddNews()
 {
  global $color01,$color02,$color03,$color04;
  global $id,$login,$headline,$message,$section,$info,$preview,$PHP_SELF;
  global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 // CHECK PRIVILEGIES
 if(CheckPriv("news_add") <> 1) { echo _NOTENOUGHPRIV;ShowMain();Exit;}

 if ($headline <> "" and $preview <> "")
 {
  $message = htmlentities($message);
  $headline = htmlentities($headline);
  $preview = htmlentities($preview);
  $res2 = mysql_query("SELECT * FROM $db_news WHERE preview='$preview'") or die("<B>Error:</B>".mysql_error());
  if(mysql_num_rows($res2)<1)
  {  
   $res = mysql_query("INSERT INTO $db_news VALUES(0,'$headline','$login','$section','',CURRENT_TIMESTAMP,'$preview','$message','uk',0)") or die("<B>Error:</B>".mysql_error());
  }
  makeRSS();
  ShowMain();
 }
 if ($headline == "" or $preview == "")
 { 
  ?>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD>
    <A HREF="news.php"><?echo _NEWSMANAGER;?></A>
   <TD ALIGN=RIGHT VALIGN=TOP>
    <?
     $res = mysql_query("SELECT * from $db_news order by datum desc") or die("<B>Error:</B>".mysql_error());
     $num = mysql_num_rows($res);
     echo _SUBMITEDNEWS.": ".$num;
    ?>
   </TD>
  </TR>
 </TABLE>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD>
    <IMG SRC="gfx/big_edit.gif"><FONT SIZE=3 FACE=Arial><B><?echo _ADDNEWS;?><B></FONT><BR>
   </TD>
  <TR>
  <TD>
   <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
    <?echo _NEWSHEADLINE;?><BR>
    <INPUT TYPE="text" NAME="headline" SIZE=60><BR>
    <?echo _SECTION;?>:<BR>
    <select name=section>
    <?php
    $res2 = mysql_query("SELECT * FROM $db_topic") or die("<B>Error:</B>".mysql_error());
    while ($ar2 = mysql_fetch_array($res2)){print "<option name=section value=$ar2[id]>$ar2[topictext]</option>";}
    ?>
   </select><BR>
   <?echo _PREVIEW;?><BR>
   <TEXTAREA NAME=preview COLS=60 ROWS=6></TEXTAREA><BR>
   <?echo _MESSAGE;?><BR>
   <TEXTAREA NAME=message COLS=60 ROWS=10></TEXTAREA>
   <input type="hidden" name="info" value="<?echo $info;?>">
   <input type="hidden" name="action" value="add"><BR><BR>
   <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
  </FORM></TD></TR>
 </TABLE> <?
 }
}
?>

 <?include ("header.php");
  if ($psw == TRUE)
   {
    if ($action == "")       { ShowMain();   }
    if ($action == "edit")   { EditNews();   }
    if ($action == "delete") { DeleteNews(); }
    if ($action == "add")    { AddNews();    }
    if ($action == "open")   { ShowMain();   }
    if ($action == "logout") { Logout();     }
   }
  include ("footer.php");
 ?>
