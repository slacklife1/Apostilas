<?
  //******************************************************************************************
  //**                                                                                      **
  //** phpNewsManager v1.30                                                                 **
  //** contact: gregor@klevze.si                                                            **
  //** Last edited: 10th.June,2002                                                          **
  //******************************************************************************************

  $title    = "phpNewsManager $newman_ver";
  include ("colors.php");
  include "functions.php";
  include ("header.php");
 
 if(CheckPriv("rss_edit") == 1)
 {
 ?>

 
  <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
   <TR>
   <TD WIDTH=20>
    <IMG SRC="gfx/docman.gif" BORDER=0 ALT="RSS">
   </TD>
   <TD>
    <?echo _RSSSETTINGS;?></A>
   </TD>
  </TR>
 </TABLE>
 <TABLE WIDTH=630 CELLSPACING=2 CELLPADDING=0 CLASS=MojText>
  <TR>
   <TD>
    <?
     if($action=="changeit")
     {
      mysql_query("UPDATE $db_rss SET filename='$filename', number='$number', title='$title', link='$link', description='$description', auto='$auto'") or die("ERROR 18:".mysql_error());
     }
     $res = mysql_query("SELECT * FROM $db_rss");
     $ar = mysql_fetch_array($res);
    ?>
    <FORM ACTION="<?echo $PHP_SELF;?>" METHOD=POST>
     <?echo _NAMEOFRSSFILE;?>:<BR>
     <INPUT TYPE="text" NAME="filename" CLASS=text VALUE="<?echo $ar[filename];?>"><BR>
     <?echo _NUMBEROFNEWS;?>:<BR>
     <INPUT TYPE="text" NAME="number" VALUE="<?echo $ar[number];?>"><BR>
     <?echo _RSSTITLE;?>:<BR>
     <INPUT TYPE="text" NAME="title" VALUE="<?echo $ar[title];?>"><BR>
     <?echo _RSSLINK;?>:<BR>
     <INPUT TYPE="text" NAME="link" VALUE="<?echo $ar[link];?>"><BR>
     <?echo _RSSDESCRIPTION;?>:<BR>
     <INPUT TYPE="text" NAME="description" VALUE="<?echo $ar[description];?>"><BR>
     <BR>
     <INPUT TYPE="checkbox" <?if($ar[auto]==1){echo " CHECKED ";}?> NAME="auto" VALUE="1"><?echo _AUTOCREATERSS;?><BR>
     <BR>
     <INPUT TYPE="hidden" NAME="action" VALUE="changeit">
     <INPUT TYPE="submit" VALUE="<?echo _SUBMIT;?>">
    </FORM>
   </TD>
  </TR>
 </TABLE>
<?
}
else
{
 echo _NOTENOUGHPRIV;
}
?>
 <?include ("footer.php");?>
