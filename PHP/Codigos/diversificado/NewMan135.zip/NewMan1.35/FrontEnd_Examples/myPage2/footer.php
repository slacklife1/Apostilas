<BR><BR><BR>
</TD>
</TR>
</TABLE>

  </TD>
  <TD WIDTH=160 ALIGN=RIGHT CLASS=MojText VALIGN=TOP>

   <TABLE WIDTH=141 ALIGN=CENTER CELLSPACING=0 CELLPADDING=0 CLASS=MojText>
    <TR>
     <TD BACKGROUND="gfx/menu1.jpg" WIDTH=141 HEIGHT=36>
      <SPAN STYLE="padding-left:5px; font-family:arial; font-size:12px; font-weight:bold;">
      USER</SPAN>
     </TD>
    </TR>
    <TR>
     <TD CLASS=BoxText BACKGROUND="gfx/menu2.jpg" STYLE="padding-left:5px; padding-right:5px;">
      <?ShowLoginMenu("#000000");?><BR>
     </TD>
    </TR>
    <TR>
     <TD>
      <IMG SRC="gfx/menu3.jpg"><BR>
     </TD>
    </TR>
   </TABLE>
   <BR>

   <TABLE WIDTH=141 ALIGN=CENTER CELLSPACING=0 CELLPADDING=0 CLASS=MojText>
    <TR>
     <TD BACKGROUND="gfx/menu1.jpg" WIDTH=141 HEIGHT=36>
      <SPAN STYLE="padding-left:5px; font-family:arial; font-size:12px; font-weight:bold;">
      PARTNERS</SPAN>
     </TD>
    </TR>
    <TR>
     <TD CLASS=BoxText BACKGROUND="gfx/menu2.jpg" STYLE="padding-left:5px; padding-right:5px;">
      <?ShowPartners("#000000");?><BR>
     </TD>
    </TR>
    <TR>
     <TD>
      <IMG SRC="gfx/menu3.jpg"><BR>
     </TD>
    </TR>
   </TABLE>
   <BR>

  </TD>
 </TR>
</TABLE>
 
<TABLE WIDTH=100%>
 <TR>
  <TD ALIGN=CENTER>
   <SPAN STYLE="font-family:tahoma; font-size:10px; color:#999999;">
    All rights reserved. Copyright 2001 by SkinTech Slovenija
   </SPAN>
  </TD>
 </TR>
</TABLE>
<?
$time_end = getmicrotime();
$time = $time_end - $time_start;
?>
<CENTER><SPAN STYLE="font-family:tahoma; font-size:7pt;">Computed in <?printf ("%.2f",$time);?> seconds</SPAN></CENTER>
</body>
</html>

