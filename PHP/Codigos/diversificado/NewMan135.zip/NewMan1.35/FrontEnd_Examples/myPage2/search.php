<HTML>
<!-- CREATION DATE: 16.8.00 -->
<HEAD>
<TITLE>Searching</TITLE>
<?php include("header.php");
?>
<BR>
<TABLE WIDTH=99% BORDER=0 CELLSPACING=0 CELLPADDING=2 BGCOLOR=#000000 ALIGN=CENTER>
<tr> 
 <td bgcolor="#9EC5E4" Class=MojText>
  <font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#ffffff">
  <b>
  <font face="Arial, Helvetica, sans-serif">
  Searching</span></b> | Query: <?echo "<B>$query</B>";?>
 </td>
</tr>
</table>

<?php
 print "<TABLE WIDTH=95% ALIGN=CENTER BORDER=0 CLASS=MojText>";
 print "<TR><TD>#</TD><TD>News</TD></TR>";
 $f=1; $tbs=0;

 $quer = "%$query%";
 $res = mysql_query("SELECT * FROM $db_news WHERE (preview like '$quer' or tekst like '$quer')"); 
 $num = mysql_num_rows($res);
 while ($ar = mysql_fetch_array($res))
  {
   $x++;
   $ar[description] = ereg_replace($query, "<b>$query</b>", $ar[description]);
   $ar[name]        = ereg_replace($query, "<b>$query</b>", $ar[name]);  
   $ar[uname]       = ereg_replace($query, "<b>$query</b>", $ar[uname]);
   $tb++;
   $barva="AED5F4";
   if ($tb == 2) { $tb=0; $barva="8EB5D4";}
   print "<TR><TD WIDTH=30 VALIGN=TOP BGCOLOR=#$barva CLASS=MojText><B><BIG>".$f++."</BIG></B></TD>";
   print "<TD BGCOLOR=#$barva CLASS=MojText><A HREF=news.php?id=$ar[id]>$ar[headline]</A> by $ar[author]<BR>".ttl(smiley($ar[preview]))."<BR></TD>";
   print "</TR>";
  }
 print "</TABLE>";

include("footer.php");
?>

