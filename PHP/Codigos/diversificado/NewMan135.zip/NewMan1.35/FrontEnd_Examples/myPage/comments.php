<HTML>
<!-- CREATION DATE: 1.9.2000 -->
<HEAD>
 <TITLE>News</TITLE>
<?php include("header.php");?>
<BR>
<?
if ($action=="store")
 {
  $comment = ereg_replace( "\n","<BR>",$comment);
  $comment = ereg_replace( "\"","&quot;",$comment);
  $comment = ereg_replace( "\'","&acute",$comment);
  $res = mysql_query("SELECT * FROM $db_news_comments WHERE tekst='$comment'");
  $num = mysql_num_rows($res);
  if (empty($num)) {$num=0;}  
  if ($num==0) 
  {
   $res = mysql_query("INSERT INTO $db_news_comments VALUES (0,'$id','$login',CURRENT_TIMESTAMP,'$comment')");

  }

 }
?>
<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=2 WIDTH=95% ALIGN=CENTER CLASS=MojText>
 <TR>
  <TD CLASS=MojText>
    <?php
     $aip = getenv("REMOTE_ADDR");
     $ip =gethostbyaddr($aip); 
     $g = mysql_query("SELECT * FROM $db_news_logged WHERE (nid=$id AND ip='$ip')");
     $ns = mysql_num_rows($g);
     if(empty($ns)) {$ns=0;}
     if ($ns < 1) {mysql_query("INSERT INTO $db_news_logged VALUES (0,'$id','$ip')");}
     $res = mysql_query("SELECT * FROM $db_news where id='$id'"); 
     while ($ar = mysql_fetch_array($res))
      { 
       $res2 = mysql_query("SELECT email FROM $db_users WHERE uname='$ar[author]'");
       $ar2 =  mysql_fetch_array($res2);
       $res3 = mysql_query("SELECT * FROM $db_topic where id='$ar[category]'"); 
       $ar3 = mysql_fetch_array($res3);

       $datum = formatTimestamp($ar[datum]);
       ?>
        <TABLE WIDTH=100% BGCOLOR=#6475AD CELLSPACING=1 CELLPADDING=3>
         <TR>
          <TD BGCOLOR=#D9D9D9 CLASS=MojText>
           <FONT SIZE=4><?echo $ar[headline];?></FONT><BR>Posted by <A HREF="mailto:<?echo $ar2[email];?>"><?echo $ar[author];?></A> on <?echo $datum;?> 
          </TD>
         </TR>
         <TR>
          <TD BGCOLOR=#ffffff CLASS=MojText>
           <IMG SRC="../topic/<?echo ttl($ar3[topicimage]);?>" ALIGN=RIGHT><?echo smiley(ttl($ar[preview]));?><BR><BR><?echo smiley(ttl($ar[tekst]));?><BR><BR>
<BR>
   <TABLE WIDTH=100% ALIGN=LEFT CELLSPACING=2 BGCOLOR=#6475AD CELLPADDING=0>
    <TR>
     <TD ALIGN=LEFT CLASS=MojText>
      <?
       $aip = getenv("REMOTE_ADDR");
       $ip =gethostbyaddr($aip); 
       $ress = mysql_query("SELECT * FROM $db_news_logged WHERE ip='$ip' and nid='$ar[id]'");
       $ars = mysql_fetch_array($ress);
       if (mysql_num_rows($ress)==0) 
        {
         mysql_query("INSERT INTO $db_news_logged VALUES (0,'$ar[id]','$ip')") or die ("napaka 001");
        }
       $resd = mysql_query("SELECT * FROM $db_news_comments WHERE nid='$ar[id]'");
       $ard = mysql_fetch_array($resd);
       $num = mysql_num_rows($resd);
       if(empty($num)) {$num =0;}
       echo "<A HREF=comments.php?id=$ar[id]>$num Comments</A>";
       echo " | ";
       echo "<A HREF=comments.php?id=$ar[id]&action=add>Add comment</A>";
       echo " | ";
       $resd = mysql_query("SELECT * FROM $db_news_logged WHERE nid='$ar[id]'") or die ("mysql error");
       $ard = mysql_fetch_array($resd);
       $num = mysql_num_rows($resd);
       if(empty($num)) {$num =0;}
       echo "$num times readed";
      ?>
     </TD>
    </TR>
   </TABLE>     

  </TD>
 </TR>
</TABLE>
<BR>
  <?  } ?>
  </TD>
 </TR>
</TABLE>
<BR>
<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=2 WIDTH=95% ALIGN=CENTER BGCOLOR=#3B4977>
 <TR>
  <TD BGCOLOR=#D9D9D9 CLASS=MojText>
   <FONT SIZE=4>Comments</FONT>
  </TD>
 </TR>
 <TR>
  <TD BGCOLOR=#ffffff CLASS=MojText>
<?
$res = mysql_query("SELECT * FROM $db_news_comments WHERE nid=$id ORDER BY datum");
while ($ar = mysql_fetch_array($res))
{
 $datum = formatTimestamp($ar[datum]);
 echo "<TABLE WIDTH=100% CELLSPACING=0 CELLPADDING=0 BORDER=0 CLASS=MojText><TR><TD VALIGN=TOP>";
 echo "By <A HREF=\"profile.php?uname=$ar[author]\">$ar[author]</A> on $datum:<BR>";
 echo smiley(ttl($ar[tekst]))."<BR></TD><TD VALIGN=TOP WIDTH=60 ALIGN=CENTER>";
 $res2=mysql_query("SELECT * from $db_users where uname='$ar[author]'");
 $ar2=mysql_fetch_array($res2);
 if(!empty($ar2[icon])){echo "<A HREF=\"profile.php?uname=$ar[author]\"><IMG SRC=\"/files/usericons/$ar2[icon]\" WIDTH=50 HEIGHT=50 BORDER=0></A>";}
 echo "</TD></TR><TD COLSPAN=2><HR SIZE=1 COLOR=#dddddd WIDTH=100%></TD></TR></TABLE>";
}
?>
  </TD>
 </TR>
</TABLE><BR>

<?
if ($action=="add")
 {
  ?>
<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=2 WIDTH=95% ALIGN=CENTER BGCOLOR=#3B4977>
 <TR>
  <TD BGCOLOR=#D9D9D9 CLASS=MojText>
   <FONT SIZE=4>Comments</FONT>
  </TD>
 </TR>
 <TR>
  <TD BGCOLOR=#ffffff CLASS=MojText>
   <?
   if ($login == "") 
    {echo "Please login first!<BR> If you still dont have an account, register it  <A HREF=\"signup.php\">here</A>";}
   else
   {
    ?>
     <FORM ACTION="?" METHOD=POST>
      Comments<BR>
      <TEXTAREA NAME=comment STYLE="width:99%;" ROWS=10 class=textarea></TEXTAREA>
      <INPUT TYPE="hidden" NAME="id" VALUE="<?echo $id;?>">
      <INPUT TYPE="hidden" NAME="action" VALUE="store"><BR><BR>
      <CENTER><INPUT TYPE="submit" value="Submit" class=submit></CENTER>
     </FORM>
     <?
    }
    ?>
    </TD>
   </TR>
  </TABLE><BR>
 <?
 }
?>

<?php include("footer.php");?>

