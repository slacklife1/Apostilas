<HTML>
<HEAD>
<TITLE>Lost password</TITLE>
<?php include("header.php");?>

<?
 if ($action == "sendpass")
 {
  $res0 = mysql_query("SELECT * FROM $db_users where uname='$nlogin'"); 
  $ar0 = mysql_fetch_array($res0);
  if($ar0[uname] == $nlogin)
  {
   echo "<BR><BR>
        <TABLE WIDTH=95% ALIGN=CENTER CELLSPACING=1 CELLPADDING=4 BGCOLOR=#3B4977 CLASS=MojText>
        <TR>
        <TD CLASS=MojText BGCOLOR=#6475AD>
        <H2>EMAIL SENT</H2>
        </TD>
        </tr>
        <TR>
        <TD CLASS=mojText BGCOLOR=#FFFFFF>
        Your password was sent.
        </TD>
        </TR>
        </TABLE><BR>";
        mail($ar0[email],"Password","Dear $nlogin,\n\n Password: $ar0[passwd] \n","From: webmaster@skinbase.org\n");
        include ("footer.php");
        exit;
     }
   }

?>

 <BR><BR>
 <TABLE WIDTH=95% ALIGN=CENTER CELLSPACING=1 CELLPADDING=5 BORDER=0 BGCOLOR=#3B4977>
  <TR>
   <TD BGCOLOR=#6475AD>
    LOST PASSWORD
   <TABLE WIDTH=100% ALIGN=CENTER CELLSPACING=0 CELLPADDING=0 BORDER=0 ALIGN=CENTER CLASS=MojText>
    <TR>
     <TD WIDTH=5 BGCOLOR=#ffffff></TD>
     <TD BGCOLOR=#ffffff>
      <FORM ACTION="?" METHOD=POST>
      Username<BR><INPUT TYPE="text" NAME="nlogin" SIZE=40><BR>
      <INPUT TYPE="hidden" NAME="action" value="sendpass">
      <INPUT TYPE="submit" VALUE="Submit"></FORM>
     </FORM>
     </TD>
    </TR>
   </TABLE>
  </TD>
 </TR>
</TABLE>

<?php include("footer.php");?>

