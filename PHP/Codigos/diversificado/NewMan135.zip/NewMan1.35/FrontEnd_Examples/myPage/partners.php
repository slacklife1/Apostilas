<HTML>
<!-- CREATION DATE: 16.8.00 -->
<HEAD>
 <TITLE>Skinbase.org: Links</TITLE>
<?php include("header.php");?>
<BR><BR>

<FONT SIZE=4 FACE=ARIAL><B>LINKS // PARTNERS </B></FONT>
<BR>
   <TABLE BORDER=0 CELLSPACING=2 CELLPADDING=4 WIDTH=95% ALIGN=CENTER>
      <?
      $res = mysql_query("select * from $db_partners order by name;");
      while($ar=mysql_fetch_array($res))
      {
      ?>
      <TR>
       <TD CLASS=MojText VALIGN=TOP>
        <FONT SIZE=3 FACE=ARIAL><B><A HREF="jump.php?id=<?echo $ar[id];?>" TARGET=_new><?echo $ar[name];?></A></B></FONT><BR>
        <A HREF="jump.php?id=<?echo $ar[id];?>" TARGET=_new><IMG SRC="../gfx/partners/<?echo $ar[picture];?>" BORDER=0></A><BR><?echo $ar[description];?><BR>
       </TD>
      </TR>
      <?
      }
      ?>
   </TABLE>
<?php include("footer.php");?>

