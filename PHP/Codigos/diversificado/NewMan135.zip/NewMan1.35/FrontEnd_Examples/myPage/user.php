<?php

Function ChangePassForm()
{
 global $color01,$color02,$color03,$color04,$color06,$color08,$color10,$v_icq;
 global $login;
 global $changepassword,$setnewpass,$username,$actualpassword,$newpassword,$retypenewpassword,$changeit;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
?>
<BR>
<TABLE WIDTH=99% BORDER=0 CELLSPACING=1 CELLPADDING=1 BGCOLOR=#3B4977 ALIGN=CENTER>
 <TR> 
  <TD BGCOLOR=#3B4977 Class=MojText>
   <b>   <font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#ffffff">
   Change Password</font></b> 
  </TD>
 </TR>
</TABLE>
<TABLE WIDTH=99% BORDER=0 CELLSPACING=1 CELLPADDING=1 BGCOLOR=#3B4977 ALIGN=CENTER>
 <TR BGCOLOR=#D9D9D9> 
  <TD Class=MojText>
   Change Pasword
  </TD>
 </TR>
  <TR BGCOLOR=#ffffff>
   <TD CLASS=MojText WIDTH=50% VALIGN=TOP>
      <FORM ACTION="?" METHOD=POST>
      <BR>
      <H3>Username: <?echo $login;?></H3>
      Password<BR><INPUT TYPE="password" NAME="oldpass" SIZE=20 MAXLENGHT=10 CLASS=input><BR>
      New password<BR><INPUT TYPE="password" NAME="newpass" SIZE=20 MAXLENGTH=10 CLASS=input><BR>
      Verify password<BR><INPUT TYPE="password" NAME="newpass2" SIZE=20 MAXLENGTH=10 CLASS=input><BR>
      <BR>
      <INPUT TYPE="hidden" NAME="action" value="savenewpass">
      <INPUT TYPE="submit" VALUE="Apply" CLASS=submit></FORM>
  </TD>
 </TR>
</TABLE>
<?}

Function ModifyProfileForm()
{
 global $login,$username,$email,$addinfo,$infos,$names;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
 $res = mysql_query("select * from $db_users where uname='$login'");
 $ar = mysql_fetch_array($res);
?>

<BR>
<TABLE WIDTH=99% BORDER=0 CELLSPACING=1 CELLPADDING=1 BGCOLOR=#3B4977 ALIGN=CENTER>
 <TR> 
  <TD BGCOLOR=#3B4977 Class=MojText>
   <font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#ffffff">
   <b><font face="Arial, Helvetica, sans-serif">Modify profile</font></b> 
  </TD>
 </TR>
</TABLE>
<TABLE WIDTH=99% BORDER=0 CELLSPACING=1 CELLPADDING=1 BGCOLOR=#3B4977 ALIGN=CENTER>
  <TR BGCOLOR=#ffffff>
   <TD CLASS=MojText WIDTH=100% VALIGN=TOP>

      <FORM ACTION="?" METHOD=POST>
       <H3>Username: <?php echo $login;?></H3>
       Email<BR><INPUT TYPE="text" NAME="email" VALUE="<?echo $ar[email];?>" SIZE=40 CLASS=input><BR>
       Real Name<BR><INPUT TYPE="text" NAME="names" VALUE="<?echo $ar[name]?>" SIZE=40 CLASS=input><BR>
       Info<BR><INPUT TYPE="text" NAME="infos" SIZE=40 VALUE="<?echo $ar[info];?>" CLASS=input><BR>
       <input type="hidden" name="action" value="savenewprofile"><BR>
       <INPUT TYPE="submit" VALUE="Update" CLASS=submit>
      </FORM>
  </TD>
 </TR>
</TABLE>
<?
}


Function SaveNewPass()
{
 global $color01,$color02,$color03,$color04,$color06,$color08,$color10;
 global $login,$newpass,$newpass2,$oldpass;
 global $passwordchanged,$oldpassnotmatch,$username;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
 $res = mysql_query("select passwd FROM $db_users WHERE uname='$login'");
 $ar = mysql_fetch_array($res);
 if ($ar[passwd] == $oldpass)
  {
   if ($newpass == $newpass2) {$res = mysql_query("update $db_users SET passwd='$newpass' where uname='$login'");}
   print "<DIV ALIGN=CENTER> Username: $login</DIV><BR>";
   print "<DIV ALIGN=CENTER><B>Success:</B>Password was changed<BR></DIV>";
  }
 else  {echo "Verify password!";}
}


Function SaveNewProfile()
{
 global $color01,$color02,$color03,$color04,$color06,$color08,$color10,$genders;
 global $action,$login,$date1,$date2,$date3,$gender,$lang,$newsletter,$email,$web,$icq,$country,$v_icq;
 global $yahoo,$aim,$msn,$infos,$names;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
 $res = mysql_query("update $db_users SET email='$email', name='$names', info='$infos' where uname='$login'");
 ModifyProfileForm();
}

?>
<HTML>
<!-- CREATION DATE: 16.8.00 -->
<HEAD>
<TITLE>User Modifications</TITLE>
<?php include("header.php");

if ($action == "changepass")     {ChangePassForm();}
if ($action == "savenewpass")    {SaveNewPass();}
if ($action == "editprofile")    {ModifyProfileForm();}
if ($action == "savenewprofile") {SaveNewProfile();}
if ($action == "userset")        {UserSettings();}

include("footer.php");?>

