<HTML>
<!-- CREATION DATE: 16.8.00 -->
<HEAD>
 <TITLE>Weekly Pool Results</TITLE>
<?php include("header.php");?>

<?php
 if ($pid <> "")
  {
   $gres = mysql_query("SELECT * FROM $db_weekQ where id=$pid"); 
   $gar = mysql_fetch_array($gres);
  }
  if ($pid == "")
   {
    $gres = mysql_query("SELECT * FROM $db_weekQ order by id desc limit 1"); 
    $gar = mysql_fetch_array($gres);
    $pid = $gar[id];
   }
 
$myvote = mysql_query("select count(*) as suma from $db_weekA where wid=$pid");
$myvres = mysql_fetch_array($myvote);
?>

 <BR><BR>

<TABLE WIDTH=99% BORDER=0 CELLSPACING=0 CELLPADDING=2 BGCOLOR=#3B4977 ALIGN=CENTER>
 <TR> 
  <TD BGCOLOR=#3B4977 Class=MojText>
   <font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#FFFFFF">
   <b>
   <font face="Arial, Helvetica, sans-serif">
   Weekly Poll</span></b> | Question: <?echo $gar[1];?> | Results: <?echo $myvres[suma];?>
  </TD>
</tr>
</table>
<BR>

<TABLE WIDTH=90% CELLSPACING=1 CELLPADDING=2 ALIGN=CENTER>
 <TR BGCOLOR=#6475AD Class=MojText>
  <TD>#</TD>
  <TD>Answers</TD>
  <TD>Numbers</TD>
  <TD>%</TD>
 </TR>
<?
 $odg = explode (":", $gar[2]);
 while ( list ($key,$values)= each($odg))
  {
   $x++;
   $myres = mysql_query("select count(*) as vote from $db_weekA where wid=$pid and answer=$key;");
   $myar  = mysql_fetch_array($myres);
   if ($ar[uname] == $login) { echo "<B>";}
   echo "<TR Class=MojText><TD>$x</TD>";
   echo "<TD>$values</TD>";
   echo "<TD>$myar[vote]</TD>";
   $procent = $myar[vote]/$myvres[suma]*100;
   printf ("<TD>%.2f</TD>",$procent);
   echo "</TR>";
  }
 echo "</TABLE>";?>
 
<?php include("footer.php");?>

