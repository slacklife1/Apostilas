<HTML>
<!-- CREATION DATE: 16.August.2000 -->
 <HEAD>
  <TITLE>Submit News</TITLE>
  <?php include("header.php");?>

<BR>

<?

if(empty($login))
{
 echo "Please Logon First!<BR>";
 include "footer.php";
 exit();
}
?>

<TABLE WIDTH=80% CELLSPACING=0 CELLPADDING=0 ALIGN=CENTER>
 <TR>
  <TD Class=MojText>
<?
 if ($headline <> "" and $preview <> "")
  {
   $nmessage = ereg_replace( "\n", "<BR>",$nmessage);
   $nmessage = ereg_replace( "\'", "&acute",$nmessage);
   $headline = ereg_replace( "\"", "&quot;",$headline);
   $headline = ereg_replace( "\n", " ",$headline);
   $headline = ereg_replace( "\'", "�",$headline);
   $preview = ereg_replace( "\n", "<BR>",$preview);
   $preview = ereg_replace( "\'", "�",$preview);
   $res2 = mysql_query("SELECT * FROM $db_pnews WHERE preview='$preview'");
   if(mysql_num_rows($res2)<1){$res = mysql_query("INSERT INTO $db_pnews VALUES(0,'$headline','$login','$msection','',CURRENT_TIMESTAMP,'$preview','$nmessage','uk')") or die("error<BR>");}
   ?>
  <TABLE WIDTH=80% ALIGN=CENTER CELLSPACING=0 CELLPADDING=0>
   <TR>
    <TD CLASS=MojText VALIGN=TOP>
     News received<BR>
    </TD>
   </TR>
  </TABLE>	
  </TD>
 </TR>
</TABLE>
<? 
  include("footer.php");
  exit();

  }
 if ($headline == "" or $preview == "")
  { 
   ?>
    <TABLE WIDTH=100% CELLSPACING=2 CELLPADDING=0>
    <TR><TD CLass=MojText>
    <FORM ACTION="?" METHOD="POST">
    Headline<BR>
    <INPUT TYPE="text" NAME="headline" class=input SIZE=60><BR>
    Category:<BR>
    <select name=msection class=input>
    <?php
    $res2 = mysql_query("SELECT * FROM topic"); 
    while ($ar2 = mysql_fetch_array($res2)){print "<option name=msection value=$ar2[id]>$ar2[topictext]</option>";}
    ?>
   </select><BR>
   Preview<BR>
   <TEXTAREA NAME=preview COLS=60 ROWS=6 class=textarea></TEXTAREA><BR>
   Message<BR>
   <TEXTAREA NAME=nmessage COLS=60 ROWS=10 class=textarea></TEXTAREA>
   <input type="hidden" name="action" value="add"><BR><BR>
   <INPUT TYPE="submit" VALUE="Submit" class=submit>
  </FORM></TD></TR></TABLE> 
  <?}?>

  </TD>
 </TR>
</TABLE>

<?php include("footer.php");?>
