<?
 include "../db.inc.php";
 $link = mysql_connect("$db_server","$db_uname","$db_pass");
 mysql_select_db($db_name); 

 mysql_query("UPDATE partners SET out=out+1 WHERE id=$id");
 $res = mysql_query("SELECT * FROM partners WHERE id=$id");
 $ar=mysql_fetch_array($res);

 header ("Location: $ar[link]");
?>
