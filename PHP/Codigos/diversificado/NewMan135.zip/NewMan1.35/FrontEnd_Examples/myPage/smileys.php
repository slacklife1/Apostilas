<HTML>
<!-- CREATION DATE: 16.8.00 -->
<HEAD>
 <TITLE>Smiley's</TITLE>
<?php include("header.php");?>
<BR><BR>
<TABLE WIDTH=95% BORDER=0 CELLSPACING=0 CELLPADDING=2 BGCOLOR=#<?echo $color03;?> ALIGN=CENTER>
<tr> 
 <td width="82%" bgcolor="#<?echo $color03;?>" Class=MojText>
  <font size="2" face="Verdana, Arial, Helvetica, sans-serif" color="#<?echo $color06;?>">
  <b>
  <font face="Arial, Helvetica, sans-serif">
   SMILEYS CODE
 </font></font></td>
 <td width="18%" bgcolor="#<?echo $color10;?>"> 
 </td>
</tr>
</table>

<TABLE WIDTH=100% CELLSPACING=0 CELLPADDING=0>
 <TR>
  <TD Class=MojText>
   <BR>

   <TABLE BORDER=0 CELLSPACING=3 CELLPADDING=3 WIDTH=90% ALIGN=CENTER >
    <?
     $x=0;
?>


    <TR Class=mojtext>
     <TD CLASS=MojText VALIGN=TOP> 
      <?
       $res=mysql_query("SELECT * FROM $db_smiles ORDER BY emotion;");
       while($ar=mysql_fetch_array($res))
       {
        $x++;
        if ($x == 1) { echo "<TR>";};
        $nm = $xnum[$ar[fname]];
        echo "<TD WIDTH=30 VALIGN=TOP CLASS=Smallt><IMG SRC=\"../gfx/smiles/$ar[smile]\" BORDER=0 ALT=\"$ar[emotion]\"></TD><TD CLASS=MojText>$ar[code]</TD><TD CLASS=MojText>$ar[emotion]</TD>";
        if ($x == 3) { echo "</TR>";$x=0;};
       }
       ?>
     </TD>
    </TR>
   </TABLE>

</TD></TR></TABLE>
<?php include("footer.php");?>
