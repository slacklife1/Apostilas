<?
function ttl ($data='') 
 {
  if(empty($data)) { return $data; }
  $lines = split("\n",$data);
  while ( list ($key,$line) = each ($lines)) {
  $line = eregi_replace("([ \t]|^)www\."," http://www.",$line);
  $line = eregi_replace("([ \t]|^)ftp\."," ftp://ftp.",$line);
  $line = eregi_replace("(http://[^ )\r\n]+)","<A href=\"\\1\" target=\"_blank\">\\1</A>",$line);
  $line = eregi_replace("(https://[^ )\r\n]+)","<A href=\"\\1\" target=\"_blank\">\\1</A>",$line);
  $line = eregi_replace("(ftp://[^ )\r\n]+)","<A href=\"\\1\" target=\"_blank\">\\1</A>",$line);
  $line = eregi_replace("([-a-z0-9_]+(\.[_a-z0-9-]+)*@([a-z0-9-]+(\.[a-z0-9-]+)+))","<A HREF=\"mailto:\\1\">\\1</A>",$line);
  $newText .= $line . "\n";
 }
 return $newText;
}

function ttl2 ($data='') 
 {
  if(empty($data)) { return $data; }
  $lines = split("\n",$data);
  while ( list ($key,$line) = each ($lines)) {
  $line = eregi_replace("([ \t]|^)www\."," http://www.",$line);
  $line = eregi_replace("([ \t]|^)ftp\."," ftp://ftp.",$line);
  $line = eregi_replace("(http://[^ )\r\n]+)","<A href=\"\\1\" target=\"_blank\">\\1</A>",$line);
  $line = eregi_replace("(https://[^ )\r\n]+)","<A href=\"\\1\" target=\"_blank\">\\1</A>",$line);
  $line = eregi_replace("(ftp://[^ )\r\n]+)","<A href=\"\\1\" target=\"_blank\">\\1</A>",$line);
  $line = eregi_replace("([-a-z0-9_]+(\.[_a-z0-9-]+)*@([a-z0-9-]+(\.[a-z0-9-]+)+))","<A HREF=\"mailto:\\1\">\\<LINK></A>",$line);
  $newText .= $line . "\n";
 }
 return $newText;
}

 function online($username,$color)
{
 global $therearecurrently,$guest,$member,$l_guest;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smileys,$db_topic,$db_users,$db_weekQ,$db_weekA;
 $ip = getenv("REMOTE_ADDR");
 if ($username == '') {$username = "$ip"; $guest = 1;}
 $past = time()-900;
 mysql_query("DELETE FROM $db_session WHERE time < $past");
 $result = mysql_query("SELECT time FROM $db_session WHERE username='$username'");
 $ctime = time();
 if ($row = mysql_fetch_array($result)){mysql_query("UPDATE $db_session SET username='$username', time='$ctime', host_addr='$ip', guest='$guest' WHERE username='$username'");} 
 else {mysql_query("INSERT INTO $db_session (username, time, host_addr, guest) VALUES ('$username', '$ctime', '$ip', '$guest')");}
 $result = mysql_query("SELECT username FROM $db_session where guest=1");
 $guest_online_num = mysql_num_rows($result);
 $result = mysql_query("SELECT username FROM $db_session where guest=0");
 $member_online_num = mysql_num_rows($result);
 $who_online_num = $guest_online_num + $member_online_num;
 echo "<SPAN STYLE=\"color:$color;\">";
 echo "$therearecurrently:<BR> <LI> $l_guest: $guest_online_num <LI>$member: $member_online_num <br></SPAN>";
}

Function Smiley($string)
{
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smileys,$db_topic,$db_users,$db_weekQ,$db_weekA;
 $getsmiles = mysql_query("SELECT * FROM $db_smileys") or die (mysql_error());
 while($sm = mysql_fetch_array($getsmiles))
 {
    $string = str_replace($sm[code], "<IMG SRC=\"../gfx/smiles/$sm[smile]\" BORDER=0>", $string);
 }
 return $string;
}

function formatTimestamp($time) 
 {
  ereg ("([0-9]{4})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})", $time, $datetime);
  $datetime = date("F jS @ H:i", mktime($datetime[4],$datetime[5],$datetime[6],$datetime[2],$datetime[3],$datetime[1]));
  return($datetime);
}

function CheckLogin($login,$pass)
{
  global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smileys,$db_topic,$db_users,$db_weekQ,$db_weekA;
  $passek = "notok";
  $result = mysql_query("select passwd from $db_users where uname='$login'") or die ("Invalid query");
  $ar = mysql_fetch_array($result);
  $num = mysql_num_rows($result);
  if($num == 1) {if ($ar[passwd] == "$pass") {$passek="ok";}}
  return $passek;
}

function CheckTheLogin()
{
  global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smileys,$db_topic,$db_users,$db_weekQ,$db_weekA;
  $info = base64_decode("$users");
  $info = explode(":", $info);
  $login = $info[0];
  $pass = $info[1];

  $result = mysql_query("select passwd from $db_users where uname='$login'") or die ("Invalid query");
  $passek = "notok";
  if(mysql_num_rows($result)==1) 
   {
    $ar = mysql_fetch_array($result);
    if ($ar[passwd] == $pass) {$passek="ok";} 
   }
  if ($login == "") {$passek="notok";}
  return $passek;
}

Function ShowLoginMenu($color)
{
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smileys,$db_topic,$db_users,$db_weekQ,$db_weekA;
 global $login,$pass;
?>
<TABLE WIDTH=98% BORDER=0 ALIGN=CENTER CELLPADDING=0 CELLSPACING=0>
 <TR> 
  <TD class=mojlink> 
   <?
   $passek = CheckLogin($login,$pass);
   if ($passek <> "ok") 
    {
    ?>
    <FORM ACTION="index.php" METHOD=POST>
    <SPAN STYLE="color:<?echo $color;?>;">
    Username<BR><INPUT TYPE="text" NAME="login" SIZE=12 class=input><BR>
    Password<BR><INPUT TYPE="password" NAME="pass" SIZE=12 class=input>
    <INPUT TYPE="hidden" NAME="action" VALUE="Login"><BR>
    <INPUT TYPE="submit" Value="Login" class=submit><BR>
    <HR SIZE=1 COLOR=#<?echo $color00;?>>
    <A HREF="signup.php" STYLE="color:<?echo $color;?>;">Signup</A><BR>
    <A HREF="lostpass.php" STYLE="color:<?echo $color;?>;">Lost Pass</A><BR>
    </SPAN>
    </FORM> <?
 }
 if ($passek == "ok") 
    {
     echo "<A HREF='user.php?action=changepass' STYLE=\"color:$color;\">Change pass</A><BR>";
     echo "<A HREF='user.php?action=editprofile' STYLE=\"color:$color;\">Edit profile</A><BR>";
     echo "<A HREF=\"addnews.php\" STYLE=\"color:$color\">Submit News</A><BR>";
     echo "<A HREF='index.php?action=Logout' STYLE=\"color:$color;\">Logout</A><BR><BR>";
    }
   ?>
  </TD>
 </TR>
 </TABLE>
<?
}

Function SearchMenu($color)
{
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smileys,$db_topic,$db_users,$db_weekQ,$db_weekA;
 global $squery,$HTTP_USER_AGENT;
?>
  <TABLE WIDTH=98% BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=CENTER>
   <TR> 
    <TD class=mojlink>
     <SPAN STYLE="color:<?echo $color;?>;">
      <FORM ACTION="search.php" METHOD="POST">
       Search for<BR>
       <input type="text" name="query" size=10 class=input>
       <input type="submit" value="GO" class=submit><BR>
       <input type="hidden" name="action" value="search">
      </FORM>
     </SPAN>
    </TD>
   </TR>
  </TABLE>
<?
}

Function ShowWeeklyPool($color)
{
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smileys,$db_topic,$db_users,$db_weekQ,$db_weekA;
 global $voteview,$vote;
 ?>
 <TABLE WIDTH=98% BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=CENTER>
  <TR> 
   <td class=mojlink> 
    <SPAN STYLE="color:<?echo $color;?>;">
    <?
     $gres = mysql_query("SELECT * FROM $db_weekQ order by ID desc limit 1"); 
     $gar = mysql_fetch_array($gres);
     $odg = explode (":", $gar[2]);
    ?>
    <FORM ACTION="vote.php" METHOD=POST>
     <?echo $gar[1];?><BR>

       <?php
       while ( list ($key,$values)= each($odg))
        {
         echo "<INPUT TYPE=\"radio\" NAME=\"pool\" VALUE=\"$key\" class=radio>$values<BR>";
        }
       ?>
       <INPUT TYPE="hidden" NAME="vid" VALUE="<?echo $gar[0];?>">
       <INPUT TYPE="submit" VALUE="vote" class=submit>
       <?
        $gres = mysql_query("SELECT * FROM $db_weekQ order by id desc limit 1"); 
        $gar = mysql_fetch_array($gres);
        $pid = $gar[id];
        $myvote = mysql_query("select count(*) as suma from $db_weekA where wid=$pid");
	$myvres = mysql_fetch_array($myvote);
       ?>
       <BR><A HREF="voteres.php" STYLE="color:<?echo $color;?>;"><?echo $myvres[suma];?> Results</A>
       </FORM>
       </SPAN>
      </TD>
     </TR>
    </TABLE>
<?
}

Function ShowPartners($color)
{
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smileys,$db_topic,$db_users,$db_weekQ,$db_weekA;
 ?>
 <TABLE WIDTH=98% BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=CENTER>
  <TR> 
   <TD class=mojlink>


    <?
     $res = mysql_query("select * from $db_partners where main=1 and gfx=0 ORDER by name;");
     while($ar=mysql_fetch_array($res))
     {
      echo "<A HREF=\"jump.php?id=$ar[id]\"  STYLE=\"color:$color\" TARGET=_new>$ar[name]</A><BR>";     
     }
    ?>    
    <BR>
    <?
     $res = mysql_query("select * from $db_partners where main=1 and gfx=1 ORDER by name;");
     while($ar=mysql_fetch_array($res))
     {
      echo "<A HREF=\"jump.php?id=$ar[id]\" target=_new><IMG WIDTH=88 HEIGHT=31 SRC=\"./../gfx/partners/$ar[picture]\" border=0></A>\n";
      echo "<BR>";     
     }
    ?>    
    <BR>
    <A HREF="partners.php"  STYLE="color:<?echo $color;?>;">More...</A><BR>
   </TD>
  </TR>
 </TABLE>
<BR>
<?
}


?>