<BR><BR><BR>
</TD>
</TR>
</TABLE>

  </TD>
  <TD WIDTH=160 ALIGN=RIGHT CLASS=MojText VALIGN=TOP>

<TABLE WIDTH=160 CELLSPACING=0 CELLPADDING=0 CLASS=MojText>
 <TR>
  <TD>
   <img src="./gfx/okvir-r-up-skins.gif" border="0" width="160" height="26" alt=""><BR>
  </TD>
 </TR>
 <TR>
  <TD BACKGROUND="./gfx/okvir-r-mid.gif" WIDTH=160 HEIGHT=100 CLASS=MojText>
   <SPAN STYLE="width:158px; font-family:verdana; color:#FFcc00; padding-left:15px;">
   <B><IMG SRC="./gfx/green-arrow.gif" width=10 height=10 border=0><font color="#ffcc00">
    <?php
       if (!empty($login)) { echo "Logged";}
       if (empty($login)) { echo "Not Logged";}
      ?></B><BR>            
     <?ShowLoginMenu("#192251");?>  
      <BR>
     <B><IMG SRC="./gfx/green-arrow.gif" width=10 height=10 border=0><font color="#ffcc00">Partners</font><BR></B>
    <?ShowPartners("#192251");?>
    <BR>

      <BR>
  </TD>
 </TR>
 <TR>
  <TD>
   <img src="./gfx/okvir-r-bot.gif" border="0" width="160" height="24" alt=""><BR>
  </TD>
 </TR>
</TABLE>
 </SPAN>
  </TD>
 </TR>
</TABLE>
 
<TABLE WIDTH=100%>
 <TR>
  <TD ALIGN=CENTER>
   <SPAN STYLE="font-family:tahoma; font-size:10px; color:#999999;">
    All rights reserved. Copyright 2001 by SkinTech Slovenija
   </SPAN>
  </TD>
 </TR>
</TABLE>
<?
$time_end = getmicrotime();
$time = $time_end - $time_start;
?>
<CENTER><SPAN STYLE="font-family:tahoma; font-size:7pt;">Computed in <?printf ("%.2f",$time);?> seconds</SPAN></CENTER>
</body>
</html>

