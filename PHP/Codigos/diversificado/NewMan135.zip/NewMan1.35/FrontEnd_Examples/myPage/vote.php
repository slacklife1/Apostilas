<HTML>
<!-- CREATION DATE: 16.8.00 -->
<HEAD>
 <TITLE>Weekly Poll</TITLE>
<?php include("header.php");?>

<?

$gres = mysql_query("SELECT * FROM $db_weekQ where ID='$vid'"); 
$gar = mysql_fetch_array($gres);

$res = mysql_query("INSERT INTO $db_weekA VALUES (0,'$vid','$pool')"); 
 
?>
 <BR><BR>
<?php
 if ($pid <> "")
  {
   $gres = mysql_query("SELECT * FROM $db_weekQ where id=$pid"); 
   $gar = mysql_fetch_array($gres);
  }
  if ($pid == "")
   {
    $gres = mysql_query("SELECT * FROM $db_weekQ order by id desc limit 1"); 
    $gar = mysql_fetch_array($gres);
    $pid = $gar[id];
   }
 
$myvote = mysql_query("select count(*) as suma from $db_weekA where wid=$pid");
$myvres = mysql_fetch_array($myvote);
?>

 <BR><BR>

<TABLE WIDTH=99% BORDER=0 CELLSPACING=0 CELLPADDING=2 ALIGN=CENTER>
 <TR> 
  <TD Class=MojText>
   <b>
   <font face="Arial, Helvetica, sans-serif">
   Weekly Poll</span></b> | Question was: <?echo $gar[1];?> | Answer: <?echo $myvres[suma];?>
  </TD>
</tr>
</table>
<BR>

<TABLE WIDTH=90% CELLSPACING=1 CELLPADDING=2 ALIGN=CENTER>
 <TR Class=MojText>
  <TD>#</TD>
  <TD>Asnwers</TD>
  <TD>Number</TD>
  <TD>%</TD>
 </TR>
<?
 $odg = explode (":", $gar[2]);
 while ( list ($key,$values)= each($odg))
  {
   $x++;
   $myres = mysql_query("select count(*) as vote from $db_weekA where wid=$pid and answer=$key;");
   $myar  = mysql_fetch_array($myres);
   if ($ar[uname] == $login) { echo "<B>";}
   echo "<TR Class=MojText><TD>$x</TD>";
   echo "<TD>$values</TD>";
   echo "<TD>$myar[vote]</TD>";
   $procent = $myar[vote]/$myvres[suma]*100;
   printf ("<TD>%.2f</TD>",$procent);
   echo "</TR>";
  }
 echo "</TABLE>";?>
<BR>

 <TABLE WIDTH=95% ALIGN=CENTER CELLSPACING=1 CELLPADDING=5 BORDER=0>
  <TR>
   <TD>
   <BR><FONT FACE=5><B>Thank you for voting</B></FONT><BR>
   Your vote was saved!<BR>

   <TABLE WIDTH=100% ALIGN=CENTER CELLSPACING=0 CELLPADDING=0 BORDER=0>
    <TR>
     <TD>
      <SPAN STYLE="width:400; text-align:justify; padding-left:14pt;">
       <BR>
       <?php
        $odg = explode (":", $gar[2]);
	$ans = $odg[$pool];
       ?>
       Your vote:<B><?echo $ans?></B><BR>
     </TD>
    </TR>
   </TABLE>
  </TD>
 </TR>
</TABLE>


<?php include("footer.php");?>

