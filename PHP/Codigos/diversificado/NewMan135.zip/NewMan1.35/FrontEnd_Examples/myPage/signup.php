<HTML>
<HEAD>
<TITLE>Signup</TITLE>
<?include("header.php");?>

<?
  if ($action == "Signuped")
   {
    ?>
     <HTML>
     <HEAD>
     <TITLE>Signup</TITLE>
      <?

    if ($passwd <> $chkpass)
     {
      print "<TABLE ALIGN=CENTER WIDTH=95%><TR><TD><H1>$error:</H1>$passwnotm</TD></TR></TABLE>";
      include ("footer.php");
      exit;
     }

    if ($nlogin == "")
     {
      print "<TABLE ALIGN=CENTER WIDTH=95%><TR><TD><H1>Error:</H1>Username exist</TD></TR></TABLE>";
      include ("footer.php");
      exit;
     }
    if ($passwd == "")
     {
      print "<TABLE ALIGN=CENTER WIDTH=95%><TR><TD><H1>Error:</H1>Check password</TD></TR></TABLE>";
      include ("footer.php");
      exit;
     }

    $res = mysql_query("SELECT uname FROM $db_users where uname='$nlogin'"); 
    $ar = mysql_fetch_array($res);

    if($ar[uname] == $nlogin)
     {
      print "<TABLE ALIGN=CENTER WIDTH=95%><TR><TD><H1>$error:</H1>$unameinuse</TD></TR></TABLE>";
      include ("footer.php");
      exit;
     }

   $res = mysql_query("INSERT INTO $db_users VALUES(0,'$nlogin','$passwd','$email','$infos','$rname')") or die("error"); 

   print "
    <BR><BR>
   <TABLE WIDTH=80% ALIGN=CENTER CELLSPACING=1 CELLPADDING=4 BGCOLOR=#3B4977>
    <TR>
     <TD CLASS=MojText BGCOLOR=#6475AD>
      <H2>Welcome</H2>
     </TD>
    </tr>
    <TR>
     <TD CLASS=mojText BGCOLOR=#FFFFFF>
      <B>$login</B>, you're member of our service.<BR>
      <HR><BR>
	Check email box for further instructions.
     </TD>
    </TR>
   </TABLE><BR>
   ";
   mail($email,"Signup","dear $nlogin,\n\nInfo: username: $nlogin\npassword:	$passwd\n\n","From: info@skinbase.org\n");
   include ("footer.php");
   exit;
   }

?>

 <BR><BR>
 <TABLE WIDTH=80% ALIGN=CENTER CELLSPACING=1 CELLPADDING=5 BORDER=0 BGCOLOR=#3B4977 CLASS=MojText>
  <TR>
   <TD BGCOLOR=#6475AD>
   <BR><FONT FACE=5 COLOR=#FFFFFF><B>SIGNUP</B></FONT><BR>

   <TABLE WIDTH=100% ALIGN=CENTER CELLSPACING=0 CELLPADDING=0 BORDER=0 CLASS=MojText>
    <TR>
     <TD WIDTH=5 BGCOLOR=#FFFFFF></TD>
     <TD BGCOLOR=#FFFFFF>
  <FORM ACTION="signup.php" METHOD=POST>
   Username<BR><INPUT TYPE="text" NAME="nlogin" SIZE=40 class=input><BR>
   Password<BR><INPUT TYPE="password" NAME="passwd" SIZE=40 MAXLENGTH=10 class=input><BR>
   Validate password<BR><INPUT TYPE="password" NAME="chkpass" SIZE=40 MAXLENGTH=10 class=input><BR>
   Email<BR><INPUT TYPE="text" NAME="email" SIZE=40 MAXLENGTH=80" class=input><BR>
   Info<BR><INPUT TYPE="text" NAME="infos" SIZE=40 MAXLENGTH=120 class=input><BR>
   Real Name<BR><INPUT TYPE="text" NAME="rname" SIZE=40 MAXLENGTH=120 class=input><BR>
   <input type="hidden" name="action" value="Signuped"><BR>
   <INPUT TYPE="submit" VALUE="Submit" class=submit>
   </FORM>
     </TD>
    </TR>
   </TABLE>
  </TD>
 </TR>
</TABLE>

<?php include("footer.php");?>

