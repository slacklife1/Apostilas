<?
 function getmicrotime()
 { 
  list($sec, $usec) = explode(" ",microtime()); 
  return ($sec + $usec); 
 } 
$time_start = getmicrotime();

include "../db.inc.php";
$link = mysql_connect("$db_server","$db_uname","$db_pass");
mysql_select_db($db_name); 

if ($action <> "Login")
 {
  $info = base64_decode("$users");
  $info = explode(":", $info);
  $login = $info[0];
  $pass = $info[1];
 }
 
if ($action == "Logout")
 {
  $login = "";
  $pass = "";
 }

include ("functions.php");

?>

<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<META NAME="description" CONTENT="skinbase.org - Fast and Free Graphics portal for a many skinning programs like 3D-FTP, 3dftp, 3D Studio Max, @time, attime, Aimster, aimster, Aston, aston, AXE, axe, Axion Chat, axion, BabelFish, babelfish, Banshee, banshee, BeatNik, beatnik, BeautifulCalc, beautifu, Blaze Media Pro, blazemed, BoxBar, boxbar, BoxCard, boxcard, BoxChess, boxchess, BoxFonts, boxfonts, BoxIP, boxip, BoxKeeper, boxkeeper, BoxSpectra, boxspectra, BoxZoom, boxzoom, BS Player, bsplayer, BuddyPhone, buddyphone, C-4, c4, Calenz, calenz, CD Stomper, cdstomper, CDRun, cdrun, Chameleon, chameleon, Chroma, chroma, Clock Candy, ccandy, Codename2, codename2, Cool Desk 99, cooldesk99, ColorPad, colorpad, Consolable, consolab, ControlBar, controlb, CoolDesk, cooldesk, CoolPlayer, coolplayer, CoordPad, coordpad, Copernic 2000, copernic, CyberJukebox, cybjuke, DarkStep, darkstep, DesktopX Objs, dxobjects, DesktopX, dxthemes, DigiDeck, digideck, DigitalCD, digitalcd, DJ2000, dj2000, dvwm, dvwm, eFX, efx, EGN, egn, EgoMainiac, egomaini, eLOL, elol, EuroCalculator, eurocalc, EVWM, evwm, EzPop, ezpop, FireBurner, fireburn, FiveClock, fiveclock, FreeAmp, freeamp, FunkyFX, funkyfx, GameSpy Arcade, gamespy, Get Smart, getsmart, Ge0Shell, geoshell, GetRight, getright, Gnotella, gnotella, Groove, groove, GuidesX Encrypt, guidesxe, Half-Life, halflife, Hotbar, hotbar, HoverDesk, hoverdes, ICCD, iccd, iCaster, icaster, IceSphere, icesphere, IconPackager, iconpackager, ICQ Plus 1.x, icqplus1, ICQ Plus 2.x, icqplus2, Illumination, illumination, iMesh, imesh, iPanel, ipanel, Jet Audio, jetaudio, Jotter, jotter, K-Jofol, kjofol, L-ement, lement, LAUNCHkaos, launchkaos, Litestep, litestep, Mad Cow, madcow, Mail Checker, mailchec, MaxxChat, maxxchat, MemoPad, memopad, Media Jukebox, mediajuke, Media Wizard, mediawizard, MechWarrior 3, mektek, MicroDVD, microdvd, Millenium Note, millnote, MP3Spy, mp3spy, MP3Studio, mp3studio, MPFree, mpfree, MusicMatch, mmjb, MyCQ, mycq, MyPad, mypad, NECST, necst, NeoPlanet, neoplanet, NextSTART, nextstart, NewsNabber, newsnabber, Odigo, odigo, Outsider99, outsider99, Oxygenator, oxygenat, PageLink, pagelink, PalmOS Emu, palmemu, PAM, pam, Pluser, pluser, Poco, poco, PowerDVD, powerdvd, PowerPager, powerpager, PSmplay, psmplay, PureLS, purels, QCD, qcd, QCD 2.x, qcd2, QCD 3.x, qcd3, Quake, quake, Quake2, quake2, Quake3, quake3, Quick Clock, custoclock, QuickLAUNCH, qlaunch, QuickNotes, quicknotes, Quintessential, quint, QX, qx, RealJukeBox, realjukebox, Reveal, reveal, Scribbles, scribbles, Serenade, serenade, SAP, sap, SimpleCD, simplecd, SkinnyMix, skinnymix, SkinnyPad, skinnypad, SkinPad, skinpad, Socket, socket, SongSpy, songspy, Sonique, sonique, Soritong, soritong, StationRadio, stationradio, SysMeter 1, sysmeter, SysMeter 2, sysmeter2, Talisman, talisman, The Clock, theclock, ThemeBar, themebar, Throttlebox, throttle, VirtualTurntables, turntabl, Tyme, tyme, UltraPlayer, ultraplayer, UnrealPlayer, unrealplayer, URLMenu99, urlmenu, uTOK, utok, VDE, vde, VivTV, vivtv, VoidEYE, voideye, Wallpapers, wallpapers, WBiff, wbiff, Weather1, weather1, WebBlinds, webblinds, WinAmp, winamp, WinAmp 2.x, winamp2, WindowBlinds, wb, WinPanel, winpanel, WMP7, wmp7, WPlay, wplay, xiOn, xion, XXCalc, xxcalc, YahooMessenger, yahoo, YAwN, yawn, YerTV, yertv, Yo!NK, yoink, ZVolume, zvolume,  and many more of them">
<META NAME="keywords" CONTENT="skins, skinz, 3ds, max, scenes, free, hot, new, graphics, gfx, web, webmaster, nullsoft, stardock, 3D-FTP, 3dftp, @time, attime, Aimster, aimster, Aston, aston, AXE, axe, Axion Chat, axion, BabelFish, babelfish, Banshee, banshee, BeatNik, beatnik, BeautifulCalc, beautifu, Blaze Media Pro, blazemed, BoxBar, boxbar, BoxCard, boxcard, BoxChess, boxchess, BoxFonts, boxfonts, BoxIP, boxip, BoxKeeper, boxkeeper, BoxSpectra, boxspectra, BoxZoom, boxzoom, BS Player, bsplayer, BuddyPhone, buddyphone, C-4, c4, Calenz, calenz, CD Stomper, cdstomper, CDRun, cdrun, Chameleon, chameleon, Chroma, chroma, Clock Candy, ccandy, Codename2, codename2, Cool Desk 99, cooldesk99, ColorPad, colorpad, Consolable, consolab, ControlBar, controlb, CoolDesk, cooldesk, CoolPlayer, coolplayer, CoordPad, coordpad, Copernic 2000, copernic, CyberJukebox, cybjuke, DarkStep, darkstep, DesktopX Objs, dxobjects, DesktopX, dxthemes, DigiDeck, digideck, DigitalCD, digitalcd, DJ2000, dj2000, dvwm, dvwm, eFX, efx, EGN, egn, EgoMainiac, egomaini, eLOL, elol, EuroCalculator, eurocalc, EVWM, evwm, EzPop, ezpop, FireBurner, fireburn, FiveClock, fiveclock, FreeAmp, freeamp, FunkyFX, funkyfx, GameSpy Arcade, gamespy, Get Smart, getsmart, Ge0Shell, geoshell, GetRight, getright, Gnotella, gnotella, Groove, groove, GuidesX Encrypt, guidesxe, Half-Life, halflife, Hotbar, hotbar, HoverDesk, hoverdes, ICCD, iccd, iCaster, icaster, IceSphere, icesphere, IconPackager, iconpackager, ICQ Plus 1.x, icqplus1, ICQ Plus 2.x, icqplus2, Illumination, illumination, iMesh, imesh, iPanel, ipanel, Jet Audio, jetaudio, Jotter, jotter, K-Jofol, kjofol, L-ement, lement, LAUNCHkaos, launchkaos, Litestep, litestep, Mad Cow, madcow, Mail Checker, mailchec, MaxxChat, maxxchat, MemoPad, memopad, Media Jukebox, mediajuke, Media Wizard, mediawizard, MechWarrior 3, mektek, MicroDVD, microdvd, Millenium Note, millnote, MP3Spy, mp3spy, MP3Studio, mp3studio, MPFree, mpfree, MusicMatch, mmjb, MyCQ, mycq, MyPad, mypad, NECST, necst, NeoPlanet, neoplanet, NextSTART, nextstart, NewsNabber, newsnabber, Odigo, odigo, Outsider99, outsider99, Oxygenator, oxygenat, PageLink, pagelink, PalmOS Emu, palmemu, PAM, pam, Pluser, pluser, Poco, poco, PowerDVD, powerdvd, PowerPager, powerpager, PSmplay, psmplay, PureLS, purels, QCD, qcd, QCD 2.x, qcd2, QCD 3.x, qcd3, Quake, quake, Quake2, quake2, Quake3, quake3, Quick Clock, custoclock, QuickLAUNCH, qlaunch, QuickNotes, quicknotes, Quintessential, quint, QX, qx, RealJukeBox, realjukebox, Reveal, reveal, Scribbles, scribbles, Serenade, serenade, SAP, sap, SimpleCD, simplecd, SkinnyMix, skinnymix, SkinnyPad, skinnypad, SkinPad, skinpad, Socket, socket, SongSpy, songspy, Sonique, sonique, Soritong, soritong, StationRadio, stationradio, SysMeter 1, sysmeter, SysMeter 2, sysmeter2, Talisman, talisman, The Clock, theclock, ThemeBar, themebar, Throttlebox, throttle, VirtualTurntables, turntabl, Tyme, tyme, UltraPlayer, ultraplayer, UnrealPlayer, unrealplayer, URLMenu99, urlmenu, uTOK, utok, VDE, vde, VivTV, vivtv, VoidEYE, voideye, Wallpapers, wallpapers, WBiff, wbiff, Weather1, weather1, WebBlinds, webblinds, WinAmp, winamp, WinAmp 2.x, winamp2, WindowBlinds, wb, WinPanel, winpanel, WMP7, wmp7, WPlay, wplay, xiOn, xion, XXCalc, news, submit, free">
<META NAME="Author" CONTENT="gRAVE email: gregor@klevze.si">
<META name="robots" content="index,follow">
<META name="revisit" content="1 day"> 

<STYLE>
 a { text-decoration: none }
 A:hover { text-decoration:underline;}

 .MojHeadl    {font-family:Verdana, Tahoma,Arial; font-weight:bold; font-size:10pt; padding:2pt;}
 .MojHeadl2   {font-family:Arial, Verdana, Arial; font-weight:bold; font-size:12pt; padding:2pt; color:white;}
 .SmallT      {font-family:Arial; font-size:8pt; text-align:justify;}
 .MojHead     {font-family:Arial; font-size:12pt;  font-weight:bold; padding-left : 5pt;}
 .MenuHead    {width:159; padding-left:8pt; padding-right:8pt; font-family:tahoma; color:white; font-weight:bold; font-size:10pt;}
 .MenuText    {width:159; padding-left:8pt; padding-right:8pt; font-family:tahoma; color:black; font-size:9pt;}
 .MojLink    { font-family:tahoma; color:black; font-size:9pt;}
 .MojText    { font-family:tahoma; color:black; font-size:9pt;}
 .MenuTextSml {width:159; padding-left:8pt; padding-right:8pt; font-family:tahoma; color:black; font-size:11px;}
</STYLE>

</HEAD>

<BODY BGCOLOR=#FFFFFF TEXT=#000000 LINK=#000000 VLINK=#000000 ALINK=#000000 LEFTMARGIN=0 TOPMARGIN=0 RIGHTMARGIN=0 MARGINWIDTH=0>

<TABLE WIDTH=100% CELLSPACING=0 CELLPADDING=0 CLASS=MojText>
 <TR>
  <TD><img src="gfx/menu-up-l1.gif" border="0" width="16" height="25" alt=""><BR></TD>
  <TD WIDTH=100% BACKGROUND="gfx/menu-up-l2.gif" ALIGN=CENTER>
  <SPAN STYLE="font-family:tahoma; font-size:11px;color:black;">
   <a href="index.php" style=color:black;><IMG SRC="gfx/green-arrow.gif" width=10 height=10 border=0> News</a>
   <a href="newsarc.php" style=color:black;><IMG SRC="gfx/green-arrow.gif" width=10 height=10 border=0> News Archive</a>
   <a href="addnews.php" style=color:black;><IMG SRC="gfx/green-arrow.gif" width=10 height=10 border=0> Submit News</a>
   <a href="signup.php" style=color:black;><IMG SRC="gfx/green-arrow.gif" width=10 height=10 border=0> Signup</a>
   </SPAN>
  </TD>
  <TD><img src="gfx/menu-up-l3.gif" border="0" width="16" height="25" alt=""><BR></TD>
 </TR>
 
 <TR>
  <TD WIDTH=16 BACKGROUND="gfx/menu-up-m1.gif" HEIGHT=75></TD>
  <TD HEIGHT=75 BGCOLOR=#6475AD WIDTH=200>
   
  </TD>
  <TD WIDTH=16 BACKGROUND="gfx/menu-up-m3.gif" HEIGHT=75></TD>
 </TR>

 <TR>
  <TD><img src="gfx/menu-up-b1.gif" border="0" width="16" height="23" alt=""><BR></TD>
  <TD WIDTH=100% BACKGROUND="gfx/menu-up-b2.gif" ALIGN=CENTER></TD>
  <TD><img src="gfx/menu-up-b3.gif" border="0" width="16" height="23" alt=""><BR></TD>
 </TR>

</TABLE> 

<TABLE WIDTH=100% CELLSPACING=0 CELLPADDING=0 border=0>
 <TR>
  <TD VALIGN=TOP WIDTH=170 HEIGHT=100% ALIGN=CENTER>

<TABLE WIDTH=160 CELLSPACING=0 CELLPADDING=0 CLASS=MojText>
 <TR>
  <TD>
   <img src="./gfx/okvir-up-skins.gif" border="0" width="160" height="26" alt=""><BR>
  </TD>
 </TR>
 <TR>
  <TD BACKGROUND="./gfx/okvir-mid.gif" WIDTH=160 HEIGHT=100>
    <SPAN STYLE="width:140px; padding-left:10px;">
 
    <IMG SRC="gfx/green-arrow.gif" width=10 height=10 border=0><FONT COLOR=#FccF00 SIZE=1 FACE=verdana><B><font color=#FFcc00>Search</font><BR>
    <?SearchMenu("#192251");?><BR>
    <BR>
    
    <B><IMG SRC="./gfx/green-arrow.gif" width=10 height=10 border=0><font color="#ffcc00">Weekly Poll</font><BR></B>
    <?ShowWeeklyPool("#192251");?>
    <BR>

    
    </FONT>
   </SPAN>

  </TD>
 </TR>
 <TR>
  <TD>
   <img src="./gfx/okvir-bot.gif" border="0" width="160" height="24" alt=""><BR>
  </TD>
 </TR>
</TABLE>


  </TD>
  <TD WIDTH=100% VALIGN=TOP>
   
<TABLE WIDTH=98% CELLSPACING=1 CELLPADDING=1 ALIGN=CENTER>
 <TR>
  <TD VALIGN=TOP>
 
 