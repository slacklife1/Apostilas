<?php

Function ShowGroups()
{
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
 global $color03,$color10,$color01,$color06,$color08;
 global $skinbasenews;
?>
<BR>


<TABLE WIDTH=99% BORDER=0 CELLSPACING=0 CELLPADDING=2 BGCOLOR=#3B4977 ALIGN=CENTER>
 <TR> 
 <TD WIDTH=100% BGCOLOR=#3B4977 CLASS=MojText>
 <FONT COLOR=white FACE=Arial SIZE=2>
  <B>NEWS</B>
  </FONT>
 </TD>
</TR>
</TABLE>
<BR>

<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=1 WIDTH=95% ALIGN=CENTER >
 <TR>
  <TD CLASS=MojText VALIGN=TOP>
    <?php
     $res = mysql_query("SELECT * FROM $db_topic ORDER BY topictext"); 
     print "<TABLE WIDTH=95%><TR>";
     while ($ar = mysql_fetch_array($res))
      {
       $x++;
       print "<TD ALIGN=CENTER HEIGHT=100><A HREF=\"newsarc.php?action=category&id=$ar[id]\"><IMG SRC=../topic/$ar[topicimage] ALT=$ar[topictext] BORDER=0></A></TD>";
       if ($x == 6) { print "</TR><TR>";$x=0;} 
      }
    ?>
   </TR></TABLE>
  </TD>
 </TR>
</TABLE>
<?
}

Function DisplayGroup()
{
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
 global $color03,$color10,$color01,$color06,$color08;
 global $id;
 global $skinbasenews;

 $res = mysql_query("SELECT * FROM $db_topic where id='$id'"); 
 $tp = mysql_fetch_array($res);
?>
<BR>
<BR>
<TABLE WIDTH=99% BORDER=0 CELLSPACING=0 CELLPADDING=2 BGCOLOR=#3B4977 ALIGN=CENTER>
 <TR> 
 <TD WIDTH=100% BGCOLOR=#3B4977 CLASS=MojText>
 <FONT COLOR=white FACE=Arial SIZE=2>
  <B><A HREF="newsarc.php"><FONT COLOR=white>NEWS</FONT></A></B> | <?php echo $tp[topictext];?>
  </FONT>
 </TD>
</TR>
</TABLE>
<BR>

<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=1 WIDTH=95% ALIGN=CENTER>
 <TR>
  <TD CLASS=MojText VALIGN=TOP>
   <IMG SRC="../topic/<?echo "$tp[topicimage]\" ALT=\"$tp[topictext]";?>" BORDER=0><BR><BR>
   <?php
    if ($category <> "")
     {
      print "<IMG SRC=\"../topic/$ar[topicimage]\" ALT=\"$ar[topictext]\" BORDER=0><FONT SIZE=4 FACE=Arial>$ar[topictext]</FONT><BR><HR COLOR=#3B4977 SIZE=2>";
     }
    $res = mysql_query("SELECT * FROM $db_news where category='$id' ORDER BY datum DESC"); 
    while ($ar = mysql_fetch_array($res))
     { 
      ereg ("([0-9]{4})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})", $ar[datum], $datetime);
      $datum = date("M jS ", mktime($datetime[4],$datetime[5],$datetime[6],$datetime[2],$datetime[3],$datetime[1]));
      $x++;
      print "$x.<A HREF=newsarc.php?action=shownews&category=$category&id=$id&topicid=$ar[id]>$ar[headline] / <SMALL>$datum</SMALL> <BR></A>";
     }
   ?>
  </TD>
 </TR>
</TABLE>
<?
}

Function ShowNews()
{
 global $color03,$color10,$color01,$color06,$color08;
 global $id,$topicid,$category;
 global $skinbasenews;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 $aip = getenv("REMOTE_ADDR");
 $ip =gethostbyaddr($aip); 
 $rm = mysql_query("SELECT * from $db_news where id='$ar[topicid]'");
 $nm = mysql_num_rows($rm);
 if($nm>0) {mysql_query("INSERT INTO $db_news_logged VALUES (0,'$topicid','$ip')") or die ("napaka 001");}

 $res = mysql_query("SELECT * FROM $db_topic where id='$id'"); 
 $tp = mysql_fetch_array($res)
?>

<BR>
<TABLE WIDTH=99% BORDER=0 CELLSPACING=0 CELLPADDING=2 BGCOLOR=#3B4977 ALIGN=CENTER CLASS=MojText>
 <TR> 
 <TD WIDTH=100% BGCOLOR=#3B4977 CLASS=MojText>
 <FONT COLOR=white FACE=Arial SIZE=2>
  <B><A HREF="newsarc.php"><FONT COLOR=white>News</FONT></A></B> | <A HREF="newsarc.php?action=category&id=<?echo $id;?>"><FONT COLOR=white><?echo $tp[topictext];?></FONT></A>
  </FONT>
 </TD>
</TR>
</TABLE>
<BR>

<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=1 WIDTH=95% ALIGN=CENTER>
 <TR>
  <TD CLASS=MojText VALIGN=TOP>
   <IMG SRC=../topic/<?php echo "$tp[topicimage] ALT=$tp[topictext]";?> BORDER=0><BR><BR>
   <HR SIZE=1 COLOR=#999999>
    <?php
     $res = mysql_query("SELECT * FROM $db_news where id='$topicid'"); 
     while ($ar = mysql_fetch_array($res))
      { 
       $res2 = mysql_query("SELECT email FROM $db_users WHERE uname='$ar[author]'");
       $ar2 =  mysql_fetch_array($res2);
       $res3 = mysql_query("SELECT $db_topicimage FROM topic where id='$ar[category]'"); 
       $ar3 = mysql_fetch_array($res3);

       $datum = formatTimestamp($ar[datum]);
       ?>
        <TABLE WIDTH=100% CELLSPACING=1 CELLPADDING=3>
         <TR>
          <TD CLASS=MojText>
           <FONT SIZE=4 COLOR=#ff0000><?echo $ar[headline];?></FONT><BR>
           <I>Posted by <A HREF="mailto:<?echo $ar2[email];?>"><?echo $ar[author];?></A> on <?echo $datum;?></I> 
	   <BR><BR>
          </TD>
         </TR>
         <TR>
          <TD BGCOLOR=#ffffff CLASS=MojText>
           <?echo smiley(ttl($ar[preview]));?><BR><BR><?echo smiley(ttl($ar[tekst]));?><BR>

   <TABLE WIDTH=100% ALIGN=LEFT CELLSPACING=2 BGCOLOR=#eeeeee CELLPADDING=0 CLASS=SmlText>
    <TR>
     <TD ALIGN=LEFT>
      <?
       $aip = getenv("REMOTE_ADDR");
       $ip =gethostbyaddr($aip); 
       mysql_query("INSERT INTO $db_news_logged VALUES (0,'$ar[id]','$ip')") or die ("napaka 001");
       $resd = mysql_query("SELECT * FROM $db_news_comments WHERE nid='$ar[id]'");
       $ard = mysql_fetch_array($resd);
       $num = mysql_num_rows($resd);
       if(empty($num)) {$num =0;}
       echo "<A HREF=comments.php?id=$ar[id]>$num Comments</A>";
       echo " | ";
       echo "<A HREF=comments.php?id=$ar[id]&action=add>Add comment</A>";
       echo " | ";
       $resd = mysql_query("SELECT * FROM $db_news_logged where nid='$ar[id]'");
       $num = mysql_num_rows($resd);
       if(empty($num)) {$num =0;}
       echo "$num times readed";
      ?>
     </TD>
    </TR>
   </TABLE>     

          </TD>
         </TR>
        </TABLE><BR>
  <?  } ?>
  </TD>
 </TR>
</TABLE>
<?
}


?>
<HTML>
<!-- CREATION DATE: 1.9.2000 -->
<HEAD>
 <TITLE>Skinbase.org: News Archive</TITLE>
<?php 
  
 include("header.php");

 if ($action == "")         {ShowGroups();}
 if ($action == "category") {DisplayGroup();}
 if ($action == "shownews") {ShowNews();}

 include("footer.php");

?>

