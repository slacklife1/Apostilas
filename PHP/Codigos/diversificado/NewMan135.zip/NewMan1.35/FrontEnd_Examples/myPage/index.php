<?php
  if ($action == "Login")
   {
    $info = base64_encode("$login:$pass");
    setcookie("users","$info",time()+15552000); // 6 mo is 15552000
    header ("Location: index.php"); 
   }

  if ($action == "Logout")
   {
    $info = ".";
    setcookie("users","$info",time()+15552000); // 6 mo is 15552000
    header ("Location: index.php"); 
   }
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<!-- CREATION DATE: 28.November.2001 -->
 <HEAD>
  <TITLE>NewsManager</TITLE>
  <?php include("header.php");?>

<?

 if ($page    == "") {$page=1;}
 if ($hits == "") {$hits=10;}
 $start = $hits*($page-1);

 $res =mysql_query ("SELECT id FROM $db_news");
 $xnum = mysql_num_rows($res);
 
 $stw2 = ($xnum/$hits);
 $stw2 = (int) $stw2;
 if ($xnum%$hits > 0) {$stw2++;}
 
 $np = $page+1;
 $pp = $page--;
 if ($page == 1) { $pp=1; }

 $res = mysql_query("SELECT * FROM $db_news order by datum desc LIMIT $start,$hits") or die("<B>".mysql_errno()."Error:</B>".mysql_error());
?>

<BR>

<TABLE WIDTH=99% CELLSPACING=0 CELLPADDING=0 CLASS=MojText>
 <TR>
  <TD><img src="gfx/menu-up-l1.gif" border="0" width="16" height="25" alt=""><BR></TD>
  <TD WIDTH=100% BACKGROUND="gfx/menu-up-l2.gif" ALIGN=CENTER>
  <SPAN STYLE="font-family:tahoma; font-size:11px;color:black;">
  <B>N E W S</B>
  </SPAN>
  </TD>
  <TD><img src="gfx/menu-up-l3.gif" border="0" width="16" height="25" alt=""><BR></TD>
 </TR>
 
 <TR>
  <TD WIDTH=16 BACKGROUND="gfx/menu-up-m1.gif" HEIGHT=75></TD>
  <TD HEIGHT=75 BGCOLOR=#6475AD>
 
 <TABLE WIDTH=100% CELLSPACING=1 CELLPADDING=1 BGCOLOR=#000000 CLASS=MojText>
 <TR>
 <TD BGCOLOR=#FFFFFF>
<?
 while ($ar = mysql_fetch_array($res))
  { 
   $res2 = mysql_query("SELECT email FROM $db_admin WHERE uname='$ar[author]'");
   $ar2 =  mysql_fetch_array($res2);
   $res3 = mysql_query("SELECT * FROM $db_topic where id='$ar[category]'"); 
   $ar3 = mysql_fetch_array($res3);
   $datum = formatTimestamp($ar[datum]);
   ?>
   <B><FONT SIZE=3 FACE=Arial><A HREF=news.php?topicid=<?echo $ar[id]?>><?echo smiley($ar[headline]);?></A></FONT></B><BR>
   <I>by <A HREF="mailto:<?echo $ar2[email];?>"><?echo $ar[author];?></A> on <SMALL> <?echo $datum;?></SMALL></I><BR>
   <I>Category: <?echo "$ar3[topictext]";?></I><BR>
   <BR>
   <?echo smiley(ttl($ar[preview]));?><BR><BR>
   <TABLE WIDTH=100% ALIGN=LEFT CELLSPACING=2 BGCOLOR=#EEEEEE CELLPADDING=0 CLASS=SmlText>
    <TR>
     <TD ALIGN=LEFT CLASS=MojText>
      <?
       echo "<A HREF=news.php?topicid=$ar[id]>Read More</A>";
       echo " | ";
       $resd = mysql_query("SELECT * FROM $db_news_comments WHERE nid='$ar[id]'");
       $ard = mysql_fetch_array($resd);
       $num = mysql_num_rows($resd);
       if(empty($num)) {$num =0;}
       echo "<A HREF=comments.php?id=$ar[id]>$num Comments</A>";
       echo " | ";
       echo "<A HREF=comments.php?id=$ar[id]&action=add>Add comment</A>";
       echo " | ";
       $resd = mysql_query("SELECT * FROM $db_news_logged where nid='$ar[id]'");
       //$ard = mysql_fetch_array($resd);
       $num = mysql_num_rows($resd);
       if(empty($num)) {$num =0;}
       echo "$num times read";
      ?>
     </TD>
    </TR>
   </TABLE>     
<?  
 } 
?>

</TD></TR></TABLE>

<TABLE CLASS=MojText>
 <TR>
  <TD>
   <A HREF="?page=<?echo $pp;?>">Previous 10</A>
  </TD>
  <TD ALIGN=RIGHT>
   <A HREF="?page=<?echo $np;?>">Next 10</A>
  </TD>
 </TR>
</TABLE>
 
  
  </TD>
  <TD WIDTH=16 ALIGN=RIGHT BACKGROUND="gfx/menu-up-m3.gif"></TD>
 </TR>

 <TR>
  <TD><img src="gfx/menu-up-b1.gif" border="0" width="16" height="23" alt=""><BR></TD>
  <TD  WIDTH=100% BACKGROUND="gfx/menu-up-b2.gif" ALIGN=CENTER></TD>
  <TD><img src="gfx/menu-up-b3.gif" border="0" width="16" height="23" alt=""><BR></TD>
 </TR>
</TABLE> 



<?php include("footer.php");?>

