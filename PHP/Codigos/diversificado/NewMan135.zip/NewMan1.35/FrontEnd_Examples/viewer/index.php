<HTML>
 <HEAD>
  <TITLE>Viewer</TITLE>
 </HEAD>
<BODY BGCOLOR=#0061E5>

<?include "viewer.php";?>
   
<TABLE WIDTH=100% HEIGHT=100% CELLSPACING=3 CELLPADDING=3 ALIGN=CENTER BGCOLOR=#0061e5>
 <TR>
  <TD WIDTH=20% VALIGN=TOP CLASS=MojText BGCOLOR=#0071f5>
   <BR>
    <SPAN STYLE="font-family:tahoma; font-size:9px;">
    <form action="?" method="post">
     Query:<BR><input type="text" name="query" size=10 value="<?echo $query;?>">
     <input type="submit" value="Go">
     <input type="hidden" name="action" value="search" size=40 maxlength=40>
   </form>
   <BR>
   <BR>Example 1:<BR>
   <?ShowHeadlines(1,5);?>
   <HR>
   <BR>Example 2:<BR>
   <?ShowHeadlines(2,5);?>
   <HR>
   <BR>Example 3:<BR>
   <?ShowHeadlines(3,5);?>
   <HR>
   Weekly Poll<BR>
   <?ShowWeeklyPoll("white");?>

  </TD>
  <TD WIDTH=70% VALIGN=TOP BGCOLOR=#0061e5>
    <SPAN STYLE="font-family:tahoma; font-size:9px;">
   <?NewsManager();?>  
  </TD>
  <TD VALIGN=TOP WIDTH=10% BGCOLOR=#0071f5>
    <SPAN STYLE="font-family:tahoma; font-size:9px;">
   <?ShowGroups(1,0);?>
   </SPAN>
  </TD>
 </TR>
</TABLE>

</BODY>
</HTML>