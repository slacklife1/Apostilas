<?
//*************************************************************************************************
//
//                                NewsManager V1.03: Viewer
//
// First Release: 18.April,2001
// 1. Update: 15.July,2001
// 2. Update: 28.November,2001
// 3. Update:  4.February,2002
//
// CHANGE LOG:
// -----------
// V1.03 | Updated for NewMan v1.26
// V1.02 | www links, smiles
// V1.01 | Adding search
// V1.00 | First public release
//*************************************************************************************************

// CHANGE THIS PARAMETERS
 include "./../db.inc.php";

 $skin            = "./skins/aqua/";  
 $num_news	  = "10";			// How many healdines will be displayed; 
 

@mysql_connect($db_server,$db_uname,$db_pass);
mysql_select_db($db_name); 


function ttl ($data='') 
 {
  if(empty($data)) { return $data; }
  $lines = split("\n",$data);
  while ( list ($key,$line) = each ($lines)) {
  $line = eregi_replace("([ \t]|^)www\."," http://www.",$line);
  $line = eregi_replace("([ \t]|^)ftp\."," ftp://ftp.",$line);
  $line = eregi_replace("(http://[^ )\r\n]+)","<A href=\"\\1\" target=\"_blank\">\\1</A>",$line);
  $line = eregi_replace("(https://[^ )\r\n]+)","<A href=\"\\1\" target=\"_blank\">\\1</A>",$line);
  $line = eregi_replace("(ftp://[^ )\r\n]+)","<A href=\"\\1\" target=\"_blank\">\\1</A>",$line);
  $line = eregi_replace("([-a-z0-9_]+(\.[_a-z0-9-]+)*@([a-z0-9-]+(\.[a-z0-9-]+)+))","<A HREF=\"mailto:\\1\">\\1</A>",$line);
  $newText .= $line . "\n";
 }
 return $newText;
}

Function Smiley($string)
{
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smileys,$db_topic,$db_users,$db_weekQ,$db_weekA;
 $getsmiles = mysql_query("SELECT * FROM $db_smileys");
 while($sm = mysql_fetch_array($getsmiles)){$string = str_replace($sm[code], "<IMG SRC=\"/gfx/smiles/$sm[smile]\" BORDER=0>", $string);}
 return $string;
}

function formatTimestamp($time)
 {
  global $datetime;
  ereg ("([0-9]{4})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})([0-9]{1,2})", $time, $datetime);
  $datetime = date("d M Y", mktime($datetime[4],$datetime[5],$datetime[6],$datetime[2],$datetime[3],$datetime[1]));
  return($datetime);
}

//
// MAIN FUNCTIONS
//

function NewsManager()
{
 global $query,$action,$id,$num_news;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
 //if ($action == "")        {DisplayHeadlines();}
 if ($action == "headlines") {DisplayHeadlines();}
 if ($action == "groups")    {ShowGroups($type,$id);}
 if ($action == "show")      {DisplayNews($id);}
 if ($action == "search")    {SearchNews($query);}
}

function SearchNews($query)
{
 global $topic_url,$skin;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 $fd = fopen("$skin/searchres.ntl","r");
 while (!feof ($fd)){$buffer .= fgets($fd, 4096);}
 fclose ($fd);
 $tbuf = $buffer;
 
 $res = mysql_query("SELECT * FROM $db_news WHERE headline like '%$query%' or preview like '%$query%' or tekst like '%$query%'") or die("Main error"); 
 $num = mysql_num_rows($res);
 if ($num < 1)
  {
   echo "Search not found<BR>";
  }
 else
  {
   while ($ar = mysql_fetch_array($res))
    {
     $buffer = $tbuf;
     $res2 = mysql_query("SELECT email FROM $db_admin WHERE uname='$ar[author]'");
     $ar2  = mysql_fetch_array($res2);
     $res3 = mysql_query("SELECT * FROM $db_topic WHERE id=$ar[category]");
     $ar3  = mysql_fetch_array($res3);
     if(empty($ar2[email])) {$ar2[email]="";}
     if(empty($ar3[topicimage])) {$ar3[topicimage]="";}
     if(empty($ar3[topictext])) {$ar3[topictext]="";}
     $datum = formatTimestamp($ar[datum]); 

     $ar[headline]= eregi_replace($query, "<b>$query</b>", $ar[headline]);
     $ar[preview] = eregi_replace($query, "<b>$query</b>", $ar[preview]);  
     $ar[text]    = eregi_replace($query, "<b>$query</b>", $ar[text]);   

     $buffer = ereg_replace( '\$headline',"<A HREF=\"?action=show&id=$ar[id]\">$ar[headline]</A>",$buffer);
     $buffer = ereg_replace( '\$time',"$datum",$buffer);
     $buffer = ereg_replace( '\$author',"<A HREF=\"mailto:$ar2[email]\">$ar[author]</A>",$buffer);
     $buffer = ereg_replace( '\$category',"$ar3[topictext]",$buffer);
     $buffer = ereg_replace( '\$preview',"$ar[preview]",$buffer);
     $buffer = ereg_replace( '\$tekst',"$ar[tekst]",$buffer);
     $buffer = ereg_replace( '\$logo_right',"<IMG SRC=\"$topic_url/$ar3[topicimage]\" ALIGN=RIGHT>",$buffer);
     $buffer = ereg_replace( '\$logo_left', "<IMG SRC=\"$topic_url/$ar3[topicimage]\" ALIGN=LEFT>",$buffer);
     echo smiley(ttl($buffer));
    }
  }
}

function DisplayHeadlines()
{
 global $topic_url,$skin,$num_news,$page;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;
  
 $fd = fopen("$skin/headlines.ntl","r");
 while (!feof ($fd)){$buffer .= fgets($fd, 4096);}
 fclose ($fd);
 $tbuf = $buffer;

 $query = "SELECT * FROM $db_news ORDER BY datum DESC ";
 // if ($num <> "all") {$query .= "LIMIT $num";}

   if(empty($page)) {$page=1;}
   if($page<2) {$page=1;}
   $nn = mysql_num_rows(mysql_query("SELECT id FROM $db_news"));
   if (empty($page)) {$page=1;}    
   $stw2 = ($nn/$num_news);
   $stw2 = (int) $stw2;
   if ($nn%$num_news <> 0) {$stw2++;}
  
   $np = $page+1;
   $pp = $page-1;
   if ($page < 2) { $pp=1; }
   if ($np > $stw2) { $np = $stw2;} 
   
   $sp=($page-1)*$num_news+1;
   $ep=($page-1)*$num_news+$num_news+1;
   $m=0;
   $res = mysql_query($query);
   while ($ar=mysql_fetch_array($res))
    {
     $m++;
     if($m>=$sp and $m<$ep)
      {      
       $buffer = $tbuf;
       $res2 = mysql_query("SELECT email FROM $db_admin WHERE uname='$ar[author]'");
       $ar2  =mysql_fetch_array($res2);
       $res3 = mysql_query("SELECT * FROM $db_topic WHERE id=$ar[category]");
       $ar3  =mysql_fetch_array($res3);
       if(empty($ar2[email])) {$ar2[email]="";}
       if(empty($ar3[topicimage])) {$ar3[topicimage]="";}
       if(empty($ar3[topictext])) {$ar3[topictext]="";}
       $datum = formatTimestamp($ar[datum]); 

       $buffer = ereg_replace( '\$headline',"<A HREF=\"?action=show&id=$ar[id]\">$ar[headline]</A>",$buffer);
       $buffer = ereg_replace( '\$time',"$datum",$buffer);
       $buffer = ereg_replace( '\$author',"<A HREF=\"mailto:$ar2[email]\">$ar[author]</A>",$buffer);
       $buffer = ereg_replace( '\$category',"$ar3[topictext]",$buffer);
       $buffer = ereg_replace( '\$viewed',"$ar[views]",$buffer);
       $buffer = ereg_replace( '\$preview',"$ar[preview]",$buffer);
       $buffer = ereg_replace( '\$tekst',"$ar[tekst]",$buffer);
       $buffer = ereg_replace( '\$logo_right',"<IMG SRC=\"$topic_url/$ar3[topicimage]\" ALIGN=RIGHT>",$buffer);
       $buffer = ereg_replace( '\$logo_left', "<IMG SRC=\"$topic_url/$ar3[topicimage]\" ALIGN=LEFT>",$buffer);
       echo $buffer;
    }
  }
   echo "<BR><CENTER><A HREF=\"?page=$pp\">Previous</A> <--";
   for ($i=1;$i<=$stw2;$i++) {if($page==$i){echo "<B>$i</B>";} else{echo " <A HREF=\"?page=$i\">$i</A> ";}}
   echo "--> <A HREF=\"?page=$np\">Next</A></CENTER>";
}

function ShowHeadlines($type,$num_news)
{
 global $topic_url,$skin,$groups;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 switch($type)
 {
  case 0:
	$fname = "headlines.ntl";
	break;
  case 1:
	$fname = "headlines1.ntl";
	break;
  case 2:
	$fname = "headlines2.ntl";
	break;
  case 3:
	$fname = "headlines3.ntl";
	break;
  case 4:
	$fname = "headlines4.ntl";
	break;
  default:
	$fname = "headlines.ntl";
	break;
 }
  
 $fd = fopen("$skin/$fname","r");
 while (!feof ($fd)){$buffer .= fgets($fd, 4096);}
 fclose ($fd);
 $tbuf = $buffer;

 $query  = "SELECT * FROM $db_news ";
 if(!empty($groups)) { $query .= " WHERE category='$groups' ";}
 $query .= " ORDER BY datum DESC ";
 if ($num_news <> "all") {$query .= "LIMIT $num_news";}
 $res = mysql_query($query) or die("MyError");
 while ($ar=mysql_fetch_array($res))
  {
   $buffer = $tbuf;
   $res2 = mysql_query("SELECT email FROM $db_admin WHERE uname='$ar[author]'");
   $ar2  =mysql_fetch_array($res2);
   $res3 = mysql_query("SELECT * FROM $db_topic WHERE id=$ar[category]");
   $ar3  =mysql_fetch_array($res3);
   if(empty($ar2[email])) {$ar2[email]="";}
   if(empty($ar3[topicimage])) {$ar3[topicimage]="";}
   if(empty($ar3[topictext])) {$ar3[topictext]="";}
   $datum = formatTimestamp($ar[datum]); 

   $buffer = ereg_replace( '\$headline',"<A HREF=\"?action=show&id=$ar[id]\">$ar[headline]</A>",$buffer);
   $buffer = ereg_replace( '\$time',"$datum",$buffer);
   $buffer = ereg_replace( '\$author',"<A HREF=\"mailto:$ar2[email]\">$ar[author]</A>",$buffer);
   $buffer = ereg_replace( '\$category',"$ar3[topictext]",$buffer);
   $buffer = ereg_replace( '\$viewed',"$ar[views]",$buffer);
   $buffer = ereg_replace( '\$preview',"$ar[preview]",$buffer);
   $buffer = ereg_replace( '\$tekst',"$ar[tekst]",$buffer);
   $buffer = ereg_replace( '\$logo_right',"<IMG SRC=\"$topic_url/$ar3[topicimage]\" ALIGN=RIGHT>",$buffer);
   $buffer = ereg_replace( '\$logo_left', "<IMG SRC=\"$topic_url/$ar3[topicimage]\" ALIGN=LEFT>",$buffer);
   echo $buffer;
  }
}

function ShowGroups($type,$id)
{
 global $topic_url,$skin;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 switch($type)
 {
  case 0:
	$fname = "groups.ntl";
	break;
  case 1:
	$fname = "groups1.ntl";
	break;
  case 2:
	$fname = "groups2.ntl";
	break;
  case 3:
	$fname = "groups3.ntl";
	break;
  default:
	$fname = "groups.ntl";
	break;
 }
  
 $fd = fopen("$skin/$fname","r");
 while (!feof ($fd)){$buffer .= fgets($fd, 4096);}
 fclose ($fd);
 $tbuf = $buffer;

 $query = "SELECT * FROM $db_topic";
 $res = mysql_query($query) or die("MyError Groups");
 while ($ar=mysql_fetch_array($res))
  {
   $buffer = $tbuf;
   if(empty($ar3[topicimage])) {$ar3[topicimage]="";}
   //if(empty($ar3[topictext])) {$ar3[topictext]="";}
   echo "x. $ar3[topictext] ";
   $buffer = ereg_replace( '\$headline',"<A HREF=\"?action=show&id=$ar[id]\">$ar[headline]</A>",$buffer);
   $buffer = ereg_replace( '\$time',"$datum",$buffer);
   $buffer = ereg_replace( '\$author',"<A HREF=\"mailto:$ar2[email]\">$ar[author]</A>",$buffer);
   $buffer = ereg_replace( '\$category',"$ar3[topictext]",$buffer);
   $buffer = ereg_replace( '\$viewed',"$ar[views]",$buffer);
   $buffer = ereg_replace( '\$preview',"$ar[preview]",$buffer);
   $buffer = ereg_replace( '\$tekst',"$ar[tekst]",$buffer);
   $buffer = ereg_replace( '\$logo_right',"<IMG SRC=\"$topic_url/$ar3[topicimage]\" ALIGN=RIGHT>",$buffer);
   $buffer = ereg_replace( '\$logo_left', "<IMG SRC=\"$topic_url/$ar3[topicimage]\" ALIGN=LEFT>",$buffer);
   $buffer = ereg_replace( '\$logo', "<IMG SRC=\"$topic_url/$ar3[topicimage]\">",$buffer);
   echo $buffer;
  }
}


function DisplayNews($id)
{
 global $topic_url,$skin,$num_news;
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 $res = mysql_query("SELECT * FROM $db_news WHERE ID=$id");
 $ar=mysql_fetch_array($res);

 mysql_query("UPDATE $db_news SET datum='$ar[datum]', views=views+1 where id='$id'") or die("error 1");

 $res2 = mysql_query("SELECT email FROM $db_admin WHERE uname='$ar[author]'");
 $ar2  =mysql_fetch_array($res2);

 $res3 = mysql_query("SELECT * FROM $db_topic WHERE id=$ar[category]");
 $ar3  =mysql_fetch_array($res3);

 if(empty($ar2[email])) {$ar2[email]="";}
 if(empty($ar3[topicimage])) {$ar3[topicimage]="";}
 if(empty($ar3[topictext])) {$ar3[topictext]="";}
 $datum = formatTimestamp($ar[datum]);
 
 $fd = fopen("$skin/fullnews.ntl","r");
 while (!feof ($fd)) {$buffer .= fgets($fd, 4096);}
 fclose ($fd);

 $buffer = ereg_replace( '\$headline',$ar[headline],$buffer);
 $buffer = ereg_replace( '\$time',"$datum",$buffer);
 $buffer = ereg_replace( '\$author',"<A HREF=\"mailto:$ar2[email]\">$ar[author]</A>",$buffer);
 $buffer = ereg_replace( '\$preview',"$ar[preview]",$buffer);
 $buffer = ereg_replace( '\$category',"$ar3[topictext]",$buffer);
 $buffer = ereg_replace( '\$tekst',"$ar[tekst]",$buffer);
 $buffer = ereg_replace( '\$viewed',"$ar[views]",$buffer);
 $buffer = ereg_replace( '\$logo_right',"<IMG SRC=\"$topic_url/$ar3[topicimage]\" ALIGN=RIGHT>",$buffer);
 $buffer = ereg_replace( '\$logo_left', "<IMG SRC=\"$topic_url/$ar3[topicimage]\" ALIGN=LEFT>",$buffer);
 echo smiley(ttl($buffer));
}

Function ShowWeeklyPoll($color)
{
 global $db_admin,$db_news,$db_groups,$db_news_comments,$db_news_logged,$db_partners,$db_pnews,$db_smiles,$db_topic,$db_users,$db_weekQ,$db_weekA;

 ?>
 <TABLE WIDTH=98% BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=CENTER>
  <TR> 
   <td class=MojText> 
    <SPAN STYLE="color:<?echo $color;?>;">
    <?
     $gres = mysql_query("SELECT * FROM $db_weekQ order by ID desc limit 1"); 
     $gar = mysql_fetch_array($gres);
     $odg = explode (":", $gar[2]);
    ?>
    <FORM ACTION="vote.php" METHOD=POST>
     <?echo $gar[1];?><BR>

       <?php
       while ( list ($key,$values)= each($odg))
        {
         echo "<INPUT TYPE=\"radio\" NAME=\"pool\" VALUE=\"$key\" class=radio>$values<BR>";
        }
       ?>
       <INPUT TYPE="hidden" NAME="vid" VALUE="<?echo $gar[0];?>">
       <INPUT TYPE="submit" VALUE="Vote" class=submit>
       <?
        $gres = mysql_query("SELECT * FROM $db_weekQ order by id desc limit 1"); 
        $gar = mysql_fetch_array($gres);
        $pid = $gar[id];
        $myvote = mysql_query("select count(*) as suma from $db_weekA where wid=$pid");
	$myvres = mysql_fetch_array($myvote);
       ?>
       <BR><A HREF="voteres.php" STYLE="color:<?echo $color;?>;"><?echo $myvres[suma];?> Votes</A>
       </FORM>
       </SPAN>
      </TD>
     </TR>
    </TABLE>
<?
}
?>