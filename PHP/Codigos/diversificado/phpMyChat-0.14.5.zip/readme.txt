-----------------
 Read me first !
-----------------


You will find the following files in the 'docs' directory :

install.txt     : Installation guide
database.txt    : Specific help for databases
copying.txt     : Copyright license
changes.txt     : List of changes in each release
feedback.txt    : How you can help us
translation.txt : How to translate phpMyChat
help.txt        : Where you can find help
credits.txt     : Who developed phpMyChat
todo.txt        : What has to be done next


Read the install.txt file first.

It has everything you need to know to install phpMyChat on your system.


We hope you will find phpMyChat useful and easy to use. Thank you for taking
the time to try it. If you have any questions, just ask.

Enjoy,


The phpHeaven Team