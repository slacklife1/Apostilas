<?php
/******************************************************************************
EzGuestBook Administration Panel !

You can change (edit) this file only if you want to change font or size
of the text.

Copyright Armin Kalajdzija, 2002.
E-mail: kalajdzija@hotmail.com
WebSite: http://www.ak85.tk
******************************************************************************/
print "<table width='100%' border='0' cellspacing='0' bgcolor=$nav_meni_color>\n\t<tr>";
print "\n\t<td width='20%' height='20' valign='middle'><b><font face='Verdana' size='1'><a href=guestbook.php?action=signin><font color=$nav_meni_text_color>Sign in guestbook</font></b></a></font></td>";
print "\n\t<td width='20%'><font face='Verdana' size='1'><a href=guestbook.php?action=sort&by=date&from=desc><font color=$nav_meni_text_color>Sort by date</font></a></font></td>";
print "\n\t<td width='40%'><font face='Verdana' size='1'><a href=guestbook.php?action=sort&by=name&from=A><font color=$nav_meni_text_color>Sort by name</font></a></font></td>";
print "\n\t<td width='20%'><p align='right'><font face='Verdana' size='1' color=$nav_meni_text_color><a href=$site_url><font color=$nav_meni_text_color>Back to $site_name</font></a></font></p></td>";
print "\n\t</tr>\n</table><br>";
if (isset($action)) {
   if (($action == "sort") and ($by == "name")) {
   print "<table width=100 border='0' cellspacing='0'>\n\t<tr>";
   for ($i = 65; $i <= 90; $i++) {
    $ch = chr($i);
    print "\n\t<td width=5><font face='Verdana' size='2' color=$nav_meni_text_color><a href=guestbook.php?action=sort&by=name&from=$ch>$ch</a></font></td>";
   }
   print "\n\t</tr>\n</table><br>";
   }
}
?>
