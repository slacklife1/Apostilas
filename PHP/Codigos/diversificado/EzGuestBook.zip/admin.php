<?php
/******************************************************************************
EzGuestBook Administration Panel !

Do not change (edit) this script file !

Copyright Armin Kalajdzija, 2002.
E-mail: kalajdzija@hotmail.com
WebSite: http://www.ak85.tk
******************************************************************************/

     /*if ((!isset($user_pass)) and (!isset($user_login))) {      // cookie check
         $user_logovan = $HTTP_COOKIE_VARS["EzGuestCookie"];
         list ($user_login, $user_pass) = split ('[|]',$user_logovan);
     }*/

     session_start();
     include "config.php";
     $varcount = 0;
     
     $auth = false;   // setting auth var to false

if (!session_is_registered('user_login')) {
     if (isset($user_login) and ($user_login <> "") and isset($user_pass) and ($user_pass <> "")) {     // connection to MySQL
     if (isset($hostname) and isset($database) and isset($db_login) and isset($db_pass)) {
     $dbconn = mysql_connect($hostname, $db_login, $db_pass) or die("Could not connect");

     mysql_select_db($database) or die("Could not select database");

     $query = "SELECT login,password FROM ez_guestbook_auth";        // selecting login and pass from database
     $result = mysql_query($query) or die("Query failed");

     $line = mysql_fetch_array($result);

     if ($line[0] == $user_login) {          // login check
        if ($line[1] == (crypt($user_pass,$line[1]))) {      // pass check
            $auth = true;        // setting to true
            session_register('user_login');
            session_register('user_pass');
            $date = date("Y-m-d h:i:s");
            $query = "UPDATE ez_guestbook_auth SET ip='$REMOTE_ADDR', datetime='$date'";   //updating IP and date when last logged
            $result = mysql_query($query) or die("Query failed");
        }
     }
     }
     }
}else{
    $auth = true;
}
     if (isset($action) and ($action == "logout")) {
        session_destroy();
        Print "<div align='center'><font face='Verdana' size='3'>You are logged out !</font>";
        Print "<br><font face='Verdana' size='2'><a href='admin.php'>Click here to login again</a></font></div>";
        die;
     }
         
     print "<title>EzGuestBook Version 1.0 !</title>";
     Print "<font face='Verdana' size='5'>EzGuestBook Administration Panel !</font><br>";

     if ($auth) {
     $dbconn = mysql_connect($hostname, $db_login, $db_pass) or die("Could not connect");

     mysql_select_db($database) or die("Could not select database");
     print "<font face='Verdana' size='2'>MySQL Ver: ";
     print mysql_get_server_info($dbconn);                            //MySQL information
     print " | User Logged: $db_login  <a href='admin.php?action=logout'>Logout</a> | Host: ";
     print mysql_get_host_info($dbconn);
     print "</font><br><br>";
     }
     
     if (!$auth) {
     // login and password display
     print "<br><br><br><form name='forma' method='post' action='admin.php'>";
     print "<table width='350' border='0' align='center' cellpadding='0' cellspacing='0'>";
     print "<tr bgcolor='#003366'>";
     print "<td colspan='2'>";
     print "<div align='center'><font face='Verdana' size='2'><b><font color='#FFFFFF'>EzGuestBook Administration v1.0</font></b></font></div>";
     print "</td>";
     print "</tr>";
     print "<tr><td width='118'><font face='Verdana' size='2'>Login:</font></td>";
     print "<td width='232'><font face='Verdana' size='2'><input type='text' name='user_login'></font></td></tr>";
     print "<tr><td width='118'><font face='Verdana' size='2'>Password:</font></td>";
     print "<td width='232'><font face='Verdana' size='2'><input type='password' name='user_pass'></font></td></tr>";
     print "<tr><td colspan='2'><div align='center'><input type='submit' name='btnlogin' value='Login'><input type='reset' name='Submit2' value='Reset'>";
     print "</div></td></tr></table>";
     }

     if ($auth == true) {
     $db_link = mysql_connect($hostname, $db_login, $db_pass) or die("Could not connect");
     mysql_select_db($database) or die("Could not select database");
     
     if (isset($rowcount) and ($rowcount <> "")) {               // next function
         $query = "SELECT * FROM ez_guestbook WHERE id<$rowcount ORDER BY id DESC";
         $result = mysql_query($query) or die("Query failed");
     }else{
         $query = "SELECT * FROM ez_guestbook ORDER BY id DESC";
         $result = mysql_query($query) or die("Query failed");
     }
     
     $rowcount = 0;
     if (isset($action)) {
         if (($action == "del") and (!isset($sure) or ($sure <> 1))) {     //delete function
             print "<br><font face='Verdana' size='2'>Are you sure to delete the $id record ?</font>";
             print "<br><font face='Verdana' size='2'><a href='admin.php?action=del&id=$id&sure=1'>YES</a></font>";

         }else if (($action == "del") and ($sure == 1)) {                 //delete function confirmed
             $query = "DELETE FROM ez_guestbook WHERE id=$id";
             $result = mysql_query($query) or die("Query failed");

             print "<br><font face='Verdana' size='2'>Record $id deleted !</font>";
             print "<br><font face='Verdana' size='2'><br><a href='admin.php'>Back to the Administration Panel !</a></font>";

         }else if (($action == "edit") and (!isset($change)) and isset($id)) {         //edit function
             $query = "SELECT name,email,message FROM ez_guestbook WHERE id=$id";
             $result = mysql_query($query) or die("Query failed");

             print "<table border='1' cellpadding='0' cellspacing='0'>\n";
             print "<tr bgcolor='#000066'>";
             print "<td width='320'><font face='Verdana' size='2' color='#FFFFFF'>Name</font></td>";
             print "<td width='320'><font face='Verdana' size='2' color='#FFFFFF'>E-Mail</font></td>";
             print "<td width='320'><font face='Verdana' size='2' color='#FFFFFF'>Message</font></td>";
             print "</tr>";
             print "</table>";
             print "<form name='change' method='post' action='admin.php'>";

             while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
                 foreach ($line as $col_value[$varcount]) {

                     $fname = mysql_field_name($result,$varcount);
                     print "<input type=text name=$fname value='$col_value[$varcount]' size='50'>";
                     $varcount = $varcount + 1;
                 }
             $varcount = 0;
             }
             print "<input type='hidden' name='id' value=$id>";
             print "<input type='hidden' name='action' value='edit'>";
             print "<input type='hidden' name='change' value=1>";
             print "<br><br><input type='submit' name='sub' value='Change'></form>";

         }else if (($action == "edit") and isset($change) and ($change == 1) and isset($id)) {      //change fun. confirmed
             $query = "UPDATE ez_guestbook SET name='$name' , email='$email', message='$message' WHERE id=$id";
             $result = mysql_query($query) or die("Query failed");

             print "<br><font face='Verdana' size='2'>Change on $id record is done !</font>";
             print "<br><font face='Verdana' size='2'><br><a href='admin.php'>Back to Administration Panel</a></font>";
         }

     }else{                                //display hole database
           print "<table border='1' cellpadding='0' cellspacing='0'>\n";
           print "<tr bgcolor='#000066'>";
           print "<td width='30'><font face='Verdana' size='2' color='#FFFFFF'>ID</font></td>";
           print "<td width='200'><font face='Verdana' size='2' color='#FFFFFF'>Name</font></td>";
           print "<td width='200'><font face='Verdana' size='2' color='#FFFFFF'>E-Mail</font></td>";
           print "<td width='50'><font face='Verdana' size='2' color='#FFFFFF'>Message</font></td>";
           print "<td width='50'><font face='Verdana' size='2' color='#FFFFFF'>Date/Time</font></td>";
           print "<td width='50'><font face='Verdana' size='2' color='#FFFFFF'>IP</font></td>";
           print "<td width='50'><font face='Verdana' size='2' color='#FFFFFF'>Edit</font></td>";
           print "<td width='50'><font face='Verdana' size='2' color='#FFFFFF'>Delete</font></td>";
           print "</tr>";
           
           while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
           if ($rowcount <= 30) {
           $rowcount = $rowcount + 1;
           print "\t<tr>\n";
              foreach ($line as $col_value[$varcount]) {
                 print "\t\t<td><font face='Verdana' size='2'>$col_value[$varcount]</font></td>\n";
                 if ($varcount == 0) {
                     $idend = $col_value[$varcount];
                 }
                 $varcount = $varcount + 1;
              }
           print "<td width='50'><font face='Verdana' size='2'><a href='admin.php?action=edit&id=$col_value[0]'>Edit</a></font></td>";
           print "<td width='50'><font face='Verdana' size='2'><a href='admin.php?action=del&id=$col_value[0]'>Delete</a></font></td>";
           print "\t</tr>\n";
           $varcount = 0;
           
           }else{
               $next = 1;
           }
           }
           print "</table>\n";
           
           if (isset($next) and ($next == 1)) {
               Print "<font face='Verdana' size='2'><a href=admin.php?rowcount=$idend>Next >></a></font>";
           }
     }
     }

?>
