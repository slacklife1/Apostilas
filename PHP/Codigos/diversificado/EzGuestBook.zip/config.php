<?php
/******************************************************************************
EzGuestBook Configuration !

Change data in every variable before running install.php !

Copyright Armin Kalajdzija, 2002.
E-mail: kalajdzija@hotmail.com
WebSite: http://www.ak85.tk
******************************************************************************/

$hostname = "your.host.com";      // example $hostname = "db.host.sk";
$database = "database";      // example $database = "armin";
$db_login = "db_login";         // $db_login = "armin";
$db_pass = "db_pass";       // $db_pass = "temp123";

$list_length = 10;     //How many guestbook entrys will be displayed in one page !

$guestbook_name = "Ez Guest Book !";       //name of the guestbook
$site_name = "AK85 Home Page !";             //name of your site
$site_url = "http://www.ak85.tk";            //site url

$back_color = "#FFFFFF";                    //back color
$text_color = "#000000";                    //text color
$link_color = "#000000";                    //link color
$nav_meni_color = "#003366";                //navigation menu back color
$nav_meni_text_color = "#FFFFFF";           //navigation menu text color

?>
