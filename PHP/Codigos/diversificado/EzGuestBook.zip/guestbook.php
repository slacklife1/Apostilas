<?php
/******************************************************************************
EzGuestBook v1.0 !

Do not change (edit) this script file !

Copyright Armin Kalajdzija, 2002.
E-mail: kalajdzija@hotmail.com
WebSite: http://www.ak85.tk
******************************************************************************/
    include "config.php";

    print "<title>$guestbook_name</title>";
    print "<body bgcolor=$back_color text=$text_color link=$link_color alink=$link_color vlink=$link_color>";
    include "navmenu.php";
    
    if (!isset($action)){
    $action = "sort";
    $from = "desc";
    $by = "date";
    }
    
    $db_link = mysql_connect($hostname, $db_login, $db_pass) or die("Could not connect");
    mysql_select_db($database) or die("Could not select database");

    if (isset($guest_name) and isset($guest_email) and isset($guest_message) and isset($action)) {
        if (($guest_name <> "") and ($guest_email <> "") and ($guest_message <> "") and ($action == "signed")) {
        $query = "SELECT id from ez_guestbook";
        $result = mysql_query($query) or die("Query failed");

        $id = (mysql_num_rows($result) + 1);
        $date = date("Y-m-d h:i:s");
        
        $query = "SELECT id FROM ez_guestbook WHERE id=$id";
        $result = mysql_query($query) or die("Query failed");
        
        $line = mysql_fetch_array($result);

        while ($line[0] == $id) {
                 $id = ($id + 1);
                 $query = "SELECT id FROM ez_guestbook WHERE id=$id";
                 $result = mysql_query($query) or die("Query failed");
                 $line = mysql_fetch_array($result);
        }

        $query = "INSERT INTO ez_guestbook (id,name,email,message,datetime,ip) VALUES ('$id','$guest_name','$guest_email','$guest_message','$date','$REMOTE_ADDR')";
        $result = mysql_query($query) or die("Query failed");
        print "<p align='center'><font face='Verdana' size='4'>You have signed in $guestbook_name !</font></p>";
        print "<p align='center'><font face='Verdana' size='3'>Go back to <a href=guestbook.php>$guestbook_name</a> or go to <a href=$site_url>$site_name</a> !</font></p>";
        die;
        }
    }

    if (isset($action) and ($action <> "signin")) {

    if (($action == "sort") and isset($by) and ($by == "name")) {
               $query = "SELECT name,email,datetime,message,id FROM ez_guestbook WHERE name LIKE '$from%' ORDER BY name";
               $result = mysql_query($query) or die("Query failed");
    }else if (($action == "sort") and isset($by) and ($by == "date") and isset($from) and ($from == "desc")) {
                  $query = "SELECT name,email,datetime,message,id FROM ez_guestbook ORDER BY datetime DESC";
                  $result = mysql_query($query) or die("Query failed");

    }else if (($action == "list") and isset($rowcount)) {
                  $query = "SELECT name,email,datetime,message,id FROM ez_guestbook WHERE id<$rowcount ORDER BY datetime DESC";
                  $result = mysql_query($query) or die("Query failed");

    }else{
                $query = "SELECT name,email,datetime,message,id FROM ez_guestbook ORDER BY datetime DESC";
                $result = mysql_query($query) or die("Query failed");
    }

    $rowcount = 0;
    $varcount = 0;
    $idend = 0;

    while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
        if ($rowcount < $list_length) {
        $rowcount = $rowcount + 1;
        print "<table>\n";
        print "\t<tr>\n";
        foreach ($line as $col_value[$varcount]) {
            if ($varcount == 0) {
                print "\t\t<td><font face='Verdana' size='2'><b>Name:</b></font></td>\t\n";
            }else if ($varcount == 1) {
                print "\t\t<td><font face='Verdana' size='2'>E-Mail:</font></td>\t\n";
            }else if ($varcount == 3) {
                print "\t\t<td><font face='Verdana' size='2'>Message:</font></td>\t\n";
            }else if ($varcount == 2) {
                print "\t\t<td><font face='Verdana' size='1'>Signed:</font></td>\t\n";
            }
            if ($varcount == 4) {
               $idend = $col_value[$varcount];
            }
            if ($varcount == 1) {
                print "\t\t<td><font face='Verdana' size='2'><a href=mailto:$col_value[$varcount]>$col_value[$varcount]</a></font></td>\t</tr>\n";
            }else if ($varcount == 0) {
                  print "\t\t<td><font face='Verdana' size='2'><b>$col_value[$varcount]</b></font></td>\t</tr>\n";
            }else if ($varcount == 2) {
                  print "\t\t<td><font face='Verdana' size='1'>$col_value[$varcount]</font></td>\t</tr>\n";
            }else{
                  if ($varcount <> 4) {
                  print "\t\t<td><font face='Verdana' size='2'>$col_value[$varcount]</font></td>\t</tr>\n";
                  }
            }
            $varcount = $varcount + 1;
        }
        print "</table><br>\n";
        $varcount = 0;

        }else{
              if (!isset($by) or ($by <> "name")) {
              Print "<font face='Verdana' size='2'><a href=guestbook.php?action=list&rowcount=$idend>Next >></a></font>";
              die;
              }

        }
    }

    print "</body>";
    die;
    }
    if (isset($result)) {
    mysql_free_result($result);
    }
    mysql_close($db_link);

?>
<br><br>
<form name="sign_in_form" method="post" action="guestbook.php">
  <table width="375" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr bgcolor="#000066">
      <td colspan="2" height="22">
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Sign
          in <?php print $guestbook_name; ?></font></div>
      </td>
    </tr>
    <tr>
      <td width="98" height="32"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Name:</font></td>
      <td width="277" height="32"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
        <input type="text" name="guest_name" size="35">
        </font></td>
    </tr>
    <tr>
      <td width="98" height="38"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">E-Mail:</font></td>
      <td width="277" height="38"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
        <input type="text" name="guest_email" size="35">
        </font></td>
    </tr>
    <tr>
      <td width="98" valign="top" height="90"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Message:</font></td>
      <td width="277" height="90"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
        <textarea name="guest_message" cols="27" rows="6"></textarea>
        </font></td>
    </tr>
    <tr>
      <td colspan="2" height="40">
        <div align="center"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
          <input type="submit" name="Submit" value="Sign in">
          <input type="hidden" name="action" value="signed">
          <input type="reset" name="reset" value="Reset">
          </font></div>
      </td>
    </tr>
  </table>
  <p align="center"><font face="Verdana" size="2">Back to <a href=guestbook.php><?php print "$guestbook_name</a> "; ?></font></p>
</form>
</body>
</html>
