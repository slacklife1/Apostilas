Title: EzGuestBook 1.1
Description: EzGuestBook is a very simple guestbook written in PHP that contains guestbook record sorting, administration panel, IP Logging and many other functions. It is made for MySQL and PHP version 4.0 or later.
This 1.1 version comes with modified administration panel without cookies :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=615&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
