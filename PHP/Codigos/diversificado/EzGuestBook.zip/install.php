<?php
/******************************************************************************
EzGuestBook Instalation !

Do not change (edit) this file. All changes can be made in config.php file !

Copyright Armin Kalajdzija, 2002.
E-mail: kalajdzija@hotmail.com
WebSite: http://www.ak85.tk
******************************************************************************/


     include "config.php";
     
if (isset($hostname) and isset($database) and isset($db_login) and isset($db_pass) and isset($user_login) and ($user_login <> "") and isset($user_pass) and ($user_pass <> "")) {  // variable check

    if (isset($user_pass) and isset($user_pass2) and ($user_pass == $user_pass2)) {     // password == password again check
        $user_pass3 = crypt($user_pass);
    $dbconn = mysql_connect($hostname, $db_login, $db_pass) or die("Could not connect");   // connects to host
    print "<div align='center'>Connected to host!<br>";

    mysql_select_db($database) or die("Could not select database");    // selecting databes
    print "Database selected !<br>";

    $query = "CREATE TABLE ez_guestbook (id INT (4), name TEXT, email TEXT, message LONGTEXT, datetime DATETIME, ip TEXT)";
    $result = mysql_query($query) or die("Query failed");     // running create table powerban query
    print "Table powerban is created !<br>";

    $query = "CREATE TABLE ez_guestbook_auth (login TEXT, password TEXT, ip TEXT, datetime DATETIME)";
    $result = mysql_query($query) or die("Query failed");     // running create table powerban_auth query
    print "Table powerban_auth is created !<br>";
    
    $query = "INSERT INTO ez_guestbook_auth (login, password) VALUES ('$user_login', '$user_pass3')";
    $result = mysql_query($query) or die("Query failed");       // creating admin account record
    print "Administrator account created !<br>";

    mysql_close($dbconn);                                   // closing connection with database
    print "EzGuestBook is installed :)<br><br>";
    print "<a href='admin.php'>To continue click here</a></div>";
    die;
    }else{
        print "<font face='Verdana' size='2'>Password doesn't match with repeated one !</font>";      //display pass don't match text !
        die;
    }

}
?>
<html>
<head>
<title>EzGuestBook Instalation !</title>
</head>

<body bgcolor="#FFFFFF" text="#000000">
<form name="installfrm" method="post" action="install.php">
  <table width="503" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#003366">
    <tr bgcolor="#003366">
      <td colspan="2" height="31"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>EzGuestBook Instalation !</b></font></td>
    </tr>
    <tr bordercolor="#FFFFFF" valign="bottom">
      <td colspan="2" height="32"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Administrator
        Information:</font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Admin
        Login:</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">
        <input type="text" name="user_login">
        </font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Admin
        Password:</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">
        <input type="password" name="user_pass">
        </font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Admin
        Password (again):</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">
        <input type="password" name="user_pass2">
        </font></td>
    </tr>
    <tr valign="bottom" bordercolor="#FFFFFF">
      <td colspan="2" height="34"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">MySQL
        Information:</font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Hostname:</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><?php echo $hostname; ?></font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Database:</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><?php echo $database; ?></font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Login:</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><?php echo $db_login; ?></font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Password:</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><?php echo $db_pass; ?></font></td>
    </tr>
    <tr valign="bottom" bordercolor="#FFFFFF">
      <td colspan="2" height="33"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Things
        to do:</font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221" height="2"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Create
        ez_guestbook table</font></td>
      <td width="276" height="2"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Table
        where the banners will be stored</font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Create
        ez_guestbook_auth table</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Table
        with admin login and password</font></td>
    </tr>
  </table>
  <p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Note:
    If you want to change any data, you will need to edit config.php and refresh
    this index.php :)</font></p>
  <p align="center">
    <input type="submit" name="install" value="Install">
    <input type="reset" name="Submit2" value="Clear Info">
  </p>
</form>
</body>
</html>


