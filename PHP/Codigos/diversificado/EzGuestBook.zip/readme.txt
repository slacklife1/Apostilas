EzGuestBook Version 1.1

1. What is new
1. About EzGuestBook
2. Instalation
3. About Author

-----------------------

1. What is new
----------------

This 1.1 version is not so diferent from 1.0 except that authentification
part of admin.php script is now based on sessions (not on cookie like 1.0).
This is very important change on script becose I have recaved many mails from
people that didn't have cookies enabled in there browser.


2. About EzGuestBook
----------------------

EzGuestBook is my new project based on scripts that was made for
Power Banner Manager. It is very simple guestbook written in PHP
that contains guestbook record sorting, administration panel
IP Logging and many other functions. It is made for MySQL and
PHP version 4.0 or later.

Zip file contains following files:

guestbook.php - Main script that displays guestbook records. You
should link this script on your site for visitors to view the 
guestbook and "guestbook.php?action=signin" for visitors to go
directly on signin form !

admin.php - Administration Panel Script

config.php - Configuration scripts that includes variables for you
MySQL database

install.php - This is the instalation script, creates tables 
and admin account.

navmanu.php - Script that is included in every other script,
it contains link to singin, sorting options and your home
page.


3. Instalation
----------------

Change your settings in config.php and run install.php. After
instalation delete install.php or move to safe place where it 
cannot be runned.


4. About Author
-----------------

My name is Armin Kalajdzija and I am young developer form 
Bosnia and Herzegovina. I am 17. years old and this is my first 
time coding in PHP, before this I was coding in VisualBasic 
and Delphi and I still do :)

If you have any questions or sugestions please send it to:
kalajdzija@hotmail.com 
or visit my home page:
http://www.ak85.tk

Copyright Armin Kalajdzija, 2002.