<?php
echo "
<!--
    Incluir logo ap�s  a tag BODY.
    Formulario para postagem das variaveis de paginacao
-->
<!-- Formul�rio da paginacao-->
      <form name=\"frmPaginacao\" method=\"post\" action=\"$PaginaPost\">
             <input type=\"hidden\" name=\"hidIni\" value=\"$hidIni\">
             <input type=\"hidden\" name=\"hidTer\" value=\"$hidTer\">
             <input type=\"hidden\" name=\"hidPag\" value=\"$hidPag\">
      </form>
<!-- Fim formul�rio da paginacao-->

<!-- Inclusa na tag <HEAD> -->
        <style type=\"text/css\">
        .class_pg1 {
        font-family: Tahoma, Verdana, Arial, Helvetica, sans-serif;
        font-size: 9px;
        color: #666666;
        font-variant: normal;
        text-decoration: none;
        }
        .class_pg2 {
        font-family: Tahoma, Verdana, Arial, Helvetica, sans-serif;
        font-size: 13px;
        color: red;
        font-variant: normal;
        text-decoration: none;
        }
        </style>
<!-- FIM Inclusa na tag <HEAD> -->
";
?>