<?php
/*
  codigo para paginacao
  Insira este codigo onde deseja que apareca os numeros das paginas
*/

$total_linhas=$linhas_exibir;

if ($linha >$total_linhas){
/*se o total de linhas a ser paginada
for maior que a quantidade a ser exibida*/
echo "<center>
<table width=$widthTab border=\"0\" cellspacing=\"1\" cellpadding=\"0\">
<tr>
<td colspan=3 valign=\"\" height=\"11\" width=\"14%\">
   <div align=\"center\"><font face=\"verdana\" size=\"1\">
        <font face=\"arial\" size=\"1\" class=\"class_pg1\">
        <b>
        P&aacute;ginas
        ";

        $total_paginas = ($linha / $total_linhas); //Calculo para verificar o total de paginas

        $pagina = 1;
        $pagina_anterior=0;
        while($pagina < $total_paginas){
              if ($hidPag == $pagina){
                      $vClass="class=\"class_pg2\"";
              }else{
                      $vClass="";
              }
              echo"<a href=\"javascript:pagina($pagina,$pagina_anterior,"; echo ($total_linhas * $pagina) - 1; echo");\" title=\"Click para visualizar a p&aacute;gina $pagina\" $vClass onmouseOver=\"window.status='Visualizar p&aacute;gina $pagina'; return true\" onmouseout=\"window.status='Sistema'; return true\">$pagina</a>&nbsp;|&nbsp;
              ";
              $pagina_anterior=($total_linhas * $pagina);
              $pagina++;

        }
        if ($hidPag == $pagina){
                $vClass="class=\"class_pg2\"";
        }else{
                $vClass="";
        }
        echo"<a href=\"javascript:pagina($pagina,$pagina_anterior,$linha);\" title=\"Click para visualizar a p&aacute;gina $pagina\" $vClass onmouseOver=\"window.status='Visualizar p&aacute;gina $pagina'; return true\" onmouseout=\"window.status='Sistema'; return true\">$pagina</pagina></a>&nbsp;|&nbsp;
        </b>
        </font>
   <br><hr>
   </div>
</td>
</tr>
<tr>
<td align=left height=\"11\" width=\"14%\">";

       if($hidPag>1){
       echo "<a href=\"javascript:pagina("; echo $hidPag-1; echo ","; echo ($total_linhas * ($hidPag-2)); echo ","; echo ($total_linhas * ($hidPag-2) + ($linhas_exibir -1)); echo")\">
       <img src=\"$dirImagem/little_anterior.gif\"  border=0>
       </a>";
       }
echo"
</td>
<td align=center height=\"11\" width=\"14%\">
       <font face=\"arial\" size=\"2\" class=\"class_pg1\">Exibindo p&aacute;gina: $hidPag com $linhas_exibir linhas.</font><br>
       <font face=\"arial\" size=\"2\" class=\"class_pg1\">Total geral de item(s): $linha </font>
</td>
<td align=right height=\"11\" width=\"14%\">";

       if ($hidPag<$total_paginas){
       echo "
       <a href=\"javascript:pagina("; echo $hidPag+1; echo ","; echo ($total_linhas * ($hidPag)); echo ","; echo ($total_linhas * ($hidPag) + ($linhas_exibir-1)); echo")\">
       <img src=\"$dirImagem/little_proximo.gif\" border=0>
       </a> ";
       }

echo"</td>
</tr>
</table>
</center>";
}else{
        echo "<br><font size=2 face=arial class=\"class_pg1\"> <center>" . $linha. " Item(s) encontrado(s) </center></font>";
}
//fim do codigo opara pagina��o

echo "
<!--
    Insira este script para que possa ocorrer a
    postagem das variaveis de paginacao.
-->
<script language=\"JavaScript\">

      if (navigator.appName == 'Microsoft Internet Explorer'){
               frmP = document.frmPaginacao;//formulario da paginacao
      } else{
               frmP = document.document.frmPaginacao;//formulario da paginacao
      }
      //funcao da paginacao
      function pagina (pag,ini,ter){
                           frmP.hidPag.value = pag;
                           frmP.hidIni.value = ini;
                           frmP.hidTer.value = ter;
                           frmP.submit();
      }

</script>";

?>


