<?php


        $usuario= 'postgres';
        $senha =  '';
        $banco = 'web_func';
        $servidor = 'localhost';

        //Postgres
        $conexao = pg_pConnect("host=$servidor dbname=$banco  user=$usuario")or die ("Impossivel Conectar ao Servidor");

        //MySql
        $conexao = mysql_pconnect("$servidor", "$usaurio","$senha")or die ("Impossivel Conectar ao Servidor");
        mysql_select_db("$banco");

        //Oracle
        $conexao = OCILogon("$usuario","$senha","$servidor")or die ("Impossivel Conectar ao Servidor");

       /*
        Incluir este codigo antes da tag <html> ou
        ap�s o select principal dos dados a serem paginados
        O select geralmente =e atribuido a uma v�riavel. esse exmplo atribuimos � variavel resultado.
        Certifique-se de atribuir a mesma variavel no seu select.
        */

        //Postgres
        $resultado  = pg_Exec($conexao ,"SELECT nome FROM tb_logins") or die ("Erro");

        //MYsql
        $resultado  = mysql_query($conexao ,"SELECT nome FROM tb_logins") or die ("Erro");

        //Oracle
        $resultado  = OCIExecute($conexao ,"SELECT nome FROM tb_logins") or die ("Erro");




       /*****PODE SER ALTERADO PELO USUARIO********************************************/
       /*variaveis da paginacao                                                       */
         $linhas_exibir=3;                     //Total de linhas a exibir por pagina
       /*******************************************************************************/

       /*Total de registro a ser paginado (a fun��o varia de banco para banco*/

       //Postgres
       $linha=pg_NumRows ($resultado);

       //MYsql
       $linha= mysql_num_rows($resultado),

       //Oracle
       $linha= OCIRowCount($resultado);


       $vContador_quebra=0;                  //contador para quebrar as p�ginas da Paginacao
       $dirImagem="../image";                      //Definir o diretorio das imagens

       if ($hidIni==""){                     //se a pagina for chamada pela 1� vez
            $hidIni=0;                       //zera o inicio
            $hidTer=$linhas_exibir-1;        //o termino fica como o limite a ser exibido por pagina
            $hidPag="1";                     //A pagina atual fica sendo a n�.1
       }
  //fim  variaveis da paginacao
?>

<html>
<body>

<!--cabecalho da pagina��o-->
<?php
        $PaginaPost = "listagem.php"; //variavel da pagina para postagem (pagina onde contem a listagem)
        include $dirRaiz."top_paginacao.php";
?>

<?php

  //Postgres
  while (pg_Fetch_Array($query)) {

  //Mysql
  while (mysql_fetch_array($query)) {

  //Oracle
  while (OCIFetchInto($query)) {

        /* Codigo paginacao if para paginacao Incluir este codigo dentro do loop dos registros a serem paginados */
        if($vContador_quebra >= $hidIni && $vContador_quebra <= $hidTer){
        /*
                /*****PODE SER ALTERADO PELO USUARIO*********************
                 *        insira aqui os dados a serem paginados        *
                 *  Insira o html com as informa��es a serem paginadas. *
                /*******************************************************/
        */
        }
        $vContador_quebra++;
        //fim codigo paginacao if
  }

?>
<!--rodap� da pagina��o-->
<?php
        $widthTab="500";  //tamanho da tabela para coinsidir com a tabela dos itens paginados
        $dirImagem = "imagens";
        include "but_paginacao.php";
?>

</body>
</html>