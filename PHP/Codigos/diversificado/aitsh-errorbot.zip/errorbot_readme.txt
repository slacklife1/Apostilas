***********************************************************************************
*   SCRIPT        :   AITSH Errorbot
*   VERSION       :   1.0b
*   AUTHOR        :   Advanced IT Services Holland
*   EMAIL         :   info@aitsh.com
*   DATE          :   09/13/1999 (original : 08/25/1999) 
*   COUNTRY       :   The Netherlands, Europe
*   COPYRIGHT     :   You are free to modify this script,
                      as long as you keep this header in your script. 
*   DESCRIPTION   :   A simple Errorbot to catch those nasty 401, 403 404 and 500 errors.
                      NOTE: This will only work if your Provider supports it !!!
*   COMMENTS      :   Simple to set-up and to configure/adjust it 
*   INSTALLATION  :   Instructions are inside the script
                      Edit the vars below and your ready !!! [after uploading :-)]
*   THINGS TO DO  :   Better documentation inside the script, and more...
*   THINGS DONE   :   Added a 'back-to-referring'-page/-site link to 404 Error 
************************************************************************************