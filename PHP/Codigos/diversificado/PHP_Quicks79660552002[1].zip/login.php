<? 
setcookie ("userid");
if ($email <> "" and $password <> "") {

$conn=pg_pconnect("user=myusername dbname=mydbname");
$result=pg_exec($conn, "select * from users where email='$email' and password='$password'");

if (pg_numrows($result) == 1) {
$id=pg_result($result,0,'id');
$success="yes";
if ($remember == "true") {
setcookie ("userid",$id,time()+14220000);
} else {
setcookie ("userid",$id);
}
} else {
$success="no";
}

}
?>
<html><!-- #BeginTemplate "/Templates/template.dwt" -->
<head>
<!-- #BeginEditable "doctitle" -->
<title>Zack Coburn - Log in</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">
<!--



<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
//-->
</script>
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#0033CC" vlink="#0033CC" alink="#0033CC">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="248" height="49" valign="middle" align="center">LOGOHERE!</td>
<td width="900000" valign="top" bgcolor="#999999" align="right" height="1">&nbsp;</td>
</tr>
<tr bgcolor="#99CCCC">
<td colspan="2" height="1" valign="top">  &nbsp;<a href="index.php">Home</a> | Link | Link</td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" height="100">
<tr>
<td colspan="2" height="242" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="4" height="100%">
<tr>
<td valign="top" width="160" bgcolor="#EEEEEE">
<img src="library/images/spacer.gif" width="160" height="1"><br>
<?
if ($userid=="") {
?>Welcome, <b>guest</b>!<br>
<br>
<a href="login.php">Log in</a> |&nbsp;<a href="register.php">Register</a>
<?
} else {
$conn=pg_pconnect("user=myusername dbname=mydbname");
$result=pg_exec($conn, "select * from users where id='$userid'");

if (pg_numrows($result) <> 0) {
$name=pg_result($result,0,'name');
}
?> <b><?=$name?></b><br>
<br>
<a href="updateaccount.php">Update Account
</a><br>
<a href="login.php">Log out</a>
<?
} 
?>
</td>
<td valign="top">
<h3><font face="Times New Roman, Times, serif"><!-- #BeginEditable "header" -->Log in<!-- #EndEditable --></font></h3>
<font face="Times New Roman, Times, serif"><!-- #BeginEditable "content" -->
<?
if ($success=="yes") {
?>
Congratulations, you are now logged in.
<?
}
if ($success=="no") {
?> 
Sorry, you entered an incorrect login. You might want to <a href="register.php">register</a>.
<?
}
if ($success<>"yes") {
?>
<form name="form1" method="post" action="login.php">
E-mail:
<input type="text" name="email">
<br>
Password: 
<input type="password" name="password">
<br>
<br>
<input type="checkbox" name="remember" value="true">
Remember me<br>
<input type="submit" name="Submit" value="Log in">
</form>
<?
}
?>
<br>
<br>
* Please note that in order to take advantage of user authentication, you must enable cookies.<br>
In Microsoft Internet Explorer 4.0, you can enable cookies from the menu View&gt;Internet Options&gt;Advanced&gt;Security. In Netscape 4.0, you can enable cookies from the menu Edit&gt;Preferences&gt;Advanced.<!-- #EndEditable -->
<br>
</font></td>
</tr>
</table>
</td>
</tr>


</table>
</body>
<!-- #EndTemplate --></html>