<html><!-- #BeginTemplate "/Templates/template.dwt" -->
<head>
<!-- #BeginEditable "doctitle" -->
<title>Zack Coburn - Register</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">
<!--



<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
//-->
</script>
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#0033CC" vlink="#0033CC" alink="#0033CC">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="248" height="49" valign="middle" align="center">LOGOHERE!</td>
<td width="900000" valign="top" bgcolor="#999999" align="right" height="1">&nbsp;</td>
</tr>
<tr bgcolor="#99CCCC">
<td colspan="2" height="1" valign="top">  &nbsp;<a href="index.php">Home</a> | Link | Link</td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" height="100">
<tr>
<td colspan="2" height="242" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="4" height="100%">
<tr>
<td valign="top" width="160" bgcolor="#EEEEEE">
<img src="library/images/spacer.gif" width="160" height="1"><br>
<?
if ($userid=="") {
?>Welcome, <b>guest</b>!<br>
<br>
<a href="login.php">Log in</a> |&nbsp;<a href="register.php">Register</a>
<?
} else {
$conn=pg_pconnect("user=myusername dbname=mydbname");
$result=pg_exec($conn, "select * from users where id='$userid'");

if (pg_numrows($result) <> 0) {
$name=pg_result($result,0,'name');
}
?> <b><?=$name?></b><br>
<br>
<a href="updateaccount.php">Update Account
</a><br>
<a href="login.php">Log out</a>
<?
} 
?>
</td>
<td valign="top">
<h3><font face="Times New Roman, Times, serif"><!-- #BeginEditable "header" -->Register<!-- #EndEditable --></font></h3>
<font face="Times New Roman, Times, serif"><!-- #BeginEditable "content" --><b>Bold</b> = Required
<form action="registercheck.php" method="post" name="register">
Public Information:<br>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr bgcolor="lightgrey">
<td width="150" nowrap>Name:&nbsp;&nbsp;</td>
<td>
<input type="text" name="name" maxlength="50">
</td>
</tr>
<tr bgcolor="white">
<td width="150" nowrap>E-mail:&nbsp;&nbsp;</td>
<td>
<input type="text" name="email" maxlength="200">
</td>
</tr>
<tr bgcolor="lightgrey">
<td width="150" nowrap>Password:&nbsp;&nbsp;</td>
<td>
<input type="password" name="password" maxlength="100">
</td>
</tr>
<tr bgcolor="white">
<td width="150" nowrap>URL:&nbsp;&nbsp;</td>
<td>
<input type="text" name="url" maxlength="200" value="http://">
</td>
</tr>
</table>
<br>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr bgcolor="lightgrey">
<td width="150" nowrap>Address:&nbsp;&nbsp;</td>
<td>
<input type="text" name="address" maxlength="100">
</td>
</tr>
<tr bgcolor="white">
<td width="150" nowrap>City:&nbsp;&nbsp;</td>
<td>
<input type="text" name="city" maxlength="100">
</td>
</tr>
<tr bgcolor="lightgrey">
<td width="150" nowrap>State:&nbsp;</td>
<td>
<input type="text" name="state" size="5" value="" maxlength="2">
</td>
</tr>
<tr bgcolor="white">
<td width="150" nowrap>Zip:</td>
<td>
<input type="text" name="zip" size="7" value="" maxlength="5">
</td>
</tr>


<tr bgcolor="lightgrey">
<td width="150" nowrap>Phone:&nbsp;&nbsp;</td>
<td>
<input type="text" name="phone" maxlength="30">
</td>
</tr>
</table>
<br>
<input type="submit" name="Submit" value="Register!">
</form>
<!-- #EndEditable -->
<br>
</font></td>
</tr>
</table>
</td>
</tr>


</table>
</body>
<!-- #EndTemplate --></html>