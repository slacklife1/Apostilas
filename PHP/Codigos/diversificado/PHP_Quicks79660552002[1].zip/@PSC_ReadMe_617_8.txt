Title: PHP Quicksite
Description: <Version 2.0 is available at http://www.planetsourcecode.com/vb/scripts/ShowCode.asp?txtCodeId=672&lngWId=8> PHP Quicksite is basically a quick and easy site-in-a-box. Quicksite uses Macromedia Dreamweaver for templates, so all the design is up to you. 
PHP Quicksite uses a Postgresql database backend, and you will need to make a users database and update PHP Quicksite with your database information. PHP Quicksite currently includes user authorization (register / log in / update account / log out). http://www.zackcoburn.com is an example of PHP Quicksite in use. Please visit http://www.ensophic.filetap.com to get your computer questions answered by experts!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=617&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
