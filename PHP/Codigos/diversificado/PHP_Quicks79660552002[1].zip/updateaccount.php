<html><!-- #BeginTemplate "/Templates/template.dwt" -->
<head>
<!-- #BeginEditable "doctitle" -->
<title>Zack Coburn - Update Account</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">
<!--



<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
//-->
</script>
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#0033CC" vlink="#0033CC" alink="#0033CC">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="248" height="49" valign="middle" align="center">LOGOHERE!</td>
<td width="900000" valign="top" bgcolor="#999999" align="right" height="1">&nbsp;</td>
</tr>
<tr bgcolor="#99CCCC">
<td colspan="2" height="1" valign="top">  &nbsp;<a href="index.php">Home</a> | Link | Link</td>
</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" height="100">
<tr>
<td colspan="2" height="242" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="4" height="100%">
<tr>
<td valign="top" width="160" bgcolor="#EEEEEE">
<img src="library/images/spacer.gif" width="160" height="1"><br>
<?
if ($userid=="") {
?>Welcome, <b>guest</b>!<br>
<br>
<a href="login.php">Log in</a> |&nbsp;<a href="register.php">Register</a>
<?
} else {
$conn=pg_pconnect("user=myusername dbname=mydbname");
$result=pg_exec($conn, "select * from users where id='$userid'");

if (pg_numrows($result) <> 0) {
$name=pg_result($result,0,'name');
}
?> <b><?=$name?></b><br>
<br>
<a href="updateaccount.php">Update Account
</a><br>
<a href="login.php">Log out</a>
<?
} 
?>
</td>
<td valign="top">
<h3><font face="Times New Roman, Times, serif"><!-- #BeginEditable "header" -->Update Account<!-- #EndEditable --></font></h3>
<font face="Times New Roman, Times, serif"><!-- #BeginEditable "content" -->


<?
if ($userid=="") {
?>Sorry, but you must be logged in to update your account.<br>
<a href="login.php">Log in</a> or <a href="register.php">Register</a>
<?
} else {

if ($thepassword<>"" and $theemail<>"" and $name<>"") {
$conn=pg_pconnect("user=myusername dbname=mydbname");
$result=pg_exec($conn, "select password from users where id='$userid'");

if (pg_result($result,0,'password')==$thepassword) {
if ($thenewpassword=="") { 
$thenewpassword=$thepassword; 
}
pg_exec($conn, "update users set name='$thename',email='$theemail',password='$thenewpassword',url='$theurl',address='$theaddress',city='$thecity',state='$thestate',zip='$thezip',phone='$thephone' where id='$userid' and password='$thepassword'");
}

}
?>
<?
$conn=pg_pconnect("user=myusername dbname=mydbname");
$result=pg_exec($conn, "select * from users where id='$userid'");

if (pg_numrows($result) <> 0) {
$name=pg_result($result,0,'name');
$password=pg_result($result,0,'password');
$email=pg_result($result,0,'email');
$url=pg_result($result,0,'url');
$address=pg_result($result,0,'address');
$city=pg_result($result,0,'city');
$state=pg_result($result,0,'state');
$zip=pg_result($result,0,'zip');
$phone=pg_result($result,0,'phone');
}
?>
<b>Bold</b> = Required
<form action="updateaccount.php" method="post" name="register">
Public Information:<br>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr bgcolor="lightgrey">
<td width="150" nowrap>Name:&nbsp;&nbsp;</td>
<td>
<input type="text" name="thename" maxlength="50" value="<?=$name?>">
</td>
</tr>
<tr bgcolor="white">
<td width="150" nowrap>E-mail:&nbsp;&nbsp;</td>
<td>
<input type="text" name="theemail" maxlength="200" value="<?=$email?>">
</td>
</tr>
<tr bgcolor="lightgrey">
<td width="150" nowrap>Old Password:&nbsp;&nbsp;</td>
<td>
<input type="password" name="thepassword" maxlength="100">
</td>
</tr>

<tr bgcolor="white">
<td width="150" nowrap>New Password:&nbsp; </td>
<td>
<input type="password" name="thenewpassword" maxlength="100">
</td>
</tr>
<tr bgcolor="lightgrey">
<td width="150" nowrap>URL:&nbsp;&nbsp;</td>
<td>
<input type="text" name="theurl" maxlength="200" value="<?=$url?>">
</td>
</tr>
</table>
<br>
<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr bgcolor="lightgrey">
<td width="150" nowrap>Address:&nbsp;&nbsp;</td>
<td>
<input type="text" name="theaddress" maxlength="100" value="<?=$address?>">
</td>
</tr>
<tr bgcolor="white">
<td width="150" nowrap>City:&nbsp;&nbsp;</td>
<td>
<input type="text" name="thecity" maxlength="100" value="<?=$city?>">
</td>
</tr>
<tr bgcolor="lightgrey">
<td width="150" nowrap>State:&nbsp;</td>
<td>
<input type="text" name="thestate" size="5" value="<?=$state?>" maxlength="2">
</td>
</tr>
<tr bgcolor="white">
<td width="150" nowrap>Zip:</td>
<td>
<input type="text" name="thezip" size="7" value="<?=$zip?>" maxlength="5">
</td>
</tr>


<tr bgcolor="lightgrey">
<td width="150" nowrap>Phone:&nbsp;&nbsp;</td>
<td>
<input type="text" name="thephone" maxlength="30" value="<?=$phone?>">
</td>
</tr>
</table>
<br>
<input type="submit" name="Submit" value="Update!">
</form>
<?
} 
?>
<!-- #EndEditable -->
<br>
</font></td>
</tr>
</table>
</td>
</tr>


</table>
</body>
<!-- #EndTemplate --></html>