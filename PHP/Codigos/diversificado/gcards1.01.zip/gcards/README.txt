gCards 1.0 Setup Instructions
--------------------------

1. Create a database to hold the gCards database tables

2.  Open config.php and change the settings to reflect your database connection properties and your desired gCards options

3. Upload the all of the files in the gCards directory to your web server

4. Browse to setup.php (i.e. http://www.host.com/gcards/setup.php) - this will setup the database tables and give you further instructions

5.  CHMOD the images folder to 777 if the script could not automatically do it

6.  Delete setup.php or CHMOD it to 000 so that it cannot be accessed

7.  Login to the Administration Console with the username: admin password: admin

8.  Change the admin password for security purposes

9.  Add categories and cards in the Administration Console

10.  Browse to index.php to view your site!

