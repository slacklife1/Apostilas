<?
/* ===================================================================================
 * Copyright (c) 2001 Rudy S. Ingga (toekangweb@wartamikael.org). All rights reserved.
 *
 * This module is released under the GNU General Public License. 
 * 	See: http://www.gnu.org/copyleft/gpl.html
 * 
 * wmview.php
 * 	Part of WMNews,
 *	View news/category was created by wmnews.php.
 *	Last Updated: Wednesday, 16 May, 2001 12:11:58 PM
 * 
 * WMNews Version 0.2
 * 	Another PHP & MySQL driven News Publishing system.
 *
 * For latest version and example, visit:
 * 	http://wartamikael.org/PHPScripts/WMNews
 * ===================================================================================
 */

$article_catfile = "ArticleCat";
$article_file = "Article";
if(!isset($config)){ include("config/config.php"); }
if(!isset($wmlib)){ include("wmlib.php"); }
$output = "";

if(isset($ArtID)){

	$get_news = mysql_query("SELECT *,$article_catfile.ArtDesc AS CatDesc,$article_catfile.ArtIcon AS CatIcon FROM $article_file,$article_catfile WHERE $article_file.ArtCat=$article_catfile.ArtCat AND $article_file.ArtID='$ArtID' LIMIT 0,1",$db);
	$get_rows = mysql_fetch_array($get_news);
	$ArtCat = $get_rows[ArtCat];
	$Category = $get_rows[CatDesc];
	$pretty_time = pretty_time($get_rows[ArtDate],1);
	$ArtDate = $get_rows[ArtDate];
	$content = $get_rows[ArtMsg];
	$page_title = $get_rows[ArtTitle] . " - " . $get_rows[CatDesc];

	if(!empty($ArtDate)){

	if(isset($act)){

		if(isset($tion)){

			$error = "";
			if(trim($yname) == ""){ $error .= "<li>$t_err_bnm"; }
			if(!empty($ymail)){
				if(!ereg("^([a-z0-9_]|\\-|\\.)+@(([a-z0-9_]|\\-)+\\.)+[a-z]{2,4}\$",$ymail)){
					$error .= "<li>$t_err_wym";
				}
			}else{
				$ymail = $owner_email;
			}
			if(trim($yfname) == ""){ $error .= "<li>$t_err_bfn"; }
			if(!ereg("^([a-z0-9_]|\\-|\\.)+@(([a-z0-9_]|\\-)+\\.)+[a-z]{2,4}\$",$yfmail)){ $error .= "<li>$t_err_wfm";	}
			$output = box_open(2,$get_rows[CatIcon],$get_rows[CatDesc]);
			if(trim($ymsg) != ""){
				if(strlen(trim($ymsg)) > 255){
					$error .= "<li>$t_err_tlc";
				}
			}
			if($error != ""){
$output .= <<<EOF
				<tr><td bgcolor = "$bgcol">
					<p><span class="errmsg">$t_err_inv:</span></p>
					<blockquote>$error</blockquote>
					<p><a href = 'javascript:history.go(-1)'>$tback</a>
				</td></tr>
EOF;
			}else{
				$urltosend = "$base_url/wmview.php?ArtID=$ArtID";
				$subject = $t_rf_sbj;
				$contents = "Hi $yfname...,\n";
				$contents .= "$yname $t_rf_snt\n\n";
				$contents .= "$ArtTitle - $ArtDate\n$urltosend\n\n";
				if($ymsg != ""){ $contents .= "$t_rf_msg $yname:\n$ymsg\n\n"; }
				$contents .= "$t_rf_rgd\n";
				$contents .= "$site_title\n$owner_email\n\n";
				mail($yfmail,$subject,$contents,"From: $ymail\nReply-To: $ymail");
				$upd_refer = mysql_query("UPDATE $article_file SET ArtRefer = ArtRefer + 1, ArtDate = '$ArtDate' WHERE ArtID = '$ArtID'", $db);
$output .= <<<EOF
				<tr><td bgcolor="$bgcol">
					<p align="center">$t_rf_thk $yname, $yfname $t_rf_not $yfmail</p>
					<p align="center"><a href="$urltosend">$tback</a></p>
				</td></tr>
EOF;
			}
			$output .= box_close("","","");

		}else{

			if(checkIE() == "1"){
				$size = 30;
			}else{
				$size = 20;
			}
			$sizetarea = $size+round($size/2,0);
			$output = box_open(2,$get_rows[CatIcon],$get_rows[CatDesc]);
			$output .= GetArticle($ArtID,0);
$output .= <<<EOF
			<tr><td bgcolor="$bgcol">
				<form method="post" action="$PHP_SELF?ArtID=$ArtID&act=refer&tion=ok">
					<input type="hidden" name="ArtTitle" value="$get_rows[ArtTitle]">
					<input type="hidden" name "ArtDate" value="$pretty_time">
					<center><table border="0">
						<tr><td colspan="2" align="center" class="title">$trefer<p></td></tr>
						<tr><td align="right">*)&nbsp;$t_rf_yna:&nbsp;</td><td><input type="text" name="yname" size="$size" maxlength="100"></td></tr>
						<tr><td align="right">$t_rf_yml:&nbsp;</td><td><input type="text" name="ymail" size="$size" maxlength="100"></td></tr>
						<tr><td align="right">*)&nbsp;$t_rf_yfn:&nbsp;</td><td><input type="text" name="yfname" size="$size" maxlength="100"></td></tr>
						<tr><td align="right">*)&nbsp;$t_rf_yfm:&nbsp;</td><td><input type="text" name="yfmail" size="$size" maxlength="100"></td></tr>
						<tr><td align="right">$t_rf_ams:&nbsp;</td><td><textarea name="ymsg" rows="5" cols="$sizetarea"></textarea></td></tr>
						<tr><td colspan="2" class="date">*)&nbsp;$t_gnr_mus</td></tr>
						<tr><td colspan="2"><input type="image" src="images/send.gif" border="0" align="absmiddle"></td></tr>
					</table></center>
				</form>
			</td></tr>
EOF;
			$output .= box_close("","","");

		}

	}else{

/*
		$clength=strlen($content);
		if($clength > $maxchr){
			require "StoryPager/StoryPager.lib";
			$pager=new StoryPager;
			$pager->optimum_pl($maxchr);
			$pager->split($content);
			$isi=$pager->pages;
			if(!isset($page)){
				$page=0;
			}else{
				$page--;
			}
			$content=$isi[$page];
		}
*/

		$image_file = "images/icons/$get_rows[CatIcon]";
		if(!file_exists($image_file)){ $image_file="images/shim.gif"; }

		if($get_rows[ArtRate] > 0){
			$wv_rate = $get_rows[ArtRate] / $get_rows[ArtTRate];
		}else{
			$wv_rate = 0;
		}

		if($wv_rate > 0 && $t_rt_use){
			$wv_star = "&nbsp;&nbsp;&nbsp;";
			for($s = 5; $s <= $wv_rate; $s++){
				$wv_star .= "<img src=\"images/icons/star.gif\" border=\"0\" align=\"absmiddle\">";
			}
			$wv_rest = $wv_rate - ($s - 1);
			if($wv_rest > 0.49 && $wv_rest < 0.75){
				$wv_star .= "<img src=\"images/icons/starhalf.gif\" border=\"0\" align=\"absmiddle\">";
			}elseif($wv_rest >= 0.75){
				$wv_star .= "<img src=\"images/icons/star.gif\" border=\"0\" align=\"absmiddle\">";
			}
		}

		$wv_botlink = "&nbsp;<a href=\"$PHP_SELF?ArtID=$ArtID&act=refer\"><img src=\"images/icons/kirim.gif\" border=\"0\" align=\"absmiddle\" alt=\"$trefer\"></a>&nbsp;<a href=\"wmprint.php?ArtID=$ArtID\"><img src=\"images/icons/lprinter.gif\" border=\"0\" align=\"absmiddle\" alt=\"$tpver\"></a>";
		$wv_botlink_ket = "&nbsp;<span class=\"lead\">(View: $get_rows[ArtView] | Refer: $get_rows[ArtRefer] | Print: $get_rows[ArtPrint]";

		if($t_rt_use){
			$wv_botlink .= "&nbsp;<a href=\"wmrate.php?ArtID=$ArtID\"><img src=\"images/icons/rate.gif\" border=\"0\" align=\"absmiddle\" alt=\"$t_rt\"></a>";
			$wv_botlink_ket .= " | Rate: " . number_format($wv_rate,2) . " / $get_rows[ArtTRate] votes";
		}


		if($t_cmt_use){
			$wv_botlink .= "&nbsp;<a href=\"wmcomments.php?ArtID=$ArtID\"><img src=\"images/icons/comments.gif\" border=\"0\" align=\"absmiddle\" alt=\"$t_cmt\"></a>";
			$wv_botlink_ket .= " | Comment: $get_rows[ArtComment]";
		}
	
		$wv_botlink_ket .= ")</span>";

$output .= <<<EOF
		<table width="100%" cellpadding="1" cellspacing="0" border="0">
			<tr><td width="100%">
				<table width="100%" border="0" cellspacing="0" cellpadding="3">
					<tr><td width="100%" bgcolor="$botrowcol" class="judul">
						<img src="$image_file" border="0" align="absmiddle">&nbsp;<font color="$linkcol">$get_rows[CatDesc]</font>
					</td></tr>
					<tr><td>
						<p><span class="date">$pretty_time</span><br>
						<span class="bigtitle"><font color="$linkcol">$get_rows[ArtTitle]</font></span> $wv_star<br>
						<i>$get_rows[ArtLead]</i>
						<p>$content&nbsp<img src="images/signwm.gif" border="0" align="absmiddle">
					</td></tr>
					<tr><td><img src="images/dot_black.gif" width="100%" height="1" border="0"></td></tr>
					<tr><td>$wv_botlink$wv_botlink_ket</td></tr>
					<tr><td><img src="images/dot_black.gif" width="100%" height="1" border="0"></td></tr>
				</table>
			</td></tr>
		</table>
EOF;

		// Show 5 newest than current Article

		//$get_news=mysql_query("select * from $article_file where ArtCat='$ArtCat' and ArtID>'$ArtID' order by ArtDate desc limit 0,5",$db);
		$get_news = mysql_query("SELECT * FROM $article_file WHERE ArtCat = '$ArtCat' AND ArtID > '$ArtID'", $db);
		$nw_numrec = mysql_num_rows($get_news);
		if($nw_numrec > 0){
			if($nw_numrec < 5){
				$nw_limit = $nw_numrec;
				$nw_start = 0;
			}else{
				$nw_limit = 5;
				$nw_start = $nw_numrec - $nw_limit;
			}
			$get_news = mysql_query("SELECT * FROM $article_file WHERE ArtCat = '$ArtCat' AND ArtID > '$ArtID' ORDER BY ArtDate DESC LIMIT $nw_start, $nw_limit", $db);
$output .= <<<EOF
			<p><table width="100%" cellpadding="1" cellspacing="0" border="0">
				<tr><td width="100%">
					<table width="100%" border="0" cellspacing="0" cellpadding="3">
						<tr><td colspan="2" class="judul">$tnewnews</td></tr>
EOF;
			while($get_rows = mysql_fetch_array($get_news)){
				$pretty_time = pretty_time($get_rows[ArtDate],1);
$output .= <<<EOF
				<tr><td width="1%" valign="top">&#149;</td><td width="99%"><a href="$PHP_SELF?ArtID=$get_rows[ArtID]">$get_rows[ArtTitle]</a>&nbsp;&#150;&nbsp;<span class="date">$pretty_time</span></td></tr>
EOF;
			}
			$output .= "</table></td></tr></table>";
		}

		// Show 5 past news before current Article

		$get_news=mysql_query("select * from $article_file where ArtCat='$ArtCat' and ArtID<'$ArtID' order by ArtDate desc limit 0,5",$db);
		if(mysql_num_rows($get_news)>0){
$output .= <<<EOF
			<p><table width="100%" cellpadding="1" cellspacing="0" border="0">
				<tr><td width="100%">
					<table width="100%" border="0" cellspacing="0" cellpadding="3">
						<tr><td colspan="2" class="judul">$tpastnews</td></tr>
EOF;
			while($get_rows=mysql_fetch_array($get_news)){
				$pretty_time=pretty_time($get_rows[ArtDate],1);
$output .= <<<EOF
				<tr><td width="1%" valign="top">&#149;</td><td width="99%"><a href="$PHP_SELF?ArtID=$get_rows[ArtID]">$get_rows[ArtTitle]</a>&nbsp;&#150;&nbsp;<span class="date">$pretty_time</span></td></tr>
EOF;
			}
			$output .= "</table></td></tr></table>";
		}

		$upd_view = mysql_query("UPDATE $article_file SET ArtView = ArtView + 1, ArtDate = '$ArtDate' WHERE ArtID = '$ArtID'", $db);

	}

	}else{

		$output = box_open(2,"note.gif","#$ArtID");
		$output .= "<tr><td bgcolor=\"$bgcol\" class=\"errmsg\">$tnonews";
		$output .= box_close("","","");
		$page_title = $tnonews;

	}

}else{

	if(isset($ArtCat)){

		if(!isset($pos)){$pos=0;}
		$temp_pos=$pos;
		if(isset($ArtCat)){
			$where="and $article_file.ArtCat='$ArtCat'";
		}else{
			$where="";
		}
		$get_count=mysql_query("select count(ArtID) as Total from $article_file where $article_file.ArtCat='$ArtCat'",$db);
		$count_row=mysql_fetch_array($get_count);
		$numrec=$count_row[Total];
		$numpage=intval($numrec/$step);
		if($numrec%$step){
			$numpage++;
		}
		$get_news=mysql_query("select *,$article_catfile.ArtDesc as CatDesc,$article_catfile.ArtIcon as CatIcon from $article_file,$article_catfile where $article_file.ArtCat=$article_catfile.ArtCat $where order by $article_file.ArtDate desc limit $pos,$step",$db);
		if(mysql_num_rows($get_news)=="0"){
			$output = box_open(2,"note.gif","#$ArtCat");
			$output .= "<tr><td bgcolor=\"$bgcol\" class=\"errmsg\">$tnonews";
			$output .= box_close("","","");
			$page_title = $tnonews;
		}else{
			$i=0;
			while($get_rows=mysql_fetch_array($get_news)){
				$i++;
				if($i==1){
$output .= <<<EOF
					<table width="100%" cellpadding="1" cellspacing="0" border="0">
						<tr><td width="100%" bgcolor="$bgcol">
							<table width="100%" border="0" cellspacing="0" cellpadding="3">
								<tr><td width="100%" bgcolor="$botrowcol" class="judul" colspan="2"><img src="images/icons/$get_rows[CatIcon]" border="0" align="absmiddle">&nbsp;<font color="$linkcol">$get_rows[CatDesc]</font></td></tr>
EOF;
				}
				$pretty_time=pretty_time($get_rows[ArtDate],1);
$output .= <<<EOF
				<tr><td bgcolor="$bgcol" width="1%" valign="top">&#149;</td><td bgcolor="$bgcol" width="99%" valign="top"><a href="$PHP_SELF?ArtID=$get_rows[ArtID]">$get_rows[ArtTitle]</a>&nbsp;&#150;&nbsp;<span class="date">$pretty_time</span></td></tr>
EOF;
				$page_title = $get_rows[CatDesc];
			}
			$output.="</table></td></tr></table>";
		}

	}else{

		if($Top){

			$wv_query[] = "SELECT * FROM $article_file WHERE ArtView > 0 ORDER BY ArtView DESC LIMIT 0,10";
			$wv_query[] = "SELECT * FROM $article_file WHERE ArtRefer > 0 ORDER BY ArtRefer DESC LIMIT 0,10";
			$wv_query[] = "SELECT * FROM $article_file WHERE ArtPrint > 0 ORDER BY ArtPrint DESC LIMIT 0,10";

			$wv_querydesc[] = $t_top_viw;
			$wv_querydesc[] = $t_top_rfr;
			$wv_querydesc[] = $t_top_prn;

			$wv_queryval[] = "ArtView";
			$wv_queryval[] = "ArtRefer";
			$wv_queryval[] = "ArtPrint";

			if($t_cmt_use){
				$wv_query[] = "SELECT * FROM $article_file WHERE ArtComment > 0 ORDER BY ArtComment DESC LIMIT 0,10";
				$wv_querydesc[] = $t_top_cmt;
				$wv_queryval[] = "ArtComment";
			}

			if($t_rt_use){
				$wv_query[] = "SELECT * FROM $article_file WHERE ArtTRate > 0 ORDER BY ArtTRate DESC LIMIT 0,10";
				$wv_query[] = "SELECT ArtID, ArtDate, ArtTitle, ArtRate/ArtTRate AS RateVal FROM $article_file WHERE ArtRate > 0 ORDER BY RateVal DESC LIMIT 0,10";
				$wv_querydesc[] = $t_top_vot;
				$wv_querydesc[] = $t_top_rte;
				$wv_queryval[] = "ArtTRate";
				$wv_queryval[] = "RateVal";
			}

			$wv_topout = "";
			for($i = 0; $i < count($wv_query); $i++){
				$get_news = mysql_query($wv_query[$i], $db);
				$wv_topout .= "<tr><td colspan=\"2\" class=\"bigtitle\">$wv_querydesc[$i]</td></tr>";
				while($get_rows = mysql_fetch_array($get_news)){
					$wv_ptime = pretty_time($get_rows[ArtDate],1);
					if($wv_queryval[$i] == "RateVal"){
						$wv_qryval = number_format($get_rows[RateVal],2);
					}else{
						$wv_qryval = $wv_queryval[$i];
						$wv_qryval = $get_rows[$wv_qryval];
					}
					$wv_topout .= "<tr><td width=\"1%\" valign=\"top\">&#149;</td><td width=\"99%\" valign=\"top\"><a href=\"$PHP_SELF?ArtID=$get_rows[ArtID]\">$get_rows[ArtTitle]</a>&nbsp;&nbsp;<span class=\"lead\">($wv_qryval)</span>&nbsp;&nbsp;&#150;&nbsp;<span class=\"date\">$wv_ptime</span></td></tr>";
				}
				$wv_topout .= "<tr><td colspan=\"2\"><img src=\"images/dot_black.gif\" width=\"100%\" height=\"1\" border=\"0\"></td></tr>";
			}

			$output = box_open(2,"top.gif","$t_top_txt");
			$output .= $wv_topout;
			$output .= box_close("","","");
			$page_title = $t_top_txt;


		}


	}

}


/* Print Out the whole thing we've got from above into browser */

flush();
include("header.php");
echo "<table border=\"0\" cellpadding=\"0\" cellspacing=\"1\" width=\"100%\"><tr><td width=\"20%\" valign=\"top\">";
include("leftcol.php");
echo "</td><td width=\"60%\" valign=\"top\"><table width=\"100%\" cellpadding=\"2\" cellspacing=\"0\" border=\"0\"><tr><td width=\"100%\">";
echo $output;
echo "</td></tr></table>";
if($numpage > 1){
	pagespan("$PHP_SELF?ArtCat=$ArtCat", $tsnews, 0);
}
/* WARNING: Do not remove this line until you pay for comercial version (No WMNews link!) */
echo "<p align=center><span class=\"lead\">Managed by <a href=\"http://wartamikael.org/PHPScripts/?product=WMNews\" target=\"_blank\">WMNews</a>, <a href=\"http://www.php.net\" target=\"_blank\">PHP</a> & <a href=\"http://www.mysql.com\" target=\"_blank\">MySQL</a></span>";
echo "</td><td width=\"20%\" valign=\"top\">";
include("rightcol.php");
echo "</td></tr></table>";
include("footer.php");

?>