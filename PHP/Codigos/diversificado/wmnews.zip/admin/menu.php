<?
/* ===================================================================================
 * Copyright (c) 2001 Rudy S. Ingga (toekangweb@wartamikael.org). All rights reserved.
 *
 * menu.php
 *   Admin Menu
 * ===================================================================================
 */
?>

<html>
	<head>
		<base target="main">
		<title>News Administration Module</title>
		<link rel="stylesheet" href="../wm.css">
	</head>
	<body topmargin="5" leftmargin="5" marginwidth="5" marginheight="5" bgcolor="#ffffff" text="#000000" link="#0000FF" alink="#FF0000" vlink="#0000FF">
		<h1><center>Back Office</center></h1>
		<table border="0" width="100%" cellpadding="3" cellspacing="0">
			<tr>
				<td width="100%" align="right" nowrap>
					<p><a href="../" target="_blank">Home</a></p>
					<p><b>Back End:</b></p>
					<a href="wmnews.php">News</a><br>
					<p><b>Information:</b></p>
					<a href="phpinfo.php">PHP Info</a><br>
				</td>
			</tr>
		</table>
	</body>
</html>
