<?
/* ===================================================================================
 * Copyright (c) 2001 Rudy S. Ingga (toekangweb@wartamikael.org). All rights reserved.
 *
 * This module is released under the GNU General Public License. 
 * 	See: http://www.gnu.org/copyleft/gpl.html
 * 
 * wmnews.php
 * 	Part of WMNews,
 *	Back end script.
 *	Last Updated: Thursday, 14 June, 2001 10:51:01 AM
 * 
 * WMNews Version 0.2
 * 	Another PHP & MySQL driven News Publishing system.
 *
 * For latest version and example, visit:
 * 	http://wartamikael.org/PHPScripts/WMNews
 * ===================================================================================
 */

$article_catfile = "ArticleCat";
$article_file = "Article";
$cmt_file = "ArtComments";

if(!isset($config)){ include("../config/config.php"); }
if(!isset($wmlib)){ include("../wmlib.php"); }

if(checkIE()){
	$size = 40;
}else{
	$size = 30;
}
$sizetarea = $size+round($size/2,0);
$sizesarea = $size-round($size/2,0);

function DelComments($CmID){
	global $db, $cmt_file;
	$get_comment = mysql_query("SELECT * FROM $cmt_file WHERE CmID = '$CmID' LIMIT 0,1", $db);
	while($get_row = mysql_fetch_array($get_comment)){
		DelSubComments($get_row[CmID]);
		$delete = mysql_query("DELETE FROM $cmt_file WHERE CmID = '$CmID'", $db);
	}
}

function DelSubComments($ParentID){
	global $db, $cmt_file;
	$get_subcomments = mysql_query("SELECT * FROM $cmt_file WHERE CmPID = '$ParentID'", $db);
	while($get_rows = mysql_fetch_array($get_subcomments)){
		$CmPID = $get_rows[CmID];
		$delete = mysql_query("DELETE FROM $cmt_file WHERE CmPID = '$ParentID'", $db);
		DelSubComments($CmPID);
	}
}

?>

<html>
	<head>
		<title>News Administration Module</title>
		<link rel="stylesheet" href="../wm.css">
		<script src="../wm.js" language="Javascript"></script>
	</head>
	<body topmargin="5" leftmargin="5" marginwidth="5" marginheight="5" bgcolor="<? echo $bgcol;?>" text="<? echo $textcol;?>" link="<? echo $linkcol;?>" vlink="<? echo $vlinkcol;?>" alink="<? echo $alinkcol;?>">
	<?
	echo "<h1>News/Articles Administration</h1>";
	echo "<p><b><a href=\"$PHP_SELF\">Main Menu</a></b></p>";

	if(!isset($act)){

$mainmenu=<<<EOF
			<p><b>Categories:</b></p>
			<p>
			&nbsp;&nbsp;&nbsp;&nbsp;<a href="$PHP_SELF?act=addcat">Add Category</a><br>
			&nbsp;&nbsp;&nbsp;&nbsp;<a href="$PHP_SELF?act=vicat">View Category</a>
			</p>
			<p><b>News/Articles:</b></p>
			<p>
			&nbsp;&nbsp;&nbsp;&nbsp;<a href="$PHP_SELF?act=add">Add News</a><br>
			&nbsp;&nbsp;&nbsp;&nbsp;<a href="$PHP_SELF?act=vi">View All News</a><br>
			&nbsp;&nbsp;&nbsp;&nbsp;<a href="$PHP_SELF?act=vi&wc=1">View All News with comments</a>
			</p>
			<p><b>Search:</b>
			<form action="$PHP_SELF?act=vi" method="post">
			&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="nw_search" size="$size" value="" maxlength="50">
			&nbsp;&nbsp;<input type="submit" value="Go">
			</form>
			</p>
			<p><b>Generator:</b></p>
			<p>
			&nbsp;&nbsp;&nbsp;&nbsp;<a href="$PHP_SELF?act=crtcat">Create Category Box</a><br>
			&nbsp;&nbsp;&nbsp;&nbsp;<a href="$PHP_SELF?act=crt">Create Last News Box per Category</a><br>
			&nbsp;&nbsp;&nbsp;&nbsp;<a href="$PHP_SELF?act=crtall">Create All Last News</a>
			</p>
EOF;
			echo $mainmenu;

	}else{

		if($act=="addcat"){

			if(!isset($tion)){
$addcat=<<<EOF
					<h2>Add Category</h2>
					<form action="$PHP_SELF?act=addcat&tion=save" method="post">
						<table cellpadding=3 cellspacing=0 border=0>
						<tr><td align="right">New Category:</td><td><input type=text name="Category" size="$size" maxlength="100" value="Type New Category here..."></td></tr>
						<tr><td align="right">Display Limit:</td><td><input type=text name="Limit" size="$sizesarea" maxlength="2" value="1">&nbsp;&nbsp;How many record(s) display on the Box</td></tr>
						<tr><td align="right">Box Style:</td><td><input type=text name="BoxStyle" size="$sizesarea" maxlength="1" value="1">&nbsp;&nbsp;1=Side&nbsp;2=Center</td></tr>
						<tr><td align="right">List:</td><td><input type=text name="List" size="$sizesarea" maxlength="1" value="1">&nbsp;&nbsp;1=List&nbsp;0=Do not List on Category Box</td></tr>
						<tr><td align="right">Icon:</td><td><input type=text name="Icon" size="$sizetarea" maxlength="25" value="note.gif">&nbsp;&nbsp;icon file name</td></tr>
						<tr><td colspan="2"><input type="submit" value="Save"></td></tr>
						</table>
					</form>
EOF;
				echo $addcat;
				echo "<a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"Return\"></a>";
			}else{
				$query="insert into $article_catfile (ArtDesc,ArtLimit,ArtDisplay,ArtList,ArtIcon) values ('$Category','$Limit','$BoxStyle','$List','$Icon')";
				$insert=mysql_query($query,$db);
				echo "Done!";
				echo "<p><a href=\"$PHP_SELF?act=addcat\">Add More Category</a><br>";
			}

		}elseif($act=="modcat"){

			if(!isset($tion)){

				$get_cat=mysql_query("select * from $article_catfile where ArtCat='$ArtCat'",$db);
				$get_rows=mysql_fetch_array($get_cat);
$modifycat=<<<EOF
				<h2>Modify Category</h2>
				<form action="$PHP_SELF?act=modcat&tion=ok" method="post">
						<table cellpadding=3 cellspacing=0 border=0>
						<tr><td align="right">Category:</td><td><input type=text name="Category" size="$size" maxlength="100" value="$get_rows[ArtDesc]"></td></tr>
						<tr><td align="right">Display Limit:</td><td><input type=text name="Limit" size="$sizesarea" maxlength="2" value="$get_rows[ArtLimit]">&nbsp;&nbsp;How many record(s) display on the Box</td></tr>
						<tr><td align="right">Box Style:</td><td><input type=text name="BoxStyle" size="$sizesarea" maxlength="1" value="$get_rows[ArtDisplay]">&nbsp;&nbsp;1=Side&nbsp;2=Center</td></tr>
						<tr><td align="right">List:</td><td><input type=text name="List" size="$sizesarea" maxlength="1" value="$get_rows[ArtList]">&nbsp;&nbsp;1=List&nbsp;0=Do not List on Category Box</td></tr>
						<tr><td align="right">Icon:</td><td><input type=text name="Icon" size="$sizetarea" maxlength="25" value="$get_rows[ArtIcon]">&nbsp;&nbsp;icon file name</td></tr>
						<tr><td colspan="2"><input type="submit" value="Save"><input type="hidden" name="ArtCat" value="$ArtCat"></td></tr>
						</table>
				</form>
EOF;
				echo $modifycat;
				echo "<a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"Return\"></a>";

			}else{

				$update=mysql_query("update $article_catfile set ArtDesc='$Category',ArtLimit='$Limit',ArtDisplay='$BoxStyle',ArtList='$List',ArtIcon='$Icon' where ArtCat='$ArtCat'",$db);
				echo "Done!";
				echo "<p><a href=\"$PHP_SELF?act=vicat\">Continue</a><br>";

			}

		}elseif($act=="delcat"){

			if(!isset($tion)){

				$get_cat=mysql_query("select * from $article_catfile where ArtCat='$ArtCat'",$db);
				$get_rows=mysql_fetch_array($get_cat);
				echo "<h2>Delete Category</h2>";
				echo "<table width=100% border=1 cellpadding=3>";
				echo "<tr><td align=center width=5%><b>ID</b></td><td align=center width=20%><b>Category Name</b></td><td align=center width=5%><b>Display Limit</b></td><td align=center width=5%><b>Box Style</b></td><td align=center width=5%><b>List</b></td><td align=center width=20%><b>Icon</b></td></tr>";
				echo "<tr><td align=center>$get_rows[ArtCat]</td><td>$get_rows[ArtDesc]</td><td align=center>$get_rows[ArtLimit]</td><td align=center>$get_rows[ArtDisplay]</td><td align=center>$get_rows[ArtList]</td><td align=center>$get_rows[ArtIcon]</td></tr>";
				echo "</table>";
				echo "<table width=100%><tr><td>";
				echo "<form action=\"$PHP_SELF?act=delcat&tion=ok\" method=\"post\">";
				echo "Are u sure want to delete this category? ";
				echo "<input type=hidden name=ArtCat value=$ArtCat>";
				echo "<input type=submit value=Delete>";
				echo "</form>";
				echo "<a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"Return\"></a>";
				echo "</td></tr></table>";

			}else{

				$delete=mysql_query("delete from $article_catfile where ArtCat='$ArtCat'",$db);
				echo "Done!";
				echo "<p><a href=\"$PHP_SELF?act=vicat\">Continue</a><br>";

			}

		}elseif($act=="vicat"){

			if(!isset($pos)){$pos=0;}
			$temp_pos=$pos;
			$get_count=mysql_query("select count(ArtCat) as Total from $article_catfile",$db);
			$count_row=@mysql_fetch_array($get_count);
			$numrec=$count_row[Total];
			$numpage=intval($numrec/$step);
			if($numrec%$step){
				$numpage++;
			}
			$get_cats=mysql_query("select * from $article_catfile order by ArtDesc asc limit $pos,$step",$db);
			if(mysql_num_rows($get_cats)=="0"){
				echo "No Category!";
			}else{
				echo "<h2>View Category</h2>";
				echo "<table width=100% border=0 cellspacing=1 cellpadding=3>\n";
				echo "<tr><td align=center width=5% bgcolor=$toprowcol class=JudulPutih><b>ID</b></td><td align=center width=20% bgcolor=$toprowcol class=JudulPutih><b>Category Name</b></td><td align=center width=5% bgcolor=$toprowcol class=JudulPutih><b>Display Limit</b><td class=JudulPutih align=center width=5% bgcolor=$toprowcol><b>Box Style</b></td><td align=center width=5% bgcolor=$toprowcol class=JudulPutih><b>List</b></td><td align=center width=20% bgcolor=$toprowcol class=JudulPutih><b>Icon</b></td><td align=center width=35% bgcolor=$toprowcol class=JudulPutih><b>Action</b></td></tr>\n";
				$i=0;
				while($get_rows=mysql_fetch_array($get_cats)){
					$i++;
					if(($i%2)==1){
						$bgcolor=$botrowcol;
					}else{
						$bgcolor=$bgcol;
					}
					echo "<tr><td align=center bgcolor=$bgcolor>$get_rows[ArtCat]</td><td bgcolor=$bgcolor>$get_rows[ArtDesc]</td><td align=center bgcolor=$bgcolor>$get_rows[ArtLimit]</td><td align=center bgcolor=$bgcolor>$get_rows[ArtDisplay]</td><td align=center bgcolor=$bgcolor>$get_rows[ArtList]</td><td align=center bgcolor=$bgcolor>$get_rows[ArtIcon]</td>";
					echo "<td align=center bgcolor=$bgcolor><a href=\"$PHP_SELF?act=add&ArtCat=$get_rows[ArtCat]\"><img src=\"../images/icons/add.gif\" border=\"0\" align=\"absmiddle\" alt=\"Add News/Article\"></a>&nbsp;&nbsp;&nbsp;<a href=\"$PHP_SELF?act=vi&ArtCat=$get_rows[ArtCat]\"><img src=\"../images/icons/view.gif\" border=\"0\" align=\"absmiddle\" alt=\"View News/Article\"></a>&nbsp;&nbsp;&nbsp;<a href=\"$PHP_SELF?act=addcat\"><img src=\"../images/icons/addcat.gif\" border=\"0\" align=\"absmiddle\" alt=\"Add Category\"></a>&nbsp;&nbsp;&nbsp;";
					echo "<a href=\"$PHP_SELF?act=delcat&ArtCat=$get_rows[ArtCat]\"><img src=\"../images/icons/delcat.gif\" border=\"0\" align=\"absmiddle\" alt=\"Delete Category\"></a>&nbsp;&nbsp;&nbsp;<a href=\"$PHP_SELF?act=modcat&ArtCat=$get_rows[ArtCat]\"><img src=\"../images/icons/modifycat.gif\" border=\"0\" align=\"absmiddle\" alt=\"Edit Category\"></a></td></tr>\n";
				}
				echo "<tr><td bgcolor=$toprowcol>&nbsp;</td><td bgcolor=$toprowcol>&nbsp;</td><td bgcolor=$toprowcol>&nbsp;</td><td bgcolor=$toprowcol>&nbsp;</td><td bgcolor=$toprowcol>&nbsp;</td><td bgcolor=$toprowcol>&nbsp;</td><td bgcolor=$toprowcol>&nbsp;</td></tr></table>";
			}
			if($numpage>1){
				pagespan("$PHP_SELF?act=vicat", "category");
			}

		}elseif($act=="crtcat"){

			$get_cats=mysql_query("select * from $article_catfile order by ArtDesc asc",$db);
			//$contents=box_open(1, "archives.gif", $tboxcat);
			$contents="<table width=\"100%\" cellpadding=\"1\" cellspacing=\"0\" border=\"0\"><tr><td width=\"100%\" bgcolor=\"<? echo \$linkcol;?>\">\n";
			$contents.="<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\"><tr><td bgcolor=\"<? echo \$toprowcol;?>\" class=\"judulputih\" colspan=\"2\"><img src=\"images/icons/archives.gif\" border=\"0\" align=\"absmiddle\">&nbsp;$tboxcat</td></tr>\n";
			$i=0;
			while($get_rows=mysql_fetch_array($get_cats)){
				if($get_rows[ArtList]==1){
					$i++;
					if(($i%2)==1){
						$bgcolor=$grey;
					}else{
						$bgcolor=$bgcol;
					}
					$contents.="<tr><td class=\"lead\" align=\"right\" valign=\"top\" width=\"99%\" bgcolor=\"$bgcolor\"><a href=\"$base_url/wmview.php?ArtCat=$get_rows[ArtCat]\">$get_rows[ArtDesc]</a></td><td width=\"1%\" valign=\"top\" bgcolor=\"$bgcolor\"><img src=\"images/icons/folder.gif\" border=\"0\" align=\"absmiddle\"></td></tr>\n";
				}
			}
			$contents.="</td></tr></table></td></tr></table>";
			$fn=trim($article_catfile);
			$fn=eregi_replace(" ","_",$fn).".wmn";
			$fo=fopen("$base_datapath/$fn","w");
			$fw=fwrite($fo,$contents);
			$fc=fclose($fo);
			echo "&nbsp;&nbsp;&nbsp;Created $fn...Done!<br>\n";

		}elseif($act == "vicmt"){

			if($ArtID){

				/* Check article first */
				$get_news = mysql_query("SELECT * FROM $article_file WHERE ArtID = '$ArtID' LIMIT 0,1", $db);
				if(mysql_num_rows($get_news) == "0"){
					echo "No Article!";
					echo "<p><a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"Return\"></a>";
				}else{
					$get_row = mysql_fetch_array($get_news);
					$nw_artlink = "<a href=\"$PHP_SELF?act=detail&ArtID=$ArtID&ArtCat=$get_row[ArtCat]\">$get_row[ArtTitle]</a>";
					/* Then check if any comments from article */
					if($CmID && !$CmPID){
						$get_cmt = mysql_query("SELECT * FROM $cmt_file WHERE CmID = '$CmID' LIMIT 0,1", $db);
						if(mysql_num_rows($get_cmt) == "0"){
							$CmPID = 0;
						}else{
							$get_row = mysql_fetch_array($get_cmt);
							$CmPID = $get_row[CmPID];
						}
					}
					if(!$CmPID){ $CmPID = 0; }
					$get_cmt = mysql_query("SELECT * FROM $cmt_file WHERE CmArtID = '$ArtID' AND CmPID = '$CmPID'", $db);
					$nw_numrec = mysql_num_rows($get_cmt);
					if($nw_numrec != "0"){
						$nw_numpage = intval($nw_numrec / $step);
						if($nw_numrec % $step){
							$nw_numpage++;
						}
						echo "<h2>Comments</h2>";
						if($CmPID > 0){
							$nw_ttlink = "<a href=\"$PHP_SELF?act=vicmt&ArtID=$ArtID\"><img src=\"../images/cmt_topthr.gif\" border=\"0\" align=\"absmiddle\"></a>";
						}
						echo "<p>$nw_artlink&nbsp;&nbsp;&nbsp;$nw_ttlink</p>";
						echo "<table width=100% border=0 cellspacing=1 cellpadding=3>";
						echo "<tr><td align=center width=15% bgcolor=$toprowcol class=JudulPutih><b>Time Stamp</b></td><td align=center width=15% bgcolor=$toprowcol class=JudulPutih><b>Poster</b></td><td align=center width=55% bgcolor=$toprowcol class=JudulPutih><b>Comment</b></td><td align=center width=15% bgcolor=$toprowcol class=JudulPutih><b>Action</b></td></tr>\n";
						if(!isset($pos)){ $pos = 0; }
						$get_cmt = mysql_query("SELECT * FROM $cmt_file WHERE CmArtID = '$ArtID' AND CmPID = '$CmPID' LIMIT $pos, $step", $db);
						$i=0;
						while($get_rows = mysql_fetch_array($get_cmt)){
							$i++;
							if(($i % 2) == 1){
								$nw_bgcolor = $botrowcol;
							}else{
								$nw_bgcolor = $bgcol;
							}
							if($get_rows[CmEmail] != ""){
								$nw_name = "<a href=\"mailto:$get_rows[CmEmail]\">$get_rows[CmName]</a>";
							}else{
								$nw_name = $get_rows[CmName];
							}
							$nw_name .= "<br><span class=\"lead\">$get_rows[CmIP]</span>";
							$nw_comment = "<b>$get_rows[CmSubject]</b><br>";
							$nw_comment .= nl2br($get_rows[CmContent]);
							$nw_comment2 = "";
							if($get_rows[CmContent2] != "" && $get_rows[CmDate2] != "00000000000000"){
								$nw_comment2 .= "<p><blockquote><span class=\"title\">Admin Reply</span> - <span class=\"date\">" . pretty_time($get_rows[CmDate2],1) . "</span>";
								$nw_comment2 .= "<br>" . nl2br($get_rows[CmContent2]) . "</blockquote>";
							}
							echo "<tr><td align=center valign=top bgcolor=$nw_bgcolor>$get_rows[CmDate]</td><td valign=top bgcolor=$nw_bgcolor>$nw_name</td><td valign=top bgcolor=$nw_bgcolor>$nw_comment $nw_comment2</td>";
							echo "<td align=right valign=top bgcolor=$nw_bgcolor>";
							/* Check if any child comments? */
							$get_c_cmt = mysql_query("SELECT * FROM $cmt_file WHERE CmArtID = '$ArtID' AND CmPID = '$get_rows[CmID]'", $db);
							$nw_c_numrec = mysql_num_rows($get_c_cmt);
							if($nw_c_numrec != "0"){
								echo "<a href=\"$PHP_SELF?act=vicmt&ArtID=$ArtID&CmPID=$get_rows[CmID]\"><img src=\"../images/icons/view.gif\" border=\"0\" align=\"absmiddle\" alt=\"View Child Comment\"></a>&nbsp;&nbsp;&nbsp;";
							}
							echo "<a href=\"$PHP_SELF?act=delcmt&ArtID=$ArtID&CmID=$get_rows[CmID]\"><img src=\"../images/icons/delete.gif\" border=\"0\" align=\"absmiddle\" alt=\"Delete Comment\"></a>&nbsp;&nbsp;&nbsp;";
							echo "<a href=\"$PHP_SELF?act=modcmt&ArtID=$ArtID&CmID=$get_rows[CmID]\"><img src=\"../images/icons/modify.gif\" border=\"0\" align=\"absmiddle\" alt=\"Edit / Admin Reply Comment\"></a>";
							if($CmPID > 0){
								if($get_rows[CmPID] == "0"){
									echo "&nbsp;&nbsp;&nbsp;<a href=\"$PHP_SELF?act=vicmt&ArtID=$ArtID\"><img src=\"../images/icons/toparent.gif\" border=\"0\" align=\"absmiddle\" alt=\"View Parrent Comment\"></a>";
								}else{
									echo "&nbsp;&nbsp;&nbsp;<a href=\"$PHP_SELF?act=vicmt&ArtID=$ArtID&CmID=$get_rows[CmPID]\"><img src=\"../images/icons/toparent.gif\" border=\"0\" align=\"absmiddle\" alt=\"View Parrent Comment\"></a>";
								}
							}
						}
						echo "<tr><td bgcolor=$toprowcol>&nbsp;</td><td bgcolor=$toprowcol>&nbsp;</td><td bgcolor=$toprowcol>&nbsp;</td><td bgcolor=$toprowcol>&nbsp;</td></tr></table>";
						$numrec = $nw_numrec;
						if($nw_numpage > 1){
							pagespan("$PHP_SELF?act=vicmt&ArtID=$ArtID&CmPID=$CmPID",$t_cmt);
						}
					}else{
						/* No comments on this article */
						echo "No Comments!";
						echo "<p><a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"Return\"></a>";
					}
				}

			}

		}elseif($act == "modcmt"){

			if(!isset($tion)){

				/* Check comment first */
				$get_cmt = mysql_query("SELECT * FROM $cmt_file WHERE CmID = '$CmID' LIMIT 0,1", $db);
				if(mysql_num_rows($get_cmt) == "0"){
					echo "No Comment!";
					echo "<p><a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"Return\"></a>";
				}else{
					$get_row = mysql_fetch_array($get_cmt);
					$nw_ptime = pretty_time($get_row[CmDate],1);
$nw_modcmt_form = <<<EOF
					<h2>Modify Comment</h2>
					<form action="$PHP_SELF?act=modcmt&tion=ok" method="post">
					<table cellpadding=3 cellspacing=0 border=0>
						<tr><td align="right">Date:</td><td>$nw_ptime</td></tr>
						<tr><td align="right">Poster:</td><td><input type=text name=CmName size=$size value="$get_row[CmName]"></td></tr>
						<tr><td align="right">E-mail:</td><td><input type=text name=CmEmail size=$size value="$get_row[CmEmail]"> ($get_row[CmIP])</td></tr>
						<tr><td align="right">Subject:</td><td><input type=text name=CmSubject size=$sizetarea value="$get_row[CmSubject]"></td></tr>
						<tr><td align="right">Comment:<p>No html,<br>255 character max.</td><td><textarea name="CmContent" cols="$sizetarea" rows="5">$get_row[CmContent]</textarea></td></tr>
						<tr><td align="right">Admin Reply:<p>No html,<br>255 character max.</td><td><textarea name="CmContent2" cols="$sizetarea" rows="5">$get_row[CmContent2]</textarea></td></tr>
						<tr><td colspan="2">
							<input type="submit" value="Save">
							<input type="hidden" name="CmDate" value="$get_row[CmDate]">
							<input type="hidden" name="CmID" value="$CmID">
							<input type="hidden" name="Referer" value="$HTTP_REFERER">
						</td></tr>
						</table>
					</form>
EOF;
				}
				echo $nw_modcmt_form;
				echo "<a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"Return\"></a>";

			}else{

				$nw_offset_time = offset_time();
				if($CmContent2 == ""){ $nw_offset_time = "00000000000000"; }
				$update = mysql_query("UPDATE $cmt_file SET CmDate='$CmDate',CmName='$CmName',CmEmail='$CmEmail',CmSubject='$CmSubject',CmContent='$CmContent',CmContent2='$CmContent2',CmDate2='$nw_offset_time' WHERE CmID = '$CmID'",$db);
				CreateLComments();
				echo "Done!";
				echo "<p><a href=\"$Referer\">Continue</a><br>";

			}

		}elseif($act == "delcmt"){

			if(!isset($tion)){

				/* Check comment first */
				$get_cmt = mysql_query("SELECT * FROM $cmt_file WHERE CmID = '$CmID' LIMIT 0,1", $db);
				if(mysql_num_rows($get_cmt) == "0"){
					echo "No Comment!";
					echo "<p><a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"Return\"></a>";
				}else{
					$get_row = mysql_fetch_array($get_cmt);
					$nw_ptime = pretty_time($get_row[CmDate],1);
$nw_delcmt_form = <<<EOF
					<h2>Delete Comment</h2>
					<form action="$PHP_SELF?act=delcmt&tion=ok" method="post">
					<table cellpadding=3 cellspacing=0 border=0>
						<tr><td align="right">Date:</td><td>$nw_ptime</td></tr>
						<tr><td align="right">Poster:</td><td>$get_row[CmName]</td></tr>
						<tr><td align="right">E-mail:</td><td>$get_row[CmEmail] ($get_row[CmIP])</td></tr>
						<tr><td align="right">Subject:</td><td>$get_row[CmSubject]</td></tr>
						<tr><td align="right">Comment:</td><td>$get_row[CmContent]</td></tr>
						<tr><td align="right">Admin Reply:</td><td>$get_row[CmContent2]</td></tr>
						<tr><td colspan="2">Delete this comment including all it's child comments?
							<input type="submit" value="Delete">
							<input type="hidden" name="CmID" value="$CmID">
							<input type="hidden" name="ArtID" value="$get_row[CmArtID]">
						</td></tr>
						</table>
					</form>
EOF;
				}
				echo $nw_delcmt_form;
				echo "<a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"Return\"></a>";

			}else{

				DelComments($CmID);
				$get_comments = mysql_query("SELECT CmID FROM $cmt_file WHERE CmArtID = '$ArtID'", $db);
				$nw_ttlcmt = mysql_num_rows($get_comments);
				$update = mysql_query("UPDATE $article_file SET ArtComment = $nw_ttlcmt, ArtDate = ArtDate WHERE ArtID = '$ArtID'", $db);
				CreateLComments();
				echo "Done!";
				echo "<p><a href=\"$PHP_SELF?act=vicmt&ArtID=$ArtID\">Continue</a><br>";

			}

		}elseif($act=="add"){

			if(!isset($tion)){
				$get_cats=mysql_query("select * from $article_catfile order by ArtDesc asc",$db);
				$catoption="<select name=\"selectcat\">";
				while($get_rows=mysql_fetch_array($get_cats)){
					if(isset($ArtCat) && ($get_rows[ArtCat]==$ArtCat)){
						$catoption.="<option value=\"$get_rows[ArtCat]\" selected>$get_rows[ArtDesc]</option>";
					}else{
						$catoption.="<option value=\"$get_rows[ArtCat]\">$get_rows[ArtDesc]</option>";
					}
				}
				$catoption.="</select>";
$addform=<<<EOF
				<h2>Add News/Article</h2>
				<form action="$PHP_SELF?act=add&tion=prv" method="post">
					<table cellpadding=3 cellspacing=0 border=0>
					<tr><td align="right" width="20%">Category:</td><td width="80%">$catoption</td></tr>
					<tr><td align="right">Title:</td><td><input type=text name="NewsTitle" size="$sizetarea" maxlength="100" value="Type News Title here..."></td></tr>
					<tr><td align="right">Lead:</td><td><input type=text name="NewsLead" size="$sizetarea" maxlength="255" value="Type News Lead here..."></td></tr>
					<tr><td align="right">Message:</td><td><textarea name="NewsMsg" rows="10" cols="$sizetarea">Html tags are allowed!\nUse&lt;P&gt; for every paragraph</textarea></td></tr>
					<tr><td colspan="2"><input type="submit" value="Preview"></td></tr>
					</table>
				</form>
EOF;
				echo $addform;
				echo "<a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"Return\"></a>";
			}else{
				if($tion=="prv"){
					$get_cats=mysql_query("select * from $article_catfile where ArtCat='$selectcat' limit 0,1",$db);
					while($get_rows=mysql_fetch_array($get_cats)){
						$Category=$get_rows[ArtDesc];
					}
					$NewsTitle=FixQuotes($NewsTitle);
					$NewsLead=FixQuotes($NewsLead);
					$NewsMsg=FixQuotes($NewsMsg);
$preview=<<<EOF
					<h2>Preview News</h2>
					<table border=1 width=100%>
					<tr><td align="right" width="20%"><b>Category:</b></td><td width="80%">$Category</td></tr>
					<tr><td align="right" valign="top"><b>Title:</b></td><td>$NewsTitle</td></tr>
					<tr><td align="right" valign="top"><b>Lead:</b></td><td>$NewsLead</td></tr>
					<tr><td align="right" valign="top"><b>Message:</b></td><td>$NewsMsg</td></tr>
					</table>
					<table border=0>
					<tr><td><form action="$PHP_SELF?act=add&tion=save" method="post">
					<input type="hidden" name="ArtCat" value="$selectcat">
					<input type="hidden" name="NewsTitle" value="$NewsTitle">
					<input type="hidden" name="NewsLead" value="$NewsLead">
					<input type="hidden" name="NewsMsg" value="$NewsMsg">
					<input type="submit" value="Save">
					</form></td></tr>
					</table>
EOF;
					echo $preview;
					echo "<a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"Return\"></a>";
				}elseif($tion=="save"){
					$offset_time=offset_time();
					$query="insert into $article_file (ArtCat,ArtDate,ArtTitle,ArtLead,ArtMsg) values ('$ArtCat','$offset_time','$NewsTitle','$NewsLead','$NewsMsg')";
					$insert=mysql_query($query,$db);
					echo "Done!";
					echo "<p><a href=\"$PHP_SELF?act=add\">Add More News/Article</a><br><a href=\"$PHP_SELF?act=crt\">Create Last News Box</a>";
				}
			}

		}elseif($act == "vi"){

			if(!isset($pos)){ $pos = 0; }
			$temp_pos = $pos;
			$nw_where = "";
			if(!empty($ArtCat)){
				$nw_where = "$article_file.ArtCat = '$ArtCat'";
			}
			if(!empty($nw_search)){
				$nw_where = "ArtTitle LIKE '%$nw_search%' OR ArtLead LIKE '%$nw_search%' OR ArtMsg LIKE '%$nw_search%'";
			}
			if($wc){
				$nw_where = "ArtComment > 0";
			}
			if($nw_where != ""){
				$get_search = mysql_query("SELECT COUNT(ArtID) AS Total FROM $article_file WHERE $nw_where", $db);
			}else{
				$get_search = mysql_query("SELECT COUNT(ArtID) AS Total FROM $article_file", $db);
			}
			$nw_count = mysql_fetch_array($get_search);
			$nw_numrec = $nw_count[Total];
			$nw_numpage = intval($nw_numrec / $step);
			if($nw_numrec % $step){
				$nw_numpage++;
			}
			if($nw_where != ""){
				$get_news = mysql_query("SELECT * FROM $article_file LEFT JOIN $article_catfile ON $article_file.ArtCat=$article_catfile.ArtCat WHERE $nw_where ORDER BY $article_file.ArtDate DESC LIMIT $pos,$step", $db);
			}else{
				$get_news = mysql_query("SELECT * FROM $article_file LEFT JOIN $article_catfile ON $article_file.ArtCat=$article_catfile.ArtCat ORDER BY $article_file.ArtDate DESC LIMIT $pos,$step", $db);
			}
			if(mysql_num_rows($get_news) == "0"){
				echo "No Article!";
				echo "<p><a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"$tback\"></a>";
			}else{
				echo "<h2>View News/Article</h2>";
				echo "<table width=100% border=0 cellspacing=1 cellpadding=3>";
				echo "<tr><td align=center width=5% bgcolor=$toprowcol class=JudulPutih><b>ID</b></td><td align=center width=15% bgcolor=$toprowcol class=JudulPutih><b>Time Stamp</b></td><td align=center width=15% bgcolor=$toprowcol class=JudulPutih><b>Category</b></td><td align=center width=45% bgcolor=$toprowcol class=JudulPutih><b>Title</b></td><td align=center width=20% bgcolor=$toprowcol class=JudulPutih><b>Action</b></td></tr>\n";
				$i=0;
				while($get_rows = mysql_fetch_array($get_news)){
					$i++;
					if(($i % 2) == 1){
						$nw_bgcolor = $botrowcol;
					}else{
						$nw_bgcolor = $bgcol;
					}
					echo "<tr><td align=center valign=top bgcolor=$nw_bgcolor>$get_rows[ArtID]</td><td align=center valign=top bgcolor=$nw_bgcolor>$get_rows[ArtDate]</td><td valign=top bgcolor=$nw_bgcolor>$get_rows[ArtDesc]</td><td valign=top bgcolor=$nw_bgcolor>$get_rows[ArtTitle]</td>";
					echo "<td valign=top bgcolor=$nw_bgcolor><a href=\"$PHP_SELF?act=add&ArtCat=$get_rows[ArtCat]\"><img src=\"../images/icons/add.gif\" border=\"0\" align=\"absmiddle\" alt=\"Add News/Article\"></a>&nbsp;&nbsp;&nbsp;<a href=\"$PHP_SELF?act=detail&ArtID=$get_rows[ArtID]&ArtCat=$get_rows[ArtCat]\"><img src=\"../images/icons/view.gif\" border=\"0\" align=\"absmiddle\" alt=\"View Detail\"></a>&nbsp;&nbsp;&nbsp;";
					echo "<a href=\"$PHP_SELF?act=del&ArtID=$get_rows[ArtID]\"><img src=\"../images/icons/delete.gif\" border=\"0\" align=\"absmiddle\" alt=\"Delete News/Article\"></a>&nbsp;&nbsp;&nbsp;<a href=\"$PHP_SELF?act=mod&ArtID=$get_rows[ArtID]&ArtCat=$get_rows[ArtCat]\"><img src=\"../images/icons/modify.gif\" border=\"0\" align=\"absmiddle\" alt=\"Edit News/Article\"></a>&nbsp;&nbsp;&nbsp;";
					echo "<a href=\"$PHP_SELF?act=vicmt&ArtID=$get_rows[ArtID]\"><img src=\"../images/icons/comments.gif\" border=\"0\" align=\"absmiddle\" alt=\"View Comments\"></a> <span class=\"lead\">($get_rows[ArtComment])</span></td></tr>";
				}
				echo "<tr><td bgcolor=$toprowcol>&nbsp;</td><td bgcolor=$toprowcol>&nbsp;</td><td bgcolor=$toprowcol>&nbsp;</td><td bgcolor=$toprowcol>&nbsp;</td><td bgcolor=$toprowcol>&nbsp;</td></tr></table>";
			}
			if($nw_numpage > 1){
				if(isset($ArtCat)){
					$nw_action = "$PHP_SELF?act=vi&ArtCat=$ArtCat";
				}elseif(isset($nw_search)){
					$nw_action = "$PHP_SELF?act=vi&nw_search=$nw_search";
				}elseif(isset($wc)){
					$nw_action = "$PHP_SELF?act=vi&wc=1";
				}else{
					$nw_action = "$PHP_SELF?act=vi";
				}
				$numrec = $nw_numrec;
				pagespan($nw_action, "article");
			}

		}elseif($act == "detail"){

			/* Check article first */
			$get_news = mysql_query("SELECT * FROM $article_file LEFT JOIN $article_catfile ON $article_file.ArtCat = $article_catfile.ArtCat WHERE $article_file.ArtID = '$ArtID' LIMIT 0,1", $db);
			if(mysql_num_rows($get_news) == "0"){
				echo "No Article!";
				echo "<p><a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"$tback\"></a>";
			}else{
				echo "<h2>View Detail News/Article</h2>";
				$get_row = mysql_fetch_array($get_news);
				$nw_ptime = pretty_time($get_row[ArtDate],1);
				if($get_row[ArtRate] > 0){
					$nw_rate = number_format($get_row[ArtRate]/$get_row[ArtTRate],2);
				}else{
					$nw_rate = 0;
				}
$nw_shdetail = <<<EOF
				<p><span class="date">$nw_ptime</span><br>
				<span class="bigtitle"><font color="$linkcol">$get_row[ArtTitle]</font></span>&nbsp;&nbsp;&nbsp;(Rate: $nw_rate / $get_row[ArtTRate] votes)<br>
				<i>$get_row[ArtLead]</i>
				<p>$get_row[ArtMsg]
				<p><a href="javascript:history.go(-1)"><img src="../images/icons/return.gif" border="0" align="absmiddle" alt="Return"></a>
				&nbsp;&nbsp;&nbsp;<a href="$PHP_SELF?act=add&ArtCat=$get_row[ArtCat]"><img src="../images/icons/add.gif" border="0" align="absmiddle" alt="Add News/Article"></a>
				&nbsp;&nbsp;&nbsp;<a href="$PHP_SELF?act=del&ArtID=$ArtID"><img src="../images/icons/delete.gif" border="0" align="absmiddle" alt="Delete News/Article"></a>
				&nbsp;&nbsp;&nbsp;<a href="$PHP_SELF?act=mod&ArtID=$ArtID&ArtCat=$ArtCat"><img src="../images/icons/modify.gif" border="0" align="absmiddle" alt="Edit News/Article"></a>
				&nbsp;&nbsp;&nbsp;<a href="$PHP_SELF?act=vicmt&ArtID=$ArtID"><img src="../images/icons/comments.gif" border="0" align="absmiddle" alt="View Comments"></a> <span class="lead">($get_row[ArtComment])</span>
				&nbsp;&nbsp;&nbsp;<a href="$PHP_SELF?act=vi&ArtCat=$get_row[ArtCat]"><img src="../images/icons/viewcat.gif" border="0" align="absmiddle" alt="View Category: $get_row[ArtDesc]"></a>
EOF;
				echo $nw_shdetail;
			}

		}elseif($act=="del"){

			echo "<h2>Delete News/Article</h2>";
			if(!isset($tion)){
				$get_news=mysql_query("select * from $article_file where ArtID='$ArtID'",$db);
				$get_rows=mysql_fetch_array($get_news);
				$pretty_time=pretty_time($get_rows[ArtDate],1);
$delform=<<<EOF
				<p><span class="date">$pretty_time</span><br>
				<b>$get_rows[ArtTitle]<br></b>
				<i>$get_rows[ArtLead]</i>
				<p>$get_rows[ArtMsg]</p>
				<form action="$PHP_SELF?act=del&tion=ok" method="post">
				Are u sure want to delete this news/article? <input type=hidden name=ArtID value=$ArtID>
				<input type=submit value=Delete>
				</form>
				<a href='javascript:history.go(-1)'><img src="../images/icons/return.gif" border="0" align="absmiddle" alt="Return"></a>
EOF;
				echo $delform;
			}else{
				$delete=mysql_query("delete from $article_file where ArtID='$ArtID'",$db);
				$delete = mysql_query("delete from $cmt_file where CmArtID = '$ArtID'", $db);
				CreateLComments();
				echo "Done!";
				echo "<p><a href=\"$PHP_SELF?act=vi\">Continue</a><br>";
			}

		}elseif($act=="mod"){

			if(!isset($tion)){
				$get_cats=mysql_query("select * from $article_catfile order by ArtDesc asc",$db);
				$catoption="<select name=\"selectcat\">";
				while($get_rows=mysql_fetch_array($get_cats)){
					if(isset($ArtCat) && ($get_rows[ArtCat]==$ArtCat)){
						$catoption.="<option value=\"$get_rows[ArtCat]\" selected>$get_rows[ArtDesc]</option>";
					}else{
						$catoption.="<option value=\"$get_rows[ArtCat]\">$get_rows[ArtDesc]</option>";
					}
				}
				$catoption.="</select>";
				$get_news=mysql_query("select * from $article_file where ArtID='$ArtID'",$db);
				$get_rows=mysql_fetch_array($get_news);
$modifyform=<<<EOF
				<h2>Modify News/Article</h2>
				<form action="$PHP_SELF?act=mod&tion=ok" method="post">
					<table cellpadding=3 cellspacing=0 border=0>
					<tr><td align="right" width="20%">Category:</td><td width="80%">$catoption</td></tr>
					<tr><td align="right">Title:</td><td><input type=text name="NewsTitle" size="$sizetarea" maxlength="100" value="$get_rows[ArtTitle]"></td></tr>
					<tr><td align="right">Lead:</td><td><input type=text name="NewsLead" size="$sizetarea" maxlength="255" value="$get_rows[ArtLead]"></td></tr>
					<tr><td align="right">Message:</td><td><textarea name="NewsMsg" rows="10" cols="$sizetarea">$get_rows[ArtMsg]</textarea></td></tr>
					<tr><td colspan="2"><input type="hidden" name="ArtID" value="$ArtID"><input type="hidden" name="ArtDate" value="$get_rows[ArtDate]"><input type="submit" value="Save"></td></tr>
					</table>
				</form>
EOF;
				echo $modifyform;
				echo "<a href='javascript:history.go(-1)'><img src=\"../images/icons/return.gif\" border=\"0\" align=\"absmiddle\" alt=\"Return\"></a>";
			}else{
				$NewsTitle=FixQuotes($NewsTitle);
				$NewsLead=FixQuotes($NewsLead);
				$NewsMsg=FixQuotes($NewsMsg);
				$update=mysql_query("update $article_file set ArtCat='$selectcat',ArtDate='$ArtDate',ArtTitle='$NewsTitle',ArtLead='$NewsLead',ArtMsg='$NewsMsg' where ArtID='$ArtID'",$db);
				echo "Done!";
				echo "<p><a href=\"$PHP_SELF?act=vi\">Continue</a><br><a href=\"$PHP_SELF?act=crt\">Create Last News Box</a>";
			}

		}elseif($act == "crtall"){

			$get_cats=mysql_query("select * from $article_catfile order by ArtDesc asc",$db);
			while($get_rows=mysql_fetch_array($get_cats)){
				if($get_rows[ArtList]==1){
					$get_news=mysql_query("select * from $article_file where ArtCat='$get_rows[ArtCat]' order by ArtDate desc limit 0,$get_rows[ArtLimit]",$db);
					while($get_rowsnews=mysql_fetch_array($get_news)){
						$icon[]="images/icons/$get_rows[ArtIcon]";
						$warta[]=$get_rowsnews[ArtTitle];
						$link[]="$base_url/wmview.php?ArtID=$get_rowsnews[ArtID]";
						$linkcat[]="$base_url/wmview.php?ArtCat=$get_rows[ArtCat]";
						$linkcatdesc[]=$get_rows[ArtDesc];
					}
				}
			}
			$contents="<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tr><td width=\"100%\" bgcolor=\"<? echo \$toprowcol;?>\">\n";
			$contents.="<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\"><tr><td valign=\"top\" colspan=\"2\" bgcolor=\"<? echo \$toprowcol;?>\" class=\"judulputih\"><img src=\"images/icons/note.gif\" border=\"0\" align=\"absmiddle\">&nbsp;$tboxlastnews</td></tr>\n";
			$banyak=count($icon);
			$i=1;
			$mlistcontents="$tboxlastnews $site_title:\n\n";
			while($i<=$banyak){
				$iconnya=$icon[$i-1];
				$wartanya=$warta[$i-1];
				$linknya=$link[$i-1];
				$linkcatnya=$linkcat[$i-1];
				$linkcatdescnya=$linkcatdesc[$i-1];
				if(($i%2)==1){
					$bgcolor="$grey";
				}else{
					$bgcolor="$bgcol";
				}
				$mlistcontents.="$linkcatdescnya: $wartanya\n$linknya\n\n";
				$contents.="<tr><td class=\"lead\" align=\"right\" valign=\"top\" width=\"99%\" bgcolor=\"$bgcolor\"><a href=\"$linknya\">$wartanya</a></td><td width=\"1%\" bgcolor=\"$bgcolor\"><a href=\"$linkcatnya\"><img src=\"$iconnya\" border=\"0\" align=\"absmiddle\" alt=\"$linkcatdescnya\"></a></td></tr>\n";
				$i++;
			}
			$contents.="</td></tr></table></td></tr></table>";
			$fn="Warta_Terakhir.wmn";
			$fo=fopen("$base_datapath/$fn","w");
			$fw=fwrite($fo,$contents);
			$fc=fclose($fo);
			echo "&nbsp;&nbsp;&nbsp;Created $fn...Done!<br>\n";
			$fn="Warta_Terakhir_Milis.wmn";
			$fo=fopen("$base_datapath/$fn","w");
			$fw=fwrite($fo,$mlistcontents);
			$fc=fclose($fo);
			echo "&nbsp;&nbsp;&nbsp;Created $fn...Done!<br>\n";

		}elseif($act=="crt"){

			$get_cats=mysql_query("select * from $article_catfile order by ArtDesc asc",$db);
			while($get_rows=mysql_fetch_array($get_cats)){
				$get_news=mysql_query("select * from $article_file where ArtCat='$get_rows[ArtCat]' order by ArtDate desc limit 0,$get_rows[ArtLimit]",$db);
				if(mysql_num_rows($get_news)=="0"){
					echo "No News/Article for $get_rows[ArtDesc]<br>\n";
				}else{
					if($get_rows[ArtDisplay]==1){		// Side Box Style
$contents=<<<EOF
						<table width="100%" cellpadding="1" cellspacing="0" border="0">
							<tr>
								<td width="100%" bgcolor="<? echo \$toprowcol;?>">
									<table width="100%" border="0" cellspacing="0" cellpadding="3">
										<tr>
											<td width="100%" bgcolor="<? echo \$toprowcol;?>" colspan="2" class=JudulPutih>
												<img src="images/icons/$get_rows[ArtIcon]" border="0" align="absmiddle">&nbsp;$get_rows[ArtDesc]
											</td>
										</tr>
EOF;
					}else{
$contents=<<<EOF
						<table width="100%" cellpadding="1" cellspacing="0" border="0">
							<tr>
								<td width="100%" bgcolor="<? echo \$bgcol;?>">
									<table width="100%" border="0" cellspacing="0" cellpadding="3">
										<tr>
											<td width="100%" bgcolor="<? echo \$botrowcol;?>" colspan="2" class="judul">
												<img src="images/icons/$get_rows[ArtIcon]" border="0" align="absmiddle"><font color="<? echo \$toprowcol;?>">&nbsp;$get_rows[ArtDesc]</font>
											</td>
										</tr>
EOF;
					}
					while($get_rowsnews=mysql_fetch_array($get_news)){
						$pretty_time=pretty_time($get_rowsnews[ArtDate],1);
						$ArtID=$get_rowsnews[ArtID];
						$ArtCat=$get_rowsnews[ArtCat];
						$NewsLead=trim($get_rowsnews[ArtLead]);
						
						if(strlen($NewsLead)==0){
							$NewsLead="<br>";
							$chr=$dispchr;
						}else{
							$NewsLead="<br><span class=\"lead\">$NewsLead</span><br>";
							$chr=$dispchr-strlen($NewsLead);
						}

						if($dispchr == 0){
							$SomeNewsMsg = "";
						}else{
							$SomeNewsMsg=preg_replace("/<[a-zA-Z]+>|<[\/a-zA-Z]+>/","",$get_rowsnews[ArtMsg]);
							$SomeNewsMsg=substr($SomeNewsMsg,0,$chr);
							$LastString=substr($SomeNewsMsg,$chr-1,1);
							if($LastString<>" "){
								$SomeNewsMsg=substr($SomeNewsMsg,0,strrpos($SomeNewsMsg," "))."...<br>";
							}else{
								$SomeNewsMsg=substr($SomeNewsMsg,0,$chr-1)."...<br>";
							}
						}

						if($get_rows[ArtDisplay]==1){
$contents.=<<<EOF
										<tr>
											<td width="1%" valign="top" align="center" bgcolor="<? echo \$bgcol;?>">&#149;</td>
											<td width="99%" bgcolor="<? echo \$bgcol;?>"><span class="title"><a href="$base_url/wmview.php?ArtID=$ArtID">$get_rowsnews[ArtTitle]</a></span>$NewsLead$SomeNewsMsg<span class="date">$pretty_time</span></td>
										</tr>
EOF;
						}else{
$contents.=<<<EOF
										<tr>
											<td width="1%" valign="top" align="center" bgcolor="<? echo \$bgcol;?>">&#149;</td>
											<td width="99%" bgcolor="<? echo \$bgcol;?>"><span class="title"><a href="$base_url/wmview.php?ArtID=$ArtID">$get_rowsnews[ArtTitle]</a></span>$NewsLead$SomeNewsMsg<span class="date">$pretty_time</span></td>
										</tr>
EOF;
						}
					}
					if($get_rows[ArtDisplay]==1){		// Side Box Style
$contents.=<<<EOF
										<tr>
											<td align="right" bgcolor="<? echo \$bgcol;?>" colspan="2"><a href="$base_url/wmview.php?ArtCat=$ArtCat">$tarchive...</a>&nbsp;<img src="images/icons/archives.gif" border="0" align="absmiddle"></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
EOF;
					}else{
$contents.=<<<EOF
										<tr>
											<td align="right" bgcolor="<? echo \$bgcol;?>" colspan="2"><a href="$base_url/wmview.php?ArtCat=$ArtCat">$tarchive...</a>&nbsp;<img src="images/icons/archives.gif" border="0" align="absmiddle"></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
EOF;
					}
					$fn=trim($get_rows[ArtDesc]);
					$fn=eregi_replace(" ","_",$fn).".wmn";
					$fo=fopen("$base_datapath/$fn","w");
					$fw=fwrite($fo,$contents);
					$fc=fclose($fo);
					echo "&nbsp;&nbsp;&nbsp;Created $fn...Done!<br>\n";
				}
			}
		}
	}
	?>
	<p align="center"><span class="lead">Managed by <a href="http://wartamikael.org/PHPScripts/?product=WMNews" target="_blank">WMNews</a>, <a href="http://www.php.net" target="_blank">PHP</a> & <a href="http://www.mysql.com\" target="_blank">MySQL</a></span>
	</body>
</html>
