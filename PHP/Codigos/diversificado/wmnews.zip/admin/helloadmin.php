<?
/* ===================================================================================
 * Copyright (c) 2001 Rudy S. Ingga (toekangweb@wartamikael.org). All rights reserved.
 *
 * helloadmin.php
 *   Just want to say "Hello" to admin :P
 * ===================================================================================
 */

?>

<html>
	<head>
		<base target="main">
	</head>
	<body topmargin="10" leftmargin="0" marginheight="10" marginwidth="0" bgcolor="#FFFFFF" link="#0000FF" vlink="#0000FF" alink="#0000FF">
		<table border="0" width="100%" cellpadding="5" cellspacing="0">
			<tr>
				<td width="100%" ><font face="Verdana" size="2"> 
					Hello Admin, please choose your action on left side!
				</font></td>
			</tr>
		</table>
	</body>
</html>
