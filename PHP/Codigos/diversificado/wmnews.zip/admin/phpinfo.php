<?
/* =======================================================
 * phpinfo.php
 *   Display PHP Information on the server using phpinfo()
 * =======================================================
 */
?>

<html>
	<head>
		<base target="main">
	</head>
	<body topmargin="10" leftmargin="0" marginheight="10" marginwidth="0" bgcolor="#FFFFFF" link="#0000FF" vlink="#0000FF" alink="#0000FF">
		<table border="0" width="100%" cellpadding="5" cellspacing="0">
			<tr>
				<td width="100%" ><font face="Verdana" size="2"> 
					<?
					$phpinfo=phpinfo();
					echo $phpinfo;
					?>
				</font></td>
			</tr>
		</table>
	</body>
</html>
