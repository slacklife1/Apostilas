<html>
<head>
<title><? echo $site_title;?></title>
<link rel="stylesheet" href="wm.css">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
</head>
<body topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" bgcolor="<? echo $bgcol;?>" text="<? echo $textcol;?>" link="<? echo $linkcol;?>" vlink="<? echo $vlinkcol;?>" alink="<? echo $alinkcol;?>">
<a name="Atas"></a>
<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="<? echo $toprowcol;?>">
  <tr>
    <td>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td rowspan="2" valign="top" class="judulputih">&nbsp;&nbsp;&nbsp;WMNews ver 0.2<br>&nbsp;&nbsp;&nbsp;<span class="title">Another news automation system for your page</span></td>
          <td align="right">
            <table width="100%" border="0" cellspacing="0" cellpadding="2">
              <tr>
                <td align="right" valign="top"><? include("sbox.php");?></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td align="right" valign="bottom" class="date">
            <? echo pretty_date();?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br>
