<?
/* ===================================================================================
 * Copyright (c) 2001 Rudy S. Ingga (toekangweb@wartamikael.org). All rights reserved.
 *
 * sbox.php
 *   Sample search box for your site
 * 
 * Wednesday, March 14, 2001 08:54:56 PM
 * ===================================================================================
 */

$agent=$HTTP_USER_AGENT;
$agent=strpos($agent, "MSIE");
if($agent){
	$size=20;
}else{
	$size=12;
}

?>

<table cellpadding="0" cellspacing="3" border="0" background="images/shim.gif">
	<tr>
		<form method=post action="<? echo $base_url;?>/search.php">
			<td align="right" valign="middle">
				<input type="text" name="term" value="<? echo $term;?>" size="<? echo $size;?>" maxlength="50">
				&nbsp;<input type="image" src="images/search.gif" border="0" align="absmiddle"><br><a class="putih" href="<? echo "$base_url/search.php";?>">Advanced Search</a>
			</td>
		</form>
	</tr>
</table>