<?
/* ===================================================================================
 * Copyright (c) 2001 Rudy S. Ingga (toekangweb@wartamikael.org). All rights reserved.
 *
 * This module is released under the GNU General Public License.
 * 	See: http://www.gnu.org/copyleft/gpl.html
 * 
 * wmcomments.php
 * 	Part of WMNews,
 *	Full threaded comment system.
 *	Last Updated: Wednesday, 16 May, 2001 12:11:58 PM
 * 
 * WMNews Version 0.2
 * 	Another PHP & MySQL driven News Publishing system.
 *
 * For latest version and example, visit:
 * 	http://wartamikael.org/PHPScripts/WMNews
 * ====================================================================================
 */

$article_catfile	= "ArticleCat";
$article_file	= "Article";
$cmt_file		= "ArtComments";

if(!isset($config)){ include("config/config.php"); }
if(!isset($wmlib)){ include("wmlib.php"); }

/* Do not use comment system, redirecting user to the homepage */
if(!$t_cmt_use){ header("Location: $base_url"); }

function GetComments($CmID=0){
	global $db, $ArtID, $cmt_file, $pos, $step;
	if(!$CmID){
		$CmID = 0;
	}
	$get_comments = mysql_query("SELECT * FROM $cmt_file WHERE CmArtID = '$ArtID' AND CmPID = '$CmID' ORDER BY CmDate ASC LIMIT $pos, $step", $db);
	$comment_counter = mysql_num_rows($get_comments);
	if($comment_counter > 0){
		$return_msg .= "<ul>\n";
	}else{
		return false;
	}
	for($i = 0; $i < $comment_counter; $i++){
		$get_rows = mysql_fetch_array($get_comments);
		$return_msg .= ShowLink($get_rows[CmID],$get_rows[CmSubject],$get_rows[CmName],$get_rows[CmEmail],$get_rows[CmDate]);
		$return_msg .= GetSubComments($get_rows[CmID]);
	}
	$return_msg .= "</ul>\n";
	return $return_msg;
}

function GetSubComments($ParentID){
	global $db, $cmt_file, $ArtID, $depth, $max_indent;
	$get_subcomments = mysql_query("SELECT * FROM $cmt_file WHERE CmArtID = '$ArtID' AND CmPID = '$ParentID' ORDER BY CmDate ASC", $db);
	$subcomment_counter = mysql_num_rows($get_subcomments);
	if($subcomment_counter > 0){
		if($depth < $max_indent){
			$return_msg .= "<ul>\n";
		}
		for($i = 0; $i < $subcomment_counter; $i++){
			$get_rows = mysql_fetch_array($get_subcomments);
			$return_msg .= ShowLink($get_rows[CmID],$get_rows[CmSubject],$get_rows[CmName],$get_rows[CmEmail],$get_rows[CmDate]);
			$depth++;
			$return_msg .= GetSubComments($get_rows[CmID]);
			$depth--;
		}
		if($depth < $max_indent){
			$return_msg .= "</ul>\n";
		}
		return $return_msg;
	}else{
		return false;
	}
}

function GetCommentHead($ID){
	global $db, $cmt_file, $comment_re, $page_title, $ArtID;
	$get_comment = mysql_query("SELECT * FROM $cmt_file WHERE CmID = '$ID' AND CmArtID = '$ArtID' LIMIT 0,1",$db);
	if(mysql_num_rows($get_comment) > 0){
		$get_row = mysql_fetch_array($get_comment);
		$CmPID = $get_row[CmPID];
		$CmSubject = $get_row[CmSubject];
		$page_title = $CmSubject;
		$comment_re = "Re: " . $CmSubject;
		$CmName = $get_row[CmName];
		$CmEmail = $get_row[CmEmail];
		$CmContent = nl2br($get_row[CmContent]);
		$CmDate = $get_row[CmDate];
		$CmContent2 = nl2br($get_row[CmContent2]);
		$CmDate2 = $get_row[CmDate2];
		$return_msg .= ShowComment($ID,$CmPID,$CmSubject,$CmName,$CmEmail,$CmContent,$CmDate,$CmContent2,$CmDate2);
		return $return_msg;
	}else{
		return false;
	}
}

function ShowLink($CmID,$CmSubject,$CmName,$CmEmail,$CmDate){
	global $PHP_SELF, $ArtID;
	$pretty_time = pretty_time($CmDate,1);
	if($CmEmail != ""){
		$email_name = "<a href=\"mailto:$CmEmail\">$CmName</a>";
	}else{
		$email_name = $CmName;
	}
	$return_msg .= "\n<li><a href=\"$PHP_SELF?act=vi&CmID=$CmID&ArtID=$ArtID\">$CmSubject</a> - $email_name - <span class=\"date\">$pretty_time</span>";
	return $return_msg;
}

function ShowComment($CmID,$CmPID,$CmSubject,$CmName,$CmEmail,$CmContent,$CmDate,$CmContent2,$CmDate2){
	global $PHP_SELF, $ArtID, $grey, $act, $t_cmt_adm;
	$pretty_time = pretty_time($CmDate,1);
	if($CmEmail != ""){
		$email_name = "<a href=\"mailto:$CmEmail\">$CmName</a>";
	}else{
		$email_name = $CmName;
	}
	$nw_comment2 = "";
	if($CmContent2 != "" && $CmDate2 != "00000000000000"){
		$nw_comment2 .= "<p><blockquote><span class=\"title\">$t_cmt_adm</span> - <span class=\"date\">" . pretty_time($CmDate2,1) . "</span>";
		$nw_comment2 .= "<br>" . nl2br($CmContent2) . "</blockquote>";
	}
	$return_msg .= "<br>&nbsp;</td></tr>\n<tr><td bgcolor=\"$grey\">$email_name - <span class=\"date\">$pretty_time</span></td></tr>";
	$return_msg .= "\n<tr><td bgcolor=\"$grey\"><span class=\"title\">$CmSubject</span><br>$CmContent $nw_comment2</td></tr>";
	//if($act == "vi"){
		$nav = ShowNav($CmID, $CmPID);
		$return_msg .= "\n<tr><td bgcolor=\"$grey\">$nav</td></tr>";
	//}
	$return_msg .= "\n<tr><td>";
	return $return_msg;
}

function ShowNav($CmID,$CmPID){
	global $PHP_SELF, $ArtID, $t_cmt_add, $t_cmt_top, $t_cmt_prn, $tback;
	$nav_repl = "<a href=\"$PHP_SELF?act=add&CmPID=$CmID&ArtID=$ArtID\"><img src=\"images/cmt_reply.gif\" border=\"0\" alt=\"$t_cmt_add\"></a>";
	$nav_top = "<a href=\"$PHP_SELF?ArtID=$ArtID\"><img src=\"images/cmt_topthr.gif\" border=\"0\" alt=\"$t_cmt_top\"></a>";
	$nav_retr = "<a href=\"javascript:history.go(-1)\"><img src=\"images/cmt_return.gif\" border=\"0\" alt=\"$tback\"></a>";
	if($CmPID == "0"){
		$nav_prnt = "<a href=\"$PHP_SELF?ArtID=$ArtID\"><img src=\"images/cmt_parent.gif\" border=\"0\" alt=\"$t_cmt_prn\"></a>";
	}else{
		$nav_prnt = "<a href=\"$PHP_SELF?act=vi&CmID=$CmPID&ArtID=$ArtID\"><img src=\"images/cmt_parent.gif\" border=\"0\" alt=\"$t_cmt_prn\"></a>";
	}
	return $nav_repl . "&nbsp;" . $nav_top . "&nbsp;" . $nav_prnt . "&nbsp;" .$nav_retr;
}

function ShowAddLink(){
	global $PHP_SELF, $t_cmt_add, $ArtID, $act, $tback, $CmPID, $t_cmt_top;
	$return_msg .= "\n<p><a href=\"$PHP_SELF?act=add&ArtID=$ArtID&CmPID=0\"><img src=\"images/cmt_newtopic.gif\" border=\"0\" alt=\"$t_cmt_add\"></a>";
	if($act == "add" && $CmPID == "0"){
		$return_msg .= "&nbsp;<a href=\"$PHP_SELF?ArtID=$ArtID\"><img src=\"images/cmt_topthr.gif\" border=\"0\" alt=\"$t_cmt_top\"></a>&nbsp;<a href=\"javascript:history.go(-1)\"><img src=\"images/cmt_return.gif\" border=\"0\" alt=\"$tback\"></a>";
	}
	return $return_msg;
}

function AddCommentCounter(){
	global $db, $article_file, $ArtID;
	$get_news = mysql_query("SELECT * FROM $article_file WHERE ArtID = '$ArtID' LIMIT 0,1", $db);
	while($get_row = mysql_fetch_array($get_news)){
		$ArtDate = $get_row[ArtDate];
	}
	$update = mysql_query("UPDATE $article_file SET ArtDate = '$ArtDate', ArtComment = ArtComment + 1 WHERE ArtID = '$ArtID'", $db);
}

$depth = 0;
$max_indent = 5;

$swear = array("isep","bau tai","kudis","anjing ","kurap","nonok","berak","mencret","entot","ngewe","kontol","titit","peler","jembut","memek","itil","taik","cibai","fuck","asshole","pekker","whore","bitch","shit","nigger","bigass","tits","cum ","cunt","clit");

$output = "";
$output .= box_open(2,"comments.gif",$t_cmt);

if(!isset($act)){
	if(!isset($ArtID)){
		$ArtID = GetLast();
	}
	if($ArtID){
		$headlines .= GetArticle($ArtID);
		if($headlines){
			$output .= $headlines;
			if(!isset($pos)){$pos = 0;}
			$temp_pos = $pos;
			$get_count = mysql_query("SELECT COUNT(CmID) AS Total FROM $cmt_file WHERE CmArtID = '$ArtID' AND CmPID = '0'",$db);
			$count_row = mysql_fetch_array($get_count);
			$numrec = $count_row[Total];
			$numpage = intval($numrec / $step);
			if($numrec % $step){ $numpage++; }
			$output .= ShowAddLink();
			$comment_top = GetComments();
			if($comment_top){
				$output .= $comment_top;
			}else{
				$output .= "\n<tr><td bgcolor=\"$bgcol\">$t_cmt_ept";
			}
		}else{
			$output .= "<tr><td bgcolor=\"$bgcol\" class=\"errmsg\">$tnonews #$ArtID";
		}
	}
}else{
	if($act == "vi"){
		if(!isset($ArtID)){
			$ArtID = GetLast();
		}
		if($ArtID){
			$headlines .= GetArticle($ArtID);
			if($headlines){
				$output .= $headlines;
				if(!isset($CmPID)){ $CmPID = 0; }
				$output .= ShowAddLink(0);
				$comment_head = GetCommentHead($CmID);
				if($comment_head){
					$output .= $comment_head;
					$output .= GetSubComments($CmID);
				}else{
					$output .= "<tr><td bgcolor=\"$bgcol\">$t_cmt_ept - #$CmID";
				}
			}else{
				$output .= "<tr><td bgcolor=\"$bgcol\" class=\"errmsg\">$tnonews #$ArtID";
			}
		}
	}elseif($act == "add"){
		if(!isset($tion)){
			if(!isset($ArtID)){
				$ArtID = GetLast();
			}
			if($ArtID){
				$headlines .= GetArticle($ArtID);
				if($headlines){
					$output .= $headlines;
					$output .= ShowAddLink();
					$comment_re = "";
					$comment_head = GetCommentHead($CmPID);
					if($comment_head){
						$output .= $comment_head;
						$CmID = $CmPID;
					}
					$output .= "\n<tr><td>&nbsp;</td></tr>\n<tr><td bgcolor=$bgcol align=left>";
					if(checkIE() == "1"){
						$size = 35;
					}else{
						$size = 18;
					}
					$sizetarea = $size+round($size/2,0);
$cmt_form = <<<EOF
					<form action="$PHP_SELF?act=add&tion=prv" method="POST">
					<table width="100%" cellpadding="3" cellspacing="0" border="0">
						<tr><td align="right">*) $t_rf_yna:</td><td><input type="text" name="yname" size="$size" maxlength="50"></td></tr>
						<tr><td align="right"> $t_rf_yml:</td><td><input type="text" name="ymail" size="$size" maxlength="50"></td></tr>
						<tr><td align="right">*) $t_cmt_sbj:</td><td><input type="text" name="subject" size="$size" maxlength="100" value="$comment_re"></td></tr>
						<tr><td align="right">*) $t_cmt:<br><br>No html,<br>255 character max.</td><td><textarea name="comment" rows="5" cols="$sizetarea"></textarea></td></tr>
						<tr><td align="right" class="date">*) $t_gnr_mus</td><td><INPUT TYPE="image" src="images/cmt_preview.gif" border="0" align="absmiddle"></td></tr>
						<INPUT TYPE="hidden" NAME="ArtID" VALUE="$ArtID"><INPUT TYPE="hidden" NAME="CmPID" VALUE="$CmPID">
					</table>
					</form>
EOF;
					$output .= $cmt_form."</td></tr>\n<tr><td>";
					//$output .= GetSubComments($CmID);
				}
			}
		}elseif($tion == "prv"){
			$error = "";
			if(trim($yname) == ""){ $error .= "<li>$t_err_bnm"; }
			if(!empty($ymail)){
				if(!ereg("^([a-z0-9_]|\\-|\\.)+@(([a-z0-9_]|\\-)+\\.)+[a-z]{2,4}\$",$ymail)){
					$error .= "<li>$t_err_wym";
				}
			}
			if(trim($subject) == ""){ $error .= "<li>$t_err_eps"; }
			if(trim($comment) == ""){ $error .= "<li>$t_err_epc"; }
			if(strlen(trim($comment)) > 255){ $error.="<li>$t_err_tlc"; }
			if($error!=""){
$cmt_form_err = <<<EOF
				<tr><td bgcolor="$bgcol">
					<p><span class="errmsg">$t_err_inv:</span></p>
					<blockquote>$error</blockquote>
					<p><a href="javascript:history.go(-1)"><img src="images/cmt_return.gif" border="0" align="absmiddle" alt="$tback"></a>
				</td></tr>
EOF;
				$output .= $cmt_form_err;
			}else{
				foreach($swear as $badword => $filter){
					$yname = eregi_replace($filter,"*",$yname);
					$ymail = eregi_replace($filter,"*",$ymail);
					$subject = eregi_replace($filter,"*",$subject);
					$subject = FixQuotes($subject);
					$comment = eregi_replace($filter,"*",$comment);
				}
				$comment = preg_replace("/\S{50,}/","*",$comment);
				$comment = FixQuotes($comment);
				$comment_disp = nl2br($comment);
$cmt_form_prev = <<<EOF
				<tr><td bgcolor="$bgcol">
					<table width="100%" cellpadding="3" cellspacing="0" border="0">
						<tr><td class="title" align="right" width="30%">$t_rf_yna : </td><td>$yname</td></tr>
						<tr><td class="title" align="right">$t_rf_yml : </td><td>$ymail</td></tr>
						<tr><td class="title" align="right">$t_cmt_sbj : </td><td>$subject</td></tr>
						<tr><td class="title" align="right" valign="top">$t_cmt : </td><td>$comment_disp</td></tr>
						<tr><td class="title" align="right">IP Address : </td><td>$REMOTE_ADDR</td></tr>
						<tr><td colspan="2">&nbsp;</td></tr>
						<form action="$PHP_SELF?act=add&tion=ok" method="POST">
						<tr><td>&nbsp;</td><td>
						<INPUT TYPE="hidden" name="yname" value="$yname"><INPUT TYPE="hidden" name="ymail" value="$ymail">
						<INPUT TYPE="hidden" name="subject" value="$subject"><INPUT TYPE="hidden" name="comment" value="$comment">
						<INPUT TYPE="hidden" name="ArtID" value="$ArtID"><INPUT TYPE="hidden" name="CmPID" value="$CmPID">
						<INPUT TYPE="hidden" name="yip" value="$REMOTE_ADDR">
						<INPUT TYPE="image" src="images/cmt_send.gif" border="0" align="absmiddle">&nbsp;<a href="$PHP_SELF?ArtID=$ArtID"><img src="images/cmt_cancel.gif" border="0" align="absmiddle"></a>&nbsp;<a href="javascript:history.go(-1)"><img src="images/cmt_return.gif" border="0" align="absmiddle" alt="$tback"></a>
						</td></tr>
						</form>
					</table>
				</td></tr>
EOF;
				$output .= $cmt_form_prev;
			}
		}elseif($tion == "ok"){
			// Check for double entry first!
			$get_comment = mysql_query("SELECT 1 FROM $cmt_file WHERE (CmArtID='$ArtID' AND CmPID='$CmPID' AND CmName='$yname' AND CmEmail='$ymail' AND CmSubject='$subject' AND CmContent='$comment')",$db);
			if(mysql_num_rows($get_comment) == 1){
$cmt_form_exist = <<<EOF
				<tr><td bgcolor="$bgcol" align="center">
					$t_cmt_don
					<p><a href="javascript:history.go(-1)"><img src="images/cmt_return.gif" border="0" align="absmiddle" alt="$tback"></a>
				</td></tr>
EOF;
			}else{
				$offset_time = offset_time();
				$insert = mysql_query("INSERT INTO $cmt_file (CmArtID,CmPID,CmDate,CmIP,CmName,CmEmail,CmSubject,CmContent) VALUES ('$ArtID','$CmPID','$offset_time','$yip','$yname','$ymail','$subject','$comment')",$db);
				AddCommentCounter();
				CreateLComments();

				if($t_cmt_ctr){

					// I want to know people who write comment //

					$em_subj = "User Posting";
					$em_cont = "Hi " . $owner_email . "...,\n\n";
					$em_cont .= "$yname ( $ymail ) - ( $yip ) write a comment on $offset_time:\n\n";
					$em_cont .= "$subject\n";
					$em_cont .= "$comment\n\n";
					$em_cont .= "for article ID #$ArtID: $base_url/wmcomments.php?ArtID=$ArtID\n\n";
					$em_cont .= "$trregard\n";
					$em_cont .= "$site_title\n$owner_email\n\n";
					mail($owner_email,$em_subj,$em_cont,"From: $owner_email\nReply-To: $owner_email");

				}

				if($CmPID == "0"){
					$Location = "$PHP_SELF?ArtID=$ArtID";
				}else{
					$Location = "$PHP_SELF?act=vi&CmID=$CmPID&ArtID=$ArtID";
				}
				header("Location: $Location");
			}			
			$output .= $cmt_form_exist;
		}
	}
}

/* Print Out the whole thing we've got from above into browser */

flush();
include("header.php");
echo "<table border=\"0\" cellpadding=\"0\" cellspacing=\"1\" width=\"100%\"><tr><td width=\"20%\" valign=\"top\">";
include("leftcol.php");
echo "</td><td width=\"60%\" valign=\"top\"><table width=\"100%\" cellpadding=\"2\" cellspacing=\"0\" border=\"0\"><tr><td width=\"100%\">";
$output .= box_close("","","");
echo $output;
echo "</td></tr></table>";
if($numpage > 1){
	pagespan("$PHP_SELF?ArtID=$ArtID", $t_cmt_top, 0);
}
/* WARNING: Do not remove this line until you pay for comercial version (No WMNews link!) */
echo "<p align=center><span class=\"lead\">Managed by <a href=\"http://wartamikael.org/PHPScripts/?product=WMNews\" target=\"_blank\">WMNews</a>, <a href=\"http://www.php.net\" target=\"_blank\">PHP</a> & <a href=\"http://www.mysql.com\" target=\"_blank\">MySQL</a></span>";
echo "</td><td width=\"20%\" valign=\"top\">";
include("rightcol.php");
echo "</td></tr></table>";
include("footer.php");

?>