<?
/* =========================================================================
 * Copyright (c) 2001 Rudy S. Ingga (rudy@wita.or.id). All rights reserved.
 *
 * This module is released under the GNU General Public License. 
 * 	See: http://www.gnu.org/copyleft/gpl.html
 * 
 * search.php
 * 	Part of WMNews,
 *	Search news/by category.
 *	Last Updated: Wednesday, 16 May, 2001 12:11:58 PM
 * 
 * WMNews Version 0.2
 * 	Another PHP & MySQL driven News Publishing system.
 *
 * For latest version and example, visit:
 * 	http://wartamikael.org/PHPScripts/WMNews
 * =========================================================================
 */

$article_catfile="ArticleCat";
$article_file="Article";
if(!isset($config)){ include("config/config.php"); }
if(!isset($wmlib)){ include("wmlib.php"); }
$page_title = $t_src_jdl;
include("header.php");
?>

		<table border="0" cellpadding="0" cellspacing="1" width="100%">
			<tr>
				<td width="20%" valign="top">
					<? include("leftcol.php");?>
				</td>
				<td width="60%" valign="top">
					<table width="100%" cellpadding="2" cellspacing="0" border="0">
						<tr><td width="100%">

							<?

							if($term){

								if(!isset($pos)){$pos=0;}
								if(!isset($perpage)){$perpage=$step;}
								$temp_pos=$pos;
								$term=trim($term);
								$where="($article_file.ArtTitle like '%$term%' or $article_file.ArtLead like '%$term%' or $article_file.ArtMsg like '%$term%')";
								if($ArtCat){
									if($ArtCat>0){$where.=" and $article_file.ArtCat='$ArtCat'";}
								}
								$get_count=mysql_query("select count(ArtID) as Total from $article_file where $where",$db);
								$count_row=@mysql_fetch_array($get_count);
								$numrec=$count_row[Total];
								$numpage=intval($numrec/$perpage);

								if($numrec%$perpage){$numpage++;}

$output=<<<EOF
								<table width="100%" cellpadding="1" cellspacing="0" border="0">
									<tr><td width="100%" bgcolor="$bgcol">
										<table width="100%" border="0" cellspacing="0" cellpadding="3">
											<tr><td width="100%" bgcolor="$grey" class="judul" colspan="2">$t_src_rst&nbsp;<font color="$linkcol">$term</font></td></tr>
EOF;

								if($numrec>0){
									$get_news=mysql_query("select *,$article_catfile.ArtDesc as Category from $article_file, $article_catfile where $where and $article_file.ArtCat=$article_catfile.ArtCat order by $article_file.ArtDate desc limit $pos,$perpage",$db);
									while($get_rows=mysql_fetch_array($get_news)){
										$pretty_time=pretty_time($get_rows[ArtDate],1);
$output.=<<<EOF
											<tr><td bgcolor="$bgcol" width="1%" valign="top">&#149;</td><td bgcolor="$bgcol" width="99%" valign="top"><a href="$base_url/wmview.php?ArtID=$get_rows[ArtID]">$get_rows[ArtTitle]</a>&nbsp;&#150;&nbsp;<a href="$base_url/wmview.php?ArtCat=$get_rows[ArtCat]">$get_rows[Category]</a>&nbsp;&#150;&nbsp;<span class="date">$pretty_time</span></td></tr>
EOF;
									}
								}else{
$output.=<<<EOF
											<tr><td bgcolor="$bgcol" width="1%" valign="top">&#149;</td><td bgcolor="$bgcol" width="99%" valign="top" class="errmsg">$t_src_nfo</td></tr>
EOF;
								}

								$output.="</table></td></tr></table>";

							}

							$get_cats=mysql_query("select * from $article_catfile order by ArtDesc asc",$db);
							$catoption="<select name=\"ArtCat\">";
							$catoption.="<option value=\"0\" selected>$t_src_aca</option>";
							while($get_rows=mysql_fetch_array($get_cats)){
								if($ArtCat && $get_rows[ArtCat] == $ArtCat){
									$catoption.="<option value=\"$get_rows[ArtCat]\" selected>$get_rows[ArtDesc]</option>";
								}else{
									$catoption.="<option value=\"$get_rows[ArtCat]\">$get_rows[ArtDesc]</option>";
								}
							}
							$catoption.="</select>";
							if(checkIE()){
								$size=20;
							}else{
								$size=12;
							}

							$s_perpage = array("10", "25", "50");
							$s_perpage_opt = "<select name=\"perpage\">";
							while(list($k,$v) = each($s_perpage)){
								if($perpage == $v){
									$s_perpage_opt .= "<option value=\"$v\" selected>$v</option>";
								}else{
									$s_perpage_opt .= "<option value=\"$v\">$v</option>";
								}
							}
							$s_perpage_opt .= "</select>";

$searchform = <<<EOF
								<table width="100%" cellpadding="1" cellspacing="0" border="0">
									<tr><td width="100%" bgcolor="$bgcol">
										<form method=post action="$PHP_SELF">
										<table width="100%" border="0" cellspacing="0" cellpadding="3">
											<tr><td width="100%" bgcolor="$botrowcol" class="judul" colspan="2">
												<img src="images/icons/cari.gif" border="0" align="absmiddle">&nbsp;<font color="$linkcol">$t_src_jdl</font>&nbsp;
											</td></tr>
											<tr><td width="35%" bgcolor="$bgcol" align="right">$t_src_key</td><td width="65% bgcolor="$bgcol"><input type="text" name="term" size="$size" maxlength="50" value="$term"></td></tr>
											<tr><td bgcolor="$bgcol" align="right">$t_src_cat</td><td bgcolor="$bgcol">$catoption</td></tr>
											<tr><td bgcolor="$bgcol" align="right">$t_src_ppg</td><td bgcolor="$bgcol">$s_perpage_opt&nbsp;<input type="image" src="images/search.gif" border="0" align="absmiddle"></td></tr>
										</table>
										</form>
									</td></tr>
								</table>
EOF;

							if(!isset($output)){$output="";}
							$output="$searchform"."$output";
							echo $output;
							if($numpage>1){
								pagespan("$PHP_SELF?term=$term&perpage=$perpage", $tsnews, 0);
							}

							?>


						</td></tr>
					</table>
					<p align="center"><span class="lead">Managed by <a href="http://wartamikael.org/PHPScripts/?product=WMNews" target="_blank">WMNews</a>, <a href="http://www.php.net" target="_blank">PHP</a> & <a href="http://www.mysql.com\" target="_blank">MySQL</a></span>
				</td>
				<td width="20%" valign="top">
					<? include("rightcol.php");?>
				</td>
			</tr>
		</table>
		<? include("footer.php");?>