<?
/* ====================================================================================
 * Copyright (c) 2001 Rudy S. Ingga (toekangweb@wartamikael.org).  All rights reserved.
 *
 * config.php
 *   This configuration file customized for WMNews ver 0.2 only.
 *
 * This module is released under the GNU General Public License. See:
 *   http://www.gnu.org/copyleft/gpl.html
 *
 * For latest version and example, visit:
 *   http://wartamikael.org/PHPScripts
 * ====================================================================================
 */

$config = 1;			// Let it there!

/*
 * ============================================================
 * Database Options
 * Change $dbhost, $dbport, $dbuser, $dbpass and $dbname please
 * ------------------------------------------------------------
 */

$dbhost = "localhost";		// MySQL server host
$dbport = "3306";			// MySQL server port, 3306 is the default port, change to "" if you don't know.
$dbuser = "username";		// MySQL username
$dbpass = "password";		// MySQL password

/* Don't run the page if not connected into the database */

$db=mysql_connect("$dbhost:$dbport","$dbuser","$dbpass");	
if(is_string($db)){
	die("Could not connect to database server!");
}

$db_name = "database";		// Your database name

$dbuse=mysql_select_db($db_name,$db);
if(!$dbuse){
	die("Could not use database!");
}


/*
 * ==============================================================================
 * General Options
 * Change $base_path, $base_datapath, $base_url, $base_url_admin, $offset,
 * $site_title, $owner_email, and page_title please.
 * If you like, change the other variables.
 * ------------------------------------------------------------------------------
 */

/* Path where you place WMNews (No trailing slash) */

$base_path = "/home/user/public_html";

/* Your data path (No trailing slash)
 * Keeps all files created by generator on administration menu, for your security,
 * change name of this directory to be an unusual name like 'jVld0ksqQk' or 
 * something else to make it hard to find by someone who doesn't have authority
 * for the * files :). Don't forget to chmod this subdir to '777'.
 */

$base_datapath="$base_path/data";

/* Web Path of your WMNews (No trailing slash) */

$base_url = "http://mysite.com";

/* Web Path of your WMNews admin directory (No trailing slash), default is 'admin'.
 * For security purpose read Your data path above.
 * If you are using apache webserver, add .htaccess and .htpasswd to protect this
 * subdir. I forgot URL about .htaccess and .htpasswd but you can find it by type
 * '.htpasswd' on the search engines like Yahoo, Altavista, etc. Learn from there.
 */

$base_url_admin = "$base_url/admin";

/* How many links(records) display per page for the list page */

$step = 12;

/* How many seconds different between webserver time and the real time in your place,
 * 3600 means 3600 seconds / 1 hour. I've never tried with -/minus :)
 */

$offset = 0;

/* Set your date here,
 * $date_format = 1 (Saturday, 17 March 2001), = 2 (Saturday, March 17, 2001)
 * Change $namabulan, $namahari if necessary (into your own language)
 */

$date_format = 2;
$namabulan = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
$namahari = array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");

/* Your Site Name */

$site_title = "My News Site";

/* Your Email as an admin goes here */

$owner_email = "webmaster@mysite.com";

/* Layout color, I've never experiment with the color, but if you like you can change them too */

$bgcol	= "#FFFFFF";					// Background color
$textcol	= "#000000";					// Text color
$linkcol	= "#9A0404";					// Link color
$vlinkcol	= "#9A0404";					// Visited Link color
$alinkcol	= "#FF0000";					// Active Link color
$toprowcol	= "#059AEB";					// Table Top Row Color
$ctrrowcol	= "#69C9FC";					// Table Center Row Color
$botrowcol	= "#CBECFE";					// Table Bottom Row Color
$grey		= "#E4E4E4";					// What is the grey Color?

/* Change to whatever you like as a default title page */

$page_title = "Interactive";


/* ==============
 * WMNews Options
 * --------------
 */

$dispchr		= 325;					// How many character to display for every article, 0 to disable opening news text
$maxchr		= 3000;					// Maximum character per page for every article
$t_rt_use		= 1;						// 1 -> use rating system!; 0 -> do not use!
$t_cmt_use		= 1;						// 1 -> use comment system!; 0 -> do not use!
$t_cmt_ctr		= 0;						// 1 -> will send any comment posted by visitor to admin!; 0 -> No email to admin!

/* Change all the variables below to your mother language :) */

$tsnews 		= "article";				// News/Article text
$tboxcat		= "Categories";				// Title for Category Box
$tboxlastnews 	= "Last Articles";			// Title for Last News Box
$tnewnews 		= "Next:";					// New News text, display on the bottom of every article
$tpastnews 		= "Previous:";				// Past News text, display on the bottom of every article
$tnonews 		= "Sorry, no article found!";		// No News text
$trefer 		= "Send this article to a friend";	// Send To Friend text Link
$tpver 		= "Printer friendly version";		// Printable version text
$tback 		= "Return";					// Return text
$tarchive 		= "Archives";				// Archives text

$t_err_inv		= "Invalid input";								// Invalid input text
$t_err_bnm		= "Your name could not left be blank";					// Your name could not left be blank text
$t_err_bfn		= "Your friend's name could not left be blank";				// Your friend's name could not left be blank text
$t_err_wfm 		= "Invalid friend's e-mail format";						// Wrong friend's e-mail format text
$t_err_wym 		= "Invalid e-mail format";							// Wrong e-mail format text
$t_err_epc		= "Comment could not left be blank";					// Empty comment text
$t_err_tlc		= "Too long comment";								// Too long comment text
$t_err_eps		= "Subject could not left be blank";					// Empty subject text

$t_rt			= "Give Rate";									// Give rate text
$t_rt_txt		= "My rate:";									// My rate text
$t_rt_lvl		= array("Poor", "Enough", "Fair", "Good", "Excellent");		// Rate Level, must 5 elements from worst to best!
$t_rt_don		= "Sorry, you already rate this article!";				// Already rated text
$t_rt_thk		= "Thanks for your rate!";							// Thank you for your rate text

$t_gnr_mus		= "required fields!";								// Must entry text

$t_src_rst		= "You searched for:";								// Result of the search text
$t_src_jdl 		= "Search";										// Search text
$t_src_key 		= "Enter word(s):";								// Enter word to search text
$t_src_cat 		= "Looking in:";									// Search in category text
$t_src_aca 		= "All categories";								// All categories text
$t_src_ppg 		= "Per page:";									// How many record display per page text
$t_src_nfo		= "Sorry, I didn't find what you want, please try again!";		// Sorry data not found, please try again text

$t_cmt 		= "Comment";									// Comment text
$t_cmt_sbj		= "Subject";									// Subject comment text
$t_cmt_add		= "Add Comment";									// Add comment text
$t_cmt_ept		= "No Comment available";							// Empty comment text
$t_cmt_top		= "Comment's Topic";								// Top thread comment text
$t_cmt_prn		= "Parent's comment";								// Parent comments text
$t_cmt_adm		= "Admin reply";									// Admin reply text
$t_cmt_don		= "Sorry, please do not post the same comment!";			// Please do not post the same comments text
$t_cmt_las		= "Last Comments";								// Last comments text

$t_rf_yna 		= "Your Name";									// Your name text
$t_rf_yml		= "Your E-mail";									// Your e-mail text
$t_rf_yfn		= "Friend's Name";								// Your friend's name text
$t_rf_yfm		= "Friend's E-mail";								// Your friend's e-mail text
$t_rf_ams		= "Additional Message";								// Additional message text
$t_rf_sbj		= "Interesting article from $site_title"; 				// E-mail subject when refer an article text
$t_rf_snt 		= "sent you an interesting article at $site_title";			// Sent interesting an article text
$t_rf_msg 		= "Message from";									// Message from text
$t_rf_rgd 		= "Regards,";									// Regards text
$t_rf_thk 		= "Thank You";									// Thanks text
$t_rf_not		= "will receive notice via";							// Will receive notice via text

$t_top_txt		= "Popular articles";			// Top article text
$t_top_viw		= "Most Viewed";				// Top article based on viewed text
$t_top_rfr		= "Most Refered";				// Top article based on refered text
$t_top_prn		= "Most Printed";				// Top article based on printed text
$t_top_cmt		= "Most Commented";			// Top article based on commented text
$t_top_vot		= "Most Rated";				// Top article based on voted text
$t_top_rte		= "By Rating";				// Top article based on rated text

?>