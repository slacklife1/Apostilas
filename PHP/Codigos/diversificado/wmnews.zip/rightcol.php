<table width="100%" cellpadding="3" cellspacing="0" border="0">
	<?
	if(file_exists("$base_datapath/Warta_Terakhir.wmn")){
	?>
	<tr><td width="100%">
		<? include("$base_datapath/Warta_Terakhir.wmn");?>
	<?
	}else{
	?>
	<p><span class="title">Right Column</span></p>
	<p>You can put links, news, anything else here, or just include your news/article file was created by WMNews.</p>
	<p>Default sample for this column are latest news, categories box were created by generator at admin menu, and latest comments box.</p>
	<p>If you can read this, it means you haven't run the generator at admin menu.</p>
	<? 
	}
	?>
	</td></tr>
	<?
	if(file_exists("$base_datapath/ArticleCat.wmn")){
	?>
	<tr><td width="100%">
		<? include("$base_datapath/ArticleCat.wmn");?>
	<?
	}else{
	?>
	<p>If you can read this, it means you haven't run the generator at admin menu to create Category Box.</p>
	<? 
	}
	?>
	</td></tr>
	<?
	if(file_exists("$base_datapath/Komentar_Terakhir.wmn")){
	?>
	<tr><td width="100%">
		<? include("$base_datapath/Komentar_Terakhir.wmn");?>
	<?
	}else{
	?>
	<p>If you didn't see the latest comment box, it means there is no comments placed onto your news, please try give a comment to your news.</p>
	<?
	}
	?>
	</td></tr>
	<? clearstatcache(); ?>
</table>
