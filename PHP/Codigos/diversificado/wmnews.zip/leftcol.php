<table width="100%" cellpadding="3" cellspacing="0" border="0">
	<tr><td width="100%">
		<p class="title">Left Column</p>
		<p>You can put links, news, anything else here, or just include your news/article file was created by WMNews.
		<p><a href="/">Home</a><br><a href="wmview.php?Top=1">Top 10 (Popular)</a>
	</td></tr>
</table>
