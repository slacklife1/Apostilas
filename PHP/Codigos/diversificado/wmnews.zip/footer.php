<p>
<table border="0" cellpadding="3" cellspacing="1" width="100%">
	<tr bgcolor=<? echo $ctrrowcol;?>>
		<td><img src="images/shim.gif" width="1" height="1"></td>
	</tr>
	<tr bgcolor=<? echo $toprowcol;?>>
		<td>
			&copy; <? echo $site_title; ?>
		</td>
	</tr>
</table>
</body></html>