<?
/* ===================================================================================
 * Copyright (c) 2001 Rudy S. Ingga (toekangweb@wartamikael.org). All rights reserved.
 *
 * This module is released under the GNU General Public License. 
 * 	See: http://www.gnu.org/copyleft/gpl.html
 * 
 * wmprint.php
 * 	Part of WMNews,
 *	View news/category was created by wmnews.php in printable version
 *	Last Updated: Wednesday, 16 May, 2001 12:11:58 PM
 * 
 * WMNews Version 0.2
 * 	Another PHP & MySQL driven News Publishing system.
 *
 * For latest version and example, visit:
 * 	http://wartamikael.org/PHPScripts/WMNews
 * ===================================================================================
 */

$article_catfile="ArticleCat";
$article_file="Article";
if(!isset($config)){include("config/config.php");}
if(!isset($wmlib)){include("wmlib.php");}

if(isset($ArtID)){

	$get_news=mysql_query("select *,$article_catfile.ArtDesc as CatDesc,$article_catfile.ArtIcon as CatIcon from $article_file,$article_catfile where $article_file.ArtCat=$article_catfile.ArtCat and $article_file.ArtID='$ArtID' limit 0,1",$db);
	$get_rows=mysql_fetch_array($get_news);
	$ArtCat=$get_rows[ArtCat];
	$Category=$get_rows[CatDesc];
	$pretty_time=pretty_time($get_rows[ArtDate],1);
	$ArtDate = $get_rows[ArtDate];
	$content=$get_rows[ArtMsg];
	$article_title = $get_rows[ArtTitle];

$detail=<<<EOF
	<html>
	<head>
		<title>$site_title - $article_title - $Category</title>
		<link rel="stylesheet" href="wm.css">
		<script src="wm.js" language="Javascript"></script>
		<meta http-equiv="Cache-Control" content="no-cache">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="-1">
		<meta name="revisit-after" content="15">
		<meta name="classification" content="Religion">
		<meta name="description" content="Lingkungan Santo Mikael, Puspita Loka BSD, Paroki Santa Monika Serpong Tangerang">
		<meta name="keywords" content="Catholic, Katolik, Komunitas, Lingkungan, Santo, Mikael, Monika, Paroki, Gereja, Serpong, Tangerang, BSD, Bumi Serpong Damai, Warta Mikael, Buletin, ">
		<meta name="robots" content="ALL">
	</head>
	<body topmargin="20" leftmargin="20" marginwidth="20" marginheight="20" bgcolor="$bgcol" text=$textcol" link="$linkcol" vlink="$vlinkcol" alink="$alinkcol">
	<h2>$site_title - $base_url - $Category</h2>
	<p><span class="bigtitle"><font color="$linkcol">$article_title</font></span> - <i>$pretty_time</i><br><i>$get_rows[ArtLead]</i>
	<p><p>$content&nbsp[WM]
	<p><a href='javascript:history.go(-1)'>$tback</a>
	</body>
	</html>
EOF;
	echo $detail;
	$upd_print = mysql_query("UPDATE $article_file SET ArtPrint = ArtPrint + 1, ArtDate = '$ArtDate' WHERE ArtID = '$ArtID'", $db);
}

?>