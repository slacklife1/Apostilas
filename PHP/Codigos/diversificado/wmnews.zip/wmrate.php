<?
/* ===================================================================================
 * Copyright (c) 2001 Rudy S. Ingga (toekangweb@wartamikael.org). All rights reserved.
 *
 * This module is released under the GNU General Public License.
 * 	See: http://www.gnu.org/copyleft/gpl.html
 * 
 * wmrate.php
 * 	Part of WMNews,
 *	Rate an article module
 *	Last Updated: Wednesday, 16 May, 2001 12:11:58 PM
 * 
 * WMNews Version 0.2
 * 	Another PHP & MySQL driven News Publishing system.
 *
 * For latest version and example, visit:
 * 	http://wartamikael.org/PHPScripts/WMNews
 * ====================================================================================
 */

$article_catfile	= "ArticleCat";
$article_file	= "Article";

if(!isset($config)){ include("config/config.php"); }
if(!isset($wmlib)){ include("wmlib.php"); }

/* Do not use rate system, redirecting user to the homepage */
if(!$t_rt_use){ header("Location: $base_url"); }

$output = "";
$output .= box_open(2,"rate.gif",$t_rt);

if(!isset($ArtID)){
	$ArtID = GetLast();
}
if($ArtID){
	$headlines .= GetArticle($ArtID, 0);
	if($headlines){
		$output .= $headlines;
		if(!isset($wr_nilai)){
			$wr_rform = "\n<select name=\"wr_nilai\">";
			for($i = 0; $i < 5; $i++){
				$wr_i = $i + 5;
				if($i == "2"){
					$wr_rform .= "\n<option value=\"$wr_i\" selected>$t_rt_lvl[$i]</option>";
				}else{
					$wr_rform .= "\n<option value=\"$wr_i\">$t_rt_lvl[$i]</option>";
				}
			}
			$wr_rform .= "\n</select>";
			$output .= "\n<form action=\"$PHP_SELF\" method=\"post\">";
			$output .= $t_rt_txt . " " . $wr_rform . " ";
			$output .= "\n<input type=\"image\" src=\"images/send.gif\" border=\"0\" align=\"absmiddle\">";
			$output .= "\n<input type=\"hidden\" name=\"ArtID\" value=\"$ArtID\">";
			$output .= "\n</form>";
		}else{
			$wr_cookies = "wmrate" . $ArtID;
			if($HTTP_COOKIE_VARS["$wr_cookies"] == "1"){
				$output .= "<p><span class=\"errmsg\">$t_rt_don</span><p><a href='javascript:history.go(-2)'>$tback</a>";
			}else{
				$wr_cookies_exp = time() + $offset + 86400;
				setcookie("$wr_cookies", "1", $wr_cookies_exp);
				$wr_update = mysql_query("UPDATE $article_file SET ArtDate = ArtDate, ArtRate = ArtRate + $wr_nilai, ArtTRate = ArtTRate + 1 WHERE ArtID = '$ArtID'", $db);
				$output .= "<p><span class=\"title\">$t_rt_thk</span><p><a href=\"$base_url/wmview.php?ArtID=$ArtID\">$tback</a>";
			}
		}
	}else{
		$output .= "<tr><td bgcolor=\"$bgcol\"><span class=\"errmsg\">$tnonews #$ArtID</span>";
	}
}


/* Print Out the whole thing we've got onto the browser */

flush();
include("header.php");
echo "<table border=\"0\" cellpadding=\"0\" cellspacing=\"1\" width=\"100%\"><tr><td width=\"20%\" valign=\"top\">";
include("leftcol.php");
echo "</td><td width=\"60%\" valign=\"top\"><table width=\"100%\" cellpadding=\"2\" cellspacing=\"0\" border=\"0\"><tr><td width=\"100%\">";
$output .= box_close("","","");
echo $output;
echo "</td></tr></table>";
/* WARNING: Do not remove this line until you pay for comercial version (No WMNews link!) */
echo "<p align=center><span class=\"lead\">Managed by <a href=\"http://wartamikael.org/PHPScripts/?product=WMNews\" target=\"_blank\">WMNews</a>, <a href=\"http://www.php.net\" target=\"_blank\">PHP</a> & <a href=\"http://www.mysql.com\" target=\"_blank\">MySQL</a></span>";
echo "</td><td width=\"20%\" valign=\"top\">";
include("rightcol.php");
echo "</td></tr></table>";
include("footer.php");

?>