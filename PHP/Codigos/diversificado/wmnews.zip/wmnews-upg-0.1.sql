# ============================================================================
# Upgrade WMNews Tables Structure from ver 0.1/0.1a to ver 0.2
# Current WMNews Version	: 0.2
# Last Updated			: Friday, June 01, 2001 - 12:05:29 PM
# Author				: Rudy S. Ingga (toekangweb@wartamikael.org)
#							    (rudy@wita.or.id)
# ----------------------------------------------------------------------------

# Updated Table structure for table 'Article' from ver 0.1/0.1a to ver 0.2
#
ALTER TABLE Article ADD ArtView INTEGER(7) DEFAULT '0' NOT NULL;
ALTER TABLE Article ADD ArtRefer INTEGER(7) DEFAULT '0' NOT NULL;
ALTER TABLE Article ADD ArtPrint INTEGER(7) DEFAULT '0' NOT NULL;
ALTER TABLE Article ADD ArtComment INTEGER(7) DEFAULT '0' NOT NULL;
ALTER TABLE Article ADD ArtRate INTEGER(7) DEFAULT '0' NOT NULL;
ALTER TABLE Article ADD ArtTRate INTEGER(7) DEFAULT '0' NOT NULL;
ALTER TABLE Article ADD INDEX ArtTitle (ArtTitle);
ALTER TABLE Article ADD INDEX ArtLead (ArtLead);

# Table structure for table 'ArtComments', table added since ver 0.2
#
DROP TABLE IF EXISTS ArtComments;
CREATE TABLE ArtComments (
  CmID int(7) NOT NULL auto_increment,
  CmDate timestamp(14),
  CmArtID int(7) DEFAULT '0' NOT NULL,
  CmPID int(7) DEFAULT '0' NOT NULL,
  CmName varchar(50) DEFAULT '' NOT NULL,
  CmEmail varchar(50) DEFAULT '' NOT NULL,
  CmSubject varchar(100) DEFAULT '' NOT NULL,
  CmContent varchar(255) DEFAULT '' NOT NULL,
  CmDate2 timestamp(14),
  CmContent2 varchar(255) DEFAULT '' NOT NULL,
  CmIP varchar(20) DEFAULT '' NOT NULL,
  PRIMARY KEY (CmID),
  INDEX CmArtID (CmArtID)
);

# ----------------------------------------------------------------------------
# End of upgrade WMNews tables structure from ver 0.1/0.1a to ver 0.2
# ============================================================================
