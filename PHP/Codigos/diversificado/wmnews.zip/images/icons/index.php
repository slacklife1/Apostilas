<?
include("../../config/config.php");
header("Location: $base_url");
?>