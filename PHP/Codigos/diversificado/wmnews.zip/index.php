<?
/* =========================================================================
 * Copyright (c) 2001 Rudy S. Ingga (rudy@wita.or.id).  All rights reserved.
 *
 * index.php
 *   Sample index file for your site
 * 
 * Wednesday, March 14, 2001 08:53:56 PM
 * =========================================================================
 */

if(!isset($config)){include("config/config.php");}
if(!isset($wmlib)){include("wmlib.php");}
include("header.php");	
?>

<table border="0" cellpadding="0" cellspacing="1" width="100%">
	<tr>
		<td width="20%" valign="top">
			<? include("leftcol.php");?>
		</td>
		<td width="60%" valign="top">
			<table width="100%" cellpadding="2" cellspacing="0" border="0">
				<tr><td width="100%" colspan="2">
					<p class="title">Center Column</p>
					<p>You can put links, news, anything else here, or just include your news/article file was created by WMNews. Open index.php with your text editor, then follow the instructions below:
					<p class="title">How to include files created by WMNews:<p>
					<p>If you want to include the last news/article box per Category:
					<p>&nbsp;&nbsp;&nbsp;<code>&lt;? include("$base_datapath/Category_Name.wmn");?&gt;</code>.
					<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Don't forget to change <span class="errmsg">Category_Name</span> with your real category name!
					<p>If you want to include the all last news/article box:
					<p>&nbsp;&nbsp;&nbsp;<code>&lt;? include("$base_datapath/Warta_Terakhir.wmn");?&gt;</code>.
					<p>If you want to include category list box:
					<p>&nbsp;&nbsp;&nbsp;<code>&lt;? include("$base_datapath/ArticleCat.wmn");?&gt;</code>.
 				</td></tr>
			</table>
		</td>
		<td width="20%" valign="top">
			<? include("rightcol.php");?>
		</td>
	</tr>
</table>
<? include("footer.php");?>