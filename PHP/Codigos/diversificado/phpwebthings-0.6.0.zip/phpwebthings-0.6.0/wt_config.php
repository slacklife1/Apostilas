<?php
// Database configuration
$config["dbtype"] = "mysql";  //mysql/pgsql
$config["host"] = "localhost";
$config["user"] = "webthings";
$config["password"] = "12345";
$config["database"] = "webthings";
// prefix for tables at webthings. all tables will be {$config["prefix"]}_tablename
$config["prefix"] = "wt";
?>
