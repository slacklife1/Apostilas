<?php
// lang file for news
// News
define( 'NEWS_TITLE', "Novinky" );
define( 'NEWS_POSTED_BY', "Zasl�no " );
define( 'NEWS_SAME_CAT', "v�ce podobn�ch" );
define( 'NEWS_CLICK_MORE', "pro pokra�ov�n� klikn�te..." );
define( 'NEWS_SUBMIT_TITLE', "Zaslat novinky" );
define( 'NEWS_SUBMIT_DONE', "Zasl�n� novinek" );
define( 'NEWS_SUBMIT_THANKS', "Va�e novinka byla zasl�na!<br><br>D�ky!" );
define( 'NEWS_SUBMIT_THANKS_MAIL_TITLE', "Novinky byly zasl�ny." );
define( 'NEWS_SUBMIT_THANKS_MAIL', "Novinky byly p�id�na na va�i str�nku a byly aktivov�ny" );
define( 'NEWS_SUBMIT_THANKS2', "Novinka byla zasl�na, ale nejd��ve mus� b�t aktivov�na administr�torem str�nek<br><br>D�ky!" );
define( 'NEWS_SUBMIT_THANKS2_MAIL', "Novinka byla p�id�na na str�nka a �ek� na aktivaci" );
define( 'NEWS_FIELD_TITLE', "Titulek:" );
define( 'NEWS_FIELD_IMAGE', "Obr�zek:" );
define( 'NEWS_FIELD_CAT', "Kategorie:" );
define( 'NEWS_FIELD_TEXT', "Text:" );
define( 'NEWS_FIELD_FULL_TEXT', "Pln� text (nepovinn�):" );
define( 'NEWS_FIELD_ACTIVE', "Published" );
define( 'NEWS_FIELD_ARCHIVED', "Archived" );
define( 'NEWS_FIELD_UID', "User:" );
define( 'NEWS_FIELD_DATE', "Date:" );
define( 'NEWS_FIELD_ALIGN', "Image align:" );
define( 'NEWS_PENDING', "Activation pending for these news" );
define( 'NEWS_PENDING_NONE', "There is no news pending for activation" );
define( 'NEWS_EDIT', "edit" );
define( 'NEWS_ARCHIVED', "View archived news" );
define( 'NOT_LOGGED_NEWS', "Sorry, but you need to login to send a news. If you don't have a login, why don't you register? It's free!" );
?>