<?php
// lang file for news
// News
define( 'NEWS_TITLE', "Berita & Referensi" );
define( 'NEWS_POSTED_BY', "Dikirim oleh " );
define( 'NEWS_SAME_CAT', "lebih banyak mengenai..." );
define( 'NEWS_CLICK_MORE', "klik disini untuk selengkapnya..." );
define( 'NEWS_SUBMIT_TITLE', "Kirim Berita" );
define( 'NEWS_SUBMIT_DONE', "Berita Terkirim" );
define( 'NEWS_SUBMIT_THANKS', "Berita anda telah terkirim!<br><br>Terima Kasih!" );
define( 'NEWS_SUBMIT_THANKS_MAIL_TITLE', "Sebuah Berita telah dikirim ke www.stieken.ac.id" );
define( 'NEWS_SUBMIT_THANKS_MAIL', "Sebuah Berita telah dikirim ke website anda, dan telah diaktifkan" );
define( 'NEWS_SUBMIT_THANKS2', "Berita anda telah terkirim, tetapi harus diaktifkan dahulu oleh site administrator.<br><br>Terima Kasih!" );
define( 'NEWS_SUBMIT_THANKS2_MAIL', "Sebuah Berita telah ditambahkan ke www.stieken.ac.id dan menunggu anda aktifkan" );
define( 'NEWS_FIELD_TITLE', "Judul:" );
define( 'NEWS_FIELD_IMAGE', "Gambar:" );
define( 'NEWS_FIELD_CAT', "Kategori:" );
define( 'NEWS_FIELD_TEXT', "Teks:" );
define( 'NEWS_FIELD_FULL_TEXT', "Teks Lengkap (optional):" );
define( 'NEWS_FIELD_ACTIVE', "Published" );
define( 'NEWS_FIELD_ARCHIVED', "Archived" );
define( 'NEWS_FIELD_UID', "User:" );
define( 'NEWS_FIELD_DATE', "Date:" );
define( 'NEWS_FIELD_ALIGN', "Image align:" );
define( 'NEWS_PENDING', "Activation pending for these news" );
define( 'NEWS_PENDING_NONE', "There is no news pending for activation" );
define( 'NEWS_EDIT', "edit" );
define( 'NEWS_ARCHIVED', "View archived news" );
define( 'NOT_LOGGED_NEWS', "Sorry, but you need to login to send a news. If you don't have a login, why don't you register? It's free!" );
?>