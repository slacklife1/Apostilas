<?php
// polish file for phpwebthings - zombiek <pzabek@realnet.pl>
// News
define( 'NEWS_TITLE', "Aktualno�ci" );
define( 'NEWS_POSTED_BY', "Wys�ane przez " );
define( 'NEWS_SAME_CAT', "wi�cej z tej kategorii" );
define( 'NEWS_CLICK_MORE', "wi�cej..." );
define( 'NEWS_SUBMIT_TITLE', "Dodaj njusa" );
define( 'NEWS_SUBMIT_DONE', "News dodany" );
define( 'NEWS_SUBMIT_THANKS', "Tw�j news zosta� dodany!<br><br>Dzi�ki!" );
define( 'NEWS_SUBMIT_THANKS_MAIL_TITLE', "NEWS zosta� dodany do twojej strony" );
define( 'NEWS_SUBMIT_THANKS_MAIL', "NEWS zostal dodany do strony, i zosta� aktywowany" );
define( 'NEWS_SUBMIT_THANKS2', "Tw�j news zosta� dodany, lecz najpierw musi by� zweryfikowany przez administratora.<br><br>Dzi�ki!" );
define( 'NEWS_SUBMIT_THANKS2_MAIL', "NEWS czeka na weryfikacj�" );
define( 'NEWS_FIELD_TITLE', "Tytu�:" );
define( 'NEWS_FIELD_IMAGE', "Zdj�cie:" );
define( 'NEWS_FIELD_CAT', "Kategoria:" );
define( 'NEWS_FIELD_TEXT', "Tre��:" );
define( 'NEWS_FIELD_FULL_TEXT', "Pe�na tre�� (opcjonalnie):" );
define( 'NEWS_FIELD_ACTIVE', "Published" );
define( 'NEWS_FIELD_ARCHIVED', "Archived" );
define( 'NEWS_FIELD_UID', "User:" );
define( 'NEWS_FIELD_DATE', "Date:" );
define( 'NEWS_FIELD_ALIGN', "Image align:" );
define( 'NEWS_PENDING', "Activation pending for these news" );
define( 'NEWS_PENDING_NONE', "There is no news pending for activation" );
define( 'NEWS_EDIT', "edit" );
define( 'NEWS_ARCHIVED', "View archived news" );
define( 'NOT_LOGGED_NEWS', "Sorry, but you need to login to send a news. If you don't have a login, why don't you register? It's free!" );
?>