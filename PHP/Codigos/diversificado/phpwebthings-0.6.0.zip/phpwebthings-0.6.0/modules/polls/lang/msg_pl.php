<?php
// polish file for phpwebthings - zombiek <pzabek@realnet.pl>
define( 'POLL_TITLE', "Sonda" );
define( 'POLL_RESULT', "Rezultaty" );
define( 'POLL_VOTE_BUTTON', "G�osuj" );
define( 'POLL_RESULTS_LINK', "Rezultaty" );
define( 'POLL_VOTE_AGAIN', "Ju� g�osowa�e� w tym miesi�cu" );
define( 'POLL_ALLPOLLS', "List all polls" );
?>