<?php
// lang file for polls
define( 'POLL_TITLE', "Anketa" );
define( 'POLL_RESULT', "V�sledky" );
define( 'POLL_VOTE_BUTTON', "Hlasovat" );
define( 'POLL_RESULTS_LINK', "V�sledky" );
define( 'POLL_VOTE_AGAIN', "Tento m�s�c jste u� hlasoval(a)" );
define( 'POLL_ALLPOLLS', "List all polls" );
?>