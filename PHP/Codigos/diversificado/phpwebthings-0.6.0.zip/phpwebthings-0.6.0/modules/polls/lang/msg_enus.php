<?php
// lang file for polls
$lang["POLL_TITLE"]="Poll";
$lang["POLL_RESULT"]="Poll result";
$lang["POLL_VOTE_BUTTON"]="Vote";
$lang["POLL_RESULTS_LINK"]="Results";
$lang["POLL_VOTE_AGAIN"]="You already voted this month";
$lang["POLL_ALLPOLLS"]="List all polls";
$lang["POLL_NOVALUE"]="You need to choose one item to vote";

?>