<?php
// french file for phpwebthings - Eric Courtes <eric.courtes@wanadoo.fr>

define( 'POLL_TITLE', "Vote" );
define( 'POLL_RESULT', "R�sultat du Vote" );
define( 'POLL_VOTE_BUTTON', "Vote" );
define( 'POLL_RESULTS_LINK', "Resultats" );
define( 'POLL_VOTE_AGAIN', "Vous avez d�j� vot� ce mois-ci" );
define( 'POLL_ALLPOLLS', "List all polls" );
?>