<?php
// lang file for polls
define( 'POLL_TITLE', "Jajak Pendapat" );
define( 'POLL_RESULT', "Hasil jajak pendapat" );
define( 'POLL_VOTE_BUTTON', "Pilih" );
define( 'POLL_RESULTS_LINK', "Hasil" );
define( 'POLL_VOTE_AGAIN', "Anda telah memilih bulan ini" );
define( 'POLL_ALLPOLLS', "List all polls" );
?>