<?php
// lang file for polls
$lang["POLL_TITLE"]="Enquete";
$lang["POLL_RESULT"]="Resultado da Enquete";
$lang["POLL_VOTE_BUTTON"]="Votar";
$lang["POLL_RESULTS_LINK"]="Resultados";
$lang["POLL_VOTE_AGAIN"]="Voc� j� votou nesta enquete";
$lang["POLL_ALLPOLLS"]="Listar todas as enquetes";
$lang["POLL_NOVALUE"]="Escolha uma op��o para votar.";
?>