<?php
// Dutch file for polls - Frank dirckx <X-a-V@langames.nldefine( 'POLL_TITLE', "Poll" );

define( 'POLL_RESULT', "Poll resulaat" );
define( 'POLL_VOTE_BUTTON', "Stem" );
define( 'POLL_RESULTS_LINK', "Resultaten" );
define( 'POLL_VOTE_AGAIN', "Je hebt al gestemt deze maand" );
define( 'POLL_ALLPOLLS', "List all polls" );
?>