<?php
// Norwegian lang file for polls
define( 'POLL_TITLE', "Unders�kelse" );
define( 'POLL_RESULT', "Resultat" );
define( 'POLL_VOTE_BUTTON', "Stem" );
define( 'POLL_RESULTS_LINK', "Resultat" );
define( 'POLL_VOTE_AGAIN', "Du har allerede avgitt stemme denne m�neden" );
define( 'POLL_ALLPOLLS', "List all polls" );
?>