<?php
// This is the config file for the module
// the four lines below enable this module at the modules list
$config_var["modules"]["links"]["type"] = "checkbox";
$config_var["modules"]["links"]["desc"] = "Links";
$config_var["modules"]["links"]["default"] = true;
$config_var["modules"]["links"]["obs"] = "Manage links at your site.";

// these lines are for configuration of the current module
?>