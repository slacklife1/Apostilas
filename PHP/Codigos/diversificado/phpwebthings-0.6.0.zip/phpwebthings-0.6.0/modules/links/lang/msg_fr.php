<?php
// lang file for downloads

define( 'LINKS_TITLE', "Liens" );
define( 'LINKS_HEADER_1', "Lien" );
define( 'LINKS_HEADER_4', "Hits" );
define( 'LINKS_BACK', "Retour au t�l�chargement" );

?>
