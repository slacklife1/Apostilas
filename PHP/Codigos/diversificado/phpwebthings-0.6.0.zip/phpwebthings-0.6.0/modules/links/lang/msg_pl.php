<?php
// polish file for phpwebthings - zombiek <pzabek@realnet.pl>

define( 'LINKS_TITLE', "Downloads" );
define( 'LINKS_HEADER_1', "Link" );
define( 'LINKS_HEADER_4', "Trafie�" );
define( 'LINKS_BACK', "Powr�t do downloads" );

?>
