<?php
// lang file for links  by Frank Dirckx <X-a-V@langames.nl> 

define( 'LINKS_TITLE', "Links" );
define( 'LINKS_HEADER_1', "Link" );
define( 'LINKS_HEADER_4', "Hits" );
define( 'LINKS_BACK', "Terug naar Links" );

?>