<?php
// lang file for downloads
$lang["LINKS_TITLE"]="Links";
$lang["LINKS_HEADER_1"]="Link";
$lang["LINKS_HEADER_4"]="Hits";
$lang["LINKS_BACK"]="Voltar";
$lang["LINKS_ERROR01"]="Categoria inv�lida";
$lang["LINKS_VISIT"]="Visite!";
$lang["LINKS_GOUP"] = "Voltar um n�vel";
?>