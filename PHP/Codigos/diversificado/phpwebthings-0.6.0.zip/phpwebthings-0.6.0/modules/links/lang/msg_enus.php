<?php
// lang file for downloads

$lang["LINKS_TITLE"]="Links";
$lang["LINKS_HEADER_1"]="Link";
$lang["LINKS_HEADER_4"]="Hits";
$lang["LINKS_BACK"]="Back to links";
$lang["LINKS_ERROR01"]="Invalid category";
$lang["LINKS_VISIT"]="Go there!";
$lang["LINKS_GOUP"] = "Go up one level";

?>