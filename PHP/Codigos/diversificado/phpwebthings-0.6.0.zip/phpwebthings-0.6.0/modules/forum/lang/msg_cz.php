<?php
// lang file for forums by Paulo Assis <paulo@coral.srv.br>

define( 'FORUM_TITLE', "F�rum" );
define( 'FORUM_HEADER_TITLE', "Titulek" );
define( 'FORUM_HEADER_TOPICS', "T�ma" );
define( 'FORUM_HEADER_POSTS', "P��sp�vky" );
define( 'FORUM_HEADER_LASTPOST', "Posledn� p��sp�vek" );
define( 'FORUM_HEADER_POSTED', "Zasl�no" );
define( 'FORUM_HEADER_VIEWS', "Zobrazen�" );
define( 'FORUM_HEADER_REPLIES', "Odpov�di" );
define( 'FORUM_BY', "od" );
define( 'FORUM_WROTE', "naps�no na" );
define( 'FORUM_POSTED', "POsl�no na" );
define( 'FORUM_QUOTE', "citovat zpr�vu" );
define( 'FORUM_TEXT', "Zpr�va" );
define( 'FORUM_SEND', "Poslat zpr�vu" );
define( 'FORUM_POST', "Poslat zpr�vu" );
define( 'FORUM_NOT_LOGGED', "Je mi l�to, ale pro zasl�n� zpr�vy se mus�te nalogovat. Pokud nem�te login, pro� se neregistrovat? je to Z D A R M A! :)" );
define( 'FORUM_NOT_LOGGED2', "Je mi l�to, ale pro zobrazen� on-line u�ivatel� se mus�te nalogovat. Pokud nem�te login, pro� se neregistrovat? je to Z D A R M A! :)" );
define( 'FORUM_SEARCH', "Hledat" );
define( 'FORUM_FOUND', "zpr�v nalezeno" );
?>