<?php
// polish file for phpwebthings - zombiek <pzabek@realnet.pl>

define( 'FORUM_TITLE', "Forum" );
define( 'FORUM_HEADER_TITLE', "Tytu�" );
define( 'FORUM_HEADER_TOPICS', "Tematy" );
define( 'FORUM_HEADER_POSTS', "Post�w" );
define( 'FORUM_HEADER_LASTPOST', "Ostatni post" );
define( 'FORUM_HEADER_POSTED', "Wys�ane" );
define( 'FORUM_HEADER_VIEWS', "Ogl�dane" );
define( 'FORUM_HEADER_REPLIES', "Odpowiedzi" );
define( 'FORUM_BY', "przez" );
define( 'FORUM_WROTE', "Napisane" );
define( 'FORUM_POSTED', "Wys�ane" );
define( 'FORUM_QUOTE', "Quota wiadomo�ci" );
define( 'FORUM_TEXT', "Wiadomo��" );
define( 'FORUM_SEND', "Wy�lij wiadomo��" );
define( 'FORUM_POST', "Wy�lij wiadomo��" );
define( 'FORUM_NOT_LOGGED', "Niestety, musisz si� zalogowa�, aby wys�a� wiadomo��. Je�li nie masz jeszcze konta, zarejestruj si�? Rejestracja jest darmowa!" );
define( 'FORUM_NOT_LOGGED2', "Niestety, musisz si� zalogowa�, aby wys�a� wiadomo��. Je�li nie masz jeszcze konta, zarejestruj si�? Rejestracja jest darmowa!" );
define( 'FORUM_SEARCH', "Szukaj" );
define( 'FORUM_FOUND', "znalezionych wiadomo�ci" );
?>