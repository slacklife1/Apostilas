<?php
// lang file for forums by Paulo Assis <paulo@coral.srv.br>

$lang["FORUM_TITLE"]="F�rums";
$lang["FORUM_HEADER_TITLE"]="T�tulo";
$lang["FORUM_HEADER_TOPICS"]="T�picos";
$lang["FORUM_HEADER_POSTS"]="Msgs";
$lang["FORUM_HEADER_LASTPOST"]="�ltima msg";
$lang["FORUM_HEADER_VR"]="Exib/Resp";
$lang["FORUM_BY"]="por";
$lang["FORUM_WROTE"]="escreveu em";
$lang["FORUM_POSTED"]="Enviada em";
$lang["FORUM_QUOTE"]="<img src=\"modules/forum/images/quote_enus.gif\" alt=\"Quote Message\" border=\"0\">";
$lang["FORUM_TEXT"]="Mensagem";
$lang["FORUM_SEND"]="Enviar mensagem";
$lang["FORUM_POST"]="Enviar uma mensagem";
$lang["FORUM_NOT_LOGGED"]="Desculpe, mas voc� precisa se logar para enviar uma mensagem no f�rum. Se voc� n�o tem um login, porque n�o se registra? � de gra�a!";
$lang["FORUM_NOT_LOGGED2"]="Voc� poderia enviar uma mensagem para o f�rum se estivesse registrado. Se voc� n�o tem um login, porque n�o se registra? � de gra�a!";
$lang["FORUM_SEARCH"]="Procurar";
$lang["FORUM_FOUND"]="mensagens encontradas";
$lang["FORUM_LOCKED"]="<i>(F&oacute;rum bloqueado)</i>";
$lang["FORUM_CLOSED"]="<i>(Discuss�o fechada)</i>";
$lang["FORUM_PARSE"]="Habilita tags WT?";
$lang["FORUM_PREVIOUS"]="Anterior";
$lang["FORUM_NEXT"]="Pr�ximo";
$lang["FORUM_NOUSER"]="*nobody*";
$lang["FORUM_EDIT"]="editar";
$lang["FORUM_GOUP"]="Voltar";
$lang["FORUM_ERROR_01"]="Voc� precisa informar o t�tulo e mensagem.";
$lang["FORUM_MSG_POSTED"]= "Sua mensagem foi enviada!";
$lang["FORUM_MSG_OPTION1"]= "Voltar ao f�rum";
$lang["FORUM_MSG_OPTION2"]= "Ver a mensagem que voc� postou";
?>