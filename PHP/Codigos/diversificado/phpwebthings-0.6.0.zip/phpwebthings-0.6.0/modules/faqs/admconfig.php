<?php
// This is the config file for the module
// the four lines below enable this module at the modules list
$config_var["modules"]["faqs"]["type"] = "checkbox";
$config_var["modules"]["faqs"]["desc"] = "FAQs";
$config_var["modules"]["faqs"]["default"] = true;
$config_var["modules"]["faqs"]["obs"] = "Manage FAQs at your site.";

// these lines are for configuration of the current module
?>