<?php
// english file for faqs - Paulo Assis <paulo@phpdbform.com>
define( 'NOT_LOGGED_FAQ', "Kdybyste byl registrov�n(a), mohl(a) byste p�idat FAQ!<br>. Pokud nem�te login, pro� se neregistrovat? je to Z D A R M A! :)" );
define( 'FAQ_TITLE', "FAQ" );
define( 'FAQ_ERROR_01', "Pokud nejste registrov�n(a) nem��ete p�idat FAQ<br>" );
define( 'FAQ_ERROR_02', "Mus�te zadat ot�zku<br>" );
define( 'FAQ_ERROR_03', "Mus�te zadat odpov��<br>" );
define( 'FAQ_ERROR_04', "�patn� t�ma<br>" );
define( 'FAQ_SUBMIT_DONE_TITLE', "FAQ p�id�no" );
define( 'FAQ_SUBMIT_THANKS', "Va�e FAQ blo p�id�no, ale nejprve mus� b�t aktivov�no aministr�torem str�nek<br><br>D�ky!" );
define( 'FAQ_SUBMIT_MAIL_TITLE', "FAQ bylo p�id�no" );
define( 'FAQ_SUBMIT_MAIL', "FAQ bylo p�id�no a nyn� �ek� na aktivaci" );
define( 'FAQ_TOPICS', "FAQ t�mata" );

define( 'FAQ_FORM_TITLE', "P�idat a FAQ" );
define( 'FAQ_FORM_QUESTION', "Ot�zka:" );
define( 'FAQ_FORM_ANSWER', "Odpov��:" );
define( 'FAQ_FORM_SUBMIT', "POslat faq" );
define( 'FAQ_POSTED_BY', "P��sp�vek od" );

?>
