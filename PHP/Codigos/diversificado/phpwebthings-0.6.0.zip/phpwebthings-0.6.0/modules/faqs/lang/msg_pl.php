<?php
// polish file for phpwebthings - zombiek <pzabek@realnet.pl>

define( 'NOT_LOGGED_FAQ', "Gdyby� by� zalogowany m�g�by� doda� FAQ!<br>Mo�e zarejestrujesz si� teraz? Rejestracja jest darmowa!" );
define( 'FAQ_TITLE', "FAQ" );
define( 'FAQ_ERROR_01', "Nie mo�esz doda� FAQ nie b�d�c zalogowanym<br>" );
define( 'FAQ_ERROR_02', "Musisz wpisa� pytanie<br>" );
define( 'FAQ_ERROR_03', "Musisz wpisa� odpowied�<br>" );
define( 'FAQ_ERROR_04', "z�y temat<br>" );
define( 'FAQ_SUBMIT_DONE_TITLE', "FAQ dodane" );
define( 'FAQ_SUBMIT_THANKS', "Twoje FAQ zosta�o dodane, lecz najpierw musi by� zweryfikowane przez administratora.<br><br>Thanks!" );
define( 'FAQ_SUBMIT_MAIL_TITLE', "Dodano FAQ do strony" );
define( 'FAQ_SUBMIT_MAIL', "FAQ czeka na Twoj� weryfikacj�" );
define( 'FAQ_TOPICS', "FAQ - Najcz�ciej zadawane pytania - Tematy:" );

define( 'FAQ_FORM_TITLE', "Dodaj FAQ" );
define( 'FAQ_FORM_QUESTION', "Pytanie:" );
define( 'FAQ_FORM_ANSWER', "odpowied�:" );
define( 'FAQ_FORM_SUBMIT', "Wy�lij faq" );
define( 'FAQ_POSTED_BY', "Dodane przez" );

?>
