<?php
// Norwegian file for faqs - Frode Joergensen <www.kulinarisk.no>
define( 'NOT_LOGGED_FAQ', "Hvis du var logget p� kunne du legge til en Fakta!<br>Hvorfor registrerer du deg ikke n�? Det er gratis!" );
define( 'FAQ_TITLE', "Fakta" );
define( 'FAQ_ERROR_01', "Du kan ikke legge til fakta n�r du ikke er p�logget<br>" );
define( 'FAQ_ERROR_02', "Du m� skrive et sp�rsm�l<br>" );
define( 'FAQ_ERROR_03', "Du m� skrive et svar<br>" );
define( 'FAQ_ERROR_04', "Feil tittel<br>" );
define( 'FAQ_SUBMIT_DONE_TITLE', "Fakta lagt til" );
define( 'FAQ_SUBMIT_THANKS', "Din Fakta er lagt til, men m� godkjennes av administrator.<br><br>Takk!" );
define( 'FAQ_SUBMIT_MAIL_TITLE', "En Fakta ble lagt til p� din side" );
define( 'FAQ_SUBMIT_MAIL', "En Fakta er lagt til p� din side og venter p� din aktivisering" );
define( 'FAQ_TOPICS', "Fakta Tema" );

define( 'FAQ_FORM_TITLE', "Legg til Fakta" );
define( 'FAQ_FORM_QUESTION', "Sp�rsm�l:" );
define( 'FAQ_FORM_ANSWER', "Svar:" );
define( 'FAQ_FORM_SUBMIT', "Send Fakta" );
define( 'FAQ_POSTED_BY', "Sendt inn av" );

?>
