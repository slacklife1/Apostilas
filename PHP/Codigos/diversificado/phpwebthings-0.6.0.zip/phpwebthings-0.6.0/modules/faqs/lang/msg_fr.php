<?php
// french file for phpwebthings - Eric Courtes <eric.courtes@wanadoo.fr>

define( 'NOT_LOGGED_FAQ', "Si vous �tiez inscrit vous pourriez ajouter une FAQ !<br>Pourquoi ne pas vous inscrire d�s maintenant ? c'est gratuit !" );
define( 'FAQ_TITLE', "FAQ" );
define( 'FAQ_ERROR_01', "Vous ne pouvez ajouter une faq si vous n'�tes pas inscrit<br>" );
define( 'FAQ_ERROR_02', "Vous devez fournir une question<br>" );
define( 'FAQ_ERROR_03', "Vous devez fournir une r�ponse<br>" );
define( 'FAQ_ERROR_04', "topic incorrect<br>" );
define( 'FAQ_SUBMIT_DONE_TITLE', "FAQ soumise" );
define( 'FAQ_SUBMIT_THANKS', "Votre FAQ a �t� soumise, mais elle doit �tre valid� par l'admnistrateur du site.<br><br>Merci !" );
define( 'FAQ_SUBMIT_MAIL_TITLE', "Une FAQ a �t� soumise sur votre site" );
define( 'FAQ_SUBMIT_MAIL', "Une FAQ a �t� soumise sur votre site et attend d'�tre valid�e" );
define( 'FAQ_TOPICS', "Topics FAQ" );

define( 'FAQ_FORM_TITLE', "Ajouter une FAQ" );
define( 'FAQ_FORM_QUESTION', "Question:" );
define( 'FAQ_FORM_ANSWER', "R�ponse:" );
define( 'FAQ_FORM_SUBMIT', "Poster faq" );
define( 'FAQ_POSTED_BY', "Post� par" );
?>
