<?php
// Ricardo Shiro <shiro@ricardo.shiro.nom.br>
$lang["NOT_LOGGED_FAQ"]="Se voc� j� � registrado, fa�a o Login para enviar seu FAQ.<br><br>Se voc� n�o se cadastrou ainda, <a href=newuser.php>CADASTRE-SE AGORA!</a>";
$lang["FAQ_TITLE"]="FAQ";
$lang["FAQ_ERROR_01"]="Voc� precisa estar logado para enviar um FAQ<br>";
$lang["FAQ_ERROR_02"]="Preencha a PERGUNTA<br>";
$lang["FAQ_ERROR_03"]="Preencha a RESPOSTA<br>";
$lang["FAQ_ERROR_04"]="T�pico inv�lido<br>";
$lang["FAQ_SUBMIT_DONE_TITLE"]="FAQ enviado";
$lang["FAQ_SUBMIT_THANKS"]="Seu FAQ foi enviado, mas precisa ser ativado pelo administrador.<br><br>Obrigado!";
$lang["FAQ_SUBMIT_MAIL_TITLE"]="FAQ publicado no seu site";
$lang["FAQ_SUBMIT_MAIL"]="FAQ aguardando ativa��o no seu site";
$lang["FAQ_TOPICS"]="FAQ-T�picos";

$lang["FAQ_FORM_TITLE"]="Adicionar FAQ";
$lang["FAQ_FORM_QUESTION"]="Pergunta:";
$lang["FAQ_FORM_ANSWER"]="Resposta:";
$lang["FAQ_FORM_SUBMIT"]="Postar FAQ";
$lang["FAQ_POSTED_BY"]="por";

$lang["FAQ_HEADER_1"]="T�pico";
$lang["FAQ_HEADER_2"]="�tens";

$lang["FAQ_QUESTIONS"]="Perguntas";
$lang["FAQ_ANSWERS"]="Respostas";
$lang["FAQ_GOUP"]="Voltar � lista de FAQs";
?>
