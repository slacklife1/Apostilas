With this version you can set picofday to work
as picofpage; when set at wt_config the following
line: $config["picofday_random"] = true;

Picofday will choose one picture per page hit.

See ya,

Paulo Assis
paulo@phpdbform.com