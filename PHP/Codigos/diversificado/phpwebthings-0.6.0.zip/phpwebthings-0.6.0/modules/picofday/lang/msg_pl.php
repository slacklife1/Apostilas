<?php
// polish file for phpwebthings - zombiek <pzabek@realnet.pl>

define( 'PICOFDAY_TITLE', "Fotka dnia" );
define( 'PICOFDAY_BY', "Autor" );
define( 'PICOFDAY_CLICK', "Kliknij aby powi�kszy�" );
define( 'PICOFDAY_VIEWS', "Wy�wietle�:" );
define( 'PICOFDAY_CLICKS', "Klikni��:" );
define( 'PICOFDAY_DESC', "Oto kilka fotek..." );
?>