<?php
// English file for Pic of The Day - Paulo Assis <paulo@phpdbform.com>

$lang["PICOFDAY_TITLE"] = "Pic of the Day";
$lang["PICOFDAY_BY"] = "by";
$lang["PICOFDAY_CLICK"] = "Click to enlarge";
$lang["PICOFDAY_VIEWS"] = "Total views:";
$lang["PICOFDAY_CLICKS"] = "Total cliks:";
$lang["PICOFDAY_DESC"] = "These are some pictures I've choose to put here.";
$lang["PICOFDAY_NOCAT"] = "Invalid category";
$lang["PICOFDAY_GOUP"] = "Go up one level";
?>