<?php
// Dutch file for Pic of The Day - Frank dirckx <X-a-V@langames.nl

define( 'PICOFDAY_TITLE', "Plaatje van de dag" );
define( 'PICOFDAY_BY', "Door" );
define( 'PICOFDAY_CLICK', "Klik om te vergroten" );
define( 'PICOFDAY_VIEWS', "Totaal bekeken:" );
define( 'PICOFDAY_CLICKS', "Totaal aangeklikt:" );
define( 'PICOFDAY_DESC', "Dit zijn een aantal plaatjes die we gekozen hebben voor de site." );
?>