<?php
// English file for Pic of The Day - Paulo Assis <paulo@phpdbform.com>

$lang["PICOFDAY_TITLE"]="Imagem do Dia";
$lang["PICOFDAY_BY"]="por";
$lang["PICOFDAY_CLICK"]="Clique para ampliar";
$lang["PICOFDAY_VIEWS"]="Views:";
$lang["PICOFDAY_CLICKS"]="Cliks:";
$lang["PICOFDAY_DESC"]="Aqui voc� ver� todas as imagens que j� foram e que ser�o \"IMAGENS DO DIA\".<br><br>";
$lang["PICOFDAY_NOCAT"] = "Categoria inv�lida";
$lang["PICOFDAY_GOUP"] = "Voltar um n�vel";
?>