<?php
// french file for phpwebthings - Eric Courtes <eric.courtes@wanadoo.fr>

define( 'PICOFDAY_TITLE', "Image du Jour" );
define( 'PICOFDAY_BY', "par" );
define( 'PICOFDAY_CLICK', "Cliquer pour agrandir" );
define( 'PICOFDAY_VIEWS', "Vues total :" );
define( 'PICOFDAY_CLICKS', "Clic total :" );
define( 'PICOFDAY_DESC', "Voici quelques images." );
?>