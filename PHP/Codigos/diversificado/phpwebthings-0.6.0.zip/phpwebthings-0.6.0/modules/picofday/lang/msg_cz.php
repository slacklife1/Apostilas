<?php
// English file for Pic of The Day - Paulo Assis <paulo@phpdbform.com>

define( 'PICOFDAY_TITLE', "Obr�zek dne" );
define( 'PICOFDAY_BY', "od" );
define( 'PICOFDAY_CLICK', "Pro zv�t�en� klikn�te" );
define( 'PICOFDAY_VIEWS', "Celkem zobrazen�:" );
define( 'PICOFDAY_CLICKS', "Klik� celkem:" );
define( 'PICOFDAY_DESC', "Toto jsou obr�zky kter� jsem se rozhodl sem d�t." );
?>