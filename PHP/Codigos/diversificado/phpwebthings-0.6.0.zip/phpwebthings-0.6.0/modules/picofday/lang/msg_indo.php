<?php
// Indonesia file for Pic of The Day - Iwan Setya Putra <iwan@gotcha-inc.com.com>

define( 'PICOFDAY_TITLE', "Foto Pilihan" );
define( 'PICOFDAY_BY', "oleh" );
define( 'PICOFDAY_CLICK', "Klik untuk memberpesar" );
define( 'PICOFDAY_VIEWS', "Total dilihat:" );
define( 'PICOFDAY_CLICKS', "Total klik:" );
define( 'PICOFDAY_DESC', "Ini adalah foto pilihan dari kami." );
?>