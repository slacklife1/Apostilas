<?php
// Norwegian file for Pic of The Day - Frode Joergensen <www.kulinarisk.no>

define( 'PICOFDAY_TITLE', "Dagens bilde" );
define( 'PICOFDAY_BY', "Av" );
define( 'PICOFDAY_CLICK', "Klikk for � forst�rre" );
define( 'PICOFDAY_VIEWS', "Totalt sett:" );
define( 'PICOFDAY_CLICKS', "Totalt klikk:" );
define( 'PICOFDAY_DESC', "Her er noen bilder vi har lagt ut" );
?>