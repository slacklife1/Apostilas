<?php
// English file for Articles - Paulo Assis <paulo@phpdbform.com>

$lang["ARTICLES_TITLE"]="Articles";
$lang["ARTICLES_HEADER1"]="Title";
$lang["ARTICLES_HEADER2"]="Date";
$lang["ARTICLES_POSTEDBY"]="Posted by";
$lang["ARTICLES_HEADER4"]="Views";
$lang["ARTICLES_NEXT"]="next &gt;&gt;";
$lang["ARTICLES_PREV"]="&lt;&lt; previous";
$lang["ARTICLES_LAST_TITLE"]="Last articles";
?>