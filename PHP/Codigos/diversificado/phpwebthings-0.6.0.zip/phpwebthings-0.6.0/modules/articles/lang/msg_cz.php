<?php
// English file for Articles - Paulo Assis <paulo@phpdbform.com>

define( 'ARTICLES_TITLE', "�l�nky" );
define( 'ARTICLES_HEADER1', "Titulek" );
define( 'ARTICLES_HEADER2', "Datum" );
define( 'ARTICLES_POSTEDBY', "P��sp�vek od" );
define( 'ARTICLES_HEADER4', "Zobrazen�" );
define( 'ARTICLES_NEXT', "dal�� &gt;&gt;" );
define( 'ARTICLES_PREV', "&lt;&lt; p�edchoz�" );
define( 'ARTICLES_LAST_TITLE', "Posledn� �l�nek" );
?>