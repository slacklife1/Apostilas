<?php
// Indonesia file for Pic of The Day - Iwan Setya Putra <iwan@gotcha-inc.com>

define( 'ARTICLES_TITLE', "Artikel-Artikel" );
define( 'ARTICLES_HEADER1', "Judul" );
define( 'ARTICLES_HEADER2', "Tanggal" );
define( 'ARTICLES_POSTEDBY', "Diposting oleh" );
define( 'ARTICLES_HEADER4', "Dilihat" );
define( 'ARTICLES_NEXT', "selanjutnya &gt;&gt;" );
define( 'ARTICLES_PREV', "&lt;&lt; sebelumnya" );
?>