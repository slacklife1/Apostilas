<?php
// Portugu�s Brasil para artigos - Paulo Assis <paulo@phpdbform.com>

$lang["ARTICLES_TITLE"]="Artigos";
$lang["ARTICLES_HEADER1"]="T�tulo";
$lang["ARTICLES_HEADER2"]="Data";
$lang["ARTICLES_POSTEDBY"]="Autor";
$lang["ARTICLES_HEADER4"]="Hits";
$lang["ARTICLES_NEXT"]="pr�ximo &gt;&gt;";
$lang["ARTICLES_PREV"]="&lt;&lt; anterior";
$lang["ARTICLES_LAST_TITLE"]="�ltimos artigos";
?>