<?php
// Norwegian file for Articles - Frode J�rgensen <frode@kulinarisk.no>

define( 'ARTICLES_TITLE', "Artikler" );
define( 'ARTICLES_HEADER1', "Tittel" );
define( 'ARTICLES_HEADER2', "Dato" );
define( 'ARTICLES_POSTEDBY', "Sendt inn av" );
define( 'ARTICLES_HEADER4', "Lest" );
define( 'ARTICLES_NEXT', "neste &gt;&gt;" );
define( 'ARTICLES_PREV', "&lt;&lt; forrige" );
define( 'ARTICLES_LAST_TITLE', "Siste artikkel" );
?>