<?php
// french file for phpwebthings - Eric Courtes <eric.courtes@wanadoo.fr>

define( 'ARTICLES_TITLE', "Articles" );
define( 'ARTICLES_HEADER1', "Titre" );
define( 'ARTICLES_HEADER2', "Date" );
define( 'ARTICLES_POSTEDBY', "Post� par" );
define( 'ARTICLES_HEADER4', "Vue" );
define( 'ARTICLES_NEXT', "suivant &gt;&gt;" );
define( 'ARTICLES_PREV', "&lt;&lt; pr�c�dent" );
define( 'ARTICLES_LAST_TITLE', "Derniers articles" );
?>
