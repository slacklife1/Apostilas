<?php
// Dutch file for Articles - Frank Dirckx <X-a-V@LanGames.nl>

define( 'ARTICLES_TITLE', "Artiekel" );
define( 'ARTICLES_HEADER1', "Titel" );
define( 'ARTICLES_HEADER2', "Datum" );
define( 'ARTICLES_POSTEDBY', "Geplaatst door" );
define( 'ARTICLES_HEADER4', "aantal keer bekeken" );
define( 'ARTICLES_NEXT', "volgende &gt;&gt;" );
define( 'ARTICLES_PREV', "&lt;&lt; vorge" );
define( 'ARTICLES_LAST_TITLE', "Laatste artiekel" );
?>