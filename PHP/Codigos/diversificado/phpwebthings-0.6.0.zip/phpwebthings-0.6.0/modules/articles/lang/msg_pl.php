<?php
// polish file for phpwebthings - zombiek <pzabek@realnet.pl>

define( 'ARTICLES_TITLE', "Artyku�y" );
define( 'ARTICLES_HEADER1', "Tytu�" );
define( 'ARTICLES_HEADER2', "Data" );
define( 'ARTICLES_POSTEDBY', "Dodane przez" );
define( 'ARTICLES_HEADER4', "Ogl�dane" );
define( 'ARTICLES_NEXT', "nast�pne &gt;&gt;" );
define( 'ARTICLES_PREV', "&lt;&lt; poprzednie" );
define( 'ARTICLES_LAST_TITLE', "Ostatnie artyku�y" );
?>