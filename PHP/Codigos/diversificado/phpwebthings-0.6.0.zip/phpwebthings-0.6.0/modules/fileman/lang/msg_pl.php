<?php
// polish file for phpwebthings - zombiek <pzabek@realnet.pl>

define( 'FILEMAN_TITLE', "Menad�er Plik�w" );
define( 'FILEMAN_HEADER_1', "Katalog" );
define( 'FILEMAN_HEADER_2', "Plik" );
define( 'FILEMAN_HEADER_3', "Rozmiar" );
define( 'FILEMAN_DELETE', "Skasuj" );
define( 'FILEMAN_DELETED', "Plik %s skasowany");
define( 'FILEMAN_UPLOAD', "Wybierz plik do za�adowania:" );
define( 'FILEMAN_UPLOADED', "Plik %s za�adowany");
define( 'FILEMAN_ULBUTTON', "Uploaduj" );
define( 'FILEMAN_ULTITLE', "Uploaduj plik" );
define( 'FILEMAN_RETURN', "Powr�t do listy plik�w" );
define( 'FILEMAN_ERROR_01', "Nie mo�esz korzysta� z tej strony bezpo�rednio, powinna by� u�yta przez inne strony!" );
define( 'FILEMAN_ERROR_02', "Plik jest za du�y!" );
define( 'FILEMAN_ERROR_03', "Nie mo�esz wybra� tego katalogu!" );
?>
