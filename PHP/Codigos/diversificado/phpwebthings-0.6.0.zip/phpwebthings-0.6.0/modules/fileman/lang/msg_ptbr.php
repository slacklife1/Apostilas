<?php
$lang["FILEMAN_TITLE"]="Gerenciador de arquivos";
$lang["FILEMAN_FOLDERS"]="Gerenciador de arquivos - Pastas";
$lang["FILEMAN_HEADER_1"]="Pasta";
$lang["FILEMAN_HEADER_2"]="Arquivo";
$lang["FILEMAN_HEADER_3"]="Tamanho";
$lang["FILEMAN_DELETE"]="Apagar";
$lang["FILEMAN_DELETED"]="Arquivo %s exclu�do";
$lang["FILEMAN_UPLOAD"]="Selecione um arquivo para enviar:";
$lang["FILEMAN_UPLOADED"]="Arquivo %s recebido";
$lang["FILEMAN_ULBUTTON"]="Enviar";
$lang["FILEMAN_ULTITLE"]="Enviar arquivo";
$lang["FILEMAN_RETURN"]="Retornar � lista de arquivos";
$lang["FILEMAN_ERROR_01"]="You can't access this page directly, it should be used by other pages!";
$lang["FILEMAN_ERROR_02"]="Arquivo enviado muito grande!";
$lang["FILEMAN_ERROR_03"]="Voc� n�o pode selecionar esta pasta!";
$lang["FILEMAN_ERROR_04"]="Somente imagens s�o permitidas!";
?>
