<?php
// English lang file for fileman - Oleg Kourapov <ok@2sheds.ru>

define( 'FILEMAN_TITLE', "File Manager" );
define( 'FILEMAN_HEADER_1', "Slo�ka" );
define( 'FILEMAN_HEADER_2', "Soubor" );
define( 'FILEMAN_HEADER_3', "Velikost" );
define( 'FILEMAN_DELETE', "Smazat" );
define( 'FILEMAN_DELETED', "Soubor(y) % smaz�ny");
define( 'FILEMAN_UPLOAD', "Vybrat soubor pro upload:" );
define( 'FILEMAN_UPLOADED', "Soubor(y) % uploadov�ny");
define( 'FILEMAN_ULBUTTON', "Uploadovat" );
define( 'FILEMAN_ULTITLE', "Uploadovat soubor" );
define( 'FILEMAN_RETURN', "Zp�t k seznamu " );
define( 'FILEMAN_ERROR_01', "Nem��ete k t�to str�nce p�istoupit p��mo, pou�ijte pros�m jinou stranu!" );
define( 'FILEMAN_ERROR_02', "Soubor pro uplodov�n� je p��li� velk�!" );
define( 'FILEMAN_ERROR_03', "Tuto slo�ku nelze vybrat!" );
?>
