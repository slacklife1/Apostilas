<?php
// English lang file for fileman - Oleg Kourapov <ok@2sheds.ru>

define( 'FILEMAN_TITLE', "Gestionnaire de Fichier" );
define( 'FILEMAN_HEADER_1', "Fichier" );
define( 'FILEMAN_HEADER_2', "Date" );
define( 'FILEMAN_HEADER_3', "Taille" );
define( 'FILEMAN_DELETE', "Supprimer" );
define( 'FILEMAN_DELETED', "Fichier %s supprim�");
define( 'FILEMAN_UPLOAD', "S�lectionner un fichier transf�rer:" );
define( 'FILEMAN_UPLOADED', "Fichier %s transf�r�");
define( 'FILEMAN_ULBUTTON', "Transf�rer" );
define( 'FILEMAN_ULTITLE', "Transfert de fichier" );
define( 'FILEMAN_RETURN', "Retour � la liste des fichiers" );
define( 'FILEMAN_ERROR_01', "Vous ne pouvez acc�der � cette page directement, elle doit �tre utilis� par d'autres pages!" );
define( 'FILEMAN_ERROR_02', "Le fichier transf�r� est trop grand!" );
define( 'FILEMAN_ERROR_03', "Vous ne pouvez pas choisir ce dossier!" );
?>
