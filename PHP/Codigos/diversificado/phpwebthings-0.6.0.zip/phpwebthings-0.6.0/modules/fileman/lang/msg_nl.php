<?php
// Dutch lang file for fileman - Frank Dirckx <X-a-V@langames.nl>

define( 'FILEMAN_TITLE', "Bestanden Beheren" );
define( 'FILEMAN_HEADER_1', "Map" );
define( 'FILEMAN_HEADER_2', "Bestand" );
define( 'FILEMAN_HEADER_3', "Grote" );
define( 'FILEMAN_DELETE', "Verwijder" );
define( 'FILEMAN_DELETED', "Bestand %s is Verwijdert");
define( 'FILEMAN_UPLOAD', "Selekteer een bestand voor upload:" );
define( 'FILEMAN_UPLOADED', "Bestand %s is geupload");
define( 'FILEMAN_ULBUTTON', "Upload" );
define( 'FILEMAN_ULTITLE', "Upload Bestand" );
define( 'FILEMAN_RETURN', "Terug naar bestanden lijst" );
define( 'FILEMAN_ERROR_01', "je kan deze pagina niet derekt bekijken, het moet gebruikt worden door andere pagina's!" );
define( 'FILEMAN_ERROR_02', "Geuploade Bestand is tegroot!" );
define( 'FILEMAN_ERROR_03', "Deze map kan je niet selekteren!" );
?>
