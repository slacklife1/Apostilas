<?php
// This is the config file for the module
// the four lines below enable this module at the modules list
$config_var["modules"]["contact"]["type"] = "checkbox";
$config_var["modules"]["contact"]["desc"] = "Contact Us";
$config_var["modules"]["contact"]["default"] = true;
$config_var["modules"]["contact"]["obs"] = "Allow users to send an e-mail for you using the site.";

// these lines are for configuration of the current module
?>