<?php
// english file for messages - Abu Mami <admin@abumami.com>
define( 'CONTACT_TITLE', "Contact" );
define( 'CONTACT_SEND', "Contactez nous..." );
define( 'CONTACT_SEND_TITLE', "Sujet:" );
define( 'CONTACT_SEND_TEXT', "Message:" );
define( 'CONTACT_SEND_BUTTON_S', "Envoyer message" );
define( 'CONTACT_SEND_ERROR_01', "Veuillez entrer le sujet du message et son contenu" );
define( 'CONTACT_SEND_ERROR_02', "Vous avez indiqu� une adresse email incorrecte." );
define( 'CONTACT_SEND_ERROR_03', "Impossible de transmettre ! Veuillez r�-�ssayer ult�rieurement." );
?>
