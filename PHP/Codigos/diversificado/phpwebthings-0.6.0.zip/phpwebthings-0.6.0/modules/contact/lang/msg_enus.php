<?php
// english file for messages - Abu Mami <admin@abumami.com>
$lang["CONTACT_TITLE"]="Contact us";
$lang["CONTACT_SEND"]="Contact us...";
$lang["CONTACT_SEND_TITLE"]="Subject:";
$lang["CONTACT_SEND_TEXT"]="Message: (html tags not allowable)";
$lang["CONTACT_SEND_BUTTON_S"]="Send message";
$lang["CONTACT_SEND_ERROR_01"]="Please enter a subject and a message";
$lang["CONTACT_SEND_ERROR_02"]="You supplied an invalid email address.";
$lang["CONTACT_SEND_ERROR_03"]="Unable to send! Please try again later.";
$lang["CONTACT_NOT_LOGGED"]="You are not logged in, please enter in your email address:";
$lang["CONTACT_SEND_SENT"]="E-mail sent. Soon we will respond for you. Thanks for coming.";
?>