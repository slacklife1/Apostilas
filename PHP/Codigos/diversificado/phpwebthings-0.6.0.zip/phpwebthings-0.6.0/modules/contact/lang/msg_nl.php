<?php
// english file for messages - Frank Dirckx <X-a-V@langames.nl>
define( 'CONTACT_TITLE', "Contact ons" );
define( 'CONTACT_SEND', "Contact ons..." );
define( 'CONTACT_SEND_TITLE', "Onderwerp:" );
define( 'CONTACT_SEND_TEXT', "Bericht:" );
define( 'CONTACT_SEND_BUTTON_S', "Verstuur Bericht" );
define( 'CONTACT_SEND_ERROR_01', "type een onderwerp en bericht in" );
define( 'CONTACT_SEND_ERROR_02', "je hebt een verkeerd e-mail adress ingevoerd." );
define( 'CONTACT_SEND_ERROR_03', "het is niet mogelijk om je bericht nu teversturen! Probeer later nog eens." );
?>