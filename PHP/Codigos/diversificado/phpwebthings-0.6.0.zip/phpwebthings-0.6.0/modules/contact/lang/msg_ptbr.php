<?php
// Brazilian Portuguese by Paulo Assis

$lang["CONTACT_TITLE"]="Entre em contato";
$lang["CONTACT_SEND"]="Entre em contato...";
$lang["CONTACT_SEND_TITLE"]="Assunto:";
$lang["CONTACT_SEND_TEXT"]="Mensagem: (tags html n�o s�o aceitas)";
$lang["CONTACT_SEND_BUTTON_S"]="Enviar mensagem";
$lang["CONTACT_SEND_ERROR_01"]="Por favor informe um assunto e uma mensagem";
$lang["CONTACT_SEND_ERROR_02"]="O e-mail informado &eacute; inv&aacute;lido.";
$lang["CONTACT_SEND_ERROR_03"]="Erro ao enviar! Por favor tente novamente mais tarde.";
$lang["CONTACT_NOT_LOGGED"]="Voc� n�o se logou, por favor informe seu e-mail:";
$lang["CONTACT_SEND_SENT"]="E-mail enviado. Em breve iremos responder. Obrigado.";
?>