<?php
// lang file for comments

define( 'COMMENTS_NUM', "koment��e" );
define( 'COMMENTS_TITLE', "koment��e" );
define( 'COMMENTS_FORM_TITLE', "Poslat koment��" );
define( 'COMMENTS_FIELD', "p�idat koment��:" );
define( 'COMMENTS_POST', "POslat koment��" );
define( 'COMMENTS_ADDED', "Koment�� p�id�n" );
define( 'COMMENTS_DELETED', "Koment�� smaz�n" );
define( 'NOT_LOGGED_COMMENTS', "Je mi l�to, ale pro posl�n� koment��e se mus�te nalogovat. Pokud nem�te login, pro� se neregistrovat? je to Z D A R M A! :)" );
?>