<?php
// lang file for comments

$lang["COMMENTS_NUM"]="coment�rios";
$lang["COMMENTS_TITLE"]="Coment�rios";
$lang["COMMENTS_FORM_TITLE"]="Envie seu coment�rio";
$lang["COMMENTS_FIELD"]="Coment�rio:";
$lang["COMMENTS_POST"]="Enviar";
$lang["COMMENTS_ADDED"]="Coment�rio enviado";
$lang["COMMENTS_DELETED"]="Coment�rio exclu�do";
$lang["NOT_LOGGED_COMMENTS"]="Se voc� j� � registrado, fa�a o Login para enviar seu coment�rio.<br><br>Se voc� n�o se cadastrou ainda, <a href=newuser.php>CADASTRE-SE AGORA!</a>";
?>