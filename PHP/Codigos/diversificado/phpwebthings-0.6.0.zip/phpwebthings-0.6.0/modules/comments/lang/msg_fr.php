<?php
// french file for phpwebthings - Eric Courtes <eric.courtes@wanadoo.fr>

define( 'COMMENTS_NUM', "commentaires" );
define( 'COMMENTS_TITLE', "commentaires" );
define( 'COMMENTS_FORM_TITLE', "Envoyer un commentaire" );
define( 'COMMENTS_FIELD', "Ajouter un commentaire :" );
define( 'COMMENTS_POST', "Poster un commentaire" );
define( 'COMMENTS_ADDED', "Commentaire ajouter" );
define( 'COMMENTS_DELETED', "Commentaire supprim�" );
define( 'NOT_LOGGED_COMMENTS', "Si vous �tiez inscrit, vous pourriez poster un commentaire. Si vous n'�tes pas inscrit, pourquoi ne pas vous inscrire ? C'est gratuit !" );
?>