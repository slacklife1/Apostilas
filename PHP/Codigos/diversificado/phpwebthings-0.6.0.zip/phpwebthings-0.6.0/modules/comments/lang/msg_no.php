<?php
// Norwegian lang file for comments

define( 'COMMENTS_NUM', "Kommentarer" );
define( 'COMMENTS_TITLE', "Kommentar" );
define( 'COMMENTS_FORM_TITLE', "Legg inn kommentar" );
define( 'COMMENTS_FIELD', "Legg til din kommentar:" );
define( 'COMMENTS_POST', "Send kommentar" );
define( 'COMMENTS_ADDED', "Kommentar lagt til" );
define( 'COMMENTS_DELETED', "Kommentar slettet" );
define( 'NOT_LOGGED_COMMENTS', "Hvis du var logget p� kunne du ha lagt til en kommentar. Hvis du ikke har et brukernavn, hvorfor registrerer du deg ikke? Det er gratis!" );
?>