<?php
// lang file for comments

define( 'COMMENTS_NUM', "komentar" );
define( 'COMMENTS_TITLE', "komentar" );
define( 'COMMENTS_FORM_TITLE', "Kirim komentar anda" );
define( 'COMMENTS_FIELD', "Tambah komentar anda:" );
define( 'COMMENTS_POST', "Posting komentar" );
define( 'COMMENTS_ADDED', "Komentar telah tercatat" );
define( 'COMMENTS_DELETED', "Komentar dihapus" );
define( 'NOT_LOGGED_COMMENTS', "Jika anda anggota anda bisa kirim komentar. Bila anda ingin mendaftar, silahkan e-mail webmaster@stieken.ac.id" );
?>