<?php
// Dutch file for comments - Frank Dirckx <X-a-V@langames.nl>


define( 'COMMENTS_NUM', "Reakties" );
define( 'COMMENTS_TITLE', "Reakties" );
define( 'COMMENTS_FORM_TITLE', "Verstuurje Reaktie" );
define( 'COMMENTS_FIELD', "Voeg je reaktie toe:" );
define( 'COMMENTS_POST', "Plaats Reaktie" );
define( 'COMMENTS_ADDED', "Reaktie toegevoegt" );
define( 'COMMENTS_DELETED', "Reaktie verwijdert" );
define( 'NOT_LOGGED_COMMENTS', "als je ingelogt was had je wel een reaktie kunnen plaatsten. als je geen login hebt, registreer dan even, Het is gratis!" );
?>