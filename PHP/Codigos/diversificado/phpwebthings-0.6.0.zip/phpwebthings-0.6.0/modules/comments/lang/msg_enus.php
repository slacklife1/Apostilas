<?php
// lang file for comments

$lang["COMMENTS_NUM"]="comments";
$lang["COMMENTS_TITLE"]="comments";
$lang["COMMENTS_FORM_TITLE"]="Send your comment";
$lang["COMMENTS_FIELD"]="Add your comment:";
$lang["COMMENTS_POST"]="Post comment";
$lang["COMMENTS_ADDED"]="Comment added";
$lang["COMMENTS_DELETED"]="Comment deleted";
$lang["NOT_LOGGED_COMMENTS"]="If you were logged you could send a comment. If don't have a login, why don't you register? It's free!";
?>