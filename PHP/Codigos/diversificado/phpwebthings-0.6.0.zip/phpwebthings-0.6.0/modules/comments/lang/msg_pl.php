<?php
// polish file for phpwebthings - zombiek <pzabek@realnet.pl>

define( 'COMMENTS_NUM', "komentarze" );
define( 'COMMENTS_TITLE', "komentarze" );
define( 'COMMENTS_FORM_TITLE', "Dodaj sw�j komentarz" );
define( 'COMMENTS_FIELD', "Dodaj komentarz:" );
define( 'COMMENTS_POST', "Wy�lij komentarz" );
define( 'COMMENTS_ADDED', "Komentarz dodany" );
define( 'COMMENTS_DELETED', "Komentarz skasowany" );
define( 'NOT_LOGGED_COMMENTS', "Tylko zarejestrowany u�ytkownik mo�e dodawa� komentarze. Je�li nie masz swojego konta to zarejestruj si�! Rejestracja jest darmowa!" );
?>