<?php
// This is the config file for the module
// the four lines below enable this module at the modules list
$config_var["modules"]["comments"]["type"] = "checkbox";
$config_var["modules"]["comments"]["desc"] = "Comments";
$config_var["modules"]["comments"]["default"] = false;
$config_var["modules"]["comments"]["obs"] = "Enable comments for several modules.";

// these lines are for configuration of the current module
//$config_var["comments"][""]["type"] = "";
//$config_var["comments"][""]["desc"] = "";
//$config_var["comments"][""]["default"] = false;
//$config_var["comments"][""]["obs"] = "";

?>
