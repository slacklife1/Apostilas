<?php
echo "this is a php code inside a text box:<br>";
for( $i=1; $i<=5; $i++ ) echo "$i ";

?>
