<?php
// This is the config file for the module
// the four lines below enable this module at the modules list
$config_var["modules"]["sideboxes"]["type"] = "checkbox";
$config_var["modules"]["sideboxes"]["desc"] = "Sideboxes";
$config_var["modules"]["sideboxes"]["default"] = true;
$config_var["modules"]["sideboxes"]["obs"] = "Manage drawing of boxes at the sides of the site.";

// these lines are for configuration of the current module
?>