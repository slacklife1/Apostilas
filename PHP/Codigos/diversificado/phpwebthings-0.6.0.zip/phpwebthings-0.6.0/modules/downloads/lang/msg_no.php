<?php
// Norwegian lang file for downloads

define( 'DOWNLOAD_TITLE', "Nedlasting" );
define( 'DOWNLOAD_HEADER_1', "Fil" );
define( 'DOWNLOAD_HEADER_2', "Dato" );
define( 'DOWNLOAD_HEADER_3', "St�rrelse" );
define( 'DOWNLOAD_HEADER_4', "Treff" );
define( 'DOWNLOAD_HEADER_5', "Karakterer" );
define( 'DOWNLOAD_FILE', "Last ned" );
define( 'DOWNLOAD_CLICK', "Forst�rr" );
define( 'DOWNLOAD_BACK', "tilbake til Nedlasting" );
?>