<?php
// polish file for phpwebthings - zombiek <pzabek@realnet.pl>

define( 'DOWNLOAD_TITLE', "Pliki do �ci�gni�cia" );
define( 'DOWNLOAD_HEADER_1', "Plik" );
define( 'DOWNLOAD_HEADER_2', "Data" );
define( 'DOWNLOAD_HEADER_3', "Rozmiar" );
define( 'DOWNLOAD_HEADER_4', "Pobra�" );
define( 'DOWNLOAD_HEADER_5', "Ocena" );
define( 'DOWNLOAD_FILE', "�ci�gnij Plik" );
define( 'DOWNLOAD_CLICK', "Kliknij aby powi�kszy�" );
define( 'DOWNLOAD_BACK', "Powr�t to downloads" );
?>