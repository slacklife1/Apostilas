<?php
// lang file for downloads

$lang["DOWNLOAD_TITLE"]="Downloads";
$lang["DOWNLOAD_TITLECAT"]="Downloads Categories";
$lang["DOWNLOAD_HEADER_1"]="File";
$lang["DOWNLOAD_HEADER_2"]="Date";
$lang["DOWNLOAD_HEADER_3"]="File size";
$lang["DOWNLOAD_HEADER_4"]="Downloads";
$lang["DOWNLOAD_HEADER_5"]="User rating";
$lang["DOWNLOAD_FILE"]="Download the file";
$lang["DOWNLOAD_CLICK"]="Click to enlarge";
$lang["DOWNLOAD_BACK"]="Back to downloads";
$lang["DOWNLOAD_SEARCH"]="Search";
$lang["DOWNLOAD_NEXT"]="Next";
$lang["DOWNLOAD_PREVIOUS"]="Previous";
$lang["DOWNLOAD_CATEGORY"]="Category";
$lang["DOWNLOAD_COUNT"]="Count";
$lang["DOWNLOAD_ERROR01"]="Invalid category";
$lang["DOWNLOAD_GOUP"] = "Go up one level";
$lang["DOWNLOAD_RATEIT"] = "Rate it!";
$lang["DOWNLOAD_RATE01"] = "Bad";
$lang["DOWNLOAD_RATE02"] = "";
$lang["DOWNLOAD_RATE03"] = "";
$lang["DOWNLOAD_RATE04"] = "";
$lang["DOWNLOAD_RATE05"] = "Regular";
$lang["DOWNLOAD_RATE06"] = "";
$lang["DOWNLOAD_RATE07"] = "";
$lang["DOWNLOAD_RATE08"] = "";
$lang["DOWNLOAD_RATE09"] = "Good";
$lang["DOWNLOAD_RATE10"] = "Excelent!";
$lang["DOWNLOAD_FILES"] = "Files";

?>