<?php
// lang file for downloads

define( 'DOWNLOAD_TITLE', "Ke sta�en�" );
define( 'DOWNLOAD_HEADER_1', "Soubor" );
define( 'DOWNLOAD_HEADER_2', "Datum" );
define( 'DOWNLOAD_HEADER_3', "Velikost" );
define( 'DOWNLOAD_HEADER_4', "po�et sta�en�" );
define( 'DOWNLOAD_HEADER_5', "Rating" );
define( 'DOWNLOAD_FILE', "St�hnot soubor" );
define( 'DOWNLOAD_CLICK', "Pro zv�t�en� klikn�te" );
define( 'DOWNLOAD_BACK', "Zp�t Ke sta�en�" );
?>