<?php
// lang file for downloads

define( 'DOWNLOAD_TITLE', "File Download" );
define( 'DOWNLOAD_HEADER_1', "File" );
define( 'DOWNLOAD_HEADER_2', "Tanggal" );
define( 'DOWNLOAD_HEADER_3', "Ukuran" );
define( 'DOWNLOAD_HEADER_4', "Hits" );
define( 'DOWNLOAD_HEADER_5', "Penilaian" );
define( 'DOWNLOAD_FILE', "File Download" );
define( 'DOWNLOAD_CLICK', "Klik untuk memperbesar" );
define( 'DOWNLOAD_BACK', "kembali ke download file" );
?>