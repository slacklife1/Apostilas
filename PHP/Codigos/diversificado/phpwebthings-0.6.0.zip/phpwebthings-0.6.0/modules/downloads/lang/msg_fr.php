<?php
// french file for phpwebthings - Eric Courtes <eric.courtes@wanadoo.fr>

define( 'DOWNLOAD_TITLE', "T�l�chargements" );
define( 'DOWNLOAD_HEADER_1', "Fichier" );
define( 'DOWNLOAD_HEADER_2', "Date" );
define( 'DOWNLOAD_HEADER_3', "Taille" );
define( 'DOWNLOAD_HEADER_4', "Hits" );
define( 'DOWNLOAD_HEADER_5', "Rates" );
define( 'DOWNLOAD_FILE', "Transfert le fichier" );
define( 'DOWNLOAD_CLICK', "Clic pour agrandir" );
define( 'DOWNLOAD_BACK', "Retour au t�l�chargement" );
define( 'DOWNLOAD_SEARCH', "Recherche" );
define( 'DOWNLOAD_NEXT', "Suivant" );
define( 'DOWNLOAD_PREVIOUS', "Pr�c�dent" );
define( 'DOWNLOAD_CATEGORY', "Cat�gorie" );
define( 'DOWNLOAD_COUNT', "Nombre" );
?>
