<?php
// Dutch file for Downloads - Frank Dirckx <X-a-V@langames.nl>

define( 'DOWNLOAD_TITLE', "Downloads" );
define( 'DOWNLOAD_HEADER_1', "Bestand" );
define( 'DOWNLOAD_HEADER_2', "Datum" );
define( 'DOWNLOAD_HEADER_3', "Grote" );
define( 'DOWNLOAD_HEADER_4', "Hits" );
define( 'DOWNLOAD_HEADER_5', "Rates" );
define( 'DOWNLOAD_FILE', "Download het bestand" );
define( 'DOWNLOAD_CLICK', "Klik om te vergroten" );
define( 'DOWNLOAD_BACK', "Terug naar downloads" );
?>