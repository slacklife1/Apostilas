<?php
// lang file for downloads

$lang["DOWNLOAD_TITLE"]="Downloads";
$lang["DOWNLOAD_TITLECAT"]="Categorias de downloads";
$lang["DOWNLOAD_HEADER_1"]="Arquivo";
$lang["DOWNLOAD_HEADER_2"]="Data";
$lang["DOWNLOAD_HEADER_3"]="Tamanho";
$lang["DOWNLOAD_HEADER_4"]="Downloads";
$lang["DOWNLOAD_HEADER_5"]="Avalia��o";
$lang["DOWNLOAD_FILE"]="Pegue o arquivo";
$lang["DOWNLOAD_CLICK"]="Clique para ampliar";
$lang["DOWNLOAD_BACK"]="Voltar para downloads";
$lang["DOWNLOAD_SEARCH"]="Procurar";
$lang["DOWNLOAD_NEXT"]="Pr�ximo";
$lang["DOWNLOAD_PREVIOUS"]="Anterior";
$lang["DOWNLOAD_CATEGORY"]="Categoria";
$lang["DOWNLOAD_COUNT"]="Qtde";
$lang["DOWNLOAD_ERROR01"]="Categoria inv�lida";
$lang["DOWNLOAD_GOUP"] = "Voltar um n�vel";
$lang["DOWNLOAD_RATEIT"] = "Avalie!";
$lang["DOWNLOAD_RATE01"] = "P�ssimo";
$lang["DOWNLOAD_RATE02"] = "";
$lang["DOWNLOAD_RATE03"] = "";
$lang["DOWNLOAD_RATE04"] = "";
$lang["DOWNLOAD_RATE05"] = "Regular";
$lang["DOWNLOAD_RATE06"] = "";
$lang["DOWNLOAD_RATE07"] = "";
$lang["DOWNLOAD_RATE08"] = "";
$lang["DOWNLOAD_RATE09"] = "Bom";
$lang["DOWNLOAD_RATE10"] = "Excelente!";
$lang["DOWNLOAD_FILES"] = "Arquivos";
?>