<?php
// polish file for phpwebthings - zombiek <pzabek@realnet.pl>
define( 'NOT_LOGGED_UMSG', "Musisz si� zalogowa� aby zobaczy� swoje wiadomo�ci. Je�li nie masz swojego konta, zarejestruj si�!" );
define( 'UMSG_TITLE', "Wy�lij wiadomo��" );
define( 'UMSG_HEADER', "Wiadomo�ci od " );
define( 'UMSG_HEADER_1', "Od" );
define( 'UMSG_HEADER_2', "Tytu�" );
define( 'UMSG_HEADER_3', "Data" );
define( 'UMSG_HEADER_4', "Czytane" );
define( 'UMSG_HEADER_5', "kliknij tu aby skasow�" );
define( 'UMSG_REPLY', "Odpowiedz na wiadomo��" );
define( 'UMSG_SEND', "Wy�lij wiadomo�� do innego u�ytkownika" );
define( 'UMSG_DELETE', "Wiadomo�� skasowana." );
define( 'UMSG_SEND_TO', "Do:" );
define( 'UMSG_SEND_TITLE', "Tytu�:" );
define( 'UMSG_SEND_TEXT', "Tre��:" );
define( 'UMSG_SEND_BUTTON_R', "Odpowiedz" );
define( 'UMSG_SEND_BUTTON_S', "Wy�lij" );
define( 'UMSG_SEND_ADD_USER', "Mo�esz doda� u�ytkownik�w na stronie \"Moje Konto\"." );
define( 'UMSG_SEND_ERROR_01', "Nie mo�esz wys�a� wiadomo�ci bez tytu�u i/lub tre�ci" );
define( 'UMSG_SEND_ERROR_02', "Nie mo�esz wys�a� wiadomo�ci do nikogo" );
define( 'UMSG_BACK', "Powr�t do wiadomo�ci" );
define( 'UMSG_MESSAGES', "<br>Jest %d %snowych wiadomo�ci%s do Ciebie" );
?>