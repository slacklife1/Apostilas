<?php
// english file for messages - Paulo Assis <paulo@phpdbform.com>
define( 'NOT_LOGGED_UMSG', "Je mi l�to, ale pro zobrazen� va�ich zpr�v se mus�te nalogovat. Pokud nem�te login, pro� se neregistrovat? je to Z D A R M A! :)" );
define( 'UMSG_TITLE', "Zpr�vy" );
define( 'UMSG_HEADER', "Zpr�vy pro " );
define( 'UMSG_HEADER_1', "Od" );
define( 'UMSG_HEADER_2', "Titulek" );
define( 'UMSG_HEADER_3', "Datum" );
define( 'UMSG_HEADER_4', "��st" );
define( 'UMSG_HEADER_5', "Klikn�te pro smaz�n� zpr�vy" );
define( 'UMSG_REPLY', "Odpov�d�t na zpr�vu" );
define( 'UMSG_SEND', "Zaslat zpr�vu dal��mu u�ivateli" );
define( 'UMSG_DELETE', "Zpr�va smaz�na." );
define( 'UMSG_SEND_TO', "Pro:" );
define( 'UMSG_SEND_TITLE', "Titulek:" );
define( 'UMSG_SEND_TEXT', "Text:" );
define( 'UMSG_SEND_BUTTON_R', "Odpov�d�t na zpr�vu" );
define( 'UMSG_SEND_BUTTON_S', "Poslat zpr�vu" );
define( 'UMSG_SEND_ADD_USER', "M��ete p�idat u�ivatele do va�eho seznamu na str�nce \"My Account\"." );
define( 'UMSG_SEND_ERROR_01', "Nem��ete poslat zpr�vu bez titulku a/nebo textu" );
define( 'UMSG_SEND_ERROR_02', "Bohu�el nejde zaslat zpr�vu panu NIKDO" );
define( 'UMSG_BACK', "Zp�t na zpr�vy" );
define( 'UMSG_MESSAGES', "<br>M�me celkem  %d %s nov�ch zpr�v pro v�s" );
?>