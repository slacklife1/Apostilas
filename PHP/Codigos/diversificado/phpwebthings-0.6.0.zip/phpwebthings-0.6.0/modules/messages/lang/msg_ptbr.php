<?php
// english file for messages - Paulo Assis <paulo@phpdbform.com>
$lang["NOT_LOGGED_UMSG"]="Se voc� j� � registrado, fa�a o Login para enviar sua mensagem.<br><br>Se voc� n�o se cadastrou ainda, <a href=newuser.php>CADASTRE-SE AGORA!</a>";
$lang["UMSG_TITLE"]="Mensagens";
$lang["UMSG_HEADER"]="Mensagens para ";
$lang["UMSG_HEADER_1"]="De";
$lang["UMSG_HEADER_2"]="T�tulo";
$lang["UMSG_HEADER_3"]="Data";
$lang["UMSG_HEADER_4"]="Lida";
$lang["UMSG_HEADER_5"]="Deletar mensagem";
$lang["UMSG_REPLY"]="Responder";
$lang["UMSG_SEND"]="Enviar mensagem";
$lang["UMSG_DELETE"]="Mensagem deletada.";
$lang["UMSG_SENT"]="Mensagem enviada.";
$lang["UMSG_SEND_TO"]="Para:";
$lang["UMSG_SEND_TITLE"]="T�tulo:";
$lang["UMSG_SEND_TEXT"]="Texto:";
$lang["UMSG_SEND_BUTTON_R"]="Responder";
$lang["UMSG_SEND_BUTTON_S"]="Enviar";
$lang["UMSG_SEND_ADD_USER"]="Voc� pode adicionar usu�rios em \"Minha Conta\".";
$lang["UMSG_SEND_ERROR_01"]="Voc� n�o pode enviar uma mensagem se n�o contiver um T�tulo e/ou Texto";
$lang["UMSG_SEND_ERROR_02"]="Voc� n�o pode enviar uma mensagem para NINGU�M";
$lang["UMSG_BACK"]="Voltar para Mensagens";
$lang["UMSG_MESSAGES"]="<br>%d %snovas mensagens%s para voc�";
$lang["UMSG_FLD_INBOX"]="Caixa de entrada";
$lang["UMSG_FLD_SENT"]="�tens enviados";
$lang["UMSG_DELETE_MSG"]="Exlcuir mensagens selecionadas";
$lang["UMSG_DELETE_MSG2"]="Excluir mensagem";
?>