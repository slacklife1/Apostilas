// mAd - Advert Rotation Manager //

// Version 0.3                   //
// 18th December 2003            //

// Created by Ian Bennett        //
// ian at ianbennett dot net     //
// w3 dot ianbennett dot net     //


LICENCE
=======
This program is provided under the agreement that it is used only for the
display of rotating image links on a website.
It may be used to gain profit by using it as a tool to display advertisements.
It must not be repackaged or provided under another name; displayed as being
by another person, or sold for profit.
You install this program at your own risk, and you agree not to hold me
liable to any damage incurred by using it.
Support is not provided, however there is a support forum at
http://www.w00ty.com/forum where you can get help.
If you agree to the terms, then go ahead and install ^_-


INTRO
=====
mAd is a web-based program for maintaining a number of adverts on a
website, when you want one image advert on the screen. Every time the page
loads (or pages load ^_-), mAd will select an ad from the database, and
show it along with it linking to wherever you want it to.

mAd also keeps track of how many times each ad has been shown, and how many
times they've been clicked on by your site visitors. These figures are
freely available on a stats page, which you can edit to suit your own site
design.

The new v0.3 adds a number of new features: skinning options, individual stats
pages with password protection, and customisable stat values being some of them.


REQUIREMENTS
============
To use mAd, you must first have webspace capable of parsing PHP (this version
should be most compatible with version 4.3.4 but other versions should work
fine). You must also have a MySQL database to store ad data in. This program
uses one MySQL table.


INSTALLATION
============

Install mAd from scratch -
1: Create a folder in your webspace for mAd, and name it whatever you like.
2: Make sure the CHMOD setting (sometimes called permission settings) of this
   folder is at one of these settings (different wordings of the same setting):
   755
   rwxr--r--
   Owner: read, write, execute; Group: read; World: read
3: Upload the install.php file into this folder.
4: Open your browser and go to the URL where the install.php file is.
5: Type the username and password you want to log into mAd with, into the first
   two text boxes. Your password will be visible as you type it in.
6: In the second set of text boxes, insert the information you insert to use
   your MySQL database. The location is usually "localhost" (the same server);
   the database is the name of the database you're using; the table is the name
   you want mAd to create inside the database, and the username and password
   are the ones you use to log in to the database.
7: Once you are sure your information is correct, click the "Install mAd"
   button.
8: A results page will appear telling you whether the installation was
   completed successfully. If not, check your settings and try again. If it
   continues to fail, you may have to use the manual installer instead.
9: Go to the folder you uploaded the installer, where mAd should be installed.

Update an out-of-date installation -
 * This pack will update all previous versions of mAd.
1: Make sure the CHMOD setting (sometimes called permission settings) of the
   folder you installed mAd in is 755 (see above for other wordings).
2: Upload the install.php file into the folder you installed mAd in.
3: Open your browser and go to the URL where the install.php file is.
4: Check the "Update from existing installation" checkbox, and click the
   "Install mAd" button.
5: A results page will appear telling you whether the update was completed
   successfully.
6: Use mAd as usual.


USAGE
=====
Instructions on the usage of mAd are in the program itself.


==============================
mAd copyright Ian Bennett 2003