<?php

///////////////////////////////////
// mAd - Advert Rotation Manager //
///////////////////////////////////
// Version 0.3                   //
///////////////////////////////////
// Created by Ian Bennett        //
// ian at ianbennett dot net     //
// w3 dot ianbennett dot net     //
///////////////////////////////////
// This program is provided      //
// under the agreement that it   //
// is used only for the display  //
// of rotating image links on a  //
// website.                      //
///////////////////////////////////
// It may be used to gain profit //
// by using it as a tool to      //
// display advertisements.       //
// Just remember who made this   //
// thing when you're rakin' the  //
// papers!                       //
///////////////////////////////////
// It must not be repackaged or  //
// provided under another name;  //
// displayed as being by another //
// person, or sold for profit.   //
///////////////////////////////////
// If you agree to the terms,    //
// then go ahead and install ^_- //
///////////////////////////////////
// Any bugs, comments or         //
// suggestions, go to my forum @ //
// http://www.w00ty.com/forum    //
///////////////////////////////////

if ($confirm == "yes") {
	$success = '<font color="green"><b>Success!</b></font>';
	$failure = '<font color="red"><b>Failed</b></font>';
	$skipped = '<font color="orange"><b>Skipped</b></font>';

// INDEX.PHP
$install_file_index = <<<TXT
<?php
///////////////////////////////////
// mAd - Advert Rotation Manager //
///////////////////////////////////
// Version 0.3                   //
///////////////////////////////////
// Created by Ian Bennett        //
// ian at ianbennett dot net     //
// w3 dot ianbennett dot net     //
///////////////////////////////////
// This program is provided      //
// under the agreement that it   //
// is used only for the display  //
// of rotating image links on a  //
// website.                      //
///////////////////////////////////
// It may be used to gain profit //
// by using it as a tool to      //
// display advertisements.       //
// Just remember who made this   //
// thing when you're rakin' the  //
// papers!                       //
///////////////////////////////////
// It must not be repackaged or  //
// provided under another name;  //
// displayed as being by another //
// person, or sold for profit.   //
///////////////////////////////////
// Any bugs, comments or         //
// suggestions, go to my forum @ //
// http://www.w00ty.com/forum    //
///////////////////////////////////
\$mad_version = 0.3;
\$current_time = time();
session_start();
if (\$act == "logout") {
	unset(\$_SESSION);
	session_destroy();
}
if (!\$_SESSION['user']) {
	require "config/user.php";
	if ((addslashes(\$input_user) == \$config_user) && (addslashes(\$input_pass) == \$config_pass)) {
		\$_SESSION['user'] = \$input_user;
		header("Location: \$PHP_SELF");
		exit();
	}
	else {
		\$content = <<<HTML
<h3>Login to mAd</h3>
<form action="\$PHP_SELF" method="post">
<input type="text" name="input_user" style="width: 10%">&nbsp;Username
<br />
<input type="password" name="input_pass" style="width: 10%">&nbsp;Password
<br />
<input type="submit" value="Login" style="width: 10%">
</form>
<br />
<a href="http://www.w00ty.com/forum/viewforum.php?f=2">m Web Dev Forum</a>
<br />
<br />
<!-- mAd announcements and notices of outdated software.
     This does NOT do anything malicious such as record data.
     It shows information relevant to your version of mAd only. -->
<iframe src="http://www.w00ty.com/mad/remote.php?v=\$mad_version" frameborder="0" />
<br />
HTML;
	}
}
elseif (\$_SESSION['user']) {
require "config/config.php";
	function doSQL(\$sql_query,\$refresh) {
		require "config/config.php";
		unset(\$error);
		if (!@\$sql_connect = mysql_connect("\$config_sqlhost", "\$config_sqluser", "\$config_sqlpass")) {
			\$error = "couldn't login to SQL [ " . mysql_error() . " ]";
		}
		else {
			if (!@mysql_select_db("\$config_sqldb")) {
				\$error = "couldn't select database [ " . mysql_error() . " ]";
			}
			else {
				if (\$sql_result = @mysql_query(\$sql_query)) {
					if (\$refresh == 1) {
						header("Location: \$PHP_SELF?result=success");
						exit();
					}
				}
				else {
					\$error = "couldn't run SQL query [ " . mysql_error() . " ]";
				}
			}
		}
		if (\$error && (\$refresh == 1)) {
			header("Location: \$PHP_SELF?result=fail&error=\$error&query=\$sql_query");
			exit();
		}
	return \$sql_result;
	}
	function getFile(\$file) {
		\$content = str_replace("\\r","",implode("",file(\$file)));
		return \$content;
	}
	if (\$act == "add") {
		\$add_name = addslashes(\$add_name);
		\$add_url = addslashes(\$add_url);
		if (\$add_pass) {
			\$add_pass = '"' . md5(\$add_pass) . '"';
		}
		else {
			\$add_pass = 'null';
		}
		\$sql_query = <<<SQL
INSERT INTO \$config_sqltable VALUES ( "", "\$add_name", "\$add_url", "\$add_link", 0, 0, \$add_pass, \$current_time )
SQL;
		doSQL(\$sql_query,1);
	}
	elseif (\$act == "edit") {
		\$edit_name = addslashes(\$edit_name);
		\$edit_url = addslashes(\$edit_url);
		if (\$edit_editpass == "yes") {
			if (!\$edit_pass) {
				\$edit_pass = ', ad_pass=null';
			}
			else {
				\$edit_pass = ', ad_pass="' . md5(\$edit_pass) . '"';
			}
		}
		else {
			unset(\$edit_pass);
		}

		\$sql_query = <<<SQL
UPDATE \$config_sqltable SET ad_name="\$edit_name", ad_url="\$edit_url", ad_link="\$edit_link"\$edit_pass WHERE ad_id=\$id
SQL;
		doSQL(\$sql_query,1);
	}
	elseif (\$act == "delete") {
		\$sql_query = "DELETE FROM \$config_sqltable WHERE ad_id=\$id";
		doSQL(\$sql_query,1);
	}
	elseif (\$act == "options") {
		\$config_contents = getFile("config/config.php");
		if (!\$options_statprotect) {
			\$options_statprotect = "no";
		}
		\$config_contents = str_replace(array("\\n",\$config_skin,\$config_statprotect),array("\\r\\n",\$options_skin,\$options_statprotect),\$config_contents);
		if (@fwrite(@fopen("config/config.php","w"),\$config_contents)) {
			header("Location: \$PHP_SELF?result=success");
			exit();
		}
		else {
			\$error = "couldn't edit options [ " . php_error() . " ]";
			header("Location: \$PHP_SELF?result=fail&error=\$error");
			exit();
		}
	}
	elseif (\$act == "stats") {
		if (\$id == "public") {
			\$temp_files = array("public","publicentry");
			\$temp_content = array(\$stats_public,\$stats_publicentry);
		}
		elseif (\$id == "private") {
			\$temp_files = array("login","private");
			\$temp_content = array(\$stats_login,\$stats_private);
		}
		elseif (\$id == "vars") {
			\$temp_files[0] = "vars";
			\$temp_content[0] = \$stats_vars;
		}
		for (\$i=0;\$temp_files[\$i];\$i++) {
			if (!@fwrite(@fopen("config/stats_" . \$temp_files[\$i] . ".php","w"),stripslashes(\$temp_content[\$i]))) {
				\$error = "couldn't edit skin [ " . php_error() . " ]";
				header("Location: \$PHP_SELF?result=fail&error=\$error");
				exit();
			}
		}
		header("Location: \$PHP_SELF?result=success");
		exit();
	}
	else {
		if (\$result == "success") {
			\$result = "Action was successfully carried out.";
		}
		elseif (\$result == "fail") {
			\$result = "Action failed, " . \$error . "<br /><br />" . \$query;
		}
		elseif (\$result) {
			unset(\$result);
		}
		\$sql_query = <<<SQL
SELECT ad_id, ad_name, ad_url, ad_link, ad_pass FROM \$config_sqltable
SQL;
		\$sql_result = doSQL(\$sql_query,0);
		while (\$row = @mysql_fetch_row(\$sql_result)) {
			list(\$row_id,\$row_name,\$row_url,\$row_link,\$row_pass) = \$row;
			\$row_namesl = addslashes(\$row_name);
			if (\$row_pass) {
				\$row_pass = "<br />Password exists";
			}
			\$content_adlist .= <<<HTML
<tr><td>\$row_id</td><td>\$row_name</td><td><a href="\$row_link"><img src="\$row_url" title="\$row_name"></a></td><td><a href="#edit" onClick="getDetails(\$row_id,'\$row_namesl','\$row_url','\$row_link')">Edit</a>
<br />
<a href="\$PHP_SELF?act=delete&id=\$row_id">Remove</a>\$row_pass
</td></tr>
HTML;
		}
		if (\$row_id) {
			\$content_adlist = <<<HTML
<tr class="title"><td>ID</td><td>Title</td><td>Banner Preview</td><td>Function</td></tr>
\$content_adlist
HTML;
		}
		else {
			\$content_adlist = <<<HTML
<tr><td>No ads currently</td></tr>
HTML;
		}
		\$options_config_skin = htmlspecialchars(stripslashes(\$config_skin));
		if (\$config_statprotect == "yes") {
			\$temp_statprotect = " CHECKED";
		}
		\$config_statspublic = getFile("config/stats_public.php");
		\$config_statspublicentry = getFile("config/stats_publicentry.php");
		\$config_statslogin = getFile("config/stats_login.php");
		\$config_statsprivate = getFile("config/stats_private.php");
		\$config_statsvars = getFile("config/stats_vars.php");
		\$content = <<<HTML
<a href="#exist">Existing Ads</a> :: <a href="#add">Add Ad</a> :: <a href="#edit">Edit Ad</a> :: <a href="#options">Program Options</a> :: <a href="#stats">Skin Settings</a> :: <a href="#instructions">Instructions</a> :: <a href="\$PHP_SELF?act=logout">Log Out</a>
<br /><br />
\$result
<a name="exist" />
<fieldset>
<legend>Existing ads</legend>
<table cellspacing="0">
\$content_adlist
</table>
</fieldset>
<br />
<a name="add" />
<fieldset>
<legend>Add a new ad banner</legend>
<form action="\$PHP_SELF" method="post" name="add">
<input type="hidden" name="act" value="add">
<input type="text" name="add_name" value="Title" title="Ad title" size="50">&nbsp;<input type="text" name="add_url" value="URL" title="Image URL" size="50">
<br />
<input type="text" name="add_link" value="Link" title="Link URL" size="50">&nbsp;<input type="text" name="add_pass" value="Statistics password" title="Stats protection password" size="50">
<br />
<input type="submit" value="Add Banner">
</form>
</fieldset>
<br />
<a name="edit" />
<fieldset>
<legend>Edit an existing ad</legend>
<form action="\$PHP_SELF" method="post" name="edit">
<input type="hidden" name="act" value="edit">
<input type="hidden" name="id" value="0">
<input type="text" name="edit_name" value="Title" title="Ad title" size="50" disabled>&nbsp;<input type="text" name="edit_url" value="URL" title="Image URL" size="50" disabled>
<br />
<input type="text" name="edit_link" value="Link" title="Link URL" size="50" disabled>&nbsp;<input type="text" name="edit_pass" value="Statistics password" title="Stats protection password" size="50" disabled>
<br />
Edit statistics password: <input type="checkbox" name="edit_editpass" value="yes" onChange="setPassInput()" disabled> (submit a blank text box to remove password)
<br />
<input type="submit" name="edit_button" value="Edit Banner" disabled>
</form>
</fieldset>
<br />
<a name="options" />
<fieldset>
<legend>Program Options</legend>
<form action="\$PHP_SELF" method="post" name="options">
<input type="hidden" name="act" value="options">
Format for display of ads: <input type="text" size="70" name="options_skin" value="\$options_config_skin">
<br />
Codes: <b>[title]</b> ad title, <b>[image]</b> URL of the ad, <b>[link]</b> URL to link to.
<br /><br />
Enable statistics protection: <input type="checkbox" name="options_statprotect" value="yes"\$temp_statprotect>
<br />
Enabling stat protection stops public access of stats.php. A password - set for each ad - is required.
<br /><br />
<input type="submit" name="options_button" value="Change Options">
</form>
</fieldset>
<br />
<a name="stats" />
<fieldset>
<legend>Statistics Skins</legend>
<form action="\$PHP_SELF" method="post" name="stats">
<input type="hidden" name="act" value="stats">
<input type="hidden" name="id" value="public">
<b>Public Mode Stats</b>
<br /><br />
Overall Statistics skin
<br />
<textarea name="stats_public" cols="100" rows="20">\$config_statspublic</textarea>
<br />
Code: <b>[stats]</b> show statistics rows
<br /><br />
Ad Statistics (repeats for each ad at <b>[stats]</b> above)
<br />
<textarea name="stats_publicentry" cols="100" rows="5">\$config_statspublicentry</textarea>
<br />
Codes: <b>[id]</b> ad ID, <b>[title]</b> ad title, <b>[image]</b> ad URL, <b>[link]</b> ad link, <b>[time]</b> time ad was added (Unix timestamp) <b>[views]</b> number of views, <b>[clicks]</b> number of clicks
<br /><br />
<input type="submit" name="public_button" value="Update Public Skin">
</form>
<br /><br />
<hr>
<br />
<form action="\$PHP_SELF" method="post" name="stats">
<input type="hidden" name="act" value="stats">
<input type="hidden" name="id" value="private">
<b>Stats Protection Mode Stats</b>
<br /><br />
Advertiser Login skin
<br />
<textarea name="stats_login" cols="100" rows="20">\$config_statslogin</textarea>
<br />
Code: <b>[id]</b> ID login box, <b>[pass]</b> password login box, <b>[submit]</b> submit button
<br /><br />
Private Statistics skin
<br />
<textarea name="stats_private" cols="100" rows="20">\$config_statsprivate</textarea>
<br />
Codes: <b>[id]</b> ad ID, <b>[title]</b> ad title, <b>[image]</b> ad URL, <b>[link]</b> ad link, <b>[time]</b> time ad was added (Unix timestamp) <b>[views]</b> number of views, <b>[clicks]</b> number of clicks
<br /><br />
<input type="submit" name="private_button" value="Update Private Skin">
</form>
<br /><br />
<hr>
<br />
<form action="\$PHP_SELF" method="post" name="stats">
<input type="hidden" name="act" value="stats">
<input type="hidden" name="id" value="vars">
<b>Customisable Variables (advanced users only)</b>
<br /><br />
<textarea name="stats_vars" cols="100" rows="20">\$config_statsvars</textarea>
<br />
Use this area to set variables - for example <b>[ratio]</b> - for use in the Ad Statistics and Private Statistics skins. Use PHP-style equations (for example <b>time()</b>), and reference the time/views/clicks using <b>[time]</b> etc. One per line.
<br />
Format: <b>[variable] = equation;</b>
<br /><br />
<input type="submit" name="vars_button" value="Update Variables">
</form>
</fieldset>
<br />
<a name="instructions" />
<fieldset style="text-align: left">
<legend>Instructions</legend>
<form></form>
1: To add an advert to the rotation, type in the title of the site/ad, the image's URL, and the URL to link to in the Add area above, and click the submit button.
<br /><br />
2: To edit an advert, click the "Edit" link in the banner list at the top, and then edit the details in the Edit area above.
<br /><br />
3: To remove an advert, click the "Remove" link in the banner list.
<br /><br />
4: To insert the adverts into a page, first the page itself must have a .php extension, and be on the same site as this script is. From there, include \$config_path/include.php using PHP (for example, <b>&lt;?php include "\$config_path/include.php"; ?></b>). The rest will be taken care of by mAd.
<br /><br />
5: A public statistics page is at <a href="stats.php">\$config_path/stats.php</a>. If you have statistics protection enabled, a password (set when adding/editing ads) must be input by the user (usually the owner of the advertised site). They can login at the above link. In either mode, they can access the private stats page at <b>\$config_path/stats.php?ad_id=<i>[advert id]</i>&ad_pass=<i>[password]</i></b>, where <b><i>[advert id]</i></b> is replaced with the ID of that ad and <b><i>[password]</i></b> is the password you set here. You can also include stats.php into your site through PHP.
</fieldset>
<script language="Javascript">
function getDetails(id,name,url,link) {
	document.edit.id.value = id;
	document.edit.edit_name.value = name;
	document.edit.edit_url.value = url;
	document.edit.edit_link.value = link;
	document.edit.edit_name.disabled = false;
	document.edit.edit_url.disabled = false;
	document.edit.edit_link.disabled = false;
	document.edit.edit_button.disabled = false;
	document.edit.edit_editpass.disabled = false;
}
function setPassInput() {
	if (document.edit.edit_editpass.checked == true) {
		document.edit.edit_pass.disabled = false;
	}
	else {
		document.edit.edit_pass.disabled = true;
	}
}
</script>
HTML;
	}
}
print <<<HTML
<html>
<head>
<title>mAd - I got ad skillz</title>
<style type="text/css">
body, table { text-align: center; font-family: Arial, sans-serif }
fieldset { width: 80%; text-align: center; margin-left: auto; margin-right: auto }
table { width: 90% }
table, table td { border: 1px solid black; margin-left: auto; margin-right: auto }
tr.title td { background-color: black; color: white; font-weight: bold }
img { border: none }
a { color: black }
hr { width: 30% }
</style>
</head>
<body>
<span style="font-size: 400%; font-weight: bold">mAd</span><br /><span style="font-size: 150%">Advert Rotation Manager</span>
<br /><br />
\$content
<br />
<font size="-1"><a href="http://www.w00ty.com/mad">mAd</a> Advert Rotation Manager v\$mad_version created by and Copyright &copy; 2003 <a href="http://www.ianbennett.net">Ian Bennett</a>.</font>
</body>
</html>
HTML;
unset(\$GLOBALS);
?>
TXT;

// INCLUDE.PHP
$install_file_include = <<<TXT
<?php
///////////////////////////////////
// mAd - Advert Rotation Manager //
///////////////////////////////////
// Version 0.3                   //
///////////////////////////////////
// Created by Ian Bennett        //
// ian at ianbennett dot net     //
// w3 dot ianbennett dot net     //
///////////////////////////////////
// This program is provided      //
// under the agreement that it   //
// is used only for the display  //
// of rotating image links on a  //
// website.                      //
///////////////////////////////////
// It may be used to gain profit //
// by using it as a tool to      //
// display advertisements.       //
// Just remember who made this   //
// thing when you're rakin' the  //
// papers!                       //
///////////////////////////////////
// It must not be repackaged or  //
// provided under another name;  //
// displayed as being by another //
// person, or sold for profit.   //
///////////////////////////////////
// Any bugs, comments or         //
// suggestions, go to my forum @ //
// http://www.w00ty.com/forum    //
///////////////////////////////////
\$mad_include_name = "config/config.php";
\$mad_include_script = \$SCRIPT_NAME;
\$mad_include_dirnum = 1;
\$mad_include_bars = count(explode("/",\$script))-(\$numDir+2);
\$mad_include_path = "";
if (\$mad_include_bars > 0){
	for (\$i=0; \$i < \$mad_include_bars; \$i++) {
		\$mad_include_path .= "../";
	}
}
require \$mad_include_path . \$mad_include_name;

unset(\$mad_error);

if (!\$mad_sql_connect = @mysql_connect("\$config_sqlhost", "\$config_sqluser", "\$config_sqlpass")) {
	\$mad_error = "Login error [ " . mysql_error() . " ]";
}
else {
	if (!@mysql_select_db("\$config_sqldb")) {
		\$mad_error = "DB error [ " . mysql_error() . " ]";
	}
	else {
		\$mad_sql_query1 = <<<SQL
SELECT * FROM \$config_sqltable
SQL;
		if (\$mad_sql_result = @mysql_query(\$mad_sql_query1)) {
			if (!\$mad_ad_count = @mysql_num_rows(\$mad_sql_result)) {
				\$mad_error = "Count error [ " . mysql_error() . " ]";
			}
		}
		else {
			\$mad_error = "Count query error [ " . mysql_error() . " ]";
		}
		\$mad_sql_number = (time() % \$mad_ad_count);
		\$mad_sql_query2 = <<<SQL
SELECT ad_id FROM \$config_sqltable
SQL;
		if (\$mad_sql_result = @mysql_query(\$mad_sql_query2)) {
			if (!\$mad_id = @mysql_result(\$mad_sql_result,\$mad_sql_number)) {
				\$mad_error = "ID error [ " . mysql_error() . " ]";
			}
		}
		else {
			\$mad_error = "ID query error [ " . mysql_error() . " ]";
		}
		\$mad_sql_query3 = <<<SQL
SELECT ad_name, ad_url, ad_views FROM \$config_sqltable WHERE ad_id=\$mad_id
SQL;
		if (\$mad_sql_result = @mysql_query(\$mad_sql_query3)) {
			if (!\$mad_sql_row = @mysql_fetch_row(\$mad_sql_result)) {
				\$mad_error = "Data error [ " . mysql_error() . " ]";
			}
		}
		else {
			\$mad_error = "Data query error [ " . mysql_error() . " ]";
		}
		list(\$mad_name,\$mad_url,\$mad_views) = \$mad_sql_row;
		\$mad_views++;
		\$mad_sql_query4 = <<<SQL
UPDATE \$config_sqltable SET ad_views=\$mad_views WHERE ad_id=\$mad_id
SQL;
		if (!@mysql_query(\$mad_sql_query4)) {
			\$mad_error = "View increment error [ " . mysql_error() . " ]";
		}
	}
	@mysql_close(\$mad_sql_connect);
	if (\$mad_error) {
		print "An SQL error has occurred.<br /><br />" . \$mad_error;
	}
	else {
		\$mad_skin_find = array(
"[title]", "[image]", "[link]"
);
		\$mad_skin_replace = array(
\$mad_name, \$mad_url, \$config_path . "/out.php?id=" . \$mad_id
);
		\$mad_skin = str_replace(\$mad_skin_find, \$mad_skin_replace, \$config_skin);
		print \$mad_skin;
		print "\n\n<!-- Ad powered by mAd - www.w00ty.com/mad -->\n\n";
	}
}

unset(\$mad_include_name,\$mad_include_script,\$mad_include_dirnum,\$mad_include_bars,\$mad_include_path,\$mad_error,\$mad_sql_connect,\$mad_sql_query1,\$mad_sql_result,\$mad_ad_count,\$mad_sql_number,\$mad_sql_query2,\$mad_id,\$mad_sql_query3,\$mad_sql_row,\$mad_name,\$mad_url,\$mad_views,\$mad_sql_query4,\$file_content,\$mad_skin_find,\$mad_skin_replace,\$mad_skin,\$config_sqlhost,\$config_sqldb,\$config_sqltable,\$config_sqluser,\$config_sqlpass,\$config_path,\$config_skin);

?>
TXT;

// OUT.PHP
$install_file_out = <<<TXT
<?php
///////////////////////////////////
// mAd - Advert Rotation Manager //
///////////////////////////////////
// Version 0.3                   //
///////////////////////////////////
// Created by Ian Bennett        //
// ian at ianbennett dot net     //
// w3 dot ianbennett dot net     //
///////////////////////////////////
// This program is provided      //
// under the agreement that it   //
// is used only for the display  //
// of rotating image links on a  //
// website.                      //
///////////////////////////////////
// It may be used to gain profit //
// by using it as a tool to      //
// display advertisements.       //
// Just remember who made this   //
// thing when you're rakin' the  //
// papers!                       //
///////////////////////////////////
// It must not be repackaged or  //
// provided under another name;  //
// displayed as being by another //
// person, or sold for profit.   //
///////////////////////////////////
// Any bugs, comments or         //
// suggestions, go to my forum @ //
// http://www.w00ty.com/forum    //
///////////////////////////////////
require "config/config.php";
if (!@\$sql_connect = mysql_connect("\$config_sqlhost", "\$config_sqluser", "\$config_sqlpass")) {
	\$error = "Login error [ " . mysql_error() . " ]";
}
else {
	if (!@mysql_select_db("\$config_sqldb")) {
		\$error = "DB error [ " . mysql_error() . " ]";
	}
	else {
		\$sql_query1 = <<<SQL
SELECT ad_link, ad_clicks FROM \$config_sqltable WHERE ad_id=\$id
SQL;
		if (\$sql_result = @mysql_query(\$sql_query1)) {
			if (!\$sql_row = @mysql_fetch_row(\$sql_result)) {
				\$error = "Data error [ " . mysql_error() . " ]";
			}
			else {
				list(\$link,\$clicks) = \$sql_row;
				\$clicks++;
				\$sql_query2 = <<<SQL
UPDATE \$config_sqltable SET ad_clicks=\$clicks WHERE ad_id=\$id
SQL;
				if (!@mysql_query(\$sql_query2)) {
					\$mad_error = "Click increment error [ " . mysql_error() . " ]";
				}
			}
		}
		else {
			\$error = "Data query error [ " . mysql_error() . " ]";
		}
	}
}
if (\$error) {
	print "An SQL error has occurred.<br /><br />" . \$error;
}
else {
	header("Location: " . \$link);
}
unset(\$GLOBALS);
?>
TXT;

// STATS.PHP
$install_file_stats = <<<TXT
<?
///////////////////////////////////
// mAd - Advert Rotation Manager //
///////////////////////////////////
// Version 0.3                   //
///////////////////////////////////
// Created by Ian Bennett        //
// ian at ianbennett dot net     //
// w3 dot ianbennett dot net     //
///////////////////////////////////
// This program is provided      //
// under the agreement that it   //
// is used only for the display  //
// of rotating image links on a  //
// website.                      //
///////////////////////////////////
// It may be used to gain profit //
// by using it as a tool to      //
// display advertisements.       //
// Just remember who made this   //
// thing when you're rakin' the  //
// papers!                       //
///////////////////////////////////
// It must not be repackaged or  //
// provided under another name;  //
// displayed as being by another //
// person, or sold for profit.   //
///////////////////////////////////
// Any bugs, comments or         //
// suggestions, go to my forum @ //
// http://www.w00ty.com/forum    //
///////////////////////////////////
\$mad_include_script = \$SCRIPT_NAME;
\$mad_include_dirnum = 1;
\$mad_include_bars = count(explode("/",\$mad_script))-(\$mad_numDir+2);
\$mad_include_path = "";
if (\$mad_include_bars > 0){
	for (\$mad_i=0; \$mad_i < \$mad_mad_include_bars; \$mad_i++) {
		\$mad_include_path .= "../";
	}
}
require \$mad_include_path . "config/config.php";
\$mad_lines = file(\$mad_include_path . "config/stats_vars.php");
unset(\$mad_error);

function getFile(\$file) {
	\$content = str_replace("\r","",implode("",file(\$file)));
	return \$content;
}
\$mad_invalid = array("eval","basename","chgrp","chmod","chown","clearstatcache","copy","delete","dirname","disk_free_space","disk_total_space","diskfreespace","fclose","feof","fflush","fgetc","fgetcsv","fgets","fgetss","file_exists","file_get_contents","file_put_contents","file","fileatime","filectime","filegroup","fileinode","filemtime","fileowner","fileperms","filesize","filetype","flock","fnmatch","fopen","fpassthru","fputs","fread","fscanf","fseek","fstat","ftell","ftruncate","fwrite","glob","is_dir","is_executable","is_file","is_link","is_readable","is_uploaded_file","is_writable","is_writeable","link","linkinfo","lstat","mkdir","move_uploaded_file","parse_ini_file","pathinfo","pclose","popen","readfile","readlink","realpath","rename","rewind","rmdir","set_file_buffer","symlink","tempnam","tmpfile","touch","umask","unlink","mysql_affected_rows","mysql_change_user","mysql_client_encoding","mysql_close","mysql_connect","mysql_create_db","mysql_data_seek","mysql_db_name","mysql_db_query","mysql_drop_db","mysql_errno","mysql_error","mysql_escape_string","mysql_fetch_array","mysql_fetch_assoc","mysql_fetch_field","mysql_fetch_lengths","mysql_fetch_object","mysql_fetch_row","mysql_field_flags","mysql_field_len","mysql_field_name","mysql_field_seek","mysql_field_table","mysql_field_type","mysql_free_result","mysql_get_client_info","mysql_get_host_info","mysql_get_proto_info","mysql_get_server_info","mysql_info","mysql_insert_id","mysql_list_dbs","mysql_list_fields","mysql_list_processes","mysql_list_tables","mysql_num_fields","mysql_num_rows","mysql_pconnect","mysql_ping","mysql_query","mysql_real_escape_string","mysql_result","mysql_select_db","mysql_stat","mysql_tablename","mysql_thread_id","mysql_unbuffered_query");

if ((\$ad_id && \$ad_pass) || \$config_statprotect == "no") {

	if (!\$mad_sql_connect = @mysql_connect("\$config_sqlhost", "\$config_sqluser", "\$config_sqlpass")) {
		\$mad_error = "Login error [ " . mysql_error() . " ]";
	}
	else {
		if (!@mysql_select_db("\$config_sqldb")) {
			\$mad_error = "DB error [ " . mysql_error() . " ]";
		}
		else {
			if (\$ad_id && \$ad_pass) {
				\$mad_sql_query = <<<SQL
SELECT ad_pass FROM \$config_sqltable WHERE ad_id=\$ad_id
SQL;
				if (\$mad_sql_result = @mysql_query(\$mad_sql_query)) {
					if (md5(\$ad_pass) == mysql_result(\$mad_sql_result,0)) {
						\$mad_sql_query = <<<SQL
SELECT ad_id, ad_name, ad_url, ad_link, ad_views, ad_clicks, ad_time FROM \$config_sqltable WHERE ad_id=\$ad_id
SQL;
						if (\$mad_row = @mysql_fetch_row(@mysql_query(\$mad_sql_query))) {
							list(\$mad_row_id,\$mad_row_name,\$mad_row_url,\$mad_row_link,\$mad_row_views,\$mad_row_clicks,\$mad_row_time) = \$mad_row;
							\$mad_find = array("[id]","[title]","[image]","[link]","[views]","[clicks]","[time]");
							\$mad_replace = array(\$mad_row_id,\$mad_row_name,\$mad_row_url,\$mad_row_link,\$mad_row_views,\$mad_row_clicks,\$mad_row_time);
							foreach (\$mad_lines as \$mad_key => \$mad_line) {
								if (\$mad_line[0] == "[") {
									\$mad_error = 0;
									foreach (\$mad_invalid as \$invalid) {
										if (preg_match("/" . \$invalid . "/i",\$mad_line)) {
											print "ERROR: Variable uses an invalid command. [ \$mad_line ]<br />";
											\$mad_error = 1;
										}
									}
									if (\$mad_error == 0) {
										\$mad_words = explode(" ",\$mad_line);
										\$mad_line = str_replace(array('\$','[',']'),array('','\$mad_row_',''),\$mad_line);
										@eval(\$mad_line);
										\$mad_find2[\$mad_key] = \$mad_words[0];
										\$mad_words = str_replace(array('\$','[',']'),array('','mad_row_',''),\$mad_words[0]);
										\$mad_replace2[\$mad_key] = \${\$mad_words};
									}
								}
								else {
									if ((\$mad_line[0] != "/" || \$mad_line[1] != "/") && (trim(\$mad_line))) {
										print "ERROR: Does not set a variable. [ \$mad_line ]<br />";
									}
								}
							}
							\$mad_content = str_replace(\$mad_find,\$mad_replace,getFile(\$mad_include_path . "config/stats_private.php"));
							print str_replace(\$mad_find2,\$mad_replace2,\$mad_content);
						}
						else {
							\$mad_error = "Data query error [ " . mysql_error() . " ]";
						}
					}
					else {
						\$mad_error = "Login error. please check your ID and password.";
					}
				}
				else {
					\$mad_error = "Data query error [ " . mysql_error() . " ]";
				}
			}
			else {
				\$mad_sql_query = <<<SQL
SELECT ad_id, ad_name, ad_url, ad_link, ad_views, ad_clicks, ad_time FROM \$config_sqltable
SQL;
				if (\$mad_sql_result = @mysql_query(\$mad_sql_query)) {
					while (\$mad_row = @mysql_fetch_row(\$mad_sql_result)) {
					list(\$mad_row_id,\$mad_row_name,\$mad_row_url,\$mad_row_link,\$mad_row_views,\$mad_row_clicks,\$mad_row_time) = \$mad_row;
						\$mad_find = array("[id]","[title]","[image]","[link]","[views]","[clicks]","[time]");
						\$mad_replace = array(\$mad_row_id,\$mad_row_name,\$mad_row_url,\$mad_row_link,\$mad_row_views,\$mad_row_clicks,\$mad_row_time);
						foreach (\$mad_lines as \$mad_key => \$mad_line) {
							if (\$mad_line[0] == "[") {
								\$mad_error = 0;
								foreach (\$mad_invalid as \$invalid) {
									if (preg_match("/" . \$invalid . "/i",\$mad_line)) {
										print "ERROR: Variable uses an invalid command. [ \$mad_line ]<br />";
										\$mad_error = 1;
									}
								}
								if (\$mad_error == 0) {
									\$mad_words = explode(" ",\$mad_line);
									\$mad_line = str_replace(array('\$','[',']'),array('','\$mad_row_',''),\$mad_line);
									@eval(\$mad_line);
									\$mad_find2[\$mad_key] = \$mad_words[0];
									\$mad_words = str_replace(array('\$','[',']'),array('','mad_row_',''),\$mad_words[0]);
									\$mad_replace2[\$mad_key] = \${\$mad_words};
								}
							}
							else {
								if ((\$mad_line[0] != "/" || \$mad_line[1] != "/") && (trim(\$mad_line))) {
									print "ERROR: Does not set a variable. [ \$mad_line ]<br />";
								}
							}
						}
						\$mad_content = str_replace(\$mad_find,\$mad_replace,getFile(\$mad_include_path . "config/stats_publicentry.php"));
						\$mad_content = str_replace(\$mad_find2,\$mad_replace2,\$mad_content);
						\$mad_content_adlist .= \$mad_content;
					}
					print str_replace("[stats]",\$mad_content_adlist,getFile(\$mad_include_path . "config/stats_public.php"));
				}
				else {
					\$mad_error = "Data query error [ " . mysql_error() . " ]";
				}
			}

		}
		if (\$mad_error) {
			print \$mad_error;
		}
	}
}

else {
	\$mad_find = array("[id]","[pass]","[submit]");
	\$mad_replace = array(
'<form action="' . \$PHP_SELF . '" method="post" name="login"><input type="text" name="ad_id" value="' . \$ad_id . '">',
'<input type="password" name="ad_pass">',
'<input type="submit" value="Login"></form>'
);
	print str_replace(\$mad_find,\$mad_replace,getFile(\$mad_include_path . "config/stats_login.php"));
}

unset(\$mad_include_name,\$mad_include_script,\$mad_include_dirnum,\$mad_include_bars,\$mad_include_path,\$config_sqlhost,\$config_sqldb,\$config_sqltable,\$config_sqluser,\$config_sqlpass,\$config_path,\$config_skin,\$mad_sql_connect,\$mad_sql_query,\$mad_sql_result,\$mad_row,\$mad_row_clicks,\$mad_row_views,\$mad_row_link,\$mad_row_url,\$mad_row_name,\$mad_row_id,\$mad_row_namesl,\$mad_content_adlist,\$mad_invalid,\$mad_lines,\$mad_line,\$mad_words,\$mad_content,\$mad_find,\$mad_replace,\$mad_find2,\$mad_replace2,\$config_statprotect,\$mad_row_time,\$mad_error,\$invalid,\$mad_key);

?>
TXT;

// CONFIG/STATS_PUBLIC.PHP
$install_file_statspublic = <<<TXT
<html>
<head>
<title>Ad Statistics</title>
<style type="text/css">
body, table { text-align: center; font-family: Arial, sans-serif }
fieldset { width: 80%; text-align: center; margin-left: auto; margin-right: auto }
table { width: 90% }
table, table td { border: 1px solid black; margin-left: auto; margin-right: auto }
tr.title td { background-color: black; color: white; font-weight: bold }
input { width: 30% }
img { border: none }
a { color: black }
</style>
</head>
<body>
<span style="font-size: 400%; font-weight: bold">mAd</span><br /><span style="font-size: 150%">Advert Rotation Manager</span>
<br /><br />
<fieldset>
<legend>Currently in rotation</legend>
<table cellspacing="0">
<tr class="title"><td>Banner</td><td>Views</td><td>Clicks</td><td>Uptime</td></tr>
[stats]
</table>
</fieldset>
<br />
<font size="-1"><a href="http://www.w00ty.com/mad">mAd</a> Advert Rotation Manager created by and Copyright � 2003 <a href="http://www.ianbennett.net">Ian Bennett</a></font>
</body>
</html>
TXT;

// CONFIG/STATS_PUBLICENTRY.PHP
$install_file_statspublicentry = <<<TXT
<tr><td><a href="[link]"><img src="[image]" title="[title]"></a></td><td>[views]<br />([viewsaday]/day)</td><td>[clicks]<br />([clicksaday]/day)</td><td>[uptimedays] day, [uptimehrs] hr</tr>
TXT;

// CONFIG/STATS_LOGIN.PHP
$install_file_statslogin = <<<TXT
<html>
<head>
<title>Ad Statistics: User Login</title>
<style type="text/css">
body, table { text-align: center; font-family: Arial, sans-serif }
fieldset { width: 80%; text-align: center; margin-left: auto; margin-right: auto }
table { width: 90% }
table, table td { border: 1px solid black; margin-left: auto; margin-right: auto }
tr.title td { background-color: black; color: white; font-weight: bold }
input { width: 10% }
img { border: none }
a { color: black }
</style>
</head>
<body>
<span style="font-size: 400%; font-weight: bold">mAd</span><br /><span style="font-size: 150%">Advert Rotation Manager</span>
<br /><br />
<h3>Statistics Login</h3>
Please enter the ID of your ad and the password you received from the site admin.
<br /><br />
[id] Advert ID
<br />
[pass] Password
<br />
[submit]
</form>
<br />
<font size="-1"><a href="http://www.w00ty.com/mad">mAd</a> Advert Rotation Manager created by and Copyright � 2003 <a href="http://www.ianbennett.net">Ian Bennett</a></font>
</body>
</html>
TXT;

// CONFIG/STATS_PRIVATE.PHP
$install_file_statsprivate = <<<TXT
<html>
<head>
<title>Ad Statistics</title>
<style type="text/css">
body { text-align: center }
body, table { font-family: Arial, sans-serif }
fieldset { width: 80%; text-align: center; margin-left: auto; margin-right: auto }
table { width: 90% }
table, table td { border: none; margin-left: auto; margin-right: auto }
tr.title td { background-color: black; color: white; font-weight: bold }
input { width: 30% }
img { border: none }
a { color: black }
</style>
</head>
<body>
<span style="font-size: 400%; font-weight: bold">mAd</span><br /><span style="font-size: 150%">Advert Rotation Manager</span>
<br /><br />
<fieldset>
<legend>Stats for [title]</legend>
<a href="[link]"><img src="[image]" title="[title]" border="0"></a>
<br /><br />
<table>
<tr><td align="right"><b>Ad ID:</b></td><td>[id]</td></tr>
<tr><td align="right"><b>Links to:</b></td><td><a href="[link]">[link]</a></td></tr>
<tr><td align="right"><b>Image URL:</b></td><td><a href="[image]">[image]</a></td></tr>
<tr><td align="right"><b>Views:</b></td><td>[views] ([viewsaday] a day)</td></tr>
<tr><td align="right"><b>Clicks:</b></td><td>[clicks] ([clicksaday] a day)</td></tr>
<tr><td align="right"><b>Views per click:</b></td><td>[viewsperclick]</td></tr>
<tr><td align="right"><b>Creation time:</b></td><td>[created]</td></tr>
<tr><td align="right"><b>Uptime:</b></td><td>[uptimedays] day, [uptimehrs] hr, [uptimemins] min</td></tr>
</table>
</fieldset>
<br />
<font size="-1"><a href="http://www.w00ty.com/mad">mAd</a> Advert Rotation Manager created by and Copyright � 2003 <a href="http://www.ianbennett.net">Ian Bennett</a></font>
</body>
</html>
TXT;

// CONFIG/STATS_VARS.PHP
$install_file_statsvars = <<<TXT
// date() stats - see php.net/date for a list of code letters
[created] = date("g:ia o\\n d/m/y",[time]); // creation time, format "9:14am on 23/4/03"

// Uptime stats (time since ad was added)
[uptime] = time() - [time];  // in seconds
[uptimedays] = floor([uptime] / 86400);  // full days
[uptimehrs] = floor(([uptime] % 86400) / 3600);  // full hours since last full day
[uptimemins] = floor(([uptime] % 3600) / 60);  // full minutes since last full hour
[uptimesecs] = [uptime] % 60;  // seconds since last full minute

// View/click stats
[viewsaday] = round([views] / ([uptime] / 84000),2);  // views a day
[clicksaday] = round([clicks] / ([uptime] / 84000),2);  // clicks a day
[viewsperclick] = round([views] / [clicks],2);  // views per click
TXT;

	if ($install_update == "yes") {
		require("config/config.php");
		print <<<HTML
<html>
<head>
<title>mAd Update</title>
<style type="text/css">
body { text-align: center }
fieldset { width: 50%; text-align: left; margin-left: auto; margin-right: auto }
a { color: black }
</style>
</head>
<body>
<h3>Updating mAd from existing installation</h3>
<fieldset>
<legend>Install Progress</legend>
Creating mAd program file: 
HTML;
		flush();

		if (@fwrite(@fopen("index.php","w"),$install_file_index)) {
			print $success;
		}
		else {
			print $failure;
		}
		print "<br />Creating statistics display file: ";
		flush();

		if (@fwrite(@fopen("stats.php","w"),$install_file_stats)) {
			print $success;
		}
		else {
			print $failure;
		}
		print "<br />Creating statistics skin files: ";
		flush();

		if ((@fwrite(@fopen("config/stats_public.php","w"),$install_file_statspublic)) &&
(@fwrite(@fopen("config/stats_publicentry.php","w"),$install_file_statspublicentry)) &&
(@fwrite(@fopen("config/stats_login.php","w"),$install_file_statslogin)) &&
(@fwrite(@fopen("config/stats_private.php","w"),$install_file_statsprivate)) &&
(@fwrite(@fopen("config/stats_vars.php","w"),$install_file_statsvars))) {
			print $success;
		}
		else {
			print $failure;
		}

		print "<br />Creating config file: ";
		flush();

		$config_skin = addslashes($config_skin);
		$file_content = <<<TXT
<?php
\$config_sqlhost = "$config_sqlhost";
\$config_sqldb = "$config_sqldb";
\$config_sqltable = "$config_sqltable";
\$config_sqluser = "$config_sqluser";
\$config_sqlpass = "$config_sqlpass";
\$config_path = "$config_path";
\$config_skin = "$config_skin";
\$config_statprotect = "no";
?>
TXT;
		if (@fwrite(@fopen("config/config.php","w"),$file_content)) {
			print $success;
		}
		else {
			print $failure;
		}

		print "<br />Updating SQL table: ";
		flush();

		$sql_query = <<<SQL
ALTER TABLE `$config_sqltable` ADD `ad_pass` VARCHAR(255), ADD `ad_time` INT(10) NOT NULL;
SQL;
		if (!@$sql_connect = mysql_connect("$config_sqlhost", "$config_sqluser", "$config_sqlpass")) {
			print $failure . ", couldn't login to SQL [ " . mysql_error() . " ]<br />";
		}
		else {
			if (!@mysql_select_db("$config_sqldb")) {
				print $failure . ", couldn't select database [ " . mysql_error() . " ]<br />";
			}
			else {
				if ($sql_result = @mysql_query($sql_query)) {
					print $success;
				}
				else {
					print $failure . ", couldn't run SQL query [ " . mysql_error() . " ]<br />";
				}
			}
		}
	print <<<HTML
<br /><br />
Updating is now complete, you can now access mAd. You should delete install.php to avoid security issues. If you got a "Failed" message, mAd probably won't work, or the existing version will still be intact. If this happens please use the manual installer instead.
<br /><br />
Please note that one of the updates now stores the ad creation time in SQL. Ads created before updating will now have a creation time of midnight 1st January 1970 which will disrupt statistics that use creation time; so you should replace them, or edit the time in an SQL editor such as phpMyAdmin.
</fieldset>

</body>
</html>
HTML;

	}

	elseif (!$install_update) {
		print <<<HTML
<html>
<head>
<title>mAd Installation</title>
<style type="text/css">
body { text-align: center }
fieldset { width: 50%; text-align: left; margin-left: auto; margin-right: auto }
a { color: black }
</style>
</head>
<body>
<h3>Installing mAd</h3>
<fieldset>
<legend>Install Progress</legend>
Creating config file folder: 
HTML;
		flush();

		if (is_dir("config")) {
			print $skipped . ", folder already exists.";
		}
		else {
			if (@mkdir("config",0700)) {
				print $success;
			}
			else {
				print $failure;
			}
		}

		print "<br />Creating user login file: ";
		flush();

		list($install_user,$install_pass) = array(addslashes($install_user),addslashes($install_pass));
		$file_content = <<<TXT
<?php
\$config_user = "$install_user";
\$config_pass = "$install_pass";
?>
TXT;
		if (@fwrite(@fopen("config/user.php","w"),$file_content)) {
			print $success;
		}
		else {
			print $failure;
		}

		print "<br />Creating config file: ";
		flush();

		$install_file = explode("/", $SCRIPT_NAME);
		for ($temp=0; $temp < (count($install_file) - 1); $temp++) {
			if ($temp == 0) {
				$install_path = $install_file[$temp];
			}
			else {
				$install_path .= "/" . $install_file[$temp];
			}
		}
		$install_path = "http://" . $HTTP_HOST . $install_path;
		$file_content = <<<TXT
<?php
\$config_sqlhost = "$install_sqlhost";
\$config_sqldb = "$install_sqldb";
\$config_sqltable = "$install_sqltable";
\$config_sqluser = "$install_sqluser";
\$config_sqlpass = "$install_sqlpass";
\$config_path = "$install_path";
\$config_skin = "<a href=\\"[link]\\"><img src=\\"[image]\\" title=\\"[title]\\" border=\\"0\\"></a>";
\$config_statprotect = "no";
?>
TXT;
		if (@fwrite(@fopen("config/config.php","w"),$file_content)) {
			print $success;
		}
		else {
			print $failure;
		}
		print "<br />Creating mAd program file: ";
		flush();

		if (@fwrite(@fopen("index.php","w"),$install_file_index)) {
			print $success;
		}
		else {
			print $failure;
		}
		print "<br />Creating ad display file: ";
		flush();

		if (@fwrite(@fopen("include.php","w"),$install_file_include)) {
			print $success;
		}
		else {
			print $failure;
		}
		print "<br />Creating redirection file: ";
		flush();

		if (@fwrite(@fopen("out.php","w"),$install_file_out)) {
			print $success;
		}
		else {
			print $failure;
		}
		print "<br />Creating statistics display file: ";
		flush();

		if (@fwrite(@fopen("stats.php","w"),$install_file_stats)) {
			print $success;
		}
		else {
			print $failure;
		}
		print "<br />Creating statistics skin files: ";
		flush();

		if ((@fwrite(@fopen("config/stats_public.php","w"),$install_file_statspublic)) &&
(@fwrite(@fopen("config/stats_publicentry.php","w"),$install_file_statspublicentry)) &&
(@fwrite(@fopen("config/stats_login.php","w"),$install_file_statslogin)) &&
(@fwrite(@fopen("config/stats_private.php","w"),$install_file_statsprivate)) &&
(@fwrite(@fopen("config/stats_vars.php","w"),$install_file_statsvars))) {
			print $success;
		}
		else {
			print $failure;
		}

		print "<br />Creating SQL table: ";
		flush();

		if ($install_sqlexists) {
			print $skipped;
		}
		else {
			$sql_query = <<<SQL
CREATE TABLE `$install_sqltable` (
`ad_id` INT( 5 ) NOT NULL AUTO_INCREMENT ,
`ad_name` VARCHAR( 255 ) DEFAULT 'Title' NOT NULL ,
`ad_url` VARCHAR( 255 ) DEFAULT 'URL' NOT NULL ,
`ad_link` VARCHAR( 255 ) DEFAULT 'Link' NOT NULL ,
`ad_views` INT( 20 ) DEFAULT 0 NOT NULL ,
`ad_clicks` INT( 20 ) DEFAULT 0 NOT NULL ,
`ad_pass` VARCHAR( 255 ) NULL ,
`ad_time` INT( 10 ) DEFAULT 0 NOT NULL ,
PRIMARY KEY ( `ad_id` )
);
SQL;
			if (!@$sql_connect = mysql_connect("$install_sqlhost", "$install_sqluser", "$install_sqlpass")) {
				print $failure . ", couldn't login to SQL [ " . mysql_error() . " ]<br />";
			}
			else {
				if (!@mysql_select_db("$install_sqldb")) {
					print $failure . ", couldn't select database [ " . mysql_error() . " ]<br />";
				}
				else {
					if ($sql_result = @mysql_query($sql_query)) {
						print $success;
					}
					else {
						print $failure . ", couldn't run SQL query [ " . mysql_error() . " ]<br />";
					}
				}
			}
		}

	print <<<HTML
<br /><br />
Installation is now complete, you can now access mAd. You should delete install.php to avoid security issues. If you got a "Failed" message, mAd probably won't work; if you inserted incorrect details, click Back and install again.
</fieldset>

</body>
</html>
HTML;
	}
}
else {
	$content = <<<HTML
<html>
<head>
<title>mAd Installation</title>
<style type="text/css">
body { text-align: center; font-family: Arial, sans-serif }
fieldset { width: 50%; text-align: left; margin-left: auto; margin-right: auto }
a { color: black }
</style>
</head>
<body>
<span style="font-size: 400%; font-weight: bold">mAd</span><br /><span style="font-size: 150%">Advert Rotation Manager</span>
<br /><br />
<h3>Installing mAd</h3>
<form action="$PHP_SELF" method="post">
<input type="hidden" name="confirm" value="yes">
<fieldset>
<legend>Select Installation</legend>
<input type="checkbox" name="install_update" value="yes"> Update an existing installation
<br /><br />
If you check this option, mAd will be updated to the new version. The login and SQL details will not be changed, and all ads will be intact. Only insert the below details if you are installing the program for the first time - otherwise just click the button at the bottom.
</fieldset>
<br />
<fieldset>
<legend>Login Details</legend>
<input type="text" name="install_user"> Admin Username
<br />
<input type="text" name="install_pass"> Admin Password
</fieldset>
<br />
<fieldset>
<legend>Settings</legend>
The database and username/password must already be created, the table should not.
<br /><br />
<input type="text" name="install_sqlhost"> Database host location (usually "localhost")
<br />
<input type="text" name="install_sqldb"> SQL database to use
<br />
<input type="text" name="install_sqltable"> SQL table in database to store ad details
<br />
<input type="checkbox" name="install_sqlexists" value="yes"> SQL table already exists (don't create table)
<br />
<input type="text" name="install_sqluser"> Username to log into database
<br />
<input type="text" name="install_sqlpass"> Password to log into database
<br />
</fieldset>
<br />
Please make sure that the folder this installer is in has a CHMOD of <b>777</b> (rwxrwxrwx), else file installation may not work.
<br /><br />
<input type="submit" value="Install mAd">
</form>

</body>
</html>
HTML;
}
print <<<HTML
$content
<br />
<font size="-1">mAd Advert Rotation Manager created by and Copyright &copy; 2003 <a href="http://www.ianbennett.net">Ian Bennett</a></font>
HTML;
unset($GLOBALS);
?>