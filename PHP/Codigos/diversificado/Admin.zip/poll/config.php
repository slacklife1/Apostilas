<?php
#########################################################################
# Please make changes in this file for $path as per your requirement.   #
# change the value of $host,$user,$passwd to connect to mysql database  #
# initially run createdb.php to create database skeleton                # 
# Any bugs please feel free to mail to kelkar_mandar@yahoo.com          # 
# Any modificatoins please let me know so i can modify accordingly      #
# If you are configuring this for linux use $path=/tmp					#
# Other os please use your own paths									#
#########################################################################

/////// Change only this five parameters to your requirements ///////
		$path="c:";  										  ///////	
		$host="localhost";								      ///////
		$user="root";										  ///////			
		$password="";										  ///////	
		$database="poll";	//preferably dont change this	  ///////		
/////////////////////////////////////////////////////////////////////


//~~~~~    If you are creating database on your own then please comment this code from start of commenting till you get end of commenting ~~~~~~//

//start of commenting 
$dblink= mysql_connect("$host","$user","$password");
$listdbs = mysql_list_dbs($dblink);
$dbarray=array();
while ($databaseObject = mysql_fetch_object($listdbs)) {
     array_push($dbarray,$databaseObject->Database);
}
if (!in_array($database,$dbarray)){
@mysql_create_db($database);
} 
//end of commenting 
      

function dbconnect($host,$user,$password,$database){
	@mysql_pconnect("$host","$user","$password") or die ("Cant connect using login and password ");
	@mysql_select_db($database) or die ("failed connection to database");
	echo mysql_error();
}

dbconnect($host,$user,$password,$database);
?>