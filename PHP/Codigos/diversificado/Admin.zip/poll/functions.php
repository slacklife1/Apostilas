<?php
include_once("config.php");
function site_header($title){
echo "<html>
<head>
<title>$title</title>
<link rel = stylesheet type=text/css href=style.css>
</head>
<body bgcolor=#ffffff topmargin=0 leftmargin=0 rightmargin=0>
<table width=60% align=center cellspacing=0 cellpadding=0>
	<tr>
	<td class=infoboxcontent><b><a href=admin.php?state=show>Add new poll</a></b></td>
	<td class=infoboxcontent><b><a href=admin.php?state=viewpoll>View poll's</a></b></td>
	<td class=infoboxcontent><b><a href=admin.php?state=modifypoll>Modify poll</a></b></td>
	<td class=infoboxcontent><b><a href=admin.php?state=deletepoll>Delete poll</a></b></td>
	</tr>
	<tr rowspan=3>
		<td colspan=3>&nbsp;</td>
	</tr>
</table>";
}

function showPollList($condition){
$sql="select * from addpoll";
$result=mysql_query($sql);
$rows=@mysql_num_rows($result);
if ($rows>0){
echo "<form action=admin.php method=post>";
echo "<table width=100% cellpadding=0 cellspacing=0 align=center>";
echo "<tr>
		<td class=infoboxtitle>Sr No.</td>
		<td class=infoboxtitle>Question</td>
		<td class=infoboxtitle>Answer 1</td>
		<td class=infoboxtitle>Answer 2</td>
		<td class=infoboxtitle>Answer 3</td>
		<td class=infoboxtitle>Answer 4</td>
		<td class=infoboxtitle>Answer 5</td>
		<td class=infoboxtitle>Answer 6</td>
		<td class=infoboxtitle>URL</td>";
		if ($condition==delete){
		echo "<td class=infoboxtitle>Delete</td>";
		}
		if ($condition==modify){
		echo "<td class=infoboxtitle>Modify</td>";
		}
echo "</tr>";
$cnt=1;
		while ($recordObj=mysql_fetch_object($result)){
			if ($recordObj->display==1){
				$bg="bgcolor=#ffcc9f";
			} else {
				$bg="bgcolor=#ffdddf";
			}
			echo "<tr>";
			echo "<td class=content $bg>".$cnt."</td>";
			echo "<td class=content $bg>".$recordObj->question."</td>";
			echo "<td class=content $bg>&nbsp;".$recordObj->answer1."</td>";
			echo "<td class=content $bg>&nbsp;".$recordObj->answer2."</td>";
			echo "<td class=content $bg>&nbsp;".$recordObj->answer3."</td>";
			echo "<td class=content $bg>&nbsp;".$recordObj->answer4."</td>";
			echo "<td class=content $bg>&nbsp;".$recordObj->answer5."</td>";
			echo "<td class=content $bg>&nbsp;".$recordObj->answer6."</td>";
			echo "<td class=content $bg>&nbsp;".$recordObj->url."</td>";
				if ($condition==delete){
					echo "<td class=infoboxcontent><input type=checkbox name=deletearr[] value=".$recordObj->pid."></td>";
				}
				if ($condition==modify){
					echo "<td class=infoboxcontent><a href=admin.php?state=modifyrecords&recid=".$recordObj->pid.">Modify</a></td>";
				}

			echo "</tr>";
			$cnt++;
		}
if ($condition==delete){
	echo "<tr>
			<td class=infoboxcontent colspan=9>&nbsp;</td>
			<td class=infoboxcontent><input type=submit value=' Delete '></td>
		  </tr>";
}

echo "</table>";
echo "<input type=hidden name=state value=deletepollrecords>";
echo "</form>";
} else {
echo "<font class=red><center><b>No poll records exist..<br>Add new poll..</b></center></font>";
}
}
function showResult($id,$question,$answer1,$answer2,$answer3,$answer4,$answer5,$answer6,$answer)
{
	$answerarr=array();
	array_push($answerarr,$answer1);
	array_push($answerarr,$answer2);
	array_push($answerarr,$answer3);
	array_push($answerarr,$answer4);
	array_push($answerarr,$answer5);
	array_push($answerarr,$answer6);

	include_once("urlstlye.css");
echo "	<table width=30% cellpadding=0 cellspacing=0 align=center>
		<tr>
			<td class=question colspan=2>$question</td>
		</tr>";
//get record array from database for poll result

		$records=showanswers($id);
		$noa=$records[noofanswers];
		
		for($i=1; $i<=$noa; $i++){
		$answervar="answer".$i;
		$total+=$records[$answervar];
		}

		for($i=1; $i<=$noa; $i++){
		$answervar="answer".$i;
		$arraycnt=$i-1;

		//here goes logic to actually decide the width and height to show the result for a poll
		$noofvotes=$records[$answervar];
		$width=($noofvotes/$total)*100;
		$height=15;

		////////  Get the user broswer and accordingly set the height ////////
		$browserObj=get_browser();
		$user_browser=$browserObj->browser;
		/////////////////////////////////////////////////////////////////////
		
		if ($width==0){
			if ($user_browser==IE) $height=15;
			if ($user_browser==Netscape) $height=6;
		}

echo "	<tr>
		<td class=answer width=50%>".$answerarr[$arraycnt]."</td>
		<td class=answer>&nbsp;<img src=red.gif width=$width height=$height>&nbsp;&nbsp;".sprintf("%01.1f",$width)."%</td>
		</tr>";
		} 

echo "	<tr>
			<td class=answer>Total Votes </td>
			<td class=answer><b><center>$total</center></b></td>
		</tr>";

echo "	</table>";
}

function showanswers($pid){
$sql="select * from pollresult where pid=$pid";
$result=@mysql_query($sql);
return $recordArray=@mysql_fetch_array($result);
}