<?php
/********************************************************************************/  // The Entire voting concept is restrited for 1 hour from time last voted.      //
// May be cookies or sessions or file writing.....								//
// If browsers not closed then cant vote even after 1 hour since sessions are   //
// active at this time also.													//
/********************************************************************************/

session_start();
include_once("config.php");
include_once("functions.php");

if (!$answer){
include_once("show.php");
exit;
}

//get the ip name and create the filename variable $filename
$ip=$REMOTE_ADDR;
$filename=$ip.".txt";
if (@file_exists("$path/$filename")){
		$fp=fopen("$path/$filename","r");
		$timeinfile=fread($fp,20);
		$currenttime=time();
		if (($currenttime-$timeinfile)<3600){
		showResult($id,$question,$answer1,$answer2,$answer3,$answer4,$answer5,$answer6,$answer);
		exit;
		}
}
if (!isset($pollcookievoted) and $pollsessionvoted!='yes'){
	$time=time();
	$time=$time+10;
	setcookie("pollcookievoted","yes",$time);
	session_register(pollsessionvoted);
	$pollsessionvoted="yes";
	
	//since every browser has its on cookies and sessions code becomes buggy if i vote once through IE and other time through Netscape. So i am writing this variable to temp file in c: for windows and in /tmp for linux .. Others os please modify code.. as per ur server. (i am using windows as local server and linux as online....

	$fp=fopen("$path/$filename","w+");
	$write=fwrite($fp,$time);
	$answervar="answer".$answer;
	
	//check if such record for pollid exists
	$pollrow=@mysql_num_rows(@mysql_query("select * from pollresult where pid=$id"));
	if ($pollrow >0){
		//Get the actual no of votes for this answer
		$getanswer="select $answervar from pollresult where pid=$id";
		$getresult=@mysql_query($getanswer);
		$rows=@mysql_num_rows($getresult);
		$pollanswer=($rows >0)?@mysql_result($getresult,0,$answervar):0;

		//increment no of votes by 1 if already exist or set it to 0+1
		$pollanswer+=1;  
			
		//since set now update that pollresult table with one
		$updatesql="update pollresult set $answervar=$pollanswer where pid=$id";
		@mysql_query($updatesql);
showResult($id,$question,$answer1,$answer2,$answer3,$answer4,$answer5,$answer6,$answer);

	} else {
		$insertnew="insert into pollresult (pid,$answervar,noofanswers) values($id,1,$noa)";
		@mysql_query($insertnew);
showResult($id,$question,$answer1,$answer2,$answer3,$answer4,$answer5,$answer6,$answer);
	}
} else {
showResult($id,$question,$answer1,$answer2,$answer3,$answer4,$answer5,$answer6,$answer);
}
?>