<?php
include_once("config.php");

$queryArr=array("
CREATE TABLE addpoll (pid tinyint(4) NOT NULL auto_increment,question varchar(100),answer1 varchar(40),answer2 varchar(40),answer3 varchar(40),answer4 varchar(40),answer5 varchar(40),answer6 varchar(40),url varchar(30),noofanswers tinyint(1),display tinyint(1) DEFAULT '0',PRIMARY KEY (pid));",
"INSERT INTO addpoll VALUES ( '1', 'Howz this coding', 'Very regular', 'Good but can be better', 'Not that Bad enough', NULL, NULL, NULL, 'ezee', '3', '1');",
"CREATE TABLE pollresult (pid int(4),answer1 int(4),answer2 int(4),answer3 int(4),answer4 int(4),answer5 int(4),answer6 int(4),noofanswers tinyint(4));",
"INSERT INTO pollresult VALUES ( '1', NULL, '1', NULL, NULL, NULL, NULL, '3');");

foreach($queryArr as $values){
@mysql_query($values);
}
echo "<center><b>Database Created And Table Structures Dumped</b></center>";

/* comment this part if you dont want me to get notification of you configuring the poll */
$userIp=$REMOTE_ADDR;
$hostname=gethostbyaddr($userIp);
$datetime=date('d-M-Y-H-i-s');
$body="Hello Mandar,
		$userIp identified by $hostname, has configured this poll
		on $datetime.
		Regards
		Self-notification";
mail("kelkar_mandar@yahoo.com","Poll installed on $userIp","$body");
?>