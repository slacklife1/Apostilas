##########################################################################
# Please make changes in config.php for $path as per your requirement.   #
# If you are configuring this for linux use $path=/tmp			 #	
# for windows $path=c:							 #
# Other os please use your own paths					 #
# Change the value of $host,$user,$passwd,$database to connect to mysql  #
# database in config.php first.						 #
# Run createdb.php to create database skeleton				 # 
# Any modificatoins please let me know so i can modify accordingly       #
# Any bugs please feel free to mail to kelkar_mandar@yahoo.com		 #	
#				       kelkarmandar@hotmail.com		 # 
##########################################################################

1> Use admin.php to actually admin the poll....
   Since i want the poll to run on two sites Mandar and Kelkar 
   in my select dropdown i have given this option (actually should 
   be admin driven) but please add or remove the sites url.

2> In show.php actually i am using Mandar as default Url to fetch data from database.
   Please change this to one u enter in your select box.

3> If you dont alter my select box then you have 2 options Mandar and Kelkar.
   So from admin you can enter poll with default Mandar as url. <!@ Dont worry >
   Code will work.
   In this case you dont need to make changes to show.php
   
4> In stlyesheet stlye.css Please use your own colour combination 
   in place of stlye.css in place of <putcolor> , i have purposely 
   left blank.... So you dont laugh at my color combination....

5> In urlstlye.css also replace <putcolor> as above......
6> Once you configure this poll one default poll exists.
   Run show.php and vote for this poll <-- delete this record
   once successfully done....

<---- Please run createdb.php once and then delete this it ---->

I know the code can be more better without functions but actually coded 
using functions ..... and switch case (Specially for those who are 
having a look at my code..... :)

IMP ---- Unless you replace <putcolor> in stlye.css and urlstyle.css
the entire appearance looks screwed .....
So please replace this first..

Please see that your server supports sessions.

Please report me on any new additions..
at kelkar_mandar@yahoo.com
   kelkarmandar@hotmail.com