<?php
include_once("config.php");
include_once("functions.php");
include_once("urlstlye.css");

//enter the url of site to which this script is used
$url=mandar;
$sql="select * from addpoll where display=1 and url='$url'";
$result=@mysql_query($sql);
$pollRecordArray=@mysql_fetch_array($result);
echo "<form action=pollresult.php method=post>";
echo "	<table border=1 bordercolor=green align=center cellspacing=0 cellpadding=0 width=25%>
		<tr>
			<td class=question colspan=2>".$pollRecordArray['question']."</td>
		</tr>";

for($i=1; $i<=$pollRecordArray['noofanswers']; $i++){
	$answer=answer.$i;
echo "	<tr>
			<td class=answer>&nbsp;&nbsp;&nbsp;".$pollRecordArray[$answer]."</td>
			<td class=answer><input type=radio name=answer value=$i></td>
		</tr>";
}

echo "	<tr>
			<td class=answer>&nbsp;</td>
			<td class=answer><input type=submit value=' Vote '></td>
		</tr>";
echo "	</table>";
echo "<input type=hidden name=id value=".$pollRecordArray[pid].">";
echo "<input type=hidden name=noa value=".$pollRecordArray[noofanswers].">";
echo "<input type=hidden name=question value='".$pollRecordArray[question]."'>";
echo "<input type=hidden name=answer1 value='".$pollRecordArray[answer1]."'>";
echo "<input type=hidden name=answer2 value='".$pollRecordArray[answer2]."'>";
echo "<input type=hidden name=answer3 value='".$pollRecordArray[answer3]."'>";
echo "<input type=hidden name=answer4 value='".$pollRecordArray[answer4]."'>";
echo "<input type=hidden name=answer5 value='".$pollRecordArray[answer5]."'>";
echo "<input type=hidden name=answer6 value='".$pollRecordArray[answer6]."'>";
echo "</form>";
?>