<?php
include_once("functions.php");
site_header("Admin for polling");

function showForm($error){
echo "<font class=blue><center>Please enter question and select no of answers for it.";
echo $error;
echo "<br>";
echo "<form action=admin.php method=post>
	  <table action=admin.php method=post align=center cellspacing=1 cellpadding=2>
	  <tr>
		<td class=infoboxtitle>Enter Question</td>
		<td class=infoboxtitle><input size=12 type=text name='question'></td>
	  </tr>
	  <tr>
		<td class=infoboxtitle>No of answers</td>
		<td class=infoboxtitle><select name=noa>";
		for ($i=1; $i<7; $i++){
			if ($noa==$i){
			echo "<option value=$i selected>$i</option>";
			} else {
			echo "<option value=$i>$i</option>";		
			}
		}
echo "</select></td></tr>
	 <tr>
		 <td class=infoboxtitle>&nbsp;</td>
		 <td class=infoboxtitle><input type=submit value=' Submit '></td>
	</tr>
	  </table>
	  <input type=hidden name=state value=submit>	   
	  </form>";

}


function submit($question,$answer,$noa,$error,$url,$formaction,$recid){
	if ($question=='' || empty($question)){
	$error="<font color=red><center>Please fill in the question.";
	showForm($error);
	} else {
		if ($error){
			echo "<font class=red><center>$error</center></font>";
		}
	 echo "<form action=admin.php method=post>";	
	 echo"<table align=center cellspacing=1 cellpadding=2>
	  <tr>
		<td class=infoboxtitle>Your Question</td>
		<td class=infoboxtitle>";
		if ($formaction){
			echo "<input type=text name=question value='$question'>";
		} else {
		echo "<input type=hidden name=question value='$question'>$question";
		}
		echo "</td></tr>";

	  for ($i=0; $i<$noa; $i++){
		  $disp=$i+1;
		  echo "<tr>
				<td class=infoboxtitle>Answer $disp</td>
				<td class=infoboxtitle><input type=text name=answer[] value='$answer[$i]'";
			/*	if ($error){
					echo $answer[$i];
				} */
				echo "'></td>
				</tr>";
	  }


	 echo "<tr>
			 <td class=infoboxtitle>Select Url ";
			 if ($formaction){
				 echo "<font class=blue><u> $url </u></font>";
			 }
				echo "</td>
			 <td class=infoboxtitle>
				 <select name=url>
					<option value=mandar>Mandar</option>
					<option value=kelkar>Kelkar</option>
				 </select>
			 </td>
		   </tr>";

	 echo "<tr>
			 <td class=infoboxtitle>Make Active</td>
			 <td class=infoboxtitle>Check to make the poll live <input type=checkbox name=activate></td>
		   </tr>";
	 echo "<tr>
			 <td class=infoboxtitle>&nbsp;</td>
			 <td class=infoboxtitle><input type=submit value=' Submit '></td>
		   </tr>";
	  echo "</table>
	  <input type=hidden name=state value=";
	  if ($formaction){
		  echo newstate;
	  } else {
		  echo enter;
	  }
	  echo ">
	  <input type=hidden name=noa value=$noa>
	  <input type=hidden name=recid value=$recid>
	  </form>";
	}
}

function checkAnswer($question,$answer,$noa,$activate,$url){
	foreach ($answer as $key=>$value){
		if ($value=='' || empty ($value)){
			$error='yes';
		}
	}

	if ($url=='' || empty ($url)){
			$urlerror='yes';
		}

		if ($error){
		$error="<font class=red><center>Please fill in all answers.</center></font>";
		submit($question,$answer,$noa,$error,$url,$formaction,$recid);
		} elseif ($urlerror){
		$error="<font class=red><center>Please select the Url.</center></font>";
		submit($question,$answer,$noa,$error,$url,$formaction,$recid);
		} else {
		$sql="insert into addpoll (question,url,";
			if ($activate){
			//since i am making this a live poll other live should be made inactive since every site will have only one live poll
			$makesql="update addpoll set display=0 where url='$url'";
			@mysql_query($makesql);
				$sql.="display,";
			}
			foreach ($answer as $key => $values){
			$keys=$key+1;
			$sql.="answer$keys,";
			}
		$sql.="noofanswers) values ('$question','$url',";
			if ($activate){
				$sql.="1,";
			}
			foreach ($answer as $key => $values){
			$sql.="'$values',";
			}
		$sql.=count($answer).")";
		@mysql_query($sql);
		echo "<font class=blue><center>Poll entered successfully</center></font>";
		}

}



function displayall() {
showPollList($condition);
}

function displayallfordelete() {
showPollList('delete');
}

function displayallformodify() {
showPollList('modify');
}

function displaymodifyrec($recid){
$sql="select * from addpoll where pid=$recid";
$result=@mysql_query($sql);
$question=@mysql_result($result,0,'question');
$noa=@mysql_result($result,0,'noofanswers');
$answer=array();
for ($i=1;$i<=$noa;$i++){
$field="answer$i";
$getanswer=mysql_result($result,0,$field);
array_push($answer,$getanswer);
}
$geturl=mysql_result($result,0,'url');
$formaction='yes';
submit($question,$answer,$noa,$error,$geturl,$formaction,$recid);
}

function updateindb($recid,$question,$answer,$url,$noa,$activate){
//echo "$recid,$question,$answer,$url,$noa";
//print_r($answer);
$sql="update addpoll set question='$question',";
for($i=1;$i<=count($answer);$i++){
	$newi=$i-1;
	$sql.="answer$i='$answer[$newi]',";
	}
$sql.="url='$url'";
if ($activate){
	//since i am making this a live poll other live should be made inactive since every site will have only one live poll
	$makesql="update addpoll set display=0 where url='$url'";
	@mysql_query($makesql);

$sql.=",display=1";
} else {
$sql.=",display=0";
}
$sql.=" where pid=$recid";
@mysql_query($sql);
echo "<font class=blue><b><center>Poll updated successfully</center></b></font>";
}

function deletenow($deletearr){
//	print_r($deletearr);
$sql="delete from addpoll where ";
	foreach($deletearr as $value){
	$sql.="pid=$value or ";
	}

	$sql=substr($sql,0,strlen($sql)-3);
	@mysql_query($sql);
echo "<font class=blue><b><center>Poll deleted successfully</center></b></font>";
}


switch($state){
case show:showForm($error);
	break;
case submit:submit($question,$answer,$noa,$error,$url,$formaction,$recid);
	break;
case enter:checkAnswer($question,$answer,$noa,$activate,$url);
	break;
case viewpoll:displayall();
	break;
case deletepoll:displayallfordelete();
	break;
case modifypoll:displayallformodify();
	break;
case modifyrecords:displaymodifyrec($recid);
	break;
case newstate:updateindb($recid,$question,$answer,$url,$noa,$activate);
	break;
case deletepollrecords:deletenow($deletearr);
	break;
}
echo "</body></html>";
?>