<? 
if (isset($submitbookmark)) {
	include("common.php");	
	
	mysql_connect($hostname,$username,$passwrd) OR DIE("Oh twadi! Couldnt connect to the database, sorry mate!");
	@mysql_select_db($dbname) or die( "Unable to select database");
	$query3 = "INSERT INTO $tablename VALUES (NULL, '$folder','$linkname','$linkurl','$approved')";
	$result3 = mysql_query($query3);
}
?>

<table align=center cellspacing=10 width=100% border="0">
<tr>
	<td valign="top" width="60%"><strong class="black-header">all bookmarks</strong><br>
<?
include("common.php");	

	mysql_connect($hostname,$username,$passwrd) OR DIE("Oh twadi! Couldnt connect to the database, sorry mate!");
	@mysql_select_db($dbname) or die( "Unable to select database");
	$query2 = "SELECT folder, linkname, linkurl FROM $tablename WHERE approved='yes' ORDER BY folder";
	$result2 = mysql_query($query2) or die ("<strong class=black>Whoops! Something wrong happened to the my database! It would be nice if you emailed <a href=mailto:sandeep@wde.org>me</a> and told me!</strong>");
		if ($result2) {
			while ($r2 = mysql_fetch_array($result2)) {
			extract($r2);
			$linkname = strtolower($linkname);
				if ( $folder != $folder_previous)   {
		        echo "<strong class=black>&raquo; </strong> <strong class=black-small>$folder</strong><br>";
			   }
				echo " &nbsp;&nbsp;&nbsp; <strong class=black>-</strong> &nbsp; <small class=black-small><a href=$linkurl target=\"_blank\">$linkname</a></small><br>";
				$folder_previous = $folder;
			}	    
		echo "</td>";
		mysql_free_result($result2);	
		}
unset($linkname);
unset($linkurl);
unset($folder);

echo "<td valign=top width=40%>";

if (isset($submitbookmark)) {
	echo "<small class=black>your bookmark has been into the database! once it has been approved by me, it will show up here. <br><br> if you want to insert another bookmark, click <a href=\"$page\">here</a> </small><br><br>";
}
else {
	echo "<form action=\"$page\" method=post><input type=\"hidden\" name=\"approved\" value=\"no\">
				<strong class=black-header>send me a bookmark!</strong><br><br>";

				mysql_connect($hostname,$username,$passwrd) OR DIE("Oh twadi! Couldnt connect to the database, sorry mate!");
				@mysql_select_db($dbname) or die( "Unable to select database");	
				$query4 = "SELECT folder FROM $tablename GROUP BY folder";
				$result4 = mysql_query($query4) or die("<strong class=black>Whoops! Something wrong happened to the my database! It would be nice if you emailed <a href=mailto:$webmaster>me</a> and told me!</strong>");
					if ($result4) {
						echo "<table cellpadding=0 cellspacing=0><tr><td>folder :</td><td><select name=\"folder\"><option>";
						while ($r4 = mysql_fetch_array($result4)) {
							extract($r4);
								echo "
							<option value=\"$folder\">$folder";
						}
						echo "</select>";
						mysql_free_result($result4);
					}
				
	echo " </td></tr>
					<tr><td>site :</td> <td><input type=text name=\"linkname\" class=normal value=$linkname></td></tr>
					<tr><td>the url:</td> <td><input type=text name=\"linkurl\" class=normal value=\"http://\"></td></tr>
					<tr><td colspan=2 align=center><input type=\"submit\" name=\"submitbookmark\" value=\"submit bookmark\"></td></tr> </table>
			</form><br>";
}

	mysql_connect($hostname,$username,$passwrd) OR DIE("Oh twadi! Couldnt connect to the database, sorry mate!");
	@mysql_select_db($dbname) or die( "Unable to select database");
	$query1 = "SELECT * FROM $tablename WHERE approved='yes' ORDER BY id DESC LIMIT 10";
	$result1 = mysql_query($query1) or die ("<strong class=black>Whoops! Something wrong happened to the my database! It would be nice if you emailed <a href=mailto:$webmaster>me</a> and told me!</strong>");
		if ($result1) {
		echo "<strong class=black-header>last 10 bookmarks submitted</strong><br>";
			while ($r1 = mysql_fetch_array($result1)) {
			extract($r1);
			$linkname = strtolower($linkname);
				echo " <strong class=black-large>&raquo;</strong> <strong class=black-small><a href=$linkurl target=\"_blank\">$linkname</a></strong><br>";
			}
		echo "</td>";
		mysql_free_result($result1);
		}

echo "</table>";
?>