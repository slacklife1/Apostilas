<?
include("common.php");

if (isset($addbookmark)) {
	if (strlen($folder2) > 3) { $folder = $folder2; }
	$query3 = "INSERT into $tablename values (NULL, '$folder','$linkname','$linkurl','$approved')";
	$result3 = mysql_query($query3);
	header("Location: $adminpage");
	}

elseif (isset($approve)) {	
	$query4 = "UPDATE $tablename SET approved='yes' WHERE id='$id' ";
	$result4 = mysql_query($query4);
	header("Location: $adminpage");
}

elseif (isset($delete)) { 
	$query5 = "DELETE FROM $tablename WHERE id='$id' ";
	$result5 = mysql_query($query5);
	header("Location: $adminpage");
}	

else {
?>	
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Admin -  Bookmarks!</title>
</head>

<body bgcolor="ffffff" text="000000">
	
<form action="<? echo $adminpage; ?>" method="post">
<input type="hidden" name="approved" value="yes">

<table align=center cellspacing=10 width="80%">
	<tr><td colspan=2><hr color="990000" size="2" noshade width="100%">
		<h2>Add a bookmark</h2></td>
	</tr>

	<tr>
		<td align=right><strong>the folder : </strong></td>
		<td>
		<?
			$query2 = "SELECT folder FROM $tablename GROUP BY folder";
			$result2 = mysql_query($query2) or die("<strong class=black>Whoops! Something wrong happened to the my database! It would be nice if you emailed <a href=mailto:$webmaster>me</a> and told me!</strong>");
				if ($result2) {
				echo "<select name=\"folder\"><option>";
					while ($r2 = mysql_fetch_array($result2)) {
						extract($r2);
						echo "
						<option value=\"$folder\">$folder";
					}
					echo "</select>";
					mysql_free_result($result2);
				}
		?> <input type="text" name="folder2">
		
		</td></tr>

	<tr><td align=right valign=top><strong>bookmark name</strong></td><td><input type="text" name="linkname" size="50" maxlength="40"></td></tr>
	<tr><td align=right valign=top><strong>link / url</strong></td><td><input type="text" name="linkurl" size="50" maxlength="255" value="http://"></td></tr>

	<tr><td colspan="2" align="center"><input type="submit" name="addbookmark"><br><hr color="990000" size="2" noshade width="100%"></td></tr>
</table>
</form>

	<?
	$query1 = "SELECT * FROM $tablename WHERE approved='no' ORDER BY id";
	$result1 = mysql_query($query1) or die ("<strong class=black>Whoops! Something wrong happened to the my database! It would be nice if you emailed <a href=mailto:$webmaster>me</a> and told me!</strong>");
	if ($result1) {
	echo "<table align=center cellspacing=10 width=80%>
					<tr><td colspan=4><hr color=990000 size=2 noshade width=100%><h2>Approve bookmarks</h2></td></tr>";
							while ($r1 = mysql_fetch_array($result1)) {
							extract($r1);
							echo "<form action=\"$adminpage\" method=\"post\"><tr><td><strong>$folder</strong></td><td><strong><a href=$linkurl target=_blank>$linkname</a></strong></td><td><input type=\"submit\" name=\"approve\" value=\"approve\"></td><td><input type=\"submit\" name=\"delete\" value=\"delete\"></td></tr><input type=\"hidden\" name=\"id\" value=\"$id\"></form>";
							}
	echo "<tr><td colspan=4 align=center><hr color=990000 size=2 noshade width=100%></td></tr></table>";
	mysql_free_result($result1);	
	}
	?>
	
	<?
}
?>
</body>
</html>
