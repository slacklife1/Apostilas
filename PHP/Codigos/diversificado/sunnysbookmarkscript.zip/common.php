<?
$hostname = "sql.host.com";
$dbname = "databname";
$username = "user";
$passwrd = "password";
// database details above which you need to change!

mysql_connect($hostname,$username,$passwrd) OR DIE("Oh damn! Couldnt connect to the database, sorry mate!");
@mysql_select_db($dbName) or die("Unable to select database"); 

$tablename = "bookmarks"; // the table which stores your bookmarks
$webmaster = "youremail@yoursite.com"; // your email incase there are errors querying database

$page = "index.php";
$adminpage = "admin.php";
// what have you called the pages? this is to ensure netscape and ie compatibiity.

?>