read me for sunny's online bookmarks 1.0

- description of files :
	+ index.php : this is the main page where your bookmarks get displayed and people can send you bookmarks.
	+ common.php : has all the database and main variables you need to edit. you cannot use the bookmarks script without editing this file!
	+ database.sql : this contains the sql to make a table for your bookmarks. you can either type it out into your mysql prompt or do something 
	like this when you telnet to your server - 
		mysql -h(mysql_host_address) -u(your_username) -p(yourpassword) (database name) < ./database.sql 
		but you have to make sure that you are currently in the directory where database.sql file resides, otherwise it wont be able to find the file to create the table.
		
	+ admin.php : this file is used to delete or approve bookmarks sent to you, and you can also use to add new bookmarks.
	+ styles.css : the style sheet to control font looks as well as the input boxes borders.


- installation	of application :	
	1 unpack all the files into a folder, something like : "http://www.yourhomepage.com/bookmarks/"
	2 make the tables in your database using file "database.sql" (you can change the name of the tables if you want).
	3 edit common.php to replace with your own variables. this needs to be changed for certain!
	5 go to the admin file where you unpacked the files, and add a bookmarks to see it working!

if you have any problems, you are welcome to leave questions at my php mini-forum at : 	
http://www.wde.org/me/php/ 
and i'll try and help you out.

also, it would be nice to let me know by email or on my messagebaord as to where you've used this application, and if you made any changes, as i might include them. join the mailing list on my site to know when i've improved this application (i got loads of things planned!) or released others for people to use.

/sunny
sunny@wde.org 


