CREATE TABLE bookmarks (
   id smallint(6) NOT NULL auto_increment,
   folder varchar(30),
   linkname varchar(50),
   linkurl varchar(255),
   approved char(3) DEFAULT 'no' NOT NULL,
   PRIMARY KEY (id)
);