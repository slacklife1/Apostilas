################################################################################
# MY Random Image Displayer Version 1.00  , Released: 18-07-2001
# Copyright (C) 2001 MERT YALDIZ - mertyaldiz@yahoo.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################


MY Random Image displayer V.1.0
Displays random images on your pages with the proper links and alt texts.

SETUP
-----------

Just modify the first 7 lines in myrandomimage.php

$banners= array('1.gif','2.gif','3.gif');
$alt_texts= array ('alt_text1','alt_text2','alt_text3');
$links= array('link1','link1','link1');  (e.g. 'http://www.yoursite.com')
$border="0"; (border width)
$target="_blank"; (link target)
$width=""; (image width)
$height=""; (image height)
$action=""; (If you want to use with javascript write "js" else leave it empty)

* UPLOAD THE SCRIPT IN ASCII MODE

Usage:
------------
Include anywhere in a page where you want to display random images.

e.g. (include in a php file) as
include("myrandomimage.php");

or
you may use as ssi (.shtml file)

<!--#include virtual="myrandomimage.php" -->

or you may use via javascript within any HTML file;

<script language="javascript" src="myrandomimage.php"></script>
