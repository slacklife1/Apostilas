<?
/*
MY RANDOM IMAGE DISPLAYER Version 1.00
Copyright (C) 2001 Mert Yald�z - mertyaldiz@yahoo.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

// modify the 7 lines below
$banners= array('images/banner1.gif','images/banner2.gif','images/banner3.gif');
$alt_texts= array ('alt_text1','alt_text2','alt_text3');
$links= array('http://www.mert.org','link1','link1'); /* e.g. 'http://www.yoursite.com' */
$border="0";
$target="_blank";
$width="140";
$height="50";
$action="";// for javascript enter 'js' else leave empty.

// YOU DO NOT NEED TO MODIFY BELOW

$random_no= count($banners);
$random=$random_no-1;

mt_srand ((double) microtime () * 1000000);
$rnd= mt_rand(0,$random);

$banner=$banners[$rnd];
$alt_text=$alt_texts[$rnd];
$link=$links[$rnd];

if ($action=="js")
	{
		echo("document.write('<a href=\"$link\" target=\"$target\"><img src=\"$banner\" border=\"$border\" width=\"$width\" height=\"$height\" alt=\"$alt_text\"></a>');");
	}
	else 
	{
		echo"<a href=\"$link\" target=\"$target\"><img src=\"$banner\" border=\"$border\" width=\"$width\" height=\"$height\" alt=\"$alt_text\"></a>";
	}
	?>


