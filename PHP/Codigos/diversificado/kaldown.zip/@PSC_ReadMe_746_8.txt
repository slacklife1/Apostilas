Title: kaldown
Description: kaldown give you possibility to :
+ count number of hits on your files (or your links) 
+ view time of latest hit 
+ view IP of latest person who hit a link
+ address like : http://www.yoursite.com/go.php?id=x
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=746&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
