<?
//-----------------------------------------
// Author :	Tarik kallida
// Email :      	kallida@caramail.com
// Age :                  16 years
// Country :            Morroco (North Africa)
// Licence :             GNU/GPL (See http://www.gnu.org for more Information)
//-----------------------------------------
$file = "data/$id.txt";
$open = fopen("$file","r+");
$read = fgets($open,100);
$link = explode('|',$read);

$new_hits = $link[1]+1;
$new_date = gmdate("Y-m-d H:i");
$new_ip = $REMOTE_ADDR;

$new_read="$link[0]|$new_hits|$link[2]|$new_date|$new_ip";

fseek($open,0);
fputs($open,$new_read);
fclose($open);

print Header("location: $link[0]");
?>