<?
//-----------------------------------------
// Author :	Tarik kallida
// Email :      	kallida@caramail.com
// Age :                  16 years
// Country :            Morroco (North Africa)
// Licence :             GNU/GPL (See http://www.gnu.org for more Information)
//-----------------------------------------
include("config.inc.php");
include("lang/$lang.lang.php");
//-----------------------------------------
echo"<html ";
    if($lang==arabic) {echo 'dir=rtl';}   
 echo"><head><title>Kaldown : $message[7] : $link_name</title></head><body bgcolor=$bgcolor> <meta http-equiv='Content-Type' content='text/html; charset=$charset'>";

echo"
<p>$message[7] $message[8]</p>
<div align=left>
  <table border=1 cellpadding=0 cellspacing=0 bordercolor=$font_color width=50 height=65>
    <tr>
      <td width=361 height=106 dir=ltr>
   &lt;script language=&quot;javascript&quot;
  <br>src=&quot;$site_url/display.php?type=text&id=$id&quot;&gt;&lt;/script&gt;</td>
   </tr>
</table>

</div>
<p>$message[7] $message[53]</p>
<div align=left>
  <table border=1 cellpadding=0 cellspacing=0 bordercolor=$font_color width=361 height=106>
   <tr>
      <td width=361 height=106 dir=ltr>
      &lt;script language=&quot;javascript&quot;
  <br>src=&quot;$site_url/display.php?type=graphic&id=$id&quot;&gt;&lt;/script&gt;</td>
    </tr>
  </table>
</div>";
?>