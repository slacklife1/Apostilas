<?
//-----------------------------------------
// Author :	Tarik kallida
// Email :      	kallida@caramail.com
// Age :                  16 years
// Country :            Morroco (North Africa)
// Licence :             GNU/GPL (See http://www.gnu.org for more Information)
//-----------------------------------------
 session_save_path("./sessions");
 session_start();  
 session_unregister("password");  
 session_unset(); 
 session_destroy();  
//-----------------------------------------
 print Header("Location: login.php") ;  
?>

