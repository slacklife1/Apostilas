<? 
//-----------------------------------------
// Author :	Tarik kallida
// Email :      	kallida@caramail.com
// Age :                  16 years
// Country :            Morroco (North Africa)
// Licence :             GNU/GPL (See http://www.gnu.org for more Information)
//-----------------------------------------
//---  you must have PHP => 4.0.1 so that this script work correctly  ----------
   session_save_path("./sessions");
   session_start();                 
   if ( !session_is_registered("password"))
          { 
       print Header("Location:login.php"); 
                    } 
  else
  {    
//------------------------------------------------------------------------------
include("config.inc.php");  //include configuration
include("lang/$lang.lang.php");

//---------------------------------functions------------------------------------
$style="style='BACKGROUND-COLOR: $bgcolor; COLOR: $font_color ;FONT-FAMILY: $font_face'";

function Input($type,$name,$size,$dir,$style,$value)
                                {
echo"&nbsp;<input type='$type' name='$name' size='$size' dir='$dir' $style  value='$value'>";
                                }
//------------------------------------------------------------------------------
 echo"<html ";

    if($lang==arabic) {echo 'dir=rtl';}   

 echo"><head><title>Administration of kaldown $version</title>
      <meta http-equiv='Content-Type' content='text/html; charset=$charset'>
       <STYLE>
       A:link{COLOR:$a_link;TEXT-DECORATION:none}
       A:hover{COLOR:$a_hover;FONT-WEIGHT: bold;TEXT-DECORATION:none}
       A:visited {COLOR:$a_visited;TEXT-DECORATION:none}
       </STYLE></head>
       <body bgcolor=$bgcolor><fontbase=$font_face colorbase=$font_color sizebase=2>
       <table border=2 bordercolor=$table_border_color>
       <tr>
       <td width=100% height=120 colspan=2><p align=center>
       <a href=$kaldown_url><img src=../img/logo_kaldown.jpg border=0></a><br>";
 if($lang==arabic)
                              { 
            echo "<font color=$font_color size=2>����� � �����: <a href=mailto:kallida@caramail.com>
                       ���� ����� </a>16 ��� �� ������";
                              }

 if($lang==french)
                             { 
                         echo "<font color=$font_color size=2>Programmation & design
 : <a href=mailto:kallida@caramail.com>Tarik kallida </a>16 ans du Maroc ...";
                             }

 if($lang!=french && $lang!=arabic) 
                           { 
                       echo "<font color=$font_color size=2>Programming & design by 
 : <a href=mailto:kallida@caramail.com>Tarik kallida </a>16 Years old From Morroco ...</font>";
                            }
echo"
</td>
    </tr>
    <tr>
        <td width=150 height=0 valign=top><p>
<br>
<table border=1 bordercolor=$table_border_color align=center >
    <tr>
        <td width=110 height=26 align=center bgcolor=
$table_bgcolor><p><font size=2><b>
<a href=./?s=$s>$message[36]</a></td>    </tr>
  
</table><br>
<table border=1 bordercolor=$table_border_color align=center>
    <tr>
        <td width=90% height=26 align=center bgcolor=$table_bgcolor><p><font size=2 color=$font_color><b>$message[37]</td>    </tr>
    <tr>
        <td width=100 height=27><center>
   <a href=./?s=$s&action=add><font size=2><b>$message[38]</a><br>
     <a href=./?s=$s&action=view><font size=2><b>$message[39] </a><br>
       <a href=./?s=$s&action=view><font size=2><b>$message[40]</a><br> </tr></tr>
</table>
<br>
<table border=1 bordercolor=$table_border_color align=center>
    <tr>
        <td width=90% height=26 align=center  bgcolor=$table_bgcolor><p><font size=2 color=$font_color><b>$message[41]</td></tr>
    <tr>
        <td width=100 height=27><center>
   <a href=./?s=$s&action=options><font size=2><b>$message[42]</a><br>
   <a href=./?s=$s&action=changepass><font size=2><b>$message[43]</a><br>
      </tr></tr>
</table><br>
<table border=1 bordercolor=$table_border_color align=center>
    <tr>
        <td width=110 height=26 align=center bgcolor=$table_bgcolor><p><font size=2><b><a href=logout.php?s=$s>$message[44]</a>
</td></tr></table><br>
</td>
        <td width=635 height=400 valign=top><p>&nbsp";

 switch($action) {
 case "view";      

$folder='../data';
$handle=opendir($folder);
//-----------------------------------------
 echo "<script language=\"JavaScript\">
<!--
function MM_goToURL() {
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+\".location='\"+args[i+1]+\"'\");
                                        }
</script>";
$nb_of_files=0;

   while ($files = readdir($handle))

            {
             $extension= strtolower(substr( strrchr($files, "." ), 1 ));

              if ($extension==txt)

                            {
                            $name_of_files=substr($files,0,strlen($files)-4);
                            $compteur=$compteur+$nb_download;
                            $nb_of_files++;
                            $id[$nb_of_files]="$name_of_files";
                            $links[$nb_of_files]="../go.php?id=$name_of_files";
                            }
              }
//-----------------------------------------
   echo"<center>
            <font size=2 color=$font_color>$message[4] <b>$nb_of_files</b>
             $message[5]</font> ";

  $next=0;
  while ($next<$nb_of_files)
           {
           $next++;
//-----------------------------------------
$file = "../data/$id[$next].txt";
$open = fopen("$file","r");
$read = fgets($open,100);
$link = explode('|',$read);
//-----------------------------------------
echo "
<TABLE align=center bgColor=black border=0 cellPadding=2 cellSpacing=0 width=90% ><TBODY><TR><TD>
<TABLE align=center bgColor=$bgcolor border=0 cellPadding=3 cellSpacing=0 width='100%' dir=ltr><TBODY><TR>
<TD bgColor=$table_bgcolor width='40%'>&nbsp; <A href='../go.php?id=$id[$next]' title='Go to $link[2]' target=_blank>
<font face=$font_face size=2 color=$font_color><b>$link[2]</b></A> </TD><TD align=right bgColor=$table_bgcolor width='50%'>
<font face=$font_face size=2 color=$font_color> <b>
<a name=$id[$next]>
<a href=./?s=$s&action=modify&id=$id[$next]><img src=../img/$lang.modify.gif border=0></a>
<a href=\"#$id[$next]\" onclick=\"if(confirm('$message[6] : $link[2] ? ')) MM_goToURL('self','./?s=$s&action_ok=delete&id=$id[$next]');return \">
<img src=../img/$lang.delete.gif border=0>  </a>  </TD></TR><TR><TD colSpan=10><TABLE align=center border=0 width='100%'><TR><TD width='100%'>
<font style='font-family: $font_face; font-size: 10pt; color: $font_color'>";
//-----------------------------------------
if ($link[1] == 0 OR empty($link[3])) { $gmt = ""; } else { $gmt = "GMT"; }
if ($lang == ar) { $dir=rtl; } else { $dir="ltr"; }
echo"<font dir=$dir>ID : <b>$id[$next]</b> &nbsp;<b>|</b>&nbsp;
$message[9] : <b>$link[1]</b><br>
 $message[54] : <b>$link[3] $gmt</b>&nbsp;
<b>|</b>&nbsp; $message[55] : <b>$link[4]</b> <br>
 URL : <a href=$link[0] target=_blank>$link[0]</a>


<hr color=$table_bgcolor width=190%>
<A HREF=\"./?s=$s&get=code&id=$id[$next]\"
  onClick=\"window.open('code.php?id=$id[$next]&link_name=$link[2]','code','toolbar=0,location=0,directories=0,status=0,scrollbars=0,resizable=1,copyhistory=0,menuBar=0,width=420,height=350');return(false)\">
$message[7]</A>


</TD></TR></TBODY></TABLE></TD></TR>
</TBODY></TABLE></TD></TR></TBODY></TABLE><br>";
}
echo "</table>";
closedir($handle);
break;
//-----------------------------------------
case "add";
$file = "../data/count.number";
 $open = fopen("$file","r");
 $id = fgets($open,100);
 $id++;
 echo"
<p align=center><font color=$font_color face=$font_face size=5>
 $message[52] (Next Autoindex : $id)</font></p>
<center>
<form action=./?s=$s&action_ok=add method=post>
<input type=hidden name=id value=$id>
<table border=1 cellpadding=10 cellspacing=2
style=border-collapse: collapse bordercolor=#111111 width=90% height=100>
  <tr>
    <td width=29% height=20><font face=$font_face size=2 color=$font_color>
<b>&nbsp;&nbsp;&nbsp; $message[50] :</b></td>
    <td width=90% height=20><font face=$font_face>";
//-----------------------------------------
 Input(text,link_name,40,ltr,$style,$link_name);
//-----------------------------------------
 echo"</td></tr><tr>
<td width=29% height=19><font face=$font_face size=2 color=$font_color>
<b>&nbsp;&nbsp;&nbsp; $message[2] :</b></td>
<td width=90% height=19><font face=$font_face>";
//-----------------------------------------
 if(empty($url)) { $url = "http://"; }
 Input(text,url,60,ltr,$style,$url);
//-----------------------------------------
 echo"</td></tr></table><p> ";
//-----------------------------------------
Input(submit,submit,20,ltr,$style,$message[3]);
Input(reset,reset,20,ltr,$style,Reset);
//-----------------------------------------
 echo"</form>";
break;
case "modify";
 $file = "../data/$id.txt";
 $open = fopen("$file","r");
 $read = fgets($open,100);
 $link = explode('|',$read);
//-----------------------------------------
 $message[51] = str_replace('{NAME_OF_LINK}', $link[2], $message[51]);
//-----------------------------------------

echo"
<p align=center><font face=$font_face color=$font_color size=5> $message[51] </font></p>
<table width=90% border=1 height=55% bordercolor=#000000 align=center>
  <tr>
    <td align=center><font face=$font_face size=2 color=$font_color><b>$message[1]</b></font></td>
    <td>
<form method=post action=./?s=$s&action_ok=modify&id=$id>
<font face=$font_face size=2 color=$font_color><b>&nbsp;&nbsp;$id</b><font>
</td></tr><tr><td align=center>
<font face=$font_face size=2 color=$font_color><b>$message[50] : </b></td><td> ";
//-----------------------------------------
Input(text,link_name,40,ltr,$style,$link[2]);
//-----------------------------------------
echo"<tr><td align=center>
<font face=$font_face size=2 color=$font_color><b>$message[2] : </b></td><td>";
//-----------------------------------------
Input(text,url,60,ltr,$style,$link[0]);
//-----------------------------------------
echo"<br></td></tr><tr><td align=center>
<font face=$font_face size=2 color=$font_color><b>$message[9] : </b></td><td>";
//-----------------------------------------
Input(text,nb,10,ltr,$style,$link[1]);
//-----------------------------------------
echo"<br></td></tr><tr><td align=center>
<font face=$font_face size=2 color=$font_color><b>$message[54] : </b></td><td>";
//-----------------------------------------
Input(text,last_date,40,ltr,$style,$link[3]);
//-----------------------------------------
echo"<br></td></tr><tr><td align=center>
<font face=$font_face size=2 color=$font_color><b>$message[55] : </b></td><td>";
//-----------------------------------------
Input(text,last_ip,40,ltr,$style,$link[4]);
//-----------------------------------------
echo"</td></tr></table><p align=center>";
//-----------------------------------------
Input(submit,submit,40,ltr,$style,$message[10]);
Input(Reset,Reset,40,ltr,$style,Reset);
//-----------------------------------------
echo"</form>";

break;
case "options";
echo"<p align=center><font face=$font_face size=5 color=$font_color>$message[23]</font></p>
<table width=90% border=1 height=250 bordercolor=
$table_border_color align=center>
  <tr>
    <td align=center><font face=$font_face size=2 color=$font_color> $message[16]</font></td>
    <td>
<form name=options action=./?s=$s&action_ok=options method=post>
      &nbsp;<select name=new_lang $style>";
//-----------------------------------------
$folder="./lang"; 
    $read=opendir($folder); 
    $ext_lang=".lang.php"; 
    $long_ext=strlen($ext_lang); 
    $i=0; 
    $cpt=0; 

while($files=readdir($read)) 
        { 
        $long_file=strlen($files)-$long_ext; 
        $name_of_files=substr($files,0,strlen($files)-9);

       if (($files!=".") and ($files!="..") and (substr 
      ($files,$long_file,$long_ext)==$ext_lang)) 
  
      if($lang==$name_of_files)
                    { 
                   echo"<option value=$name_of_files                              SELECTED>$name_of_files</option>"; 
                   }
            else 
                 { 
                 echo"<option value=$name_of_files>$name_of_files</option>"; }
               $cpt++; 
                 } 
//-----------------------------------------
echo"
      </select>
    </td>
  </tr>
  <tr>
    <td align=center><font face=$font_face size=2 color=$font_color> $message[17]</font></td>
    <td>";
//-----------------------------------------
 Input(text,new_site_url,50,ltr,$style,$site_url);
//-----------------------------------------
 echo"</td>
  </tr>
  <tr>
    <td align=center><font face=$font_face size=2 color=$font_color> $message[18]</font></td>
    <td>";
//-----------------------------------------
 Input(text,new_images_url,50,ltr,$style,$images_url);
//-----------------------------------------
  echo"</td>
  </tr>
  <tr>
 <td align=center><font face=$font_face size=2 color=$font_color> $message[19]</font></td>
    <td>";
//-----------------------------------------
 Input(text,new_ext,15,ltr,$style,$ext);
//-----------------------------------------
 echo"</td>
  </tr>
</table>
<p align=center><font face=$font_face size=5 color=$font_color>$message[24]</font><br></p>
<table width=90% border=1 height=250 bordercolor=
$table_border_color align=center>
  <tr>
    <td width=61% align=center><font face=$font_face size=2 color=$font_color> $message[26]</font></td>
    <td width=39%>";
//-----------------------------------------
 Input(text,new_bgcolor,20,ltr,$style,$bgcolor);
//-----------------------------------------
  echo"  </td>
  </tr>
  <tr>
    <td width=61% align=center><font face=$font_face size=2 color=$font_color> $message[56]</font></td></td>
    <td width=39%>";
//-----------------------------------------
 Input(text,new_table_bgcolor,20,ltr,$style,$table_bgcolor);
//-----------------------------------------
  echo"  </td>
  </tr>
  <tr>
    <td width=61% align=center><font face=$font_face size=2 color=$font_color> $message[20]</font></td></td>
    <td width=39%>";
//-----------------------------------------
 Input(text,new_table_border_color,20,ltr,$style,$table_border_color);
//-----------------------------------------
 echo"  </td>
  </tr>
  <tr>
    <td width=61% align=center><font face=$font_face size=2 color=$font_color> $message[27]</font></td></td>
    <td width=39%>";
//-----------------------------------------
 Input(text,new_a_link,20,ltr,$style,$a_link);
//-----------------------------------------
  echo"  </td>
  </tr>
  <tr>
   <td width=61% align=center><font face=$font_face size=2 color=$font_color> $message[28]</font></td>
    <td width=39%>";
//-----------------------------------------
 Input(text,new_a_hover,20,ltr,$style,$a_hover);
//-----------------------------------------
  echo"  </td>
  </tr>
  <tr>
<td width=61% align=center><font face=$font_face size=2 color=$font_color> $message[29]</font></td>
    <td width=39%>";
//-----------------------------------------
 Input(text,new_a_visited,20,ltr,$style,$a_visited);
//-----------------------------------------
   echo" </td>
  </tr>
  <tr>
<td width=61% align=center><font face=$font_face size=2 color=$font_color> $message[30]</font></td>
    <td width=39%>";
//-----------------------------------------
 Input(text,new_font_color,20,ltr,$style,$font_color);
//-----------------------------------------
     echo"</td>
  </tr>
  <tr>
<td width=61% align=center><font face=$font_face size=2 color=$font_color> $message[31]</font></td>
    <td width=39%>";
//-----------------------------------------
 Input(text,new_font_face,20,ltr,$style,$font_face);
//-----------------------------------------
   echo" </td>
  </tr>
</table>
<p align=center>";
//-----------------------------------------
 Input(submit,submit,20,ltr,$style,$message[25]);
 Input(reset,reset,20,ltr,$style,Reset);
//-----------------------------------------
echo"</p><p></p></body></html>";
//-----------------------------------------

break;
case "changepass";
echo"<p align=center><font face=$font_face size=5 color=$font_color>$message[32]</font></p>
<table width=90% border=1 height=250 bordercolor=
$table_border_color align=center>
 <form name=options action=./?s=$s&action_ok=changepass method=post>
   <tr>
    <td align=center><font face=$font_face size=2 color=$font_color> $message[33]</font></td>
    <td> ";
//-----------------------------------------
 Input(password,old_pass,20,ltr,$style,'');
//-----------------------------------------
echo"</td>
  </tr>
  <tr>
    <td align=center><font face=$font_face size=2 color=$font_color> $message[34]</font></td>
    <td>";
//-----------------------------------------
 Input(password,new_pass,20,ltr,$style,'');
//-----------------------------------------
 echo"</td>
  </tr>
  <tr>
 <td align=center><font face=$font_face size=2 color=$font_color> $message[35]</font></td>
    <td>";
//-----------------------------------------
 Input(password,two_new_pass,20,ltr,$style,'');
//-----------------------------------------
echo"</td>
  </tr>
</table><p align=center>";
//-----------------------------------------
 Input(submit,submit,20,ltr,$style,$message[25]);
 Input(reset,Reset,20,ltr,$style,Reset);
//-----------------------------------------
echo"</p><p></p></body></html> ";
break;
default;
echo"<table width=95% border=0 height=10 align=center>
  <tr>
    <td>";
if ($lang!=french && $lang!=arabic) {

echo"
<font size=5 color=$font_color>Welcome To administration</font>
<br><br>
<font color=$font_color size=2>
From Here you can admin Kaldown V$version , if it your first visit , please change from <a href=./?s=$s&action=changepass>Here</a> The deflaut password to any password you want  ...<br>
you must also change some options in the <a href=./?s=$s&action=options>Options page</a> as the path where you have opload this script ... etc ...<br>
to add a new link  <a href=./?s=$s&action=add>click here</a> ...<br>
to modify or delete some links <a href=./?s=$s&action=modify>click here</a> <br>
if you have any problem , feel free to contact me at <a href=mailto:kallida@caramail.com>kallida@caramail.com</a>...<br>
To get the lastest Version Please go to <a href=$kaldown_url target=_blank>Kaldown Home page</a> ...";  }

if ($lang==french) {
echo"
<font size=5 color=$font_color>Bienvenue dans  l'administration</font>
<br><br>
<font color=$font_color size=2>
D'ici vous pouvez administrer Kaldown V$version , si c'est v�tre premi�re visite , changez s'il faut pla�t <a href=./?s=$s&action=changepass>de cette page</a>  le mot de passe par defaut par un mot de passe de v�tre choix    ...<br>
Vous devez aussi changer quelques options dans <a href=./?s=$s&action=options>la page des Options </a> comme le chemin vers le script  ... etc ...<br>
Pour ajouter un nouveau lien  <a href=./?s=$s&action=add>cliquez ici</a> ...<br>
Pour modifier ou supprimer quelques liens <a href=./?s=$s&action=modify>cliquez ici</a> ...<br>
Si vous avez le moins probl�me n'�sitez pas � me contactez => <a href=mailto:kallida@caramail.com>kallida@caramail.com</a>... 
<br>
Pour obtenir la dernier version de Kaldown aller �  <a href=$kaldown_url target=_blank>la page de Kaldown</a> ...";
 } 

if ($lang==arabic) {
echo"
<font size=5 color=$font_color>����� �� �� �������</font>
<br><br>
<font color=$font_color size=2>
�� ��� ����� ������ �� Kaldown V$version , ��� ��� ��� ��� ����� �� , �� ���� ����  <a href=./?s=$s&action=changepass>�� ���</a>  ���� ���� ��� ���� �� �������   ...<br>
��� ���� ���� ����� ��� �������� �� <a href=./?s=$s&action=options>���� ���������� </a> <br>
������ ���� ����  <a href=./?s=$s&action=add>���� ���</a> ...<br>
������ �� ��� ��� ������� <a href=./?s=$s&action=modify>���� ���</a> ...<br>
��� ��� ���� ���� �� ������� �� ����� �� ������� => <a href=mailto:kallida@caramail.com>kallida@caramail.com</a>... 
<br>
������ ��� ��� ���� �� �������   <a href=$kaldown_url target=_blank>���� ���</a> ...";
 } 
echo"</td>
  </tr>
</table>";
break;
}
//-----------------------------------------
switch($action_ok) {

case "add";
 if(empty($link_name) || empty ($url))
              {
               echo "<script language=Javascript>
               alert('$message[11]');
               window.location='./?s=$s&action=add&url=$url&link_name=$link_name';
                </script>";
                exit();
               }
     elseif(file_exists("../data/$id.txt"))
               {
                echo "<script language=Javascript>
                alert('$message[13]');
                window.location='$HTTP_REFERER';
                </script>";
                 exit();
                }
     else
               {
               $file = "../data/$id.txt";
               $nb=0;
               $last_click = Never;

               $data="$url|$nb|$link_name|$last_click";

               $open = fopen("$file","w+");
               fseek($open,0);
               fputs($open,$data);
               fclose($open);

               $file = "../data/count.number";
               $open = fopen("$file","r");
               $id = fgets($open,100);
               $id++;
               fclose($open);

              $open = fopen("$file","w+");
              fputs($open,$id);
              fclose($open);

              echo "<script language=Javascript>
                         alert('$message[14]');
                         window.location='./?s=$s&action=view';
                        </script>";
             }
break;
//-----------------------------------------
case "modify";
    if(empty($link_name) || empty($url))
         {
           echo "<script language=Javascript>
                      alert('$message[11]');
                       window.location='$HTTP_REFERER';
                       </script>";
          }
     else
          {
            if(empty($nb)) { $nb = "0"; }
            $file = "../data/$id.txt";
            $data="$url|$nb|$link_name|$last_date|$last_ip";

             $open = fopen("$file","w+");
             fseek($open,0);
             fputs($open,$data);
             fclose($open);

              echo "<script language=Javascript>
                          alert('$message[12]');
                          window.location='./?s=$s&action=view';
                           </script>";
             }
break;
//-----------------------------------------
case "delete";
if (!empty($id))
     {
     unlink("../data/$id.txt");
     echo "<script language=Javascript>
                alert('$message[15]');
                 window.location='./?s=$s&action=view';
                 </script>";
      }
else
      {
       echo"$message[11]";
      }
break;
//-----------------------------------------
case "options";
     $options="config.inc.php";
     $open = fopen("$options","w+");

     $config="<?\n";
     $config.="\$version='3.2.1';\n";
     $config.="\$kaldown_url='http://kaldown.sourceforge.net';\n";
     $config.="\$lang='$new_lang';\n";
     $config.="\$site_url='$new_site_url';\n";
     $config.="\$images_url='$new_images_url';\n";
     $config.="\$ext='$new_ext';\n";
     $config.="\$bgcolor='$new_bgcolor';\n";
     $config.="\$table_bgcolor='$new_table_bgcolor';\n";
     $config.="\$table_border_color='$new_table_border_color';\n";
     $config.="\$a_link='$new_a_link';\n";
     $config.="\$a_hover='$new_a_hover';\n";
     $config.="\$a_visited='$new_a_visited';\n";
     $config.="\$font_color='$new_font_color';\n";
     $config.="\$font_face='$new_font_face';\n";
     $config.="?>";

     fputs($open, $config);
     fclose($open);
//-----------------------------------------
    include("lang/$new_lang.lang.php");
     echo "<body bgcolor=$bgcolor>
               <script language=Javascript>
               alert('$message[45]');
               window.location='./?s=$s&action=view';
                </script>";
break;
//-----------------------------------------
case "changepass";
   include("pass.inc.php");
   $password= md5($old_pass);

  if ($password!=$password_defini)
                            {
   echo"<script language=Javascript>
  alert('$message[47]');
  window.location='$HTTP_REFERER';
   </script>";   exit();
                             }
  if ($new_pass!=$two_new_pass OR empty($new_pass) OR empty($two_new_pass))
                            {
    echo"<script language=Javascript>
    alert('$message[48]');
    window.location='$HTTP_REFERER';
     </script>"; exit();
                             }
 $new_password= md5($new_pass);
 $pass_file="pass.inc.php";
 $open = fopen("$pass_file","w+");
 $pass="<?\n";
 $pass.="\$password_defini='$new_password';\n";
 $pass.="?>";

  fputs($open, $pass);
  fclose($open);

  echo "<body bgcolor=$bgcolor>
  <script language=Javascript>
  alert('$message[46]');
  window.location='./?s=$s&action=view';
   </script>";
break;
//-----------------------------------------
           }
             } 
?>
