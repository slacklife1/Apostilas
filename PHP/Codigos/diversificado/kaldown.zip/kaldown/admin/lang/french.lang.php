<?
//-----------------------------------------
// Author :	Tarik kallida
// Email :      	kallida@caramail.com
// Age :                  16 years
// Country :            Morroco (North Africa)
// Licence :             GNU/GPL (See http://www.gnu.org for more Information)
//-----------------------------------------
// language   :                        French (Fran�ais)
// Translator :	                Tarik kallida
// Email of Translator :      	kallida@caramail.com
//-----------------------------------------
$charset = "windows-1252";
//-----------------------------------------
$message=array(
"0" => "Administation",
"1" => "ID du lien",
"2" => "Url du lien",
"3" => "Ajouter",
"4" => "il ya ",
"5" => " liens au total ...",
"6" => "Vous �tes s�r de vouloir supprimer ce lien",
"7" => "code pour afficher de NB de clicks ",
"8" => "(texte)",
"9" => "NB de clicks",
"10" => "mise&nbsp;�&nbsp;jour",
"11" => "Il y a une erreur  ... ",
"12" => "Mise � jour accompli ... !! ",
"13" => "Ce lien existe d�ja .. !!",
"14" => "Le lien � �t� ajouter avec succ�s ...",
"15" => "Lien supprimer ... !!",
"16" => "Selectionnez Votre langue",
"17" => "chemin vers le script ,<br> sans '/' � la fin ",
"18" => "chemin vers les images 1,2,3,4,5,6,7,8,9,0 
                <br>pour les resultats graphiques , sans '/' � la fin  .. ",
"19" => "Extension de ces images : <br>gif, jpg , png ...",
"20" => "Coleur du border du Tableau :",
"21" => "Fran�ais",
"22" => "Arabe",
"23" => "Options G�n�ral ...",
"24" => "Options de couleur et de police ...",
"25" => "Envoyer",
"26" => "Couleur de fond :",
"27" => "Couleur de lien :",
"28" => "Couleur de lien (actif) :",
"29" => "Couleur de lien (visiter) :",
"30" => "Couleur de police :",
"31" => "Police :",
"32" => "Changez le mot de passe de l'administration",
"33" => "Ancien mot de passe :",
"34" => "Nouveau mot de passe : ",
"35" => "Retapez le nouveau mot de passe : ",
"36" => "Home",
"37" => "Liens",
"38" => "Ajouter",
"39" => "Modifier",
"40" => "Supprimer",
"41" => "configuration",
"42" => "Options",
"43" => "Changez M.D.P",
"44" => "Sortir",
"45" => "Mise � jour des options accompli ... !!",
"46" => "Changement du mot de passe  accompli ... !!",
"47" => "Mauvais ancien mot de passe",
"48" => "le nouveau mot de passe n'est pas le m�me dans les deux champ",
"49" => "Mauvais mot de passe ...",
"50" => "Nom",
"51" => "Modifier le lien : {NAME_OF_LINK}",
"52" => "Ajouter un lien ",
"53" => "(Graphique)",
"54" => "Dernier click",
"55" => "IP du dernier clickeur",
"56" => "Coleur de gb du Tableau :",
);
?>