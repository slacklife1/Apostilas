<?
//-----------------------------------------
// Author :	Tarik kallida
// Email :      	kallida@caramail.com
// Age :                  16 years
// Country :            Morroco (North Africa)
// Licence :             GNU/GPL (See http://www.gnu.org for more Information)
//-----------------------------------------
// language   :                        English
// Translator :	                Tarik kallida
// Email of Translator :      	kallida@caramail.com
//-----------------------------------------
$charset = "windows-1252";
//-----------------------------------------
$message=array(
"0" => "Administation",
"1" => "ID",
"2" => "URL",
"3" => "Add",
"4" => "There are ",
"5" => " links in total ...",
"6" => "are you sure to want to delete this link $link",
"7" => "code to display the NB of clicks",
"8" => "(texte)",
"9" => "NB of clicks",
"10" => "Update",
"11" => "There are a some error .. ! ",
"12" => "Update finished ... !! ",
"13" => "This link already exists .. !!",
"14" => "The link been successfully add ...",
"15" => "Link deleted  ... !!",
"16" => "Select Your langague",
"17" => "path where you have upload The script, <br>
                without trailing with '/'  in the end ... ",
"18" => "path toward pictures 1,2,3,4,5,6,7,8,9,0 
<br>for the graphic results , without trailing with '/'  in the end ...   .. ",
"19" => "Extension of these pictures : <br>gif, jpg , png ...",
"20" => "Border Table color :",
"21" => "French",
"22" => "Arabic",
"23" => "General options ...",
"24" => "Options of color and police ...",
"25" => "Send",
"26" => "background Color :",
"27" => "Link color :",
"28" => "Link color (active) :",
"29" => "Color of lien (visited) :",
"30" => "Font color :",
"31" => "font :",
"32" => "Change the password of the administration",
"33" => "Old password :",
"34" => "New password : ",
"35" => "Rewrite the new password : ",
"36" => "Home",
"37" => "Links",
"38" => "Add",
"39" => "Modify",
"40" => "Delete",
"41" => "configuration",
"42" => "Options",
"43" => "Change pass",
"44" => "logout",
"45" => "Update Options finished ... !!",
"46" => "Change of the password finished ... !!",
"47" => "Bad old password ... !!",
"48" => "the new password is not even in the two field ...",
"49" => "wrong password ...",
"50" => "Name",
"51" => "Modify the link : {NAME_OF_LINK}",
"52" => "Add new link ",
"53" => "(Graphic)",
"54" => "Last click",
"55" => "IP of last clicked",
"56" => "Table bgcolor :",
);
?>