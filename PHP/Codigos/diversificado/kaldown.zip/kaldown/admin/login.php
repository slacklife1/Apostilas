 <?
//-----------------------------------------
// Author :	Tarik kallida
// Email :      	kallida@caramail.com
// Age :                  16 years
// Country :            Morroco (North Africa)
// Licence :             GNU/GPL (See http://www.gnu.org for more Information)
//-----------------------------------------
   include("config.inc.php");       
   include("pass.inc.php");
   include("lang/$lang.lang.php");   
   error_reporting(0);
//------------------------------------------
 if($password!=$password_defini)
  {
   echo"<html><head><title>administration of kaldown $version</title></head>
      <meta http-equiv='Content-Type' content='text/html; charset=$charset'>
        <body bgcolor=$bgcolor><br><br><br>
              <table border=1 cellspacing=0 cellpadding=5 
        align=center bordercolor=
$table_border_color>
              <tr bgcolor=$table_bgcolor> <td align=center>
        <a href=$kaldown_url><img src=../img/logo_kaldown.jpg border=0></a><br><center>
              <b><font size=2 color=$font_color>$message[0]</b>
        </center></td></tr><tr><td align=center>
              <form method=post action=login.php?action=in>
        <table border=0 width=400 align=center>
              <tr>
         <td width=200><b><font size=2 color=$font_color>Password :<b></td>
               <td width=200><input type=password name=password 
         style='BACKGROUND-COLOR: $bgcolor; COLOR: $font_color; 
                FONT-FAMILY: $font_face;'></td>
        <td width=200>
               <input type=submit value=$message[25]
         style='BACKGROUND-COLOR: $bgcolor; COLOR: $font_color; 
                FONT-FAMILY: $font_face ; Cursor: Hand'></td></table> "; 
  }

//-----------------------------------------
 $password=md5($password);  

 if ($HTTP_GET_VARS[action] == in && $password!=$password_defini)
                           {
             echo"<br><font color=$a_hover>
              <b>$message[49]</b></font>";
                            }            
//-----------------------------------------
 if ($HTTP_GET_VARS[action] == in && $password==$password_defini)
                          {      
  session_save_path("./sessions");   
  session_start(); 
   session_register("password"); 
   $id = session_id(); 

 echo"<meta http-equiv='refresh' content='0; url=./?s=$id'>";
 echo"<font size=2 color=$font_color>Please Wait or</font> <a href=./?s=$id><font color=$a_hover size=2>Click Here</font></a>";
                           }         
//-----------------------------------------          
echo"</tr></table></form>  <center><font size=2 color=$font_color>Powered by  <a href=$kaldown_url><font size=2 color=
$a_hover>Kaldown V $version </font></a>
             by <a href=mailto:kallida@caramail.com><font size=2 color=
$a_hover>Tarik kallida</font></a>";
  ?> 
