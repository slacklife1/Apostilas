<? 
//-----------------------------------------
// Author :	Tarik kallida
// Email :      	kallida@caramail.com
// Age :                  16 years
// Country :            Morroco (North Africa)
// Licence :             GNU/GPL (See http://www.gnu.org for more Information)
//-----------------------------------------
include("admin/config.inc.php");
include("admin/lang/$lang.lang.php");
//-----------------------------------------
echo"
<html><head><title>Kaldown $version : Link manager</title></head>
<meta http-equiv='Content-Type' content='text/html; charset=$charset'>
<body bgcolor=$bgcolor>
<table width=95% border=0 cellpadding=2 cellspacing=2 align=center>
  <tr>
   <th bgcolor=
$table_bgcolor><b><font size=2 color=$font_color>$message[50]</b></font></th>
   <th bgcolor=
$table_bgcolor><b><font size=2 color=$font_color>$message[9]</b></font></th>
   <th bgcolor=
$table_bgcolor><b><font size=2 color=$font_color>$message[54]</b></font></th>
   <th bgcolor=
$table_bgcolor><b><font size=2 color=$font_color>$message[55]</b></font></th>";
$folder="./data";
$handle=opendir($folder);
$nb_of_files=0;

   while ($files = readdir($handle))

            {
             $extension= strtolower(substr( strrchr($files, "." ), 1 ));

              if ($extension==txt)

                            {
                            $name_of_files=substr($files,0,strlen($files)-4);
                            $compteur=$compteur+$nb_download;
                            $nb_of_files++;
                            $id[$nb_of_files]="$name_of_files";
                            $links[$nb_of_files]="../go.php?id=$name_of_files";
                            }
              }
               echo"<center>
            <font size=2 color=$font_color>$message[4] <b>$nb_of_files</b>
             $message[5]</font> ";
 $next=0;
  while ($next<$nb_of_files)
           {

        $next++;
 $file = "./data/$id[$next].txt";
 $open = fopen("$file","r");
 $read = fgets($open,100);
 $link = explode('|',$read);
 if ($link[1] == 0) { $gmt = ""; } else { $gmt = GMT; }
echo" <tr>
<th bgcolor=$bg_color><font size=2>
<a href=go.php?id=$id[$next] target=_blank> <font color=
$a_hover>$link[2]</a></font></th>
<th bgcolor=$table_bgcolor><font size='2' color=$font_color>$link[1]</font></th>
<th bgcolor=$bg_color><font size='2' color=$font_color>$link[3] $gmt</font></th>
<th bgcolor=$table_bgcolor><font size='2' color=$font_color>$link[4]</font></th>
</tr>
";
            }
            echo"</table>
            <center><hr width=50% color=$font_color><font size=2 color=$font_color>Powered by  <a href=$kaldown_url><font size=2 color=
$a_hover>Kaldown V$version </font></a>
             by <a href=mailto:kallida@caramail.com><font size=2 color=
$a_hover>Tarik kallida</font></a>
</body>
</html>"; ?>
