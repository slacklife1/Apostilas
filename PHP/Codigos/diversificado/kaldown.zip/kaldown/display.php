<?
//-----------------------------------------
// Author :	Tarik kallida
// Email :      	kallida@caramail.com
// Age :                  16 years
// Country :            Morroco (North Africa)
// Licence :             GNU/GPL (See http://www.gnu.org for more Information)  
//-----------------------------------------
 include("admin/config.inc.php");
//-----------------------------------------
 if ($type == text && !empty($id))
               {
               header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
               header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
               header("Cache-Control: no-cache, must-revalidate");
               header("Pragma: no-cache"); 

               $file="data/$id.txt";
               $nb=0;

                 if(file_exists("$file"))
   	                    {
                          $open = fopen("$file","r");
                          $read = fgets($open,100);
                          $link = explode('|',$read); 
                          fclose($open);
                          $nb = $link[1];
                        }
  echo "document.write(\"<font face=tahoma size=2>$nb</font>\");";
                }
//-----------------------------------------
 else if ($type==graphic && !empty($id))
              {
               header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
               header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
               header("Cache-Control: no-cache, must-revalidate");
               header("Pragma: no-cache");  

               $file = "data/$id.txt";         
               $open = fopen("$file","r");
               $read = fgets($open,100);
               $link = explode('|',$read); 
               fclose($open);

               $cpt = $link[1];
               $cpt = chunk_split($cpt,1,$ext."><img align=absMiddle src=$images_url/");
               $cpt2 = "<img align=absMiddle src=$images_url/$cpt";
               $cpt3 = $cpt2."b";
               $cpt4 = str_replace("><img align=absMiddle src=$images_url/b",">",$cpt3);

                echo "document.write(\"$cpt4\");";
               }
?>
