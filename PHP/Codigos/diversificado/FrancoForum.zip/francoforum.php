<?
// FrancoForum by Jean-Marc Lelièvre (wizekat@mac.com)
// french /english threaded web forum (bbs)
// with cryptographic features to post encrypted messages
// moderated or unmoderated groups
// user created groups
// upload in your web directory and point your browser at /francoforum.php?install=1
// to setup databases tables
// base config
// the following can be set to use in conjunction with Hosting Assistant users database
// it requires a database with a table named users with at least 2 fields : user, pass
$admdb = "maxi"; // user database table (optional see above)
// $mod_auth = 1; // moderator authentication supplement (optional see above)

$dbhost = "localhost"; // serveur de base de donnÈes / database server
$dbuser = "root"; // nom d'utilisateur / db user name
// if you are using a password to connect to your MySQL server
// uncomment following line and set your password
// $dbpass = "password"; // mot de passe / db password
$db = "francoforum"; // nom de la base de donnÈes / database name
$tbl = "formess"; // nom de la table des messages / messages table name
$page = $PHP_SELF; // page d'accËs / access page name
$sitename = "FrancoForum";
$expire = 30; // number of days to keep articles
$cyph = 1;
// display config
$bgcol = "#004080";	// page background
$tdcol = "#CCCC99"; // main table background
$thcol = "#CCCC99";	// menubar background
$h_color = "brown";	// heading color
$p_color = "#004080";	// pargraph color
$hr_color = "brown";	// ruler color
$ol_color = "brown";	// numbered list color
$ul_color = "#004080";	// list color

$tm_width = "600";
$h_width = "500";
$font1 = "Arial,helvetica,sans"; // main font
$font2 = "Verdana,helvetica,sans";	// links and list font

$l_color = "white";	// link color
$lv_color = "white";	// visited link color
$lh_color = "red";	// hover link color

$l_deco = "underline";	// link text decoration
$lv_deco = "underline";	// visited link text decoration
$lh_deco = "underline";	// hover link text decoration

$standalone = 1;	// use stand alone or embeded in html page

// to use in a pre designed HTML template, do the following :
// set $standalone = 0
// create or download a html page and insert this tag at the top (before the <html> tag) : 
// <? include ("francoforum.php"); ? > ( remove the space between ? and >)

// Then, put the following PHP tags where you want data to be displayed
// site name <? echo "$sitename"; ? > ( remove the space between ? and >)
// forum name <? echo "$forumname"; ? > ( remove the space between ? and >)
// date <? echo "$date"; ? > ( remove the space between ? and >)
// time <? echo "$heure:$minute:$seconde"; ? > ( remove the space between ? and >)
// navigation <? echo "$nav"; ? > ( remove the space between ? and >)
// search form <? echo "$sform"; ? > ( remove the space between ? and >)
// main display <? echo "$screen"; ? > ( remove the space between ? and >)
// language version <? echo "$syslang"; ? > ( remove the space between ? and >)
// copyright info <? echo "$copyr"; ? > ( remove the space between ? and >)

// language config
if ($lang == "fr") {
// french version setup
$modertext = "Acc&egrave;s mod&eacute;rateur";
$helptopic = "Aide en ligne";
$helptext = "En cours de conception";
$ismod = "Bonjour Moderateur";
$ismodtxt = "vous ne pouvez lire que les articles mod&eacute;r&eacute;s jusqu'&agrave; votre";
$modlolabel = "D&eacute;connexion";
$syslang = "version fran&ccedil;aise";
$replylabel = "R&eacute;pondre &agrave; ce message";
$dblabel = "Bases de donn&eacute;es";
$oslabel = "Syst&egrave;mes d'exploitation";
$netlabel = "R&eacute;seaux";
$sforumlabel = "Rechercher :";
$sb_label = "Rechercher"; // nom du champ de recherche / search box label
$cre_label = "Nouveau forum";
$t_label = "Titre :";
$p_label = "Auteur :";
$c_label = "Date :";
$k_label = "Cl&eacute; d'encryption :";
$sr_label = "R&eacute;sultat de la recherche pour :";
$post_label = "poster";
$m_label = "Article :";
$toc_label = "Choisir ce forum";
$newmsg_label = ">> Ecrire un article";
$home_label = "Accueil";
$help_label = "Aide";
$nxt_label = "Suivant(s)";
$glabel = "Liste des groupes";
}
else {
// english version setup
$modertext = "Moderator login";
$glabel = "Group list";
$nxt_label = "Next";
$helptopic = "online help";
$helptext = "Under construction";
$ismod = "Welcome Moderator";
$ismodtxt = "you can only browse moderated articles until you";
$modlolabel = "logout";
$lang = "en";
$syslang = "Engish version";
$replylabel = "Reply to this message";
$dblabel = "Databases";
$oslabel = "Operating systems";
$netlabel = "Networks";
$sforumlabel = "choose a forum";
$sb_label = "Search: "; // nom du champ de recherche / search box label
$t_label = "Title :";
$p_label = "Author :";
$c_label = "Date :";
$k_label = "Encryption key:";
$sr_label = "Search result for :";
$post_label = "post";
$m_label = "Article :";
$toc_label = "Choose";
$newmsg_label = ">> Post new article";
$home_label = "Home";
$help_label = "Help";
$cre_label = "New forum";
}

$style = "<style type=\"text/css\">
TD {
font-family: $font1;
color: $p_color;
font-size: 12px;
align: left;
}
Th {
font-family: $font1;
color: $h_color;
font-size: 12px;
}
HR {
color: $hr_color;
}

H1 {
    color: $h_color;
	font-family: $font1;
    font-size: 24px;
    font-style: oblique;
}
H2 {
    color: $h_color;
	font-family: $font1;
    font-size: 20px;
    font-style: oblique;
}
H3 {
    color: $h_color;
	font-family: $font1;
    font-size: 16px;
    font-style: oblique;
}
H4 {
    color: $h_color;
font-family: $font1;
    font-size: 12px;
    font-style: bold;
}
P {
font-family: $font1;
font-size: 12px;
color: $p_color;
}
ul {
font-family: $font2;
font-size: 12px;
color: $ul_color;
}
ol {
font-family: $font2;
font-size: 12px;
color: $ol_color;
}
A:link {font-family: $font2; color: $l_color; text-decoration: $l_deco;}
A:visited {font-family: $font2; color: $lv_color; text-decoration: $lv_deco;}
A:hover {font-family: $font2; color: $lh_color; text-decoration: $lh_deco;}

</style>";
$copyr = "<a href=http://www.planetsourcecode.com/vb/scripts/BrowseCategoryOrSearchResults.asp?txtCriteria=Jean%2DMarc+Leli%E8vre&blnWorldDropDownUsed=TRUE&txtMaxNumberOfEntriesPerPage=10&blnResetAllVariables=TRUE&lngWId=8&B1=Quick+Search&optSort=Alphabetical target=_blank>FrancoForum</A> &copy; <a href=mailto:wizekat@mac.com>Jean-Marc Leli&egrave;vre</A> 2001";
//
// this where configuration stops, you can change som stuff below but that's
// at your own risks...
$ver = date("d/m/Y - H:i", filemtime($PATH_TRANSLATED)); 
$rel = "1.0b";
$sitename = " $sitename $rel"; 

if ($modlogout) {
	setcookie("FFmod"); 
	setcookie("user"); 
	setcookie("email"); 
	$user = "";
	$email = "";
header ("Location: $page");
}

if ($modadm) {
// fill in some kind of auth
$auth_ok = 1;
	if ($mod_auth) {
	$auth_ok = 0;
	$auth = "SELECT user, pass FROM users WHERE ";
	$auth.= "user = \"$user\" AND pass = \"$passwd\" ";
		if ($dbpass) {
		$sid = mysql_connect($dbhost, $dbuser,$dbpass);
		}
		else {
		$sid = mysql_connect($dbhost, $dbuser);
		}
	mysql_select_db($admdb, $sid);
	$authrep = mysql_query($auth, $sid);
		if (mysql_num_rows($authrep)) {
		$auth_ok = 1;
		}
	}
	
	if ($auth_ok == 1) {
		$ttl = time()+1800;
		$FFmod = $ttl;
		setcookie("FFmod", "$FFmod", time()+18000, "/"); 
		setcookie("user", "$user", time()+18000, "/"); 
		setcookie("email", "$email", time()+18000, "/"); 
	
	}	
}

if ($install) {
	if ($dbpass) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
}
else {
$sid = mysql_connect($dbhost, $dbuser);
}
mysql_create_db($db, $sid);

if ($dbpass) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
}
else {
$sid = mysql_connect($dbhost, $dbuser);
}
mysql_select_db($db, $sid);

 // database tables
$messages_table = "
CREATE TABLE $tbl (
   id int(11) NOT NULL auto_increment,
   title varchar(64),
   poster varchar(64),
   created datetime,
   parent int(11),
   body blob,
   fname varchar(40),
   ckey varchar(100),
   PRIMARY KEY (id)
) ";
mysql_query($messages_table, $sid);

$forum_list_table = "
CREATE TABLE forlist (
   forname varchar(50) NOT NULL,
   forgroup varchar(50) NOT NULL,
   moder tinyint(2) DEFAULT '0' NOT NULL,
   crypto tinyint(2) DEFAULT '0' NOT NULL,
   defckey varchar(100) NOT NULL,
   id int(5) unsigned NOT NULL auto_increment,
   UNIQUE id (id),
   KEY forname (forname)
) ";
mysql_query($forum_list_table, $sid);

$group_list_table = "
CREATE TABLE grouplist (
   gname varchar(50) NOT NULL,
   owner varchar(50) DEFAULT 'wizekat' NOT NULL,
   email varchar(100) DEFAULT 'wizekat@mac.com' NOT NULL,
   UNIQUE gname (gname),
   KEY owner (owner)
) ";
mysql_query($group_list_table, $sid);
header ("Location: $page");
exit;
}

$date = date("Y-m-d");

// expiration of old articles
// when running a busy forum you can cut and paste
// in a separate file and run it from a daily cron job
// with a command like : php my-expire-script.php
// this will speedup overall performance if you want to keep
// articles for a long time (over 30 days)

$exval = time()-($expire*24*60*60);
$eqr = "DELETE from $tbl ";
$eqr.= "WHERE UNIX_TIMESTAMP(created) < $exval ";
	if ($dbpass) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
}
else {
$sid = mysql_connect($dbhost, $dbuser);
}
mysql_select_db($db, $sid);
mysql_query($eqr, $sid);
// end of expiration routine


if ($newp) {
$postit = "new";
}
if ($ckey != "") {
$cyph = 1;
}
$screen = "";
function x_E($string, $key) {

  for($i=0; $i<strlen($string); $i++) {
    for($j=0; $j<strlen($key); $j++) {
      $string[$i] = $string[$i]^$key[$j];
    }
  }

  return $string;
}


function x_D($string, $key) {

  for($i=0; $i<strlen($string); $i++) {
    for($j=0; $j<strlen($key); $j++) {
      $string[$i] = $key[$j]^$string[$i];
    }
  }

  return $string;
}

function GetSID ($nSize=24) {
    		mt_srand ((double) microtime() * 1000000);
    		for ($i=1; $i<=$nSize; $i++) {
   			
   			$nRandom = mt_rand(1,30);
    			if ($nRandom <= 10) {
    				// Uppercase letters
    				$sessionID .= chr(mt_rand(65,90));
    			} elseif ($nRandom <= 20) {
    				$sessionID .= mt_rand(0,9);
    			} else {
    				// Lowercase letters
    				$sessionID .= chr(mt_rand(97,122));
    			}
    			
    		}		
    		return $sessionID;
    	}
    	// $toto = GetSID(16);


	$heure = date("H");
	$minute = date("i");
	$seconde = date("s");


	
$nav = "<table width=96%><tr><th bgcolor=$thcol>
<a href=$page?lang=$lang>$glabel</a>&nbsp;<a href=$page?cre=1&lang=$lang>$cre_label</a>&nbsp;<a href=$page?help=yes&lang=$lang&crypto=$crypto>$help_label</a>&nbsp;<a href=$page?lang=en>English</A>&nbsp; <a href=$page?lang=fr>Fran&ccedil;ais</A></th></tr></table>";

$sform = "<form action=$page method=post> <input type=hidden name=lang value=$lang>
<input type=text size=16 name=item>&nbsp;<input type=submit name=action value=\"$sb_label\">
</form>";
if ($mod_auth) {
$restricted = "<h4>This feature requires a valid Maxi-web username and password.</h4>";	
}
$ugr = "<form action=$page method=post>$restricted
<b>create group/forum</b><br>
User: <input type=text name=user><br>
Password: <input type=password name=passwd><br>
email: <input type=text name=email><br>
group: <input type=text name=usergroup><br>
forum: <input type=text name=userfor><br>
Moderated <select name=moder><option selected value=0>No</optionselected>
<option value=1>Yes</option></select><br>
Encryption: <select name=crypto><option selected value=0>No</optionselected>
<option value=1>Yes</option></select><br>
Default key: <input type=text name=defckey><br>
<input type=submit name=action value=Create!>
</form>";

if (!$FFmod) {
	$moderator = "<form action=$page method=post>$modertext > 
User: <input type=text size=10 name=user> password: <input type=password name=passwd size=10> email: <input type=text size=16 name=email> <input type=submit name=modadm value=Login></form>";
}
else {
	$moderator = "$ismod <b>$user</b>, $ismodtxt &nbsp;<a href=$page?modlogout=1&lang=$lang>$modlolabel</A>";
//	$modadm = 1;
}

if ($usergroup) {
	$auth_ok = 1;
	if ($mod_auth) {
	$auth_ok = 0;
	$auth = "SELECT user, pass FROM users WHERE ";
	$auth.= "user = \"$user\" AND pass = \"$passwd\" ";
		if ($dbpass) {
		$sid = mysql_connect($dbhost, $dbuser,$dbpass);
		}
		else {
		$sid = mysql_connect($dbhost, $dbuser);
		}
	mysql_select_db($admdb, $sid);
	$authrep = mysql_query($auth, $sid);
		if (mysql_num_rows($authrep)) {
		$auth_ok = 1;
		}
	}
if ($auth_ok == 1) {
	if ($dbpass) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
}
else {
$sid = mysql_connect($dbhost, $dbuser);
}
	mysql_select_db($db, $sid);

$query = "INSERT into grouplist VALUES ( ";
$query.= "\"$usergroup\", 
		\"$user\", 
		\"$email\") ";

mysql_query($query,$sid);

$query = "INSERT into forlist VALUES ( ";
$query.= "\"$userfor\", 
		 \"$usergroup\", 
		 $moder, 
		 $crypto, 
		 \"$defckey\", 
		 0) ";
mysql_query($query,$sid);

$fname = $userfor;
}
}

elseif ($action != "") {

	if (($action == "post") && ($fname != "")) {
//	$inputtitle = ereg_replace("'","''",$inputtitle);
//	$inputbody = ereg_replace("'","''",$inputbody);
	$inputbody = htmlentities($inputbody);
		if (($cyph) && ($ckey)) {
		$inputbody = x_E($inputbody,$ckey);
		}
		if ($dbpass) {
		$sid = mysql_connect($dbhost, $dbuser,$dbpass);
		}
		else {
		$sid = mysql_connect($dbhost, $dbuser);
		}
	mysql_select_db($db, $sid);

	$query = "insert into $tbl ";
	$query.= "values(
				0, 
				\"$inputtitle\", 
				\"$inputposter\", 
				now(), 
				$inputparent, 
				\"$inputbody\", 
				\"$fname\",
				\"$ckey\"
				)";

	mysql_query($query,$sid);
		if (substr($fname,0,1) == "_") {
		$flen = strlen($fname) - 1;
	//	$forumname = "<h3>";
		$fname = substr($fname,1,$flen);
	//	$forumname.= "</h3>";
		}


	}

}



if ($fname) {
$forhead = "<form action=$page method=post>";	
	if ($standalone > 0) {
	$forhead.= "<tr><th bgcolor=$thcol>";
	}
$forhead.= "<h3 align=center><i>Forum</i> &nbsp;[ $fname ]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	if ($standalone > 0) {
	$forhead.= "</h3></th><th bgcolor=$thcol>";
	}
 $forhead.= "<input type=hidden name=fname value=$fname>
 <input type=hidden name=lang value=$lang>
 <input type=hidden name=crypto value=$crypto>
 <input type=hidden name=mod value=$mod>
 <input type=submit name=newp value=\"$newmsg_label\">
 </form></h3>";
 	if ($standalone > 0) {
	$forhead.= "</th></tr>";
 	}

$forumname = "<h3>$fname</h3>";

	if (substr($fname,0,1) != "_") {
	$flen = strlen($fname) - 1;
	$forumname = "<h3>";
	$forumname.= substr($fname,1,$flen);
	$forumname.= "</h3>";
	}

}
	

$screen = "<table align=center><tr><td valign=top align=center bgcolor=$tdcol><table align=center>";

if ($standalone > 0) {
$screen.= "<tr><th>$moderator</th><th><font size=3>$sitename</font><br><small>updated: $ver</small></th></tr>
<tr><th align=left bgcolor=$thcol>$date $heure:$minute:$seconde &nbsp; $syslang</th><th bgcolor=$thcol rowspan=2>$sform</th></tr>
<tr><td align=center valign=top bgcolor=$bgcol>$nav</td></tr>$forhead";
}

$screen.= "<tr><td colspan=2 align=left valign=top>";

if ($cre) {
$screen.= "<h3>Create user forum</h3><hr width=$h_width>$ugr<hr width=$h_width>";	
}	

if ($dbpass) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
}
else {
$sid = mysql_connect($dbhost, $dbuser);
}
mysql_select_db($db, $sid);

// list messages
function msglist($fn) {
global $sid;
global $tbl;
global $FFmod;
global $cry;
global $mod;
global $screen;
global $lang;

$query = "select fname ";
$query.= "from $tbl ";
$query.= "where fname=\"$fn\" ";
$query.= "order by created DESC";
$reponse = mysql_query($query, $sid);
$nm = mysql_num_rows($reponse);
$screen.= "<li>";

$screen.= "<a href=$page?fname=$fn&mod=$mod&crypto=$cry&lang=$lang>$fn</a> : $nm";
	if ($cry == 1) {
	$screen.= "<b> [C]</b>";
	}
	if ($mod == 1) {
	$screen.= "<b> [M]</b>";
	}

$screen.= "</li>\n";

}

function showMessages($parentid, $fname) {
global $fname;
global $sid;
global $tbl;
global $screen;
global $lang;
global $crypto;
global $mod;
global $FFmod;
$datetouse = Date("U");
$screen.= "<ul>\n";

$query = "select id, title,created,parent,poster ";
$query.= "from $tbl ";
$query.= "where fname=\"$fname\" ";

 if (!$FFmod) {
 $query.= "AND parent=$parentid ";
 }

$query.= "order by created DESC ";

$reponse = mysql_query($query, $sid);

	while ($row = mysql_fetch_row($reponse)) {

	$messageid = $row[0];
	$messagetitle = $row[1];
	$messagecreated = $row[2];
	$messageparent = $row[3];
	$messageposter = $row[4];
	

	$screen.= "<LI><a href=\"$page?messageid=$messageid&fname=$fname&mod=$mod&crypto=$crypto\"><b>$messagetitle</b></a> ($messagecreated) <i>by <b>$messageposter</b></i></font> ";
	if ($FFmod) {
	$screen.= "<b> [<a href=\"$page?messageid=$messageid&fname=$fname&mod=$mod&crypto=$crypto&lang=$lang&valid=1\">VALID</A>]</b>";
	$screen.= "<b> [<a href=\"$page?messageid=$messageid&fname=$fname&mod=$mod&crypto=$crypto&lang=$lang&valid=0\">REJECT</A>]</b>";
	}

 if (!$FFmod) {
	showMessages($messageid,$fname);
 }
 	$rowcount++;
	}

$screen.= "</ul>\n";
// echo $screen;
}

function postform($parentid,$usetitle,$fname) {
global $fname;
global $t_label;
global $p_label;
global $k_label;
global $post_label;
global $crypto;
global $ckey;
global $screen;
global $lang;
global $mod;

$screen.= "<form action=\"$page\" method=post>";
$screen.= "<input type=hidden name=inputparent value=$parentid>";
$screen.= "<input type=hidden name=action value=post>";
if ($mod == 1) {
$fmod = "_";
}	
$screen.= "<input type=hidden name=fname value=\"$fmod$fname\">";

$screen.= "\n<table border=0 cellspacing=0 cellpadding=0 width=\"$tm_width\">";

$screen.= "\n<tr><th align=right width=\"25%\"><font color=#004080><b>$t_label </b></font></td><td width=\"75%\"><input type=text name=inputtitle size=35 maxlength=64 value=\"$usetitle\"></td></tr>";
$screen.= "\n<tr><th align=right width=\"25%\"><font color=#004080><b>$p_label </b></font></td><td width=\"75%\"><input type=text name=inputposter size=35 maxlength=64></td></tr>";

if ($crypto == 1) {
$screen.= "\n<tr><th align=right width=\"25%\"><font color=#004080><b>$k_label </b></font></td><td width=\"75%\"><input type=password name=ckey size=35 maxlength=64></td></tr>";
}

$screen.= "\n<tr><td colspan=2><textarea name=inputbody cols=55 rows=10></textarea></td></tr>";
$screen.= "\n<tr><td colspan=2 align=middle><input type=submit value=$post_label></td></tr>";
$screen.= "\n</table></form>";
// echo $screen;
}


if ($messageid > 0) {
	if ($FFmod) {
		$flen = strlen($fname) - 1;
		$fname = substr($fname,1,$flen);
		if ($valid == 1) {
		$query = "UPDATE $tbl SET fname = \"$fname\" WHERE id=$messageid ";
		mysql_query($query,$sid);
		$screen.= "<b>$fnane art: $messageid APPROVED</b><br>";	
		}
		elseif ($valid == 0) {
		$query = "DELETE from $tbl WHERE id=$messageid ";
		mysql_query($query,$sid);	
		$screen.= "<b>$fnane art: $messageid DELETED</b><br>";	
		}
	$messageid = 0;
	$fname = "_".$fname;
	}
	else {
$query = "select * from $tbl WHERE id=$messageid ";
// $query = $query . "where id=$messageid ";
$reponse = mysql_query($query,$sid);

	if ($row = mysql_fetch_row($reponse)) {
	$messagetitle = $row[1];
	$messageposter = $row[2];
	$messagecreated = $row[3];
	$messageparent = $row[4];
	$messagebody = $row[5];

	if (($cyph) && ($key)) {
	$messagebody = x_D($messagebody,$key);
	}


	$screen.= "\n<table border=0 cellspacing=0 cellpadding=0 width=$tm_width>";
	
		if ($rep) {
		$screen.= "\n<tr><td colspan=2>Date: $messagecreated, [$messageposter] :<br>$messagebody</td></tr>";
		$screen.= "\n</table>";
		postform($messageid, "Re: $messagetitle", $fname);
		}
		else {
		$screen.= "\n<tr><th width=25% align=right><b>$t_label</b></td><td width=75%>$messagetitle</td></tr>";
		$screen.= "\n<tr><th width=25% align=right><b>$p_label</b></td><td width=75%>$messageposter</td></tr>";
		$screen.= "\n<tr><th width=25% align=right><b>$c_label</b></td><td width=75%>$messagecreated</td></tr>";
		if ($crypto == 1) {
		$screen.= "\n<tr><form action=$page method=post><td align=right width=25%><b>$k_label</b></td><td width=75%><input type=password name=key size=25 maxlength=64><input type=hidden name=messageid value=$messageid> &nbsp; <input type=submit name=cyph value=DECRYPT></td></form></tr>";
		}
		$screen.= "\n<tr><th colspan=2 align=left><hr>$m_label</td></tr>";
		$screen.= "\n<tr><td colspan=2>$messagebody<hr></td></tr>";
		$screen.= "\n</table>";
		$screen.= "<h4><a href=$page?rep=1&messageid=$messageid&fname=$fname&mod=$mod&messagetitle=$messagetitle>$replylabel</a></H4>\n";
		}	
	}
}
}

if ($messageid < 1 || !$messageid) {
// else {
		if ($postit) {
	postform(0, "", $fname);
	}
	else {
	$screen.= "\n<table border=0 cellspacing=0 cellpadding=0 width=$tm_width><tr><td valign=top>\n";
		if ($fname) {
	
		showMessages(0,$fname);
		}
		elseif ($help) {
		$screen.= "<h4>Mode d'emploi / how to use $sitename</h4>\n";
		
		$screen.= "<ol><Li>
		<b>$helptopic</b><p>
		$helptext</p>
		</li>";
			if ($crypo == 1) {
			$screen.= "<li><b>$helpcrypto</b><p>
			$helpcryptotext</p>
			</li>";
			}
		$screen.= "</ol>\n";
		}

		else {
		// list groups, forums and count articles
			if ($FFmod) {
			$rows = 3;
			$lines = 0;
			$qry = "SELECT gname FROM grouplist WHERE owner = \"$user\" AND email =\"$email\" ORDER BY gname ";
			$reponse = mysql_query($qry, $sid);
			$screen.= "<ol>";
				while ($row = mysql_fetch_row($reponse)) {
				$mfor = $row[0];	
				$screen.= "<li><h3>$user // $mfor</h3>";
				$qr = "SELECT forname, forgroup, crypto, moder FROM forlist ";
				$qr.= "WHERE forgroup = \"$mfor\" ";
				$qr.= "AND moder = 1 ";
				$qr.= "ORDER BY forname ";
				$llist = mysql_query($qr, $sid);
				$screen.= "<ul>";
					while ($rw = mysql_fetch_row($llist)) {
						if ($rw[0] != "$fn") {
						$lines++;	
						$fn = "_";
						$fn.= $rw[0];
						$cry = $rw[2];
						$mod = $rw[3];
						msglist($fn);
						}

						if ($lines > $rows) {
						$screen.= "</ul></td><td valign=top><ul>";
						$lines = 0;
						}

					}
				$screen.= "</ul>";

				}
			$screen.= "</ol>";
		}
	
		elseif ($fgr) {
		$rows = 3;
		$lines = 0;
		$qr = "SELECT forname, forgroup, crypto, moder FROM forlist ";
		$qr.= "WHERE forgroup = \"$fgr\" ORDER BY forname ";
		$llist = mysql_query($qr, $sid);
		$screen.= "<h3>Group: $fgr</h3><ul>";
			while ($rw = mysql_fetch_row($llist)) {
			$lines++;	
			$fn = $rw[0];
			$cry = $rw[2];
			$mod = $rw[3];
			msglist($fn);
	
				if ($lines > $rows) {
				$screen.= "</ul></td><td valign=top><h3>Group: $fgr</h3><ul>";
				$lines = 0;
				}
			}
		}
		elseif (!$item) {
		$rows = 3;
		$lines = 0;
		$qry = "SELECT gname FROM grouplist ORDER BY gname ";
		$reponse = mysql_query($qry, $sid);
		$screen.= "<b>$glabel</b><ol>";
			while ($row = mysql_fetch_row($reponse)) {
			$lines++;
			$qry2 = "SELECT crypto, moder FROM forlist WHERE forgroup = \"$row[0]\" ";
			$reponse2 = mysql_query($qry2, $sid);
			$allfor = 0;
			$cryfor = 0;
			$mofor = 0;
			$freefor = 0;
					while ($row2 = mysql_fetch_row($reponse2)) {
						$allfor++;
						if ($row2[0] == "1") {
						$cryfor++;	
						}
						elseif ($row2[1] == "1") {
						$mofor++;	
						}
						else {
						$freefor++;
						}
					}
			$screen.= "<li><b><a href=\"$page?lang=$lang&fgr=$row[0]\">$row[0]</A> $allfor forum(s)</b> ($freefor free $cryfor encrypted $mofor moderated)</li>\n";
				if ($lines > $rows) {
				$screen.= "</ol></td><td valign=top><h3>Group list</h3><ol>";
				$lines = 0;
				}
			}
		}


	if ($item != "") {
		if ($dbpass) {
		$sid = mysql_connect($dbhost, $dbuser,$dbpass);
		}
		else {
		$sid = mysql_connect($dbhost, $dbuser);
		}
	mysql_select_db($db, $sid);
	$query = "select * from $tbl ";
	$query.= "where title like \"%$item%\" ";
	$query.= "OR poster like \"%$item%\" ";
	$query.= "OR body like \"%$item%\" ";
	$query.= "OR created like \"%$item%\" ";
	$query.= "ORDER by created DESC ";

	$reponse = mysql_query($query, $sid);

	$screen.= "<font face=helvetica color=navy>$sr_label <b>$item</b><ol>";

	$count = mysql_num_rows($reponse);
		if ($deb == "") {
		$deb = 10;
		}
		if ($start == "") {
		$start = 0;
		}
	$show = 0;

		while (($row = mysql_fetch_row($reponse)) && ($show < $deb)) {
		$show++;
			if ($show > $start) {
			$screen.= "<li><a href=$page?messageid=$row[0]&fname=$fname&lang=$lang>$row[1]</a> ($row[3])<br>Forum: <b>$row[6]</b> <i> $p_label: $row[2]</i></li>\n";
			}
		}
	
	$screen.= "</ol><hr width=$h_width>Article(s) 1 - $show / $count - ";
	$start = $show;
	$deb = ($deb + 10);
	$screen.= "<a href=\"$page?item=$item&start=$start&deb=$deb&action=Go!\">$nxt_label</a>.</td></tr></table>";
	// $screen.= "</td></tr></table>\n";	
	// exit;
}


$screen.= "</ul></li></ul>\n";

$screen.= "</ul></li></ul>\n";

}
$screen.= "</td></tr></table>";
}
}

$screen.= "</td></tr></table></td></tr></table>";
// $screen.= "<table align=center width=$tm_width><tr><td align=right bgcolor=$thcol><small><i>powered by:</i> $copyr</small>&nbsp;</td></tr></table>\n";

	if ($standalone > 0) {
	echo "<html><head><title>$sitename : $forumname</title>$style</head><basefont=$font1><body bgcolor=$bgcol text=$p_col link=$l_color visited=$lv_color active=$lh_color>$screen</body></html>";
	}

 

?>
