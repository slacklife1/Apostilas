Title: FrancoForum, a complete threaded web discussion forum with MySQL,
Description: This is a complete multi-threaded, multi-groups web discussion forum. It uses a MySQL database, expiration routine, moderated or free groups, user groups, message encryption with private key, auto-install feature, can be used embedde in any web page or stand alone (default), it is bi-lingual (default english/french) and can configured to display in whatever color scheme you wish. You can view it in action at http://www.maxi-web.net/bbs
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=398&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
