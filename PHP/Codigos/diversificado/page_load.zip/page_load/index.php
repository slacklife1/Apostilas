<?
include('page_load.php');
loadtime();
?>