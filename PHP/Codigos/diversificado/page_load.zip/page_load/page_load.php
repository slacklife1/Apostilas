<?
function loadtime() {
$thetime = explode(' ', microtime());
$starttime = $thetime[1] + $thetime[0];
$newtime = explode(' ', microtime());
$endtime = $newtime[1] + $newtime[0];
$loadtime = number_format(($endtime - $starttime), 7);
echo '<font face="verdana" size="2">Page loaded in '.$loadtime.' seconds.</font>';
}
?>
