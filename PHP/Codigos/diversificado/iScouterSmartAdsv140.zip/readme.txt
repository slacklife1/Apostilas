This is the latest CVS of iScouter Smart ADs Rotator.
v1.4.0, Feb. 14, 2001
Please go to http://www.iscouter.net/www/freePHP for documentation.

*NOTE:*
edit two .php files accordingly before uploading them to your server.

iScouter.net

heji@iscouter.net