<?php
				/////////////////////////////////////////////////////////////
				/////////////////////////////////////////////////////////////
				// 							iScouter Smart AD Rotater                  //
				//          (Copyright 2000-2001 iScouter.net)             //
				//	free for use and distribution under certain conditions //
				//  please read the claims via "Admininistration Suite"    //
				//  For latest version of this program, please visit:      //
				//  http://www.iscouter.net/www/freePHP										 //
				/////////////////////////////////////////////////////////////
				/////////////////////////////////////////////////////////////

class CAds	{

/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
// 							Database Configurations                    //
//         (Must be properly set before use)               //
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
					
					//host name of your mySQL server
	var $adsdbhostname = "localhost";
					//mySQL database name
	var $adsdbname = "database";
	
					//user name & password to access the above database
	var $adsdbusername = "username";
	var $adsdbpassword = "password";

					//the table name to save the ads banner records
					//no need to change if no confliction
	var $adsdbtable = "adbanner";

/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
// 							File Location Configurations               //
//         (Must be properly set before use)               //
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
					
					//the WEB URL of _ads.php. _ads.php is used to handle the general requests such as 
					//"admin" and "click"
	var $refpage = "/www/support/_ads.php";
	
					//the css file that defines neccessary css styles
					//iScouter.net would be glad to borrow it's css file to you,
					//so you may don't need modify this setting ;-)
					//To use your own css file, please make sure it
					//contains these three stypes:
					//cssnormal, csssmaller and cssbigger
		//note: May 12, 2002: this variable is disabled.
	var $cssfile = "";

	
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
// 							Optional Configurations                    //
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////

				//////////////////////////////
				// Trick Click
				//////////////////////////////

					//whether use trick to auto "click" on the banner
					//this setting can be overrided during new banner creation
	var $usetrick = FALSE;
	
					//two alternative trick mode:
					//"HIDDEN" - inline frame (user won't notice, but some low version browsers do not support inline frame)
					//"POP" - pop up a new window
	var $trickmode = "HIDDEN";
	//var $trickmode = "POP";	
	
					//the dummy click-rate, defined as click once per $trickrate banners (randomly controlled)
	var $trickrate = 40;

				//////////////////////////////
				// Type definition table
				//////////////////////////////

					//because the type is used to auto-detect the size of the banner
					//during banner addition. (for v1.2.11 and above).
	var $validtype = Array ("468*60", "360*60", "234*60", "150*150", "125*125", "125*60", "137*40", "100*60", "90*31", "text");

					//new setting for v1.2.9 and above, text banner is a special type of banner, because they can be fitted to any
					//banner cell dispite of the size. The $TEXTTYPE defines this type of banner, by default, it is "text" as listed above in the
					//$validtype setting, you may change to any other keyword as you like, such as "simplest" or "fitall".
	var $TEXTTYPE = "text";

					//iframe setting for each type, this gives the default <iframe> width and height for
					//each type of banners. Only applicable in "rotatebox" mode
	var $iframesetting = Array(
					"468*60" => Array("472", "62"),
					"360*60" => Array("362", "62"),
					"234*60" => Array("240", "62"),
					"150*150" => Array("152", "152"),					
					"125*125" => Array("127", "127"),
					"125*60" => Array("127", "62"),
					"137*40" => Array("140", "42"),
					"100*60" => Array("102", "62"),					
					"90*31" => Array("92", "33"),
					"text" => Array("152", "62")
				);

					//in case of multiple types are specified, default iframe width & height will be applied
	var $defaultiframew = "472";
	var $defaultiframeh = "62";

					//this gives the minimal CELL size (not the <iframe> size) for the text banner
					//note: since the text banner may be displayed in the inline frame
					//this size can not be bigger than the inline frame size (see above)
	var $textcellwidth = "150";
	var $textcellheight = "60";

				//////////////////////////////
				// custom random pattern brackets
				//////////////////////////////
					//a random pattern is a special sub string in the banner codes
					//that will be parsed and replaced with random digits/characters
					//useage: $RANDSTARTrandompattern$RANDEND
	var $RANDSTART = "RAND{";
	var $RANDEND = "}RAND";
					//to specify the random pattern:
					// "0" - a random digit varies from 0 to 9
					// "c" - a random lower-case character varies from a to z
					// "C" - a random upper-case character varies from A to Z
					// any other symbols - keep as original.
					//example: RAND{uidCc0000}RAND to be replaced with uidAe8760


				//////////////////////////////
				// multiples zones/types delimiter
				//////////////////////////////
					//usage: zone1$ADSZONEDELIMITERzone2...
					//example: zone1|zone2
	var $ADSZONEDELIMITER = "|";

				//////////////////////////////
				// working mode
				//////////////////////////////

					//default banner displaying mode
					//possible values are:
					//"rotatebox": open a <iframe> box in the current referer page and auto-rotate banners in the <iframe> box
					//"rotatepage": automatically refresh the WHOLE page periodically to rotate the banners, useful for frames
					//"show": display a random banner ONCE and keep it stable in the referer page.
	var $defaultop = "show";

					//the rotating speed if working under "rotatebox" and "rotatepage" modes, in seconds
					//currently: display a new banner once each 20 seconds
	var $rotategap = 20;

				//////////////////////////////
				// misc settings
				//////////////////////////////

					//the default text to be displayed to the visitors, in case of database
					//accessing error and other unknown problems
	var $defaultads = "This Ad place could be yours!";

					//the background color of the inline frame
	var $iframebgcolor = "#F0F0F0";

					//the background color of the banners
	var $textcellbkcolor = "#FFFFEE";
	var $imagecellbkcolor = "#FFFFFF";

					//the border settings for the banners
	var $addtextborder = TRUE;
					//if $borderwidth > 0, applies to both text & image banners
					//else if $borderwidth == 0 && $addtextborder == TRUE,
					//no border for image banners but add border for text banners
	var $borderwidth = 0;
	var $bordercolor = "#CCCCCC";
	

					/////////////////////////////////////////////////////////////
					/////////////////////////////////////////////////////////////
					// 							DO NOT EDIT ANYTHING BELOW                 //
					/////////////////////////////////////////////////////////////
					/////////////////////////////////////////////////////////////

				//default pre-set display settings
	var $adstype = "ALL";
	var $adsmaxw = "NONE";
	var $adsmaxh = "NONE";
	var $adszone = "ALL";

	var $latestver = "v1.4.0";
	var $specialver = "(free version)";
	var $latestdate = "Feb. 14, 2001";

	var $copyright =
"
Contact: <b>Mr. J. He</b> (<a href = \"mailto:heji@iscouter.net\"> heji@iscouter.net</a>) 
(for personally limited support and bug report)<br><br>
<b><i>iScouter.net</i> Claims:</b>
<br><br>
Copyright 2000-2001 by <b><i>iScouter.net</i></b>. Permission to use, copy, modify 
and distribute this program is hereby granted without fee, provided that this 
copyright notice appear in all copies and that both that copyright notice and this 
permission notice appear in supporting documentation. If the source code of the 
program is modified or enhanced, the source code must be made public and it must be 
clearly mentioned in the documentation what was modified. 
<br><br>
THIS PROGRAM IS PROVIDED \"AS IS\" WITHOUT EXPRESS OR IMPLIED WARRANTY. THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL 
<b><i>iScouter.net</i></b> LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL 
DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, 
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTUOUS ACTION, ARISING OUT 
OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. 
";

				//the class constructor
				//if the object is created without any argument, the global vars will be grabed for
				//configuration, and the object will be waiting for specific operation request
				//NOTE: simply create a object with blank argument will display ALL kinds of 
				//banners (using $defaultop) in a $defaultiframew * $defaultiframh frame (if $defaultop = rotatebox)
function CAds($adstype = "ALL", $adsmaxw = "NONE", $adsmaxh = "NONE", $adszone = "ALL", $defaultop="DEFAULT", $usetrick = "DEFAULT")	{

		$this->adstype = $adstype;
		$this->adsmaxw = $adsmaxw;
		$this->adsmaxh = $adsmaxh;
		$this->adszone = $adszone;
		
		if ($defaultop != "DEFAULT")  $this->defaultop = $defaultop;
		if ($usetrick != "DEFAULT")  $this->usetrick = ($usetrick ==1)?TRUE:FALSE;

		$adsop = isset($GLOBALS["adsop"]) ? $GLOBALS["adsop"] : $this->defaultop;
		$adsid = isset($GLOBALS["adsid"]) ? $GLOBALS["adsid"] : "NONE";
		
		global $HTTP_POST_VARS;
		if (!isset($HTTP_POST_VARS)) $HTTP_POST_VARS = "";		
		
		switch ($adsop)	{
			case "click":
				$this->click($adsid);
				break;
			case "rotatebox":
				$this->rotatebox();
				break;
			case "rotatepage":
				$this->rotatepage();
				break;
			case "admin":
				$this->admin($HTTP_POST_VARS);
				break;				
			case "show":
			default:
				$this->show();
				break;
		}
	}



function connectdb()	{
		if (MYSQL_CONNECT($this->adsdbhostname, $this->adsdbusername, $this->adsdbpassword) == FALSE)	return FALSE;
		if (mysql_select_db($this->adsdbname) == FALSE)	return FALSE;
		
		return TRUE;
	}

function rotatebox()	{
		$refpage = $this->refpage;

		$adstype = $this->adstype;
		$adsmaxw = $this->adsmaxw;
		$adsmaxh = $this->adsmaxh;
		$adszone = $this->adszone;
		
		if ($adsmaxw != "NONE") {
			$iframew = $adsmaxw;
		} else	{
			$iframew = isset($this->iframesetting["$adstype"][0]) ? $this->iframesetting["$adstype"][0] : $this->defaultiframew;
		}
		
		if ($adsmaxh != "NONE")	{
			$iframeh = $adsmaxh;
		} else	{
			$iframeh = isset($this->iframesetting["$adstype"][1]) ? $this->iframesetting["$adstype"][1] : $this->defaultiframeh;
		}
		
		//if request for inline rotate, first create a in-line frame
		echo("
				<iframe width=\"$iframew\" height=\"$iframeh\" frameborder=\"0\" scrolling=\"no\" marginheight=\"0px\" marginwidth=\"0px\" src=\"$refpage?adstype=$adstype&adsop=rotatepage&adsmaxw=$adsmaxw&adsmaxh=$adsmaxh&adszone=$adszone\">
		");
		//for those browsers that do not support iframe, force show one ad
		$this->show();
		echo("</iframe>");
	}	

function rotatepage(){
		//showrotate option will create a self-rotating page when called by the above codes, 
		//if displayed in the inline frame, add background color
		$bg = $this->iframebgcolor;
		$cssfile = $this->cssfile;

		$adstype = $this->adstype;
		$adsmaxw = $this->adsmaxw;
		$adsmaxh = $this->adsmaxh;

		srand((double)microtime()*1000000); 
		
		//slightly adjust the rotate gap to avoid multiple frames loading banners at the same time
		$min = $this->rotategap - 5;
		if ($min <= 1)	$min = 1;
		$max = $this->rotategap + 10;
		
		$timegap = rand($min, $max) * 1000;				
		
		echo("<html>
					<head>
					<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">
					<link rel=\"stylesheet\" href=\"$cssfile\" type=\"text/css\">
					<script language=\"javascript\">
						function rotate()	{
							setTimeout('location.reload()',$timegap);
						}
					</script>
					</head>
					<body bgcolor=\"$bg\" class=\"cssnormal\" onload=\"javascript:rotate()\" leftmargin=\"0\" topmargin=\"0\" marginwidth=\"0\" marginheight=\"0\">
					<center>
				");
		
		$showresult = $this->show();
	
		echo("</center></body></html>");		
	}


				//show a random ads of specified type, or show a specific ads
				//return:
				//if successful, return an array containing all the information 
				//of that ads
function show($adsid = -999, $record = TRUE)	{
		
		$table = $this->adsdbtable;
		$refpage = $this->refpage;
		
		$adstype = $this->adstype;
		$adsmaxw = $this->adsmaxw;
		$adsmaxh = $this->adsmaxh;
		$adszone = $this->adszone;
		
		$cellwidth = $this->textcellwidth;
		$cellheight = $this->textcellheight;

		if ($adsmaxw == "NONE")	$adsmaxw=9999;
		if ($adsmaxh == "NONE")	$adsmaxh=9999;
		
		$needclick = FALSE;
		
		srand((double)microtime()*1000000);
		
		//echo("$adszone");

		if ($adszone != "ALL") {
			//if multiple zones are apecified, randomly pick one zone
			$delimiter = $this->ADSZONEDELIMITER;
			$adszonearray = explode($delimiter, $adszone);
			$adszonenum = count($adszonearray);
	
			if ($adszonenum == 1)	{
				$randzone = $adszone;
			} else	{
				$randidx = rand(0, $adszonenum -1 );
				$randzone = $adszonearray[$randidx];
			}
		}

		//new feature in v1.2.11 and above.
		//$adstype can also be multiple
		if ($adstype != "ALL") {
			//if multiple zones are apecified, randomly pick one zone
			$delimiter = $this->ADSZONEDELIMITER;
			$adstypearray = explode($delimiter, $adstype);

			$adstypenum = count($adstypearray);
	
			if ($adstypenum == 1)	{
				$randtype = $adstype;
			} else	{
				$randidx = rand(0, $adstypenum -1 );
				$randtype = $adstypearray[$randidx];
			}
			

		}

		
		//random pick one AD
		if ($this->connectdb() == FALSE)	{
			//disp default ads
			//force ads type to "text"
			$adstype = $this->TEXTTYPE;
			$disphtml = $this->defaultads;
			
			$returnval = FALSE;
		} else	{
			if ($adsid > 0)	{
				//if an ads id is given, display the specific ads only
				$myquery = "SELECT * FROM $table WHERE id = '$adsid'";
			}	else if ($adstype == "ALL")	{
				if ($adszone == "ALL")	{
					$myquery = "SELECT * FROM $table WHERE (active = '1' AND width <= '$adsmaxw' AND height <= '$adsmaxh')";				
				} else	{
					$myquery = "SELECT * FROM $table WHERE (active = '1' AND width <= '$adsmaxw' AND height <= '$adsmaxh' AND (zone LIKE '$randzone$delimiter%' OR zone LIKE '%$delimiter$randzone' OR zone LIKE '%$delimiter$randzone$delimiter%' OR zone = '$randzone'))";
				}
			} else	{	
				if ($adszone == "ALL")	{
					$myquery = "SELECT * FROM $table WHERE (type = '$randtype' AND active = '1' AND width <= '$adsmaxw' AND height <= '$adsmaxh')";
				}	else	{
					$myquery = "SELECT * FROM $table WHERE (type = '$randtype' AND active = '1' AND width <= '$adsmaxw' AND height <= '$adsmaxh' AND (zone LIKE '$randzone$delimiter%' OR zone LIKE '%$delimiter$randzone' OR zone LIKE '%$delimiter$randzone$delimiter%' OR zone = '$randzone'))";
				}
			}
			
			//echo("$myquery");
			
			$myresult = MYSQL_QUERY($myquery);
			if ($myresult == FALSE || mysql_numrows($myresult) < 1)	{
				$adstype = $this->TEXTTYPE;
				$disphtml = $this->defaultads;
				
				$returnval = FALSE;
			} else	{
			 	//pick a random ads to display
			 	$number = mysql_numrows($myresult);
			 	
			 	if($number == 1){
					$randomnumber = 0;
				}	else	{
					--$number;
					$randomnumber = rand(0,$number);
				}
				
				//Get the details for that entry
				$adsid = mysql_result($myresult,$randomnumber,"id");
				$adstype = mysql_result($myresult,$randomnumber,"type");
				$adszone = mysql_result($myresult,$randomnumber,"zone");				
				$active = mysql_result($myresult,$randomnumber,"active");
				$adswidth = mysql_result($myresult,$randomnumber,"width");
				$adsheight = mysql_result($myresult,$randomnumber,"height");
				$beforelink	= mysql_result($myresult,$randomnumber,"beforelink");
				$linkbody	= mysql_result($myresult,$randomnumber,"linkbody");
				$linktarget	= mysql_result($myresult,$randomnumber,"linktarget");
				$afterlink	= mysql_result($myresult,$randomnumber,"afterlink");
				$html	= mysql_result($myresult,$randomnumber,"html");
				$memo = mysql_result($myresult,$randomnumber,"memo");
				$display = mysql_result($myresult,$randomnumber,"display");
				$click = mysql_result($myresult,$randomnumber,"click");
				
				if ($html != "")	{
					$disphtml = trim($html);
				} else	{
					
					
					$disphtml = trim("$beforelink<a href=\"$refpage?adsop=click&adsid=$adsid\" target=\"_blank\">$linkbody</a>$afterlink");
					
					//now the current banner has a "link target", and if trick flag is switched on,
					//determin whether need trick or not
					$randomnumber = rand(0,$this->trickrate);
					if ($randomnumber == 1 && $this->usetrick==TRUE)	$needclick = TRUE;
				}
	
				
				if ($record)	{				
						if ($display < 0) $display = 0;
						$display++;
						
						//write display count
						$query = "UPDATE $table SET display = '$display' WHERE (id = '$adsid')";
						mysql_query($query);
				}
				
				$returnval = array(
					"id" => $adsid,
					"type" => $adstype,
					"zone" => $adszone,					
					"active" => $active,
					"width" => $adswidth,
					"height" => $adsheight,
					"beforelink" => $beforelink,
					"linkbody" => $linkbody,
					"linktarget" => $linktarget,
					"afterlink" => $afterlink,
					"html" => $html,
					"memo" => $memo,
					"display" => $display,
					"click" => $click
				);
			}
	
			$cellsizedef = ($adstype == $this->TEXTTYPE) ? " width=\"$cellwidth\" height=\"$cellheight\" " : "";
			$cellbkcolor = ($adstype == $this->TEXTTYPE) ? $this->textcellbkcolor : $this->imagecellbkcolor;
			
			/////////new feature for v1.2.9 and above.
			//replace the random pattern specification with
			//random strings (digits and characters)
			$disphtml = $this->dorandomreplace($disphtml);
			
			//display ads			
			$borderwidth = ($adstype == $this->TEXTTYPE && $this->addtextborder == TRUE && $this->borderwidth == 0) ? 1 : $this->borderwidth;
			$bgcolor = $this->bordercolor;
			echo("
		      <!-- ads no. $adsid -->
		      <table border=\"0\" cellspacing=\"0\" cellpadding=\"$borderwidth\" align=\"center\">
		        <tr> 
		          <td bgcolor=\"$bgcolor\"> 
		            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		              <tr> 
		                <td class=\"cssnormal\" bgcolor=\"$cellbkcolor\"  align=\"center\" valign=\"center\" $cellsizedef>$disphtml</td>
		              </tr>
		            </table>
		          </td>
		        </tr>
		      </table>
		      <!-- ads no. $adsid end -->
		     ");
		     
  		//trick click
			if ( $needclick )	{
				switch ($this->trickmode)	{
					case "HIDDEN":
						echo("<iframe width=\"1\" height=\"1\" frameborder=\"0\" scrolling=\"no\" marginheight=\"0px\" marginwidth=\"0px\" src=\"$refpage?adsop=click&adsid=$adsid\"></iframe>");
						break;
					case "POP":
						echo("<script language=\"javascript\"> window.open(\"$refpage?adsop=click&adsid=$adsid\", \"myadswin\"); </script>");
						break;
				}
			}
		}
		return $returnval;
	}
	
function click($adsid = -999, $record = TRUE)	{
		$table = $this->adsdbtable;
		$refpage = $this->refpage;

		if ($adsid < 0)	return;
		
		if ($this->connectdb() == FALSE)	return;
		
		$query = "SELECT * FROM $table WHERE (id = '$adsid')";
		
		$result = mysql_query("$query");
		
		if ($result == FALSE || mysql_numrows($result) == 0)	return;
		
		$linktarget = mysql_result($result, 0, "linktarget");
		$click = mysql_result($result, 0, "click");
		
		if ($record)	{		
			if ($click < 0)	$click = 0;
			$click++;
			
			//write click count
			$query = "UPDATE $table SET click='$click' WHERE (id = '$adsid')";
			mysql_query($query);
		}
		
		//redirect to the target URL
		if (headers_sent() == TRUE)	{
			// if header has been sent, use javascript to redirect
			echo("<script language=\"javascript\">
							document.location = '$linktarget';
						</script>
						");
		}	else	{
			header ("Location: $linktarget");
			exit;
		}
	}

function dorandomreplace($strold)	{

		//debug info
		//$strold = "RAND{C00ac}RAND-RAND{c0C2}RAND";
		//echo("before: $strold<br>");
	
		$randstart = $this->RANDSTART;
		$randend = $this->RANDEND;
	
		$startpos = strpos($strold, $randstart);
		$endpos = strpos($strold, $randend);
		
		srand((double)microtime()*1000000);
		
		while ($startpos + strlen($randstart) < $endpos)	{
			//extract the sub-string between the $RANDSTART and the $RANDEND
			$oldsubstr = substr($strold, $startpos + strlen($randstart), $endpos - ($startpos + strlen($randstart)) );
			//debug info
			//echo("extracted substring: $oldsubstr<br>");
			
			$newsubstr = "";
			for ($i=0; $i < strlen($oldsubstr); $i++)	{
				//get the character one by one
				$oldchar = substr($oldsubstr, $i, 1);
				
				switch($oldchar)	{
					case "0":	
						$randnum  = rand(0, 9);
						$newchar = "$randnum";
						break;
					case "c":
						$randnum = rand(ord("a"), ord("z"));
						$newchar = chr($randnum);
						break;
					case "C":
						$randnum = rand(ord("A"), ord("Z"));
						$newchar = chr($randnum);
						break;
					default:
						$newchar = $oldchar;
						break;
				}
				
				//now the new char is get, append to the new sub-string
				$newsubstr = $newsubstr . $newchar;
			}
			//debug info
			//echo("new substring:$newsubstr<br>");
			
			//now the new substr is get, replace the old one with the new one
			//at the same time, remove the $RANDSTART and $RANDEND symbols
			$strold = substr_replace($strold, "$newsubstr", $startpos, $endpos - $startpos + strlen($randend));
			
			//debug info
			//echo("after replace:$strold<br>");
			
			//there may be other pairs, continue seeking
			$startpos = strpos($strold, $randstart);
			$endpos = strpos($strold, $randend);
		}
		
		//debug info
		//echo("return:$strold<br>");
		return $strold;
	}

//////////////////////////////////////////////
//////////////////////////////////////////////
// start of administration functions        //
//////////////////////////////////////////////
//////////////////////////////////////////////

function admin($post_vars="")	{
		$adsadminop = isset($post_vars["adsadminop"])	? $post_vars["adsadminop"] : "adsadminlogin";
		$adsadminpass = isset($post_vars["adsadminpass"])	? $post_vars["adsadminpass"] : "";
		
		$adsadminopid = isset($post_vars["adsadminopid"])	? $post_vars["adsadminopid"] : "NONE";
		$adsactive = isset($post_vars["adsactive"])	? $post_vars["adsactive"] : "";
		$adstype = isset($post_vars["adstype"])	? $post_vars["adstype"] : "ALL";
		
		//if incorrect password, force login
		if ($adsadminpass != $this->adsdbpassword)	$adsadminop = "adminlogin";
		
		$this->admin_showhead($adsadminpass);
		
		switch($adsadminop)	{
			case "adminlogin":
				$this->admin_login();
				break;
			case "confirmlogin":
				$this->admin_confirmlogin();
				break;		
			case "Create Table (install)":
				$this->admin_createtable();
				break;
			case "Drop Table (un-install)":
				$this->admin_droptable();
				break;
			case "Update Table (from v1.2.6 to v1.2.7)":
				$this->admin_updatetable();
				break;
			case "Add New Ads":
				$this->admin_prewrite($adsadminpass);
				break;
			case "Edit":
				$this->admin_prewrite($adsadminpass, $adsadminopid);
				break;
			case "write":
				$this->admin_write($post_vars);
				break;
			case "(De-)Activate":
				$this->admin_switchactive($adsadminopid, $adsactive);
				break;
			case "List All Active Ads":
				$this->admin_list($adsadminpass, 1, $adstype);
				break;
			case "List All Inactive Ads":
				$this->admin_list($adsadminpass, 0, $adstype);
				break;
			case "Delete":
				$this->admin_delete($adsadminopid);
				break;
		}
		
		$this->admin_showfoot();

	}

function admin_login()	{

		$cssfile = $this->cssfile;
		$refpage = $this->refpage;
		
		echo("
			<form action=\"$refpage\" method=\"POST\">
				<input type=\"hidden\" name=\"adsop\" value=\"admin\">
				<input type=\"hidden\" name=\"adsadminop\" value=\"confirmlogin\">
				<p align=\"center\">
					Please input the database access password to log in:
					<br><br>
					<input type=\"password\" name=\"adsadminpass\">
					<br><br>
					<input type=\"Submit\" value=\"Log in\">
				</p>
			</form>
		");
	}

function admin_confirmlogin()	{
	$this->admin_showmsg("Welcome, administrator.<br> Please select from the menu above.");
}

function admin_showmsg($msg)	{
		echo("
			<p align=\"center\" class=\"cssbigger\">
			<b>$msg</b>
			</p>
		");
	}

function admin_createtable()	{
		$adsdbtable = $this->adsdbtable;
		
		$query = 	"
			CREATE TABLE $adsdbtable (
				id int(11) NOT NULL auto_increment,
				active tinyint(4) DEFAULT '1' NOT NULL,
				type varchar(12) NOT NULL,
				zone VARCHAR (72) NOT NULL,
				width int(11) DEFAULT '468' NOT NULL,
				height int(11) DEFAULT '60' NOT NULL,				
				html blob NOT NULL,
				beforelink blob NOT NULL,
				linktarget blob NOT NULL,
				linkbody blob NOT NULL,
				afterlink blob NOT NULL,
				display int(11) DEFAULT '0' NOT NULL,
				click int(11) DEFAULT '0' NOT NULL,
				memo blob,
				PRIMARY KEY (id)
			)
		";
		
		echo("<span class=\"csssmaller\">$query<br></span>");
		
		if ($this->connectdb())	{
			$result = mysql_query($query);
			if ($result)	{
				$this->admin_showmsg("The database table has been created.<br>You can start adding records now.");
			} else	{
				$this->admin_showmsg("Failed to execute the above query. The table may exist already.<br>$result");
			}
		}	else	{
			$this->admin_showmsg("Failed to connect to the specified database.");
		}
	}
	
function admin_droptable()	{
		$adsdbtable = $this->adsdbtable;
		
		$query = 	"DROP TABLE IF EXISTS $adsdbtable";
		
		echo("<span class=\"csssmaller\">$query<br></span>");
		
		if ($this->connectdb())	{
			$result = mysql_query($query);
			if($result)	{
				$this->admin_showmsg("The database table has been removed.<br>You can rest sure to remove the software package now.");
			} else	{
				$this->admin_showmsg("Failed to execute the above query.<br>$result");
			}
		}	else	{
			$this->admin_showmsg("Failed to connect to the specified database.");
		}
	}

function admin_updatetable()	{
		$adsdbtable = $this->adsdbtable;
		
		$query = 	"ALTER TABLE $adsdbtable ADD zone VARCHAR (72) not null AFTER type";
		
		echo("<span class=\"csssmaller\">$query<br></span>");
		
		if ($this->connectdb())	{
			$result = mysql_query($query);
			if($result)	{
				$this->admin_showmsg("The database table has been updated.<br>You can modify each banner to add zone info.");
			} else	{
				$this->admin_showmsg("Failed to execute the above query. You may have updated the table already.<br>$result");
			}
		}	else	{
			$this->admin_showmsg("Failed to connect to the specified database.");
		}
	}

function admin_prewrite($adsadminpass = "", $adsadminopid = "NONE")	{
		//if adsadminopid not specified, indicating "add new"
		//otherwise, indicating "edit current ads"
		
		
				
		$refpage = $this->refpage;
		$adsdbtable = $this->adsdbtable;
		$delimiter = $this->ADSZONEDELIMITER;
				
		if ($adsadminopid != "NONE")	{
			$this->admin_showmsg("Edit Ads Record:");
			
			$adsinfo = $this->show($adsadminopid, FALSE);

			if ($adsinfo != FALSE)	{
				$adsid = isset($adsinfo["id"]) ? $adsinfo["id"] : "";
				$active = isset($adsinfo["active"]) ? $adsinfo["active"] : "";	
				$adstype = isset($adsinfo["type"]) ? $adsinfo["type"] : "";
				$adszone = isset($adsinfo["zone"]) ? $adsinfo["zone"] : "";				
				$adswidth = isset($adsinfo["width"]) ? $adsinfo["width"] : "";
				$adsheight = isset($adsinfo["height"]) ? $adsinfo["height"] : "";
				$beforelink	= isset($adsinfo["beforelink"]) ? $adsinfo["beforelink"] : "";
				$linkbody	= isset($adsinfo["linkbody"]) ? $adsinfo["linkbody"] : "";
				$linktarget	= isset($adsinfo["linktarget"]) ? $adsinfo["linktarget"] : "";
				$afterlink	= isset($adsinfo["afterlink"]) ? $adsinfo["afterlink"] : "";
				$html	= isset($adsinfo["html"]) ? $adsinfo["html"] : "";
				$memo = isset($adsinfo["memo"]) ? $adsinfo["memo"] : "";
				$display = isset($adsinfo["display"]) ? $adsinfo["display"] : "";
				$click = isset($adsinfo["click"]) ? $adsinfo["click"] : "";
			} else	{
				$this->admin_showmsg("Failed to read the specified ads record.");
				return;
			}//end of reading previous ads
		} else	{
			$adsid = $adstype = $beforelink = $linkbody = $linktarget = $afterlink = $html = $memo = "";
			$display = $click = 0;
			$active = 1;
			
			$this->admin_showmsg("Add Ads Record:");
		}
		
		
		//show edit/add new form
		echo("
			<form action=\"$refpage\" method=POST>
		  <input type=\"hidden\" name=\"adsop\" value=\"admin\">
		  <input type=\"hidden\" name=\"adsadminop\" value=\"write\">
		  <input type=\"hidden\" name=\"adsadminopid\" value=\"$adsadminopid\">
		  <input type=\"hidden\" name=\"adsadminpass\" value=\"$adsadminpass\">
		  <table align=\"center\" width=\"90%\" class=\"cssnormal\" border=\"0\" cellpadding=\"3\" cellspacing=\"0\">

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
		  			<b>Ad ID:</b>
		  		</td>
		  		<td align=\"left\" class=\"cssnormal\">
		  			<input type=\"text\" name=\"adsid\" value=\"$adsid\">
						<br>If you are editing an existed Ad, changing the ID to anything else 
						will copy the (edited) record as a NEW Ad. If you are creating a new Ad, just
						leave it blank.
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
					  <b>Active:</b>
		  		</td>
		  		<td align=\"left\" class=\"cssnormal\">
					  <input type=\"text\" name=\"active\"  value=\"$active\">
		  			<br>(The Ad will be visible to visitor only when Active = 1)
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
					  <b>Ad type:</b>
		  		</td>
		  		<td align=\"left\" class=\"cssnormal\">
		  			<select name=\"adstype\">		
		 ");
		 
		 for ($i = 0; $i < count($this->validtype); $i++)	{
		 		$currenttype = $this->validtype[$i];
		 		if ( $currenttype == $adstype)	{
		 			echo("  
    					<option value=\"$currenttype\" selected>$currenttype</option>
    					");
    		}	else	{
    			echo("  
    					<option value=\"$currenttype\">$currenttype</option>
    					");
				}
			}
			
			echo("
						</select>
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
					  <b>Ad width:</b>
		  		</td>
		  		<td align=\"left\" class=\"cssnormal\">
					  <input type=\"text\" name=\"adswidth\"  value=\"$adswidth\">
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
					  <b>Ad height:</b>
		  		</td>
		  		<td align=\"left\" class=\"cssnormal\">
					  <input type=\"text\" name=\"adsheight\"  value=\"$adsheight\"><br>
					  <span class=\"csssmaller\">If the type settings are using the default width*height format,
					  you can simply leave these two fields empty. The program will automatically assign corresponding width and height values to the banner.</span>
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
					  <b>Ad zone:</b>
		  		</td>
		  		<td align=\"left\" class=\"cssnormal\">
					  <input type=\"text\" name=\"adszone\"  value=\"$adszone\">
					  <br><span class=\"csssmaller\">The current zone delimiter is \"$delimiter\". You can use format like zone1$delimiter zone2... (NO SPACE between zones and delimiters) to specify multiple zones.</span>
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
						<b>Extra codes before main link:</b>
					</td>
					<td align=\"left\" class=\"cssnormal\">
						<textarea name=\"beforelink\" rows=\"2\" cols=\"65\">$beforelink</textarea>
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
						<b>Link target:</b>
					</td>
					<td align=\"left\" class=\"cssnormal\">
						(When click, the URL the user will be taken to:)<br>
						<textarea name=\"linktarget\" rows=\"2\" cols=\"65\">$linktarget</textarea>
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
						<b>Link body:</b>
					</td>
					<td align=\"left\" class=\"cssnormal\">
						(The codes to be embraced with < a href=... > and < /a >)
						<textarea name=\"linkbody\" rows=\"2\" cols=\"65\">$linkbody</textarea>
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
						<b>Extra codes after main link:</b><br>
					</td>
					<td align=\"left\" class=\"cssnormal\">
						<textarea name=\"afterlink\" rows=\"2\" cols=\"65\">$afterlink</textarea>
					</td>
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
						<b>Full HTML code:</b>
					</td>
					<td align=\"left\" class=\"cssnormal\">
						(Leave this blank if you have filled the items above. Otherwise use this full code. Any code in this field will OVERRIDE other fields.)<br>
						<textarea name=\"html\" rows=\"5\" cols=\"65\">$html</textarea>
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
						<b>Memo:</b>
					</td>
					<td align=\"left\" class=\"cssnormal\">
						(For further reference. It is useful to add sponsor's info. here. Since the
						\"List All Ads\" function sorts the records by memo):<br>
						<textarea name=\"memo\" rows=\"1\" cols=\"65\">$memo</textarea>
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
		  			<b>Display count: </b>
					</td>
					<td align=\"left\" class=\"cssnormal\">
		  			<input type=\"text\" name=\"display\"  value=\"$display\">
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
						<b>Click count: </b>
					</td>
					<td align=\"left\" class=\"cssnormal\">
		  			<input type=\"text\" name=\"click\"  value=\"$click\">
					</td>
				</tr>

		  	<tr>
		  		<td align=\"right\" class=\"cssnormal\" width=\"160\" valign=\"top\">
						&nbsp;
					</td>
					<td align=\"left\" class=\"cssnormal\">
						<input type=\"Submit\" value=\"Submit\">
					</td>
				</tr>
			</table>
			</form>
		");
	}

function admin_write($post_var)	{
		
		$adsdbtable = $this->adsdbtable;

		$adsid = isset($post_var["adsid"]) ? $post_var["adsid"] : "";
		$active = isset($post_var["active"]) ? $post_var["active"] : "";	
		$adstype = isset($post_var["adstype"]) ? $post_var["adstype"] : "";
		$adszone = isset($post_var["adszone"]) ? $post_var["adszone"] : "";
		$adswidth = isset($post_var["adswidth"]) ? $post_var["adswidth"] : "";
		$adsheight = isset($post_var["adsheight"]) ? $post_var["adsheight"] : "";
		$beforelink	= isset($post_var["beforelink"]) ? $post_var["beforelink"] : "";
		$linkbody	= isset($post_var["linkbody"]) ? $post_var["linkbody"] : "";
		$linktarget	= isset($post_var["linktarget"]) ? $post_var["linktarget"] : "";
		$afterlink	= isset($post_var["afterlink"]) ? $post_var["afterlink"] : "";
		$html	= isset($post_var["html"]) ? $post_var["html"] : "";
		$memo = isset($post_var["memo"]) ? $post_var["memo"] : "";
		$display = isset($post_var["display"]) ? $post_var["display"] : "";
		$click = isset($post_var["click"]) ? $post_var["click"] : "";
		
		$adsadminopid = isset($post_var["adsadminopid"]) ? $post_var["adsadminopid"] : "";

		//new func in v1.2.11 and above,
		//auto detect the size of the ads according to ads type
		if ($adswidth == "" || $adsheight == "")	{
			if ($adstype == "text")	{
				$adswidth = $adsheight = 0;
			} else	{
				$autosize = explode("*", $adstype);
				if (count($autosize) == 2)	{
					$adswidth = $autosize[0];
					$adsheight = $autosize[1];
				}
			}
		}		
		
		if ($adsadminopid == "NONE" || ($adsadminopid != "NONE" && $adsadminopid != $adsid) )	{
			//if request "add", or the ads id has been changed during last edition
			$query = "INSERT INTO $adsdbtable	
							(active, type, zone, width, height, beforelink, linkbody, linktarget, afterlink, html, memo, display, click)	
							VALUES ('$active', '$adstype', '$adszone', '$adswidth', '$adsheight', '$beforelink', '$linkbody', '$linktarget', '$afterlink', '$html', '$memo', '$display', '$click')
						";
		} else	{	
			$query = "UPDATE $adsdbtable SET
								active = '$active',
								type = '$adstype',
								zone = '$adszone',
								width = '$adswidth',
								height = '$adsheight',
								beforelink = '$beforelink',
								linkbody = '$linkbody',
								linktarget = '$linktarget',
								afterlink = '$afterlink',
								html = '$html',
								memo = '$memo',
								display = '$display',
								click = '$click'
								WHERE id = '$adsadminopid'
							";
		}	
		
		echo("$query");
		
		if ($this->connectdb() && mysql_query($query))	{
			$this->admin_showmsg("The Ad record has been added/updated.
							<br>If you are adding record, and want to add 
							duplicate records,<br>simply refresh this page.");
		} else	{
			$this->admin_showmsg("Unknow error during addition/edition");
		}
	}			

function admin_list($adsadminpass = "", $active = 1, $adstype="ALL")	{
		
		$refpage = $this->refpage;
		$adsdbtable = $this->adsdbtable;
		
		if ($adstype == "ALL" || $adstype == "")	{
			//get a full list
			$query = "SELECT * FROM $adsdbtable WHERE (active = '$active') ORDER BY memo, zone, type, width, height, id ASC";
		} else	{
			$query = "SELECT * FROM $adsdbtable WHERE (active = '$active' AND type = '$adstype') ORDER BY memo, zone, type, width, height, id ASC";
		}
		
		echo("<span class=\"csssmaller\">$query<br></span>");
		
		if ($this->connectdb())	{
			$result = mysql_query($query);
			if ($result == TRUE)	{
				$num = mysql_numrows($result);
				
				for ($i = 0; $i < $num; $i++)	{
					$adsid = mysql_result($result, $i, "id");
					$adstype = mysql_result($result, $i, "type");
					$adszone = mysql_result($result, $i, "zone");
					$active = mysql_result($result, $i, "active");
					$adswidth = mysql_result($result, $i, "width");
					$adsheight = mysql_result($result, $i, "height");
					$memo = mysql_result($result, $i, "memo");
					$display = mysql_result($result, $i, "display");
					$click = mysql_result($result, $i, "click");
					
					$bgcolor = (($i%2) == 0)? "#EEEEFF" : "#FFEEEE";
					
					echo("
						<table align=\"center\" width=\"100%\" border=\"0\" cellpadding=\"2\" cellspacing=\"1\">
							<tr>
								<td align=\"left\" class=\"csssmaller\" width=\"80\" nowrap valign=\"top\" bgcolor=\"$bgcolor\">
									ID: $adsid<br>
									Active: $active<br>
									Type: $adstype<br>
									Width: $adswidth<br>
									Height: $adsheight<br>
									Display: $display<br>
									Click: $click
								</td>
								<td align=\"center\" class=\"csssmaller\" width=\"500\" nowrap valign=\"top\"  bgcolor=\"$bgcolor\">
					");
					$this->show($adsid, FALSE);
					echo("
									<br>
									(<b>Zone:</b> $adszone)<br>
									(<b>Memo:</b> $memo)
								</td>
								<td align=\"center\" class=\"csssmaller\"  bgcolor=\"$bgcolor\">
									<form action=\"$refpage\" method=\"post\">
										<input type=\"hidden\" name=\"adsop\" value=\"admin\">
										<input type=\"hidden\" name=\"adsadminpass\" value=\"$adsadminpass\">
										<input type=\"hidden\" name=\"adsactive\" value=\"$active\">
										<input type=\"hidden\" name=\"adsadminopid\" value=\"$adsid\">
										<input type=\"Submit\" name=\"adsadminop\" value=\"(De-)Activate\"><br><br>
										<input type=\"Submit\" name=\"adsadminop\" value=\"Edit\">
										<input type=\"Submit\" name=\"adsadminop\" value=\"Delete\">
									</form>
								</td>
							</tr>
						</table>
					");
				}
			} else	{
				$this->admin_showmsg("Unknown error while accessing database: <br>$result");
			}
		}	else	{
			$this->admin_showmsg("Unknown error while accessing database.");
		}
	}


function admin_switchactive($adsadminopid, $adsactive){
		
		$adsdbtable = $this->adsdbtable;
		$newstat = ($adsactive == 1) ? 0 : 1;
		
		//get a full list
		$query = "UPDATE $adsdbtable SET active = '$newstat' WHERE (id = '$adsadminopid')";
		
		echo("<span class=\"csssmaller\">$query<br></span>");
		
		if ($this->connectdb())	{
			$result = mysql_query($query);
			if ($result == TRUE)	{
				if ($newstat == 1)	{
					$this->admin_showmsg("The Ad has been re-activated.<br>It will be visible to your site browsers.");
				} else	{
					$this->admin_showmsg("The Ad has been de-activated.<br>It will NOT be visible to your site browsers.");
				}
			} else	{
				$this->admin_showmsg("Unknown error while accessing database: <br>$result");
			}
		}	else	{
			$this->admin_showmsg("Unknown error while accessing database.");
		}
	}

function admin_delete($adsadminopid)	{
		$adsdbtable = $this->adsdbtable;
		
		//get a full list
		$query = "DELETE FROM $adsdbtable WHERE (id = '$adsadminopid')";
		
		echo("<span class=\"csssmaller\">$query<br></span>");
		
		if ($this->connectdb())	{
			$result = mysql_query($query);
			if ($result == TRUE)	{
				$this->admin_showmsg("The Ad has been DELETED from the database.");
			} else	{
				$this->admin_showmsg("Unknown error while accessing database: <br>$result");
			}
		}	else	{
			$this->admin_showmsg("Unknown error while accessing database.");
		}
	}

function admin_showhead($adsadminpass = "")	{
		$cssfile = $this->cssfile;
		$refpage = $this->refpage;
		
		$latestver = $this->latestver;
		$latestdate = $this->latestdate;
		$specialver = $this->specialver;

		$typeselect = "<select name=\"adstype\"><option value=\"ALL\" selected>All types</option>";
		 
		for ($i = 0; $i < count($this->validtype); $i++)	{
			$currenttype = $this->validtype[$i];
		 	$typeselect = $typeselect .	"<option value=\"$currenttype\">$currenttype</option>";
		}
		
		$typeselect = $typeselect . "</select>";

		
		echo("
			<html>
			<head>
			<meta http-equiv=\"Content-Language\" content=\"en-us\">
			<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">
			<title>iScouter Smart AD Rotater</title>
			<link rel=\"stylesheet\" href=\"$cssfile\">
			</head>
			
			<body bgcolor=\"#ffffff\" class=\"cssnormal\"> 
			
			<!-- logo -->
			<p align=\"center\" class=\"cssbigger\">
			<b>iScouter Smart AD Rotater $latestver ($latestdate)<br>
			$specialver<br>
			Admininistration Suite 
			</b>
			</p>
			<hr size=\"1\">
			
			<!-- menu -->
			<form action=\"$refpage\" method=\"POST\">
				<input type=\"hidden\" name=\"adsop\" value=\"admin\">
				<input type=\"hidden\" name=\"adsadminpass\" value=\"$adsadminpass\">
				<center>
				<input type=\"Submit\" name=\"adsadminop\" value=\"Add New Ads\">
				&nbsp;
				<input type=\"Submit\" name=\"adsadminop\" value=\"List All Active Ads\">
				&nbsp;
				<input type=\"Submit\" name=\"adsadminop\" value=\"List All Inactive Ads\">
				&nbsp;
				in type: $typeselect
				<br><br>
				<input type=\"Submit\" name=\"adsadminop\" value=\"Create Table (install)\">
				&nbsp;
				<input type=\"Submit\" name=\"adsadminop\" value=\"Drop Table (un-install)\">
				&nbsp;
				<input type=\"Submit\" name=\"adsadminop\" value=\"Update Table (from v1.2.6 to v1.2.7)\">
				</center>
			</form>
			<hr size=\"1\">
		");
	}		 

function admin_showfoot()	{
		$copyright = $this->copyright;
		echo("
			<p>&nbsp;</p>
			<hr size=1>
			<p align=\"center\" class=\"cssnormal\">
			Copyright &copy; <a href=\"http://www.iscouter.net\" target=\"_self\">iScouter.net</a> 
			2000 - 2001.  
			</p>
			<p align=\"left\" class=\"csssmaller\">
			$copyright
			</p>
		");
	}


}//end of class definition
?>
