<?php
				/////////////////////////////////////////////////////////////
				/////////////////////////////////////////////////////////////
				// 							iScouter Smart AD Rotater                  //
				//          (Copyright 2000-2001 iScouter.net)             //
				//	free for use and distribution under certain conditions //
				//  please read the claims via "Admininistration Suite"    //
				//  For latest version of this program, please visit:      //
				//  http://www.iscouter.net/www/freePHP										 //
				/////////////////////////////////////////////////////////////
				/////////////////////////////////////////////////////////////

		//LOCATION OF cAds.php
	require_once	"$DOCUMENT_ROOT/www/support/cAds.php";

	if (!isset($adstype))	$adstype="ALL";
	if (!isset($adsmaxw))	$adsmaxw="NONE";
	if (!isset($adsmaxh))	$adsmaxh="NONE";
	if (!isset($adszone))	$adszone="ALL";
	if (!isset($defaultop))	$defaultop="DEFAULT";
	if (!isset($usetrick))	$usetrick="DEFAULT";
	$myAds = new CAds($adstype, $adsmaxw, $adsmaxh, $adszone, $defaultop, $usetrick);
		
?>