<?php
#idia.php
#idia 1.0 for php, http://idia.sourceforge.net/

include("key.php");

if(!$HTTP_GET_VARS['refresh'] || ($HTTP_GET_VARS['refresh'] && ($refresh < 1 ||
$refresh > 100000))) {


######## START EDITING HERE ########

$refresh = 1;
}

$username = "TYPE_USERNAME_HERE";
$password = "TYPE_PASSWORD_HERE";
$security = 16;

if(1) { #change if(0) to if(1) to gain access

######## STOP EDITING HERE ########


 setcookie("cuser", $username);
 setcookie("cpass", $password);
 setcookie("ckey", $key);

 echo "<html><head><title>Good</title></head><body>Good. Now change the if(1) to if(0) in the idia.php file, upload, and refresh your browser. If all goes well your IP address will appear on the screen and in the ipaddress.txt file.</body></html>";

} else if ($key==$ckey && $username==$cuser && $password==$cpass) {
 $refresh *= 60;

 $fd = fopen("ipaddress.txt", 'w') or exit("Error: Unable to open ipaddress.txt file");
 $a = fread($fd, filesize("ipaddress.txt"));
 if ($a != $REMOTE_ADDR)
   fwrite($fd, $REMOTE_ADDR);

 fclose ($fd);
 $n="";

 for ($c = 0; $c < $security; $c++)
   $n .= rand(0, 9);

 $fd = fopen("key.php", 'w') or exit("Error: Unable to open key.php file");
 fwrite($fd, "<?php \$key = \"$n\";?>\n");
 fclose ($fd);

 setcookie("cuser", $username);
 setcookie("cpass", $password);
 setcookie("ckey", $n);

 $a = $refresh / 60;

 echo "<html><head><title>idia is working</title><META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\"><META HTTP-EQUIV=\"Refresh\" CONTENT=\"$refresh;URL=idia.php?refresh=$a\"></head><body>$REMOTE_ADDR</body></html>";

} else {
 echo "<html><head><title>access denied</title></head><body>access denied</body></html>";
}
?>
