<html>
<head>
	<title>Barcode Download</title>
</head>
<body bgcolor="#FFFFCC">
<table align='center'>
 <tr>
  <td><a href="home.php"><img src="home.png" border="0"></a></td>
  <td><a href="sample.php"><img src="sample.png" border="0"></a></td>
  <td><img src="download.png" border="1"></td>
 </tr>
</table>
<br><br>
<table align="center" width="640">
 <tr><td> This is alpha release, report any problem to <a href="mailto:barcode@mribti.com">barcode@mribti.com</a></td></tr>
 <tr><td><br></td></tr>
 <tr><td align="left">Main site</td></tr>
 <tr><td align="left"><a href="barcode-0.0.7a.tar.gz">barcode-0.0.7a.tar.gz(45kb)</a></td></tr>
 <tr><td align="left"><a href="barcode-0.0.7a.zip">barcode-0.0.7a.zip(47kb)</a></td></tr>
 <tr><td align="left">Mirror site (fast)</td></tr>
 <tr><td align="left"><a href="http://www.aramsoft.com/barcode/barcode-0.0.7a.tar.gz">barcode-0.0.7a.tar.gz(45kb)</a></td></tr>
 <tr><td align="left"><a href="http://www.aramsoft.com/barcode/barcode-0.0.7a.zip">barcode-0.0.7a.zip(47kb)</a></td></tr>
 <tr><td><br></td></tr>
</table>
<br><br>
<table align="center" width="640">
 <tr>
   <td colspan="3" align="center">CHANGES LOG</td>
 </tr>
 <tr>
  <td colspan="3"><br></td>
 </tr>
 <tr>
  <td width="20%" align="left">2001-03-25</td>
  <td width="20%" align="left">v0.0.1a</td>
  <td width="60%">Initial release.</td>
 </tr>
 <tr>
  <td width="20%" align="left">2001-03-26</td>
  <td width="20%" align="left">v0.0.2a</td>
  <td width="60%">Error checking has been added, and there are minor bugfixes</td>
 </tr>
 <tr>
  <td width="20%" align="left">2001-03-26</td>
  <td width="20%" align="left">v0.0.3a</td>
  <td width="60%">Add Code 39 support</td>
 </tr>
 <tr>
  <td width="20%" align="left">2001-03-27</td>
  <td width="20%" align="left">v0.0.4a</td>
  <td width="60%">Minor feature enhancements, new output styles. </td>
 </tr>
 <tr>
  <td width="20%" align="left">2001-03-28</td>
  <td width="20%" align="left">v0.0.5a</td>
  <td width="60%">Add font control, minor bugfixes. </td>
 </tr>
 <tr>
  <td width="20%" align="left">2001-03-29</td>
  <td width="20%" align="left">v0.0.6a</td>
  <td width="60%">Bugfix in Code 39 render, thanks to Henry Bland. </td>
 </tr>
 <tr>
  <td width="20%" align="left">2001-04-01</td>
  <td width="20%" align="left">v0.0.7a</td>
  <td width="60%">Add support for Code 128-A and Code 128-B</td>
 </tr>
</table>
</body>
</html>
