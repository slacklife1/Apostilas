Title: Display contents of a directory and include it in a text area
Description: This script will get the contents of a directory
and display it in a combo box. Then once you click on the file name it will display that file in a text area
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=656&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
