/*
-------------------------
Include script by Psykotyk
-------------------------
Feel free to change any part of this script, 
but please give me some credit for it.
you can also do this with links if you replace the <option> with <a href
and just put the include where ever you want the file to be shown
Enjoy
-- Psykotyk (development@synapse.co.za)
*/
<html>
<head>
<title>Include</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<script>
	function Change() {
		window.location = document.forms[0].select.value
	}
</script>
<p><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Welcome to my include 
  page.<br>
  This is a simple script to get the contents of a directory and display them in a drop down combo<BR>
then when you select one, it displays the contents of that file.<BR>
Coded by <B>Psykotyk</B></font></p>
<form name="form1" method="post" action="include.php">
  <div align="center"> 
    <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Current Includes: 
      <select name="select" OnChange="Change();">
        <?php
		//Open Directory you want to include
		$handel = opendir('includes');
		//Get contents of the directory
		while (false !== ($file = readdir($handel))) {
			if (($file !== ".") and ($file !== "..")) {
			list($filename, $ext) = explode(".", $file);
			list($main, $sub, $include) = explode("/", $PHP_SELF);
    		echo "<option value=\"$PHP_SELF?inc=$file\""; //Echo the file name in a combo box
			if ($inc==$file) echo " selected"; 
			echo">$file</option>\n";
			echo $file;
			}
		}
	?>
      </select>
      </font></p>
    <p> <font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
      <pre><textarea name="textarea" cols="50" rows="20"><?php include("includes/$inc"); /* Include file */ ?></textarea></pre>
      </font></p>
  </div>
</form>
<p></p>
</body>
</html>
