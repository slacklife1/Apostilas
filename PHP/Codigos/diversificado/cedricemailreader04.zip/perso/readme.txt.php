<?
/*
Vous devez cr�er un r�pertoire pour chacun des profile.
Ce r�pertoire doit avoir le m�me nom que le l'identifiant de connexion de chacun des utilisateurs
Dans ce r�pertoire, vous devez copier au moins les trois fichiers du r�pertoire "template",
et les personaliser.

You should create a directory for each profil.
This directory has the same name as the login of the user.
In this directory you should copy and modify at least the 3 files from the template directory,
and custom this files.

*/

?>