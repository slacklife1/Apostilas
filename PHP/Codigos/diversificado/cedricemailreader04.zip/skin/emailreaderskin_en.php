<?

// English skin



// Cedric Email Reader version 0.4 - Copyright (C) 2000-2001 (C�dric AUGUSTIN - cedric@isoca.com)

// This job is licenced under GPL Licence as described in the emailreaderabout.html file.







// Login page

$cer_title = "Cedric email reader";

$cer_txt_server = "Server";

$cer_txt_login = "User";

$cer_txt_pass = "Password";

$cer_button_open = "Open";

$cer_button_reset = "Reset";

$cer_txt_comment = "This webmail is actually working only with an IMAP mail server";

$cer_copyright = "Version 0.3 - Copyright (C) 2000 - 2001 (C�dric AUGUSTIN - cedric@isoca.com)<p>This program comes with ABSOLUTELY NO WARRANTY; <br>This is free software, and you are welcome to redistribute it

    under certain conditions; <br><a href=emailreaderabout.html>Click here</a> for details. ";

$cer_login_error_message = 'Error : login, password or server name mispelling.';



// Left panel

$cer_logo = "logo.gif";

$cer_logo_link = "http://www.isoca.com/";

$cer_logo_alttext = "www.isoca.com";



$cer_new_msg = "New message";

$cer_inbox = "Inbox";

$cer_sent = "Sent";

$cer_about = "About...";

$cer_about_link = "emailreaderabout.html";

$cer_logout = "Quit";





// List panel

$cer_welcome_msg = "Welcome";

$cer_you_have_msg = "you have";

$cer_mail_msg = "message(s).";

// mon tue wed thu fri sat sun

$days = array('Mon' => 'Mon', 'Tue' => 'Tue', 'Wed' => 'Wed', 'Thu' => 'Thu', 'Fri' => 'Fri', 'Sat' => 'Sat', 'Sun' => 'Sun');

$month = array('Jan'=> '01', 'Feb'=>'02', 'Mar'=>'03', 'Apr'=>'04', 'May'=>'05', 'Jun'=>'06', 'Jul'=>'07', 'Aug'=>'08', 'Sep'=>'09', 'Oct'=>'10', 'Nov'=>'11', 'Dec'=>'12');

$days_full = array('Mon' => 'Monday', 'Tue' => 'Tuesday', 'Wed' => 'Wednesday', 'Thu' => 'Thursday', 'Fri' => 'Friday', 'Sat' => 'Saturday', 'Sun' => 'Sunday');

$month_full = array('Jan'=> 'January', 'Feb'=>'F�bruary', 'Mar'=>'Mars', 'Apr'=>'April', 'May'=>'May', 'Jun'=>'June', 'Jul'=>'July', 'Aug'=>'Auguat', 'Sep'=>'September', 'Oct'=>'Octobre', 'Nov'=>'Novembre', 'Dec'=>'D�cembre');



// Detail panel

$cer_reply_txt = "Reply/Forward";

$cer_forward_txt = "Forward";

$cer_source_txt = "Source";

$cer_prev_txt = "Prev";

$cer_next_txt = "Next";

$cer_attach = 'Attachement(s)';

$cer_reply_all = 'Reply all';



// Adress book

$cer_adress_book = "Adress book";

$cer_adress_book_txt = "Add to adress book";

$cer_adress_book_title = "Adress book";

$cer_adress_book_modify_txt = "Modify";



// Option and profil

$cer_options = 'Options';





// Email composer

$cer_to_txt = "To";

$cer_copy_txt = "Copy";

$cer_blind_copy_txt = "Blind copie";

$cer_from_txt = "From";

$cer_subject_txt = "Subject";

$cer_message_txt = "Message";

$cer_attach_txt = "Attachment";

$cer_button_send = "Send";

$cer_reply_prefix = "Re:";

$cer_reply_separator = "=======================================================";

$cer_reply_date_txt = "On";

$cer_reply_wrote_txt = "wrote";

$cer_reply_char = ">";

$cer_date_txt = 'Date';





// Email send

$cer_send_msg_from = "The message from";

$cer_send_sended = "has been sent to";

$cer_send_button_close = "Close windows";

$cer_error_invalid_email = 'Invalid email address';

$cer_error_attachment = 'Temporary file error. Empty attachment';

$cer_error_upload = 'Upload error. Attachment not send.';



// Email delete

$cer_del_txt = "Delete";

$cer_del_confirm_txt = "Confirm delete";

$cer_del_cancel_txt = "Cancel";

$cer_del_ok = "The message has been deleted !!";

$cer_del_error = "Error. The message has not been deleted.";





// Logout page

$cer_back_to_login = "Back to login page";

$cer_back_to_main = "Back to Isoca";

$cer_logout_message = "Thank you for using this webmail.";



?>