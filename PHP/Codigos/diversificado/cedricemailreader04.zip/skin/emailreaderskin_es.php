<?

// Spanish skin



// Cedric Email Reader version 0.4 - Copyright (C) 2000-2001 (C�dric AUGUSTIN - cedric@isoca.com)

// This job is licenced under GPL Licence as described in the emailreaderabout.html file.







// Login page

$cer_title = "Cedric email reader";

$cer_txt_server = "Servidor";

$cer_txt_login = "Cuenta";

$cer_txt_pass = "Contrase�a";

$cer_button_open = "Abrir";

$cer_button_reset = "Poner a cero";

$cer_txt_comment = "Este webmail fonctiona por el momento solamente con un servidor mail IMAP";

$cer_copyright = "Version 0.3, Copyright (C) 2000 - 2001 Cedric AUGUSTIN - cedric@isoca.com<br>Ce programme est fourni sans AUCUNE GARANTIE.<br>Ce programme est libre et vous �tes encourag� � le redistribuer sous certaines conditions.<p>Pour plus de d�tails, <a href=emailreaderabout.html>cliquez ici</a>";

$cer_login_error_message = 'Error de conexi�n: nombre de cuenta, contrase�a or nombre de servidor errado.';





// Left panel

$cer_logo = "logo.gif";

$cer_logo_link = "http://www.isoca.com/";

$cer_logo_alttext = "www.isoca.com";



$cer_new_msg = "Nuevo recado";

$cer_inbox = "Buz�n";

$cer_sent = "Mandados";

$cer_about = "En cuanto a...";

$cer_about_link = "emailreaderabout.html";

$cer_logout = "Cerrar";





// List panel

$cer_welcome_msg = "Bon dia";

$cer_you_have_msg = "tienes";

$cer_mail_msg = "mensage(s).";

// mon tue wed thu fri sat sun

$days = array('Mon' => 'Lun', 'Tue' => 'Mar', 'Wed' => 'Mie', 'Thu' => 'Jue', 'Fri' => 'Vie', 'Sat' => 'Sab', 'Sun' => 'Dom');

$month = array('Jan'=> '01', 'Feb'=>'02', 'Mar'=>'03', 'Apr'=>'04', 'May'=>'05', 'Jun'=>'06', 'Jul'=>'07', 'Aug'=>'08', 'Sep'=>'09', 'Oct'=>'10', 'Nov'=>'11', 'Dec'=>'12');

$days_full = array('Mon' => 'Lunes', 'Tue' => 'Martes', 'Wed' => 'Miercoles', 'Thu' => 'Jueves', 'Fri' => 'Vendredi', 'Sat' => 'Sabado', 'Sun' => 'Domingo');

$month_full = array('Jan'=> 'Enero', 'Feb'=>'Febrero', 'Mar'=>'Marzo', 'Apr'=>'Abril', 'May'=>'Mayo', 'Jun'=>'Junio', 'Jul'=>'Julio', 'Aug'=>'Agosto', 'Sep'=>'Septiembre', 'Oct'=>'Octubre', 'Nov'=>'Noviembre', 'Dec'=>'Diciembre');



// Detail panel

$cer_reply_txt = "Contestar/Traspasar";

$cer_forward_txt = "Traspasar";

$cer_source_txt = "Codigo venera";

$cer_prev_txt = "Precedente";

$cer_next_txt = "Siguiente";

$cer_attach = 'Anejo(s)';

$cer_reply_all = 'Contestar todos';



// Adresse book

$cer_adress_book = "Librio de adresses";

$cer_adress_book_txt = "Agregar al librio de adresses";

$cer_adress_book_title = "Librio de adresses";

$cer_adress_book_modify_txt = "Modificar";



// Option and profil

$cer_options = 'Opci�nes';





// Email composer

$cer_to_txt = "Destinatario";

$cer_copy_txt = "Copia";

$cer_blind_copy_txt = "Copia escondida";

$cer_from_txt = "Expeditor";

$cer_subject_txt = "Sujeto";

$cer_message_txt = "Mensage";

$cer_attach_txt = "Anejo";

$cer_button_send = "Enviar";

$cer_reply_prefix = "Re:";

$cer_reply_separator = "=======================================================";

$cer_reply_date_txt = "El";

$cer_reply_wrote_txt = "a escribido";

$cer_reply_char = ">";

$cer_date_txt = 'Fecha';



// Email send

$cer_send_msg_from = "El mensage de";

$cer_send_sended = "ha estado enviado a";

$cer_send_button_close = "Cerrar la ventana";

$cer_error_invalid_email = 'Invalid email address';

$cer_error_attachment = 'Error de archivo temporario. Anejo vac�o';

$cer_error_upload = 'Error de Upload. Anejo no enviado.';



// Email delete

$cer_del_txt = "Suprimir";

$cer_del_confirm_txt = "Confirmar la supresion ?";

$cer_del_cancel_txt = "Annular";

$cer_del_ok = "El mensage ha estado suprimado !!";

$cer_del_error = "Error, el mensage no ha estado suprimado.";





// Logout page

$cer_back_to_login = "Volver al pagina de login";

$cer_back_to_main = "Volver a Isoca";

$cer_logout_message = "Gracias de ha utilisado este webmail.";



?>