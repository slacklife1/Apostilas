<?

// Swedish skin



// Cedric Email Reader version 0.4 - Copyright (C) 2000-2001 (C�dric AUGUSTIN - cedric@isoca.com)

// This job is licenced under GPL Licence as described in the emailreaderabout.html file.







// Login page

$cer_title = "Cedrics email-l�sare";

$cer_txt_server = "Server";

$cer_txt_login = "Anv�ndare";

$cer_txt_pass = "L�senord";

$cer_button_open = "�ppna";

$cer_button_reset = "Radera";

$cer_txt_comment = "Denna webmail fungerar f.n. enbart med en IMAP-server";

$cer_copyright = "Version 0.3, Copyright (C) 2000 - 2001 Cedric AUGUSTIN - cedric@isoca.com<br>

Detta program levereras UTAN N�GON SOM HELST GARANTI.<br>Det h�r programmet �r fritt och anv�ndarna uppmuntras att distribuera det under vissa villkor.<p>F�r mer detaljer, <a href=emailreaderabout.html>Klicka h�r</a>";

$cer_login_error_message = 'Fel : anv�ndarnamn, l�senord eller server-namn felskrivet.';





// Left panel

$cer_logo = "logo.gif";

$cer_logo_link = "http://www.isoca.com/";

$cer_logo_alttext = "www.isoca.com";



$cer_new_msg = "Nytt meddelande";

$cer_inbox = "Brevl�da";

$cer_sent = "Skickade";

$cer_about = "Ang�ende...";

$cer_about_link = "emailreaderabout.html";

$cer_logout = "Logga ut";





// List panel

$cer_welcome_msg = "V�lkommen";

$cer_you_have_msg = "Du har";

$cer_mail_msg = "meddelande(n).";

$days = array('Mon' => 'M�n', 'Tue' => 'Tis', 'Wed' => 'Ons', 'Thu' => 'Tor', 'Fri' => 'Fre', 'Sat' => 'L�r', 'Sun' => 'S�n');

$month = array('Jan'=> '01', 'Feb'=>'02', 'Mar'=>'03', 'Apr'=>'04', 'May'=>'05', 'Jun'=>'06', 'Jul'=>'07', 'Aug'=>'08', 'Sep'=>'09', 'Oct'=>'10', 'Nov'=>'11', 'Dec'=>'12');

$days_full = array('Mon' => 'M�ndag', 'Tue' => 'Tisdag', 'Wed' => 'Onsdag', 'Thu' => 'Torsdag', 'Fri' => 'Fredag', 'Sat' => 'L�rdag', 'Sun' => 'S�ndag');

$month_full = array('Jan'=> 'Januari', 'Feb'=>'Februari', 'Mar'=>'Mars', 'Apr'=>'April', 'May'=>'Maj', 'Jun'=>'Juni', 'Jul'=>'Juli', 'Aug'=>'Augusti', 'Sep'=>'September', 'Oct'=>'Oktober', 'Nov'=>'November', 'Dec'=>'D�cember');







// Detail panel

$cer_reply_txt = "Svara/Vidarebefordra";

$cer_forward_txt = "Vidarebefordra";

$cer_source_txt = "K�lla";

$cer_prev_txt = "F�reg�ende";

$cer_next_txt = "N�sta";

$cer_attach = 'Vidh�ftat';

$cer_reply_all = 'Svara alla';



// Adresse book

$cer_adress_book = "Adressboken";

$cer_adress_book_txt = "L�gg till i Adressboken";

$cer_adress_book_title = "Adressboken";

$cer_adress_book_modify_txt = "�ndra";



// Option and profil

$cer_options = 'Inst�llningar';





// Email composer

$cer_to_txt = "Mottagare";

$cer_copy_txt = "Kopia";

$cer_blind_copy_txt = "G�md kopia";

$cer_from_txt = "Avs�ndare";

$cer_subject_txt = "�rende";

$cer_message_txt = "Meddelande";

$cer_attach_txt = "Vidh�ftat";

$cer_button_send = "Skicka";

$cer_reply_prefix = "Re:";

$cer_reply_separator = "=======================================================";

$cer_reply_date_txt = "Den";

$cer_reply_wrote_txt = "har skrivit";

$cer_reply_char = ">";

$cer_date_txt = 'Datum';





// Email send

$cer_send_msg_from = "Meddelandet fr�n";

$cer_send_sended = "har blivit skickat till";

$cer_send_button_close = "St�ng f�nster";

$cer_error_invalid_email = 'Felaktig email-adress';

$cer_error_attachment = 'Tempor�r-fil-fel. Inget �r Vidh�ftat';

$cer_error_upload = 'Uppladdnings-fel. Vidh�ftat blev inte skickat.';



// Email delete

$cer_del_txt = "Radera";

$cer_del_confirm_txt = "Bekr�fta radering";

$cer_del_cancel_txt = "Annulera";

$cer_del_ok = "Meddelandet har blivit raderat !!";

$cer_del_error = "Ett fel har uppst�tt. Meddelandet har inte raderats.";





// Logout page

$cer_back_to_login = "Tillbaka till inloggning";

$cer_back_to_main = "Tillbaka till Isoca";

$cer_logout_message = "Tack f�r att ha anv�nt detta webmail.";



?>