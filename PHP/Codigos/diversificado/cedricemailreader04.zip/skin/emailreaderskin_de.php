<?

// German skin



// Cedric Email Reader version 0.4 - Copyright (C) 2000-2001 (C�dric AUGUSTIN - cedric@isoca.com)

// This job is licenced under GPL Licence as described in the emailreaderabout.html file.







// Login page

$cer_title = "Cedric email reader";

$cer_txt_server = "Server";

$cer_txt_login = "Konto";

$cer_txt_pass = "Passwort";

$cer_button_open = "�ffnen";

$cer_button_reset = "Neu einstellen";

$cer_txt_comment = "Dieser webmail fonktioniert nochmal nur mit ein server mail IMAP";

$cer_copyright = "Version 0.3, Copyright (C) 2000 - 2001 Cedric AUGUSTIN - cedric@isoca.com<br>Ce programme est fourni sans AUCUNE GARANTIE.<br>Ce programme est libre et vous �tes encourag� � le redistribuer sous certaines conditions.<p>Pour plus de d�tails, <a href=emailreaderabout.html>cliquez ici</a>";

$cer_login_error_message = 'Error : Password, Kontoname oder Servername falsch.';





// Left panel

$cer_logo = "logo.gif";

$cer_logo_link = "http://www.isoca.com/";

$cer_logo_alttext = "www.isoca.com";



$cer_new_msg = "Neues mitteilenden";

$cer_inbox = "Briefkasten";

$cer_sent = "Geschickt";

$cer_about = "Betreffs...";

$cer_about_link = "emailreaderabout.html";

$cer_logout = "Schliesen";





// List panel

$cer_welcome_msg = "Guten Tag";

$cer_you_have_msg = "Sie hat";

$cer_mail_msg = "mitteilende(n).";

// mon tue wed thu fri sat sun

$days = array('Mon' => 'Mon', 'Tue' => 'Din', 'Wed' => 'Mit', 'Thu' => 'Don', 'Fri' => 'Fre', 'Sat' => 'Sam', 'Sun' => 'Son');

$month = array('Jan'=> '01', 'Feb'=>'02', 'Mar'=>'03', 'Apr'=>'04', 'May'=>'05', 'Jun'=>'06', 'Jul'=>'07', 'Aug'=>'08', 'Sep'=>'09', 'Oct'=>'10', 'Nov'=>'11', 'Dec'=>'12');

$days_full = array('Mon' => 'Montag', 'Tue' => 'Dinstag', 'Wed' => 'Mittwoch', 'Thu' => 'Donnerstag', 'Fri' => 'Vendredi', 'Sat' => 'Samstag', 'Sun' => 'Sontag');

$month_full = array('Jan'=> 'Januar', 'Feb'=>'Februar', 'Mar'=>'M�rz', 'Apr'=>'April', 'May'=>'Mai', 'Jun'=>'Juni', 'Jul'=>'Juli', 'Aug'=>'August', 'Sep'=>'September', 'Oct'=>'Oktober', 'Nov'=>'November', 'Dec'=>'Dezember');



// Detail panel

$cer_reply_txt = "Antworten/Weiterschicken";

$cer_forward_txt = "Weiterschicken";

$cer_source_txt = "Kelle";

$cer_prev_txt = "Vorige";

$cer_next_txt = "N�chste";

$cer_attach = 'Anheftet';

$cer_reply_all = 'Alle Antworten';



// Adresse book

$cer_adress_book = "Adressenbuch";

$cer_adress_book_txt = "Zulegen zum adressenbuch";

$cer_adress_book_title = "Adressenbuch";

$cer_adress_book_modify_txt = "�ndern";



// Option and profil

$cer_options = 'Einstellungen';



// Email composer

$cer_to_txt = "Empf�nger";

$cer_copy_txt = "Kopie";

$cer_blind_copy_txt = "Verstecktes Kopie";

$cer_from_txt = "Von";

$cer_subject_txt = "Thema";

$cer_message_txt = "Nachricht";

$cer_attach_txt = "Anheftet";

$cer_button_send = "Schicken";

$cer_reply_prefix = "Re:";

$cer_reply_separator = "=======================================================";

$cer_reply_date_txt = "Den";

$cer_reply_wrote_txt = "hat geschrieben";

$cer_reply_char = ">";

$cer_date_txt = 'Datum';



// Email send

$cer_send_msg_from = "Die Nachricht von";

$cer_send_sended = "sind gesendet zu";

$cer_send_button_close = "Fenster schlissen";

$cer_error_invalid_email = 'Invalid email address';

$cer_error_attachment = 'Temporary file error. Empty attachment';

$cer_error_upload = 'Upload error. Attachment not send.';





// Email delete

$cer_del_txt = "Tilgen";

$cer_del_confirm_txt = "Tilgen best�tigen ?";

$cer_del_cancel_txt = "Beenden";

$cer_del_ok = "Die Nachricht sind veggenommen !!";

$cer_del_error = "Fehler. Die Nachricht sind nicht veggenommen.";





// Logout page

$cer_back_to_login = "Zur�ck nach der login-seite";

$cer_back_to_main = "Zur�ck nach Isoca";

$cer_logout_message = "Danke das Sie dieser webmail verwendet.";



?>