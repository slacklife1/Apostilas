#!/usr/local/bin/php -q
<?php

require("install-lib.php");

$setup = array();

$stdin = fopen('php://stdin', 'r');

check_php_install();
print "PHP installation looks OK...\n";

check_mysql();
print "MySQL installation looks OK...\n";

get_setup_vals();

create_directories($setup);
setup_mysql($setup);

#### reload MySQL so that the db_user can connect to the database
$command = ($setup[db_host])
    ? "mysqladmin --host=$setup[db_host] --user=$setup[mysql_admin_user] --password=$setup[mysql_admin_password] reload"
    : "mysqladmin --user=$setup[mysql_admin_user] --password=$setup[mysql_admin_password] reload";
print "$command\n";
print `$command`;

#### now run the hourly_maint.php script for the first time
$command = "su - $setup[web_user] -c '$setup[oasis_root]mgmt/hourly_maint.php start'";
print "$command\n";
print `$command`;


?>
