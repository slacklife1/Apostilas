<?php

$fallthrough = 0;
$nocookie = 0;
$remote_address = getenv("REMOTE_ADDR");
$cl_id = get_client_id();

#### are we getting called by an embedded ad serve?
if($cr_id = $c)
{
  #### rich media serves may send us a specific URL to click through to
  list($event, $code) = deliver_clickthrough($cr_id, $url);
  log_msg($cl_id, $remote_address, $s, $cr_id, $event, $code, $HTTP_USER_AGENT);
}
#### if we're getting called via an IMG-based ad serve, we need to
#### find out what creative was delivered
elseif($cr_id = retrieve_creative($cl_id, $remote_address, $s, $w, $h))
{
  list($event, $code) = deliver_clickthrough($cr_id);
  log_msg($cl_id, $remote_address, $s, $cr_id, $event, $code, $HTTP_USER_AGENT);
}
else
{
  log_msg($cl_id, $remote_address, $s, $cr_id, 'cerr', 'no_cr_found', $HTTP_USER_AGENT);
}


####---------------------------------------------------------------------------
#### look for a cookie; if found, return its ID number.  Otherwise, generate
#### a new ID.
####---------------------------------------------------------------------------
function get_client_id()
{
  global $HTTP_COOKIE_VARS;

  #### cookie is named OASISID
  if(!($id = $HTTP_COOKIE_VARS["OASISID"])) $id = '-';

  return $id;
}



####---------------------------------------------------------------------------
#### redirect to clickthrough URL
####---------------------------------------------------------------------------
function deliver_clickthrough($cr_id, $url='')
{
  global $fallthrough;

  if(!(($sem_id = sem_get(0x4f410000, 1)) && sem_acquire($sem_id)))
  {
    header("Location: ");
    return array('cerr', 'no_sem');
  }

  #### attach to Hourly Targets shared memory segment
  #### identifier:     O A S 1
  $smh = shm_attach(0x4f415301, 0);
  @$cr_info = shm_get_var($smh, $cr_id);

  #### if for some reason there is no array waiting for us (perhaps the
  #### database has been reloaded and a campaign is no longer active),
  #### we'll have to bail out
  if(!$cr_info)
  {
    header("Location: ");

    shm_detach($smh);
    sem_release($sem_id);

    return array('cerr', "no_ht_array ($php_errormsg)");
  }

  $cr_info[3]++;

  shm_put_var($smh, $cr_id, $cr_info);
  shm_detach($smh);

  sem_release($sem_id);

  #### connect to shared memory segment to get URL
  #### identifier:     O A S 3
  if (!$url)
  {
    $smh = shm_attach(0x4f415303, 0); 
    $url = shm_get_var($smh, $cr_id);
    if(!$url)
    {
      header("Location: ");
      return array('cerr', 'no_ct_array');
    }
    shm_detach($smh);
  }

  mt_srand((double)microtime()*1000000);
  $random_number = mt_rand();
  $url = preg_replace("#\[CB\]#", $random_number, $url);

  header("Location: $url");
  header("Pragma: no-cache");
  header("Cache-Control: no-cache");

  if($fallthrough) return array('click', 'fallthru');
  if($nocookie)    return array('click', 'nocookie');
  else             return array('click', '');
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function retrieve_creative($client, $ipaddr, $sec, $w, $h)
{
  global $fallthrough, $nocookie;

  $cr_id = 0;
  $key_end = sprintf("%04x%04x%04x", $sec, $w, $h);
  
  mysql_pconnect("[db_host]", "[db_user]", "[db_passwd]");
  mysql_select_db("oasis");

  #### ideally, we'd like to use the first key to retrieve the appropriate
  #### creative, but if the user is not accepting cookies, then our
  #### client ID is a bogus one, so we won't find anything in shared
  #### memory; we'll have to fall back on the IP address alone (this
  #### of course, is subject to all sorts of errors -- proxies, etc.)
  if($client != '-')
  {
    $bucket_key = $client . $key_end;
    if($result = mysql_query("select CreativeID from Delivery where IDString='$bucket_key'"))
    {
      list($cr_id) = mysql_fetch_row($result);
      if($cr_id) return $cr_id;

      $fallthrough = 1;
    }
  }
  else
  {
    $nocookie = 1;
  }

  #### OK, either we didn't get a cookie or the lookup based on the cookie
  #### we got didn't work.  So we fall through to using the IP address
  preg_match('#(\d+)\.(\d+)\.(\d+)\.(\d+)#', $ipaddr, $ip);
  $bucket_key = sprintf("%02x%02x%02x%02x", $ip[1], $ip[2], $ip[3], $ip[4])
               . $key_end;

  if($result = mysql_query("select CreativeID from Delivery where IDString='$bucket_key'"))
    list($cr_id) = mysql_fetch_row($result);

  return $cr_id;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function log_msg($user, $ipaddr, $section, $creative_id, $event, $code, $ua)
{
  $log_message = time()
       . "\t$ipaddr\t$user\t$event\t$section\t$creative_id\t$code\t$ua\n";

  #### grab a semaphore; we don't want to write to this log
  #### when another instance of this script is in there
  #### identifier:           O A 0 0
  if(!(($sem_id = sem_get(0x4f410000, 1)) && sem_acquire($sem_id)))
    return 0;

  error_log($log_message, 3, "[log_dir]/oasis.log");

  sem_release($sem_id);
}


?>
