<?php

require("lib-mgmt.inc");

print_html_header($OASISmsg[OASIS_Management]);
print_header('Index', '', '');
print_footer();

?>
