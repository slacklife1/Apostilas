<?php

require("lib-mgmt.inc");

print_html_header ($OASISmsg[Section_Management]);
?>

<BODY BGCOLOR="#ffffff" TEXT="#000000" LINK="#0000ff" VLINK="#330066" ALINK="#ff0000">

<?php

$root = get_prefs("OASISRoot");

preg_match('#(\d+)x(\d+)#', $dim, $matches);
list($c, $w, $h) = $matches;

if($result = mysql_query("select ReportName from Sections where SectionID=$s"))
{
  list($section) = mysql_fetch_row($result);
}


$label = <<<__TEXT__
<FONT SIZE="+1"><STRONG>$section, $w x $h</STRONG></FONT><BR>

__TEXT__;

if($type == 'embedded')
{
  $path = getcwd();
  $path = preg_replace("#/[^/]+$#", "", $path);

  $label .= "$OASISmsg[Sample_embedded_tag]\n";

  $sample =<<<__TEXT__
<?php
require("{$path}/oasisi-e.php");
\$ad = get_creative($s, $w, $h, '');
?>


<?php echo \$ad; ?>
__TEXT__;

}
elseif($type == 'ilayeriframe')
{
  $label .= "$OASISmsg[Sample_ILAYER_IFRAME_tag]\n";

  $sample =<<<__TEXT__
<NOLAYER>
<IFRAME SRC="{$root}oasisi-i.php?s=$s&w=$w&h=$h"
WIDTH=$w HEIGHT=$h FRAMEBORDER="no" BORDER=0 MARGINWIDTH=0
MARGINHEIGHT=0 SCROLLING="no"><A
HREF="{$root}oasisc.php?s=$s&w=$w&h=$h"><IMG
SRC="{$root}oasisi.php?s=$s&w=$w&h=$h"
BORDER=0 WIDTH=$w HEIGHT=$h></A>
</IFRAME>
</NOLAYER>
<ILAYER ID="layer1" VISIBILITY="hidden" WIDTH=$w HEIGHT=$h></ILAYER><P>
<LAYER
SRC="{$root}oasisi-i.php?s=$s&w=$w&h=$h"
WIDTH=$w HEIGHT=$h VISIBILITY="hidden"
onLoad="moveToAbsolute(layer1.pageX,layer1.pageY);clip.height=$h;clip.width=$w;visibility='show';"></LAYER>
__TEXT__;
}
elseif($type == 'iframe_j')
{
  $label .= "$OASISmsg[Sample_IFRAME_Javascript]\n";

  $sample =<<<__TEXT__
<SCRIPT LANGUAGE="JavaScript"> 
<!-- 
now = new Date(); 
random = now.getTime(); 
document.write('<IFRAME SRC="{$root}oasisi-i.php?s=$s&w=$w&h=$h&cb=' + random + '"'); 
document.write(' NORESIZE SCROLLING=NO HSPACE=0 VSPACE=0');
document.write(' FRAMEBORDER=0 MARGINHEIGHT=0 MARGINWIDTH=0');
document.write(' WIDTH=$w HEIGHT=$h>'); 
document.write('<A HREF="{$root}oasisc.php?s=$s&w=$w&h=$h&cb=' + random + '">');
document.write('<IMG SRC="{$root}oasisi.php?s=$s&w=$w&h=$h&cb=' + random + '"');
document.write(' WIDTH=$w HEIGHT=$h BORDER=0></A>');
document.write('</IFRAME>'); 
// --> 
</SCRIPT>
<NOSCRIPT>
<IFRAME SRC="{$root}oasisi-i.php?s=$s&w=$w&h=$h"
MARGINWIDTH=0 MARGINHEIGHT=0 HSPACE=0 VSPACE=0
FRAMEBORDER=0 SCROLLING=NO
WIDTH=$w HEIGHT=$h>
<A HREF="{$root}oasisc.php?s=$s&w=$w&h=$h"><IMG
SRC="{$root}oasisi.php?s=$s&w=$w&h=$h"
WIDTH=$w HEIGHT=$h BORDER=0></A>
</IFRAME>
</NOSCRIPT>
__TEXT__;
}
elseif($type == 'iframe')
{
  $label .= "$OASISmsg[Sample_IFRAME_tag]\n";

  $sample =<<<__TEXT__
<IFRAME SRC="{$root}oasisi-i.php?s=$s&w=$w&h=$h"
MARGINWIDTH=0 MARGINHEIGHT=0 HSPACE=0 VSPACE=0
FRAMEBORDER=0 SCROLLING=NO
WIDTH=$w HEIGHT=$h>
<A HREF="{$root}oasisc.php?s=$s&w=$w&h=$h"><IMG
SRC="{$root}oasisi.php?s=$s&w=$w&h=$h"
WIDTH=$w HEIGHT=$h BORDER=0></A>
</IFRAME>
__TEXT__;
}
elseif($type == 'img_j')
{
  $label .= "$OASISmsg[Sample_IMG_Javascript]\n";

  $sample =<<<__TEXT__
<SCRIPT LANGUAGE="JavaScript">
<!--
now = new Date();
random = now.getTime();
document.write('<A HREF="{$root}oasisc.php?s=$s&w=$w&h=$h&cb=' + random + '">');
document.write('<IMG SRC="{$root}oasisi.php?s=$s&w=$w&h=$h&cb=' + random + '"');
document.write(' WIDTH=$w HEIGHT=$h BORDER=0></A>');
//-->
</SCRIPT>
<NOSCRIPT>
<A HREF="{$root}oasisc.php?s=$s&w=$w&h=$h"><IMG
SRC="{$root}oasisi.php?s=$s&w=$w&h=$h"
WIDTH=$w HEIGHT=$h BORDER=0></A>
</NOSCRIPT>
__TEXT__;
}
elseif($type == 'img')
{
  $label .= "$OASISmsg[Sample_IMG_tag]\n";

  $sample =<<<__TEXT__
<A HREF="{$root}oasisc.php?s=$s&w=$w&h=$h"><IMG
SRC="{$root}oasisi.php?s=$s&w=$w&h=$h"
WIDTH=$w HEIGHT=$h BORDER=0></A>
__TEXT__;
}
elseif($type == 'javascript')
{
  $label .= "$OASISmsg[Sample_Javascript_tag]\n";

  $sample =<<<__TEXT__
<SCRIPT LANGUAGE="JavaScript"
SRC="{$root}oasisi-j.php?s=$s&w=$w&h=$h">
</SCRIPT>
<NOSCRIPT>
<A HREF="{$root}oasisc.php?s=$s&w=$w&h=$h"><IMG
SRC="{$root}oasisi.php?s=$s&w=$w&h=$h"
WIDTH=$w HEIGHT=$h BORDER=0></A>
</NOSCRIPT>
__TEXT__;
}

$sample = preg_replace('#&#', '&amp;', $sample);
$sample = preg_replace('#<#', '&lt;', $sample);
$sample = preg_replace('#>#', '&gt;', $sample);
$sample = preg_replace('#\n#', "<BR>\n", $sample);
$sample = preg_replace('# #', "&nbsp;", $sample);


print "<STRONG>$label</STRONG><P><FONT SIZE=\"-1\">$sample</FONT>";


?>
