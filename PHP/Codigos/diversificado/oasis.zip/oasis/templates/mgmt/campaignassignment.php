<?php

require("lib-mgmt.inc");

if($save) save_assignments($CampaignID, $SectionID, $save);

print_html_header($OASISmsg[Assign_Campaign_to_Sections]);
print_header('Campaign Assignments', $CampaignID, '');

print <<<__TEXT__
<FORM METHOD=POST ACTION="campaignassignment.php">
<INPUT TYPE=hidden NAME=CampaignID VALUE="$CampaignID">
<TABLE CELLPADDING=0 CELLSPACING=1 BORDER=0>
<TR>
<TD CLASS=tablehead><SPAN CLASS=tablehead>$OASISmsg[Section]</SPAN></TD>
<TD CLASS=tablehead><SPAN CLASS=tablehead>$OASISmsg[Include]</SPAN></TD>
<TD CLASS=tablehead><SPAN CLASS=tablehead>$OASISmsg[Exclude]</SPAN></TD>
<TD CLASS=tablehead><SPAN CLASS=tablehead>$OASISmsg[Exclusive]</SPAN></TD>
</TR>
__TEXT__;

load_assignments($CampaignID);
build_section_tree(0, 0);

print <<<__TEXT__
<TR><TD COLSPAN=4>
<INPUT TYPE=submit VALUE="$OASISmsg[Save]" NAME=save>
</TD></TR>
</TABLE></FORM>
__TEXT__;


print_footer();
####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function save_assignments()
{
  global $CampaignID;
  global $Includes, $Excludes, $Exclusives;
  global $OASISmsg;

  $sql = "delete from CampaignAssignments where CampaignID=$CampaignID";
  if(!mysql_query($sql))
  {
    print "$OASISmsg[MySQL_error]: " . mysql_error();
    exit;
  }

  if($Includes)
  {
    while(list(, $s) = each($Includes))
    {
      $sql = "insert into CampaignAssignments (CampaignID, SectionID, Type) values ($CampaignID, $s, 'Include')";
      if(!mysql_query($sql))
      {
        print "$OASISmsg[MySQL_error]: " . mysql_error();
        exit;
      }
    }
  }

  if($Excludes)
  {
    while(list(, $s) = each($Excludes))
    {
      $sql = "insert into CampaignAssignments (CampaignID, SectionID, Type) values ($CampaignID, $s, 'Exclude')";
      if(!mysql_query($sql))
      {
        print "$OASISmsg[MySQL_error]: " . mysql_error();
        exit;
      }
    }
  }

  if($Exclusives)
  {
    while(list(, $s) = each($Exclusives))
    {
      $sql = "insert into CampaignAssignments (CampaignID, SectionID, Type) values ($CampaignID, $s, 'Exclusive')";
      if(!mysql_query($sql))
      {
        print "$OASISmsg[MySQL_error]: " . mysql_error();
        exit;
      }
    }
  }

  header("Location: campaign.php?CampaignID=$CampaignID");
  exit;
}




####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function load_assignments($CampaignID)
{
  global $Includes, $Excludes, $Exclusives;

  $Includes = array();
  $Excludes = array();
  $Exclusives = array();

  if($result = mysql_query("select SectionID, Type from CampaignAssignments where CampaignID=$CampaignID"))
  {
    while(list($s, $t) = mysql_fetch_row($result))
    {
      if($t == 'Include') $Includes[$s] = " CHECKED";
      if($t == 'Exclude') $Excludes[$s] = " CHECKED";
      if($t == 'Exclusive') $Exclusives[$s] = " CHECKED";
    }
  }
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function build_section_tree($root, $depth)
{
  global $Includes, $Excludes, $Exclusives;
  global $bgcolor;

  if(!$root) $root = 0;

  #### create a spacer
  for($i = 0; $i < $depth * 5; $i++) { $spacer .= "&nbsp;"; }

  if($result = mysql_query("select SectionID, Name from Sections where PSectionID = $root and Active='Y' order by Name"))
  {
    while(list($s_id, $s_name) = mysql_fetch_row($result))
    {
      $bgcolor = ($bgcolor == '#ffffff') ? '#cccccc' : '#ffffff';

      print <<<__TEXT__
<TR BACKGROUND='' BGCOLOR="$bgcolor">
<TD>$spacer$s_name</TD>
<TD><INPUT TYPE=checkbox NAME="Includes[]" VALUE="$s_id"$Includes[$s_id]></TD>
<TD><INPUT TYPE=checkbox NAME="Excludes[]" VALUE="$s_id"$Excludes[$s_id]></TD>
<TD><INPUT TYPE=checkbox NAME="Exclusives[]" VALUE="$s_id"$Exclusives[$s_id]></TD>
</TR>
__TEXT__;

      build_section_tree($s_id, $depth + 1);
    }
  }
}




?>
