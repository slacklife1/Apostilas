<?php

#require ("lib-i18n.us.us.inc");
#header ("Content-Type: text/html; charset=utf-8");

#require ("lib-i18n.fr.fr.inc");
#header ("Content-Type: text/html; charset=utf-8");

require ("lib-i18n.ru.ru.utf8.inc");
header ("Content-Type: text/html; charset=utf-8");

#require ("lib-i18n.ru.ru.windows-1251.inc");
#header ("Content-Type: text/html; charset=windows-1251");

#require ("lib-i18n.ru.ru.koi8-r.inc");
#header ("Content-Type: text/html; charset=koi8-r");


print "<TABLE>\n";
while (list ($native, $trans) = each ($OASISmsg)) {
	print "<TR><TD VALIGN=top>$native</TD><TD VALIGN=top>$trans</TD></TR>\n";
}
print "</TABLE>\n";

?>
