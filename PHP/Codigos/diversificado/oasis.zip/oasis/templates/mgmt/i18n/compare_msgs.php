#!/usr/local/bin/php -q
<?php

$file1 = $argv[1];
$file2 = $argv[2];

require $file1;
foreach (array_keys($OASISmsg) as $msg)
{
  $orig_message_list[$msg] = 1;
}

require $file2;
foreach (array_keys($OASISmsg) as $msg)
{
  if (!$orig_message_list[$msg]) print "Not found in $file1: $msg\n";
  $orig_message_list[$msg] = 0;
}

foreach (array_keys($orig_message_list) as $msg)
{
  if ($orig_message_list[$msg] == 1) print "Not found in $file2: $msg\n";
}

?>
