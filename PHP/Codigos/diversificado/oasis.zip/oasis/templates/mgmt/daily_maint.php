#!/usr/local/bin/php -q
<?php
####---------------------------------------------------------------------------
####  daily_maint.php
####
####  Performs the daily maintenance on the database and shared memory.
####  Loads creative content and clickthroughs for the day into shared memory.
####
####  Note:  this must be run from hourly_maint.php, which maintains a
####         semaphore to protect the shared memory space (so that the delivery
####         engine or other instances of the maintenance scripts can't
####         read or write shared memory while we're working)
####---------------------------------------------------------------------------

set_time_limit(0);

mysql_connect("[db_host]", "[db_user]", "[db_passwd]");
mysql_select_db("oasis");

require("lib-oasis.inc");
require("lib-maint.inc");
require("lib-dengine.inc");

if($argv[1] == 'manual') $manual_reload = 1;

$now = time();

if(!$manual_reload) check_for_underdelivery();

compute_daily_targets('', '');
load_creative_content('');


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function check_for_underdelivery()
{
  $msg = '';

  if(!($result = mysql_query("select Target, Remaining, Creatives.CreativeID, Creatives.Name, Campaigns.Name from DailyTargets left join Creatives on DailyTargets.CreativeID=Creatives.CreativeID left join Campaigns on Creatives.CampaignID=Campaigns.CampaignID")))
    die("Error querying DailyTargets: " . mysql_error() . "\n");

  while(list($target, $rem, $cr_id, $cr_name, $ca_name) = mysql_fetch_row($result))
  {
    if($target > 0 && $rem > 0)
    {
      $msg .= "$ca_name/$cr_name: $target scheduled, $rem undelivered\n";
__TEXT__;

    }
  }
  $admin_email = get_prefs('AdminEmail');
  if($msg) mail($admin_email, "Underdelivery Report", $msg);
}


?>
