#!/usr/local/bin/php -q
<?php
####---------------------------------------------------------------------------
####  hourly_maint.php
####
####  This script is designed to be run at the top of the hour.  It reloads
####  the hourly target tables and loads shared memory with various lookup
####  tables for the delivery engine.
####
####  If called during the 0 hour, it will also call the daily maintenance
####  script.
####
####  If called with the argument "reload", this script assumes it is
####  being called by an admin.  It will not process log files, and it
####  _will_ call the daily maintenance script.
####
####  Since the changes to shared memory must be done safely, there can be
####  a delay introduced in the delivery engine while this script holds on
####  to a semaphore and loads shared memory.
####---------------------------------------------------------------------------

set_time_limit(0);

mysql_connect("[db_host]", "[db_user]", "[db_passwd]");
mysql_select_db("oasis");

require("lib-oasis.inc");
require("lib-maint.inc");
require("lib-dengine.inc");
require("lib-report.inc");
require("lib-logs.inc");
require_once("lib-i18n.inc");

$runtimeopts = array(
                'stop'        => array('record_last' =>1,   'rename_logs'  =>1,
                                       'process_logs'=>1,   'simulate'     =>0,
				       'clear_shm'   =>1,   'reload_hourly'=>0,
				       'call_daily'  =>0,   'force_daily'  =>0),
                'resume'      => array('record_last' =>0,   'rename_logs'  =>0,
                                       'process_logs'=>0,   'simulate'     =>0,
				       'clear_shm'   =>0,   'reload_hourly'=>1,
				       'call_daily'  =>0,   'force_daily'  =>0),
                'start'       => array('record_last' =>0,   'rename_logs'  =>0,
                                       'process_logs'=>0,   'simulate'     =>0,
				       'clear_shm'   =>0,   'reload_hourly'=>1,
				       'call_daily'  =>1,   'force_daily'  =>1),
                'reload'      => array('record_last' =>1,   'rename_logs'  =>1,
                                       'process_logs'=>1,   'simulate'     =>0,
				       'clear_shm'   =>1,   'reload_hourly'=>1,
				       'call_daily'  =>0,   'force_daily'  =>0),
                'force_daily' => array('record_last' =>1,   'rename_logs'  =>0,
                                       'process_logs'=>0,   'simulate'     =>0,
				       'clear_shm'   =>1,   'reload_hourly'=>1,
				       'call_daily'  =>1,   'force_daily'  =>1),
                'default'     => array('record_last' =>1,   'rename_logs'  =>1,
                                       'process_logs'=>1,   'simulate'     =>1,
				       'clear_shm'   =>1,   'reload_hourly'=>1,
				       'call_daily'  =>1,   'force_daily'  =>0)
		);

if(!($rtopt = $argv[1])) $rtopt = 'default';
$action = $runtimeopts[$rtopt];

admin_log("runtime options: $rtopt");

$now = time();
$hour = date('G', $now);
read_traffic_profile();

$log_dir = get_prefs('LogDir');

if($hour == 0 && $action[rename_logs])
{
  #### don't subtract a full date, since at DST, you'll get the day
  #### _before_ yesterday!  Just subtract half a day.
  $log_date = date('Y/m-d', $now - 43200);

  if(!@rename("$log_dir/oasis_admin.log", "$log_dir/$log_date-admin.log"))
    warn("Could not rename $log_dir/oasis_admin.log to $log_dir/$log_date-admin.log: $php_errormsg\n");

  if(!@rename("$log_dir/oasis_sim.log", "$log_dir/$log_date-sim.log"))
    warn("Could not rename $log_dir/oasis_sim.log to $log_dir/$log_date-sim.log: $php_errormsg\n");
}


#### grab a semaphore; we don't want to enter these shared memory
#### segments when the delivery script might be running
#### identifier:           O A 0 0
if(!(($sem_id = sem_get(0x4f410000, 1)) && sem_acquire($sem_id))) return 0;

$sem_start_time = time();

$active_creatives = array();
if($action[record_last]) record_last_hour($hour);

#### call the daily script if this is the zero hour
#### DISTFIX: if we are going to have distributed servers, we'll need
#### to make sure that only one of the servers runs the daily script (and
#### only after all servers have recorded their last hour data)
if(($hour == 0 && $action[call_daily]) || $action[force_daily])
{
  admin_log("calling daily maintenance script...");
  $start_time = time();

  if($action[force_daily]) `./daily_maint.php manual`;
  else `./daily_maint.php`;
}

if($action[reload_hourly])
{
  $wiped_clean = array();

  admin_log("building assignment table...");
  build_assignment_table(0, $hour);

  admin_log("computing next hour's targets...");
  compute_hourly_targets($hour, '');
}

if($action[clear_shm]) clear_shared_memory();

#### now populate the shared memory, if we've got something
if($action[reload_hourly]) load_shared_memory();

if($action[rename_logs])
{
  #### it's possible that the log file does not exist, so check before
  #### attempting to move the file.
  if(file_exists("$log_dir/oasis.log"))
  {
    $year = date('Y', $now - 3600);
    $mon  = date('m', $now - 3600);
    $day  = date('d', $now - 3600);
    $hour = date('H', $now - 3600);

    #### DISTFIX: if we've got multiple servers that are sharing log
    #### filespace, we'll need to use a unique server ID in this filename

    @mkdir("$log_dir/$year", 0755);

    admin_log("moving log file to $log_dir/$year/$mon-$day-$hour.log...");
    if(!@rename("$log_dir/oasis.log", "$log_dir/$year/$mon-$day-$hour.log"))
    {
      warn("Could not rename $log_dir/oasis.log to $log_dir/$year/$mon-$day-$hour.log: $php_errormsg\n");
    }
  }
}
sem_release($sem_id);

$sem_elapsed_time = time() - $sem_start_time;
admin_log("semaphore held for $sem_elapsed_time seconds");

#### do things that don't require semaphore
if($action[process_logs])
{
  if(file_exists("$log_dir/$year/$mon-$day-$hour.log"))
  {
    process_log("$log_dir/$year/$mon-$day-$hour.log",
              "$log_dir/$year/$mon-$day.log");
  }

  if($hour == 0)
  {
    housekeeping();

    #### mail reports
    #### DISTFIX: we only want to do this if we're the "main" server,
    #### and only after all other servers have processed their logs...
    if(date('w', $now) == 0) mail_reports();
  }
}

if($hour == 0 && $action[simulate])
{
  admin_log("checking inventory...");
  `nice -10 ./check_inventory.php`;
  admin_log("done.");
}

update_campaigns();
mark_complete();



####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function housekeeping()
{
  $log_dir = get_prefs('LogDir');

  $cutoff = get_prefs('KeepLogsFor');
  $log_date = date('Y/md', time() - $cutoff * 86400);

  if (file_exists ("$log_dir/$log_date.log.gz")) {
    unlink("$log_dir/$log_date.log.gz");
  }
  if (file_exists ("$log_dir/$log_date-admin.log")) {
    unlink("$log_dir/$log_date-admin.log");
  }

  $cutoff = get_prefs('KeepStatsFor');
  $stats_date = date('Y-m-d', time() - $cutoff * 86400);
  mysql_query("delete from HourlyStats where Day<'$stats_date'");
  mysql_query("delete from CampaignDailyStats where Day<'$stats_date'");
  mysql_query("delete from SectionDailyTraffic where Day<'$stats_date'");
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function mail_reports()
{
  global $active_creatives, $OASISdatefmt;

  $style = join("", file("oasis.css"));

  #### end is yesterday
  $end = time() - 86400;
  #### start a week before
  $start = $end - 6 * 86400;

  $do = ($OASISdatefmt == 'dmy') ? 'd/m/Y' : 'm/d/Y';
  $StartDate = date('Y-m-d', $start);
  $EndDate   = date('Y-m-d', $end);

  $StartDate_n = date($do, $start);
  $EndDate_n   = date($do, $end);

  $cr = join(",", $active_creatives);
  if(!$result = mysql_query("select Creatives.CampaignID, Notify from Creatives left join Campaigns on Creatives.CampaignID=Campaigns.CampaignID where CreativeID in ($cr)"))
    warn("Error querying creatives: " . mysql_error() . "\n");

  while(list($CampaignID, $email) = mysql_fetch_row($result))
    $active_campaigns[$CampaignID] = $email;

  $from_addr = get_prefs('ReportFromAddr');
  while(list($ca_id, $email) = each($active_campaigns))
  {
    if(!$email) continue;

    admin_log("sending report for Campaign $ca_id to $email...");

    $report = campaign_report($ca_id, $StartDate, $EndDate);

    $report = <<<__TEXT__
<HTML>
<HEAD><TITLE>Campaign Summary, $StartDate_n to $EndDate_n</TITLE></HEAD>
$style
<BODY>
$report
</BODY>
</HTML>
__TEXT__;

    mail($email, "Campaign Summary, $StartDate_n to $EndDate_n", $report,
         "From: $from_addr\nMIME-Version: 1.0\nContent-Type: text/html; charset=us-ascii\n");
  }

}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function clear_shared_memory()
{
  #### we need to do this periodically to avoid filling shared memory;
  #### since segment OAS 0 is keyed by SectionID (OAS0), over time
  #### it will fill up with unused sections' info.
  
  #### Note that this could be dangerous -- when we were clearing segment
  #### OAS1, we would sometimes get this error:
  ####       shmget() failed for key 0x4f415301: File exists
  #### because of this, we are no longer clearing OAS1; instead, after
  #### recording the previous hour's info for each creative, we
  #### call shm_remove_var().  After looping through all creatives running
  #### during the last hour, we have in effect cleared OAS1.

  admin_log("clearing shared memory...");

  #### if we're running for the first time, there won't be anything in here;
  #### thus we don't call clear_shared_memory() upon startup

  #### php version 4.0.7 changed the shm_remove() semantics
  if(get_php_version() >= 40007)
  {
    if(!@shm_remove(shm_attach(0x4f415300,
                        get_prefs('ShmSizeHourlyAssignments'))))
      abort("Error clearing shared memory segment OAS0 ($php_errormsg)");
  }
  else
  {
    if(!@shm_remove(0x4f415300))
      abort("Error clearing shared memory segment OAS0 ($php_errormsg)");
  }
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function load_shared_memory()
{
  global $assignments, $hourly_targets;

  admin_log("loading shared memory...");

  #### attach to a shared memory segment
  #### identifier:           O A S 0
  if(!(@$smh = shm_attach(0x4f415300, get_prefs('ShmSizeHourlyAssignments'))))
  {
    warn("Could not attach to shared memory segment OAS0 ($php_errormsg) Hourly Assignments and Hourly Targets not loaded.");
    return 0;
  }

  $assignment_count = 0;
  if($assignments)
  {
    while(list($s, $s_as) = each ($assignments))
    {
      $sec_assignments = array();
      while(list($dim, $sd_as) = each ($s_as))
      {
        $sec_dim_assignments = array();
        while(list($c, $v) = each ($sd_as))
        {
          if(!$v) continue;

	  $assignment_count++;
          array_push($sec_dim_assignments, $c);
          #print "assigning creative $c ($dim) to section $s...\n";
        }
        $sec_assignments[$dim] = $sec_dim_assignments;
      }

      if(!@shm_put_var($smh, $s, $sec_assignments))
        warn("Could not insert section $s assignments into shared memory ($php_errormsg)");
    }
  }
  if(!@shm_detach($smh))
    warn("Error detaching from shared memory segment OAS0 ($php_errormsg)");

  print "$assignment_count assignments made\n";

  #### attach to a shared memory segment
  #### identifier:           O A S 1
  if(!(@$smh = shm_attach(0x4f415301, get_prefs('ShmSizeHourlyTargets'))))
  {
    warn("Could not attach to shared memory segment OAS1 ($php_errormsg) Hourly targets not loaded.");
    return 0;
  }

  if($hourly_targets)
  {
    $hour = date('G', time());
    while(list($k, $v) = each($hourly_targets))
    {
      if(!@shm_put_var($smh, $k, $v))
        warn("Could not insert hourly targets into shared memory ($php_errormsg)");
       mysql_query("insert into RunningCreatives values ($k, $hour)");
    }
  }

  if(!@shm_detach($smh))
    warn("Error detaching from shared memory segment OAS1 ($php_errormsg)\n");
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function record_last_hour($hour)
{
  global $active_creatives;
  global $shm_delivered, $shm_snapshot;

  admin_log("recording last hour's deliveries...");

  $lasthour = ($hour == 0) ? 23 : $hour - 1;

  #### DISTFIX: Lock the daily target table if we're going to have
  #### distributed servers

  #### look in the OAS1 shared memory segment to determine how many of
  #### each creative was delivered (subtract target from remaining)

  #### attach to a shared memory segment
  #### identifier:           O A S 1
  if(!(@$smh = shm_attach(0x4f415301, get_prefs('ShmSizeHourlyTargets'))))
    abort("Error connecting to shared memory segment OAS1 ($php_errormsg)\n");

  #### go through all daily targets; look at what has been delivered
  if($result = mysql_query("select CreativeID from RunningCreatives"))
  {
    #### build an array of the number of impressions delivered, hashed on
    #### the creative ids
    $shm_delivered = array();
    while(list($cr_id) = mysql_fetch_row($result))
    {
      @$target_info = shm_get_var($smh, $cr_id);
      $shm_snapshot[$cr_id] = $target_info;

      $shm_delivered[$cr_id] = array($target_info[0] - $target_info[2],
	                           $target_info[3]);
      array_push($active_creatives, $cr_id);
    }

    #### go through the hash, and update the database
    while(list($cr_id, $v) = each ($shm_delivered))
    {
      list($i, $c) = $v;
      if(!$i) $i = 0;
      if(!$c) $c = 0;

      #print "creative $cr_id: $i impressions, $c clicks\n";

      if(!mysql_query("update DailyTargets set Remaining=Remaining-$i where CreativeID=$cr_id"))
        warn("Error updating DailyTargets for creative $cr_id (" . mysql_error() . ")");

      #### update Creatives table
      $sql = "update Creatives set ImpressionsDelivered=ImpressionsDelivered + $i, ClicksDelivered=ClicksDelivered + $c where CreativeID=$cr_id";
      if(!mysql_query($sql))
        abort("Error updating Creatives for creative $cr_id: "
	        . mysql_error() . "($sql)\n");

      #### since we've recorded the information, clear the shared memory
      if(!@shm_remove_var($smh, $cr_id))
        warn("Error clearing creative $cr_id's target info ($php_errormsg)");
    }
  }
  else
    abort("Error querying RunningCreatives: " . mysql_error() . "\n");

  if(!@shm_detach($smh))
    abort("Error detaching from shared memory segment OAS1 ($php_errormsg)");

  mysql_query("delete from RunningCreatives");

  admin_log("hourly deliveries recorded");
}



####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function update_campaigns()
{
  if(!($result1 = mysql_query("select CampaignID from Campaigns where Status='Active'")))
  {
    warn("Error querying Campaigns: " . mysql_error() . "\n");
    return;
  }

  while(list($ca_id) = mysql_fetch_row($result1))
  {
    if(!($result2 = mysql_query("select CreativeID, ImpressionsDelivered, ClicksDelivered from Creatives where CampaignID=$ca_id")))
    {
      warn("Error querying Creatives: " . mysql_error() . "\n");
      return;
    }

    $tot_imp = 0;
    $tot_click = 0;
    while(list($cr_id, $imp, $click) = mysql_fetch_row($result2))
    {
      $tot_imp += $imp;
      $tot_click += $click;
    }
    mysql_query("update Campaigns set ImpressionsDelivered='$tot_imp', ClicksDelivered='$tot_click' where CampaignID=$ca_id");
  }
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function mark_complete()
{
  if($result = mysql_query("select CreativeID from Creatives where Status='Active' and ((ImpressionsGuaranteed > 0 and ImpressionsDelivered >= ImpressionsGuaranteed) or (EndDate > '0000-00-00' and unix_timestamp(EndDate) <= unix_timestamp(now()) - 86400))"))
  {
    while(list($cr_id) = mysql_fetch_row($result))
    {
      mysql_query("update Creatives set Status='Completed' where CreativeID=$cr_id");
      admin_log("Marked creative $cr_id complete");
    }
  }

  if($result = mysql_query("select CampaignID from Campaigns where Status='Active' and ((ImpressionsGuaranteed > 0 and ImpressionsDelivered >= ImpressionsGuaranteed) or (EndDate > '0000-00-00' and unix_timestamp(EndDate) <= unix_timestamp(now()) - 86400))"))
  {
    while(list($ca_id) = mysql_fetch_row($result))
    {
      mysql_query("update Campaigns set Status='Completed' where CampaignID=$ca_id");
      admin_log("Marked campaign $ca_id complete");
      mail_summary_report($ca_id);
    }
  }
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function mail_summary_report($ca_id)
{
  global $OASISdatefmt;

  $style = join("", file("oasis.css"));

  if($result = mysql_query("select Notify, UNIX_TIMESTAMP(EndDate), UNIX_TIMESTAMP(StartDate) from Campaigns where CampaignID=$ca_id"))
  {
    list($email, $end, $start) = mysql_fetch_row($result);

    $do = ($OASISdatefmt == 'dmy') ? 'd/m/Y' : 'm/d/Y';
    $StartDate = date('Y-m-d', $start);
    $EndDate   = date('Y-m-d', $end);
    $StartDate_n = date($do, $start);
    $EndDate_n   = date($do, $end);

    $from_addr = get_prefs('ReportFromAddr');
    if(!$email) return;

    admin_log("sending report for Campaign $ca_id to $email...");

    $report = campaign_report($ca_id, $StartDate, $EndDate, true);

    $report = <<<__TEXT__
<HTML>
<HEAD><TITLE>Campaign Summary, $StartDate_n to $EndDate_n</TITLE></HEAD>
$style
<BODY>
$report
</BODY>
</HTML>
__TEXT__;

    mail($email, "Campaign Final Summary, $StartDate_n to $EndDate_n", $report,
         "From: $from_addr\nMIME-Version: 1.0\nContent-Type: text/html; charset=us-ascii\n");
  }
}


?>
