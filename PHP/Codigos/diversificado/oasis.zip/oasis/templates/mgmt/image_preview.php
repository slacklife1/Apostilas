<?php

require("lib-oasis.inc");

mysql_connect("[db_host]", "[db_user]", "[db_passwd]");
mysql_select_db("oasis");

#### this roughly mimics the process used internally by PHP to find the
#### temporary directory on non-Win32 systems.
$tmpdir = ini_get('upload_tmp_dir');
if ("$tmpdir" == '') $tmpdir = getenv("TMPDIR");
if ("$tmpdir" == '') $tmpdir = "/tmp";

$fullpath = "$tmpdir/$file";
$fullpath = preg_replace ('#\.\.+#', '', $fullpath);
list($w, $h, $mimetype) = identify_image($fullpath);

header("Content-type: $mimetype");

readfile($fullpath);

?>
