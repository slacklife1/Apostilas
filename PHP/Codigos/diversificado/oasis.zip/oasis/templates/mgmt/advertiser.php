<?php

require("lib-mgmt.inc");

if($reallydelete) really_delete_advertiser($AdvertiserID);

print_html_header($OASISmsg['Advertiser_Management']);
print_header('Advertisers', '', '');

$values = array();
if($AdvertiserID)
{
  if($delete) delete_advertiser($AdvertiserID);
  if($save) save_advertiser($AdvertiserID);

  $values = get_table_row('Advertisers', 'AdvertiserID', $AdvertiserID);
  $values[Name]   = htmlspecialchars($values[Name]);
}
elseif($new_advertiser)
{
  if($save)
  {
    $AdvertiserID = save_advertiser('');
    $values = get_table_row('Advertisers', 'AdvertiserID', $AdvertiserID);
    $new_advertiser = '';
  }
}
else
{
  list_advertisers($orderby, $ascdesc);
}

?>

<?php if ($AdvertiserID || $new_advertiser): ?>

<FORM METHOD=POST ACTION="advertiser.php">
<TABLE WIDTH=615 CELLPADDING=0 CELLSPACING=1 BORDER=0>
<INPUT TYPE=hidden NAME=AdvertiserID VALUE="<?php echo $values['AdvertiserID']; ?>">
<?php if ($new_advertiser): ?>
<INPUT TYPE=hidden NAME=new_advertiser VALUE="1">
<?php endif; ?>
<TR>
<TD COLSPAN=2>
<FONT SIZE="+1"><STRONG><?php echo $OASISmsg['Advertiser_Details']; ?></STRONG></FONT><BR>
</TD>
</TR>
<TR>
<TD><?php echo $OASISmsg['Name']; ?></TD>
<TD><INPUT NAME="Name" SIZE=32 MAXLENGTH=128 VALUE="<?php echo $values['Name']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg['URL']; ?></TD>
<TD><INPUT NAME="URL" SIZE=32 MAXLENGTH=255 VALUE="<?php echo $values['URL']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg['Contact']; ?></TD>
<TD><INPUT NAME="ContactName" SIZE=32 MAXLENGTH=128 VALUE="<?php echo $values['ContactName']; ?>"></TD>
</TR>
<TR>
<TD VALIGN=top><?php echo $OASISmsg['Street_Address']; ?></TD>
<TD>
<TEXTAREA NAME="StreetAddress" WRAP=virtual ROWS=2 COLS=40><?php echo $values['StreetAddress']; ?></TEXTAREA>
</TD>
</TR>
<TR>
<TD><?php echo $OASISmsg['City']; ?></TD>
<TD><INPUT NAME="City" SIZE=32 MAXLENGTH=64 VALUE="<?php echo $values['City']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg['State']; ?></TD>
<TD><INPUT NAME="State" SIZE=16 MAXLENGTH=64 VALUE="<?php echo $values['State']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg['Postal_Code']; ?></TD>
<TD><INPUT NAME="PostalCode" SIZE=16 MAXLENGTH=64 VALUE="<?php echo $values['PostalCode']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg['Country']; ?></TD>
<TD><INPUT NAME="Country" SIZE=16 MAXLENGTH=64 VALUE="<?php echo $values['Country']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg['Phone']; ?></TD>
<TD><INPUT NAME="Phone" SIZE=14 MAXLENGTH=64 VALUE="<?php echo $values['Phone']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg['Fax']; ?></TD>
<TD><INPUT NAME="Fax" SIZE=14 MAXLENGTH=64 VALUE="<?php echo $values['Fax']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg['Contact_Email']; ?></TD>
<TD><INPUT NAME="ContactEmail" SIZE=32 MAXLENGTH=255 VALUE="<?php echo $values['ContactEmail']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg['Login']; ?></TD>
<TD><INPUT NAME="Login" SIZE=32 MAXLENGTH=255 VALUE="<?php echo $values['Login']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg['Password']; ?></TD>
<TD><INPUT NAME="Password" SIZE=32 MAXLENGTH=255 VALUE="<?php echo $values['Password']; ?>"></TD>
</TR>
<TR>
<TD VALIGN=top><?php echo $OASISmsg['Note']; ?></TD>
<TD>
<TEXTAREA NAME="Note" ROWS=2 COLS=40 WRAP=virtual><?php echo $values['Note']; ?></TEXTAREA>
</TD>
</TR>

<TR>
<TD COLSPAN=2>
<P>
<INPUT TYPE=submit NAME=save VALUE="<?php echo $OASISmsg['Save']; ?>">
<INPUT TYPE=submit NAME=delete VALUE="<?php echo $OASISmsg['Delete']; ?>">
<P>
</TD>
</TR>

</TABLE>
</FORM>

<?php endif; ?>


<?php

print_footer();

####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function delete_advertiser($AdvertiserID)
{
  global $OASISmsg;

  if($result = mysql_query("select CampaignID, Name from Campaigns where AdvertiserID=$AdvertiserID and Status='Active'"))
  {
    $campaign_list = '';
    while(list($ca_id, $ca_name) = mysql_fetch_row($result))
    {
      $campaign_list .= <<<__TEXT__
<LI><A HREF="campaign.php?CampaignID=$ca_id">$ca_name</A>
__TEXT__;
    }

    if($campaign_list)
    {
      print <<<__TEXT__
<TABLE WIDTH=615><TR><TD>
$OASISmsg[cannot_delete];
<UL>
$campaign_list
</UL>
$OASISmsg[deactivate_msg];
</TD></TR></TABLE>
__TEXT__;

      print_footer();
      exit;
    }
  }


  print <<<__TEXT__
<TABLE WIDTH=615><TR><TD>
$OASISmsg[confirm_delete_advertiser]
Are you sure you want to delete this advertiser?  This will delete
all campaigns and creatives associated with this advertiser!
If you are sure, click
<A HREF="advertiser.php?reallydelete=1&AdvertiserID=$AdvertiserID">$OASISmsg[here]</A>.
$OASISmsg[Otherwise_click]
<A HREF="advertiser.php?AdvertiserID=$AdvertiserID">$OASISmsg[here]</A>
$OASISmsg[to_return_to_advertiser]
</TD></TR></TABLE>
__TEXT__;

  print_footer();
  exit;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function really_delete_advertiser($AdvertiserID)
{
  global $OASISmsg;

  #### get all the campaigns for this advertiser
  if(!($result1 = mysql_query("select CampaignID from Campaigns where AdvertiserID=$AdvertiserID")))
  {
    print "<EM>$OASISmsg[error_del_campaign]:<BR>\n"
          . mysql_error() . " .</EM><BR>\n";
    exit;
  }

  while(list($ca_id) = mysql_fetch_row($result1))
  {
    #### get all the creatives for this campaign
    if(!($result2 = mysql_query("select CreativeID from Creatives where CampaignID=$ca_id")))
    {
      print "<EM>$OASISmsg[error_del_campaign]<BR>\n"
          . mysql_error() . " .</EM><BR>\n";
      exit;
    }

    while(list($cr_id) = mysql_fetch_row($result2))
    {
      mysql_query("delete from CreativeAssignments where CreativeID=$cr_id");
    }
  
    #### clean up campaign, creatives, and campaign assignments
    mysql_query("delete from Campaigns where CampaignID=$ca_id");
    mysql_query("delete from Creatives where CampaignID=$ca_id");
    mysql_query("delete from CampaignAssignments where CampaignID=$ca_id");
  }

  mysql_query("delete from Advertisers where AdvertiserID=$AdvertiserID");

  header("Location: advertiser.php");
  exit;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function save_advertiser($AdvertiserID)
{
  global $Name, $URL, $ContactName, $StreetAddress, $City, $State, $PostalCode;
  global $Country, $Phone, $Fax, $ContactEmail, $Note;
  global $Login, $Password;

  global $OASISmsg;

  #$Name          = addslashes($Name);
  #$ContactName   = addslashes($ContactName);
  #$StreetAddress = addslashes($StreetAddress);
  #$City          = addslashes($City);
  #$State         = addslashes($State);
  #$Country       = addslashes($Country);
  #$ContactEmail  = addslashes($ContactEmail);
  #$Note          = addslashes($Note);

  if($AdvertiserID)
  {
    $sql = "update Advertisers set Name='$Name', URL='$URL', ContactName='$ContactName', StreetAddress='$StreetAddress', City='$City', State='$State', PostalCode='$PostalCode', Country='$Country', Phone='$Phone', Fax='$Fax', ContactEmail='$ContactEmail', Note='$Note', Login='$Login', Password='$Password' where AdvertiserID=$AdvertiserID";
  }
  else
  {
    $sql = "insert into Advertisers (Name, URL, ContactName, StreetAddress, City, State, PostalCode, Country, Phone, Fax, ContactEmail, Note, Login, Password) values ('$Name', '$URL', '$ContactName', '$StreetAddress', '$City', '$State', '$PostalCode', '$Country', '$Phone', '$Fax', '$ContactEmail', '$Note', '$Login', '$Password')";
  }

  if(mysql_query($sql))
  {
    print "<EM>$OASISmsg[Advertiser_info_saved]</EM><BR>\n";

    #### if we're putting a new record into the table, grab the AdvertiserID
    if(!$AdvertiserID  && $result = mysql_query("select LAST_INSERT_ID()"))
      list($AdvertiserID) = mysql_fetch_row($result);
  }
  else
  {
    print "<EM>$OASISmsg[error_save_advertiser]:<BR>\n"
          . mysql_error() . " .<BR>$sql</EM><BR>\n";
  }

  return $AdvertiserID;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function list_advertisers($orderby, $ascdesc)
{
  global $OASISmsg, $REQUEST_URI, $SERVER_NAME, $SERVER_PROTOCOL, $SERVER_PORT;

  if(!$ascdesc) $ascdesc = 'asc';
  if(!$orderby) $orderby = 'Name';

  $sql = "select AdvertiserID, Name, City, State from Advertisers order by $orderby $ascdesc";
  #print "$sql<BR>\n";

  #### toggle asc/desc, and set up the graphic
  if($ascdesc == 'asc')
  {
    $sortg[$orderby]
      = ' <IMG SRC="graphics/down.gif" WIDTH=12 HEIGHT=12 BORDER=0>';
    $ascdesc = 'desc';
  }
  else
  {
    $sortg[$orderby]
      = ' <IMG SRC="graphics/up.gif" WIDTH=12 HEIGHT=12 BORDER=0>';
    $ascdesc = 'asc';
  }

  if($result = mysql_query($sql))
  {
    print <<<__TEXT__
<TABLE WIDTH=615 CELLSPACING=0 CELLPADDING=0 BORDER=1>
<TR>
<TD CLASS=tablehead>
<A HREF="advertiser.php?orderby=Name&ascdesc=$ascdesc"
CLASS=tablehead>$OASISmsg[Name]{$sortg['Name']}</A>
</TD>
<TD CLASS=tablehead>
<A HREF="advertiser.php?orderby=City&ascdesc=$ascdesc"
CLASS=tablehead>$OASISmsg[City]{$sortg['City']}</A>
</TD>
<TD CLASS=tablehead>
<A HREF="advertiser.php?orderby=State&ascdesc=$ascdesc"
CLASS=tablehead>$OASISmsg[State]{$sortg['State']}</A>
</TD>
</TR>
__TEXT__;

    $bgcolor = '#cccccc';
    while(list($a_id, $name, $city, $state) = mysql_fetch_row($result))
    {
      $bgcolor = ($bgcolor == '#ffffff') ? '#cccccc' : '#ffffff';

      print <<<__TEXT__
<TR BACKGROUND='' BGCOLOR=$bgcolor>
<TD><A HREF="advertiser.php?AdvertiserID=$a_id">$name</A></TD>
<TD>$city</TD>
<TD>$state</TD>
</TR>
__TEXT__;
    }

    preg_match('#([^/]+)#', $SERVER_PROTOCOL, $matches);
    $prot = strtolower($matches[1]);
    if ($prot == 'http' && $SERVER_PORT != 80)   $port = ":$SERVER_PORT";
    if ($prot == 'https' && $SERVER_PORT != 443) $port = ":$SERVER_PORT";

    $rep_url = preg_replace('#[^/]+$#', 'advreport.php', $REQUEST_URI);
    $rep_url = "$prot://$SERVER_NAME$port$rep_url";

    print <<<__TEXT__
</TABLE>
<A HREF="advertiser.php?new_advertiser=1">$OASISmsg[Add_Advertiser]</A>
<P>
$OASISmsg[Adv_report_URL]: <A HREF="advreport.php">$rep_url</A>
__TEXT__;
  }
  else
  {
    print "$OASISmsg[MySQL_error]: " . mysql_error() . "<BR>\n";
  }
}



?>
