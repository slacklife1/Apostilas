#!/bin/sh

perl -pi -e 's%<TD CLASS=tablehead%<TD BGCOLOR="#000066"%g' $1
perl -pi -e 's%<SPAN CLASS=tablehead>(.+?)</SPAN>%<FONT COLOR="#ffffff"><B>$1</B></FONT>%g' $1
perl -pi -e 's%<SPAN CLASS=smalldata>(.+?)</SPAN>%<FONT SIZE="-1">$1</FONT>%g' $1
perl -pi -e 's%<SPAN CLASS=smalldata>%<FONT SIZE="-1">%g' $1
perl -pi -e 's%</SPAN>%</FONT>%g' $1
