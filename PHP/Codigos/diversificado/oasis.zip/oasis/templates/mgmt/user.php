<?php

require("lib-mgmt.inc");

if($reallydelete) really_delete_user($Login);

if($save_campaign_access)
{
  save_campaign_access();
  exit;
}

print_html_header($OASISmsg[User_Management]);
print_header('Admin', '', '');

$values = array();
if($edit_campaign_access)
{
  build_campaign_access_form($Login);
  print_footer();
  exit;
}
elseif($Login)
{
  if($delete) delete_user($Login);
  if($save) save_user($Login);

  $values = get_table_row_s('Users', 'Login', $Login);
}
elseif($new_user)
{
  if($save)
  {
    $Login = save_user('');
    $values = get_table_row_s('Users', 'Login', $Login);
  }
}
else
{
  list_users($orderby, $ascdesc);
}
build_form_values($values);

?>

<?php if ($Login || $new_user): ?>

<FORM METHOD=POST>
<TABLE WIDTH=615 CELLPADDING=0 CELLSPACING=1 BORDER=0>
<TR>
<TD COLSPAN=2>
<FONT SIZE="+1"><STRONG><?php echo $OASISmsg[User_Details]; ?></STRONG></FONT><BR>
</TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Login]; ?></TD>
<?php if($Login): ?>
<TD>
<INPUT TYPE=hidden NAME="Login" VALUE="<?php echo $values['Login']; ?>">
<?php echo $values['Login']; ?>
</TD>
<?php else: ?>
<TD><INPUT NAME="Login" SIZE=32 MAXLENGTH=32 VALUE="<?php echo $values['Login']; ?>"></TD>
<?php endif; ?>
</TR>
<TR>
<TD><?php echo $OASISmsg[Password]; ?></TD>
<TD><INPUT TYPE=password NAME="Password" SIZE=16 MAXLENGTH=32 VALUE="<?php echo $values['Password']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[First_Name]; ?></TD>
<TD><INPUT NAME="FirstName" SIZE=32 MAXLENGTH=64 VALUE="<?php echo $values['FirstName']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Last_Name]; ?></TD>
<TD><INPUT NAME="LastName" SIZE=32 MAXLENGTH=64 VALUE="<?php echo $values['LastName']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Email_Address]; ?></TD>
<TD><INPUT NAME="EmailAddress" SIZE=32 MAXLENGTH=64 VALUE="<?php echo $values['EmailAddress']; ?>"></TD>
</TR>
<TR>
<TD VALIGN=top><?php echo $OASISmsg[Permissions]; ?></TD>
<TD><?php echo $p_select; ?></TD>
</TR>

<TR>
<TD COLSPAN=2>
<P>
<INPUT TYPE=submit NAME=save VALUE="<?php echo $OASISmsg[Save]; ?>">

<?php if(!$new_user): ?>
<INPUT TYPE=submit NAME=delete VALUE="<?php echo $OASISmsg[Delete]; ?>">
<P>
<A HREF="user.php?edit_campaign_access=1&Login=<?php echo $Login; ?>"><?php echo $OASISmsg[Edit_Limited_Campaign_Access]; ?></A>
<?php endif; ?>
</TD>
</TR>

</TABLE>
</FORM>

<?php endif; ?>


<?php

print_footer();

####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function build_campaign_access_form($login)
{
  global $OASISmsg;

  $campaign_access = array(0);
  if($result = mysql_query("select CampaignID from CampaignAccess where Login='$login'"))
  {
    while(list($ca_id) = mysql_fetch_row($result))
      $campaign_access[$ca_id] = 1;
  }

  print <<<__TEXT__
<FORM METHOD=POST ACTION="user.php">
<INPUT TYPE=hidden NAME=Login VALUE="$login">
$OASISmsg[User]: $login
<P>
<TABLE CELLSPACING=0 CELLPADDING=0 BORDER=0>
__TEXT__;

  if($result = mysql_query("select Name, CampaignID from Campaigns where Status='Active' order by Name"))
  {
    while(list($ca_name, $ca_id) = mysql_fetch_row($result))
    { 
      $checked = ($campaign_access[$ca_id]) ? " CHECKED" : "";

      print <<<__TEXT__
<TR><TD>
<INPUT TYPE=checkbox NAME="ca_$ca_id"$checked>
<A HREF="campaign.php?CampaignID=$ca_id">$ca_name</A>
</TD></TR>

__TEXT__;
    }
  }

  print <<<__TEXT__
</TABLE>
<P>
<INPUT TYPE=submit NAME="save_campaign_access" VALUE="$OASISmsg[Save]">
</FORM>

__TEXT__;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function save_campaign_access()
{
  global $HTTP_POST_VARS;

  $sql = "delete from CampaignAccess where Login='$HTTP_POST_VARS[Login]'";
  #print "$sql<BR>\n";
  mysql_query($sql);

  while(list($k, $v) = each($HTTP_POST_VARS))
  {
    if(preg_match("#ca_(\d+)#", $k, $matches))
    {
      $ca_id = $matches[1];
      $sql = "insert into CampaignAccess values ($ca_id, '$HTTP_POST_VARS[Login]')";
      #print "$sql<BR>\n";
      mysql_query($sql);
    }
  }

  header("Location: user.php?Login=$HTTP_POST_VARS[Login]");
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function build_form_values($values)
{
  global $p_select;
  global $OASISmsg;

  $selected = array();
  if($values[Admin] == 'Y') $selected[Admin] = 1;
  if($values[Advertisers] == 'Y') $selected[Advertisers] = 1;
  if($values[Campaigns] == 'Y') $selected[Campaigns] = 1;
  if($values[CampaignInsertion] == 'Y') $selected[CampaignInsertion] = 1;
  if($values[Invoicing] == 'Y') $selected[Invoicing] = 1;
  if($values[LimitedCampaigns] == 'Y') $selected[LimitedCampaigns] = 1;
  if($values[Reports] == 'Y') $selected[Reports] = 1;
  if($values[Sections] == 'Y') $selected[Sections] = 1;

  $p_select = build_select(array(
                                 'Admin'       => $OASISmsg[Admin],
                                 'Advertisers' => $OASISmsg[Advertisers],
                                 'Campaigns'   => $OASISmsg[Campaigns],
                                 'CampaignInsertion' => $OASISmsg[Campaign_Insertion],
                                 'LimitedCampaigns' => $OASISmsg[Limited_Campaigns],
                                 'Invoicing'   => $OASISmsg[Invoicing],
                                 'Reports'     => $OASISmsg[Reports],
                                 'Sections'    => $OASISmsg[Sections],
                                 ),
				 'permissions[]',
                                 $selected, 8, 1);
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function delete_user($Login)
{
  global $OASISmsg;

  print <<<__TEXT__
<TABLE WIDTH=615><TR><TD>
$OASISmsg[confirm_delete_user_1]
<A HREF="user.php?reallydelete=1&Login=$Login">$OASISmsg[here]</A>.
$OASISmsg[confirm_delete_user_2]
<A HREF="user.php?Login=$Login">$OASISmsg[here]</A>
$OASISmsg[confirm_delete_user_3]
</TD></TR></TABLE>
__TEXT__;

  print_footer();
  exit;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function really_delete_user($Login)
{
  global $OASISmsg;

  if(!mysql_query("delete from Users where Login='$Login'"))
  {
    print "$OASISmsg[Error_deleting_user] $Login: " . mysql_error();
  }
  else
  {
    header("Location: user.php");
    exit;
  }
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function save_user($Login)
{
  global $Password, $FirstName, $LastName, $EmailAddress, $permissions;
  global $OASISmsg;

  $admin = 'N';
  $advertisers = 'N';
  $campaigns = 'N';
  $campaigninsertion = 'N';
  $invoicing = 'N';
  $limitedcampaigns = 'N';
  $reports = 'N';
  $sections = 'N';
  if ($permissions)
  {
    foreach($permissions as $p)
    {
      if($p == 'Admin')             $admin = 'Y';
      if($p == 'Advertisers')       $advertisers = 'Y';
      if($p == 'Campaigns')         $campaigns = 'Y';
      if($p == 'CampaignInsertion') $campaigninsertion = 'Y';
      if($p == 'Invoicing')         $invoicing = 'Y';
      if($p == 'LimitedCampaigns')  $limitedcampaigns = 'Y';
      if($p == 'Reports')           $reports = 'Y';
      if($p == 'Sections')          $sections = 'Y';
    }
  }

  $v = get_table_row_s('Users', 'Login', $Login);
  $p = ($v[Password] != $Password) ? "password('$Password')" : "'$Password'";

  $sql = "replace into Users (Login, Password, LastName, FirstName, EmailAddress, Admin, Advertisers, Campaigns, CampaignInsertion, Invoicing, LimitedCampaigns, Reports, Sections) values ('$Login', $p, '$LastName', '$FirstName', '$EmailAddress', '$admin', '$advertisers', '$campaigns', '$campaigninsertion', '$invoicing', '$limitedcampaigns', '$reports', '$sections')";

  if(mysql_query($sql))
  {
    print "<EM>$OASISmsg[User_info_saved]</EM><BR>\n";
    list_users($orderby, $ascdesc);
    print_footer();
    exit;
  }
  else
  {
    print "<EM>$OASISmsg[Error_saving_user]:<BR>\n"
          . mysql_error() . " .<BR>$sql</EM><BR>\n";
  }

  return $Login;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function list_users($orderby, $ascdesc)
{
  global $OASISmsg;

  if(!$ascdesc) $ascdesc = 'asc';
  if(!$orderby) $orderby = 'Login';

  $sql = "select Login, LastName, FirstName, EmailAddress from Users order by $orderby $ascdesc";
  #print "$sql<BR>\n";

  #### toggle asc/desc, and set up the graphic
  if($ascdesc == 'asc')
  {
    $sortg[$orderby]
      = ' <IMG SRC="graphics/down.gif" WIDTH=12 HEIGHT=12 BORDER=0>';
    $ascdesc = 'desc';
  }
  else
  {
    $sortg[$orderby]
      = ' <IMG SRC="graphics/up.gif" WIDTH=12 HEIGHT=12 BORDER=0>';
    $ascdesc = 'asc';
  }

  if($result = mysql_query($sql))
  {
    print <<<__TEXT__
<TABLE WIDTH=615 CELLSPACING=0 CELLPADDING=0 BORDER=1>
<TR>
<TD CLASS=tablehead>
<A HREF="user.php?orderby=Login&ascdesc=$ascdesc" CLASS=tablehead>$OASISmsg[Login]{$sortg['Login']}</A>
</TD>
<TD CLASS=tablehead>
<A HREF="user.php?orderby=LastName&ascdesc=$ascdesc" CLASS=tablehead>$OASISmsg[Last_Name]{$sortg['LastName']}</A>
</TD>
<TD CLASS=tablehead>
<A HREF="user.php?orderby=FirstName&ascdesc=$ascdesc" CLASS=tablehead>$OASISmsg[First_Name]{$sortg['FirstName']}</A>
</TD>
<TD CLASS=tablehead>
<A HREF="user.php?orderby=EmailAddress&ascdesc=$ascdesc" CLASS=tablehead>$OASISmsg[Email_Address]{$sortg['EmailAddress']}</A>
</TD>
</TR>
__TEXT__;

    $bgcolor = '#cccccc';
    while(list($l, $ln, $fn, $ea) = mysql_fetch_row($result))
    {
      $bgcolor = ($bgcolor == '#ffffff') ? '#cccccc' : '#ffffff';

      print <<<__TEXT__
<TR BACKGROUND='' BGCOLOR=$bgcolor>
<TD><A HREF="user.php?Login=$l">$l</A></TD>
<TD>$ln</TD>
<TD>$fn</TD>
<TD>$ea</TD>
</TR>
__TEXT__;
    }

    print <<<__TEXT__
</TABLE>
<A HREF="user.php?new_user=1">$OASISmsg[Add_User]</A>
__TEXT__;
  }
  else
  {
    print "$OASISmsg[MySQL_error]: " . mysql_error() . "<BR>\n";
  }
}



?>
