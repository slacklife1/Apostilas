<?php

if(!mysql_pconnect("[db_host]", "[db_user]", "[db_passwd]"))
{
  header("HTTP/1.0 500 OASIS Error - could not connect to server");
  exit;
}
if(!mysql_select_db("oasis"))
{
  header("HTTP/1.0 500 OASIS Error - could not open DB");
  exit;
}

deliver_creative($CreativeID);



####---------------------------------------------------------------------------
#### spit out the content or redirect to another site
####---------------------------------------------------------------------------
function deliver_creative($creative_id)
{
  #### attach to a shared memory segment
  #### identifier:     O A S 2
  $smh = shm_attach(0x4f415302, 0); 

  @$creative_info = shm_get_var($smh, $creative_id);

  shm_detach($smh);
  $result = mysql_query("select Content, Redirect, MIMEType, Animated, MediaType from Creatives where CreativeID=$creative_id");

  list($content, $redirect, $mime_type, $animated, $mtype)
    = mysql_fetch_row($result);

  if($mtype == 'Image')
  {
    if($redirect == 'Y')
    {
      mt_srand((double)microtime()*1000000);
      $random_number = mt_rand();
      $content = preg_replace("#\[CB\]#", $random_number, $content);
      header("Location: $content");
    }
    else
    {
      header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); 

      #### set some headers to control caching; note that due to browser
      #### wackiness, we can't set these for animated GIFs
      if($animated == 'N')
      {
        header("Expires: Sat, 13 Jun 1992 00:00:00 GMT");
        header("Cache-Control: no-cache, must-revalidate");
        header("Pragma: no-cache");
      }

      print header("Content-type: $mime_type");
      print $content;
    }
  }
  elseif($mtype == 'RichMedia')
  {
    $content = preg_replace ('#\[OASISCLICK:(.+?)\]#', '$1', $content);
    print $content;
  }
}


?>
