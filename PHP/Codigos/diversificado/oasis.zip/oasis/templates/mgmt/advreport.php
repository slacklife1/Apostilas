<?php

require("lib-http.inc");
require("lib-html.inc");
require("lib-db.inc");
require("lib-report.inc");
set_time_limit(0);

$current_advertiser = '';
check_privileges();

print_html_header ($OASISmsg[Reports]);
?>

<BODY BGCOLOR="#ffffff" TEXT="#000000" LINK="#0000ff" VLINK="#330066" ALINK="#ff0000">

<DIV ALIGN=center>
<TABLE WIDTH=620 CELLPADDING=0 CELLSPACING=0 BORDER=0>
<TR>
<TD WIDTH=1 BGCOLOR="#000000"><IMG SRC="graphics/1x1.gif"></TD>
<TD WIDTH=618 VALIGN=top BACKGROUND="graphics/background.gif"><TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0
WIDTH="100%">
<TR>
<TD VALIGN=bottom COLSPAN=8><A HREF="http://oasis.sourceforge.net/"><IMG
SRC="graphics/header.gif" BORDER=0 ALT="OASIS" WIDTH=618 HEIGHT=61></A></TD>
</TR>



<?php

if($report_type)
{
  if($StartDate_Year && $StartDate_Month && $StartDate_Day)
    $StartDate = "$StartDate_Year-$StartDate_Month-$StartDate_Day";
  else
  {
    print "<TR><TD>$OASISmsg[error_select_start]</TD></TR>";
    print_footer();
    exit;
  }
  if($EndDate_Year && $EndDate_Month && $EndDate_Day)
    $EndDate = "$EndDate_Year-$EndDate_Month-$EndDate_Day";
  else
  {
    print "<TR><TD>$OASISmsg[error_select_end]</TD></TR>";
    print_footer();
    exit;
  }

  if($report_type == 'campaign')
  {
    #### FIXME!!! Check to see if the campaign ID matches one of the
    #### current advertiser's campaigns.
    if($CampaignID == '')
    {
      print "<TR><TD>$OASISmsg[error_specify_campaign]</TD></TR>";
      print_footer();
      exit;
    }
    $sql = "SELECT AdvertiserID FROM Campaigns WHERE CampaignID=$CampaignID";
    if (!($result = mysql_query($sql))) {
      print "<TR><TD>$OASISmsg[MySQL_error]: " . mysql_error() . "</TR></TD>\n";
      print_footer();
      exit;
    }
    list($advid) = mysql_fetch_row($result);

    if ($current_advertiser != $advid) {
      print "<TR><TD>$OASISmsg[error_inadequate_privileges]</TD></TR>";
      print_footer();
      exit;
    }

    print campaign_report($CampaignID, $StartDate, $EndDate);
  }
}
else
{
  build_form_elements();

  print <<<__TEXT__

<TABLE WIDTH=615><TR><TD>
<FONT SIZE="+1"><STRONG>Reports</STRONG></FONT><BR>
<P>

$date_mgmt_script

<FORM METHOD=POST ACTION=advreport.php NAME=form1>
<TABLE>
<TR>
<INPUT TYPE=hidden NAME=report_type VALUE=campaign>
<TD>$OASISmsg[Campaign]</TD>
<TD>$campaign_dropdown</TD>
</TR>
<TR>
<TD></TD>
<TD>$OASISmsg[Start_Date]</TD>
<TD>$startdate_widget</TD>
</TR>
<TR>
<TD></TD>
<TD>$OASISmsg[End_Date]</TD>
<TD>$enddate_widget</TD>
</TR>
<TR>
<TD></TD>
<TD COLSPAN=2>
$date_mgmt_buttons
</TD>
</TR>
<TR>
<TD><BR>&nbsp;</TD>
</TR>
<TR>
<TD COLSPAN=3>
<INPUT TYPE=submit VALUE="$OASISmsg[Build_Report]">
</TD>
</TR>
</TABLE>
</FORM>
</TD></TR></TABLE>
__TEXT__;

}
?>

<?php

print_footer();

####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function check_privileges()
{
  global $PHP_AUTH_USER, $PHP_AUTH_PW, $SCRIPT_FILENAME;
  global $current_advertiser;
  global $OASISmsg;

  if(!isset($PHP_AUTH_USER)) reject_http_connection();

  $user_info = get_table_row_s('Advertisers', 'Login', $PHP_AUTH_USER);

  if($PHP_AUTH_PW != $user_info[Password]) reject_http_connection();

  $current_advertiser = $user_info[AdvertiserID];

  if(!$current_advertiser) reject_http_connection();
}



####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function build_form_elements()
{
  global $campaign_dropdown;
  global $startdate_widget, $enddate_widget;
  global $OASISmsg;
  global $current_advertiser;

  if($result = mysql_query("select CampaignID, Name from Campaigns where (Status='Active' or Status='Suspended' or (Status='Completed' and EndDate > date_sub(now(), INTERVAL 30 DAY))) and AdvertiserID=$current_advertiser order by Name"))
  {
    $a = array();
    while(list($id, $name) = mysql_fetch_row($result)) $a[$id] = $name;
    $campaign_dropdown = build_select($a, 'CampaignID', '', '', '');
    $jscript = 'onChange="document.form1.report_type[2].checked = 1;"';
    $campaign_dropdown = preg_replace('#(<SELECT.+?)>#', "\\1$jscript>", $campaign_dropdown);
  }
  else print "$OASISmsg[MySQL_error]: " . mysql_error() . "<BR>\n";

  $now = time();
  if(date('d', $now) < 7)
  {
    $lm = $now - 14 * 86400;
    $sd = date('Y-m-d', mktime(0, 0, 0, date('m', $lm), 1, date('Y', $lm)));
    $ed = date('Y-m-d', mktime(0, 0, 0, date('m', $now), 0, date('Y', $now)));
  }
  else
  {
    $nm = $now + 28 * 86400;
    $sd = date('Y-m-d', mktime(0, 0, 0, date('m', $now), 1, date('Y', $now)));
    $ed = date('Y-m-d', mktime(0, 0, 0, date('m', $nm), 0, date('Y', $nm)));
  }

  $startdate_widget = build_date_widget('StartDate', $sd, 1);
  $enddate_widget   = build_date_widget('EndDate', $ed, 1);
}

?>
