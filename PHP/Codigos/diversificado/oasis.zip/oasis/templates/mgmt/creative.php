<?php

require("lib-mgmt.inc");
require("lib-dengine.inc");
require("lib-maint.inc");

$limited = 0;
$campaignscript = "campaign.php";
$creativescript = "creative.php";
if(preg_match('#ltd#', $SCRIPT_FILENAME, $matches))
{
  $limited = 1;
  $campaignscript = "ltdcampaign.php";
  $creativescript = "ltdcreative.php";

  $campaign_access = array(0);
  if($result = mysql_query("select CampaignID from CampaignAccess where Login='$PHP_AUTH_USER'"))
  {
    while(list($ca_id) = mysql_fetch_row($result))
      $campaign_access[$ca_id] = 1;
  }
  if($CampaignID && !$campaign_access[$CampaignID])
  {
    $error = "$OASISmsg[cannot_run_on_campaign]!\n";
  }
}

if($reallydelete) really_delete_creative($CreativeID);
if($copy) copy_creative($CreativeID);

print_html_header ($OASISmsg[Campaign_Management]);
?>

<SCRIPT LANGUAGE="JavaScript">
<!--
function new_win(target, width, height)
{
  var wc;
  width += 20;
  height += 20;
  wc = "status=1,scrollbars=0,resizable=1,width=" + width + ",height=" + height;
  var win = window.open(target, "", wc);
  if (win.history.length >= 1)
  {
    var del = -win.history.length;
    win.history.go(del);
  }
}
// -->
</SCRIPT>


<BODY BGCOLOR="#ffffff" TEXT="#000000" LINK="#0000ff" VLINK="#330066" ALINK="#ff0000">

<DIV ALIGN=center>

<?php

#### get the campaign ID so we can print an appropriate header
if(!$CampaignID)
{
  $values = get_table_row('Creatives', 'CreativeID', $CreativeID);
  $CampaignID = $values[CampaignID];
}
print_header('Campaigns', $CampaignID, '');

if($error)
{
  print $error;
  print_footer();
  exit;
}


$values = array();
if($CreativeID)
{
  if($upload)
  {
    $display_upload_form = 1;
  }
  elseif($richedit)
  {
    $values = get_table_row('Creatives', 'CreativeID', $CreativeID);
    $display_richedit_form = 1;
  }
  else
  {
    if($delete) delete_creative($CreativeID);
    if($imagefile) save_image();
    if($richmedia) save_rich_media();
    if($save) save_creative($CreativeID);

    $values = get_table_row('Creatives', 'CreativeID', $CreativeID);
    $display_edit_form = 1;
  }
}
else
{
  if($save)
  {
    $CreativeID = save_creative('');
    $values = get_table_row('Creatives', 'CreativeID', $CreativeID);
    $display_edit_form = 1;
  }
  else
  {
    $display_new_form = 1;
  }
}
build_form_elements($values);
$values[Name]   = htmlspecialchars($values[Name]);
$values[ImpressionsGuaranteed]
  = number_format($values[ImpressionsGuaranteed], 0, $OASISdecpt, $OASIStsep);

?>

<?php if ($display_upload_form): ?>

<FORM ENCTYPE="multipart/form-data" METHOD=POST ACTION="creative.php">
<INPUT TYPE="hidden" name="MAX_FILE_SIZE" value="50000">
<INPUT TYPE=hidden NAME=CreativeID VALUE="<?php echo $CreativeID; ?>">
<INPUT TYPE=hidden NAME=CampaignID VALUE="<?php echo $CampaignID; ?>">
<TABLE WIDTH=615>
<TR>
<TD COLSPAN=2>
<FONT SIZE="+1"><STRONG><?php echo $OASISmsg[Upload_Image]; ?></STRONG></FONT><BR>
</TD>
</TR>
<TR>
<TD>
<?php echo $OASISmsg[Send_this_file]; ?>: <INPUT NAME="imagefile" TYPE="file">
<BR>
<INPUT TYPE="submit" VALUE="<?php echo $OASISmsg[Send_File]; ?>">
</TD>
</TR>
</TABLE>
</FORM>

<?php endif; ?>


<?php if ($display_richedit_form): ?>

<FORM METHOD=POST ACTION="creative.php">
<INPUT TYPE=hidden NAME=CreativeID VALUE="<?php echo $CreativeID; ?>">
<INPUT TYPE=hidden NAME=CampaignID VALUE="<?php echo $CampaignID; ?>">
<TABLE WIDTH=615>
<TR>
<TD COLSPAN=2>
<FONT SIZE="+1"><STRONG><?php echo $OASISmsg[Edit_rich_media]; ?></STRONG></FONT><BR>
</TD>
</TR>
<TR><TD><?php echo $OASISmsg[Width]; ?></TD><TD><INPUT SIZE=4 NAME="w" VALUE="<?php echo $values[Width]; ?>"></TD></TR>
<TR><TD><?php echo $OASISmsg[Height]; ?></TD><TD><INPUT SIZE=4 NAME="h" VALUE="<?php echo $values[Height]; ?>"></TD></TR>
<TR><TD COLSPAN=2>
<TEXTAREA NAME="richmedia" ROWS=10 COLS=50>
<?php if($values[MediaType] == 'RichMedia') echo $values[Content]; ?>
</TEXTAREA>
<BR>
<INPUT TYPE="submit" VALUE="<?php echo $OASISmsg[Save]; ?>">
</TD>
</TR>
</TABLE>
</FORM>

<?php endif; ?>



<?php if ($display_new_form): ?>
<FORM METHOD=POST>
<INPUT TYPE=hidden NAME=CampaignID VALUE="<?php echo $CampaignID; ?>">
<TABLE WIDTH=615>
<TR>
<TD COLSPAN=2>
<FONT SIZE="+1"><STRONG><?php echo $OASISmsg[Creative_Details]; ?></STRONG></FONT><BR>
</TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Name]; ?></TD>
<TD COLSPAN=3><INPUT NAME="Name" SIZE=20 MAXLENGTH=64></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Click_URL]; ?></TD>
<TD COLSPAN=3><INPUT NAME="ClickthroughURL" SIZE=40 MAXLENGTH=255></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Third_Party]; ?></TD>
<TD COLSPAN=3><INPUT NAME="ThirdParty" SIZE=40 MAXLENGTH=255></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Alt_Text]; ?></TD>
<TD COLSPAN=3><INPUT NAME="AltText" SIZE=40 MAXLENGTH=255></TD>
</TR>
<TR>
<TD COLSPAN=2>
<INPUT TYPE=submit NAME=save VALUE="<?php echo $OASISmsg[Save]; ?>">
</TD>
</TR>
</TABLE>

</FORM>

<?php endif; ?>



<?php if ($display_edit_form): ?>

<FORM METHOD=POST>
<INPUT TYPE=hidden NAME=CreativeID VALUE="<?php echo $CreativeID; ?>">
<INPUT TYPE=hidden NAME=CampaignID VALUE="<?php echo $CampaignID; ?>">
<INPUT TYPE=hidden NAME=MediaType VALUE="<?php echo $values[MediaType]; ?>">
<TABLE WIDTH=615>
<TR>
<TD COLSPAN=4>
<FONT SIZE="+1"><STRONG><?php echo $OASISmsg[Creative_Details]; ?></STRONG></FONT><BR>
</TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Name]; ?></TD>
<TD COLSPAN=3><INPUT NAME="Name" SIZE=20 MAXLENGTH=64 VALUE="<?php echo $values['Name']; ?>"></TD>
<TD ALIGN=right><?php echo $OASISmsg[Status]; ?></TD>
<TD><?php echo $status_dropdown ?></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Dimensions]; ?></TD>
<TD COLSPAN=3>
<INPUT NAME="Width" SIZE=4 VALUE="<?php echo $values['Width']; ?>">
x
<INPUT NAME="Height" SIZE=4 VALUE="<?php echo $values['Height']; ?>">
</TD>
<TD ALIGN=right><?php echo $OASISmsg[MIME_Type]; ?></TD>
<TD COLSPAN=3><INPUT NAME="MIMEType" SIZE=8 MAXLENGTH=64 VALUE="<?php echo $values['MIMEType']; ?>"></TD>
</TR>
<TR>
<TR>
<TD><?php echo $OASISmsg[Click_URL]; ?></TD>
<TD COLSPAN=5><INPUT NAME="ClickthroughURL" SIZE=40 MAXLENGTH=255 VALUE="<?php echo $values['ClickthroughURL']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Weight]; ?></TD>
<TD COLSPAN=5><INPUT NAME="Weight" SIZE=8 MAXLENGTH=10 VALUE="<?php echo $values['Weight']; ?>"></TD>
</TR>

<TR>
<TD><?php echo $OASISmsg[Impressions]; ?></TD>
<TD COLSPAN=3><INPUT NAME="ImpressionsGuaranteed" SIZE=8 MAXLENGTH=10 VALUE="<?php echo $values['ImpressionsGuaranteed']; ?>"></TD>
</TR>

<?php if ($CreativeID): ?>
<TR>
<TD VALIGN=top><?php echo $OASISmsg[Content]; ?></TD>
<TD COLSPAN=5>

<?php if($values['Content']): ?>

<?php if($values['MediaType'] == 'Image'): ?>
<A HREF="<?php echo $values['ClickthroughURL']; ?>"><IMG SRC="creative_preview.php?CreativeID=<?php echo $values['CreativeID'] . "&cachebust=$rn"; ?>" WIDTH="<?php echo $values['Width']; ?>" HEIGHT="<?php echo $values['Height']; ?>" BORDER=0></A><BR>

<?php if ($values['Redirect'] == 'N'): ?>
<DIV ALIGN=right><EM>
<?php if ($values['Animated'] == 'Y'): ?>
(<?php echo $OASISmsg[animated]; ?>)
<?php else: ?>
(<?php echo $OASISmsg[not_animated]; ?>)
<?php endif; ?>
</EM></DIV>
<?php endif; ?>

<?php endif; ?>

<?php if($values['MediaType'] == 'RichMedia'): ?>
<A HREF="javascript:new_win('creative_preview.php?CreativeID=<?php echo "$values[CreativeID]', $values[Width], $values[Height])"; ?>"><?php echo $OASISmsg[Preview_rich_media]; ?></A>
<?php endif; ?>


<?php endif; ?>

<BR>
<A HREF="creative.php?upload=1&CreativeID=<?php echo $CreativeID; ?>"><?php echo $OASISmsg[Upload_new_image]; ?></A> &middot;
<A HREF="creative.php?richedit=1&CreativeID=<?php echo $CreativeID; ?>"><?php echo $OASISmsg[Edit_Rich_Media]; ?></A>

</TD>
</TR>
<?php endif; ?>

<TR>
<TD><?php echo $OASISmsg[Third_Party]; ?></TD>
<TD COLSPAN=5><INPUT NAME="ThirdParty" SIZE=40 MAXLENGTH=255 VALUE="<?php if($values['Redirect'] == 'Y') echo $values['Content']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Alt_Text]; ?></TD>
<TD COLSPAN=5><INPUT NAME="AltText" SIZE=40 MAXLENGTH=255 VALUE="<?php echo $values['AltText']; ?>"></TD>
</TR>
<TR>
<TD VALIGN=top><?php echo $OASISmsg[Start_Date]; ?></TD>
<TD COLSPAN=3 VALIGN=top><?php echo $startdate_widget ?></TD>
<TD ROWSPAN=2 COLSPAN=2 VALIGN=top><FONT SIZE="-2">
<?php echo $dow_select; echo $hod_select ?>
</FONT></TD>
</TR>
<TR>
<TD VALIGN=top><?php echo $OASISmsg[End_Date]; ?></TD>
<TD COLSPAN=3 VALIGN=top><?php echo $enddate_widget ?></TD>
</TR>
<TR>
<TD COLSPAN=4>
<P>
<INPUT TYPE=submit NAME=save VALUE="<?php echo $OASISmsg[Save]; ?>">
<INPUT TYPE=submit NAME=delete VALUE="<?php echo $OASISmsg[Delete]; ?>">
<INPUT TYPE=submit NAME=copy VALUE="<?php echo $OASISmsg[Copy_Creative]; ?>">
<P>
<?php if(!$limited): ?>
<?php echo $section_list; ?>
<A HREF="creativeassignment.php?CreativeID=<?php echo $CreativeID; ?>&new_creativeassignment=1"><?php echo $OASISmsg[Add_Remove_Section_Assignments]; ?></A>
<?php endif; ?>
</TD>
</TR>
</TABLE>

</FORM>

<?php endif; ?>


<?php

print_footer();

####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function build_section_list($CreativeID)
{
  global $OASISmsg;

  if($result = mysql_query("select CreativeAssignments.SectionID, ReportName, Type from CreativeAssignments natural left join Sections where CreativeID=$CreativeID"))
  {
    while(list($s_id, $s_name, $a_type) = mysql_fetch_row($result))
    {
      $s_list .= <<<__TEXT__
<TR>
<TD>$s_name</TD>
<TD>$a_type</TD>
</TR>
__TEXT__;
    }
    if(!$s_list) return '';

    $s_list = <<<__TEXT__
<P><FONT SIZE="+1"><STRONG>$OASISmsg[Section_Assignments]</STRONG></FONT><BR>
<TABLE WIDTH="100%" CELLPADDING=0 CELLSPACING=0 BORDER=1>
<TR>
<TD CLASS=tablehead><SPAN CLASS=tablehead>$OASISmsg[Section]</SPAN></TD>
<TD CLASS=tablehead><SPAN CLASS=tablehead>$OASISmsg[Type]</SPAN></TD>
</TR>
$s_list
</TABLE>
__TEXT__;
  }

  return $s_list;
}



####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function build_form_elements($values)
{
  global $status_dropdown;
  global $startdate_widget, $enddate_widget;
  global $section_list;
  global $dow_select, $hod_select;
  global $rn;
  global $OASISmsg;

  mt_srand((double)microtime()*1000000);
  $rn = mt_rand();

  #### if the creative has been marked complete by the system, we can't edit it.
  if($values['Status'] == 'Completed')
  {
    $status_dropdown = <<<__TEXT__
<INPUT TYPE=hidden NAME="Status" VALUE="Completed">
<EM>$OASISmsg[Completed]</EM>
__TEXT__;
  }
  else
  {
    $status_array = array(
                        'Active'    => $OASISmsg[Active],
                        'Suspended' => $OASISmsg[Suspended],
                        'Cancelled' => $OASISmsg[Cancelled]);

    $status_dropdown = build_select($status_array, 'Status', $values['Status'], '', '');
  }

  $startdate_widget = build_date_widget('StartDate', $values['StartDate'], 0);
  $enddate_widget   = build_date_widget('EndDate', $values['EndDate'], 0);

  $dow_array = array('1' =>  $OASISmsg[Sunday],
                     '2' =>  $OASISmsg[Monday],
                     '4' =>  $OASISmsg[Tuesday],
                     '8' =>  $OASISmsg[Wednesday],
                     '16' => $OASISmsg[Thursday],
                     '32' => $OASISmsg[Friday],
                     '64' => $OASISmsg[Saturday]);

  while(list($k, $v) = each($dow_array))
    if($values[DaysOfWeek] & $k) $dow_sel[$k] = 1;

  $dow_select = build_select($dow_array, 'DaysOfWeek[]', $dow_sel, 7, 1);

  $hod_array = array('1'       => $OASISmsg[a12],
                     '2'       => $OASISmsg[a1],
                     '4'       => $OASISmsg[a2],
                     '8'       => $OASISmsg[a3],
                     '16'      => $OASISmsg[a4],
                     '32'      => $OASISmsg[a5],
                     '64'      => $OASISmsg[a6],
                     '128'     => $OASISmsg[a7],
                     '256'     => $OASISmsg[a8],
                     '512'     => $OASISmsg[a9],
                     '1024'    => $OASISmsg[a10],
                     '2048'    => $OASISmsg[a11],
                     '4096'    => $OASISmsg[p12],
                     '8192'    => $OASISmsg[p1],
                     '16384'   => $OASISmsg[p2],
                     '32768'   => $OASISmsg[p3],
                     '65536'   => $OASISmsg[p4],
                     '131072'  => $OASISmsg[p5],
                     '262144'  => $OASISmsg[p6],
                     '524288'  => $OASISmsg[p7],
                     '1048576' => $OASISmsg[p8],
                     '2097152' => $OASISmsg[p9],
                     '4194304' => $OASISmsg[p10],
                     '8388608' => $OASISmsg[p11]);
  while(list($k, $v) = each($hod_array))
    if($values[HoursOfDay] & $k) $hod_sel[$k] = 1;

  $hod_select = build_select($hod_array, 'HoursOfDay[]', $hod_sel, 7, 1);

  if($values['CreativeID'])
  {
    $section_list  = build_section_list($values['CreativeID']);
  }
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function save_rich_media()
{
  global $CreativeID, $richmedia, $w, $h;
  global $CampaignID;
  global $OASISmsg;

  $sql = "update Creatives set Content='$richmedia', Redirect='N', MIMEType='text/html', MediaType='RichMedia', Width=$w, Height=$h, Animated='N' where CreativeID=$CreativeID";

  if(!mysql_query($sql))
    print "<EM>$OASISmsg[Error_saving_creative]:<BR>\n"
          . mysql_error() . " .</EM><BR>\n";

  reload_daily($CampaignID);
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function save_image()
{
  global $CreativeID, $imagefile, $imagefile_size, $imagefile_type;
  global $CampaignID;
  global $OASISmsg, $OASISdecpt, $OASIStsep;

  $fp = fopen($imagefile, "r");
  $imagecon = addslashes(fread($fp, $imagefile_size));
  fclose($fp);

  list($w, $h, $mime_type, $animated) = identify_image($imagefile);
  if(!$result = mysql_query("select Size from MaxSizes where Width=$w and Height=$h"))
  {
    print "$OASISmsg[error_looking_for_maxsize] $w x $h: " . mysql_error();
    print_footer();
    exit;
  }
  if(list($maxsize) = mysql_fetch_row($result))
  {
    if($imagefile_size > $maxsize)
    {
      $imagefile_size = number_format($imagefile_size, 0, $OASISdecpt, $OASIStsep);
      $maxsize = number_format($maxsize, 0, $OASISdecpt, $OASIStsep);
      print "$OASISmsg[error_size_exceeded] $w x $h ($imagefile_size &gt; $maxsize)<BR>";
      print_footer();
      exit;
    }
  }

  $sql = "update Creatives set Content='$imagecon', Redirect='N', MIMEType='$mime_type', MediaType='Image', Width=$w, Height=$h, Animated='$animated' where CreativeID=$CreativeID";

  if(!mysql_query($sql))
    print "<EM>$OASISmsg[Error_saving_creative]:<BR>\n"
          . mysql_error() . " .</EM><BR>\n";

  reload_daily($CampaignID);
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function copy_creative($CreativeID)
{
  global $OASISmsg;

  if(!($result = mysql_query("select * from Creatives where CreativeID=$CreativeID")))
  {
    print "Error pulling info for creative $CreativeID: " . mysql_error();
    print_footer();
    exit;
  }

  $row = mysql_fetch_array($result, MYSQL_ASSOC);
  $row[CreativeID] = 'NULL';
  $row[Name] = "Copy of $row[Name]";
  $row[ImpressionsDelivered] = 0;
  $row[ClicksDelivered] = 0;
  $row[Status] = 'Inactive';

  $vals = array();
  while(list($k, $v) = each($row))
    array_push($vals, "'" . addslashes($v) . "'");

  $sql = "insert into Creatives values (" . join(",", $vals) . ")";
  if(!mysql_query($sql)
    || !($new_cr_id = mysql_insert_id())
    || !($result = mysql_query("select * from CreativeAssignments where CreativeID=$CreativeID")))
  {
    print "$OASISmsg[Error_copying_creative] $CreativeID: " . mysql_error();
    print_footer();
    exit;
  }

  #### copy all the creative's assignments
  while($row = mysql_fetch_array($result, MYSQL_ASSOC))
  {
    $row[CreativeID] = $new_cr_id;
    $vals = array();
    while(list($k, $v) = each($row))
      array_push($vals, "'" . addslashes($v) . "'");
    $sql = "insert into CreativeAssignments values (" . join(",", $vals) . ")";
    if(!mysql_query($sql))
    {
      print "$OASISmsg[Error_copying_section_assignments] $CreativeID $OASISmsg[to] $new_cr_id: " . mysql_error();
      print_footer();
      exit;
    }
  }

  header("Location: creative.php?CreativeID=$new_cr_id");
  exit;
}



####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function delete_creative($CreativeID)
{
  global $OASISmsg;

  if($result = mysql_query("select Campaigns.Status, Campaigns.CampaignID from Campaigns left join Creatives on Campaigns.CampaignID=Creatives.CampaignID where Creatives.CreativeID=$CreativeID"))
  {
    list($status, $CampaignID) = mysql_fetch_row($result);

    if($status == 'Active')
    {
      print <<<__TEXT__
<TABLE WIDTH=615><TR><TD>
$OASISmsg[delete_active_creative_1]
<A HREF="campaign.php?CampaignID=$CampaignID">$OASISmsg[go_back]</A>
$OASISmsg[delete_active_creative_2]
</TD></TR></TABLE>
__TEXT__;

      print_footer();
      exit;
    }
  }

  print <<<__TEXT__
<TABLE WIDTH=615><TR><TD>
$OASISmsg[confirm_delete_creative_1]
<A HREF="creative.php?reallydelete=1&CreativeID=$CreativeID">$OASISmsg[here]</A>.
$OASISmsg[confirm_delete_creative_2]
<A HREF="creative.php?CreativeID=$CreativeID">$OASISmsg[here]</A>
$OASISmsg[confirm_delete_creative_3]
</TD></TR></TABLE>
__TEXT__;

  print_footer();
  exit;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function really_delete_creative($CreativeID)
{
  #### remove this creative from the DailyTargets table; note that this will
  #### not stop it from running -- it will continue to run until the delivery
  #### engine is reloaded (rebuilding the hourly assignments table)
  mysql_query("lock tables DailyTargets write");
  mysql_query("delete from DailyTargets where CreativeID=$CreativeID");
  mysql_query("unlock tables");

  if($result = mysql_query("select CampaignID from Creatives where CreativeID=$CreativeID"))
    list($CampaignID) = mysql_fetch_row($result);

  if(mysql_query("delete from Creatives where CreativeID=$CreativeID")
     && mysql_query("delete from CreativeAssignments where CreativeID=$CreativeID"))
  {
    header("Location: campaign.php?CampaignID=$CampaignID");
    exit;
  }
  else
  {
    print "<EM>$OASISmsg[Error_deleting_creative]:<BR>\n"
          . mysql_error() . " .</EM><BR>\n";
  }

}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function save_creative($CreativeID)
{
  global $Name, $Status;
  global $StartDate_Month, $StartDate_Day, $StartDate_Year;
  global $EndDate_Month, $EndDate_Day, $EndDate_Year;
  global $Width, $Height, $MediaType, $MIMEType, $ClickthroughURL;
  global $CampaignID;
  global $ThirdParty, $AltText, $Weight, $ImpressionsGuaranteed, 
         $DaysOfWeek, $HoursOfDay;
  global $OASISmsg, $OASIStsep;

  $animated = 'N';
  if($ImpressionsGuaranteed == '') $ImpressionsGuaranteed=0;
  if($Weight == '') $Weight = 10;

  if($DaysOfWeek)
  {
    $dow = 0;
    foreach($DaysOfWeek as $d) $dow += $d;
  }
  else $dow = 127;
  if($HoursOfDay)
  {
    $hod = 0;
    foreach($HoursOfDay as $h) $hod += $h;
  }
  else $hod = 16777215;

  $ImpressionsGuaranteed = preg_replace("#[$OASIStsep]#", '', $ImpressionsGuaranteed);

  validate_creative($CreativeID,
                    "$StartDate_Year$StartDate_Month$StartDate_Day",
                    "$EndDate_Year$EndDate_Month$EndDate_Day",
		    $ImpressionsGuaranteed,
		    $Weight, $CampaignID, $ClickthroughURL);

  #### it seems that PHP has done this for us already...
  #$Name = addslashes($Name);

  if($ThirdParty)
  {
    $imagedata = '';

    #### try to open the URL; read the contents into a file
    if(get_prefs("ValidateThirdParty") == 'Y')
      $imagedata = fetch_url($ThirdParty);

    if($imagedata != '')
    {
      $tempfile = tempnam("/tmp", "OASIS");
      if($fp_w = @fopen($tempfile, "w"))
      {
        fwrite($fp_w, $imagedata);
        fclose($fp_w);

	list($w, $h, $MIMEType, $animated) = identify_image($tempfile);

	#### this is a hack -- sometimes we don't get a valid image
	#### when we try to follow a third-party banner link.  If we
	#### don't have an image 1x1 or greater, assume we didn't
	#### get a real image
	if($w > 0) $Width = $w;
	if($h > 0) $Height = $h;
      }
      else
      {
        print "$OASISmsg[Could_not_open] <A HREF=\"$tempfile\">$tempfile</A>: $php_errormsg";
        print_footer();
        exit;
      }
    }
    else
    {
      if(get_prefs("ValidateThirdParty") == 'Y')
	print <<<__TEXT__
<EM>$OASISmsg[Could_not_open] <A HREF="$ThirdParty">$ThirdParty</A>.</EM>
__TEXT__;
      else
	print <<<__TEXT__
<EM>$OASISmsg[Did_not_retrieve] <A HREF="$ThirdParty">$ThirdParty</A>.</EM>
__TEXT__;

      print <<<__TEXT__
<EM>$OASISmsg[error_no_auto_dimension]</EM><BR>
__TEXT__;
    }

    $MediaType = 'Image';

    if($CreativeID)
    {
      $sql = "update Creatives set Name='$Name', Status='$Status', StartDate='$StartDate_Year-$StartDate_Month-$StartDate_Day', EndDate='$EndDate_Year-$EndDate_Month-$EndDate_Day', MediaType='$MediaType', MIMEType='$MIMEType', Width='$Width', Height='$Height', ClickthroughURL='$ClickthroughURL', Redirect='Y', Content='$ThirdParty', AltText='$AltText', Animated='$animated', Weight='$Weight', ImpressionsGuaranteed=$ImpressionsGuaranteed, DaysOfWeek=$dow, HoursOfDay=$hod where CreativeID=$CreativeID";
    }
    else
    {
      $sql = "insert into Creatives (Name, CampaignID, StartDate, EndDate, MediaType, MIMEType, Width, Height, ClickthroughURL, Redirect, Content, AltText, Animated, Weight, ImpressionsGuaranteed, DaysOfWeek, HoursOfDay) values ('$Name', $CampaignID, '$StartDate_Year-$StartDate_Month-$StartDate_Day', '$EndDate_Year-$EndDate_Month-$EndDate_Day', '$MediaType', '$MIMEType', '$Width', '$Height', '$ClickthroughURL', 'Y', '$ThirdParty', '$AltText', '$animated', '$Weight', $ImpressionsGuaranteed, $dow, $hod)";
    }
  }
  else
  {
    if($CreativeID)
    {
      $sql = "update Creatives set Name='$Name', Status='$Status', StartDate='$StartDate_Year-$StartDate_Month-$StartDate_Day', EndDate='$EndDate_Year-$EndDate_Month-$EndDate_Day', MediaType='$MediaType', MIMEType='$MIMEType', Width='$Width', Height='$Height', ClickthroughURL='$ClickthroughURL', Redirect='N',  AltText='$AltText', Weight='$Weight', ImpressionsGuaranteed=$ImpressionsGuaranteed, DaysOfWeek=$dow, HoursOfDay=$hod where CreativeID=$CreativeID";
    }
    else
    {
      $sql = "insert into Creatives (Name, CampaignID, StartDate, EndDate, MediaType, MIMEType, Width, Height, ClickthroughURL, Redirect, AltText, Weight, ImpressionsGuaranteed, DaysOfWeek, HoursOfDay) values ('$Name', $CampaignID, '$StartDate_Year-$StartDate_Month-$StartDate_Day', '$EndDate_Year-$EndDate_Month-$EndDate_Day', '$MediaType', '$MIMEType', '$Width', '$Height', '$ClickthroughURL', 'N', '$AltText', '$Weight', $ImpressionsGuaranteed, $dow, $hod)";
    }
  }

  if(mysql_query($sql))
  {
    print "<EM>$OASISmsg[Creative_info_saved]</EM><BR>\n";

    #### if we're putting a new record into the table, grab the CreativeID
    if(!$CreativeID  && $result = mysql_query("select LAST_INSERT_ID()"))
        list($CreativeID) = mysql_fetch_row($result);
  }
  else
  {
    print "<EM>$OASISmsg[Error_saving_creative]:<BR>\n"
          . mysql_error() . " .</EM><BR>\n";
  }

  reload_daily($CampaignID);

  return $CreativeID;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function validate_creative($cr_id, $cr_sd, $cr_ed, $cr_impg, $weight, $ca_id, $ct_url)
{
  global $OASISmsg;

  #### grab some parameters from the campaign
  $sql = "select date_format(StartDate, '%Y%m%d'), date_format(EndDate, '%Y%m%d'), ImpressionsGuaranteed from Campaigns where CampaignID=$ca_id";

  if(!$result = mysql_query($sql))
  {
    print "error retrieving campaign parameters: " . mysql_error() . "<BR>$sql<BR>\n";
    print_footer();
    exit;
  }
  list($ca_sd, $ca_ed, $ca_impg) = mysql_fetch_row($result);

  #### find out about other creatives' impression guarantees
  if(!$result = mysql_query("select CreativeID, ImpressionsGuaranteed from Creatives where CampaignID=$ca_id"))
  {
    print "$OASISmsg[error_ret_creative_parm]: " . mysql_error();
    print_footer();
    exit;
  }
  $pickerupper = 0;
  $impgs = array();
  if ($cr_impg == 0) $pickerupper = 1;
  while(list($id, $impg) = mysql_fetch_row($result))
  {
    if ($id == $cr_id) continue;
    if($impg == 0) $pickerupper = 1;
    $impgs[$id] = $impg;
  }

  if($cr_id) $impgs[$cr_id] = $cr_impg;
  while(list(, $impg) = each($impgs)) $impg_tot += $impg;

  $errors = "";
  if($cr_ed > 0 && $cr_sd > $cr_ed)
    $errors .= "<LI>$OASISmsg[start_after_end]";

  if(!$cr_ed && $cr_impg > 0)
    $errors .= "<LI>$OASISmsg[imps_no_end]";

  if($weight == 0)
    $errors .= "<LI>$OASISmsg[no_zero_weights]";

  if($ca_ed > 0 && $cr_ed > $ca_ed)
    $errors .= "<LI>$OASISmsg[creative_end_after_campaign] ($cr_ed &gt; $ca_ed)";

  if($ca_impg && $cr_impg > $ca_impg)
    $errors .= "<LI>$OASISmsg[creative_imp_exceed_campaign] ($cr_impg &gt; $ca_impg)";

  if($ca_impg && $impg_tot && $impg_tot > $ca_impg)
    $errors .= "<LI>$OASISmsg[creative_imps_exceed_campaign] ($impg_tot &gt; $ca_impg)";

  if($ca_impg && $impg_tot && $impg_tot < $ca_impg && !$pickerupper)
    $errors .= "<LI>$OASISmsg[creative_imps_less_than_campaign] ($impg_tot &lt; $ca_impg)";

  if(get_prefs("ValidateClickthrough") == 'Y')
  {
    $content = fetch_url($ct_url);
    if($content == '') $errors .= "<LI>$OASISmsg[Could_not_open] $ct_url";
  }

  if($errors)
  {
    print <<<__TEXT__
<TABLE WIDTH=615><TR><TD>
<H1>$OASISmsg[Error]</H1>
$OASISmsg[error_list]:
<UL>
$errors
</UL>
$OASISmsg[error_list_fix]
</TABLE>
__TEXT__;

    print_footer();
    exit;
  }
}




?>


