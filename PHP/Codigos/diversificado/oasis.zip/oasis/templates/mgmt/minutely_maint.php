#!/usr/local/bin/php -q
<?php
####---------------------------------------------------------------------------
####  hourly_maint.php
####
####  This script is designed to be run at the top of the hour.  It reloads
####  the hourly target tables and loads shared memory with various lookup
####  tables for the delivery engine.
####
####  If called during the 0 hour, it will also call the daily maintenance
####  script.
####
####  If called with the argument "reload", this script assumes it is
####  being called by an admin.  It will not process log files, and it
####  _will_ call the daily maintenance script.
####
####  Since the changes to shared memory must be done safely, there can be
####  a delay introduced in the delivery engine while this script holds on
####  to a semaphore and loads shared memory.
####---------------------------------------------------------------------------

set_time_limit(0);

mysql_connect("[db_host]", "[db_user]", "[db_passwd]");
mysql_select_db("oasis");

require("lib-oasis.inc");

cleanup_delivery_table();


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function cleanup_delivery_table()
{
  $now = time();
  $cutoff = get_prefs("ClickthroughWindow");

  if(!$result = mysql_query("select date_sub(now(), INTERVAL $cutoff SECOND)"))
    die("Could not get current time - $cutoff seconds: " . mysql_error());
    
  list($cutoff_time) = mysql_fetch_row($result);

  $sql = "delete from Delivery where LastSeen < '$cutoff_time'";
  print "$sql\n";
  $start_time = time();
  if(!$result = mysql_query($sql))
    die("Could not clean up table: " . mysql_error());
  $elapsed_time = time() - $start_time;
  print "$elapsed_time seconds\n";
}


?>
