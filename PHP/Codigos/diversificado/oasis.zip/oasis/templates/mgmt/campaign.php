<?php

require("lib-mgmt.inc");

$limited = 0;
$campaignscript = "campaign.php";
$creativescript = "creative.php";
if(preg_match('#ltd#', $SCRIPT_FILENAME, $matches))
{
  $limited = 1;
  $campaignscript = "ltdcampaign.php";
  $creativescript = "ltdcreative.php";

  $campaign_access = array(0);
  if($result = mysql_query("select CampaignID from CampaignAccess where Login='$PHP_AUTH_USER'"))
  {
    while(list($ca_id) = mysql_fetch_row($result))
      $campaign_access[$ca_id] = 1;
  }
  if($CampaignID && !$campaign_access[$CampaignID])
  {
    $error = $OASISmsg[cannot_run_on_campaign];
  }
}

if($reallydelete) really_delete_campaign($CampaignID);
if($copy)   copy_campaign($CampaignID);

print_html_header($OASISmsg['Campaign_Management']);
print_header('Campaigns', '', '');
if($error)
{
  print $error;
  print_footer();
  exit;
}

$values = array();
if($CampaignID)
{
  if($delete) delete_campaign($CampaignID);
  if($save) save_campaign($CampaignID);

  $values = get_table_row('Campaigns', 'CampaignID', $CampaignID);
}
elseif($new_campaign)
{
  if($save)
  {
    $CampaignID = save_campaign('');

    $values = get_table_row('Campaigns', 'CampaignID', $CampaignID);

    $new_campaign = '';
  }
  $values[DaysOfWeek] = 127;
  $values[HoursOfDay] = 16777215;
}
else
{
  $status_filter = array();
  if($show_active)    $status_filter['Active']    = 1;
  if($show_inactive)  $status_filter['Inactive']  = 1;
  if($show_suspended) $status_filter['Suspended'] = 1;
  if($show_cancelled) $status_filter['Cancelled'] = 1;
  if($show_completed) $status_filter['Completed'] = 1;

  list_campaigns($orderby, $ascdesc, $status_filter, $limited);
}
build_form_elements($values);

$values[Name]   = htmlspecialchars($values[Name]);
$values[PurchaseOrder] = htmlspecialchars($values[PurchaseOrder]);
$values[Notify] = htmlspecialchars($values[Notify]);
$values[Note]   = htmlspecialchars($values[Note]);

$values[ImpressionsGuaranteed]
  = number_format($values[ImpressionsGuaranteed], 0, $OASISdecpt, $OASIStsep);
$values[ImpressionsDelivered]
  = number_format($values[ImpressionsDelivered], 0, $OASISdecpt, $OASIStsep);
$values[CPM]   = number_format($values[CPM], $OASIScurrdp, $OASISdecpt, $OASIStsep);
$values[CPC]   = number_format($values[CPC], $OASIScurrdp, $OASISdecpt, $OASIStsep);
$values[Fixed] = number_format($values[Fixed], $OASIScurrdp, $OASISdecpt, $OASIStsep);

$values[ForceInvoice] = ($values[ForceInvoice] == 'Y') ? ' CHECKED' : '';

?>

<?php if ($CampaignID || $new_campaign): ?>

<FORM METHOD=POST ACTION="<?php echo $campaignscript; ?>">
<TABLE WIDTH=615 CELLPADDING=0 CELLSPACING=1 BORDER=0>
<INPUT TYPE=hidden NAME=CampaignID VALUE="<?php echo $values['CampaignID']; ?>">
<?php if ($new_campaign): ?>
<INPUT TYPE=hidden NAME=new_campaign VALUE="1">
<?php endif; ?>
<TR>
<TD COLSPAN=4>
<FONT SIZE="+1"><STRONG><?php echo $OASISmsg[Campaign_Details]; ?></STRONG></FONT><BR>
</TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Name]; ?></TD>
<TD><INPUT NAME="Name" SIZE=20 MAXLENGTH=128 VALUE="<?php echo $values['Name']; ?>"></TD>
<?php if ($CampaignID): ?>
<TD ALIGN=right><?php echo $OASISmsg[Status]; ?></TD>
<TD><?php echo $status_dropdown; ?></TD>
<?php endif; ?>
</TR>
<TR>
<TD><?php echo $OASISmsg[Advertiser]; ?></TD>
<TD COLSPAN=3><?php echo $advertiser_dropdown; ?></TD>
</TR>
<TR>

</TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Start_Date]; ?></TD>
<TD><?php echo $startdate_widget ?></TD>
<TD ROWSPAN=5 COLSPAN=2 VALIGN=top>
<FONT SIZE="-2">
<?php echo $dow_select; echo $hod_select; ?>
</FONT>
</TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[End_Date]; ?></TD>
<TD><?php echo $enddate_widget ?></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Impressions]; ?></TD>
<TD><INPUT NAME="ImpressionsGuaranteed" SIZE=12 VALUE="<?php echo $values['ImpressionsGuaranteed']; ?>">
</TR>
<TR>
<TD><?php echo $OASISmsg[Deliver]; ?></TD>
<TD><?php echo $delivery_dropdown ?></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Weight]; ?></TD>
<TD><INPUT NAME="Weight" SIZE=8 VALUE="<?php echo $values['Weight']; ?>"></TD>
</TR>

<TR><TD COLSPAN=4><HR NOSHADE></TD></TR>

<TR>
<TD><?php echo $OASISmsg[CPM]; ?></TD>
<TD><?php echo $OASISlcurrsym; ?><INPUT NAME="CPM" SIZE=10 VALUE="<?php echo $values['CPM']; ?>"><?php echo $OASIStcurrsym; ?></TD>
<TD><?php echo $OASISmsg[Agency_Commission]; ?></TD>
<TD><INPUT NAME="AgencyCommission" SIZE=4 VALUE="<?php echo $values['AgencyCommission']; ?>"> %</TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[CPC]; ?></TD>
<TD><?php echo $OASISlcurrsym; ?><INPUT NAME="CPC" SIZE=10 VALUE="<?php echo $values['CPC']; ?>"><?php echo $OASIStcurrsym; ?></TD>
<TD><?php echo $OASISmsg[Purchase_Order]; ?></TD>
<TD><INPUT NAME="PurchaseOrder" SIZE=10 MAXLENGTH=64 VALUE="<?php echo $values['PurchaseOrder']; ?>"></TD>
</TR>
<TR>
<TD><?php echo $OASISmsg[Fixed]; ?></TD>
<TD><?php echo $OASISlcurrsym; ?><INPUT NAME="Fixed" SIZE=10 VALUE="<?php echo $values['Fixed']; ?>"><?php echo $OASIStcurrsym; ?>
<?php echo $pay_dropdown; ?>
</TD>
<TD><?php echo $OASISmsg[Force_Invoice]; ?></TD>
<TD><INPUT TYPE=checkbox NAME="ForceInvoice"<?php echo $values['ForceInvoice']; ?>></TD>
</TR>

<TR><TD COLSPAN=4><HR NOSHADE></TD></TR>

<TR>
<TD VALIGN=top><?php echo $OASISmsg[Email_Reports]; ?></TD>
<TD COLSPAN=3>
<TEXTAREA NAME="Notify" ROWS=2 COLS=40 WRAP=virtual><?php echo $values['Notify']; ?></TEXTAREA>
</TD>
</TR>
<TR>
<TD VALIGN=top><?php echo $OASISmsg[Note]; ?></TD>
<TD COLSPAN=3>
<TEXTAREA NAME="Note" ROWS=2 COLS=40 WRAP=virtual><?php echo $values['Note']; ?></TEXTAREA>
</TD>
</TR>

<TR>
<TD COLSPAN=4>
<P>
<INPUT TYPE=submit NAME=save VALUE="<?php echo $OASISmsg[Save]; ?>">

<?php if (!$new_campaign): ?>
<INPUT TYPE=submit NAME=delete VALUE="<?php echo $OASISmsg[Delete]; ?>">
<INPUT TYPE=submit NAME=copy VALUE="<?php echo $OASISmsg[Copy_Campaign]; ?>">

<P>
<?php echo $creative_list; ?>
<A HREF="<?php echo "$creativescript?CampaignID=$CampaignID&new_creative=1"; ?>"><?php echo $OASISmsg[Add_Creative]; ?></A>

<P>
<?php echo $section_list; ?>
<A HREF="campaignassignment.php?CampaignID=<?php echo $CampaignID; ?>&new_campaignassignment=1"><?php echo $OASISmsg[Add_Remove_Section_Assignments]; ?></A>

<?php endif; ?>

</TD>
</TR>

</TABLE>
</FORM>

<?php endif; ?>


<?php

print_footer();

####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function build_section_list($CampaignID)
{
  global $OASISmsg;

  if($result = mysql_query("select CampaignAssignments.SectionID, ReportName, Type from CampaignAssignments natural left join Sections where CampaignID=$CampaignID"))
  {
    while(list($s_id, $s_name, $a_type) = mysql_fetch_row($result))
    {
      $s_list .= <<<__TEXT__
<TR>
<TD>$s_name</TD>
<TD>$a_type</TD>
</TR>
__TEXT__;
    }
    if(!$s_list) return '';

    $s_list = <<<__TEXT__
<P><FONT SIZE="+1"><STRONG>$OASISmsg[Section_Assignments]</STRONG></FONT><BR>
<TABLE WIDTH="100%" CELLPADDING=0 CELLSPACING=0 BORDER=1>
<TR>
<TD CLASS=tablehead><SPAN CLASS=tablehead>$OASISmsg[Section]</SPAN></TD>
<TD CLASS=tablehead><SPAN CLASS=tablehead>$OASISmsg[Type]</SPAN></TD>
</TR>
$s_list
</TABLE>
__TEXT__;
  }

  return $s_list;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function build_creative_list($CampaignID)
{
  global $creativescript, $OASISmsg;

  if($result = mysql_query("select CreativeID, Name, Width, Height, MediaType, ClickthroughURL, Status, Weight from Creatives where CampaignID=$CampaignID"))
  {
    while(list($cr_id, $name, $w, $h, $mtype, $cr_url, $status, $weight) = mysql_fetch_row($result))
    {
      $preview = '';
      if($mtype == 'Image')
      {
	$w2 = ($h) ? floor($w / ($h / 45)) : 0;

        mt_srand((double)microtime()*1000000);
        $rn = mt_rand();

        $h2 = 45;
        $preview = <<<__TEXT__
  <A HREF="$cr_url"><IMG SRC="creative_preview.php?CreativeID=$cr_id&cachebust=$rn" BORDER=0 WIDTH=$w2 HEIGHT=$h2></A>
__TEXT__;
      }
      elseif($mtype == 'RichMedia')
      {
        $preview = $OASISmsg[not_displayed];
      }

      $cr_list .= <<<__TEXT__
<TR>
<TD><A HREF="$creativescript?CreativeID=$cr_id">$name</A></TD>
<TD>$OASISmsg[$status]</TD>
<TD>$weight</TD>
<TD>$mtype<BR>
$w x $h</TD>
<TD>$preview</TD>
</TR>
__TEXT__;
    }
    if(!$cr_list) return '';

    $cr_list = <<<__TEXT__
<P><FONT SIZE="+1"><STRONG>$OASISmsg[Creatives]</STRONG></FONT><BR>
<TABLE WIDTH="100%" CELLPADDING=0 CELLSPACING=0 BORDER=1>
<TR>
<TD CLASS=tablehead><SPAN CLASS=tablehead>$OASISmsg[Name]</SPAN></TD>
<TD CLASS=tablehead><SPAN CLASS=tablehead>$OASISmsg[Status]</SPAN></TD>
<TD CLASS=tablehead><SPAN CLASS=tablehead>$OASISmsg[Wt]</SPAN></TD>
<TD CLASS=tablehead><SPAN CLASS=tablehead>$OASISmsg[Type_Dim]</SPAN></TD>
<TD CLASS=tablehead><SPAN CLASS=tablehead>$OASISmsg[Preview]</SPAN></TD>
</TR>
$cr_list
</TABLE>
__TEXT__;
  }

  return $cr_list;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function build_form_elements($values)
{
  global $status_dropdown, $advertiser_dropdown, $pay_dropdown,
         $delivery_dropdown, $dow_select, $hod_select;
  global $startdate_widget, $enddate_widget;
  global $creative_list, $section_list;
  global $OASISmsg;

  $pay_array = array($OASISmsg[By_Period]   => 'By Period',
                     $OASISmsg[CIA]     => 'CIA',
                     $OASISmsg[End_of_Campaign]  => 'End of Campaign');
  $pay_dropdown = build_select($pay_array, 'PayFixed', $values['PayFixed'], '', '');

  $delivery_array = array('Day'   => $OASISmsg[Evenly_by_Day],
                          'Week'  => $OASISmsg[Evenly_by_Week],
                          'Month' => $OASISmsg[Evenly_by_Month]
                         );

  $delivery_dropdown = build_select($delivery_array, 'EvenDelivery', $values['EvenDelivery'], '', '');

  #### if the campaign has been marked complete by the system, we can't edit it.
  if($values['Status'] == 'Completed')
  {
    $status_dropdown = <<<__TEXT__
<INPUT TYPE=hidden NAME="Status" VALUE="Completed">
<EM>$OASISmsg[Completed]</EM>
__TEXT__;
  }
  else
  {
    $status_array = array('Inactive' => $OASISmsg[Inactive],
                        'Active'     => $OASISmsg[Active],
                        'Suspended'  => $OASISmsg[Suspended],
                        'Cancelled'  => $OASISmsg[Cancelled]);

    $status_dropdown = build_select($status_array, 'Status', $values['Status'], '', '');
  }

  if($result = mysql_query("select AdvertiserID, Name from Advertisers order by Name"))
  {
    $advertisers = array();
    while(list($id, $name) = mysql_fetch_row($result))
      $advertisers[$id] = $name;
    $advertiser_dropdown
       = build_select($advertisers, 'AdvertiserID', $values['AdvertiserID'], '', '');
  }
  else print "error: " . mysql_error() . "<BR>\n";

  $startdate_widget = build_date_widget('StartDate', $values['StartDate'], 0);
  $enddate_widget   = build_date_widget('EndDate', $values['EndDate'], 0);

  $dow_array = array('1' =>  $OASISmsg[Sunday],
                     '2' =>  $OASISmsg[Monday],
                     '4' =>  $OASISmsg[Tuesday],
                     '8' =>  $OASISmsg[Wednesday],
                     '16' => $OASISmsg[Thursday],
                     '32' => $OASISmsg[Friday],
                     '64' => $OASISmsg[Saturday]);
  while(list($k, $v) = each($dow_array))
    if($values[DaysOfWeek] & $k) $dow_sel[$k] = 1;

  $dow_select = build_select($dow_array, 'DaysOfWeek[]', $dow_sel, 7, 1);

  $hod_array = array('1'       => $OASISmsg[a12],
                     '2'       => $OASISmsg[a1],
                     '4'       => $OASISmsg[a2],
                     '8'       => $OASISmsg[a3],
                     '16'      => $OASISmsg[a4], 
                     '32'      => $OASISmsg[a5],
                     '64'      => $OASISmsg[a6], 
                     '128'     => $OASISmsg[a7], 
                     '256'     => $OASISmsg[a8],
                     '512'     => $OASISmsg[a9], 
                     '1024'    => $OASISmsg[a10],
		             '2048'    => $OASISmsg[a11], 
                     '4096'    => $OASISmsg[p12],
		             '8192'    => $OASISmsg[p1],
                     '16384'   => $OASISmsg[p2],
		             '32768'   => $OASISmsg[p3],
                     '65536'   => $OASISmsg[p4],
		             '131072'  => $OASISmsg[p5],
                     '262144'  => $OASISmsg[p6],
		             '524288'  => $OASISmsg[p7],
                     '1048576' => $OASISmsg[p8],
		             '2097152' => $OASISmsg[p9],
                     '4194304' => $OASISmsg[p10],
		             '8388608' => $OASISmsg[p11]);
  while(list($k, $v) = each($hod_array))
    if($values[HoursOfDay] & $k) $hod_sel[$k] = 1;

  $hod_select = build_select($hod_array, 'HoursOfDay[]', $hod_sel, 7, 1);

  if($values['CampaignID'])
  {
    $creative_list = build_creative_list($values['CampaignID']);
    $section_list  = build_section_list($values['CampaignID']);
  }
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function copy_campaign($CampaignID)
{
  global $OASISmsg, $campaignscript;

  if(!($result = mysql_query("select * from Campaigns where CampaignID=$CampaignID")))
  {
    print $OASISmsg[Error_copying_campaign] . mysql_error();
    print_footer();
    exit;
  }

  $row = mysql_fetch_array($result, MYSQL_ASSOC);
  $row[CampaignID]           = 'NULL';
  $row[Name]                 = $OASISmsg[Copy_of] . " $row[Name]";
  $row[ImpressionsDelivered] = 0;
  $row[ClicksDelivered]      = 0;
  $row[Status]               = 'Inactive';

  $vals = array();
  while(list($k, $v) = each($row))
    array_push($vals, "'" . addslashes($v) . "'");

  $sql = "insert into Campaigns values (" . join(",", $vals) . ")";
  if(!mysql_query($sql)
    || !($new_ca_id = mysql_insert_id())
    || !($result = mysql_query("select * from Creatives where CampaignID=$CampaignID")))
  {
    print "Error copying campaign: " . mysql_error();
    print_footer();
    exit;
  }

  #### copy all the campaign's creatives
  while($row = mysql_fetch_array($result, MYSQL_ASSOC))
  {
    $old_cr_id = $row[CreativeID];
    $row[CreativeID] = 'NULL';
    $row[CampaignID] = "$new_ca_id";
    $row[ImpressionsDelivered] = 0;
    $row[ClicksDelivered]      = 0;
    $vals = array();
    while(list($k, $v) = each($row))
      array_push($vals, "'" . addslashes($v) . "'");
    $sql = "insert into Creatives values (" . join(",", $vals) . ")";

    if(!mysql_query($sql)
       || !($new_cr_id = mysql_insert_id())
       || !($result2 = mysql_query("select * from CreativeAssignments where CreativeID=$old_cr_id")))
    {
      print "$OASISmsg[Error_copying_creatives] $CampaignID $OASISmsg[to] $new_ca_id: " . mysql_error();
      print_footer();
      exit;
    }

    #### copy all the creative assignments
    while($row = mysql_fetch_array($result2, MYSQL_ASSOC))
    {
      $row[CreativeID] = $new_cr_id;
      $vals = array();
      while(list($k, $v) = each($row))
        array_push($vals, "'" . addslashes($v) . "'");
      $sql = "insert into CreativeAssignments values (" . join(",", $vals) . ")";
      if(!mysql_query($sql))
      {
        print "$OASISmsg[Error_copying_section_assignments] $old_cr_id $OASISmsg[to] $new_cr_id: " . mysql_error();
        print_footer();
        exit;
      }
    }
  }

  #### copy all the campaign's assignments
  if(!($result = mysql_query("select * from CampaignAssignments where CampaignId=$CampaignID")))
  {
    print "$OASISmsg[Error_pulling_section_assignments] $CampaignID: " . mysql_error();
    print_footer();
    exit;
  }
  while($row = mysql_fetch_array($result, MYSQL_ASSOC))
  {
    $row[CampaignID] = $new_ca_id;
    $vals = array();
    while(list($k, $v) = each($row))
      array_push($vals, "'" . addslashes($v) . "'");
    $sql = "insert into CampaignAssignments values (" . join(",", $vals) . ")";
    if(!mysql_query($sql))
    {
      print "$OASISmsg[Error_copying_section_assignments_ca] $CampaignID $OASISmsg[to] $new_ca_id: " . mysql_error();
      print_footer();
      exit;
    }
  }

  error_log("/tmp/test", "Location: $campaignscript?CampaignID=$new_ca_id");
  header("Location: $campaignscript?CampaignID=$new_ca_id");
  exit;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function delete_campaign($CampaignID)
{
  global $campaignscript, $OASISmsg;

  if($result = mysql_query("select Status from Campaigns where CampaignID=$CampaignID"))
  {
    list($status) = mysql_fetch_row($result);

    if($status == 'Active')
    {
      print <<<__TEXT__
<TABLE WIDTH=615><TR><TD>
$OASISmsg[delete_active_campaign_1]
<A HREF="$campaignscript?CampaignID=$CampaignID">$OASISmsg[go_back]</A>
$OASISmsg[delete_active_campaign_2]
</TD></TR></TABLE>
__TEXT__;
      print_footer();
      exit;
    }
  }

  if($result = mysql_query("select InvoiceID from Invoices where CampaignID=$CampaignID"))
  {
    if(mysql_num_rows($result) > 0)
    {
      print <<<__TEXT__
<TABLE WIDTH=615><TR><TD>
$OASISmsg[delete_campaign_invoices]
</TD></TR></TABLE>
__TEXT__;

      print_footer();
      exit;
    }
  }


  print <<<__TEXT__
<TABLE WIDTH=615><TR><TD>
$OASISmsg[confirm_delete_campaign_1]
<A HREF="$campaignscript?reallydelete=1&CampaignID=$CampaignID">$OASISmsg[here]</A>.
$OASISmsg[confirm_delete_campaign_2]
<A HREF="$campaignscript?CampaignID=$CampaignID">$OASISmsg[here]</A>
$OASISmsg[confirm_delete_campaign_3]
</TD></TR></TABLE>
__TEXT__;

  print_footer();
  exit;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function really_delete_campaign($CampaignID)
{
  global $campaignscript, $OASISmsg;

  #### remove this campaign's creatives from the DailyTargets table; note
  #### that this will not stop them from running -- they will continue to
  #### run until the delivery engine is reloaded (rebuilding the hourly
  #### assignments table)
  $cr_list = array();
  if(!($result = mysql_query("select CreativeID from Creatives where CampaignID=$CampaignID")))
    die("$OASISmsg[Error_pulling_creatives] $CampaignID: " . mysql_error() . "\n");
  while(list($cr_id) = mysql_fetch_row($result)) array_push($cr_list, $cr_id);
  $cr_list = join(",", $cr_list);

  if($cr_list)
  {
    mysql_query("lock tables DailyTargets write");
    mysql_query("delete from DailyTargets where CreativeID in ($cr_list)");
    mysql_query("unlock tables");
  }

  #### clean up creative assignments
  if($result = mysql_query("select CreativeID from Creatives where CampaignID=$CampaignID"))
  {
    while(list($cr_id) = mysql_fetch_row($result))
      mysql_query("delete from CreativeAssignments where CreativeID=$cr_id");
  }
  
  #### clean up campaign, creatives, and campaign assignments
  if(mysql_query("delete from Campaigns where CampaignID=$CampaignID")
     && mysql_query("delete from Creatives where CampaignID=$CampaignID")
     && mysql_query("delete from CampaignAssignments where CampaignID=$CampaignID"))
  {
    header("Location: $campaignscript");
    exit;
  }
  else
  {
    print "<EM>$OASISmsg[error_del_campaign]:<BR>\n"
          . mysql_error() . " .</EM><BR>\n";
  }

}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function validate_campaign($ca_id, $sd, $ed, $ca_impg, $weight, $fixed)
{
  global $OASISmsg;
  $errors = "";

  #### find out about creatives' impression guarantees
  if($ca_id)
  {
    if(!$result = mysql_query("select CreativeID, ImpressionsGuaranteed from Creatives where CampaignID=$ca_id"))
    {
      print "$OASISmsg[error_ret_creative_parm]: " . mysql_error();
      print_footer();
      exit;
    }
    $pickerupper = 0;
    while(list($id, $impg) = mysql_fetch_row($result))
    {
      if($impg == 0) $pickerupper = 1;
      $impg_tot += $impg;
    }

    if($ca_impg && $impg_tot && $impg_tot > $ca_impg)
      $errors .= "<LI>$OASISmsg[creative_imps_exceed_campaign] ($impg_tot &gt; $ca_impg)";

    if($ca_impg && $impg_tot && $impg_tot < $ca_impg && !$pickerupper)
      $errors .= "<LI>$OASISmsg[creative_imps_less_than_campaign] ($impg_tot &lt; $ca_impg)";
  }

  if($ed && $sd > $ed)
    $errors .= "<LI>$OASISmsg[start_after_end]";

  if(!$sd && $ca_impg > 0)
    $errors .= "<LI>$OASISmsg[imps_no_start]";

  if(!$ed && $ca_impg > 0)
    $errors .= "<LI>$OASISmsg[imps_no_end]";

  if(!$sd && $fixed > 0)
    $errors .= "<LI>$OASISmsg[fixed_no_start]";

  if(!$ed && $fixed > 0)
    $errors .= "<LI>$OASISmsg[fixed_no_end]";

  if($weight != '' && $weight == 0)
    $errors .= "<LI>$OASISmsg[no_zero_weights]";

  if($errors)
  {
    print <<<__TEXT__
<TABLE WIDTH=615><TR><TD>
<H1>$OASISmsg[Error]</H1>
$OASISmsg[error_list]:
<UL>
$errors
</UL>
$OASISmsg[error_list_fix]
</TABLE>
__TEXT__;

    print_footer();
    exit;
  }
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function save_campaign($CampaignID)
{
  global $Name, $AdvertiserID, $Status,
         $StartDate_Month, $StartDate_Day, $StartDate_Year,
         $EndDate_Month, $EndDate_Day, $EndDate_Year,
         $ImpressionsGuaranteed, $Weight, $EvenDelivery,
	 $DaysOfWeek, $HoursOfDay,
         $CPM, $CPC, $Fixed, $PayFixed, 
         $AgencyCommission, $PurchaseOrder, $Note, $Notify,
	 $ForceInvoice;
  global $OASISmsg, $OASIStsep;

  $dow = 0;
  foreach($DaysOfWeek as $d) $dow += $d;
  $hod = 0;
  foreach($HoursOfDay as $h) $hod += $h;

  $ImpressionsGuaranteed = preg_replace("#[$OASIStsep]#", '', $ImpressionsGuaranteed);
  $CPM   = preg_replace("#[$OASIStsep]#", '', $CPM);
  $CPC   = preg_replace("#[$OASIStsep]#", '', $CPC);
  $Fixed = preg_replace("#[$OASIStsep]#", '', $Fixed);

  validate_campaign($CampaignID, 
                    "$StartDate_Year$StartDate_Month$StartDate_Day",
                    "$EndDate_Year$EndDate_Month$EndDate_Day",
		    $ImpressionsGuaranteed, $Weight, $Fixed);

  if(!$ImpressionsGuaranteed) $ImpressionsGuaranteed = 0;
  if(!$Weight) $Weight = 1;
  if(!$CPM) $CPM = 0;
  if(!$CPC) $CPC = 0;
  if(!$Fixed) $Fixed = 0;
  if(!$AgencyCommission) $AgencyCommission = 0;
  if(!$EvenDelivery) $EvenDelivery = 'Day';

  $ForceInvoice = ($ForceInvoice) ? 'Y' : 'N';

  #### it seems that this has been done for us by PHP...
  #$Name          = addslashes($Name);
  #$PurchaseOrder = addslashes($PurchaseOrder);
  #$Notify        = addslashes($Notify);
  #$Note          = addslashes($Note);

  if($CampaignID)
  {
    $sql = "update Campaigns set Name='$Name', AdvertiserID=$AdvertiserID, Status='$Status', StartDate='$StartDate_Year-$StartDate_Month-$StartDate_Day', EndDate='$EndDate_Year-$EndDate_Month-$EndDate_Day', ImpressionsGuaranteed=$ImpressionsGuaranteed, EvenDelivery='$EvenDelivery', DaysOfWeek=$dow, HoursOfDay=$hod, Weight='$Weight', CPM='$CPM', CPC='$CPC', Fixed='$Fixed', AgencyCommission='$AgencyCommission', PurchaseOrder='$PurchaseOrder', Note='$Note', Notify='$Notify', PayFixed='$PayFixed', ForceInvoice='$ForceInvoice' where CampaignID=$CampaignID";
  }
  else
  {
    $sql = "insert into Campaigns (Name, AdvertiserID, StartDate, EndDate, ImpressionsGuaranteed, EvenDelivery, DaysOfWeek, HoursOfDay, Weight, CPM, CPC, Fixed, AgencyCommission, PurchaseOrder, Note, Notify, PayFixed, ForceInvoice) values ('$Name', $AdvertiserID, '$StartDate_Year-$StartDate_Month-$StartDate_Day', '$EndDate_Year-$EndDate_Month-$EndDate_Day', $ImpressionsGuaranteed, '$EvenDelivery', $dow, $hod, '$Weight', '$CPM', '$CPC', '$Fixed', '$AgencyCommission', '$PurchaseOrder', '$Note', '$Notify', '$PayFixed', '$ForceInvoice')";
  }

  if(mysql_query($sql))
  {
    print "<EM>$OASISmsg[Campaign_info_saved]</EM><BR>\n";

    #### if we're putting a new record into the table, grab the CampaignID
    if(!$CampaignID  && $result = mysql_query("select LAST_INSERT_ID()"))
      list($CampaignID) = mysql_fetch_row($result);
  }
  else
  {
    print "<EM>$OASISmsg[error_save_campaign]:<BR>\n"
          . mysql_error() . " .<BR>$sql</EM><BR>\n";
  }

  require("lib-dengine.inc");
  require("lib-maint.inc");
  reload_daily($CampaignID);

  return $CampaignID;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function list_campaigns($orderby, $ascdesc, $status_filter, $limited)
{
  global $PHP_AUTH_USER, $campaignscript, $campaign_access, $OASISmsg;

  #### if this is a limited view, only show those campaigns which this
  #### user is entitled to see
  if($limited)
  {
      $campaign_filter = "and Campaigns.CampaignID in ("
                       . join(",", array_keys($campaign_access))
		       . ") ";
  }
  
  if(!$ascdesc) $ascdesc = 'asc';
  if(!$orderby) $orderby = 'Campaigns.Name';
  if(!$status_filter)
  {
    $status_filter['Inactive'] = 1;
    $status_filter['Active'] = 1;
    $status_filter['Suspended'] = 1;
  }
  $status_filter_string = '';
  while(list($field, $val) = each($status_filter))
  {
    if($status_filter_string) $status_filter_string .= ", '$field'";
    else               $status_filter_string = "'$field'";
  }

  $sql = "select Campaigns.CampaignID, Campaigns.Name, Campaigns.Status, Advertisers.Name as AName from Campaigns left join Advertisers on Campaigns.AdvertiserID=Advertisers.AdvertiserID where Campaigns.Status in ($status_filter_string)$campaign_filter order by $orderby $ascdesc";
  #print "$sql<BR>\n";

  #### toggle asc/desc, and set up the graphic
  $sorto = array('Campaigns.Name' => 'asc', 
                 'Advertisers.Name' => 'asc',
                 'Campaigns.Status' => 'asc');
  if($ascdesc == 'asc')
  {
    $sortg[$orderby]
      = ' <IMG SRC="graphics/down.gif" WIDTH=12 HEIGHT=12 BORDER=0>';
    $sorto[$orderby] = 'desc';
  }
  else
  {
    $sortg[$orderby]
      = ' <IMG SRC="graphics/up.gif" WIDTH=12 HEIGHT=12 BORDER=0>';
  }

  if($result = mysql_query($sql))
  {
    print <<<__TEXT__
<TABLE WIDTH=615 CELLSPACING=0 CELLPADDING=0 BORDER=1>
<TR>
<TD CLASS=tablehead>
<A HREF="$campaignscript?orderby=Campaigns.Name&ascdesc={$sorto['Campaigns.Name']}" CLASS=tablehead>$OASISmsg[Campaign]{$sortg['Campaigns.Name']}</A>
</TD>
<TD CLASS=tablehead>
<A HREF="$campaignscript?orderby=Advertisers.Name&ascdesc={$sorto['Advertisers.Name']}" CLASS=tablehead>$OASISmsg[Advertiser]{$sortg['Advertisers.Name']}</A>
</TD>
<TD CLASS=tablehead>
<A HREF="$campaignscript?orderby=Campaigns.Status&ascdesc={$sorto['Campaigns.Status']}" CLASS=tablehead>$OASISmsg[Status]{$sortg['Campaigns.Status']}</A>
</TD>
</TR>
__TEXT__;

    $bgcolor = '#cccccc';
    while(list($ca_id, $ca_name, $status, $aname) = mysql_fetch_row($result))
    {
      $bgcolor = ($bgcolor == '#ffffff') ? '#cccccc' : '#ffffff';

      print <<<__TEXT__
<TR BACKGROUND='' BGCOLOR=$bgcolor>
<TD><A HREF="$campaignscript?CampaignID=$ca_id">$ca_name</A></TD>
<TD>$aname</TD>
<TD>$OASISmsg[$status]</TD>
</TR>
__TEXT__;
    }
    print "</TABLE>\n";

    if(!$limited) print <<<__TEXT__
<A HREF="$campaignscript?new_campaign=1">$OASISmsg[Add_Campaign]</A>

__TEXT__;

    print "<FORM METHOD=POST ACTION=$campaignscript><INPUT TYPE=checkbox NAME=show_active";
    if($status_filter['Active'] == 1) print " CHECKED";
    print ">$OASISmsg[Active] &middot;\n<INPUT TYPE=checkbox NAME=show_inactive";
    if($status_filter['Inactive'] == 1) print " CHECKED";
    print ">$OASISmsg[Inactive] &middot;\n<INPUT TYPE=checkbox NAME=show_suspended";
    if($status_filter['Suspended'] == 1) print " CHECKED";
    print ">$OASISmsg[Suspended] &middot;\n<INPUT TYPE=checkbox NAME=show_cancelled";
    if($status_filter['Cancelled'] == 1) print " CHECKED";
    print ">$OASISmsg[Cancelled] &middot;\n<INPUT TYPE=checkbox NAME=show_completed";
    if($status_filter['Completed'] == 1) print " CHECKED";
    print ">$OASISmsg[Completed]\n<INPUT TYPE=submit VALUE=Filter></FORM><BR>\n";
  }
  else
  {
    print "$OASISmsg[MySQL_error]: " . mysql_error() . "<BR>\n";
  }
}



?>
