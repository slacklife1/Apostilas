<?php

####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function get_creative($s, $w, $h, $frame_target)
{
  global $error_code, $sem_id, $cr_id, $HTTP_USER_AGENT;

  $sem_id = 0;
  $cr_id = 0;

  $remote_address = getenv("REMOTE_ADDR");
  $cl_id = get_client_id($remote_address);

  $error_code = '';
  if(select_creative($s, $w, $h)
     && record_delivery($cr_id, $remote_address, $cl_id, $s, $HTTP_USER_AGENT))
  {
    @sem_release($sem_id);
    return retrieve_creative($cr_id, $frame_target, $w, $h, $remote_address, $cl_id, $s,
                          $HTTP_USER_AGENT);
  }
  else
  {
    #print "unable to select creative...<BR>\n";
    if($s == 0) $s = 0;
    log_msg(0, $cl_id, $remote_address, $s, $cr_id, 'ierr', $error_code, $HTTP_USER_AGENT);
    @sem_release($sem_id);
    return '';
  }
}


####---------------------------------------------------------------------------
#### look for a cookie; if found, return its ID number.  Otherwise, generate
#### a new ID.
####---------------------------------------------------------------------------
function get_client_id($remote_address)
{
  global $HTTP_COOKIE_VARS;

  #### cookie is named OASISID
  if($id = $HTTP_COOKIE_VARS["OASISID"])
  {
    #### some poorly-coded browsers can barf up more than just our OASISID
    #### cookie (I've even seen some dump what looks like their entire
    #### cookie table!).  When this gets logged, it will wreak havoc on
    #### the log processor.  So just to be sure, we trim off everything past
    #### the 13-character unique ID.
    $id = substr($id, 0, 13);
  }
  else
  {
    $id = uniqid('');

    #### 5-year expiration on cookie
    setcookie("OASISID", $id, time() + 157680000, "/", ".[oasis_domain]");
  }

  return $id;
}



####---------------------------------------------------------------------------
#### given a section ID and the desired width and height, select a creative
#### from the pool of available creatives
####---------------------------------------------------------------------------
function select_creative($section, $width, $height)
{
  global $cr_id, $sem_id, $error_code;
  global $media_type;

  #### grab a semaphore; we don't want to enter these shared memory
  #### segments when another instance of this script is in there
  #### or if they're being reloaded by the maintenance scripts
  #### identifier:           O A 0 0
  if(!((@$sem_id = sem_get(0x4f410000, 1)) && @sem_acquire($sem_id)))
  {
    $error_code = 'no_sem';
    return 0;
  }

  #### attach to Hourly Assignments shared memory segment
  #### identifier:     O A S 0
  @$smh = shm_attach(0x4f415300, 0); 
  @$section_creatives = shm_get_var($smh, $section);
  @shm_detach($smh);

  if(!$section_creatives)
  {
    $error_code = 'no_sec_cr';
    return 0;
  }

  $secdim_creatives = $section_creatives[$width . "x" . $height];

  if(!$secdim_creatives)
  {
    #### big problem -- no creatives scheduled for this hour for this section
    $error_code = 'no_secdim_cr';
    return 0;
  }

  #### attach to Hourly Targets shared memory segment
  #### identifier:     O A S 1
  if(!(@$smh = shm_attach(0x4f415301, 0)))
  {
    $error_code = "no_ht_shm ($php_errormsg)";
    return 0;
  }

  #### loop through creatives, looking for best candidate
  $cr_id = 0;
  $total_weight = 0;
  $total_remaining = 0;
  foreach ($secdim_creatives as $c)
  {
    @$target_info = shm_get_var($smh, $c);

    #### we really don't want/expect this to happen, but we also don't
    #### want to bring delivery to a halt just because one creative's
    #### target info isn't retrieved from shared memory
    if(!$target_info) continue;

    list($target, $weight, $remaining, $clicks, $mt) = $target_info;

    #print "creative $c: [$target, $weight, $remaining]<BR>\n";
    $media_types[$c] = $mt;
    if($remaining > 0)
    {
      $total_remaining += $remaining;
      $remaining_ads[$c] = $remaining;
    }
    elseif($target == 0)
    {
      $total_weight += $weight;
      $weight_ads[$c] = $weight;
    }
  }
  @shm_detach($smh);

  #### should we select a 'remaining' ad or a 'weight' ad?
  if($total_remaining <= 0)
  {
    $rmax = $total_weight;
    $candidates = $weight_ads;
  }
  else
  {
    $rmax = $total_remaining;
    $candidates = $remaining_ads;
  }

  if($rmax > 0)
  {
    mt_srand((double)microtime()*1000000);
    $rand_num = mt_rand(0, $rmax);
    while(list($c, $w) = each($candidates))
    {
      $rand_num -= $w;
      if($rand_num <= 0)
      {
        $cr_id = $c;
        break;
      }
    }
  }
  else
  {
    #### the creatives assigned to this section are maxed out (all have
    #### targets, and all have remaining = 0)
    $error_code = 'secdim_cr_maxed_out';
    return 0;
  }

  $media_type = $media_types[$cr_id];

  return 1;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function record_delivery($cr_id, $ra, $cl_id, $s, $ua)
{
  global $error_code;

  #### decrement the "remaining" field; we have to do this here so that
  #### the selection and decrementing is atomic (we're still inside the
  #### protection of the semaphore).  Of course, we'd prefer to do it
  #### after we've actually sent the content of the creative, but we're
  #### going to send the creative immediately after this step.  This
  #### is as close to the actual delivery as we can get; if we try to
  #### hold the semaphore until after the delivery is complete, we'll
  #### create an enormous bottleneck as we wait for slow connections.

  #### attach to Hourly Targets shared memory segment
  #### identifier:     O A S 1
  if(!(@$smh = shm_attach(0x4f415301, 0)))
  {
    $error_code = "no_ht_shm_2 ($php_errormsg)";
    return 0;
  }

  #### retrieve the current target info
  if(!@$target_info = shm_get_var($smh, $cr_id))
  {
    $error_code = "no_target_info ($php_errormsg)";
    return 0;
  }

  #### decrement "remaining" field and put back into SHM
  $target_info[2]--;
  if(@shm_put_var($smh, $cr_id, $target_info))
  {
    #### we log the delivery immediately so that it occurs right after
    #### the shared memory table is updated, reducing the chance that
    #### something might go wrong and the impression doesn't get logged.
    log_msg(0, $cl_id, $ra, $s, $cr_id, 'imp', '', $ua);
  }
  else
  {
    $error_code = "no_target_info_put ($php_errormsg)";
    return 0;
  }

  return 1;
}



####---------------------------------------------------------------------------
#### retrieve the content of the specified creative
####---------------------------------------------------------------------------
function retrieve_creative($cr_id, $frame_target, $w, $h, $ra, $cl_id, $s, $ua)
{
  global $media_type;
  global $sem_id, $error_code;

  $error_code = '';
  $target_tag = ($frame_target) ? " TARGET='$frame_target'" : "";

  #### attach to a shared memory segment
  #### identifier:     O A S 2
  @$smh = shm_attach(0x4f415302, 0); 
  @$creative_info = shm_get_var($smh, $cr_id);
  @shm_detach($smh);

  if(!$creative_info)
  {
    $error_code = "no_cr_content ($php_errormsg)";
    return '';
  }

  list($content, $redirect, $mime_type, $animated, $alt) = $creative_info;

  mt_srand((double)microtime()*1000000);
  $rand_num = mt_rand();
  if($media_type == 'Image')
  {
    if($redirect == 'Y')
    {
      $content = preg_replace("#\[CB\]#", $rand_num, $content);
      
      $cr_content = <<<__TEXT__
<A HREF="http://[oasis_host][oasis_url]oasisc.php?s=$s&c=$cr_id"$target_tag><IMG SRC="$content" WIDTH=$w HEIGHT=$h BORDER=0 ALT="$alt"></A>
__TEXT__;
    }
    else
    {
      $cr_content = <<<__TEXT__
<A HREF="http://[oasis_host][oasis_url]oasisc.php?s=$s&c=$cr_id"$target_tag><IMG SRC="http://[oasis_host][oasis_url]oasisi.php?s=$s&c=$cr_id&cb=$rand_num" WIDTH=$w HEIGHT=$h BORDER=0 ALT="$alt"></A>
__TEXT__;
    }
  }
  else
  {
    $cr_content = $content;
    while (preg_match('#\[OASISCLICK:(.+?)\]#i', $cr_content, $matches))
    { 
        $url = $matches[1];
        $url = urlencode($url);
        $cr_content = preg_replace('#\[OASISCLICK:(.+?)\]#i', "http://[oasis_host][oasis_url]oasisc.php?s=$s&c=$cr_id&cb=$rand_num&url=$url", $cr_content, 1);
    }
    $cr_content = preg_replace('#A HREF#i', "A$target_tag HREF", $cr_content);
  }

  return $cr_content;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function log_msg($get_sem, $cl_id, $ra, $section, $cr_id, $event, $code, $ua)
{
  $log_message = time()
     . "\t$ra\t$cl_id\t$event\t$section\t$cr_id\t$code\t$ua\n";

  #### grab a semaphore; we don't want to write to this log
  #### when another instance of this script is in there
  #### identifier:           O A O 0
  if($get_sem)
  {
    if(!((@$sem_id = sem_get(0x4f410000, 1)) && @sem_acquire($sem_id)))
      return 0;
  }

  error_log($log_message, 3, "[log_dir]/oasis.log");

  if($get_sem) @sem_release($sem_id);
}


?>
