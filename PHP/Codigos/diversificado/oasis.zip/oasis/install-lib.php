<?php

####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function get_php_version()
{
  $pversion = phpversion();
  $pversion = preg_replace('#[^\d.].*#', '', $pversion);
  $comp = split('\.', $pversion);

  $comp = array_reverse($comp);
  $factor = 1;
  foreach($comp as $v)
  {
    $version_number += $v * $factor;

    $factor *= 100;
  }

  return $version_number;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function check_php_install()
{
  $version_number = get_php_version ();
  if($version_number < 40000)
  {
    print "OASIS requires PHP version 4.0.0 or greater\n";
    exit;
  }

  if(!ini_get('register_argc_argv'))
  { 
    print "register_argc_argv not set in php.ini\nYou must have this set to 'On' in php.ini\n";
    exit;
  }

  if(!((@$sem_id = sem_get(0x4f410000, 1)) && @sem_acquire($sem_id)))
  {
    print "Could not acquire semaphore: $php_errormsg\nYou must enable System V semaphores and shared memory to use OASIS.\n";
    exit;
  }
  @sem_release($sem_id);

  if(!(@$smh = shm_attach(0x4f415300, 1000)))
  {
    print "Could not attach to shared memory: $php_errormsg\nYou must enable System V semaphores and shared memory to use OASIS.\n";
    exit;
  }
  @shm_detach($smh);

  #### PHP version 4.0.7 changed the shm_remove() semantics
  if (get_php_version() >= 40007)
  {
    @shm_remove(shm_attach(0x4f415300, 1000));
  }
  else
  {
    @shm_remove(0x4f415300);
  }
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function check_mysql()
{
  global $stdin, $setup;

  print "Enter MySQL hostname (blank for localhost): ";
  $hostname = chop(fgets($stdin, 65536));

  print "Enter MySQL username: ";
  $user = chop(fgets($stdin, 65536));

  print "Enter password for $user: ";
  $password = chop(fgets($stdin, 65536));

  if(!@mysql_pconnect($hostname, $user, $password))
  {
    print "Error: could not connect to MySQL server:\n" . mysql_error() . "\n";
    exit;
  }

  if(($result = mysql_query("select VERSION()"))
     && (list($v) = mysql_fetch_row($result)))
  {
    $v = preg_replace('#(\d+\.\d+).*#', '\1', $v);
    if($v < 3.23)
    {
      print "OASIS requires MySQL version 3.23 or greater\n";
      exit;
    }
  }
  else
  {
    print "Error: could not get MySQL version:\n" . mysql_error() . "\n";
    exit;
  }

  $setup[db_host] = $hostname;
  $setup[mysql_admin_user] = $user;
  $setup[mysql_admin_password] = $password;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function get_setup_vals()
{
  global $stdin, $setup;

  foreach(file('oasis.cfg') as $line)
  {
    $line = chop($line);

    #### remove comments
    $line = preg_replace('/\#.*/', '', $line);

    list($key, $val) = split(':', $line);
    $key = preg_replace('#\s+#', '', $key);
    $val = preg_replace('#\s+#', '', $val);

    if(!$key) continue;

    #print "$key => $val\n";
    $setup[$key] = $val;
  }

  if($setup['oasis_port'] != 80)
  {
    $setup['oasis_host'] .= ":" . $setup['oasis_port'];
  }
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function setup_mysql($setup)
{
  global $stdin;

  #### create oasis database
  if(!mysql_query("create database oasis"))
  {
    if(!@mysql_select_db("oasis"))
    {
      print "Error creating oasis database: " . mysql_error() . "\n";
      exit;
    }
    else
    {
      print "Database already exists: continue loading database? (y/n) ";
      $answer = chop(fgets($stdin, 65536));

      if($answer == 'Y' || $answer == 'y') {}
      else return;
    }
  }

  @mysql_select_db("mysql");

  #### create mysql user
  mysql_query("insert into user values ('localhost', '$setup[db_user]', password('$setup[db_passwd]'), 'Y', 'Y', 'Y', 'Y', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N')");
  if(!($result = mysql_query("select * from user where User='$setup[db_user]'"))
      && (list($v) = mysql_fetch_row($result)))
  {
    print "Error creating mysql user: " . mysql_error() . "\n";
    exit;
  }

  #### create tables
  @mysql_select_db("oasis");
  foreach(file('oasis.ddl') as $line)
  {
    $line = chop($line);

    $sql .= $line;
    if(preg_match('#;#', $line))
    {
      if(!mysql_query($sql))
      {
        print "Error executing SQL: " . mysql_error() . "\nSQL: $sql\n\n";
        #exit;
      }
      $sql = '';
    }
  }

  load_mysql($setup);
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function load_mysql($setup)
{
  @mysql_select_db("oasis");

  #### load prefs
  $prefs = array(
               "IdentifyPath" => "$setup[identify_path]",
               "AdminEmail"   => "webmaster",
               "LogDir"       => "$setup[log_dir]",
               "InvoiceDue"   => "30",
               "InvoiceHeaderString" => "Internet Advertising Invoice",
               "InvoiceHeaderGraphic" => "",
               "HtmldocPath" => "$setup[htmldoc_path]",
               "CurlPath" => "$setup[curl_path]",
               "GzipPath" => "$setup[gzip_path]",
               "ReportFromAddr" => "",
               "ClickthroughWindow" => "7200",
               "InvoiceFooterString" => "",
               "NewCampaignEmail" => "webmaster",
               "OASISRoot" => "http://$setup[oasis_host]$setup[oasis_url]",
               "InsertActive" => "N",
               "ValidateClickthrough" => "Y",
               "ValidateThirdParty" => "Y",
               "KeepLogsFor" => "14",
               "KeepStatsFor" => "800",
               "RevenueReportClicks" => "N",
               "InvDaysBack" => "90",
               "InvDaysForward" => "60",
               "InvMethod" => "Average",
               "InvCycle" => "Week",
               "InvScaleFactor" => "0.50",
               "InvWarningThreshold" => 80,
               "ShmSizeHourlyAssignments" => 500000,
               "ShmSizeHourlyTargets" => 50000,
               "ShmSizeCreativeContent" => 4000000,
               "ShmSizeCreativeClickthroughs" => 500000,
               );

  while(list($k, $v) = each($prefs))
  {
    $sql = "insert into OASISPrefs values ('$k', '$v')";
    if(!mysql_query($sql))
    {
      print "Error setting up prefs: " . mysql_error() . "\n";
      exit;
    }
  }

  #### create admin user
  if(!mysql_query("insert into Users values ('$setup[admin_user]', password('$setup[admin_passwd]'), '', '', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y')"))
  {
    print "Error creating admin user: " . mysql_error() . "\n";
    exit;
  }
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function create_directories($setup)
{
  global $stdin;

  $dir_list = array(
               $setup[oasis_root],
               $setup[oasis_root] . 'mgmt',
               $setup[oasis_root] . 'mgmt/graphics',
               $setup[oasis_root] . 'mgmt/docs',
               $setup[oasis_root] . 'mgmt/docs/images',
               $setup[log_dir]);

  foreach($dir_list as $dir)
  {
    if(is_dir($dir))
    {
      print "$dir exists!  Continue installing files? (y/n) ";
      $answer = chop(fgets($stdin, 65536));

      if($answer == 'Y' || $answer == 'y') break;
      else return;
    }
  }

  reset($dir_list);
  foreach($dir_list as $dir)
  {
    if(!@mkdir($dir, 0755) && !is_dir($dir))
    {
      print "error creating $dir: $php_errormsg\n";
      exit;
    }
  }
  
  if(!@chown($setup[log_dir], $setup[web_user]))
  {
    print "error changing ownership of $setup[log_dir] to $setup[web_user]: $php_errormsg\n";
    exit;
  }

  install_files($setup);
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function install_files($setup)
{
  #### suck in templates; replace special tags; install in directories
  $search = array('#\[db_host\]#',
                  '#\[db_user\]#',
                  '#\[db_passwd\]#',
                  '#\[log_dir\]#',
                  '#\[oasis_host\]#',
                  '#\[oasis_domain\]#',
                  '#\[oasis_url\]#',
		  );

  $replace = array($setup[db_host],
                   $setup[db_user],
                   $setup[db_passwd],
                   $setup[log_dir],
                   $setup[oasis_host],
                   $setup[oasis_domain],
                   $setup[oasis_url],
		  );

  if(!copy("templates/mgmt/i18n/lib-i18n.$setup[oasis_lang].inc",
           "templates/mgmt/lib-i18n.inc"))
  {
    print "error opening lib-i18n.$setup[oasis_lang].inc: $php_errormsg\n";
    exit;
  }

  #### get all language-specific files into place

  #### strip off charset info from language file
  $lang = $setup[oasis_lang];
  preg_match ('#([^.]+\.[^.]+)#', $lang, $matches);
  $lang = $matches[1]; 

  $lang_graphics_dir = "templates/mgmt/graphics/$lang";
  $dh = opendir($lang_graphics_dir);
  while (($file = readdir($dh))!==false)
  {
    if(preg_match('#\.gif$#', $file))
    {
      if(!copy("$lang_graphics_dir/$file", "templates/mgmt/graphics/$file"))
      {
        print "error opening lib-i18n.$setup[oasis_lang].inc: $php_errormsg\n";
        exit;
      }
    }
  }
  closedir($dh);

  $subdirs = array("", "mgmt/",
                   "mgmt/docs/", "mgmt/docs/images/", "mgmt/graphics/");
  foreach($subdirs as $subdir)
  {
    $dh = opendir("./templates/$subdir");
    while (($file = readdir($dh))!==false)
    {
      if(preg_match('#\.(php|inc)$#', $file))
      {
        @$fp = fopen("$setup[oasis_root]$subdir$file", "w");
        if(!$fp)
        {
          print "error opening $setup[oasis_root]$subdir$file for writing: $php_errormsg\n";
          exit;
        }

        print "installing $setup[oasis_root]$subdir$file...\n";
        $converted = preg_replace($search, $replace, file("templates/$subdir$file"));
        foreach($converted as $line) fputs($fp, $line);

        fclose($fp);
      }
      elseif(preg_match('#\.(css|gif|html?|pdf)$#', $file))
      {
        print "installing $setup[oasis_root]$subdir$file...\n";
        if(!copy("templates/$subdir$file", "$setup[oasis_root]$subdir$file"))
        {
          print "error copying to $setup[oasis_root]$subdir$file: $php_errormsg\n";
          exit;
        }
      }
    }
    closedir($dh);
  }


  $executables = array('check_inventory.php', 'daily_maint.php',
                       'hourly_maint.php', 'minutely_maint.php');
  foreach($executables as $exe)
  {
    chmod("$setup[oasis_root]mgmt/$exe", 0755);
  }
}
?>
