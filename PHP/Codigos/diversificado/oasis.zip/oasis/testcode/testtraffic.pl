#!/usr/bin/perl

#@sizes = ('468x60', '120x90');
@sizes = ('468x60');
@sections = (1);

%traffic = (
 0 => 10,
 1 => 20,
 2 => 20,
 3 => 30,
 4 => 30,
 5 => 40,
 6 => 40,
 7 => 40,
 8 => 50,
 9 => 60,
10 => 70,
11 => 80,
12 => 90,
13 => 100,
14 => 100,
15 => 90,
16 => 80,
17 => 70,
18 => 60,
19 => 50,
20 => 30,
21 => 30,
22 => 20,
23 => 10,
);


while (1) {
  $section = $sections[int (rand (scalar (@sections)))];
  print "section: $section\n";
  $size = $sizes[int (rand (scalar (@sizes)))];
  print "size: $size\n";
  ($w, $h) = ($size =~ m#(\d+)x(\d+)#o);

  $url = "http://localhost/oasis/oasisi.php?s=$section&w=$w&h=$h";

  print "$url\n";
  `curl '$url'`;

  my ($hour) = (localtime())[2];
  my $interval = rand (25) * (100 / $traffic{$hour});

  select(undef, undef, undef, $interval);
}
