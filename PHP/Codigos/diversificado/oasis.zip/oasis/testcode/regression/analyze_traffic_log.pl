#!/usr/bin/perl

while (<STDIN>) {
    chomp;

    ($event, $time, $section, $creative, $width, $height) = split ("\t", $_);

    $time =~ s#(\S+\s+\S+\s+\S+).+#$1#o;

    if ($event == 'imp') {
        $dayimp{$time}++;
        $secimp{$section}++;
    }
    else {
        $dayclick{$time}++;
        $secclick{$section}++;
    }
}

print "Day stats\n";
foreach $day (sort {$a <=> $b} keys %dayimp) {
    print "$day\t$dayimp{$day}\t$dayclick{$day}\n";
}

print "Section stats\n";
foreach $sec (sort {$a <=> $b} keys %secimp) {
    print "$sec\t$secimp{$sec}\t$secclick{$sec}\n";
}

