<?php

mysql_connect("localhost", "oasis", "pMDhn5");
mysql_select_db("oasis");

clear_sections ();
load_sections ();

clear_users ();
load_users ();

clear_advertisers ();
load_advertisers ();

clear_campaigns ();
load_campaigns ();

####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function clear_sections ()
{
    $sql = "DELETE FROM Sections";
    mysql_query($sql);
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function load_sections ()
{
    $sid1 = insert_section (0, 'OASIS Server', 'OASIS Server');

    $sid2 = insert_section ($sid1, 'chicago.com', 'chicago.com');
    $sid3 = insert_section ($sid2, 'goldcoast', 'chicago.com - goldcoast');
    $sid3 = insert_section ($sid2, 'loop', 'chicago.com - loop');
    $sid3 = insert_section ($sid2, 'lincolnpark', 'chicago.com - lincolnpark');
    $sid3 = insert_section ($sid2, 'oldtown', 'chicago.com - oldtown');
    $sid3 = insert_section ($sid2, 'streeterville', 'chicago.com - streeterville');
    $sid3 = insert_section ($sid2, 'wrigleyville', 'chicago.com - wrigleyville');

    $sid2 = insert_section ($sid1, 'dc.com', 'dc.com');
    $sid3 = insert_section ($sid2, 'adams morgan', 'dc.com - adams morgan');
    $sid4 = insert_section ($sid3, '17th', 'dc.com - adams morgan - 17th');
    $sid4 = insert_section ($sid3, '18th', 'dc.com - adams morgan - 18th');
    $sid4 = insert_section ($sid3, '19th', 'dc.com - adams morgan - 19th');
    $sid4 = insert_section ($sid3, 'columbia', 'dc.com - adams morgan - columbia');
    $sid4 = insert_section ($sid3, 'california', 'dc.com - adams morgan - california');
    $sid4 = insert_section ($sid3, 'u', 'dc.com - adams morgan - u');
    $sid3 = insert_section ($sid2, 'capitolhill', 'dc.com - capitolhill');
    $sid3 = insert_section ($sid2, 'dupontcircle', 'dc.com - dupontcircle');
    $sid3 = insert_section ($sid2, 'georgetown', 'dc.com - georgetown');

    $sid2 = insert_section ($sid1, 'raleigh.com', 'raleigh.com');
    $sid3 = insert_section ($sid2, 'boylanheights', 'raleigh.com - boylanheights');
    $sid3 = insert_section ($sid2, 'downtown', 'raleigh.com - downtown');
    $sid3 = insert_section ($sid2, 'fivepoints', 'raleigh.com - fivepoints');
    $sid3 = insert_section ($sid2, 'glenwoodsouth', 'raleigh.com - glenwoodsouth');
    $sid3 = insert_section ($sid2, 'mordecai', 'raleigh.com - mordecai');
    $sid4 = insert_section ($sid3, 'courtland', 'raleigh.com - mordecai - courtland');
    $sid5 = insert_section ($sid4, 'top', 'raleigh.com - mordecai - courtland (top)');
    $sid5 = insert_section ($sid4, 'bottom', 'raleigh.com - mordecai - courtland (bottom)');
    $sid5 = insert_section ($sid4, 'topleft', 'raleigh.com - mordecai - courtland (topleft)');
    $sid5 = insert_section ($sid4, 'bottomleft', 'raleigh.com - mordecai - courtland (bottomleft)');
    $sid4 = insert_section ($sid3, 'mordecai', 'raleigh.com - mordecai - mordecai');
    $sid4 = insert_section ($sid3, 'poplar', 'raleigh.com - mordecai - poplar');
    $sid3 = insert_section ($sid2, 'oakwood', 'raleigh.com - oakwood');

    $sid2 = insert_section ($sid1, 'stlouis.com', 'stlouis.com');
    $sid3 = insert_section ($sid2, 'dogtown', 'stlouis.com - dogtown');
    $sid3 = insert_section ($sid2, 'downtown', 'stlouis.com - downtown');
    $sid3 = insert_section ($sid2, 'landing', 'stlouis.com - landing');
    $sid3 = insert_section ($sid2, 'loop', 'stlouis.com - loop');
    $sid4 = insert_section ($sid3, 'delmar', 'stlouis.com - loop - delmar');
    $sid4 = insert_section ($sid3, 'skinker', 'stlouis.com - loop - skinker');
    $sid3 = insert_section ($sid2, 'thehill', 'stlouis.com - thehill');
    $sid3 = insert_section ($sid2, 'westend', 'stlouis.com - westend');

    mysql_query($sql);
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function insert_section ($psid, $name, $rname)
{
    $sql = <<<__TEXT__
INSERT INTO
  Sections (PSectionID, Name, ReportName, Active)
VALUES 
  ($psid, '$name', '$rname', 'Y');
__TEXT__;

    mysql_query ($sql);

    $sid = 0;
    if ($result = mysql_query("select LAST_INSERT_ID()")) {
        list ($sid) = mysql_fetch_row($result);
    }

    return $sid;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function clear_users ()
{
    $sql = "DELETE FROM Users";
    mysql_query($sql);
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function load_users ()
{
    $sql = <<<__TEXT__
INSERT INTO
  Users (Login, Password, FirstName, LastName, EmailAddress,
         Campaigns, Advertisers, Sections, Reports, Admin,
         CampaignInsertion, Invoicing)
VALUES 
  ('admin', password ('pass'), 'Admin', 'User', 'admin@oasispros.com',
   'Y', 'Y', 'Y', 'Y', 'Y',
   'Y', 'Y');
__TEXT__;
    mysql_query ($sql);

    $sql = <<<__TEXT__
INSERT INTO
  Users (Login, Password, FirstName, LastName, EmailAddress,
         Campaigns, Advertisers, Sections, Reports, Admin,
         CampaignInsertion, Invoicing)
VALUES 
  ('salesdude', password ('pass'), 'Sales', 'Dude', 'salesdude@oasispros.com',
   'N', 'N', 'N', 'Y', 'N',
   'Y', 'N');
__TEXT__;
    mysql_query ($sql);

    $sql = <<<__TEXT__
INSERT INTO
  Users (Login, Password, FirstName, LastName, EmailAddress,
         Campaigns, Advertisers, Sections, Reports, Admin,
         CampaignInsertion, Invoicing)
VALUES 
  ('contentman', password ('pass'), 'Content', 'Man', 'contentman@oasispros.com',
   'Y', 'N', 'N', 'Y', 'N',
   'N', 'N');
__TEXT__;
    mysql_query ($sql);
    $sql = "INSERT INTO CampaignAccess (CampaignID, Login) VALUES (1, 'contentman')";
    mysql_query ($sql);
    $sql = "INSERT INTO CampaignAccess (CampaignID, Login) VALUES (2, 'contentman')";
    mysql_query ($sql);

    $sql = <<<__TEXT__
INSERT INTO
  Users (Login, Password, FirstName, LastName, EmailAddress,
         Campaigns, Advertisers, Sections, Reports, Admin,
         CampaignInsertion, Invoicing)
VALUES 
  ('bizgal', password ('pass'), 'Biz', 'Gal', 'bizgal@oasispros.com',
   'N', 'N', 'N', 'N', 'N',
   'N', 'Y');
__TEXT__;
    mysql_query ($sql);

    $sql = <<<__TEXT__
INSERT INTO
  Users (Login, Password, FirstName, LastName, EmailAddress,
         Campaigns, Advertisers, Sections, Reports, Admin,
         CampaignInsertion, Invoicing)
VALUES 
  ('phb', password ('pass'), 'Pointy-Haired', 'Boss', 'phb@oasispros.com',
   'N', 'N', 'N', 'Y', 'N',
   'N', 'N');
__TEXT__;
    mysql_query ($sql);
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function clear_advertisers ()
{
    $sql = "DELETE FROM Advertisers";
    mysql_query($sql);
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function load_advertisers ()
{
    $sql = <<<__TEXT__
INSERT INTO
  Advertisers (Name, URL, ContactName, StreetAddress, City, State,
    PostalCode, Country, Phone, Fax, ContactEmail, Note, Login, Password)
VALUES 
  ('House', '', '', '', '', '',
   '', '', '', '', 'webmaster@oasispros.com', '', 'house', 'pass');
__TEXT__;
    mysql_query ($sql);

    $sql = <<<__TEXT__
INSERT INTO
  Advertisers (Name, URL, ContactName, StreetAddress, City, State,
    PostalCode, Country, Phone, Fax, ContactEmail, Note, Login, Password)
VALUES 
  ('Anheuser-Busch', 'http://www.anheuser-busch.com/', 'Augustus Busch', 'One Busch Place', 'St. Louis', 'MO',
   '63118', 'USA', '(800) 555-1234', '(800) 555-4321', 'abusch@anheuser-busch.com', '', 'ab', 'pass');
__TEXT__;
    mysql_query ($sql);

    $sql = <<<__TEXT__
INSERT INTO
  Advertisers (Name, URL, ContactName, StreetAddress, City, State,
    PostalCode, Country, Phone, Fax, ContactEmail, Note, Login, Password)
VALUES 
  ('The Boston Beer Company', 'http://www.samadams.com/', 'Jim Koch', '75 Arlington Street', 'Boston', 'MA',
   '02116', 'USA', '(800) 555-2345', '(800) 555-5432', 'jkoch@samadams.com', '', 'bb', 'pass');
__TEXT__;
    mysql_query ($sql);

    $sql = <<<__TEXT__
INSERT INTO
  Advertisers (Name, URL, ContactName, StreetAddress, City, State,
    PostalCode, Country, Phone, Fax, ContactEmail, Note, Login, Password)
VALUES 
  ('Pete\'s Brewing Company', 'http://www.peteswicked.com/', 'Pete Slosberg', '14800 San Pedro Avenue', 'San Antonio', 'TX',
   '78232', 'USA', '(800) 555-3456', '(800) 555-6543', 'pslosberg@peteswicked.com', '', 'pbc', 'pass');
__TEXT__;
    mysql_query ($sql);

    $sql = <<<__TEXT__
INSERT INTO
  Advertisers (Name, URL, ContactName, StreetAddress, City, State,
    PostalCode, Country, Phone, Fax, ContactEmail, Note, Login, Password)
VALUES 
  ('Bass Brewers Ltd.', 'http://www.bass-brewers.com/', 'Rich Barley', '137 High Street
Burton-on-Trent', 'Staffordshire', '',
   'DE14 1JZ', 'UK', '01283 511000', '01283 510001', 'rbarley@bass-brewers.com', '', 'bbl', 'pass');
__TEXT__;
    mysql_query ($sql);

}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function clear_campaigns ()
{
    $sql = "DELETE FROM Creatives";
    mysql_query($sql);

    $sql = "DELETE FROM Campaigns";
    mysql_query($sql);

    $sql = "DELETE FROM CampaignAssignments";
    mysql_query($sql);

    $sql = "DELETE FROM CreativeAssignments";
    mysql_query($sql);

    $sql = "DELETE FROM HourlyStats";
    mysql_query($sql);

    $sql = "DELETE FROM SectionDailyTraffic";
    mysql_query($sql);

    $sql = "DELETE FROM Invoices";
    mysql_query($sql);
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function load_campaigns ()
{
    $sql = <<<__TEXT__
INSERT INTO
  Campaigns (AdvertiserID, Name, Status, StartDate, EndDate,
             ImpressionsGuaranteed, EvenDelivery, ImpressionsDelivered,
             ClicksGuaranteed, ClicksDelivered, DaysOfWeek, HoursOfDay, Weight,
             Note,
             CPM, CPC, Fixed, PayFixed, AgencyCommission,
             PurchaseOrder, ForceInvoice, Notify)
VALUES 
  (1, 'Site-wide House', 'Active', '0000-00-00', '0000-00-00',
   0, NULL, 0,
   0, 0, 127, 16777215, 10,
   'house campaign for all sites',
   0, 0, 0, 'End of Campaign', 0,
   '', 'N', '');
__TEXT__;
    mysql_query ($sql);

    add_image_creative (1, 468, 60, 'Site-wide House 1', 'http://www.oasispros.com/', 'OASIS Professional Services');
    add_image_creative (1, 120, 90, 'Site-wide House 2', 'http://www.oasispros.com/', 'OASIS Professional Services');
    add_rich_creative (1, 468, 60, 'Site-wide House Rich 1', 'http://www.oasispros.com/');
    add_rich_creative (1, 120, 90, 'Site-wide House Rich 2', 'http://www.oasispros.com/');

    add_ca_assignment (1, 1, 'Include');

    $sql = <<<__TEXT__
INSERT INTO
  Campaigns (AdvertiserID, Name, Status, StartDate, EndDate,
             ImpressionsGuaranteed, EvenDelivery, ImpressionsDelivered,
             ClicksGuaranteed, ClicksDelivered, DaysOfWeek, HoursOfDay, Weight,
             Note,
             CPM, CPC, Fixed, PayFixed, AgencyCommission,
             PurchaseOrder, ForceInvoice, Notify)
VALUES 
  (1, 'stlouis.com house', 'Active', '0000-00-00', '0000-00-00',
   0, NULL, 0,
   0, 0, 127, 16777215, 10,
   'house campaign for stlouis.com',
   0, 0, 0, 'End of Campaign', 0,
   '', 'N', '');
__TEXT__;
    mysql_query ($sql);

    add_image_creative (2, 468, 60, 'stlouis.com house 1', 'http://www.oasispros.com/', 'OASIS Professional Services');
    add_image_creative (2, 120, 90, 'stlouis.com house 2', 'http://www.oasispros.com/', 'OASIS Professional Services');

    add_ca_assignment (2, 34, 'Include');


    $sql = <<<__TEXT__
INSERT INTO
  Campaigns (AdvertiserID, Name, Status, StartDate, EndDate,
             ImpressionsGuaranteed, EvenDelivery, ImpressionsDelivered,
             ClicksGuaranteed, ClicksDelivered, DaysOfWeek, HoursOfDay, Weight,
             Note,
             CPM, CPC, Fixed, PayFixed, AgencyCommission,
             PurchaseOrder, ForceInvoice, Notify)
VALUES 
  (2, 'Laclede\'s Sponsorship', 'Active', now(), date_add(now(), INTERVAL 1 YEAR),
   0, NULL, 0,
   0, 0, 127, 16777215, 10,
   'exclusive sponsorship of the landing section',
   0, 0.10, 10000, 'End of Campaign', 15,
   'AB0003', 'N', '');
__TEXT__;
    mysql_query ($sql);

    add_image_creative (3, 468, 60, 'Laclede\\\'s Sponsorship 1', 'http://www.anheuser-busch.com/', 'Anheuser Busch');
    add_image_creative (3, 468, 60, 'Laclede\\\'s Sponsorship 2', 'http://www.anheuser-busch.com/', 'Anheuser Busch');
    add_image_creative (3, 120, 90, 'Laclede\\\'s Sponsorship 3', 'http://www.anheuser-busch.com/', 'Anheuser Busch');

    add_ca_assignment (3, 37, 'Exclusive');


    $sql = <<<__TEXT__
INSERT INTO
  Campaigns (AdvertiserID, Name, Status, StartDate, EndDate,
             ImpressionsGuaranteed, EvenDelivery, ImpressionsDelivered,
             ClicksGuaranteed, ClicksDelivered, DaysOfWeek, HoursOfDay, Weight,
             Note,
             CPM, CPC, Fixed, PayFixed, AgencyCommission,
             PurchaseOrder, ForceInvoice, Notify)
VALUES 
  (2, 'Out-of-market', 'Active', now(), date_add(now(), INTERVAL 3 MONTH),
   100000, 'Month', 0,
   0, 0, 127, 16777215, 10,
   'all sites except stlouis.com',
   4, 0, 0, 'End of Campaign', 15,
   'AB0002', 'N', '');
__TEXT__;
    mysql_query ($sql);

    add_image_creative (4, 468, 60, 'Out-of-market 1', 'http://www.anheuser-busch.com/', 'Anheuser Busch Out-of-market');

    add_ca_assignment (4, 1, 'Include');
    add_ca_assignment (4, 34, 'Exclude');


    $sql = <<<__TEXT__
INSERT INTO
  Campaigns (AdvertiserID, Name, Status, StartDate, EndDate,
             ImpressionsGuaranteed, EvenDelivery, ImpressionsDelivered,
             ClicksGuaranteed, ClicksDelivered, DaysOfWeek, HoursOfDay, Weight,
             Note,
             CPM, CPC, Fixed, PayFixed, AgencyCommission,
             PurchaseOrder, ForceInvoice, Notify)
VALUES 
  (3, 'Pay-per-click', 'Active', now(), '0000-00-00',
   0, NULL, 0,
   0, 0, 127, 16777215, 50,
   'pay-per-click, indefinite, only on dc.com',
   0, 0.25, 0, 'End of Campaign', 0,
   '', 'N', '');
__TEXT__;
    mysql_query ($sql);

    add_image_creative (5, 468, 60, 'Pay-per-click 1', 'http://www.samadams.com/', 'Sam Adams Pay-per-click');

    add_ca_assignment (5, 9, 'Include');


    $sql = <<<__TEXT__
INSERT INTO
  Campaigns (AdvertiserID, Name, Status, StartDate, EndDate,
             ImpressionsGuaranteed, EvenDelivery, ImpressionsDelivered,
             ClicksGuaranteed, ClicksDelivered, DaysOfWeek, HoursOfDay, Weight,
             Note,
             CPM, CPC, Fixed, PayFixed, AgencyCommission,
             PurchaseOrder, ForceInvoice, Notify)
VALUES 
  (3, 'Blitz', 'Active', now(), date_add(now(), INTERVAL 7 DAY),
   25000, 'Day', 0,
   0, 0, 127, 16777215, 10,
   'One-week blitz with fixed, CPM, and CPC, uneven creative weights',
   5, 0.05, 1000, 'End of Campaign', 0,
   '', 'N', '');
__TEXT__;
    mysql_query ($sql);

    add_image_creative (6, 120, 90, 'Blitz 1', 'http://www.samadams.com/', 'Sam Adams Blitz', 10);
    add_image_creative (6, 120, 90, 'Blitz 2', 'http://www.samadams.com/', 'Sam Adams Blitz', 20);

    add_ca_assignment (6, 1, 'Include');


    $sql = <<<__TEXT__
INSERT INTO
  Campaigns (AdvertiserID, Name, Status, StartDate, EndDate,
             ImpressionsGuaranteed, EvenDelivery, ImpressionsDelivered,
             ClicksGuaranteed, ClicksDelivered, DaysOfWeek, HoursOfDay, Weight,
             Note,
             CPM, CPC, Fixed, PayFixed, AgencyCommission,
             PurchaseOrder, ForceInvoice, Notify)
VALUES 
  (3, 'Fridays', 'Active', now(), date_add(now(), INTERVAL 6 MONTH),
   100000, 'Day', 0,
   0, 0, 32, 16777215, 10,
   'Fridays only',
   10, 0.0, 2000, 'End of Campaign', 0,
   '', 'N', '');
__TEXT__;
    mysql_query ($sql);

    add_image_creative (7, 468, 60, 'Fridays 1', 'http://www.samadams.com/', 'Sam Adams Fridays');
    add_image_creative (7, 120, 90, 'Fridays 2', 'http://www.samadams.com/', 'Sam Adams Fridays');

    add_ca_assignment (7, 1, 'Include');


    $sql = <<<__TEXT__
INSERT INTO
  Campaigns (AdvertiserID, Name, Status, StartDate, EndDate,
             ImpressionsGuaranteed, EvenDelivery, ImpressionsDelivered,
             ClicksGuaranteed, ClicksDelivered, DaysOfWeek, HoursOfDay, Weight,
             Note,
             CPM, CPC, Fixed, PayFixed, AgencyCommission,
             PurchaseOrder, ForceInvoice, Notify)
VALUES 
  (4, 'Midwest Campaign', 'Active', now(), date_add(now(), INTERVAL 4 MONTH),
   200000, 'Day', 0,
   0, 0, 127, 16777215, 10,
   'Midwest: chicago.com, stlouis.com',
   8.75, 0.0, 0, 'End of Campaign', 0,
   'PBC0001', 'N', '');
__TEXT__;
    mysql_query ($sql);

    add_image_creative (8, 468, 60, 'Midwest 1', 'http://www.peteswicked.com/', 'Pete\\\'s Wicked Ale: Midwest');
    add_image_creative (8, 468, 60, 'Midwest 2', 'http://www.peteswicked.com/', 'Pete\\\'s Wicked Ale: Midwest');

    add_ca_assignment (8, 1, 'Include');
    add_ca_assignment (8, 9, 'Exclude');
    add_ca_assignment (8, 20, 'Exclude');


    $sql = <<<__TEXT__
INSERT INTO
  Campaigns (AdvertiserID, Name, Status, StartDate, EndDate,
             ImpressionsGuaranteed, EvenDelivery, ImpressionsDelivered,
             ClicksGuaranteed, ClicksDelivered, DaysOfWeek, HoursOfDay, Weight,
             Note,
             CPM, CPC, Fixed, PayFixed, AgencyCommission,
             PurchaseOrder, ForceInvoice, Notify)
VALUES 
  (4, 'East Coast Campaign', 'Active', now(), date_add(now(), INTERVAL 4 MONTH),
   200000, 'Day', 0,
   0, 0, 127, 16777215, 10,
   'East Coast: dc.com, raleigh.com',
   8.75, 0.0, 0, 'End of Campaign', 0,
   'PBC0002', 'N', '');
__TEXT__;
    mysql_query ($sql);

    add_image_creative (9, 468, 60, 'East Coast 1', 'http://www.peteswicked.com/', 'Pete\\\'s Wicked Ale: East Coast');
    add_image_creative (9, 468, 60, 'East Coast 2', 'http://www.peteswicked.com/', 'Pete\\\'s Wicked Ale: East Coast');
    add_image_creative (9, 468, 60, 'East Coast 3', 'http://www.peteswicked.com/', 'Pete\\\'s Wicked Ale: East Coast');
    add_image_creative (9, 468, 60, 'East Coast 4', 'http://www.peteswicked.com/', 'Pete\\\'s Wicked Ale: East Coast');
    add_image_creative (9, 468, 60, 'East Coast 5', 'http://www.peteswicked.com/', 'Pete\\\'s Wicked Ale: East Coast');
    add_image_creative (9, 468, 60, 'East Coast 6', 'http://www.peteswicked.com/', 'Pete\\\'s Wicked Ale: East Coast');

    add_ca_assignment (9, 9, 'Include');
    add_ca_assignment (9, 20, 'Include');


    $sql = <<<__TEXT__
INSERT INTO
  Campaigns (AdvertiserID, Name, Status, StartDate, EndDate,
             ImpressionsGuaranteed, EvenDelivery, ImpressionsDelivered,
             ClicksGuaranteed, ClicksDelivered, DaysOfWeek, HoursOfDay, Weight,
             Note,
             CPM, CPC, Fixed, PayFixed, AgencyCommission,
             PurchaseOrder, ForceInvoice, Notify)
VALUES 
  (5, 'Q1', 'Active', now(), date_sub(date_add(now(), INTERVAL 3 MONTH), INTERVAL 1 DAY),
   150000, 'Week', 0,
   0, 0, 127, 16777215, 10,
   'Q1: 3 months, evenly by week',
   7, 0.0, 0, 'End of Campaign', 0,
   '', 'N', '');
__TEXT__;
    mysql_query ($sql);

    add_image_creative (10, 468, 60, 'Q1 1', 'http://www.bass-brewers.com/', 'Bass Brewers Q1');

    add_ca_assignment (10, 1, 'Include');


    $sql = <<<__TEXT__
INSERT INTO
  Campaigns (AdvertiserID, Name, Status, StartDate, EndDate,
             ImpressionsGuaranteed, EvenDelivery, ImpressionsDelivered,
             ClicksGuaranteed, ClicksDelivered, DaysOfWeek, HoursOfDay, Weight,
             Note,
             CPM, CPC, Fixed, PayFixed, AgencyCommission,
             PurchaseOrder, ForceInvoice, Notify)
VALUES 
  (5, 'Q2', 'Active', date_add(now(), INTERVAL 3 MONTH), date_sub(date_add(now(), INTERVAL 6 MONTH), INTERVAL 1 DAY),
   150000, 'Week', 0,
   0, 0, 127, 16777215, 10,
   'Q2: 3 months, evenly by week',
   7, 0.0, 0, 'End of Campaign', 0,
   '', 'N', '');
__TEXT__;
    mysql_query ($sql);

    add_image_creative (11, 468, 60, 'Q2 1', 'http://www.bass-brewers.com/', 'Bass Brewers Q2');

    add_ca_assignment (11, 1, 'Include');


    $sql = <<<__TEXT__
INSERT INTO
  Campaigns (AdvertiserID, Name, Status, StartDate, EndDate,
             ImpressionsGuaranteed, EvenDelivery, ImpressionsDelivered,
             ClicksGuaranteed, ClicksDelivered, DaysOfWeek, HoursOfDay, Weight,
             Note,
             CPM, CPC, Fixed, PayFixed, AgencyCommission,
             PurchaseOrder, ForceInvoice, Notify)
VALUES 
  (5, 'Q3', 'Active', date_add(now(), INTERVAL 6 MONTH), date_sub(date_add(now(), INTERVAL 9 MONTH), INTERVAL 1 DAY),
   150000, 'Week', 0,
   0, 0, 127, 16777215, 10,
   'Q3: 3 months, evenly by week',
   7, 0.0, 0, 'End of Campaign', 0,
   '', 'N', '');
__TEXT__;
    mysql_query ($sql);

    add_image_creative (12, 468, 60, 'Q3 1', 'http://www.bass-brewers.com/', 'Bass Brewers Q3');

    add_ca_assignment (12, 1, 'Include');


    $sql = <<<__TEXT__
INSERT INTO
  Campaigns (AdvertiserID, Name, Status, StartDate, EndDate,
             ImpressionsGuaranteed, EvenDelivery, ImpressionsDelivered,
             ClicksGuaranteed, ClicksDelivered, DaysOfWeek, HoursOfDay, Weight,
             Note,
             CPM, CPC, Fixed, PayFixed, AgencyCommission,
             PurchaseOrder, ForceInvoice, Notify)
VALUES 
  (5, 'Q4', 'Active', date_add(now(), INTERVAL 9 MONTH), date_sub(date_add(now(), INTERVAL 12 MONTH), INTERVAL 1 DAY),
   150000, 'Week', 0,
   0, 0, 127, 16777215, 10,
   'Q4: 3 months, evenly by week',
   7, 0.0, 0, 'End of Campaign', 0,
   '', 'N', '');
__TEXT__;
    mysql_query ($sql);

    add_image_creative (13, 468, 60, 'Q4 1', 'http://www.bass-brewers.com/', 'Bass Brewers Q4');

    add_ca_assignment (13, 1, 'Include');
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function add_image_creative ($caid, $w, $h, $name, $clickurl, $alt, $weight=10)
{
    static $imagecount = 0;

    #### build an image
    $w1 = $w - 2;
    $h1 = $h - 2;
    `convert -crop {$w1}x{$h1}+1+1 -border 1x1 -dRaw "text 10,15 '$name'" -draw "text 10,35 '$clickurl'" blank{$w}x{$h}.gif temp{$w}x{$h}.gif`;
    if ($fp = fopen ("temp{$w}x{$h}.gif", 'rb')) {
        $imgdata = addslashes (fread ($fp, 65536));
    }

    $sql = <<<__TEXT__
INSERT INTO
  Creatives (CampaignID, Name, Status, StartDate, EndDate,
             Redirect, MediaType, MIMEType, Animated, Width, Height,
             Weight, Content, ClickthroughURL, AltText)
VALUES 
  ($caid, '$name', 'Active', '0000-00-00', '0000-00-00',
   'N', 'Image', 'image/gif', 'N', $w, $h, $weight,
   '$imgdata', '$clickurl', '$alt');
__TEXT__;

    if (!mysql_query ($sql)) {
        print "error: " . mysql_error () . "\n";
    }
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function add_rich_creative ($caid, $w, $h, $name, $clickurl, $weight=10)
{
    static $imagecount = 0;

    $content = <<<__TEXT__
RichMedia: $name ($w x $h)<BR>
CLICK HERE!!! --&gt;
<A HREF="[OASISCLICK:$clickurl]">$clickurl</A>
&lt;-- CLICK HERE!!!
__TEXT__;
    $content = addslashes ($content);

    $sql = <<<__TEXT__
INSERT INTO
  Creatives (CampaignID, Name, Status, StartDate, EndDate,
             Redirect, MediaType, MIMEType, Animated, Width, Height,
             Weight, Content, ClickthroughURL, AltText)
VALUES 
  ($caid, '$name', 'Active', '0000-00-00', '0000-00-00',
   'N', 'RichMedia', 'text/html', 'N', $w, $h, $weight,
   '$content', '$clickurl', '$alt');
__TEXT__;

    if (!mysql_query ($sql)) {
        print "error: " . mysql_error () . "\n";
    }
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
function add_ca_assignment ($caid, $sid, $type)
{
    $sql = "INSERT INTO CampaignAssignments (CampaignID, SectionID, Type) VALUES ($caid, $sid, '$type')";
    if (!mysql_query ($sql)) {
        print "error: " . mysql_error () . "\n";
    }
}

?>
