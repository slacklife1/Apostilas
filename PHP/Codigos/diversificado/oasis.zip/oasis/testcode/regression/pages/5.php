<?php
require("/home/www/html/oasis/oasisi-e.php");
$ad1 = get_creative(5, 468, 60, '');
$ad2 = get_creative(5, 120, 90, '');
?>

<?php echo $ad1; ?>
<?php echo $ad2; ?>
