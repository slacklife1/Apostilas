<?php
require("/home/www/html/oasis/oasisi-e.php");
$ad1 = get_creative(4, 468, 60, '');
$ad2 = get_creative(4, 120, 90, '');
?>

<?php echo $ad1; ?>
<?php echo $ad2; ?>
