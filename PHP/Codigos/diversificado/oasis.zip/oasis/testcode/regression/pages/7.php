<?php
require("/home/www/html/oasis/oasisi-e.php");
$ad1 = get_creative(7, 468, 60, '');
$ad2 = get_creative(7, 120, 90, '');
?>

<?php echo $ad1; ?>
<?php echo $ad2; ?>
