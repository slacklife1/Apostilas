#!/usr/bin/perl
require LWP;
require HTTP::Request;
require HTTP::Response;
#require HTTP::Status;
#require HTTP::Headers;
require LWP::UserAgent;

$ua = new LWP::UserAgent;

@sizes = ('468x60', '120x90');

$clickrate = 0.002;

$| = undef;
(-e "traffic.log")
    ?  open (LOGFILE, ">>traffic.log")
    :  open (LOGFILE, ">traffic.log");
close (LOGFILE);

%pages = (

#### chicago.com
'http://localhost/oasis/regression/3.php' => 667,
'http://localhost/oasis/regression/4.php' => 667,
'http://localhost/oasis/regression/5.php' => 667,
'http://localhost/oasis/regression/6.php' => 667,
'http://localhost/oasis/regression/7.php' => 667,
'http://localhost/oasis/regression/8.php' => 667,

#### dc.com
'http://localhost/oasis/regression/11.html' => 444,
'http://localhost/oasis/regression/12.html' => 444,
'http://localhost/oasis/regression/13.html' => 444,
'http://localhost/oasis/regression/14.html' => 444,
'http://localhost/oasis/regression/15.html' => 444,
'http://localhost/oasis/regression/16.html' => 444,
'http://localhost/oasis/regression/17.html' => 444,
'http://localhost/oasis/regression/18.html' => 444,
'http://localhost/oasis/regression/19.html' => 444,

#### raleigh.com
'http://localhost/oasis/regression/21.html' => 45,
'http://localhost/oasis/regression/22.html' => 45,
'http://localhost/oasis/regression/23.html' => 45,
'http://localhost/oasis/regression/24.html' => 45,
'http://localhost/oasis/regression/27.html' => 45,
'http://localhost/oasis/regression/28.html' => 45,
'http://localhost/oasis/regression/29.html' => 45,
'http://localhost/oasis/regression/30.html' => 45,
'http://localhost/oasis/regression/31.html' => 45,
'http://localhost/oasis/regression/32.html' => 45,
'http://localhost/oasis/regression/33.html' => 45,

#### stlouis.com
'http://localhost/oasis/regression/35.html' => 214,
'http://localhost/oasis/regression/36.html' => 214,
'http://localhost/oasis/regression/37.html' => 214,
'http://localhost/oasis/regression/39.html' => 214,
'http://localhost/oasis/regression/40.html' => 214,
'http://localhost/oasis/regression/41.html' => 214,
'http://localhost/oasis/regression/42.html' => 214,

);

%traffic = (
 0 => 10,
 1 => 20,
 2 => 20,
 3 => 30,
 4 => 30,
 5 => 40,
 6 => 40,
 7 => 40,
 8 => 50,
 9 => 60,
10 => 70,
11 => 80,
12 => 90,
13 => 100,
14 => 100,
15 => 90,
16 => 80,
17 => 70,
18 => 60,
19 => 50,
20 => 30,
21 => 30,
22 => 20,
23 => 10,
);


$page_weight_total = 0;
foreach $page (keys %pages) {
    $page_weight_total += $pages{$page};
}

while (1) {
  $url = getpage ();

  $content = retrieve_url ($url);

  #print "BEFORE:\n$content\n\n";

  #### process the "web pages" and get creatives
  $content = retrieve_iframes ($content);
  $content = retrieve_javascripts ($content);
  retrieve_img_urls ($content);

  #### log the creatives that were seen (we know unless the page uses
  #### IMG tagging) and click through every once in a while
  process_clickthrus ($content);

  #print "AFTER:\n$content\n\n";
  print "\n";

  #### pause for the appropriate time; this gives us an average of about
  #### one request every 6 seconds, which should be enough traffic for our
  #### test data (average based on average of all hourly traffic -- roughly
  #### 50, so 100/50 = 2, so we're getting an interval between 0 and 12
  my ($hour) = (localtime())[2];
  my $interval = rand (6) * (100 / $traffic{$hour});
  select(undef, undef, undef, $interval);
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
sub retrieve_url ()
{
    my ($url) = @_;

    print "getting $url\n";

    my $header = "";
    my $req = "";

    $req = new HTTP::Request('GET', $url);

    #print $req->as_string, "\n\n";

    $resp = $ua->request($req);
    $resp->content;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
sub retrieve_iframes ()
{
    my ($content) = @_;

    $content =~ s#<IFRAME.+?SRC\s*=\s*"(.+?)".+?</IFRAME>#&retrieve_url($1)#gise;

    $content;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
sub retrieve_javascripts ()
{
    my ($content) = @_;

    $newcontent = '';
    while ($content =~ m#<SCRIPT.+?SRC\s*=\s*"(.+?)"#gis) {
        $script_src = $1;
        $script_src =~ s#-j#-i#o;
        $newcontent .= &retrieve_url($script_src);
    }

    ($newcontent) && return $newcontent;

    $content;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
sub retrieve_img_urls ()
{
    my ($content) = @_;

    while ($content =~ m#<IMG.+?SRC\s*=\s*"(.+?)"#gis) {
        &retrieve_url($1);
    }

    $content;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
sub process_clickthrus ()
{
    my ($content) = @_;

    open (LOGFILE, ">>traffic.log");
    while ($content =~ m#"(http://[^"]+?oasisc.php[^"]+?)"#gs) {
        $clickurl = $1;
        print "clickurl: $clickurl\n";
        my ($section)  = ($clickurl =~ m#s=(\d+)#o);
        my ($width)    = ($clickurl =~ m#w=(\d+)#o);
        my ($height)   = ($clickurl =~ m#h=(\d+)#o);
        my ($creative) = ($clickurl =~ m#c=(\d+)#o);

        ($creative) || ($creative = "?");

        $time = localtime ();
        $log_msg = "imp\t$time\t$section\t$creative\t$width\t$height\n";
        print LOGFILE $log_msg;

        my $rand = rand (1000);
        if ($rand < $clickrate * 1000)
        {
            &retrieve_url($clickurl);
            $log_msg = "click\t$time\t$section\t$creative\t$width\t$height\n";
            print LOGFILE $log_msg;
        }
    }
    close (LOGFILE);

    $content;
}


####---------------------------------------------------------------------------
####---------------------------------------------------------------------------
sub getpage ()
{
    $rand = rand ($page_weight_total);
    $tot = 0;
    foreach $page (keys %pages) {
        $tot += $pages{$page};
        if ($tot > $rand) {
            return $page;
        }
    } 
    return $page;
}
