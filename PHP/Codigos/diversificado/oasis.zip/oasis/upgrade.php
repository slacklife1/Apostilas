#!/usr/local/bin/php -q
<?php

require("install-lib.php");

$setup = array();

$stdin = fopen('php://stdin', 'r');

get_setup_vals();

create_directories($setup);

?>
