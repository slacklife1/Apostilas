<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Informium General Configuration (inf-conf.php)
//
// Author: Cameron McKay
// Note:   This contains all the general information need for Informium to operate.
//

// WWW Root Address (no trailing slash).
$CONF[www_address] = 'http://127.0.0.1';

// WWW Cookie Address (no trailing slash).
$CONF[www_cookie]  = '127.0.0.1';

// WWW Title.
$CONF[www_title]   = "Informium Powered Website";

// LOCAL Absolute Path (no trailing slash).
$CONF[local_path]  = 'C:/Cameron/WWW/informium';

// Template Set.
// Included by default:
// - zorp
$CONF[template_set]   = 'zorp';
$CONF[template_local] = $CONF[local_path]  . '/engine/tmpl/' . $CONF[template_set];
$CONF[template_www]   = $CONF[www_address] . '/engine/tmpl/' . $CONF[template_set];

// 0. Disallow use of HTML.
// 1. Allow use of HTML.
// 2. Allow use of HTMLi. (default)
//    HTMLi (HTML-Informium) is just regular HTML except it only allows certain tags.
//    Allowed tags are:
//    <b></b>
//    <i></i>
//    <u></u>
//    <br>
//    <a>
// 3. Allow use of user-selected HTML.
$CONF[html_enable] = 3;

// If you chose option "3" above, then define which tags should be allowed.
// NOTE: This will be ignored unless option "3" is selected.
$CONF[html_tags] = '<b>,<i>,<u>,<br>,<a>,<img>,<font>';

// Require Authentication... TRUE for yes, FALSE for no.
// Users will be required to login to see news and comment if this is set to TRUE.
$CONF[auth_enable] = TRUE;

// Allow 'Anonymous' posting... TRUE for yes, FALSE for no.
$CONF[anon_enable] = TRUE;

// Comment Edit Notify ... by enabling this, an (Edited by ...) tag is added to all edited comments.
$CONF[edit_notify] = TRUE;

// Archive Method...
// 0. Weekly.  // Not Implemented.
// 1. Monthly.
$CONF[archive_method] = 1;

// Article Limit ... the number of articles to show on the main page.
$CONF[article_limit]  = 8;

// Article Title Limit ... the amount of characters allowed in the article title, from 0-64.
$CONF[article_tlimit] = 64; // Not Implemented.

// Comment Limit ... the number of comments to show per page.
$CONF[comment_limit]  = 20;

// Comment Title Limit ... the amount of characters allowed in the comment title, from 0-64.
$CONF[comment_tlimit] = 20; // Not Implemented.

// Dropdown Limit ... the number of articles to show in a dropdown.
$CONF[dropdown_limit] = 20;

// Possible Ciphers... you may disable possible ciphers if you so choose to.
// These are what is used to encrypt passwords.
// PTXT -> Plain Text (Not technically a cipher).
// DES  -> Pretty much what every UNIX variant uses.
// MD5  -> Probably the strongest default encryption PHP has.
// RT13 -> ROT13 cipher, not very strong at all, but slightly better than plaintext.
$CONF[cipher_list] = array('MD5','DES','PTXT','RT13','NUNE');

// Access Level Definitions... this is pretty much eye candy.  All it
// changes is what it says beside the number in the add or edit user menu.
$CONF[access_list]['-4'] = 'Deleted Administrator';
$CONF[access_list]['-3'] = 'Deleted Moderator';
$CONF[access_list]['-2'] = 'Deleted Member';
$CONF[access_list]['-1'] = 'Deleted User';
$CONF[access_list]['1']  = 'User';
$CONF[access_list]['2']  = 'Member';
$CONF[access_list]['3']  = 'Moderator';
$CONF[access_list]['4']  = 'Administrator';

// Access Level Count...
// Number of access levels (for every access level there must be a negative 'deleted' equivalent).
$CONF[access_count] = 4;

// Article Date Format... see documentation on date() at www.php.net/manual for more information.
$CONF[article_date] = "Y/m/d H:i:s";

// Comment Date Format... see documentation on date() at www.php.net/manual for more information.
$CONF[comment_date] = "Y/m/d H:i:s";

// User Date Format... see documentation on date() at www.php.net/manual for more information.
$CONF[user_date] = "Y/m/d H:i:s";

//
// ** NOTE **
// Remember to edit 'mysql-class.php' to your proper database values.
//

// ** Don't Touch -- Unless you're programming. **

// Tell Informium that the configuration is loaded.
$INF[CONF] = TRUE;

?>
