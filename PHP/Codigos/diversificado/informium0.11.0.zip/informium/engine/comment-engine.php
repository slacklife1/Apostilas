<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Comment Display Script (comment-engine.php)
//
// Author: Cameron McKay
// Note:   Displays the comment in the database.
//

// Import CONF.
require_once('conf/inf-conf.php');

// Import COMMENT and MYSQL classes, if needed.
require_once("$CONF[local_path]/class/comment-class.php");
require_once("$CONF[local_path]/class/mysql-class.php");

// Create new COMMENT and MYSQL objects.
$comment = new comment();
$db      = new mysql();

// Connect to the DB.
$db->pconnect();

// Prepare and execute the query.
$query  = "SELECT * FROM comments WHERE assoc_id='$post_id' ORDER BY create_date ASC";
$result = $db->query($query);

// Cycle through the result, showing the news items.
while ($list = $db->fetch_array($result))
{
	// Use the prepare() routine to prepare the list.
	$list = $comment->prepare($list);

	// Add in the template.
    include("engine/tmpl/$CONF[template_set]/comment-post.php");
}

// Free the result.
$db->free($result);

?>