<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Comment Form Display Script (form-engine.php)
//
// Author: Cameron McKay
// Note:   Displays the comment form for adding comments.
//

// Import CONF.
require_once('conf/inf-conf.php');

// Import MYSQL and SYSTEM classes, if need.
require_once("$CONF[local_path]/class/comment-class.php");
require_once("$CONF[local_path]/class/cookie-class.php");
require_once("$CONF[local_path]/class/mysql-class.php");
require_once("$CONF[local_path]/class/system-class.php");
require_once("$CONF[local_path]/class/user-class.php");

// Create new MYSQL and SYSTEM objects.
$comment = new comment();
$cookie  = new cookie();
$db      = new mysql();
$system  = new system();
$user    = new user();

// Determine some variables.
$list[assoc_id]     = $assoc_id;
$list[ip]           = $REMOTE_ADDR;
$list[host]         = gethostbyaddr($REMOTE_ADDR);
$list[link_post]    = "index.php?post_id=$assoc_id";
$list[link_add]     = "comment.php?exec=add&post_id=$assoc_id";
$list[link_root]    = $CONF[www_address];
$list[current_date] = $system->date_format(0, 'now', 'news');

// Determine if we're logged on.
if ($cookie->status($COOKIE_LOGIN)) {

	// If we are, then create values for the current username and password.
	list($list[username], $list[password]) = $cookie->decode($COOKIE_LOGIN);

}

// If we're adding a comment then add_comment will be set.
if (isset($add_comment)) {

	// Make sure the posts contain text in title and text areas.
	if (!preg_match('/\w/', $title) || !preg_match('/\w/', $text)) {

		// If not, then we error out.
		$result = 0;

		// Set the error message.
		$message = "One or more missing fields.<br />\n";

	// Check if we're anonymous...
	} else if (!strcasecmp($username, 'anonymous') || !strcmp($username, '')) {

		$username = 'Anonymous';
		$password = '';

		// Check if anonymous posting is allowed.
		if ($CONF[anon_enable] == TRUE) {
			// Then affirm the user exists.			
			$result = 123;

		// Otherwise...
		} else {
			// The user is not allowed to post.
			$result = 0;

			// Set the error message.
			$message = "Anonymous posting disabled.<br />\n";

		}
	
	// If we're not anonymous, preceed as normal...
	} else { 

		// Check if the user exists.
		$result = $user->check($username);

	}

	// If it does, then authenticated.
	if ($result > 0) {

		// Check if they're authorized (if the 'result' is 123 then we're anonymous).
		if ($user->authenticate($username, $password) || $result == 123) {

			// If they are then add the comment.
			$comment->add($user->to_id($username), $assoc_id, 'T_ARTICLE', $title, $text);

			// Set the error message.
			$message = "Thank you for your comment.<br />\n";
			
		// Otherwise leave an error message.
		} else {

			// Set the error message.
			$message = "Incorrect password.<br />\n";

		}

	// If it doesn't then refuse authorization.
	} else if ($result == 0) {

		// Set the error message if it's not set.
		if(strlen($message) < 1) {
			$message = "Username does not exist.<br />\n";

		}
	
	// If there are illegal characters then inform the user.
	} else if ($result < 0) {

		// Set the error message.
		$message = "Username contains illegal characters.<br />\n";

	// Otherwise something went screwy.
	} else {

		// Set the error message.
		$message = "Something went horribly, horribly wrong.<br />\n";

	}

	// Determine some additional variables.
	$list[message]   = $message;

	// Add in the template.
	include("engine/tmpl/$CONF[template_set]/comment-mesg.php");

} else {

	// Add in the template.
	include("engine/tmpl/$CONF[template_set]/comment-form.php");

}

?>