<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Comment Message Display Template (comment-mesg.php)
//
// Author: Cameron McKay
// Note:   Used to format comment message appearance.
//

//
// Informium Standard Template
// ---------------------------
// Template:  Zorp (Informium Default)
// PageClass: CommentMessage
// Author:    Cameron McKay
// License:   BSD License
// Version:   1.0.0
//

//
// Standard PHP 4 code is valid.
//
// The following variables are valid:
//
// $list[message]   -> The message for the user.
// $list[link_post] -> The link back to the original post.
// $list[link_root] -> The link back to the WWW root.
//

?>

<!-- Zorp Border Table -->
<table class='news_outline' width='600' cellpadding='2' cellspacing='0' border='0'>
<tr>
<td>

<!-- Zorp Inner Table  -->
<table class='news_normal' width='100%' cellpadding='6' cellspacing='0' border='0' align='center'>
<tr>
<td>

<? echo $list[message]; ?>
<br />
<a href='<? echo $list[link_post]; ?>'>Return to Article?</a><br />
<a href='<? echo $list[link_root]; ?>'>Return to Front Page?</a>

<!-- END Zorp Inner Table  -->
</td>
</tr>
</table>

<!-- END Zorp Border Table -->
</td>
</tr>
</table>