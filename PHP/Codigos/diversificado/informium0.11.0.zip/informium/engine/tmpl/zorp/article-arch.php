<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Archived Article Display Template (article-arch.php)
//
// Author: Cameron McKay
// Note:   Used to format archived article list appearance.
//

//
// Informium Standard Template
// ---------------------------
// Template:  Zorp (Informium Default)
// PageClass: ArticleArchive
// Author:    Cameron McKay
// License:   BSD License
// Version:   1.0.0
//

//
// Standard PHP 4 code is valid.
//
// The following variables are valid:
//
// $list -> The databases month's and date's.
// NOTE: This system will change in later releases as I don't like it :)
//

// -- Start Template Here --

?>

<!-- Zorp Border Table -->
<table class='news_outline' width='600' cellpadding='2' cellspacing='0' border='0'>
<tr>
<td>

<!-- Zorp Inner Table  -->
<table class='news_normal' width='100%' cellpadding='6' cellspacing='0' border='0' align='center'>
<tr>
<td>

<font class='news_title'>
<b>Archived Articles</b><br />
</font>

<br />

<center>
<? 

// Cycle through date keys.
for ($i = 0; $i < count($list); ++$i) {

	// Split the year and month into separate variables.
	list($year, $month) = split('-', $list[$i]);

	// Link 'em.
	echo "<a href='$CONF[www_address]/index.php?lookup=$list[$i]'>Month $month - Year $year</a><br />";

}

?>
</center>

<br />

<!-- END Zorp Inner Table  -->
</td>
</tr>
</table>

<!-- END Zorp Border Table -->
</td>
</tr>
</table>