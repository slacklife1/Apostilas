<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Comment Display Template (comment-post.php)
//
// Author: Cameron McKay
// Note:   Used to format comment appearance.
//

//
// Informium Standard Template
// ---------------------------
// Template:  Zorp (Informium Default)
// PageClass: CommentPost
// Author:    Cameron McKay
// License:   BSD License
// Version:   1.0.0
//

//
// Standard PHP 4 code is valid.
//
// The following variables are valid:
//
// $list[comment_id]  -> The comment's comment_id.
// $list[assoc_id]    -> The comment's assoc_id.
// $list[user_id]     -> The comment's user_id.
// $list[username]    -> The comment's author.
// $list[email]       -> The comment's author's email address.
// $list[host]        -> The comment's host address.
// $list[ip]          -> The comment's IP address.
// $list[title]       -> The comment's title.
// $list[text]        -> The comment's text.
// $list[create_date] -> The comment's date of creation.
// $list[modify_date] -> The comment's date of modification.
//
// $list[link_comment] -> Link to the add comment form.
// $list[link_root]    -> Link to the Informium WWW address.
//

?>

<a name='cid:<? echo $list[comment_id]; ?>'></a>
<a name='commentid-<? echo $list[comment_id]; ?>'></a>

<!-- Zorp Border Table -->
<table class='comment_outline' width='600' cellpadding='2' cellspacing='0' border='0'>
<tr>
<td>

<!-- Zorp Inner Table  -->
<table class='comment_normal' width='100%' cellpadding='6' cellspacing='0' border='0' align='center'>
<tr>
<td>

<font class='comment_title'><? echo $list[title]; ?></font>
<font class='small'> by <a href='mailto:<? echo $list[email]; ?>'><? echo $list[username] ;?></a> @ <? echo $list[create_date]; ?> 
(<a href='<? echo "$CONF[www_address]/index.php?post_id=$list[assoc_id]#commentid-$list[comment_id]"; ?>'>#<? echo $list[comment_id]; ?></a>) 
<a title='IP: <? echo $list[ip]; ?> Host: <? echo $list[host]; ?>'>{info}</a>
<br />
</font>

</small>
<br />

<? echo $list[text]; ?>
<br />
<br />

<font class='small'>
<a href='<? echo $list[link_comment]; ?>'>Add Comment</a> 
| 
<a href='<? echo $list[link_root]; ?>'>Front Page</a>
</font>

<!-- END Zorp Inner Table  -->
</td>
</tr>
</table>

<!-- END Zorp Border Table -->
</td>
</tr>
</table>

<br />