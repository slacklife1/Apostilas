<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Article Display Template (article-post.php)
//
// Author: Cameron McKay
// Note:   Used to format article appearance.
//

//
// Informium Standard Template
// ---------------------------
// Template:  Zorp (Informium Default)
// PageClass: ArticleMore
// Author:    Cameron McKay
// License:   BSD License
// Version:   1.0.0
//

//
// Standard PHP 4 code is valid.
//
// The following variables are valid:
//
// $list[post_id]       -> The article's post_id.
// $list[user_id]       -> The article's user_id.
// $list[username]      -> The article's author.
// $list[email]         -> The article's author's email address.
// $list[title]         -> The article's title.
// $list[text]          -> The article's text.
// $list[more_text]     -> The article's extended text.
// $list[create_date]   -> The article's date of creation.
// $list[modify_date]   -> The article's date of modification.
// $list[comment_count] -> The article's comment count.
//
// $list[link_add]      -> The add comment link.
// $list[link_comment]  -> The article's extended text and comments link.
// $list[link_root]     -> The link back to the front page.
//
// $list[section_name]  -> The section's section_name.
// $list[section_link]  -> The section's link.
// $list[section_image] -> The section's image link.
//

// -- Start Template Here --

?>

<a name='postid-<? echo $list[post_id]; ?>'></a>

<!-- Zorp Border Table -->
<table class='news_outline' width='600' cellpadding='2' cellspacing='0' border='0'>
<tr>
<td>

<!-- Zorp Inner Table  -->
<table class='news_normal' width='100%' cellpadding='6' cellspacing='0' border='0' align='center'>
<tr>
<td width='64' valign='top'>
<a href='<? echo $list[section_link]; ?>'><img src='<? echo $list[section_image]; ?>' /></a>
</td>
<td>

<font class='news_title'>
<b><? echo $list[title]; ?></b><br />
</font>
<font class='small'>
<a href='mailto:<? echo $list[email]; ?>'><? echo $list[username] ;?></a>
@ <? echo $list[create_date]; ?> 
(<a href='<? echo $list[section_link]; ?>'><? echo $list[section_name]; ?></a>)
</font>
<br />
<br />

<? echo $list[text]; ?>
<br />
<br />

<? echo $list[more_text]; ?>
<br />
<br />

<font class='small'>
<a href='index.php<? echo $list[link_comment]; ?>'><u><? echo $list[comment_count]; ?></u> Comment(s)</a>
|
<a href='<? echo $list[link_add]; ?>'>Add Comment</a> 
| 
<a href='<? echo $list[link_root]; ?>'>Front Page</a>
</font>

<!-- END Zorp Inner Table  -->
</td>
</tr>
</table>

<!-- END Zorp Border Table -->
</td>
</tr>
</table>

<br />