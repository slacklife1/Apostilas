<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Comment Display Template (comment-post.php)
//
// Author: Cameron McKay
// Note:   Used to format comment appearance.
//

//
// Informium Standard Template
// ---------------------------
// Template:  Zorp (Informium Default)
// PageClass: CommentForm
// Author:    Cameron McKay
// License:   BSD License
// Version:   1.0.0
//

//
// Standard PHP 4 code is valid.
//
// The following variables are valid:
//
// $list[assoc_id]     -> The comment's associated post_id or comment_id.
// $list[ip]           -> The comment poster's IP Address.
// $list[host]         -> The comment poster's Host Address.
// $list[current_date] -> The current date and time.
// $list[username]     -> The currently logged in user's username (only guarenteed if auth_enable is turned on).
// $list[password]     -> The currently logged in user's password (only guarenteed if auth_enable is turned on).
//

?>

<form action='' method='post'>

<!-- Zorp Border Table -->
<table class='news_outline' width='600' cellpadding='2' cellspacing='0' border='0'>
<tr>
<td>

<!-- Zorp Inner Table  -->
<table class='news_normal' width='100%' cellpadding='6' cellspacing='0' border='0' align='center'>
<tr>
<td>

<br />
<center><font class='news_title'>Article #<? echo $list[assoc_id]; ?></font></center>
<table class='news_normal' width='100%' cellpadding='5' cellspacing='0' border='0' align='center'>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr>
<td>Title:</td>
<td><input class='outline' type='text' name='title' value="" size='40' /></td>
</tr>
<tr>
<td>Username:</td>
<td><input class='outline' type='text' name='username' value="<? echo $list[username]; ?>" size='30' /></td>
</tr>
<tr>
<td>Password:</td>
<td><input class='outline' type='password' name='password' value="<? echo $list[password]; ?>" size='30' /></td>
</tr>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr>
<td>Date:</td>
<td><b><? echo $list[current_date]; ?></b></td>
</tr>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr>
<td>Text:</td>
<td><textarea name='text' rows='7' cols='50'></textarea><br /></td>
</tr>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr>
<td>&nbsp;</td>
<td><input type='checkbox' name='auto_newl' checked='checked' />&nbsp;Convert New Lines to Line Breaks.</td>
</tr>
<tr>
<td>&nbsp;</td>
<td><input type='checkbox' name='auto_link' checked='checked' />&nbsp;Automatic URL Hyperlink.</td>
</tr>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr>
<td>&nbsp;</td>
<td><input class='outline' type='submit' name='add_comment' value='Add Comment'> <input class='outline' type='reset' value='Reset'></td>
</tr>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</table>

<!-- END Zorp Inner Table  -->
</td>
</tr>
</table>

<!-- END Zorp Border Table -->
</td>
</tr>
</table>

</form>

<br />