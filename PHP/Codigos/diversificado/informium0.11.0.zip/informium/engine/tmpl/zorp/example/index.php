<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Index Template (index.php)
//
// Author: Cameron McKay
// Note:   This is merely a sample of what the main page of your
//         website would look like.
//

//
// Informium Standard Template
// ---------------------------
// Template:  Zorp (Informium Default)
// PageClass: IndexTemplate
// Author:    Cameron McKay
// License:   BSD License
// Version:   1.0.0
//
// Required Calls:
// require_once('conf/inf-conf.php')
// require_once('engine/init-engine.php');
// require_once("$CONF[template_local]/stylesheet.php");
// require_once("engine/redirect-engine.php");
//

// Import CONF.
// Initialize Informium.
require_once('conf/inf-conf.php');
require_once('engine/init-engine.php');

?>
<html>

<head>
<title>Informium -- Advanced News Script</title>
<? require_once("$CONF[template_local]/stylesheet.php"); ?>
</head>

<!-- Eliminate Margins. -->
<body leftmargin='0' topmargin='0' marginwidth='0' marginheight='0'>

<!-- ** Main Table ** -->
<table width='100%' cellpadding='15' cellspacing='0' border='0' height='100%'>
<tr valign='top'>

<td class='pane_left' width='200'>
  &nbsp;&nbsp;<a href='<? echo $CONF[www_address]; ?>'>Go to Front Page</a><br />
  &nbsp;&nbsp;<a href='<? echo $CONF[www_address]; ?>/admin/admin.php'>Go to Admin. Area</a><br />
  &nbsp;&nbsp;<a href='<? echo $CONF[www_address]; ?>/index.php?do=archives'>Go to Archives Area</a><br />
</td>
  
<td class='pane_right'>
<? require_once("engine/redirect-engine.php"); ?>
</td>

</tr>
</table>
<!-- ** END Main Table ** -->

</body>

</html>