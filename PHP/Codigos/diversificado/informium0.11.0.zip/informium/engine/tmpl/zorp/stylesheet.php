<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Stylesheet Template (stylesheet.php)
//
// Author: Cameron McKay
// Note:   Used to format entire template.
//

//
// Informium Standard Template
// ---------------------------
// Template:  Zorp (Informium Default)
// PageClass: StyleSheet
// Author:    Cameron McKay
// License:   BSD License
// Version:   1.0.0
//

$font_family  = 'Verdana, Helvetica, Arial, Sans-serif';
$font[small]  = '8pt';
$font[medium] = '10pt';
$font[large]  = '12pt';

$colour[border] = '#000000';

$colour[pane_l_back] = '#004D73';
$colour[pane_l_text] = '#FFFFFF';

$colour[pane_r_back] = '#EEEEEE';
$colour[pane_r_text] = '#FFFFFF';

$colour[news_back]    = '#004D73';
$colour[news_text]    = '#FFFFFF';
$colour[news_outline] = '#808080';

$colour[comment_back]    = '#0C6793';
$colour[comment_text]    = '#FFFFFF';
$colour[comment_outline] = '#808080';

//
// Function: e ( $variable )
//
// Purpose:  A quick and easy way of saying echo().
//
// Returns:  Nothing.
//

function e($variable)
{
	// Echo the variable.
	echo $variable;
}

?>

<style>

body  { font-family: <? e($font_family); ?>; font-size: <? e($font[medium]); ?>; } 
td    { font-family: <? e($font_family); ?>; font-size: <? e($font[medium]); ?>; }
pre   { font-family: monospace;              font-size: <? e($font[medium]); ?>; }        

.small  { font-family: <? e($font_family); ?>; font-size: <? e($font[small]);  ?>; }
.medium { font-family: <? e($font_family); ?>; font-size: <? e($font[medium]); ?>; }
.large  { font-family: <? e($font_family); ?>; font-size: <? e($font[large]);  ?>; }                                 
                                                   
.pane_left {
	background-color: <? e($colour[pane_l_back]); ?>;
	color:            <? e($colour[pane_l_text]); ?>;
}

.pane_right {
	background-color: <? e($colour[pane_r_back]); ?>;
	color:            <? e($colour[pane_r_text]); ?>;
}

.news_normal { 
	background-color: <? e($colour[news_back]); ?>;
	color:            <? e($colour[news_text]); ?>;
}

.comment_normal {
	background-color: <? e($colour[comment_back]); ?>;
	color:            <? e($colour[comment_text]); ?>;
}

.news_title {
	background-color: <? e($colour[news_back]); ?>;
	color:            <? e($colour[news_text]); ?>;
	font-size:        <? e($font[large]); ?>;
	font-weight:      bold;
}

.comment_title  {
	background-color: <? e($colour[comment_back]); ?>;
	color:            <? e($colour[comment_text]); ?>;
	font-size:        <? e($font[medium]); ?>;
	font-weight:      bold;
}

.news_outline {
	background-color: <? e($colour[news_outline]); ?>;
}

.comment_outline {
	background-color: <? e($colour[comment_outline]); ?>;
}

input.outline {
	font-family:      <? e($font_family); ?>;
	font-size:        <? e($font[medium]); ?>;
	background-color: #FFFFFF;
	border-color:     #808080;
	border-style:     solid;
}

input.normal {
	font-family:      <? e($font_family); ?>;
	font-size:        <? e($font[medium]); ?>;
	background-color: #FFFFFF;
}

select {
	font-family:      <? e($font_family); ?>;
	font-size:        <? e($font[medium]); ?>;
	background-color: #FFFFFF;
	border-color:     #808080;
	border-style:     solid;
}

textarea {
	font-family:      <? e($font_family); ?>;
	font-size:        <? e($font[medium]); ?>;
	background-color: #FFFFFF;
	border-color:     #808080;
	border-style:     solid;
}

a {
	text-decoration:  none;
	font-style:       none;
	font-weight:      bold;
	color:            #92C000;
}

a:hover {
	text-decoration:  none;
	font-style:       none;
	color:            #808080;
}

</style>