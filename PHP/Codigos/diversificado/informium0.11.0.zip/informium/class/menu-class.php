<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Menu Class (menu-class.php)
//
// Author: Cameron McKay
// Note:   Class for constructing Informium menus.
//

class menu
{
	var $access;		// Access Level.
	var $access_title;	// Access Title.

	var $title_list;	// Access Title List.

	var $menu;		// The menu array.

	// Menu Constructor.
	function menu ($access)
	{
		// Define the access level for the user.
		$this->access = $access;

		// Define Access Title List.
		$this->title_list[0] = 'User';
		$this->title_list[1] = 'Member';
		$this->title_list[2] = 'Moderator';
		$this->title_list[3] = 'Administrator';

		// Define the title for this user.
		$this->access_title = $this->title_list[$access];

	}

	//
	// Function: add ( $name, $address, $access )
	//
	// Purpose:  Inserts the menu option into the structure (I know, sooooo descriptive).
	//
	// Arguments:
	//   $name    -> The option's name (i.e. 'Insert New Article').
	//   $address -> The address of the option (i.e. 'admin.article.php?command=add').
	//   $access  -> The minimum access for that option (i.e. '1').
	//
	// Returns:  Nothing.
	//

	function add($name, $address, $access)
	{
		// Make it easier to reference.
		$menu =& $this->menu[];

		// Copy the values to the array.
		// Check if the 'name' field is SPECIAL (denoted by 123).
		if (!strncmp('123', $name, 3)) {
			$name = substr($name, 3);
			$menu[name] = $name;
		
		} else {
			$menu[name]    = '&nbsp;&nbsp;&nbsp;' . $name;

		}

		$menu[address] = $address;
		$menu[access]  = $access;
	}

	//
	// Function: put ( )
	//
	// Purpose:  Prints a stylized menu for the access level defined by 'access' when the
	//           object was made.
	//
	// Returns:  Nothing.
	//

	function put()
	{
		// Copy variables to easier to type ones.
		// Print.

		for ($i = 0; $i < count($this->menu); ++$i) {

			// Reference variable to easier name.
			$option =& $this->menu[$i];

			// Check access.
			if ($this->access >= $option[access])
				echo "<option value='$option[address]'>$option[name]</option>\n";

		}
	}
}
