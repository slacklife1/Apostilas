<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Article Class (article-class.php)
//
// Author: Cameron McKay
// Note:   Class that allows for the manipulation of articles.
//

class article
{
	// Constructor function.
	function article()
	{
		// Does nothing.
	}

	//
	// Function: add ( $section_id, $user_id, $title, $text, $more_text )
	//
	// Purpose:  Adds an article to the Informium database.
	//
	// Arguments:
	//   $user_id    -> The user's user_id.
	//   $section_id -> The article's section_id.
	//   $title      -> The article's title.
	//   $text       -> The article's text.
	//   $more_text  -> The article's extended text.
	//	
	// Returns:  The new post_id, or -1 for empty field.
	//

	function add ($section_id, $user_id, $title, $text, $more_text)
	{
		// Call the post() function to insert the article.
		return $this->post(0, $section_id, $user_id, $title, $text, $more_text);
	}

	//
	// Function: edit ( $post_id, $section_id, $user_id, $title, $text, $more_text, $UPDATE = NULL )
	//
	// Purpose:  Edits an article in the Informium database.
	//
	// Arguments:
	//   $post_id    -> The article's post_id.
	//   $section_id -> The article's section_id.
	//   $user_id    -> The user's user_id.
	//   $title      -> The article's title.
	//   $text       -> The article's text.
	//   $more_text  -> The article's extended text.
	//
	// Returns:  The post_id, or -1 for empty field.
	//

	function edit ($post_id, $section_id, $user_id, $title, $text, $more_text)
	{
		// Call the post() function to update the article.
		return $this->post($post_id, $section_id, $user_id, $title, $text, $more_text);
	}

	//
	// Function: delete ( $post_id )
	//
	// Purpose:  Deletes an article in the Informium database.
	//
	// Arguments:
	//   $post_id -> The article's post_id.
	//
	// Returns:  Nothing.
	//

	function delete ($post_id)
	{
		// Import CONF.
		global $CONF;

		// Import the MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Create a new MYSQL object.
		$db = new mysql();

		// Connect to the DB.
		$db->pconnect();

		// Prepare and execute the query.
		$query  = "DELETE FROM news WHERE post_id='$post_id'";
		$result = $db->query($query);
	}

	//
	// Function: post ( $post_id, $section_id, $user_id, $title, $text, $more_text)
	//
	// Purpose:  Adds or edits a post into the database.
	//
	// Arguments:
	//   $post_id    -> The article's post_id.  If '0', then the post is new.
	//   $section_id -> The article's section_id.
	//   $user_id    -> The user's user_id.
	//   $title      -> The article's title.
	//   $text       -> The article's text.
	//   $more_text  -> The article's extended text.
	//
	// Returns:  The new post_id, or -1 for empty field.
	//
	
	function post ($post_id, $section_id, $user_id, $title, $text, $more_text)
	{
		// Import CONF, cookie, and auto-options.
		global $CONF, $COOKIE1, $REMOTE_ADDR, $auto_newl, $auto_link;

		// Import COOKIE, MYSQL, SECTION, SYSTEM and USER classes, if needed.
		require_once("$CONF[local_path]/class/cookie-class.php");
		require_once("$CONF[local_path]/class/mysql-class.php");
		require_once("$CONF[local_path]/class/section-class.php");
		require_once("$CONF[local_path]/class/system-class.php");
		require_once("$CONF[local_path]/class/user-class.php");
 
		// Make new COOKIE, MYSQL, SECTION, SYSTEM and USER objects.
		$cookie  = new cookie();
		$db      = new mysql();
		$section = new section();
		$system  = new system();
		$user    = new user();

		// Make sure we have a valid section_id.
		if(!$section->check($section_id)) {
			return -1;

		}

		// Check to make sure 'more_text' is not blank.
		if (strlen($more_text) < 1) {
			$more_text = '---';

		}

		// Put the arguments in a list for easier manipulation.
		$list = array($title, $text, $more_text);

		// Check if we need to strip html.
		if ($CONF[html_enable] == 0)
			// No tags allowed.
			$allow = '';

		// Check if we're using HTML-Informium.
		else if ($CONF[html_enable] == 2)
			$allow = '<b>,<i>,<u>,<br>,<a>';

		// Check if we're using user defined HTML.
		else if ($CONF[html_enable] == 3)
			// Allow user defined tags.
			$allow = $CONF[html_tags];

		// Manipulate the data as needed.
		for ($i = 0; $i < count($list); ++$i) {

			// Check if we want to convert newlines to line breaks.
			if ($auto_newl)
				$list[$i] = $system->auto_newl($list[$i]);

			// Check if we want to automatically link hyperlinks.
			if ($auto_link)
				$list[$i] = $system->auto_link($list[$i]);
						
			// Strip HTML (if needed).
			if ($CONF[html_enable] != 1)
				$list[$i] = strip_tags($list[$i], $allow);

			// Check if the string contains data.
			if(strlen($list[$i]) < 1) {

				// Return the 'empty field' error.
				return -1;

			}

			// Add slashes.
			$list[$i] = addslashes($list[$i]);

		}

		// Check if we have a post_id that's greater than 0.  If we do, then
		// we're merely updating a post.
		if ($post_id > 0) {

			// If user_id is 0, then we use the article's user_id, otherwise use the supplied user_id.
			if ($user_id == 0 || $user->info(0, 'access') < 3) {

				// Get the user_id for this article.
				$user_id = $this->info($post_id, 'user_id');

			}

			// Get the original create_date (since UPDATE automatically changes the timestamp...)
			$create_date = $this->info($post_id, 'create_date');

			// Prepare the update.
			$query = "UPDATE news SET
					section_id='$section_id',
					user_id='$user_id',
					title='$list[0]',
					text='$list[1]', 
					more_text='$list[2]', 
					create_date='$create_date', 
					modify_date=NOW()
					WHERE post_id=$post_id"; 

		// Otherwise we're adding a new one.
		} else { 

			// If user_id is 0, then we use the cookie, otherwise we use the supplied user_id.
			if ($user_id == 0 || $user->info(0, 'access') < 3) {

				// Get the user_id for this user.
				if(!(list($user_id, $username, $password, $ip) = $cookie->decode($COOKIE1)))	
					die("INFORMIUM: Cookie values illegally changed.<br />\n");

			}

			// Prepare the addition.
			$query  = "INSERT INTO news VALUES('', $section_id, $user_id, '$list[0]', '$list[1]', '$list[2]', now(), now())";

		}

		// Connect to the DB.
		$db->pconnect();

		// Execute the query.
		$db->query($query);

		// Fetch the post_id for return, if needed.
		if ($post_id < 1) {
			$post_id = $db->insert_id();

		}

		// Return the values that were added.
		return $post_id;
	}

	//
	// Function: info ( $post_id, $type )
	//
	// Purpose:  Fetches certain or all information about a particular post.
	//
	// Arguments:
	//   $post_id -> The post_id of the article whose information will be retrieved.
	//	 $type    -> Can be any of the values written below or blank.
	//
	// Returns:
	//   post_id     -> The post's id number (I know, redundant, but useful for cleanliness).
	//   section_id  -> The post's section_id.
	//   user_id     -> The poster's id number.
	//   title       -> The post's title.
	//   text        -> The post's text.
	//   more_text   -> The post's more text.
	//   create_date -> The post's creation date.
	//   modify_date -> The post's last modification date.
	//   

	function info ()
	{
		// Import CONF.
		global $CONF, $INF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();

		// Connect to the database to check the access.
		$db->pconnect();

		// If we have no arguments, then get them all.
		if (func_num_args() < 2) {

			$post_id = func_get_arg(0);
			$query   = "SELECT * FROM news WHERE post_id='$post_id'";
			$result  = $db->query($query);
			$return  = $db->fetch_array($result);

		} else {

			$post_id = func_get_arg(0);
			$field   = func_get_arg(1);
			$query  = "SELECT ($field) FROM news WHERE post_id='$post_id'";
			$result = $db->query($query);
			$return = $db->result($result);

		}

		// Free the result.
		$db->free($result);

		// Return what they want.
		return $return;
	}

	//
	// Function: update ( $post_id, $field, $value )
	//
	// Purpose:  Changes the setting of a field listed below for the given post_id.
	//
	// Arguments:
	//   $field -> The field to change.
	//             * section_id
	//             * user_id             
	//             * title
	//             * text
	//             * more_text
	//             * create_date
	//             * modify_date
	//   $value -> The value to change the field to.
	//
	// Returns:  TRUE.
	//

	function update ($post_id, $field, $value)
	{
		// Import CONF.
		global $CONF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();

		// Connect to the database to check the access.
		$db->pconnect();

		// Check if we're dealing with create_date.
		// If we are, then we need a special query.
		if (!strcasecmp($field, 'create_date')) {
			// Prepare the query.
			$query = "UPDATE news SET $field='$value' WHERE post_id='$post_id'";

		// Otherwise proceed as normal.
		} else {
			// Get the original create_date...
			$create_date = $this->info($post_id, 'create_date');

			// Prepare the query.
			$query = "UPDATE news SET $field='$value', create_date='$create_date' WHERE post_id='$post_id'";

		}

		// Execute the query.
		$result = $db->query($query);

		return TRUE;
	}
		
	//
	// Function: form ( [$post_id] )
	//
	// Purpose:  Creates a form used for adding and editing
	//           articles.
	//
	// Arguments:
	//   $post_id -> If post_id is provided, then use those values.
	//
	// Returns:  Nothing.
	//

	function form()
	{
		// Import CONF and INF.
		global $CONF, $INF;

		// Import SECTION, SYSTEM, USER and XHTML classes, if needed.
		require_once("$CONF[local_path]/class/section-class.php");
		require_once("$CONF[local_path]/class/system-class.php");
		require_once("$CONF[local_path]/class/user-class.php");
		require_once("$CONF[local_path]/class/xhtml-class.php");	

		// Make new SECTION, SYSTEM, USER and XHTML objects.
		$section = new section();
		$system  = new system();
		$user    = new user();
		$xhtml   = new xhtml();

		// Get the user_id and section_id list.
		   $user_list = $user->i_list('user_id');
		$section_list = $section->i_list('section_id');

		// Determine access level.
		$access = $user->info(0, 'access');

		// Check if user is User Class (Level 1 - 2) or Power Class (Level 3 - 4) and set the disabled attribute
		// of author field.
		if ($access > 2) {
			$att_disabled = "";

		} else {
			$att_disabled = "disabled='disabled'";

		}

		// Check if we're editing.
		if (func_num_args() > 0) {

			// If we're editing, define the type.
			$type = 'edit';

			// Get the post_id.
			$post_id = func_get_arg(0);

			// Fetch details about that post.
			$post = $this->info($post_id);
			$list = $user->info($post[user_id]);

			// Remove slashes from title, text, and more_text.
			$post[title]     = stripslashes($post[title]);
			$post[text]      = stripslashes($post[text]);
			$post[more_text] = stripslashes($post[more_text]);

			$post[create_date] = $system->date_format($post_id, 'create_date', 'news');
			$post[modify_date] = $system->date_format($post_id, 'modify_date', 'news');

		// Otherwise we're adding.
		} else {

			// If we're adding, define the type.
			$type = 'add';

			// Fill in the values we can.
			$list = $user->info(0);	

			$now = $system->date_format(0, 'now', 'news');

			$post[create_date] = $now;
			$post[modify_date] = $now;

		}

		// Start a new table.
		$xhtml->table_start('normal', 500);

		// Escape PHP.
		?>
<br />
<form action='article.php?exec=<? echo $type; ?>&post_id=<? echo $post_id; ?>' method='post'>

<table class='normal' width='100%' cellpadding='5' cellspacing='0' border='0' align='center'>
<tr>
<td>Ownership:</td>
<td>
<select name='user_id' <? echo $att_disabled; ?>>
<? 

// Check access level.
// If the user is a Level 3 or 4 user, they can change the author name.
if ($access > 2) {

	// Cycle through the user_id list.
	for ($i = 0; $i < count($user_list); ++$i)
	{
		// Make a temporary user_id variable and reference it the user_id.
		$tmp_user_id  = $user_list[$i];

		// Make a temporary username variable and assign it the username.
		$tmp_username = $user->to_name($user_list[$i]);
	
		// Check if it's selected.
		if (!strcmp($list[username], $tmp_username)) {
			$att_selected = "selected='selected'";

		} else {
			$att_selected = "";

		}

		// Print the HTML.
		echo "<option value='$tmp_user_id' $att_selected>$tmp_username</option>\n";
	}

// If they're Level 1 or 2, they can do nothing to the author name.
} else {

	echo "<option value='0' selected='selected'>$list[username]</option>\n";

}

?>
</select>
</td>
</tr>
<tr>
<td>Section:</td>
<td>
<select name='section_id'>
<?

// Cycle through section_id list.
for ($i = 0; $i < count($section_list); ++$i)
{
	// Make a temporary section_id variable and reference it the section_id.
	$tmp_section_id = $section_list[$i];

	// Make a temporary username variable and assign it the username.
	$tmp_section_name = $section->to_name($section_list[$i]);
	
	// Check if it's selected.
	if (!strcmp($post[section_id], $tmp_section_id)) {
		$att_selected = "selected='selected'";

	} else {
		$att_selected = "";

	}

	// Print the HTML.
	echo "<option value='$tmp_section_id' $att_selected>$tmp_section_name</option>\n";
}
	
?>
</select>	
</td>
</tr>
<tr>
<td>Locked?</td>
<td>
<select name='section' disabled='disabled'>
<option value='123' selected='selected'>Not Implemented</option>
</select>	
</td>
</tr>
</table>

<table class='normal' width='100%' cellpadding='5' cellspacing='0' border='0' align='center'>
<tr>
<td>

Title:<br />
<input type='text' name='title' value="<? echo $post[title]; ?>" size='40' /><br />
<br />

Text:<br />
<textarea name='text' rows='5' cols='50'><? echo $post[text]; ?></textarea><br />
<br />

More Text:<br />
<textarea name='more_text' rows='7' cols='50'><? echo $post[more_text]; ?></textarea><br />
<br />

<input type='checkbox' class='checkbox' name='auto_newl' checked='checked' />&nbsp;Convert New Lines to Line Breaks.<br />
<input type='checkbox' class='checkbox' name='auto_link' checked='checked' />&nbsp;Automatic URL Hyperlink.<br />
<br />

<table class='normal' width='100%' cellpadding='5' cellspacing='0' border='0' align='center'>
<tr>
<td>Creation Date:</td><td><b><? echo $post[create_date]; ?></b></td>
</tr>
<tr>
<td>Mod. Date:</td><td><b><? echo $post[modify_date]; ?></b></td>
</tr>
<tr>
<td>Current Date:</td><td><b><? echo $system->date_format(0, 'now', 'news'); ?></b></td>
</tr>
</table>
<br />

<input type='submit' value='Post Article'> <input type='reset' value='Reset'>

</td>
</tr>
</table>

</form>
		<?
		// Re-enter PHP.

		// End the table.
		$xhtml->table_end();

	}

	//
	// Function: date_select ( $type )
	//
	// Purpose:  Displays a forms method for browsing the archives.
	//
	// Arguments:
	//   $type -> Type of archive form (either edit or delete).
	//
	// Returns:  Nothing.
	//

	function date_select ($type)
	{
		// Import CONF and COOKIE.
		global $CONF, $COOKIE1;

		// Import COOKIE, MYSQL, USER and XHTML classes, if needed.
		require_once("$CONF[local_path]/class/cookie-class.php");
		require_once("$CONF[local_path]/class/mysql-class.php");
		require_once("$CONF[local_path]/class/system-class.php");
		require_once("$CONF[local_path]/class/user-class.php");
		require_once("$CONF[local_path]/class/xhtml-class.php");

		// Create COOKIE, MYSQL, SYSTEM, USER and XHTML objects.
		$cookie = new cookie();
		$db     = new mysql();
		$system = new system();
		$user   = new user();	
		$xhtml  = new xhtml();

		// Make a new MYSQL object.
		$db = new mysql();
 
		// Connect to the database to check the access.
		$db->pconnect();

		// Determine the "day range".
		 $query[] = "SELECT DISTINCT DAYOFMONTH(create_date) AS article_dd FROM news ORDER BY article_dd";
		$result[] = $db->query($query[0]);

		// Determine the "month range".
		 $query[] = "SELECT DISTINCT MONTH(create_date) AS article_mm FROM news ORDER BY article_mm";
		$result[] = $db->query($query[1]);

		// Determine the "year range".
		 $query[] = "SELECT DISTINCT YEAR(create_date) AS article_yy FROM news ORDER BY article_yy";
		$result[] = $db->query($query[2]);

		// Start the table.
		$xhtml->table_start('normal', 500);

		// Start the form.
		echo "<br />\n";
		echo "<form action='article.php?dropdown=$type' method='post'>\n";
		echo "<table class='normal' width='100%' cellpadding='5' cellspacing='0' border='0' align='center'>\n";

		// Show Day of Month selection.
		echo "<tr>\n";
		echo "<td>Day of Month:</td>\n";
		echo "<td>\n";
		echo "<select name='article_dd'>\n";

		// Check if there are results.
		if ($db->num_rows($result[0])) {

			while ($list = $db->fetch_array($result[0]))
			{
				// Print the information.
				echo "<option value='$list[article_dd]'>$list[article_dd]</option>\n";
			}

		// Otherwise say there are not.
		} else {
			echo "<option value='%123%'>(no results found)</option>\n";

		}

		// End Day of Month selection.
		echo "</select>\n";
		echo "</td>\n";
		echo "</tr>\n";

		// Show Month selection.
		echo "<tr>\n";
		echo "<td>Month:</td>\n";
		echo "<td>\n";
		echo "<select name='article_mm'>\n";

		// Check if there are results.
		if ($db->num_rows($result[1])) {

			while ($list = $db->fetch_array($result[1]))
			{
				// Print the information.
				echo "<option value='$list[article_mm]'>$list[article_mm]</option>\n";
			}

		// Otherwise say there are not.
		} else {
			echo "<option value='%123%'>(no results found)</option>\n";

		}

		// End Month selection.
		echo "</select>\n";
		echo "</td>\n";
		echo "</tr>\n";

		// Show Year selection.
		echo "<tr>\n";
		echo "<td>Year:</td>\n";
		echo "<td>\n";
		echo "<select name='article_yy'>\n";

		// Check if there are results.
		if ($db->num_rows($result[2])) {

			while ($list = $db->fetch_array($result[2]))
			{
				// Print the information.
				echo "<option value='$list[article_yy]'>$list[article_yy]</option>\n";
			}

		// Otherwise say there are not.
		} else {
			echo "<option value='%123%'>(no results found)</option>\n";

		}

		// End Year selection.
		echo "</select>\n";
		echo "</td>\n";
		echo "</tr>\n";

		// End the form and list.
		echo "</table>\n";
		echo "<br />\n";
		echo "<input type='submit' value='Show Archived Articles'>\n";
		echo "</form>\n";

		// End the table.
		$xhtml->table_end();

	}

	//
	// Function: dropdown ( $type, $limit [, $date] )
	//
	// Purpose:  Displays a dropdown menu of posts so the user may choose one.
	//
	// Arguments:
	//   $type  -> Type of dropdown (i.e. edit or delete).
	//   $limit -> Number of items in the dropdown.
	//   $date  -> (optional) Show posts from this date only.
	//
	// Returns:  Nothing.
	//
	
	function dropdown ($type, $limit, $date = NULL)
	{
		// Import CONF and COOKIE.
		global $CONF, $COOKIE1;

		// Import COOKIE, MYSQL, USER and XHTML classes, if needed.
		require_once("$CONF[local_path]/class/cookie-class.php");
		require_once("$CONF[local_path]/class/mysql-class.php");
		require_once("$CONF[local_path]/class/system-class.php");
		require_once("$CONF[local_path]/class/user-class.php");
		require_once("$CONF[local_path]/class/xhtml-class.php");

		// Create COOKIE, MYSQL, SYSTEM, USER and XHTML objects.
		$cookie = new cookie();
		$db     = new mysql();
		$system = new system();
		$user   = new user();	
		$xhtml  = new xhtml();

		// Make a new MYSQL object.
		$db = new mysql();
 
		// Connect to the database to check the access.
		$db->pconnect();

		// Retrieve user_id of current user, and check cookie.
		if(!(list($user_id, $username, $password, $ip) = $cookie->decode($COOKIE1)))
			die("INFORMIUM: Cookie values illegally changed.<br />\n");

		// Determine user's access level.
		$access = $user->info(0, 'access');

		// Query the database depending on access level.
		// If access is 1 or 2 than we can only see our own posts.
		if ($access < 3) {

			// If 'date' is NULL, do nothing extra.
			if ($date == NULL) {
				$query = "SELECT * FROM news WHERE user_id='$user_id' ORDER BY create_date DESC LIMIT $limit"; 
			
			// Otherwise, we search for that particular date.
			} else {
				$query = "SELECT * FROM news WHERE user_id='$user_id' AND create_date LIKE '{$date}______' ORDER BY create_date DESC";

			}

		// If access is 3 or 4, than we can edit anyone's post.
		} else if ($access > 2) {

			// If 'date' is NULL, do nothing extra.
			if ($date == NULL) {
				$query = "SELECT * FROM news ORDER BY create_date DESC LIMIT $limit"; 
			
			// Otherwise, we search for that particular date.
			} else {
				$query = "SELECT * FROM news WHERE create_date LIKE '{$date}______' ORDER BY create_date DESC";

			}
			
		}

		// Execute the query.
		$result = $db->query($query);

		// Make the argument string for the form.
		if (!strcmp($type, 'edit'))
			$argument = 'form=edit';

		// Otherwise we're deleting.
		else
			$argument = 'exec=delete';

		// Start the table.
		$xhtml->table_start('normal', 500);

		// Start the form.
		echo "<br />\n";
		echo "<form action='article.php?$argument' method='post'>\n";
		echo "<select name='post_id'>\n";

		// Check if there are results.
		if ($db->num_rows($result)) {

			// Display the post list.
			while ($list = $db->fetch_array($result))
			{
				// Fetch the create_date.
				$create_date = $system->date_format($list[post_id], 'create_date', 'news');

				// Determine the username.
				$list[username] = $user->to_name($list[user_id]);

				// Remove slashes from title.
				$list[title] = stripslashes($list[title]);
			
				// Shorten the title.
				$list[title] = substr($list[title], 0, 25);

				// Print the information.
				echo "<option value='$list[post_id]'>($create_date) $list[username] - $list[title]</option>\n";
			}

		// Otherwise say there are not.
		} else {
			echo "<option value='%123%'>(no results found)</option>\n";

		}

		// Prepare string.
		$type = ucfirst($type);

		// End the form and list.
		echo "</select><br />\n";
		echo "<br />\n";
		echo "<input type='submit' value='$type Article'>\n";
		echo "</form>\n";

		// End the table.
		$xhtml->table_end();

		// Free the result.
		$db->free($result);
	}

	//
	// Function: check ( $post_id, $user_id )
	//
	// Purpose:  Checks if the user owns the specified post.
	//
	// Arguments:
	//   $post_id -> The article to check's post_id.
	//   $user_id -> The user to check's user_id.
	//
	// Returns: 1 if owned, 0 if not owned.
	//

	function check ($post_id, $user_id)
	{
		// Import CONF and COOKIE1.
		global $CONF, $COOKIE1;

		// Import MYSQL and USER class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");
 
		// Make new MYSQL and USER objects.
		$db   = new mysql();
 
		// Connect to the DB.
		$db->pconnect();
 
		// Prepare and execute the query.
		$query  = "SELECT * FROM news WHERE post_id='$post_id' AND user_id='$user_id'";
		$result = $db->query($query);
 
		// If user owns post, return 1.
		if ($db->num_rows($result))
			$return = 1;

		// If user does not own post, return 0.
		else
			$return = 0;

          // Free the result.
          $db->free($result);

		// Return the answer.
		return $return;
	}

	//
	// Function: comment_count ( $post_id )
	//
	// Purpose:  Determines the amount of comments there are associated with a post.
	//
	// Arguments:
	//   $post_id -> The target article.
	//
	// Returns: An integer amount of comments.
	// 

	function comment_count ( $post_id )
	{
		// Import CONF.
		global $CONF;

		// Import MYSQL and USER class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");
 
		// Make new MYSQL and USER objects.
		$db   = new mysql();
 
		// Connect to the DB.
		$db->pconnect();

		// Prepare and execute the query.
		$query  = "SELECT COUNT(*) FROM comments WHERE assoc_id='$post_id'";
		$result = $db->query($query);

		// Get the result's value.
		$return = $db->result($result);

		// Free the result.
		$db->free($result);

		// Return the answer.
		return $return;
	}

	//
	// Function: prepare ( $list )
	//
	// Purpose:
	// Prepares the needed variables for a template and
	// outputs the currently selected template.
	//
	// Arguments:
	//   $list -> An array containing the retrieved infromation of a post.
	//	
	// Returns: Nothing.
	//

	function prepare ($list)
	{
		// Import CONF.
		global $CONF;

		// Import SECTION, SYSTEM and USER classes, if needed.
		require_once("$CONF[local_path]/class/image-class.php");
		require_once("$CONF[local_path]/class/section-class.php");
		require_once("$CONF[local_path]/class/system-class.php");
		require_once("$CONF[local_path]/class/user-class.php");

		// Make new SECTION, SYSTEM and USER objects.
		$image   = new image();
		$section = new section();
		$user    = new user();
		$system  = new system();

		// Retrieve the user's username.
	    $list[username] = $user->to_name($list[user_id]);
	    $list[email]    = $user->info($list[user_id], 'email');

	    // Format the creation and modification dates.
	    $list[create_date] = $system->date_format($list[post_id], 'create_date', 'news');
	    $list[modify_date] = $system->date_format($list[post_id], 'modify_date', 'news');

	    // Stripslashes from title, text and more_text.
	    $list[title]     = stripslashes($list[title]);
	    $list[text]      = stripslashes($list[text]);
	    $list[more_text] = stripslashes($list[more_text]);

		// Get the comment count and the comment link.
		$list[comment_count] = $this->comment_count($list[post_id]);
		$list[link_add]      = "index.php?do=form&assoc_id=$list[post_id]";
		$list[link_comment]  = "?post_id=$list[post_id]";

		// Make the link root.
		$list[link_root]     = $CONF[www_address];

		// Retrieve Section-related & Image-related Info.
		$section_list = $section->info($list[section_id]);
		$image_list   = $image->info($section_list[image_id]);

		// Make Section-releated Info.
		$list[section_name]  = $section->info($list[section_id], 'section_name');
		$list[section_link]  = "index.php?section_id=$list[section_id]";
		$list[section_image] = $CONF[www_address] . "/i/" . $image_list[image_type]
		                                          . '/'   . $image_list[image_name];

		// Return the list.
		return $list;
	}

}