<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// MYSQL Class (mysql-class.php)
//
// Author: Cameron McKay
// Note:   This class adds degrees of error reporting and simplies
//         database usage.
//

class mysql
{
	var $_hostname;	// MYSQL server hostname.
	var $_username;	// MYSQL user username. 
	var $_password;	// MYSQL user password.
	var $_database;	// MYSQL database.

	var $opt_connect_echo;  // Toggle whether or not to print database info (OFF by default).
	var $opt_query_echo;	// Toggle whether or not to print queries (OFF by default).

	var $link;		// The link identifier.

	// The constructor (that makes the class).
	function mysql ($hostname = NULL, $username = NULL, $password = NULL, $database = NULL)
	{
		// Get the database information.
		global $DB;

		// Assign it to the object.
		if ($hostname == NULL) {

			//
			// ** EDIT THESE! **
			// For example, if you changed 'some_pass' to something like 'asecret' then you
			// would change it below accordingly.
			//
			// Example:
			// $this->_password = 'some_pass';
			// (change to)
			// $this->_password = 'asecret';
			//

			$this->_hostname = 'localhost';  // Usually localhost.
			$this->_username = 'imgr';       // Whatever you desire. 
			$this->_password = 'some_pass';  // Whatever you desire.
			$this->_database = 'informium';  // Usually informium.

			//
			// ** STOP EDITING! **
			//

		// Otherwise use the arguments.
		} else {

			$this->_hostname = $hostname;
			$this->_username = $username;
			$this->_password = $password;
			$this->_database = $database;

		}

		$this->opt_connect_echo = 0;
		$this->opt_query_echo   = 0;
	}

	// Below are functions that are used in the script, therefore they
	// are added to this object so that any error reporting or error
	// settings can be added.

	//
	// Function: pconnect( )
	//
	// Purpose:  Connects to the database defined above and selects the
	//           proper database, all in one swift pass.
	//
	// Returns:  The link identifier.
	//

	function pconnect ()
	{
		// Show connection information if needed.
		if ($this->opt_connect_echo == 1) {

			echo "Database: {$this->_database}<br />\n";
			echo "Username: {$this->_username}<br />\n";
			echo "Password: ********<br />\n";
			echo "Hostname: {$this->_hostname}<br />\n";

		}

		// Connect to the database.
		$this->link = mysql_pconnect($this->_hostname, $this->_username, $this->_password)
			or die("INFORMIUM: Error connecting to database '$this->_hostname'.<br />\n");

		// Select the database.
		mysql_select_db($this->_database, $this->link)
			or die("INFORMIUM: " . mysql_error() . "<br />\n");

		// Return the link identifier in case they want to use it.
		return $this->link;
	}

	//
	// Function: query( $query )
	//
	// Purpose:  Executes a query against the above defined MYSQL database.
	//
	// Arguments:
	//   $query -> The MYSQL query.
	//
	// Returns:  The return value of mysql_query().
	//

	function query ($query)
	{
		// Check if query_echo is on.
		if ($this->opt_query_echo)
			echo "INFORMIUM: (Query) $query<br />\n";

		// Execute the query.
		$result = mysql_query($query, $this->link);

		if (!$result) {
			echo "INFORMIUM(1): Query failed. (QUERY to '{$this->_database}': $query)<br />\n";
			echo "INFORMIUM(2): MYSQL error: " . mysql_error() . "<br />\n";

		}

		return $result;
	}

	//
	// Function: free ( $result )
	//
	// Purpose:  Exactly the same as mysql_free_result().
	//
	// Arguments:
	//   $result -> A result returned by a query.
	//
	// Returns:  The return value of mysql_free_result().
	//

	function free ($result)
	{
		// Basically a meta-function for mysql_free_result().
		return mysql_free_result($result);
	}

	//
	// Function: num_rows ( $result )
	//
	// Purpose:  mysql_num_rows() meta-function.
	//
	// Arguments:
	//   $result -> A result returned by a SELECT query.
	//
	// Returns:  The return value of mysql_num_rows().
	//

	function num_rows ($result)
	{
		// Basically a meta-function mysql_num_rows().
		return mysql_num_rows($result);
	}

	//
	// Function: affected_rows ( )
	//
	// Purpose:  mysql_affected_rows() meta-function.
	//
	// Returns:  The return value of mysql_affected_rows().
	//

	function affected_rows ()
	{
		// Basically a meta-function mysql_affected_rows().
		return mysql_affected_rows($this->link);
	}

	//
	// Function: fetch_array ( $result )
	//
	// Purpose:  mysql_fetch_array() meta-function.
	//           Always passes MYSQL_ASSOC.
	//
	// Returns:  The return value of mysql_fetch_array().
	//

	function fetch_array ($result)
	{
		// Always pass MYSQL_ASSOC (since it's all that's really useful to me).
		return mysql_fetch_array($result, MYSQL_ASSOC);
	}

	//
	// Function: result ( $result )
	//
	// Purpose:  mysql_result() meta-function.
	//           Always passes 0 as second argument.
	// 
	// Returns:  The return value of mysql_result().
	//

	function result ($result)
	{
		// Always pass 0 (since it's all that's really useful to me).
		return mysql_result($result, 0);
	}

	//
	// Function: insert_id ( )
	//
	// Purpose:  mysql_insert_id() meta-function.
	//
	// Returns:  The return value of mysql_insert_id().
	//

	function insert_id ()
	{
		// A meta-function for mysql_insert_id().
		return mysql_insert_id($this->link);
	}
}		

?>
