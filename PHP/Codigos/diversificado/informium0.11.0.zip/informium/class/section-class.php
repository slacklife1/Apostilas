<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:
//
// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Section Class (section-class.php)
//
// Author: Cameron McKay
// Note:   Class that allows for the manipulation of sections.
//

class section
{
	// Constructor function.
	function section()
	{
		// Does nothing.
	}

	//
	// Function: add ( $section_name, $image_id )
	//
	// Purpose:  Adds an section to the Informium database.
	//
	// Arguments:
	//   $section_name -> The name of the section.
	//   $image_id     -> The image associated with the section.
	//	
	// Returns:  The new section_id, or -1 for empty field.
	//

	function add ($section_name, $image_id)
	{
		// Call the insert() function to insert the section.
		return $this->insert(0, $section_name, $image_id);
	}

	//
	// Function: edit ( $section_id, $section_name, $image_id )
	//
	// Purpose:  Edits a section in the Informium database.
	//
	// Arguments:
	//   $section_id   -> The section's section_id number.
	//   $section_name -> The name of the section.
	//   $image_id     -> The image associated with the section.
	//
	// Returns:  The section_id, or -1 for empty field.
	//

	function edit ($section_id, $section_name, $image_id)
	{
		// Call the insert() function to update the section.
		return $this->insert($section_id, $section_name, $image_id);
	}

	//
	// Function: delete ( $section_id )
	//
	// Purpose:  Deletes a section in the Informium database.
	//           All articles containing this section association are reset to section_id 1.
	//           
	// Arguments:
	//   $section_id -> The section's section_id number.
	//
	// Returns:  Nothing.
	//

	function delete ($section_id)
	{
		// Import CONF.
		global $CONF;

		// Import the MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Create a new MYSQL object.
		$db = new mysql();

		// Connect to the DB.
		$db->pconnect();

		// Prepare and execute the query (change all associated section_ids to 1).
		$query = "UPDATE news SET section_id='1' where section_id='$section_id'";
		$db->query($query);

		// Prepare and execute the query (delete the section).
		$query = "DELETE FROM sections WHERE section_id='$section_id'";
		$db->query($query);


	}

	//
	// Function: insert ( $section_id, $section_name, $image_id )
	//
	// Purpose:  Adds or edits a section in the Informium database.
	//
	// Arguments:
	//   $section_id   -> The section's section_id number.
	//   $section_name -> The name of the section.
	//   $image_id     -> The image associated with the section.
	//
	// Returns:  The new section_id, or -1 for empty field.
	//
	
	function insert  ($section_id, $section_name, $image_id)
	{
		// Import CONF;
		global $CONF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");
 
		// Make new MYSQL object.
		$db = new mysql();

		// Check if the string contains data.
		if(strlen($section_name) < 1) {

			// Return the 'empty field' error.
			return -1;

		}
		
		// Prepare the section_name.
		$section_name = addslashes($section_name);

		// Check if we have a section_id that's greater than 0.  If we do, then
		// we're merely updating a section.
		if ($section_id > 0) {

			// Get the original create_date (since UPDATE automatically changes the timestamp...)
			$create_date = $this->info($section_id, 'create_date');

			// Prepare the update.
			$query = "UPDATE sections 
					SET section_name='$section_name',
					image_id='$image_id',
					create_date='$create_date' 
					WHERE section_id='$section_id'"; 

		// Otherwise we're adding a new one.
		} else { 

			// Prepare the addition.
			$query  = "INSERT INTO sections VALUES('', '$section_name', '$image_id', NOW())";

		}

		// Connect to the DB.
		$db->pconnect();

		// Execute the query.
		$db->query($query);

		// Fetch the section_id for return, if needed.
		if ($section_id < 1) {
			$section_id = $db->insert_id();

		}

		// Return the values that were added.
		return $section_id;
	}

	//
	// Function: info ( $section_id, $type )
	//
	// Purpose:  Fetches certain or all information about a particular section.
	//
	// Arguments:
	//   $section_id -> The section_id of the section whose information will be retrieved.
	//	 $type       -> Can be any of the values written below or blank.
	//
	// Returns:
	//   section_id   -> The section's section_id number.
	//   section_name -> The name of the section.
	//   image_id     -> The image associated with the section.
	//   create_date  -> The section's creation date.
	//

	function info ()
	{
		// Import CONF.
		global $CONF, $INF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();

		// Connect to the database to check the access.
		$db->pconnect();

		// If we have no arguments, then get them all.
		if (func_num_args() < 2) {

			$section_id = func_get_arg(0);
			$query      = "SELECT * FROM sections WHERE section_id='$section_id'";
			$result     = $db->query($query);
			$return     = $db->fetch_array($result);

		} else {

			$section_id = func_get_arg(0);
			$field      = func_get_arg(1);
			$query      = "SELECT ($field) FROM sections WHERE section_id='$section_id'";
			$result     = $db->query($query);
			$return     = $db->result($result);

		}

		// Free the result.
		$db->free($result);

		// Return what they want.
		return $return;
	}

	//
	// Function: update ( $section_id, $field, $value )
	//
	// Purpose:  Changes the setting of a field listed below for the given section_id.
	//
	// Arguments:
	//   $field -> The field to change.
	//             * section_name
	//             * image_id
	//             * create_date
	//   $value -> The value to change the field to.
	//
	// Returns:  TRUE.
	//

	function update ($section_id, $field, $value)
	{
		// Import CONF.
		global $CONF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();

		// Connect to the database to check the access.
		$db->pconnect();

		// Check if we're dealing with create_date.
		// If we are, then we need a special query.
		if (!strcasecmp($field, 'create_date')) {
			// Prepare the query.
			$query = "UPDATE sections SET $field='$value' WHERE section_id='$section_id'";

		// Otherwise proceed as normal.
		} else {
			// Get the original create_date...
			$create_date = $this->info($section_id, 'create_date');

			// Prepare the query.
			$query = "UPDATE sections SET $field='$value', create_date='$create_date' WHERE section_id='$section_id'";

		}

		// Execute the query.
		$result = $db->query($query);

		return TRUE;
	}
		
	//
	// Function: form ( [$section_id] )
	//
	// Purpose:  Creates a form used for adding and editing
	//           section_id.
	//
	// Arguments:
	//   $section_id -> If section_id is provided, then use those values.
	//
	// Returns:  Nothing.
	//

	function form()
	{
		// Import CONF and INF.
		global $CONF, $INF;

		// Import IMAGE, SYSTEM and XHTML classes, if needed.
		require_once("$CONF[local_path]/class/image-class.php");
		require_once("$CONF[local_path]/class/system-class.php");
		require_once("$CONF[local_path]/class/xhtml-class.php");	

		// Make new IMAGE, SYSTEM and XHTML objects.
		$image  = new image();
		$system = new system();
		$xhtml  = new xhtml();

		// Retrieve the image_id listing.
		$image_list = $image->i_list('image_id');

		// Check if we're editing.
		if (func_num_args() > 0) {

			// If we're editing, define the type.
			$type = 'edit';

			// Get the section_id.
			$section_id = func_get_arg(0);

			// Fetch details about that section.
			$section = $this->info($section_id);

			// Remove slashes from the section_name.
			$section[section_name] = stripslashes($section[section_name]);

			// Prepare date information.
			$section[create_date]  = $system->date_format($section_id, 'create_date', 'sections');

		// Otherwise we're adding.
		} else {

			// If we're adding, define the type.
			$type = 'add';

			$now = $system->date_format(0, 'now', 'sections');

			$section[create_date] = $now;
			$section[modify_date] = $now;

		}

		// Start a new table.
		$xhtml->table_start('normal', 500);

		// Escape PHP.
		?>
<br />
<form action='section.php?exec=<? echo $type; ?>&section_id=<? echo $section_id; ?>' method='post'>

<table class='normal' width='100%' cellpadding='5' cellspacing='0' border='0' align='center'>
<tr>
<td>

Section Name:<br />
<input type='text' name='section_name' value="<? echo $section[section_name]; ?>" size='40' /><br />
<br />

Section Image:<br />
<select name='image_id'>
<?

// Cycle through image_id list.
for ($i = 0; $i < count($image_list); ++$i)
{
	// Make a temporary image_id variable and reference it the image_id.
	$tmp_image_id   = $image_list[$i];

	// Make a temporary username variable and assign it the image_desc.
	$tmp_image_desc = $image->info($tmp_image_id, 'image_desc');
	
	// Check if it's selected.
	if (!strcmp($section[image_id], $tmp_image_id)) {
		$att_selected = "selected='selected'";

	} else {
		$att_selected = "";

	}

	// Print the HTML.
	echo "<option value='$tmp_image_id' $att_selected>$tmp_image_desc</option>\n";
}
	
?>
</select>
<br />
<br />

<table class='normal' width='100%' cellpadding='5' cellspacing='0' border='0' align='center'>
<tr>
<td>Creation Date:</td><td><b><? echo $section[create_date]; ?></b></td>
</tr>
<tr>
<td>Current Date:</td><td><b><? echo $system->date_format(0, 'now', 'sections'); ?></b></td>
</tr>
</table>
<br />

<input type='submit' value='<? echo ucfirst($type); ?> Section'> <input type='reset' value='Reset'>

</td>
</tr>
</table>

</form>
		<?
		// Re-enter PHP.

		// End the table.
		$xhtml->table_end();

	}

	//
	// Function: dropdown ( $type )
	//
	// Purpose:  Displays a dropdown menu of sections so the user may choose one.
	//
	// Arguments:
	//   $type  -> Type of dropdown (i.e. edit or delete).
	//
	// Returns:  Nothing.
	//
	
	function dropdown ($type)
	{
		// Import CONF;
		global $CONF;

		// Import MYSQL and XHTML classes, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");
		require_once("$CONF[local_path]/class/xhtml-class.php");

		// Create MYSQL and XHTML objects.
		$db     = new mysql();
		$xhtml  = new xhtml();

		// Connect to the DB.
		$db->pconnect();

		// Retrieve the sections listing.
		$query  = "SELECT * FROM sections ORDER BY section_name";
		$result = $db->query($query);

		// Make the argument string for the form.
		if (!strcmp($type, 'edit')) {
			$argument = 'form=edit';

		// Otherwise we're deleting.
		} else {
			$argument = 'exec=delete';

		}
		// Start the table.
		$xhtml->table_start('normal', 500);

		// Start the form.
		echo "<br />\n";
		echo "<form action='section.php?$argument' method='post'>\n";
		echo "<select name='section_id'>\n";

		// Check if there are results.
		if ($db->num_rows($result)) {

			// Display the section list.
			while ($list = $db->fetch_array($result))
			{	
				// Strip the slashes from the 
				$list[section_name] = stripslashes($list[section_name]);

				// Print the information.
				echo "<option value='$list[section_id]'>$list[section_name]</option>\n";
			}

		// Otherwise say there are not.
		} else {
			echo "<option value='%123%'>(No Sections Exist)</option>\n";

		}

		// Prepare string.
		$type = ucfirst($type);

		// End the form and list.
		echo "</select><br />\n";
		echo "<br />\n";
		echo "<input type='submit' value='$type Section'>\n";
		echo "</form>\n";

		// End the table.
		$xhtml->table_end();

		// Free the result.
		$db->free($result);
	}

	//
	// Function: i_list ( $field )
	//
	// Purpose:  Retrieves a list array of any given field name.
	//
	// Arguments:
	//   $field -> Can be any of the values written below.
	//
	// Returns:  An array with one of the following list of values.
	//   section_name -> The section's section_name.
	//   image_id     -> The section's image_id.
	//   create_date  -> The section's creation date.
	//

	function i_list ($field)
	{
		// Import CONF.
		global $CONF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();

		// Connect to the database to check the access.
		$db->pconnect();

		// Prepare the query.
		$query  = "SELECT ($field) FROM sections ORDER BY section_name";
		$result = $db->query($query);

		// Cycle through the results, making them into a list.
		while ($list = $db->fetch_array($result))
			$return[] = $list[$field];

		// Free the result.
		$db->free($result);

		// Return the answer.
		return $return;
	}

	//
	// Function: check ( $section_id )
	//
	// Purpose:  Checks if the section_id exists.
	//
	// Arguments:
	//   $section_id -> The section's section_id.
	//
	// Returns:  1 if the section_id exists, 0 if it does not.
	//

	function check ($section_id)
	{
		// Import CONF.
		global $CONF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();
		
		// Connect to the DB.
		$db->pconnect();

		// Prepare and execute the query.
		$query  = "SELECT * FROM sections WHERE section_id='$section_id'";
		$result = $db->query($query);

		// Check if we got a result.
		$return = $db->num_rows($result);

		// Free the result.
		$db->free($result);

		// Return the answer.
		return $return;
	}

	//
	// Function: to_name ( $section_id )
	//
	// Purpose:  Translates a section_id to a section_name.
	//
	// Returns:  section_name for given section_id.
	//

	function to_name($section_id)
	{
		// Import CONF.
		global $CONF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();

		// Connect to the database.
		$db->pconnect();

		// Execute query.
		$query  = "SELECT section_name FROM sections WHERE section_id='$section_id'";
		$result = $db->query($query);
		$return = $db->result($result);

		// Free result.
		$db->free($result);

		// Return username.
		return $return;
	}

	//
	// Function: to_id ($section_name OR $section_id)
	//
	// Purpose:  Translates a section_name (or section_id) to a section_id.
	//
	// Return:   The section_id for given section_name.
	//

	function to_id ( $sectdata )
	{
		// Import CONF.
		global $CONF;

		// If it's an integer than we assume it's already a section_id.
		if (is_numeric($sectdata)) { 
		
			// So we return the value untouched.
			return $sectdata;

		} else {

			// Rename it for aesthetics.
			$section_name = $sectdata;

		}

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();

		// Connect to the database.
		$db->pconnect();

		// Execute query.
		$query  = "SELECT section_id FROM sections WHERE section_name='$section_name'";
		$result = $db->query($query);
		$return = $db->result($result);

		// Free result.
		$db->free($result);

		// Return user_id.
		return $return;
	}

}