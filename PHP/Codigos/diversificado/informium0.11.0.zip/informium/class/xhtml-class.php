<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// XHTML Class (xhtml-class.php)
//
// Author: Cameron McKay
// Note:   Contains all the XHTML related functions.
//

class xhtml
{
	var $title;		// The title that appears on every page.
	var $font_family;	// The desired fonts.
	var $font;		// The desired font size.
	var $colour;		// Various colour definitions.

	// Constructor.
	function xhtml ()
	{
		$this->title        = 'Informium'; // Please leave this as it is.

		$this->font_family  = 'Verdana, Helvetica, Arial, Sans-serif';
		$this->font[small]  = 'xx-small';
		$this->font[medium] = 'x-small';
		$this->font[large]  = 'small';

		$this->colour[border]        = '#000000';

		$this->colour[header_back]   = '#00204E';
		$this->colour[header_text]   = '#FFFFFF';

		$this->colour[normal_back]   = '#00204E';
		$this->colour[normal_text]   = '#FFFFFF';
	}

	//
	// Function: header ( $title )
	//
	// Purpose:  Starts the XHTML of a page.
	//
	// Arguments:
	//   $title -> The title of the page (in addition to the internal title).
	//
	// Returns:  Nothing.
	//

	function header ($title)
	{
		echo		// Start.
		"<html>\n",
		"<head>\n",
		"<title>$this->title - $title</title>\n",
		$this->style(),
		"</head>\n",
		"<body link='#FFFFFF' alink='#FFFFFF' vlink='#FFFFFF'>\n"
		;		// End.
	}

	//
	// Function: style ( )
	//
	// Purpose:  Prints a style sheet for use across documents.
	//
	// Returns:  Nothing.
	//

	function style ()
	{
		// Import CONF.
		global $CONF;

		// Merely include the stylesheet.
		require_once("$CONF[local_path]/admin/stylesheet.php");
	}

	//
	// Function: footer ( )
	//
	// Purpose:  Ends the XHTML of the page.
	//
	// Returns:  Nothing.
	//

	function footer ()
	{
		echo		// Start.
		"</body>\n",
		"</html>"
		;		// End.
	}

	


	//
	// Function:  table_start ( $class, $width )
	// Function:  table_end   ( )
	//
	// Purpose:   Makes a stylized table using the Informium stylesheet.
	//
	// Arguments:
	//   $class -> The class to use (normally 'normal','header', or 'footer').
	//   $width -> The width of the table.
	//
	// Returns:   Nothing.
	//

	function table_start ($class, $width)
	{
		// Get the WWW path.
		global $CONF;

		// Calculate internal table width.
		$table_width = $width - 50;

		echo		// Start.
		"<table class='$class' width='$width' cellpadding='0' cellspacing='0' border='0' align='center'>\n",
		"<tr>\n",
		"<td align='left'><img src='$CONF[www_address]/i/ctl.png' /></td>\n",
		"<td><img src='$CONF[www_address]/i/pix.png' /></td>\n",
		"<td align='right'><img src='$CONF[www_address]/i/pix.png' /></td>\n",
		"</tr>\n",
		"<tr>\n",
		"<td>&nbsp;</td>\n",
		"<td>\n",
		"<table class='$class' width='$table_width' align='center'><tr><td>\n"
		;		// End.
	}

	function table_end ()
	{
		// Get the WWW path.
		global $CONF;

		echo		// Start.
		"</td></tr></table>\n",
		"</td>\n",
		"<td>&nbsp;</td>\n",
		"</tr>\n",
		"<tr>\n",
		"<td align='left'><img src='$CONF[www_address]/i/pix.png' /></td>\n",
		"<td><img src='$CONF[www_address]/i/pix.png' /></td>\n",
		"<td align='right'><img src='$CONF[www_address]/i/cbr.png' /></td>\n",
		"</tr>\n",
		"</tr>\n",
		"</table>\n"
		;		// End.
	}

}

?>
