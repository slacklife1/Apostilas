<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Image Class (image-class.php)
//
// Author: Cameron McKay
// Note:   Class that allows for the manipulation of images within Informium.
//

class image
{
	// Constructor function.
	function image()
	{
		// Does nothing.
	}

	//
	// Function: add ( $image_name, $image_desc, $image_type )
	//
	// Purpose:  Adds an image definition to the Informium database.
	//
	// Arguments:
	//   $image_name -> The image's filename (i.e. general.jpg).
	//   $image_desc -> The image's description (i.e. General Section Image).
	//   $image_type -> The image's type (i.e. section).
	//	
	// Returns:  The new image_id, or -1 for empty field.
	//

	function add ($image_name, $image_desc, $image_type)
	{
		// Call the insert() function to insert the image.
		return $this->insert(0, $image_name, $image_desc, $image_type);
	}

	//
	// Function: edit ( $image_id, $image_name, $image_desc, $image_type )
	//
	// Purpose:  Edits a image in the Informium database.
	//
	// Arguments:
	//   $image_id   -> The target image_id.
	//   $image_name -> The image's filename (i.e. general.jpg).
	//   $image_desc -> The image's description (i.e. General Section Image).
	//   $image_type -> The image's type (i.e. section).
	//
	// Returns:  The image_id, or -1 for empty field.
	//

	function edit ($image_id, $image_name, $image_desc, $image_type)
	{
		// Call the insert() function to update the image.
		return $this->insert($image_id, $image_name, $image_desc, $image_type);
	}

	//
	// Function: delete ( $image_id )
	//
	// Purpose:  Deletes an image in the Informium database.
	//           
	// Arguments:
	//   $image_id   -> The target image_id.
	//
	// Returns:  Nothing.
	//

	function delete ($image_id)
	{
		// Import CONF.
		global $CONF;

		// Import the MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Create a new MYSQL object.
		$db = new mysql();

		// Connect to the DB.
		$db->pconnect();

		// Prepare and execute the query.
		$query = "DELETE FROM images WHERE image_id='$image_id'";
		$db->query($query);
	}

	//
	// Function: insert ( $image_id, $image_name, $image_desc, $image_type )
	//
	// Purpose:  Adds or edits an image in the Informium database.
	//
	// Arguments:
	//   $image_id   -> The target image_id.
	//   $image_name -> The image's filename (i.e. general.jpg).
	//   $image_desc -> The image's description (i.e. General Section Image).
	//   $image_type -> The image's type (i.e. section).
	//
	// Returns:  The new image_id, or -1 for empty field.
	//
	
	function insert ($image_id, $image_name, $image_desc, $image_type)
	{
		// Import CONF.
		global $CONF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");
 
		// Make new MYSQL object.
		$db = new mysql();

		// Make sure all the strings contain data.
		if((strlen($image_name) < 1) || (strlen($image_desc) < 1) || (strlen($image_type) < 1)) {

			// Return the 'empty field' error.
			return -1;

		}
		
		// Prepare the image_name, image_desc & image_type.
		$image_name = addslashes($image_name);
		$image_desc = addslashes($image_desc);
		$image_type = addslashes($image_type);

		// Check if we have an image_id that's greater than 0.  If we do, then
		// we're merely updating an image.
		if ($image_id > 0) {

			// Prepare the update.
			$query = "UPDATE images SET
					image_name='$image_name',
					image_desc='$image_desc',
					image_type='$image_type',
					WHERE image_id='$image_id'"; 

		// Otherwise we're adding a new one.
		} else { 

			// Prepare the addition.
			$query  = "INSERT INTO images VALUES('', '$image_name', '$image_desc', '$image_type')";

		}

		// Connect to the DB.
		$db->pconnect();

		// Execute the query.
		$db->query($query);

		// Fetch the image_id for return, if needed.
		if ($image_id < 1) {
			$image_id = $db->insert_id();

		}

		// Return the values that were added.
		return $image_id;
	}

	//
	// Function: info ( $image_id, $type )
	//
	// Purpose:  Fetches certain or all information about a particular image_id.
	//
	// Arguments:
	//   $image_id -> The target image_id.
	//	 $type     -> Can be any of the values written below or blank.
	//
	// Returns:
	//   image_name -> The image's filename (i.e. general.jpg).
	//   image_desc -> The image's description (i.e. General Section Image).
	//   image_type -> The image's type (i.e. section).
	//

	function info ()
	{
		// Import CONF.
		global $CONF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();

		// Connect to the database to check the access.
		$db->pconnect();

		// If we have no arguments, then get them all.
		if (func_num_args() < 2) {

			$image_id = func_get_arg(0);
			$query    = "SELECT * FROM images WHERE image_id='$image_id'";
			$result   = $db->query($query);
			$return   = $db->fetch_array($result);

		} else {

			$image_id = func_get_arg(0);
			$field    = func_get_arg(1);
			$query    = "SELECT ($field) FROM images WHERE image_id='$image_id'";
			$result   = $db->query($query);
			$return   = $db->result($result);

		}

		// Free the result.
		$db->free($result);

		// Return what they want.
		return $return;
	}

	//
	// Function: update ( $image_id, $field, $value )
	//
	// Purpose:  Changes the setting of a field listed below for the given image_id.
	//
	// Arguments:
	//   $field -> The field to change.
	//             * image_name
	//             * image_desc
	//             * image_type
	//   $value -> The value to change the field to.
	//
	// Returns:  TRUE.
	//

	function update ($image_id, $field, $value)
	{
		// Import CONF.
		global $CONF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();

		// Connect to the database to check the access.
		$db->pconnect();

		// Prepare the query.
		$query = "UPDATE images SET $field='$value' WHERE image_id='$image_id'";

		// Execute the query.
		$result = $db->query($query);

		return TRUE;
	}
		
	//
	// Function: form ( [$image_id] )
	//
	// Purpose:  Creates a form used for adding and editing
	//           image_id.
	//
	// Arguments:
	//   $image_id -> If image_id is provided, then use those values.
	//
	// Returns:  Nothing.
	//

	function form()
	{
		// Import CONF.
		global $CONF;

		// Import SYSTEM and XHTML classes, if needed.
		require_once("$CONF[local_path]/class/system-class.php");
		require_once("$CONF[local_path]/class/xhtml-class.php");	

		// Make new SYSTEM and XHTML objects.
		$system = new system();
		$xhtml  = new xhtml();

		// Retrieve the image file listing.
		$image_list = $this->scan();

		// Check if we're editing.
		if (func_num_args() > 0) {

			// If we're editing, define the type.
			$type = 'edit';

			// Get the image_id.
			$image_id = func_get_arg(0);

			// Fetch details about that image.
			$image = $this->info($image_id);

			// Remove slashes from the image_name, image_desc & image_type.
			$image[image_name] = stripslashes($image[image_name]);
			$image[image_desc] = stripslashes($image[image_desc]);
			$image[image_type] = stripslashes($image[image_type]);

		// Otherwise we're adding.
		} else {

			// If we're adding, define the type.
			$type = 'add';

		}

		// Start a new table.
		$xhtml->table_start('normal', 500);

		// Escape PHP.
		?>
<br />
<form action='image.php?exec=<? echo $type; ?>&image_id=<? echo $image_id; ?>' method='post'>

<table class='normal' width='100%' cellpadding='5' cellspacing='0' border='0' align='center'>
<tr>
<td>

Image Name:<br />
<select name='image_info'>
<?

foreach ($image_list as $key => $value)
{
	for ($i = 0; $i < count($image_list[$key]); ++$i) {

		// Make easy references.
		$tmp_image_type =& $key;
		$tmp_image_name =& $image_list[$key][$i];

		// Check if it's selected.
		if (!strcmp($image[image_type], $tmp_image_type)
			&& !strcmp($image[image_name], $tmp_image_name)) {

			$att_selected = "selected='selected'";

		} else {

			$att_selected = '';

		}

		// Print the HTML.
		echo "<option value='$tmp_image_type::$tmp_image_name' $att_selected>\n";
		echo "$tmp_image_type :: $tmp_image_name\n";
		echo "</option>\n";
	
	}

}

?>
</select>	
<br />
<br />

Image Description:<br />
<input type='text' name='image_desc' value="<? echo $image[image_desc]; ?>" size='40' /><br />
<br />
<br />

<input type='submit' value='<? echo ucfirst($type); ?> Image'> <input type='reset' value='Reset'>

</td>
</tr>
</table>

</form>
		<?
		// Re-enter PHP.

		// End the table.
		$xhtml->table_end();

	}

	//
	// Function: dropdown ( $type )
	//
	// Purpose:  Displays a dropdown menu of images so the user may choose one.
	//
	// Arguments:
	//   $type  -> Type of dropdown (i.e. edit or delete).
	//
	// Returns:  Nothing.
	//
	
	function dropdown ($type)
	{
		// Import CONF;
		global $CONF;

		// Import MYSQL and XHTML classes, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");
		require_once("$CONF[local_path]/class/xhtml-class.php");

		// Create MYSQL and XHTML objects.
		$db     = new mysql();
		$xhtml  = new xhtml();

		// Connect to the DB.
		$db->pconnect();

		// Retrieve the images listing.
		$query  = "SELECT * FROM images ORDER BY image_type";
		$result = $db->query($query);

		// Make the argument string for the form.
		if (!strcmp($type, 'edit')) {
			$argument = 'form=edit';

		// Otherwise we're deleting.
		} else {
			$argument = 'exec=delete';

		}
		// Start the table.
		$xhtml->table_start('normal', 500);

		// Start the form.
		echo "<br />\n";
		echo "<form action='image.php?$argument' method='post'>\n";
		echo "<select name='image_id'>\n";

		// Check if there are results.
		if ($db->num_rows($result)) {

			// Display the image list.
			while ($list = $db->fetch_array($result))
			{	
				// Strip the slashes from the 
				$list[image_desc] = stripslashes($list[image_desc]);

				// Print the information.
				echo "<option value='$list[image_id]'>$list[image_desc]</option>\n";
			}

		// Otherwise say there are not.
		} else {
			echo "<option value='%123%'>(No Images Exist)</option>\n";

		}

		// Prepare string.
		$type = ucfirst($type);

		// End the form and list.
		echo "</select><br />\n";
		echo "<br />\n";
		echo "<input type='submit' value='$type Image'>\n";
		echo "</form>\n";

		// End the table.
		$xhtml->table_end();

		// Free the result.
		$db->free($result);
	}

	//
	// Function: i_list ( $field )
	//
	// Purpose:  Retrieves a list array of any given field name.
	//
	// Arguments:
	//   $field -> Can be any of the values written below.
	//
	// Returns:  An array with one of the following list of values.
	//   image_name -> The image's filename (i.e. general.jpg).
	//   image_desc -> The image's description (i.e. General Section Image).
	//   image_type -> The image's type (i.e. section).
	//

	function i_list ($field)
	{
		// Import CONF.
		global $CONF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();

		// Connect to the database to check the access.
		$db->pconnect();

		// Prepare the query.
		$query  = "SELECT ($field) FROM images";
		$result = $db->query($query);

		// Cycle through the results, making them into a list.
		while ($list = $db->fetch_array($result))
			$return[] = $list[$field];

		// Free the result.
		$db->free($result);

		// Return the answer.
		return $return;
	}

	//
	// Function: check ( $image_id )
	//
	// Purpose:  Checks if the image_id exists.
	//
	// Arguments:
	//   $image_id -> The target image_id.
	//
	// Returns:  1 if the image_id exists, 0 if it does not.
	//

	function check ($image_id)
	{
		// Import CONF.
		global $CONF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();
		
		// Connect to the DB.
		$db->pconnect();

		// Prepare and execute the query.
		$query  = "SELECT * FROM images WHERE image_id='$image_id'";
		$result = $db->query($query);

		// Check if we got a result.
		$return = $db->num_rows($result);

		// Free the result.
		$db->free($result);

		// Return the answer.
		return $return;
	}

	//
	// Function: scan ( )
	//
	// Purpose:  Scans for images in the specified image directory.
	//
	// Returns:  An array of possible image filenames or -1 for no
	//           images found.
	//

	function scan()
	{
		// Import CONF.
		global $CONF;

		// Import SYSTEM class, if needed.
		require_once("$CONF[local_path]/class/system-class.php");

		// Make new SYSTEM object.
		$system = new system();

		// Define the image directory.
		$image_dir = $CONF[local_path] . '/i';

		// Scan for directories.
		$dir_list  = $system->fs_list($image_dir, 1);

		// Make sure we got some directories.
		if (count($dir_list) < 1) {

			echo $dir_list;

			// Return 'no images' error.
			return -1;

		}

		// Now scan those directories for images.
		for ($i = 0; $i < count($dir_list); ++$i) {

			// Copy the return array of images in an array.
			$return[$dir_list[$i]] = $system->fs_list($image_dir . '/' . $dir_list[$i], 2);

		}

		// Return the list of files.
		return $return;
	}
}