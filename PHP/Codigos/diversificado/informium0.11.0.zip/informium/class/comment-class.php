<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Comment Class (comment-class.php)
//
// Author: Cameron McKay
// Note:   Class that allows for the manipulation of comments.
//

class comment
{
	// Constructor function.
	function comment()
	{
		// Does nothing.
	}

	//
	// Function: add ( $user_id, $assoc_id, $assoc_type, $title, $text )
	//
	// Purpose:  Adds a comment to the Informium database.
	//
	// Arguments:
	//   $user_id    -> The poster's user_id.
	//   $assoc_id   -> The associated post_id or comment_id.
	//   $assoc_type -> Either 'T_ARTICLE' or 'T_COMMENT'.
	//   $title      -> The comment's title.
	//   $text       -> The comment's text.
	//   $more_text -> The article's extended text.
	//	
	// Returns:  The new comment_id, or -1 for empty field.
	//

	function add ($user_id, $assoc_id, $assoc_type, $title, $text)
	{
		// Call the post() function to insert the comment.
		return $this->post($user_id, 0, $assoc_id, $assoc_type, $title, $text);
	}

	//
	// Function: edit ( $user_id, $comment_id, $title, $text )
	//
	// Purpose:  Edits an article in the Informium database.
	//
	// Arguments:
	//   $user_id    -> The poster's user_id.
	//   $comment_id -> The comment's comment_id.
	//   $title      -> The comment's title.
	//   $text       -> The comment's text.
	//
	// Returns:  The comment_id, or -1 for empty field.
	//

	function edit ($user_id, $comment_id, $title, $text)
	{
		// Call the post() function to update the article.
		return $this->post($user_id, $comment_id, 0, 0, $title, $text);
	}

	//
	// Function: delete ( $comment_id )
	//
	// Purpose:  Deletes a comment from the Informium database.
	//
	// Arguments:
	//   $comment_id -> The comment's comment_id.
	//
	// Returns:  Nothing.
	//

	function delete ($comment_id)
	{
		// Import CONF.
		global $CONF;

		// Import the MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Create a new MYSQL object.
		$db = new mysql();

		// Connect to the DB.
		$db->pconnect();

		// Prepare and execute the query.
		$query  = "DELETE FROM comments WHERE comment_id='$comment_id'";
		$result = $db->query($query);
	}

	//
	// Function: post ( $user_id, $comment_id, $assoc_id, $assoc_type, $title, $text )
	//
	// Purpose:  Adds or edits a comment into the database.
	//
	// Arguments:
	//   $user_id    -> The poster's user_id.
	//   $comment_id -> The comment's comment_id.
	//   $assoc_id   -> The associated post_id or comment_id.
	//   $assoc_type -> Either 'T_ARTICLE' or 'T_COMMENT'.
	//   $title      -> The comment's title.
	//   $text       -> The comment's text.
	//
	// Returns:  The new comment_id, or -1 for empty field.
	//
	
	function post ($user_id, $comment_id, $assoc_id, $assoc_type, $title, $text)
	{
		// Import CONF, cookie, and auto-options.
		global $CONF, $COOKIE1, $REMOTE_ADDR, $auto_newl, $auto_link;

		// Import COOKIE, MYSQL, SYSTEM and USER classes, if needed.
		require_once("$CONF[local_path]/class/cookie-class.php");
		require_once("$CONF[local_path]/class/mysql-class.php");
		require_once("$CONF[local_path]/class/system-class.php");
		require_once("$CONF[local_path]/class/user-class.php");
 
		// Make new COOKIE, MYSQL, SYSTEM and USER objects.
		$cookie = new cookie();
		$db     = new mysql();
		$system = new system();
		$user   = new user();

		// If the association id and type are 0, then retrieve them.
		if (($assoc_id == 0) && ($assoc_type == 0)) {
			// Retrieve values from database.
			$assoc_id   = $this->info($comment_id, 'assoc_id');
			$assoc_type = $this->info($comment_id, 'assoc_type');
		}

		// Check the association type (assoc_type) to make sure it's valid or
		// needs to be retrieved.
		// If it's T_ARTICLE or T_COMMENT it's fine.
		if (!(!strcmp($assoc_type, 'T_ARTICLE') || !strcmp($assoc_type, 'T_COMMENT')))
			// Otherwise it's fatal error.
			die("INFORMIUM: Unknown association type '$assoc_type'.<br />\n");

		// Put the arguments in a list for easier manipulation.
		$list = array($title, $text);

		// Check if we need to strip html.
		if ($CONF[html_enable] == 0)
			// No tags allowed.
			$allow = '';

		// Check if we're using HTML-Informium.
		else if ($CONF[html_enable] == 2)
			$allow = '<b>,<i>,<u>,<br>,<a>';

		// Check if we're using user defined HTML.
		else if ($CONF[html_enable] == 3)
			// Allow user defined tags.
			$allow = $CONF[html_tags];

		// Manipulate the data as needed.
		for ($i = 0; $i < count($list); ++$i) {

			// Check if we want to convert newlines to line breaks.
			if ($auto_newl)
				$list[$i] = $system->auto_newl($list[$i]);

			// Check if we want to automatically link hyperlinks.
			if ($auto_link)
				$list[$i] = $system->auto_link($list[$i]);
						
			// Strip HTML (if needed).
			if ($CONF[html_enable] != 1)
				$list[$i] = strip_tags($list[$i], $allow);

			// Check if the string contains data.
			if(strlen($list[$i]) < 1)
				// Return the 'empty field' error.
				return -1;

			// Add slashes.
			$list[$i] = addslashes($list[$i]);

		}

		// Check if we have a comment_id that's greater than 0.  If we do, then
		// we're merely updating a post.
		if ($comment_id > 0) {

			// Get the original create_date (since UPDATE automatically changes the timestamp...)
			$create_date = $this->info($comment_id, 'create_date');

			// Append the (Edited by USER at DATE) tag to post (only if the access level is less than 3).
			if (($CONF[edit_notify] == TRUE) && ($user->info(0, 'access') < 3)) {

				// Determine the current user's username.
				$username = $user->info(0, 'username');

				// Determine the current date.
				$date = $system->date_format(0, 'now');

				// Append it to the post.
				$text .= "\n<br />\n<br />\n(Edited by $username @ $date)";
			
			}

			// Get the original create_date (since UPDATE automatically changes the timestamp...)
			$create_date = $this->info($comment_id, 'create_date');

			// Prepare the update.
			$query = "UPDATE comments 
					SET user_id='$user_id', title='$title', text='$text', create_date='$create_date', modify_date=NOW()
					WHERE comment_id='$comment_id'";

		// Otherwise we're adding a new one.
		} else { 

			// Determine IP and Host Addresses.
			$ip   = $REMOTE_ADDR;
			$host = gethostbyaddr($REMOTE_ADDR);

			// Prepare the addition.
			$query  = "INSERT INTO comments VALUES('', $assoc_id, '$assoc_type', '$user_id', '$ip', '$host', '$list[0]', '$list[1]', NOW(), NOW())";

		}

		// Connect to the DB.
		$db->pconnect();

		// Execute the query.
		$db->query($query);

		// Fetch the post_id for return, if needed.
		if ($comment_id < 1)
			$comment_id = $db->insert_id();

		// Return the values that were added.
		return $comment_id;
	}

	//
	// Function: info ( $comment_id, $type )
	//
	// Purpose:  Fetches certain or all information about a particular post.
	//
	// Arguments:
	//   $comment_id -> The comment_id of the comment whose information will be retrieved.
	//	 $type       -> Can be any of the values written below or blank.
	//
	// Returns:
	//   comment_id  -> The comments's id number (I know, redundant, but useful for cleanliness).
	//   assoc_id    -> The associated post_id or comment_id.
	//   assoc_type  -> Either 'T_ARTICLE' or 'T_COMMENT'.	
	//   user_id     -> The poster's user_id.
	//   ip          -> The poster's IP Address.
	//   host        -> The poster's Host Address.
	//   title       -> The comment's title.
	//   text        -> The comment's text.
	//   create_date -> The comment's creation date.
	//   modify_date -> The comment's last modification date.
	//   

	function info ()
	{
		// Import CONF.
		global $CONF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();

		// Connect to the database to check the access.
		$db->pconnect();

		// If we have no arguments, then get them all.
		if (func_num_args() < 2) {

			$comment_id = func_get_arg(0);
			$query      = "SELECT * FROM comments WHERE comment_id='$comment_id'";
			$result     = $db->query($query);
			$return     = $db->fetch_array($result);

		} else {

			$comment_id = func_get_arg(0);
			$field      = func_get_arg(1);
			$query      = "SELECT ($field) FROM comments WHERE comment_id='$comment_id'";
			$result     = $db->query($query);
			$return     = $db->result($result);

		}

		// Free the result.
		$db->free($result);

		// Return what they want.
		return $return;
	}

	//
	// Function: update ( $comment_id, $field, $value )
	//
	// Purpose:  Changes the setting of a field listed below for the given comment_id.
	//
	// Arguments:
	//   $comment_id -> The target comment_id.
	//   $field ->      The field to change.
	//                  * assoc_id
	//                  * assoc_type
	//                  * user_id
	//                  * ip
	//                  * host
	//                  * title
	//                  * text
	//                  * create_date
	//                  * modify_date
	//   $value -> The value to change the field to.
	//
	// Returns:  TRUE.
	//

	function update ($comment_id, $field, $value)
	{
		// Import CONF.
		global $CONF;

		// Import MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Make a new MYSQL object.
		$db = new mysql();

		// Connect to the database to check the access.
		$db->pconnect();

		// Check if we're dealing with create_date.
		// If we are, then we need a special query.
		if (!strcasecmp($field, 'create_date')) {
			// Prepare the query.
			$query = "UPDATE comments SET $field='$value' WHERE comment_id='$comment_id'";

		// Otherwise proceed as normal.
		} else {
			// Get the original create_date...
			$create_date = $this->info($post_id, 'create_date');

			// Prepare the query.
			$query = "UPDATE news SET $field='$value', create_date='$create_date' WHERE comment_id='$comment_id'";

		}

		// Execute the query.
		$result = $db->query($query);

		return TRUE;
	}

	//
	// Function: form ( $comment_id )
	//
	// Purpose:  Creates a form used for adding and editing
	//           articles.
	//
	// Arguments:
	//   $comment_id -> The comment's comment_id.
	//
	// Returns:  Nothing.
	//

	function form ($comment_id)
	{
		// Import CONF and INF.
		global $CONF, $INF;

		// Import SYSTEM, USER and XHTML classes, if needed.
		require_once("$CONF[local_path]/class/system-class.php");
		require_once("$CONF[local_path]/class/user-class.php");
		require_once("$CONF[local_path]/class/xhtml-class.php");	

		// Make new SYSTEM, USER and XHTML objects.
		$system = new system();
		$user   = new user();
		$xhtml  = new xhtml();

		// Get the user_id list.
		$user_list = $user->i_list('user_id');

		// Determine access level.
		$access = $user->info(0, 'access');

		// Check if user is Power Class (Level 1 - 2) or User Class (Level 3 - 4) and set the disabled attribute
		// of author field.
		if ($access > 2) {
			$att_disabled = "";

		} else {
			$att_disabled = "disabled='disabled'";

		}

		// Define our type as 'edit'.
		$type = 'edit';

		// Fetch details about that post.
		$list = $this->info($comment_id);
		
		// Convert user_id to username, fetch email address.
		$list[username] = $user->to_name($list[user_id]);
		$list[email]    = $user->info($list[user_id], 'email');

		// Remove slashes from title and text.
		$list[title] = stripslashes($list[title]);
		$list[text]  = stripslashes($list[text]);

		$list[create_date] = $system->date_format($comment_id, 'create_date', 'comments');
		$list[modify_date] = $system->date_format($comment_id, 'modify_date', 'comments');

		// Start a new table.
		$xhtml->table_start('normal', 500);

		// Escape PHP.
		?>
<br />
<form action='comment.php?exec=<? echo $type; ?>&comment_id=<? echo $comment_id; ?>' method='post'>

<table class='normal' width='100%' cellpadding='5' cellspacing='0' border='0' align='center'>
<tr>
<td>Ownership:</td>
<td>
<select name='user_id' <? echo $att_disabled; ?>>
<? 

// Check access level.
// If the user is a Level 3 or 4 user, they can change the author name.
if ($access > 2) {

	// Cycle through the user_id list.
	for ($i = 0; $i < count($user_list); ++$i)
	{
		// Make a temporary user_id variable and reference it the user_id.
		$tmp_user_id  = $user_list[$i];

		// Make a temporary username variable and assign it the username.
		$tmp_username = $user->to_name($user_list[$i]);
	
		// Check if it's selected.
		if (!strcmp($list[username], $tmp_username)) {
			$att_selected = "selected='selected'";

		} else {
			$att_selected = "";

		}

		// Print the HTML.
		echo "<option value='$tmp_user_id' $att_selected>$tmp_username</option>\n";
	}

// If they're Level 1 or 2, they can do nothing to the author name.
} else {

	echo "<option value='0' selected='selected'>$list[username]</option>\n";

}

?>
</select>	
</td>
</tr>
<tr>
<td>Locked?</td>
<td>
<select name='section' disabled='disabled'>
<option value='123' selected='selected'>Not Implemented</option>
</select>	
</td>
</tr>
</table>

<table class='normal' width='100%' cellpadding='5' cellspacing='0' border='0' align='center'>
<tr>
<td>

Title:<br />
<input type='text' name='title' value="<? echo $list[title]; ?>" size='40' /><br />
<br />

Text:<br />
<textarea name='text' rows='5' cols='50'><? echo $list[text]; ?></textarea><br />
<br />

<input type='checkbox' class='checkbox' name='auto_newl' checked='checked' />&nbsp;Convert New Lines to Line Breaks.<br />
<input type='checkbox' class='checkbox' name='auto_link' checked='checked' />&nbsp;Automatic URL Hyperlink.<br />
<br />

<table class='normal' width='100%' cellpadding='5' cellspacing='0' border='0' align='center'>
<tr>
<td>Creation Date:</td><td><b><? echo $list[create_date]; ?></b></td>
</tr>
<tr>
<td>Mod. Date:</td><td><b><? echo $list[modify_date]; ?></b></td>
</tr>
<tr>
<td>Current Date:</td><td><b><? echo $system->date_format(0, 'now', 'news'); ?></b></td>
</tr>
</table>
<br />

<input type='submit' value='Edit Comment'> <input type='reset' value='Reset'>

</td>
</tr>
</table>

</form>
		<?
		// Re-enter PHP.

		// End the table.
		$xhtml->table_end();

	}

	//
	// Function: date_select ( $type )
	//
	// Purpose:  Displays a forms method for browsing the archives.
	//
	// Arguments:
	//   $type -> Type of archive form (either edit or delete).
	//
	// Returns:  Nothing.
	//

	function date_select ($type)
	{
		// Import CONF and COOKIE.
		global $CONF, $COOKIE1;

		// Import COOKIE, MYSQL, USER and XHTML classes, if needed.
		require_once("$CONF[local_path]/class/cookie-class.php");
		require_once("$CONF[local_path]/class/mysql-class.php");
		require_once("$CONF[local_path]/class/system-class.php");
		require_once("$CONF[local_path]/class/user-class.php");
		require_once("$CONF[local_path]/class/xhtml-class.php");

		// Create COOKIE, MYSQL, SYSTEM, USER and XHTML objects.
		$cookie = new cookie();
		$db     = new mysql();
		$system = new system();
		$user   = new user();	
		$xhtml  = new xhtml();

		// Make a new MYSQL object.
		$db = new mysql();
 
		// Connect to the database to check the access.
		$db->pconnect();

		// Determine the "day range".
		 $query[] = "SELECT DISTINCT DAYOFMONTH(create_date) AS comment_dd FROM comments ORDER BY comment_dd";
		$result[] = $db->query($query[0]);

		// Determine the "month range".
		 $query[] = "SELECT DISTINCT MONTH(create_date) AS comment_mm FROM comments ORDER BY comment_mm";
		$result[] = $db->query($query[1]);

		// Determine the "year range".
		 $query[] = "SELECT DISTINCT YEAR(create_date) AS comment_yy FROM comments ORDER BY comment_yy";
		$result[] = $db->query($query[2]);

		// Start the table.
		$xhtml->table_start('normal', 500);

		// Start the form.
		echo "<br />\n";
		echo "<form action='comment.php?dropdown=$type' method='post'>\n";
		echo "<table class='normal' width='100%' cellpadding='5' cellspacing='0' border='0' align='center'>\n";

		// Show Day of Month selection.
		echo "<tr>\n";
		echo "<td>Day of Month:</td>\n";
		echo "<td>\n";
		echo "<select name='comment_dd'>\n";

		// Check if there are results.
		if ($db->num_rows($result[0])) {

			while ($list = $db->fetch_array($result[0]))
			{
				// Print the information.
				echo "<option value='$list[comment_dd]'>$list[comment_dd]</option>\n";
			}

		// Otherwise say there are not.
		} else {
			echo "<option value='%123%'>(no results found)</option>\n";

		}

		// End Day of Month selection.
		echo "</select>\n";
		echo "</td>\n";
		echo "</tr>\n";

		// Show Month selection.
		echo "<tr>\n";
		echo "<td>Month:</td>\n";
		echo "<td>\n";
		echo "<select name='comment_mm'>\n";

		// Check if there are results.
		if ($db->num_rows($result[1])) {

			while ($list = $db->fetch_array($result[1]))
			{
				// Print the information.
				echo "<option value='$list[comment_mm]'>$list[comment_mm]</option>\n";
			}

		// Otherwise say there are not.
		} else {
			echo "<option value='%123%'>(no results found)</option>\n";

		}

		// End Month selection.
		echo "</select>\n";
		echo "</td>\n";
		echo "</tr>\n";

		// Show Year selection.
		echo "<tr>\n";
		echo "<td>Year:</td>\n";
		echo "<td>\n";
		echo "<select name='comment_yy'>\n";

		// Check if there are results.
		if ($db->num_rows($result[2])) {

			while ($list = $db->fetch_array($result[2]))
			{
				// Print the information.
				echo "<option value='$list[comment_yy]'>$list[comment_yy]</option>\n";
			}

		// Otherwise say there are not.
		} else {
			echo "<option value='%123%'>(no results found)</option>\n";

		}

		// End Year selection.
		echo "</select>\n";
		echo "</td>\n";
		echo "</tr>\n";

		// End the form and list.
		echo "</table>\n";
		echo "<br />\n";
		echo "<input type='submit' value='Show Archived Comments'>\n";
		echo "</form>\n";

		// End the table.
		$xhtml->table_end();

	}

	//
	// Function: dropdown ( $type, $limit )
	//
	// Purpose:  Displays a dropdown menu of posts so the user may choose one.
	//
	// Arguments:
	//   $type  -> Type of dropdown (i.e. edit or delete).
	//   $limit -> Number of items in the dropdown.
	//
	// Returns:  Nothing.
	//
	
	function dropdown ($type, $limit, $date = NULL)
	{
		// Import CONF and COOKIE.
		global $CONF, $COOKIE1;

		// Import COOKIE, MYSQL, USER and XHTML classes, if needed.
		require_once("$CONF[local_path]/class/cookie-class.php");
		require_once("$CONF[local_path]/class/mysql-class.php");
		require_once("$CONF[local_path]/class/system-class.php");
		require_once("$CONF[local_path]/class/user-class.php");
		require_once("$CONF[local_path]/class/xhtml-class.php");

		// Create COOKIE, MYSQL, SYSTEM, USER and XHTML objects.
		$cookie = new cookie();
		$db     = new mysql();
		$system = new system();
		$user   = new user();	
		$xhtml  = new xhtml();

		// Make a new MYSQL object.
		$db = new mysql();
 
		// Connect to the database to check the access.
		$db->pconnect();

		// Retrieve user_id of current user, and check cookie.
		if(!(list($user_id, $username, $password, $ip) = $cookie->decode($COOKIE1)))
			die("INFORMIUM: Cookie values illegally changed.<br />\n");

		// Determine user's access level.
		$access = $user->info(0, 'access');

		// Query the database depending on access level.
		// If access is 1 or 2 than we can only see our own posts.
		if ($access < 3) {

			// If 'date' is NULL, do nothing extra.
			if ($date == NULL) {
				$query = "SELECT * FROM comments WHERE user_id='$user_id' ORDER BY create_date DESC LIMIT $limit"; 
			
			// Otherwise, we search for that particular date.
			} else {
				$query = "SELECT * FROM comments WHERE user_id='$user_id' AND create_date LIKE '{$date}______' ORDER BY create_date DESC";

			}

		// If access is 3 or 4, than we can edit anyone's post.
		} else if ($access > 2) {

			// If 'date' is NULL, do nothing extra.
			if ($date == NULL) {
				$query = "SELECT * FROM comments ORDER BY create_date DESC LIMIT $limit"; 
			
			// Otherwise, we search for that particular date.
			} else {
				$query = "SELECT * FROM comments WHERE create_date LIKE '{$date}______' ORDER BY create_date DESC";

			}
			
		}

		// Execute the query.
		$result = $db->query($query);

		// Make the argument string for the form.
		if (!strcmp($type, 'edit'))
			$argument = 'form=edit';

		// Otherwise we're deleting.
		else
			$argument = 'exec=delete';

		// Start the table.
		$xhtml->table_start('normal', 500);

		// Start the form.
		echo "<br />\n";
		echo "<form action='comment.php?$argument' method='post'>\n";
		echo "<select name='comment_id'>\n";

		// Display the post list.
		while ($list = $db->fetch_array($result))
		{
			// Fetch the create_date.
			$create_date = $system->date_format($list[comment_id], 'create_date', 'comments');

			// Determine the username.
			$list[username] = $user->to_name($list[user_id]);

			// Get the first 10 characters from the title.
			$list[title] = substr($list[title], 0, 10);

			// Print the information.
			echo "<option value='$list[comment_id]'>($create_date) $list[username] #$list[comment_id] $list[title]...</option>\n";
		}

		// Prepare string.
		$type = ucfirst($type);

		// End the form and list.
		echo "</select><br />\n";
		echo "<br />\n";
		echo "<input type='submit' value='$type Comment'>\n";
		echo "</form>\n";

		// End the table.
		$xhtml->table_end();

		// Free the result.
		$db->free($result);
	}

	//
	// Function: check ( $comment_id, $user_id )
	//
	// Purpose:  Checks if the user owns the specified comment.
	//
	// Arguments:
	//   $comment_id -> The comment to check's comment_id.
	//   $user_id    -> The user to check's user_id.
	//
	// Returns: 1 if owned, 0 if not owned.
	//

	function check ($comment_id, $user_id)
	{
		// Import CONF and COOKIE1.
		global $CONF, $COOKIE1;

		// Import MYSQL and USER class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");
 
		// Make new MYSQL object.
		$db   = new mysql();
 
		// Connect to the DB.
		$db->pconnect();
 
		// Prepare and execute the query.
		$query  = "SELECT * FROM comments WHERE comment_id='$comment_id' AND user_id='$user_id'";
		$result = $db->query($query);
 
		// If user owns comment, return 1.
		if ($db->num_rows($result))
			$return = 1;

		// If user does not own comment, return 0.
		else
			$return = 0;

          // Free the result.
          $db->free($result);

		// Return the answer.
		return $return;
	}

	//
	// Function: prepare ( $list )
	//
	// Purpose:
	// Prepares the needed variables for a template and
	// outputs the currently selected template.
	//
	// Arguments:
	//   $list -> An array containing the retrieved infromation of a post.
	//
	// Returns: Nothing.
	//

	function prepare ($list)
	{
		// Import CONF.
		global $CONF;

		// Import COMMENT, SYSTEM and USER classes, if needed.
		require_once("$CONF[local_path]/class/comment-class.php");
		require_once("$CONF[local_path]/class/system-class.php");
		require_once("$CONF[local_path]/class/user-class.php");

		// Make new COMMENT, SYSTEM and USER objects.
		$comment = new comment();
		$user    = new user();
		$system  = new system();

	    // Retrieve the user's username.
	    $list[username] = $user->to_name($list[user_id]);
	    $list[email]    = $user->info($list[user_id], 'email');

	    // Format the creation and modification dates.
	    $list[create_date] = $system->date_format($list[comment_id], 'create_date', 'comments');
	    $list[modify_date] = $system->date_format($list[comment_id], 'modify_date', 'comments');

	    // Stripslashes from text and more_text.    
		$list[title] = stripslashes($list[title]); 
	    $list[text]  = stripslashes($list[text]);

		// Create the comment link & root page link.
		$list[link_comment]  = "index.php?do=form&assoc_id=$list[assoc_id]";
		$list[link_root]     = $CONF[www_address];

		// Return the list.
		return $list;
	}

}