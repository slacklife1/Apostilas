<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Cookie Class (cookie-class.php)
//
// Author: Cameron McKay
// Note:   This contains all the functions Informium needs to manipulate
//         cookies.
//

class cookie
{
	//
	// Function: encode ( $name, $value1, $value2 ... )
	//
	// Purpose:  Sets the cookie 'name' with the values defined by value1, value2 ...
	//
	// Arguments:
	//   $name   -> The name of the cookie.
	//   $value# -> The desired value to be placed in the cookie.
	//
	// Returns:  Whatever setcookie() would return.
	//

	function encode()
	{
		// Load the general config.
		global $CONF;

		// Check to make sure we have at least 2 arguments.
		if (func_num_args() < 2)
			die("INFORMIUM: encode() needs at least two values.<br />\n");

		// Copy the arguments to an editable array.
		$value = func_get_args();

		// Pop off the name from the front.
		$name  = array_shift($value);

		// Make a hash for improved security.
		$hash  = md5(serialize($value));

		// Add the hash to the array.
		array_push($value, $hash);

		// Copy the arguments to an array.
		$value = serialize($value);
	
		// Set the cookie.
		return setcookie($name, $value, mktime(0, 0, 0, 1, 1, 2010), '/', $CONF[www_cookie], 0);
	}
		
	//
	// Function: login ( $username, $password, $ip )
	//
	// Purpose:  Using the the username, password, and IP of a user, 
	//           it sends a somewhat secure cookie.
	//
	// Arguments:
	//   $user_id  -> The user_id of the user.
	//   $username -> The username of the user.
	//   $password -> The user's password (in MD5 encrypted form PLEASE).
	//   $ip       -> The IP address of the user.
	//
	// Returns:  Whatever the setcookie() function would return.
	//

	function login($user_id, $username, $password, $ip)
	{
		// Load the general config.		
		global $CONF;

		// The cookie's name (COOKIE1).
		$name = 'COOKIE1';
			
		// Now create a hash to ensure that the values in the cookie
		// are right, even if they are modified (so that if the malicious
		// user attempts to hand edit the cookie for some reason unknown, we
		// have another copy to verify it against).
		// NOTE: This is automatically done by encode().

		// Send the cookie.
		return $this->encode($name, $user_id, $username, $password, $ip);
	}

	//
	// Function: decode ( $cookie )
	//
	// Purpose:  Decodes the current user's cookie.
	//
	// Returns:  An associative array containing the values of a standard Informium
	//           cookie, or '0' if the cookie does not verify or does not exist.
	//
	// NOTE:     Informium always assumes that there is a hash value for the last value in
	//           a cookie array.
	//

	function decode($cookie)
	{
		// Extract the values.
		$value = unserialize(stripslashes($cookie));

		// Extract the hash.
		$hash  = array_pop($value);

		// Make the check hash.
		$check_hash = md5(serialize($value));

		// Check it with the encoded hash.
		if ($check_hash != $hash)
			return 0;

		// Otherwise return the values.
		else 
			return $value;
	}
	
	//
	// Function: logout ( )
	//
	// Purpose:  De-activates the login cookie (so the user is no longer logged in).
	//
	// Returns:  Nothing.
	//

	function logout()
	{
		// Load the general config.
		global $CONF;

		// The cookie's name (COOKIE1).
		$name  = 'COOKIE1';
		$value = 'logged_out';

		// Send a cookie telling Informium the user is logged out.
		$this->encode($name, $value);
	}

	//
	// Function: lcheck ( )
	//
	// Purpose:  Checks to see if the login cookie is present.
	//
	// Returns:  1 if the cookie exists (and verifies) or 0 if it doesn't.
	//

	function lcheck()
	{
		// Load the INF array and cookie.
		global $CONF, $COOKIE1;

		// Check if cookie even exists in the first place.
		if (!isset($COOKIE1))
			return 0;

		// Impornt MYSQL class, if needed.
		require_once("$CONF[local_path]/class/mysql-class.php");

		// Decode and check the cookie.
		if(!(list($user_id, $username, $password, $ip) = $this->decode($COOKIE1)))
			die("INFORMIUM: Cookie values illegally changed.<br />\n");

		// Make a new MYSQL object.
		$db = new mysql();

		// Connect to the database for authenication.
		$db->pconnect();

		// Check to password and username against the database.
		$query  = "SELECT * FROM user WHERE username='$username' AND password='$password' AND access > 0";
		$result = $db->query($query);

		if($db->num_rows($result)) {

			// Free the result.
			$db->free($result);
			return 1;

		} else {

			// Free the result.
			$db->free($result);
			return 0;

		}
	}	

	//
	// Function: status ( $cookie )
	//
	// Purpose:  Checks to see if the cookie is or is not NOT_SET.
	//
	// Arguments:
	//   $name -> The name of the cookie to check.
	//
	// Returns:  TRUE if the cookie is not NOT_SET (i.e. has values), FALSE if the cookie is NOT_SET.
	//

	function status($cookie)
	{
		// Check if the cookie even exists.
		if (!isset($cookie)) {

			// Therefore cookie is not set.
			return FALSE;

		}

		// Decode the cookie.
		$value = $this->decode($cookie);

		// Check if the value is NOT_SET.
		if (!strcmp($value[0], 'NOT_SET')) {

			// Therefore cookie is NOT_SET.
			return FALSE;

		} else {

			// Therefore cookie is not NOT_SET (so it's SET).
			return TRUE;

		}
	}

}

?>
