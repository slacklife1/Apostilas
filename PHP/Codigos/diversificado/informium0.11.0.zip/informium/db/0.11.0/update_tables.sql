##
## Informium -- Advanced News Script
##
## Informiun 0.11.0 Database Modification Script (update_tables.sql)
##
## Author: Cameron McKay
## Note:   This script creates the tables need by Informium to operate with version 0.11.0.
##         This script should be run with the command: 'mysql -u imgr -p informium < update_tables.sql'.
##

## Create 'images' table.
CREATE TABLE images (
	image_id     MEDIUMINT UNSIGNED AUTO_INCREMENT NOT NULL,
	image_name   CHAR(32) NOT NULL,
	image_desc   CHAR(32) NOT NULL,
	image_type   CHAR(32) NOT NULL,
	PRIMARY KEY (image_id, image_name)
);

## Create the default 'General' image and 'No Image' image.
INSERT INTO images VALUES('1', 'no_image.jpg', 'No Section Image',      'section');
INSERT INTO images VALUES('2', 'general.jpg',  'General Section Image', 'section');

## Create 'sections' table.
CREATE TABLE sections (
	section_id   MEDIUMINT UNSIGNED AUTO_INCREMENT NOT NULL,
	section_name CHAR(32) NOT NULL,
	image_id     MEDIUMINT UNSIGNED NOT NULL,
	create_date  TIMESTAMP NOT NULL,
	PRIMARY KEY (section_id, section_name)
);

## Create the default 'General' section.
INSERT INTO sections VALUES('1', 'General', '2', NOW());

## Alter the 'news' table to allow for sections.
ALTER TABLE news ADD section_id MEDIUMINT UNSIGNED DEFAULT '1' AFTER post_id;