##
## Informium -- Advanced News Script
##
## Create DB SQL Script (create_db.sql)
##
## Author: Cameron McKay
## Note:   This script creates a MYSQL database, then a user for it.
##         This script must be run as the root MYSQL user.
##

##
## NOTE!
## This script will not work until you uncomment all the lines with a single '#' before
## them.  Before you do that, you should change 'some_pass' to be your password for that
## user and than change that in the 'class/mysql-class.php' file as well.
##

## Create the database.
#CREATE DATABASE informium;

## Create the user for the database.
#GRANT ALL PRIVILEGES ON informium.* TO imgr@localhost IDENTIFIED BY 'some_pass';
