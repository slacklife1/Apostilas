##
## Informium -- Advanced News Script
##
## Create Tables SQL Script (create_tables.sql)
##
## Author: Cameron McKay
## Note:   This script creates the tables need by Informium to run.
##         This script should be run with the command: 'mysql -u imgr -p informium < create_tables.sql'.
##

## Create 'user' table.
CREATE TABLE user (
	user_id     MEDIUMINT UNSIGNED AUTO_INCREMENT NOT NULL,
	username    CHAR(16) NOT NULL,
	password    CHAR(64) NOT NULL,
	cipher      CHAR(4) NOT NULL,
	email       CHAR(64) NOT NULL,
	access      TINYINT DEFAULT '0' NOT NULL,
	create_date TIMESTAMP NOT NULL,
	PRIMARY KEY (user_id, username)
);

## Create 'news' table.
CREATE TABLE news (
	post_id     MEDIUMINT UNSIGNED AUTO_INCREMENT NOT NULL,
	section_id  MEDIUMINT UNSIGNED NOT NULL,
	user_id     MEDIUMINT UNSIGNED NOT NULL,
	title       CHAR(64) NOT NULL,
	text        BLOB NOT NULL,
	more_text   BLOB,
	create_date TIMESTAMP NOT NULL,
	modify_date TIMESTAMP NOT NULL,
	PRIMARY KEY (post_id)
);

## Create 'comments' table.
CREATE TABLE comments (
	comment_id  MEDIUMINT UNSIGNED AUTO_INCREMENT NOT NULL,
	assoc_id    MEDIUMINT UNSIGNED NOT NULL,
	assoc_type  CHAR(16) NOT NULL,
	user_id     MEDIUMINT UNSIGNED NOT NULL,
	ip          CHAR(16) NOT NULL,
	host        CHAR(64) NOT NULL,
	title       CHAR(64) NOT NULL,
	text        BLOB NOT NULL,
	create_date TIMESTAMP NOT NULL,
	modify_date TIMESTAMP NOT NULL,
	PRIMARY KEY (comment_id)
);

## Create 'images' table.
CREATE TABLE images (
	image_id     MEDIUMINT UNSIGNED AUTO_INCREMENT NOT NULL,
	image_name   CHAR(32) NOT NULL,
	image_desc   CHAR(32) NOT NULL,
	image_type   CHAR(32) NOT NULL,
	PRIMARY KEY (image_id, image_name)
);

## Create the default 'General' image and 'No Image' image.
INSERT INTO images VALUES('1', 'no_image.jpg', 'No Section Image',      'section');
INSERT INTO images VALUES('2', 'general.jpg',  'General Section Image', 'section');

## Create 'sections' table.
CREATE TABLE sections (
	section_id   MEDIUMINT UNSIGNED AUTO_INCREMENT NOT NULL,
	section_name CHAR(32) NOT NULL,
	image_id     MEDIUMINT UNSIGNED NOT NULL,
	create_date  TIMESTAMP NOT NULL,
	PRIMARY KEY (section_id, section_name)
);

## Create the default 'General' section.
INSERT INTO sections VALUES('1', 'General', '2', NOW());

## Create the 'Anonymous' user.
INSERT INTO user VALUES (
	'1',
	'Anonymous',
	'',
	'PTXT',
	'anonymous@anonymous.com',
	'0',
	NOW()
);

## Create the temporary administrator user 'Informium'.
INSERT INTO user VALUES (
	'2',
	'Informium',
	'1affb5dd301582ec7ca347d92c609595',
	'MD5',
	'in@form.ium',
	'4',	
	NOW()
);	

## Create the first post.
INSERT INTO news VALUES (
	'',
	'2',
	'Welcome to Informium',
	'This is the test post for Informium.  I hope you enjoy the script.',
	'This is the \'Read More\' area of Informium.',
	NOW(),
	NOW()
);
