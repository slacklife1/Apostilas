<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Admin. Login Script (login.php)
//
// Author: Cameron McKay
// Note:   Authenticates the user.
//
// Changes:
// (Author)				(Date)				(Changes)
// Cameron McKay		2002/05/11			Added ability to be re-directed to any page within the root.
// Cameron McKay		2002/05/12			Removed ability to be re-directed... (didn't like it).
//

// Import CONF.
require_once('../conf/inf-conf.php');

// Title.
$title = 'Authentication';

// Import the COOKIE, MYSQL, and XHTML classes.
require_once("$CONF[local_path]/class/cookie-class.php");
require_once("$CONF[local_path]/class/mysql-class.php");
require_once("$CONF[local_path]/class/user-class.php");
require_once("$CONF[local_path]/class/xhtml-class.php");

// Create new COOKIE and XHTML objects.
$cookie = new cookie();
$user   = new user();
$xhtml  = new xhtml();

// Check if we're already authenicated.
// If we are, then forward us to the admin section.
if ($cookie->lcheck())
	header("Location: admin.php");

// Check if 'username' and 'password' have been passed.
if (isset($username) && isset($password)) {

	// Check to see if they're the 'anonymous' user.
	if (!strcasecmp($username, 'anonymous')) {

		// They're not allowed in.
		$result = 0;

	// Otherwise, check if the user exists.
	} else {

		// Check if user exists.
		$result = $user->check($username);

	}

	// If it does, then authenticated.
	if ($result == 1) {

		// Check if they're authorized.
		if ($user->authenticate($username, $password)) {

			// Set the cookie.	
			$cookie->login($user->to_id($username), $username, $user->encrypt_password($username, $password), $REMOTE_ADDR);

			// Send the user to the administration section.
			header("Location: admin.php");

		// Otherwise leave an error message.
		} else {

			// Set the error message.
			$message = "Incorrect password or username does not exist.<br />\n";

		}

	// If it doesn't then refuse authorization.
	} else if ($result == 0) {

		// Set the error message.
		$message = "Username does not exist.<br />\n";
	
	// If there are illegal characters then inform the user.
	} else if ($result == -1) {

		// Set the error message.
		$message = "Username contains illegal characters.<br />\n";

	// Otherwise something went screwy.
	} else {

		// Set the error message.
		$message = "Something went horribly, horribly wrong. (Error Code: $result)<br />\n";

	}

}

// Start the page XHTML.
$xhtml->header($title);

// Start Body.

?>

<br /><br /><br />
<br /><br /><br />

<br />
<? $xhtml->table_start('normal', 300); ?>
<form action='<? echo $PHP_SELF; ?>' method='post'>
<input type='hidden' name='redirect' value='<? echo $redirect; ?>' />
<table class='normal'>
<tr> <td>&nbsp;Username:</td> <td><input type='text'     name='username' /></td> </tr>
<tr> <td>&nbsp;Password:</td> <td><input type='password' name='password' /></td> </tr>
<tr> <td>&nbsp;&nbsp;   </td> <td><input type='submit'   value='Submit' /></td> </tr>
</table>
<? $xhtml->table_end(); ?>
<br />

<?

// Print the error message.
if (isset($message)) {

	$xhtml->table_start('normal', 300);
	echo "&nbsp;&nbsp;" . $message;
	$xhtml->table_end();

} 

// End Body.

// End the page XHTML.
$xhtml->footer();

?>
