<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Redirect Script (redirect.php)
//
// Author: Cameron McKay
// Note:   Redirects the user to the proper script.
//         
//

// Import CONF.
require_once('../conf/inf-conf.php');

// Require SYSTEM class, if needed.
require_once("$CONF[local_path]/class/system-class.php");

// Make an allowable pages array.
$allow['admin.php']          = TRUE;
$allow['article.php']        = TRUE;
$allow['comment.php']        = TRUE;
$allow['user.php']           = TRUE;
$allow['logout.php']         = TRUE;
$allow['notfound.php']       = TRUE;
$allow['section.php']        = TRUE;
$allow['image.php']          = TRUE;
$allow["$CONF[www_address]"] = TRUE;

// If we have no location, then do nothing.
if (!isset($location))
	exit;

// Otherwise, check if it's an allowed location.
// To do that, we'll need to decrypt it.
$system = new system();

// First determine the address.	
$location = $system->decrypt($location);
$position = strpos($location, '?');

// If there is a '?' then there are arugments.
if ($position) {
	$address = substr($location, 0, $position);

// Otherwise there are not.
} else {
	$address = $location; 

}

// Verify if it's allowed.
if ($allow[$address])
	header("Location: $location");

?>
