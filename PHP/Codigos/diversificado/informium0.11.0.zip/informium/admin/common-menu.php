<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Common Menu Definition (common-menu.php)
//
// Author: Cameron McKay
// Note:   The definition for the menu used in the administration area.
//

// Import the MENU, USER, SYSTEM and XHTML classes, if needed.
require_once("$CONF[local_path]/class/menu-class.php");
require_once("$CONF[local_path]/class/system-class.php");
require_once("$CONF[local_path]/class/user-class.php");
require_once("$CONF[local_path]/class/xhtml-class.php");

// Create new SYSTEM and USER objects.
$system = new system();
$user   = new user();
$xhtml  = new xhtml();

// Set the current user's user_id.
$_user_id = $user->info(0, 'user_id');

// Set the current user's access level.
$_access  = $user->info(0, 'access');

// Create new MENU objects.
$menu[0] = new menu($_access);
$menu[1] = new menu($_access);
$menu[2] = new menu($_access);
$menu[3] = new menu($_access);
$menu[4] = new menu($_access);
$menu[5] = new menu($_access);

// Misc. Options.
$menu[0]->add('123(Miscellaneous)', $system->encrypt('admin.php'),        1);
$menu[0]->add('Go to Main Menu',    $system->encrypt('admin.php'),        1);
$menu[0]->add('Return to Website',  $system->encrypt($CONF[www_address]), 1);
$menu[0]->add('Logoff User',        $system->encrypt('logout.php'),       1);

// Article Options.
$menu[1]->add('123(Article Manipulation)',  $system->encrypt('admin.php'),                      2);
$menu[1]->add('Add a New Article',          $system->encrypt('article.php?form=add'),           2);
$menu[1]->add('Edit an Existing Article',   $system->encrypt('article.php?dropdown=edit'),      2);
$menu[1]->add('Delete an Existing Article', $system->encrypt('article.php?dropdown=delete'),    2);
$menu[1]->add('Edit an Archived Article',   $system->encrypt('article.php?date_select=edit'),   2);
$menu[1]->add('Delete an Archived Article', $system->encrypt('article.php?date_select=delete'), 2);

// Comment Options.
$menu[2]->add('123(Comment Manipulation)',  $system->encrypt('admin.php'),                      1);
$menu[2]->add('Edit an Existing Comment',   $system->encrypt('comment.php?dropdown=edit'),      1);
$menu[2]->add('Delete an Existing Comment', $system->encrypt('comment.php?dropdown=delete'),    1);
$menu[2]->add('Edit an Archived Comment',   $system->encrypt('comment.php?date_select=edit'),   1);
$menu[2]->add('Delete an Archived Comment', $system->encrypt('comment.php?date_select=delete'), 1);

// User Options.
$menu[3]->add('123(User Manipulation)',  $system->encrypt('admin.php'),                 1);
$menu[3]->add('Add a New User',          $system->encrypt('user.php?form=add'),         4);
$menu[3]->add('Edit an Existing User',   $system->encrypt('user.php?dropdown=edit'),    4);
$menu[3]->add('Delete an Existing User', $system->encrypt('user.php?dropdown=delete'),  4);
$menu[3]->add('Restore a Deleted User',  $system->encrypt('user.php?dropdown=restore'), 4);
$menu[3]->add('Edit MY User',            $system->encrypt("user.php?form=edit&user_id=$_user_id"), 1);

// Section Options.
$menu[4]->add('123(Section Manipulation)',  $system->encrypt('admin.php'),                    1);
$menu[4]->add('Add a New Section',          $system->encrypt('section.php?form=add'),         4);
$menu[4]->add('Edit an Existing Section',   $system->encrypt('section.php?dropdown=edit'),    4);
$menu[4]->add('Delete an Existing Section', $system->encrypt('section.php?dropdown=delete'),  4);

// Image Options.
$menu[5]->add('123(Image Manipulation)',  $system->encrypt('admin.php'),                  1);
$menu[5]->add('Add a New Image',          $system->encrypt('image.php?form=add'),         4);
$menu[5]->add('Edit an Existing Image',   $system->encrypt('image.php?dropdown=edit'),    4);
$menu[5]->add('Delete an Existing Image', $system->encrypt('image.php?dropdown=delete'),  4);

$xhtml->table_start('header', 500);
// Escape PHP.
?>

<table class='header' width='100%' cellpadding='5' cellspacing='0' border='0' align='center'>

<form action='redirect.php' method='post'>

<tr>
<td align='left'>
<a href='admin.php' title='Go to Main Menu'><img src='<? echo "$CONF[www_address]/i/mainmenu-icon.gif"; ?>' border='0' /></a>
<a href='logout.php' title='Logoff Informium'><img src='<? echo "$CONF[www_address]/i/logoff-icon.gif"; ?>' border='0' />
</td>

<td align='right'>
<select class='small' name='location'>
<? $menu[1]->put(); ?>
<? $menu[2]->put(); ?>
<? $menu[3]->put(); ?>
<? $menu[4]->put(); ?>
<? $menu[5]->put(); ?>
<? $menu[0]->put(); ?>
</select>
<input class='small' type='submit' value='Go' />
</td>
</tr>

</form>

</table>


<?
// Re-enter PHP.
$xhtml->table_end();

echo "<br />\n";

?>
