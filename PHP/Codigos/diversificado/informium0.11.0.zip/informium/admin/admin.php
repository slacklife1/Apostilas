<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Administration Script (admin.php)
//
// Author: Cameron McKay
// Note:   Allows the user to add, edit, delete news or comments depending
//         on privileges.
//

// Load Informium General CONF.
require_once('../conf/inf-conf.php');

// Title.
$title = 'Administration';

// Import the COOKIE, MYSQL, SYSTEM and XHTML classes.
require_once("$CONF[local_path]/class/cookie-class.php");
require_once("$CONF[local_path]/class/mysql-class.php");
require_once("$CONF[local_path]/class/system-class.php");
require_once("$CONF[local_path]/class/xhtml-class.php");

// Create new COOKIE, MYSQL, SYSTEM and XHTML objects.
$cookie = new cookie(); 
$mysql  = new mysql();
$system = new system();
$xhtml  = new xhtml();

// Check to make sure the user is allowed to be here.
if (!$cookie->lcheck()) {

	// Send back to start.
	header('Location: login.php');
	exit;

}

// Start the document.
$xhtml->header($title);

// Import the common menu.
require_once("$CONF[local_path]/admin/common-menu.php");

// Gather Informium statistics.
$stats = $system->info();

$xhtml->table_start('normal', 500);
// Escape PHP.
?>

<table class='normal' width='100%' cellpadding='2' cellspacing='0' border='0' align='center'>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td><i>User Total:</i></td><td align='right'><? echo $stats[user_total]; ?></td></tr>
<tr><td><i>Post Total:</i></td><td align='right'><? echo $stats[post_total]; ?></td></tr>
<tr><td><i>Comment Total:</i></td><td align='right'><? echo $stats[comment_total]; ?></td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td><i>Today's Post Total:</i></td><td align='right'><? echo $stats[post_today]; ?></td></tr>
<tr><td><i>Today's Comment Total:</i></td><td align='right'><? echo $stats[comment_today]; ?></td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
</table>

<?
// Re-enter PHP.
$xhtml->table_end();

// End the document.
$xhtml->footer();

?>
