<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// User Administration Script (user.php)
//
// Author: Cameron McKay
// Note:   Allows for the manipulation of users.
//

// Import CONF.
require_once('../conf/inf-conf.php');

// Import USER and XHTML classes, if needed.
require_once("$CONF[local_path]/class/user-class.php");
require_once("$CONF[local_path]/class/system-class.php");
require_once("$CONF[local_path]/class/xhtml-class.php");

// Create new USER and XHTML classes.
$user   = new user();
$system = new system(); 
$xhtml  = new xhtml();

// For Header.
if ($form)     	$option =& $form;
if ($dropdown) 	$option =& $dropdown;
if ($exec)     	$option =& $exec; 

// Header.
$xhtml->header(strtoupper($option) . ' User');

// Import common menu.
require_once("$CONF[local_path]/admin/common-menu.php");

// If user's access level is less than 4, than he can't manuipulate anything
// except themselves.
if ($user->info(0, 'access') < 4) {

	// Force user_id to the current users.
	$user_id = $user->info(0, 'user_id');

	// If an underprivileged user and trying to use the edit form,
	// force them to edit themself.
	if (!strcmp($form, 'edit'))
		$user->form($user_id);

	// If an underprivileged user and trying to apply changes,
	// force them to do them to themselves, and only certain details.
	else if (!strcmp($exec, 'edit')) {

		// Respond to user.
		$xhtml->table_start('normal', 500);		

		// Retrieve current user's details.
		$list = $user->info(0);

		// If password_old is 1 (or true), then we use it.
		if ($password_old) {

			// Set the password data to the old password.
			$password = $list[password];

			// Update the article in the database.
			$user_id = $user->edit($user_id, $list[username], $password, $list[cipher], $email, $list[access]);

		// Make sure the passwords match, and that they're at least 8 characters.
		} else if (!strcmp($password, $password_check) && (strlen($password) >= 8)) {	

			// Encrypt the password using the desired cipher.
			$password = $system->do_encrypt($password, $cipher);

			// Update the article in the database.
			$user_id = $user->edit($user_id, $list[username], $password, $list[cipher], $email, $list[access]);

		} else {

			echo "Problem:<br />\n";
			echo "Passwords do not match.<br />\n";
			echo "OR Password is not at least 8 characters long.<br />\n";
			echo "<br />\n";
			echo "Return to <a href='$CONF[www_address]/admin/user.php?dropdown=edit'>Edit an Existing User</a>.\n";

			// Set the user_id to 0.
			$user_id = 0;

		}

		// If the user_id is less than 0, then we're missing a field.
		if ($user_id < 0) {

			echo "One or more fields are missing.<br />\n";
			echo "<br />\n";
			echo "Return to <a href='$CONF[www_address]/admin/user.php?form=edit'>Edit MY User</a>.\n";
			

		// If it's greater than 0, than we're fine.
		} else if ($user_id > 0) {

			echo "User <b><i>#</i>$user_id</b> edited.<br />\n";
			echo "<br />\n";
			echo "Return to <a href='$CONF[www_address]/admin/admin.php'>Main Menu</a>.\n";
	
		}
		
	}

	// Footer.
	$xhtml->footer();

	// End execution.
	exit;

}

// Determine course of action.
if (!strcmp($form, 'add'))
	// Present the user with an add form.
	$user->form();

else if (!strcmp($form, 'edit'))
	// Present the user with an edit form.
	$user->form($user_id);

else if (!strcmp($dropdown, 'edit'))
	// Present the user with a dropdown menu of all users.
	$user->dropdown('edit', -1);

else if (!strcmp($dropdown, 'delete'))
	$user->dropdown('delete', -1);

else if (!strcmp($dropdown, 'restore'))
	$user->dropdown('restore', -1, FALSE);

else if (!strcmp($exec, 'add')) {

	// Respond to user.
	$xhtml->table_start('normal', 500);

	// Make sure the passwords match, and that they're at least 8 characters.
	if (!strcmp($password, $password_check) && (strlen($password) >= 8)) {

		// Encrypt the password using the desired cipher.
		$password = $system->do_encrypt($password, $cipher);
		
		// Add the user to the database.
		$user_id = $user->add($username, $password, $cipher, $email, $access);

	// Otherwise, the passwords don't match or are too small, so tell the user.
	} else {

		echo "Problem:<br />\n";
		echo "Passwords do not match.<br />\n";
		echo "Password is not at least 8 characters long.<br />\n";
		echo "<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/user.php?option=add'>Add a New User</a>.\n";

		// Set the user_id to 0.
		$user_id = 0;
		
	}	

	// If the user_id is less than 0, then we're missing a field.
	if ($user_id < 0) {

		// If the user_id is -1 then we have illegal characters.
		if ($user_id == -1) {
			echo "Username contains illegal characters.<br />\n";
		
		// If the user_id is -2 then we have missing fields.
		} else if ($user_id == -2) {
			echo "One or more fields are missing.<br />\n";

		// If the user_id is -3 then the user already exists.
		} else if ($user_id == -3) {
			echo "Username ALREADY EXISTS!<br />\n";

		// If we don't know what the answer is, we're fucked.
		} else {
			echo "Something went terribly, terribly wrong.<br />\n";

		}

		echo "<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/user.php?form=add'>Add a New User</a>.\n";

	// If it's greater than 0, than we're fine.
	} else if ($user_id > 0) {

		echo "User <b><i>#</i>$user_id</b> added.<br />\n";
		echo "<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/admin.php'>Main Menu</a>.\n";

	}

	// End the table.
	$xhtml->table_end();

} else if (!strcmp($exec, 'edit') || !strcmp($exec, 'delete') || !strcmp($exec, 'restore')) {

	// Respond to user.
	$xhtml->table_start('normal', 500);

	if (!strcmp($exec, 'edit')) {

		// If password_old is 1 (or true), then we use it.
		if ($password_old) {

			// Set the password data to the old password.
			$password = $user->info($user_id, 'password');

			// Update the article in the database.
			$user_id = $user->edit($user_id, $username, $password, $cipher, $email, $access);

		// Make sure the passwords match, and that they're at least 8 characters.
		} else if (!strcmp($password, $password_check) && (strlen($password) >= 8)) {	

			// Encrypt the password using the desired cipher.
			$password = $system->do_encrypt($password, $cipher);

			// Update the article in the database.
			$user_id = $user->edit($user_id, $username, $password, $cipher, $email, $access);

		} else {

			echo "Problem:<br />\n";
			echo "Passwords do not match.<br />\n";
			echo "OR Password is not at least 8 characters long.<br />\n";
			echo "<br />\n";
			echo "Return to <a href='$CONF[www_address]/admin/user.php?dropdown=edit'>Edit an Existing User</a>.\n";

			// Set the user_id to 0.
			$user_id = 0;

		}
		
	} else if (!strcmp($exec, 'delete')) {

		// Make sure the user isn't suiciding.
		if (!strcasecmp($user->info(0, 'username'), $user->to_name($user_id))) {

			// Set the user_id to -4 (suicide).
			$user_id = -4;	

		// Delete the user in the database.
		} else {
			$user->delete($user_id);

		}

	} else if (!strcmp($exec, 'restore')) {

		// Restore the user in the database.
		$user->restore($user_id);

	}

	// If the user_id is less than 0, then we're missing a field.
	if ($user_id < 0) {

		// If the user_id is -2 then we have missing fields.
		if ($user_id == -2) {
			echo "One or more fields are missing.<br />\n";

		// If the user_id is -4 then we have a suiciding user.
		} else if ($user_id == -4) {
			echo "Self-termination is not permitted!<br />\n";

		// If we don't know what the answer is, we're fucked.
		} else {
			echo "Something went terribly, terribly wrong. (Error Code: $user_id)<br />\n";

		}

		echo "<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/user.php?dropdown=edit'>Edit an Existing User</a>.<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/user.php?dropdown=delete'>Delete an Existing User</a>.\n";

	// If it's greater than 0, than we're fine.
	} else if ($user_id > 0) {

		echo "User <b><i>#</i>$user_id</b> edited, deleted or restored.<br />\n";
		echo "<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/admin.php'>Main Menu</a>.\n";

	}
	// End the table.
	$xhtml->table_end();

} 

// Footer.
$xhtml->footer();

?>
