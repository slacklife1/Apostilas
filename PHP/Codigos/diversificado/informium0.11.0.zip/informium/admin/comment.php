<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Comment Administration Script (comment.php)
//
// Author: Cameron McKay
// Note:   Allows for the manipulation of comments.
//

// Import CONF.
require_once('../conf/inf-conf.php');

// Import COMMENT and XHTML class.
require_once("$CONF[local_path]/class/comment-class.php");
require_once("$CONF[local_path]/class/xhtml-class.php");

// Make new COMMENT and XHTML objects.
$comment = new comment();
$xhtml   = new xhtml();

// For Header.
if ($form)        $option = $form;
if ($date_select) $option = $date_select . ' Archived';
if ($dropdown)    $option = $dropdown;
if ($exec)        $option = $exec; 

// Header.
$xhtml->header(ucfirst($option) . ' Comment');

// Import common menu.
require_once("$CONF[local_path]/admin/common-menu.php");

// Determine course of action.
if (!strcmp($form, 'edit'))
	// Present the user with an edit form.
	$comment->form($comment_id);

else if (!strcmp($date_select, 'edit'))
	// Present the user with the date selection form.
	$comment->date_select('edit');

else if (!strcmp($date_select, 'delete'))
	// Present the user with the date selection form.
	$comment->date_select('delete');

else if (!strcmp($dropdown, 'edit')) {

	// If the comment date is set, then we're looking up archives.
	if (isset($comment_dd)) {
		// So we need to prepare a date for use with dropdown().
		$date = sprintf("%04d%02d%02d", $comment_yy, $comment_mm, $comment_dd);

	} else {
		// Otherwise date is NULL.
		$date = NULL;

	}

	// Present the user with a dropdown menu of all comments.
	$comment->dropdown('edit', $CONF[dropdown_limit], $date);

} else if (!strcmp($dropdown, 'delete')) {

	// If the comment date is set, then we're looking up archives.
	if (isset($comment_dd)) {
		// So we need to prepare a date for use with dropdown().
		$date = sprintf("%04d%02d%02d", $comment_yy, $comment_mm, $comment_dd);

	} else {
		// Otherwise date is NULL.
		$date = NULL;

	}

	// Present the user with a dropdown menu of all comments.
	$comment->dropdown('delete', $CONF[dropdown_limit], $date);

} else if (!strcmp($exec, 'edit') || !strcmp($exec, 'delete')) {

	// Import USER class, if needed.
	require_once("$CONF[local_path]/class/user-class.php");

	// Make a new USER objects.
	$user = new user();

	// Check user's access level.
	$list = $user->info(0);

	// If user's access is 2 or lower, check if they own the comment.
	if (($list[access] > 0) && ($list[access] < 3)) {
		
		// If user owns post, authorize.
		if ($comment->check($comment_id, $list[user_id]))
			$AUTH = 1;

	// If access level is greater than 2, then authorize.
	} else if ($list[access] > 2) {

		// Like I said, authorize.
		$AUTH = 2;

	}

	// If we're authorized, then edit or delete the post.
	if ($AUTH > 0) {

		if (!strcmp($exec, 'edit')) {

			// If AUTH is 1, then we're between Level 1 - 2 & therefore cannot change our
			// user_id.
			if ($AUTH == 1) {
				// Set user_id to the same one as the cookie.
				$user_id = $list[user_id];

			}
			
			// Update the comment in the database.
			$comment_id = $comment->edit($user_id, $comment_id, $title, $text);

		} else if (!strcmp($exec, 'delete')) {
			// Delete the comment in the database.
			$comment->delete($comment_id);

		}

	}

	// Respond to user.
	$xhtml->table_start('normal', 500);

	// If AUTH is not set, then we're not authorized.
	if (!isset($AUTH)) {
 
		echo "You are not authorized to edit or delete this comment.<br />\n";
		echo "<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/comment.php?dropdown=edit'>Edit an Existing Comment</a>.<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/comment.php?dropdown=delete'>Delete an Existing Comment</a>.\n";
 
	// If AUTH is set, then we're authorized.
	} else if (isset($AUTH)) {
 
		echo "Comment <b><i>#</i>$comment_id</b> edited or deleted.<br />\n";
		echo "<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/comment.php?dropdown=edit'>Edit an Existing Comment</a>.<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/comment.php?dropdown=delete'>Delete an Existing Comment</a>.<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/admin.php'>Main Menu</a>.\n";

	}	
 
     // End the table.
     $xhtml->table_end();

} 

// Footer.
$xhtml->footer();

?>
