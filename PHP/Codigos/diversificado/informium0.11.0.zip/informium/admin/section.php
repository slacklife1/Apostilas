<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// Section Administration Script (article.php)
//
// Author: Cameron McKay
// Note:   Allows for the manipulation of sections.
//

// Import CONF.
require_once('../conf/inf-conf.php');

// Import SECTION and XHTML class.
require_once("$CONF[local_path]/class/section-class.php");
require_once("$CONF[local_path]/class/xhtml-class.php");

// Make new SECTION and XHTML objects.
$section = new section();
$xhtml   = new xhtml();

// For Header.
if ($form)        $option = $form;
if ($dropdown)    $option = $dropdown;
if ($exec)        $option = $exec; 

// Header.
$xhtml->header(ucfirst($option) . ' Section');

// Import common menu.
require_once("$CONF[local_path]/admin/common-menu.php");

// Determine course of action.
if (!strcmp($form, 'add'))
	// Present the user with an add form.
	$section->form();

else if (!strcmp($form, 'edit'))
	// Present the user with an edit form.
	$section->form($section_id);

else if (!strcmp($dropdown, 'edit')) {
	// Present the user with a dropdown menu of all sections.
	$section->dropdown('edit');

} else if (!strcmp($dropdown, 'delete')) {
	// Present the user with a dropdown menu of all sections.
	$section->dropdown('delete');

} else if (!strcmp($exec, 'add')) {

	// Import USER class, if needed.
	require_once("$CONF[local_path]/class/user-class.php");

	// Make a new USER objects.
	$user = new user();

	// Check user's access level.
	$access = $user->info(0, 'access');

	// Respond to user.
	$xhtml->table_start('normal', 500);

	// If they have an access level greater than 3, than we can add sections.
	if ($access > 3) {

		// Add the section to the database.
		$section_id = $section->add($section_name, $image_id);

		// If the post_id is less than 0, then we're missing a field.
		if ($section_id < 0) {

			echo "One or more fields are missing.<br />\n";
			echo "<br />\n";
			echo "Return to <a href='$CONF[www_address]/admin/section.php?form=add'>Add a New Section</a>.\n";

		// If it's greater than 0, than we're fine.
		} else if ($section_id > 0) {

			echo "Section <b><i>#</i>$section_id</b> added.<br />\n";
			echo "<br />\n";
			echo "Return to <a href='$CONF[www_address]/admin/admin.php'>Main Menu</a>.\n";

		}

	// Otherwise warn them.
	} else {

			echo "You are not permitted to add sections.<br />\n";
			echo "<br />\n";
			echo "Return to <a href='$CONF[www_address]/admin/admin.php'>Main Menu</a>.\n";

	}
	
	// End the table.
	$xhtml->table_end();

} else if (!strcmp($exec, 'edit') || !strcmp($exec, 'delete')) {

	// Import USER class, if needed.
	require_once("$CONF[local_path]/class/user-class.php");

	// Make a new USER objects.
	$user = new user();

	// Check user's access level.
	$list = $user->info(0);

	// Respond to user.
	$xhtml->table_start('normal', 500);

	// If they have an access level greater than 3, than we can edit or delete sections.
	if ($list[access] > 3) {
		
		if (!strcmp($exec, 'edit')) {
			// Update the section in the database.
			$section_id = $section->edit($section_id, $section_name, $image_id);

		} else if (!strcmp($exec, 'delete')) {
			// Delete the section in the database.
			$section->delete($section_id);

		}

		echo "Section <b><i>#</i>$section_id</b> edited or deleted.<br />\n";
		echo "<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/section.php?dropdown=edit'>Edit an Existing Section</a>.<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/section.php?dropdown=delete'>Delete an Existing Section</a>.<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/admin.php'>Main Menu</a>.\n";

	} else {

		echo "You are not permitted to edit or delete sections.<br />\n";
		echo "<br />\n";
		echo "Return to <a href='$CONF[www_address]/admin/admin.php'>Main Menu</a>.\n";
 
	}	
 
     // End the table.
     $xhtml->table_end();

} 

// Footer.
$xhtml->footer();

?>