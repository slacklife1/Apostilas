<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// NUNE Conversion Config (config.php)
//
// Author: Cameron McKay
// Note:   Configuration file for NUNE database conversion.  Please note
//         that this script only converts databases that have the default
//         date and time format (i.e. MM-DD-YY HH:MM) or one of those 
//         supported by GNU date syntax, which the PHP method strtotime() 
//         uses.
//

// Enable Nune Conversion Script...
$NUNE_enable  = FALSE;

// NUNE date syntax...
// If you're using the default NUNE date syntax in the database, a 
// small conversion needs to be made.
$NUNE_convert = TRUE;

// Data Preservation...
// If a post exists without a matching user then the user will
// automatically be set to the 'Anonymous' user.  If this is the
// case, then you can perserve the old data by having it appended
// to the bottom of the article or comment.
$article_preserve = TRUE;
$comment_preserve = TRUE;

// NUNE Database Setup...
// Source Database and Hostname (usually 'nune' and 'localhost').
$hostname = 'localhost';
$username = 'nunemgr';
$password = 'asecret';
$database = 'nune';

// Since NUNE allowed for custom table names, you can set them here
// if you changed them.
$news_table    = 'news';
$comment_table = 'comments';
$user_table    = 'user';

//
// Function: auto_time ( $start = NULL )
//
// Purpose:  Generates a clock hour (starting at 'start' if given).
// 
// Arguments:
//   $start -> The start date, in the format 'HHMMSS'.
//
// Returns:
// An auto-time value in the format HHMMSS.
//

function auto_time ( $start = NULL )
{
	static $HH = 00;
	static $MM = 00;
	static $SS = 00;

	// Check if we have a start time.
	if ($start != NULL) {
		$HH = $start[0].$start[1];
		$MM = $start[2].$start[3];
		$SS = $start[4].$start[5];

	}

	// If seconds are divisible by 60 then:
	if (++$SS == 60) {
		// We set SS to '0' and increment minutes.
		$SS = 0;

		// If minutes are divisible by 60 then:
		if (++$MM == 60) {
			// We set MM to '0' and increment hours.
			$MM = 0;

			// If hours are divisible by 60 then:
			if (++$HH == 60) {
				// We set HH to '0'.
				$HH = 0;

			} // End HH.

		} // End MM.

	} // End SS.

	// Return the new date.
	return sprintf("%02d%02d%02d", $HH, $MM, $SS);
}

?>