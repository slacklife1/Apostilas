<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// NUNE Comment Conversion Script (comment-conv.php)
//
// Author: Cameron McKay
// Note:   Converts a NUNE comment database into an Informium-compatible one.
//

// Import Conv. Config and CONF.
require('config.php');
require('../conf/inf-conf.php');

// Make sure NUNE Conversion is enabled.
if (!$NUNE_enable) {
	// End execution.
	exit();

}

// Title.
$title = 'NUNE Comment Conversion Script';

// Import the MYSQL and XHTML classes.
require_once("$CONF[local_path]/class/mysql-class.php");
require_once("$CONF[local_path]/class/xhtml-class.php");

// Create new MYSQL and XHTML objects.
$db     = new mysql();
$nune   = new mysql($hostname, $username, $password, $database);
$xhtml  = new xhtml();

// Connect to the two databases.
$db->pconnect();
$nune->pconnect();

// Start the document.
$xhtml->header($title);
$xhtml->table_start('normal', 500);

// Look up all the former NUNE users.
$query  = "SELECT user_id, username FROM user WHERE cipher='NUNE'";
$result = $db->query($query);

// Cycle through the users.
while ($list = $db->fetch_array($result)) {

	// Make them into an array for later on.
	$user_id[strtolower($list[username])] = $list[user_id];

}

// COMMENTS.  Convert the comments to Informium.
// This script will check if the author of the post matches any names in the Informium
// userbase.  If they match then the comment ownership is given to that user.  Otherwise,
// it is given to 'anonymous' and depending on the choices given in the configuration,
// the old data is appended to the post or discarded.

// Prepare and execute the query.
$query  = "SELECT * FROM $comment_table";
$result = $nune->query($query);

// Comment conversion counter.
$count = 0;

// Cycle thru comments.
while ($list = $nune->fetch_array($result)) {

	// Check if we need to modify according to the NUNE date syntax.
	if ($NUNE_convert == TRUE) {

		// Check if make sure this string is in the proper format.
		if (preg_match('/\d{2}-\d{2}-\d{2} \d{1,2}:\d{2}/', $list[date])) {

			// Replace the '-' with '/' to conform with GNU date syntax.
			$list[date] = str_replace('-', '/', $list[date]);

		} // End if.

	} // End if.

	// Extract the UNIX timestamp using strtotime() method.
	$list[date] = strtotime($list[date]);

	// Check if the user exists.
	if ($user_id[strtolower($list[username])]) {
		// Use that user_id.
		$list[user_id] = $user_id[strtolower($list[username])];

	// Otherwise, use user_id "1" (for Anonymous).
	} else {
		$list[user_id] = 1;

		// Check if we preserve history.
		if ($comment_preserve == TRUE) {

			// Prepare 'username' and 'email' strings.
			$list[username] = stripslashes($list[username]);
			$list[email]    = stripslashes($list[email]);

			// Append it to the comment.
			$list[comment] .= "<br />\n<br />\n";
			$list[comment] .= "(User: $list[username], E-mail: $list[email])";

		}

	}

	// Make sure texts are ' and " safe.
	$list[comment] = addslashes($list[comment]);
	
	// Assign Fake IP.
	$list[ip] = '0.0.0.0';

	// Generate a title using the first 16 characters from the comment.
	$list[title] = substr($list[comment], 0, 16) . '...';
	$list[title] = strip_tags($list[title]);

	// Transfer them to the Informium database.
	$query  = "INSERT INTO comments VALUES(
				$list[cid],
				$list[assoc_post],
				'T_ARTICLE',
				'$list[user_id]',
				'$list[ip]',
				'$list[host]',
				'$list[title]',
				'$list[comment]',
				FROM_UNIXTIME($list[date]),
				NOW())";
	$db->query($query);

	// Increment comment conversion counter.
	++$count;

}

// Free the result.
$db->free($result);

// Echo amount of comments converted.
echo "<b>$count</b> comment(s) converted.<br />\n";
echo "<br />\n";
echo "<a href='index.php'>Return to Conversion Menu...</a><br />\n";

// End the document.
$xhtml->table_end();
$xhtml->footer();