<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// NUNE User Conversion Script (user-convert.php)
//
// Author: Cameron McKay
// Note:   Converts a NUNE user database into an Informium-compatible one.
//

// Import Conv. Config and CONF.
require('config.php');
require('../conf/inf-conf.php');

// Make sure NUNE Conversion is enabled.
if (!$NUNE_enable) {
	// End execution.
	exit();

}

// Title.
$title = 'NUNE User Conversion Script';

// Import the MYSQL and XHTML classes.
require_once("$CONF[local_path]/class/mysql-class.php");
require_once("$CONF[local_path]/class/xhtml-class.php");

// Create new MYSQL and XHTML objects.
$db     = new mysql();
$nune   = new mysql($hostname, $username, $password, $database);
$xhtml  = new xhtml();

// Connect to the two databases.
$db->pconnect();
$nune->pconnect();

// Start the document.
$xhtml->header($title);
$xhtml->table_start('normal', 500);

// USER.  Convert the users to Informium.
// Since we're coming from NUNE, all the password ciphers will
// use the MySQL cipher, which is NUNE under Informium.

// Prepare and execute query.
$query  = "SELECT * FROM $user_table";
$result = $nune->query($query);

// User conversion counter.
$count = 0;

// Cycle thru users.
while ($list = $nune->fetch_array($result)) {

	// Increment access levels by one to reflect changes in Informium.
	++$list[access];

	// Transfer them to the Informium database.
	$query  = "INSERT INTO user VALUES('','$list[username]','$list[password]','NUNE','$list[email]','$list[access]',NOW())";
	$db->query($query);

	// Increment user conversion counter.
	++$count;

}

// Free the result.
$nune->free($result);

// Echo amount of users converted.
echo "<b>$count</b> user(s) converted.<br />\n";
echo "<br />\n";
echo "<a href='index.php'>Return to Conversion Menu...</a><br />\n";

// End the document.
$xhtml->table_end();
$xhtml->footer();

?>