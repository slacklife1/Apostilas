<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// NUNE Conversion Menu (index.php)
//
// Author: Cameron McKay
// Note:   Provides a nice menu to the conversion scripts.
//

// Import Conv. Config and CONF.
require_once('config.php');
require_once('../conf/inf-conf.php');

// Make sure NUNE Conversion is enabled.
if (!$NUNE_enable) {
	// End execution.
	exit();

}

// Title.
$title = 'NUNE Conversion Menu';

// Import the MYSQL and XHTML classes.
require_once("$CONF[local_path]/class/mysql-class.php");
require_once("$CONF[local_path]/class/xhtml-class.php");

// Create new MYSQL and XHTML objects.
$db     = new mysql();
$xhtml  = new xhtml();

// Connect to the DB.
$db->pconnect();

// Start the document.
$xhtml->header($title);

// Menu Header.
$xhtml->table_start('header', 500);
echo "NUNE Conversion Menu";
$xhtml->table_end();

echo "<br />\n";

// If we get the 'reset' command then we reset the appropriate table.
// For user...
if (!strcmp($reset, 'user')) {
	$query  = "DELETE FROM user WHERE username != 'Anonymous'";
	$result = $db->query($query);

// For news...
} else if (!strcmp($reset, 'news')) {
	$query  = "DELETE FROM news";
	$result = $db->query($query);

// For comments...
} else if (!strcmp($reset, 'comments')) {
	$query  = "DELETE FROM comments";
	$result = $db->query($query);

}

// Menu Body.
$xhtml->table_start('normal', 500);

// Check if users have been converted.
$query  = "SELECT * FROM user WHERE cipher='NUNE'";
$result = $db->query($query);

if ($db->num_rows($result)) {
	$status[user] = "<font style='color: #00FF00; font-weight: bold;'>[DONE]</font>";

} 

// Free the result.
$db->free($result);

// Check if the articles have been converted.
$query  = "SELECT * FROM news WHERE more_text='---'";
$result = $db->query($query);

if ($db->num_rows($result)) {
	$status[news] = "<font style='color: #00FF00; font-weight: bold;'>[DONE]</font>";

}

// Free the result.
$db->free($result);

// Check if the comments have been converted.
$query  = "SELECT * FROM comments";
$result = $db->query($query);

if ($db->num_rows($result)) {
	$status[comments] = "<font style='color: #00FF00; font-weight: bold;'>[DONE]</font>";

}

// Free the result.
$db->free($result);

echo "<table width='100%' cellpadding='0' cellspacing='0' border='0'>\n";

echo "<tr>\n";
echo "<td><a href='user-conv.php'    title='Import NUNE Users'>Import NUNE Users</a></td>      <td>$status[user]</td>\n";
echo "</tr>\n";

echo "<tr>\n";
echo "<td><a href='article-conv.php' title='Import NUNE Articles'>Import NUNE Articles</a></td><td>$status[news]</td>\n";
echo "</tr>\n";

echo "<tr>\n";
echo "<td><a href='comment-conv.php' title='Import NUNE Comments'>Import NUNE Comments</a></td><td>$status[comments]</td>\n";
echo "</tr>\n";

echo "</table>\n";
echo "<br />\n";

echo "<a href='index.php?reset=user'>Reset User Table</a><br />\n";
echo "<a href='index.php?reset=news'>Reset Article Table</a><br />\n";
echo "<a href='index.php?reset=comments'>Reset Comment Table</a><br />\n";

$xhtml->table_end();

// End the document.
$xhtml->footer();

?>