<?

//
// Copyright (c) 2002, Cameron McKay
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions 
// are met:

// * Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright 
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
// FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

//
// Informium -- Advanced News Script
//
// NUNE Article Conversion Script (article-conv.php)
//
// Author: Cameron McKay
// Note:   Converts a NUNE article database into an Informium-compatible one.
//

// Import Conv. Config and CONF.
require('config.php');
require('../conf/inf-conf.php');

// Make sure NUNE Conversion is enabled.
if (!$NUNE_enable) {
	// End execution.
	exit();

}

// Title.
$title = 'NUNE Article Conversion Script';

// Import the MYSQL and XHTML classes.
require_once("$CONF[local_path]/class/mysql-class.php");
require_once("$CONF[local_path]/class/xhtml-class.php");

// Create new MYSQL and XHTML objects.
$db     = new mysql();
$nune   = new mysql($hostname, $username, $password, $database);
$xhtml  = new xhtml();

// Connect to the two databases.
$db->pconnect();
$nune->pconnect();

// Start the document.
$xhtml->header($title);
$xhtml->table_start('normal', 500);

// Look up all the former NUNE users.
$query  = "SELECT user_id, username FROM user WHERE cipher='NUNE'";
$result = $db->query($query);

// Cycle through the users.
while ($list = $db->fetch_array($result)) {

	// Make them into an array for later on.
	$user_id[strtolower($list[username])] = $list[user_id];

}

// NEWS.  Convert the news articles to Informium.
// This script will check if the author of the post matches any names in the Informium
// userbase.  If they match then the article ownership is given to that user.  Otherwise,
// it is given to 'anonymous' and depending on the choices given in the configuration,
// the old data is appended to the post or discarded.

// Prepare and execute query.
$query  = "SELECT * FROM $news_table";
$result = $nune->query($query);

// Cycle thru comments.
while ($list = $nune->fetch_array($result)) {

	// Replace all illegal characters.
	$list[date] = strtr($list[date], '!@#$%^&*()[]`~<>?(){}|+=_', '                         ');

	// Extract the UNIX timestamp using strtotime() method.
	$list[date] = strtotime($list[date]);

	// Check if the user exists.
	if($user_id[strtolower($list[author])]) {
		// Use that user_id.
		$list[user_id] = $user_id[strtolower($list[author])];

	// Otherwise, use user_id "1" (for Anonymous).
	} else {
		$list[user_id] = 1;

		// Check if we preserve history.
		if ($article_preserve == TRUE) {

			// Prepare 'username' and 'email' strings.
			$list[author] = stripslashes($list[author]);
			$list[email]  = stripslashes($list[email]);

			// Append it to the comment.
			$list[article] .= "<br />\n<br />\n";
			$list[article] .= "(User: $list[author], E-mail: $list[email])";

		}

	}

	// Make sure texts are ' and " safe.
	$list[title]        = addslashes($list[title]);
	$list[article]      = addslashes($list[article]);
	$list[more_article] = addslashes($list[more_article]);

	// Transfer them to the Informium database.
	$query  = "INSERT INTO news VALUES($list[pid],$list[user_id],'$list[title]','$list[article]','---',FROM_UNIXTIME($list[date]),NOW())";
	$db->query($query);

	// Increment article conversion counter.
	++$count;

}

// Free the result.
$nune->free($result);

// Echo amount of articles converted.
echo "<b>$count</b> article(s) converted.<br />\n";
echo "<br />\n";
echo "<a href='index.php'>Return to Conversion Menu...</a><br />\n";

// End the document.
$xhtml->table_end();
$xhtml->footer();
