Title: PHP Candy Hearts
Description: Create "Candy Hearts" on the fly. This application demonstrates how you can use PHP functions to draw text over images. The text centering needs work, but it's functional. Please vote if you think it's cool. Tested on Linux/Apache/PHP4. Demo: http://www.danhendricks.com/index.php?page=howto/php/hearts/index.htm NOTE: For this to work, you will need to configure '--with-gd' to enable GD library, available here: http://www.boutell.com/gd/
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=333&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
