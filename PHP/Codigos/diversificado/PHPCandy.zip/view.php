<html>

<head>
<title>PHP Hearts</title>
</head>

<body bgcolor="#0FA48D" link="#FFCC66">

<p align="center"><font size="5" color="#FFFFFF"><b>PHP Heart Maker</b></font></p>
<div align="center">
  <center>
  <table border="1" bordercolor="#000000">
    <tr>
      <td width="100%"><IMG SRC="heart.php?text1=<?=$text1?>&text2=<?=$text2?>&color=<?=$color?>" alt="PHP Heart"></td>
    </tr>
  </table>
  </center>
</div>

<br><hr>
<p><i><a href="http://dan.hendricks.net"><b>http://dan.hendricks.net</b></a></i> </p>

</body></html>
