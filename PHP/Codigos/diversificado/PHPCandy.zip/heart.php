<?
Header ("Content-type: image/gif");
$font = "CANDY.TTF";
$im = ImageCreateFromGIF ("img/".$color);
$back = ImageColorAllocate ($im, 255, 255, 255); //background
$fore = ImageColorAllocate ($im, 220, 0, 220); //foreground
//The next two lines attempt to center the font.
$left1 = 50 - (strlen($text1) * ImageFontWidth($font));
$left2 = 50 - (strlen($text2) * ImageFontWidth($font));
ImageTTFText ($im, 23, 0, $left1, 43, $fore, $font, $text1);
ImageTTFText ($im, 23, 0, $left2, 64, $fore, $font, $text2);
ImageColorTransparent ($im, $back);
ImageGif ($im);
ImageDestroy ($im);
?>
