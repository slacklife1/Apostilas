<html>
<head>
<title>Variable basics</title>
</head>
<body>

<?php

/* Using variables in PHP is not as complicated as VB.  Variables are either
'numbers' or they are 'strings'.
Numbers:  includes: 'double precision (floating-poin)' for decimals
		    'integers' for whole numbers
'Strings' is the same sa VB.

To declare a varible, it follows this format:
'$' + <variable_name_goes_here> = $variable

Acceptable chracters for a variable:
a-z, A-Z, _

Varaibles can hold either type of data (number or string).  These types can be interchanged 
quite easily and variables do NOT need declaration.  They are initialized by just giving 
the variables a value.  IE:
$var = 0;

This has created the variable 'var' which is curently a number variable. Variables can hold 
one typed of data at one time, but can then be given the value of another type of variable 
later.  Ie:
$var = 1.01;
$var = 3;
$var = "hello.  this is correct to do";

Things to note about string data:
-Certain chracters must be 'escaped' so that PHP will read the data properly.
This is what I mean:
$string = "These are the special escaped chracters: \", \$, \', \\, \n, \r, \t";
This will produce the string when printed:
"These are the special escaped chracters: ", $, ', \, <new line>, <carriage return>, <tab>"

-variables can be called inside of strings.  IE:
$name = "John";
$age = 40;
$string = "Hello, $name, you are $age years old.";

This produces the phrase: "Hello John, you are 40 years old."


Last note:
Variables can also be made into arrays, which I will do a little tutorial later maybe that 
is more in depth.  Arrays can hold either all number data (either double precision floating-
point or only integers), only strings, or a combination of numbers and/or strings.  These 
arrays can also hold other arrays (so you create an array to hold different arrays) or you 
can have an array that holds arrays, which hold other arrays, which therefore makes it a 
multi-dimensional array.

*/

?>

</body>
</html>