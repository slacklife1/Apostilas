<html>
<head>
<style>
Body { background-color: #000000; color: silver; scrollbar-color: blue; scrollbar-track-color: #000000; scrollbar-arrow-color: blue; scrollbar-main-color: #009090; }
</style>
<style>
A { color: #004040; text-decoration: none; }
</style>
<style>
Input { Bowder-Width: 1px; border-color: blue; background-color: #000001; color: silver; }
</style>
<style>
textarea { Bowder-Width: 1px; border-color: blue; background-color: #000001; color: silver; }
</style>
</head>
<body>
<pre>
Thank you for Posting. Click View Posts to see your post, or Add Post to post anotherone.



<a href="book.php">View Posts</a>   <a href="Forum.html">Add Link</a>