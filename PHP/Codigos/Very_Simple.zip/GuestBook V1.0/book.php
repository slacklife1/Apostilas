<html>
<head>
<style>
Body { background-color: #000000; color: blue; scrollbar-color: blue; scrollbar-track-color: #000000; scrollbar-arrow-color: blue; scrollbar-main-color: #009090; }
</style>
<style>
A { color: #004040; text-decoration: none; }
</style>
<style>
Input { Bowder-Width: 1px; border-color: blue; background-color: #000001; color: silver; }
</style>
<style>
textarea { Bowder-Width: 1px; border-color: blue; background-color: #000001; color: silver; }
</style>
</head>
<body>
<table border="1" bordercolor="blue" align="left" width="600" cellpadding="0" cellspacing="0">
<tr>
<td align="center" background="http://www.progdomain.cc/josh/Table.jpg"><b>{����GuestBook v1.0����}</td></tr>
</table>
<br>
<br>
