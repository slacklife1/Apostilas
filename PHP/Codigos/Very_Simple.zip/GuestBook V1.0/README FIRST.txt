- Owner: Proxikal
- Site: http://punkhost.tk
- http://www.spyderinteractive.tk

first of all, Upload Book.php, foot.php, Script.php, Forum.html To your Account

Now

Chmod book.php - 777

- Warning ' If you remove the copyright on Forum.html i have all of the right to report you into your Host and / or delete your account and sue your personaly.