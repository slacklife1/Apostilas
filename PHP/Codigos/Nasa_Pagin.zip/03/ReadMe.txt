I wrote this programs using :
-> Language : PHP 4.0
-> Web server : IIS
-> Database MySQL

Step :
1. Create :
   1.1 database name = dbStaff, 
   1.2 table = tblStaff
   1.3 field 
       	1.3.1 fldStaffID
        1.3.2 fldName
	1.3.3 fldPosition
	1.3.4 fldSalary

Any problems just email me at
nasa_ai@hotmail.com/badin98@tm.net.my

Author : Nasa
Date   : 02/09/2002