
<?php
 mysql_connect("localhost", "admin", "admin") or die("could not connect");
 mysql_select_db("dbStaff");
?>

