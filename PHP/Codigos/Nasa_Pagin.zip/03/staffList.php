
<?php

/*********************************************/
/*** Author  : Nasarudin Abdullah          ***/
/*** Purpose : To display records by paging ***/
/*** Date    : 02-09-2002                  ***/
/*********************************************/

//Set the page size
$PageSize = 10;
$StartRow = 0;

//Set the page no
if(empty($_GET['PageNo'])){
    if($StartRow == 0){
        $PageNo = $StartRow + 1;
    }
}else{
    $PageNo = $_GET['PageNo'];
    $StartRow = ($PageNo - 1) * $PageSize;
}

//Set the counter start
if($PageNo % $PageSize == 0){
    $CounterStart = $PageNo - ($PageSize - 1);
}else{
    $CounterStart = $PageNo - ($PageNo % $PageSize) + 1;
}

//Counter End
$CounterEnd = $CounterStart + ($PageSize - 1);
?>

<html>
<head>
<title>Paging Example By Nasa</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="include/style.css" type="text/css">
</head>
<?php
 include '/include/dbConnection.php';
 $TRecord = mysql_query("SELECT * FROM tblStaff");
 $result = mysql_query("SELECT * FROM tblStaff ORDER BY fldStaffName LIMIT $StartRow,$PageSize");

 //Total of record
 $RecordCount = mysql_num_rows($TRecord);

 //Set Maximum Page
 $MaxPage = $RecordCount % $PageSize;
 if($RecordCount % $PageSize == 0){
    $MaxPage = $RecordCount / $PageSize;
 }else{
    $MaxPage = ceil($RecordCount / $PageSize);
 }
?>
<body class="UsePageBg">
<table width="100%" border="0" class="InternalHeader">
  <tr>
    <td width="24%">List of Staff</td>
    <td width="76%">
      <div align="right"> 
        <?php print "$RecordCount record(s) founds - You are at page $PageNo  of $MaxPage" ?></div>
    </td>
  </tr>
</table>
<br>
<table width="100%" border="0" class="NormalTableTwo">
  <tr> 
    <td class="InternalHeader" width="4%">NO</td>
    <td class="InternalHeader" width="36%">STAFF ID</td>
    <td class="InternalHeader" width="20%">NAME</td>
    <td class="InternalHeader" width="20%">POSITION</td>
    <td class="InternalHeader" width="20%">SALARY (RM)</td>
  </tr>
<?php
$i = 1;
while ($row = mysql_fetch_array($result, MYSQL_NUM)) {
    $bil = $i + ($PageNo-1)*$PageSize;
?>
  <tr> 
    <td class="NormalFieldTwo" width="4%"><?php echo $bil ?></td>
    <td class="NormalFieldTwo" width="36%"><?php echo $row[0] ?></td>
    <td class="NormalFieldTwo" width="20%"><?php echo $row[1] ?></td>
    <td class="NormalFieldTwo" width="20%"><?php echo $row[2] ?></td>
    <td class="NormalFieldTwo" width="20%"><?php echo $row[3] ?></td>
  </tr>
<?php
  $i++;
}?>
</table><br>
<table width="100%" border="0" class="InternalHeader">
  <tr>
    <td>

      <div align="center">
      <?php
        //Print First & Previous Link is necessary
        if($CounterStart != 1){
            $PrevStart = $CounterStart - 1;
            print "<a href=staffList.php?PageNo=1>First </a>: ";
            print "<a href=staffList.php?PageNo=$PrevStart>Previous </a>";
        }
        print " [ ";
        $c = 0;

        //Print Page No
        for($c=$CounterStart;$c<=$CounterEnd;$c++){
            if($c < $MaxPage){
                if($c == $PageNo){
                    if($c % $PageSize == 0){
                        print "$c ";
                    }else{
                        print "$c ,";
                    }
                }elseif($c % $PageSize == 0){
                    echo "<a href=staffList.php?PageNo=$c>$c</a> ";
                }else{
                    echo "<a href=staffList.php?PageNo=$c>$c</a> ,";
                }//END IF
            }else{
                if($PageNo == $MaxPage){
                    print "$c ";
                    break;
                }else{
                    echo "<a href=staffList.php?PageNo=$c>$c</a> ";
                    break;
                }//END IF
            }//END IF
       }//NEXT

      echo "] ";

      if($CounterEnd < $MaxPage){
          $NextPage = $CounterEnd + 1;
          echo "<a href=staffList.php?PageNo=$NextPage>Next</a>";
      }
      
      //Print Last link if necessary
      if($CounterEnd < $MaxPage){
       $LastRec = $RecordCount % $PageSize;
        if($LastRec == 0){
            $LastStartRecord = $RecordCount - $PageSize;
        }
        else{
            $LastStartRecord = $RecordCount - $LastRec;
        }

        print " : ";
        echo "<a href=staffList.php?PageNo=$MaxPage>Last</a>";
        }
      ?>
      </div>
    </td>
  </tr>
</table>
<?php
    mysql_free_result($result);
    mysql_free_result($TRecord);
?>
</body>
</html>
