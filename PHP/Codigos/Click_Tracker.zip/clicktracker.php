<?

/******************************************************************************\
 * Copyright (C) 2001 Click Tracker by Josh Sherman                           *
 *                                                                            *
 * This source and program come as is, WITHOUT ANY WARRANTY and/or WITHOUT    *
 * ANY IMPLIED WARRANTY.                                                      *
 *                                                                            *
 * Users of said software should realize that they cannot and will not hold   *
 * bombthebox.com reliable or responsible for any purpose WHAT SO EVER.       *
 * Please read all documentation and use said software responsibly.           *
 *                                                                            *
 * ANY COMMERCIAL REDISTRIBUTION OR ANY PROPRIETARY REDISTRIBUTION OF THIS    *
 * OR ANY SOURCE FROM BOMBTHEBOX.COM IS PROHIBITED UNDER CERTAIN CONDITIONS   *
 * AND SHALL NOT BE RE-SOLD OR REDISTRIBUTED WITHOUT PRIOR AGREEMENTS WITH    *
 * BOMBTHEBOX.COM                                                             *
 *                                                                            *
 * I can be reached by electronic mail if there are any questions or          *
 * concerns about this or any other software that was written/distributed by  *
 * bombthebox.com - josh@bombthebox.com                                       *
 *                                                                            *
 * Software supplied and written by http://www.bombthebox.com/                *
\******************************************************************************/

?>

<HTML>
	<HEAD>
		<TITLE></TITLE>
	</HEAD>
	<BODY>
<?

/***** Start Database Stuff *****/

$usr = "";
$pwd = "";
$db = "";
$host = "";

/****** End Database Stuff ******/

$cid = mysql_connect($host,$usr,$pwd);
if (!$cid) { echo("ERROR: " . mysql_error() . "\n"); }

$HOST = gethostbyaddr($REMOTE_ADDR);

	
$SQL = "INSERT INTO clicktracker ";
$SQL = $SQL . " (link, referer, ipaddress, host, browser) VALUES ";
$SQL = $SQL . " ('$link', '$HTTP_REFERER', '$REMOTE_ADDR', '$HOST', '$HTTP_USER_AGENT');";

$result = mysql_db_query($db,"$SQL",$cid);
if (!$result) { echo("ERROR: " . mysql_error() . "\n$SQL\n"); }

echo "<SCRIPT>window.location=\"$link\"</SCRIPT>";

?>
	</BODY>
</HTML>