Title: Click Tracker
Description: Provides a method of tracking what links the end users are clicking on. Good for aiding in content development, and making decisions as to what parts should be cut, and which links are drawing attention. DON'T FORGET TO RATE MY CODE!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=489&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
