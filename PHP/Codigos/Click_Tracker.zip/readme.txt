Before the click tracker will function, we have to do a few things.

1. 	Make sure you have PHP and MySQL on your server, if not, it won't work.

2.	Unpack the .ZIP file to a directory on your server (/clicktracker will be fine).

3.	You will need to create your database for the script to work off of:

	create table clicktracker(id int(10) not null auto_increment,link varchar(255) not null,referer varchar(255) not null,ipadress varchar(15) not null,host varchar(255) not null,browser varchar(255) not null,primary key(id));

4.	Edit clicktracker.php to reflect your database name, login and password.

5.	Now to track the files, you will have to make your links like this:

	clicktracker.php?link=[URL]

	or

	clicktracker.php?link=http://www.bombthebox.com

6.	Pardon the lack of a reporting script, but that will be around eventually, until then, try coding your own.  Cheers!