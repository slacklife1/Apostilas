Bigmeta PHP 3 Search Engine Script
"Search AltaVista, Google, Webcrawler, Thunderstone, and FastSearch all at once." 
Copyright 2000 Alan Dipert
Please do not use without including a link to my site, http://www.paanet.com/bigmeta, on your page.
Thanks, and enjoy!
-------------------

Purpose:
	
	This script retrieves and parses results from several leading search engines.
	More engines can easily be added, but search speed may greatly decrease.

-------------------

Requirements:
	
	PHP3 enabled server

-------------------

Instructions for Implementation:

	1) Place the following files in a directory:
		index.php
		webmeta.php
		searchcount.dat
		querylog.dat
		bigmeta.gif

	2) CHMOD searchcount.dat and querylog.dat for server side read/write priveledges.

	3) Hmm, I can't think of anything else you might want to do. You're done!

-------------------

Script documentation:

	Sprinkled into the script itself are some comments of mine.  Other than what I've indicated,
	The script is pretty self explanatory.

