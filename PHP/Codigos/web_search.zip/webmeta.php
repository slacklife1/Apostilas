// Bigmeta Search engine
// Copyright 2000 Alan Dipert alan_dipert@hotmail.com
// Example at http://www.paanet.com/bigmeta
// When implementing this script, please include a link on your website to my webpage http://www.paanet.com/bigmeta
// For help implementing, see readme.txt

<?php

if ($query == "")
	{
	echo "<html>
	<head>
	<meta http-equiv=\"Content-Language\" content=\"en-us\">
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">
	<META name=\"description\" content=\"Completely free, completely kickass web metasearch. Get A LOT of results.\">
	<META name=\"keywords\" content=\"web search, search engine, metasearch, meta search, infoseek, lycos, excite, yahoo, google, thunderstone\">
	<title>Big Meta meta search: searches google, altavista, webcrawler, thunderstone, fastsearch - NO ADS!</title>
	<style TYPE=\"text/css\">
	<!--
		A {text-decoration: none}
		A:link {color:\"#0000FF\";}
		A:visited {color:\"#800080\";}
		A:hover {color: \"#0066FF\";}
	-->
	</style>
	</head>
	<body link=\"#0000FF\" vlink=\"#800080\" alink=\"#FF0000\">
		<p align=\"center\">
	        <a href=\"clicks_counter.php?http://www.paanet.com/bigmeta\"><img border=\"0\" src=\"images/bigmeta.gif\"></a><br>
			<b>
			<font color=\"#000000\" size=\"2\">&quot;Search <a href=\"clicks_counter.php?http://www.altavista.com\">AltaVista</a>, <a href=\"clicks_counter.php?http://www.google.com\">Google</a>, <a href=\"clicks_counter.php?http://www.webcrawler.com\">Webcrawler</a>, <a href=\"clicks_counter.php?http://www.thunderstone.com\">Thunderstone</a>, and <a href=\"clicks_counter.php?http://www.fastsearch.com\">FastSearch</a> all at once.&quot;</font>
			</b>
		</p>
	<hr color=\"#000000\" noshade>
	<p align=\"center\"><font color=\"#FF0000\" size=\"2\"><b>ERROR: Please enter a search query.</b></font></p>
	<p align=\"center\">
			<form method=\"GET\" action=\"webmeta.php\" name=\"form\">
			<font size=\"2\" color=\"#000000\"><b>Search for: </b></font>
			<input type=\"text\" name=\"query\" size=\"55\"><input type=\"submit\" value=\"Go!\">
			</form>
	<hr color=\"#000000\" noshade>
	<div align=\"center\">
	      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
	        <tr>
	          <td width=\"33%\" valign=\"top\" align=\"center\">
	    		<p align=\"center\">
	                <font size=\"2\" color=\"#000000\"><b>Powered by gnomes on hamster wheels, along with a little help from<br>
	    			<a href=\"clicks_counter.php?http://www.php.net\">The PHP Scripting Language</a><br><br>";
					include "searchcount.dat";
	 echo " searches since 11/5/00<br><br>
	  				</b></font>
	    		</p>
	          </td>
	          <td width=\"33%\" align=\"center\">
	            <p align=\"center\"><img border=\"0\" src=\"images/verticalline.gif\" width=\"2\" height=\"100\"></td>
	          <td width=\"33%\" valign=\"top\" align=\"center\">
	    		<p align=\"center\">
	    			<font size=\"2\" color=\"#000000\">
	    			<b>Bigmeta source code released!<br>
	    			<a href=\"http://www.paanet.com/bigmeta/bigmetasource.zip\">bigmetasource.zip (8.28kb)</a><br>
	    			Includes all necessary files for implementing this PHP3 script, along with instructions on how to do it.
	  				</b></font>
	  			</p>
	          </td>
	        </tr>
	      </table>
	    </div>
	<hr color=\"#000000\" noshade>
	<p align=\"center\">
	    			<font size=\"2\" color=\"#000000\">
	    			<b>Copyright 2000 <a href=\"mailto:info@bigmeta.com\">Alan Dipert</a></b></font>
	    		</p>
	</body>
	</html>";
	}
	else
	{
		if($fp = fopen("querylog.dat", "a+"))
                	{
				$entry = "$query\n";
		   		fputs($fp, $entry);
		   		fclose($fp);
                 	}

	echo "<html>
	<a name=\"Top\"></a>
	<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">
	<META name=\"description\" content=\"Completely free, completely kickass web metasearch. Get A LOT of results.\">
	<META name=\"keywords\" content=\"web search, search engine, metasearch, meta search, infoseek, lycos, excite, yahoo, google, thunderstone\">";

	$query = str_replace("+", " ", $query);
	$query = str_replace("#", " ", $query);
	$query = str_replace("&", " ", $query);
	$query = str_replace(";", " ", $query);
	
	echo "<title>Big Meta search for \"$query\"</title>
	
	</head>
	<style TYPE=\"text/css\">
	<!--
		A {text-decoration: none}
		A:link {color:\"#0000FF\";}
		A:visited {color:\"#800080\";}
		A:hover {color:\"#0066FF\";}
	-->
	</style>
	<body link=\"#0000FF\" vlink=\"#800080\" alink=\"#FF0000\">
		<p align=\"center\">
			<a href=\"clicks_counter.php?http://www.paanet.com/bigmeta\"><img border=\"0\" src=\"images/bigmeta.gif\" width=\"255\" height=\"40\"></a><br>
	<b><font size=\"2\" color=\"#FF0000\">Like this 
	script?</font><font size=\"2\" color=\"#000000\"> Please <a href=\"clicks_counter.php?http://www.hotscripts.com/cgi-bin/rate.cgi?ID=8096\">vote 
	for it on HotScripts.com!</a></font></b>
	<br>
			<b>
			<font color=\"#000000\" size=\"2\">&quot;Search <a href=\"clicks_counter.php?http://www.altavista.com\">AltaVista</a>, <a href=\"clicks_counter.php?http://www.google.com\">Google</a>, <a href=\"clicks_counter.php?http://www.webcrawler.com\">Webcrawler</a>, <a href=\"clicks_counter.php?http://www.thunderstone.com\">Thunderstone</a>, and <a href=\"clicks_counter.php?http://www.fastsearch.com\">FastSearch</a> all at once.&quot;</font>
			</b>
		</p>
	<hr color=\"#000000\" noshade>
		<p align=\"center\">
			<form method=\"GET\" action=\"webmeta.php\">
			<font size=\"2\" color=\"#000000\"><b>Search for: </b></font>
			<input type=\"text\" name=\"query\" size=\"55\" value=\"$query\"><input type=\"submit\" value=\"Go!\">
			</form>
	 	</p>";
	
	$query = str_replace(" ", "+", $query);

	echo "<!-- Google -->
	  	<table width=\"100%\">
	    	<tr>
	      	<td width=\"30%\"><b><font size=\"2\">Results: Google</font></b></td>
	    	</center>
	    	<td width=\"70%\">
	      	<p align=\"right\"><a name=\"Google\"></a><b><font size=\"2\">Other Results: <a href=\"#AltaVista\">AltaVista</a> <a href=\"#Webcrawler\">Webcrawler</a> </font><font size=\"2\"><a href=\"#Thunderstone\">Thunderstone</a> <a href=\"#FastSearch\">FastSearch</a> <a href=\"#Top\">Top of Page</a></font></b></td>
	  	</tr>
	  	</table>
				<hr color=\"#000000\" noshade>
	  <div align=\"left\">
	    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
	      <tr>
	        <td width=\"100%\">
	          <p align=\"left\">";

				$file1 = fopen("http://www.google.com/search?q=$query", "r");
				$rf1 = fread($file1, 40000);
				fclose($file1);
				$grab1 = ereg("<p>(.*)<div class=nav>", $rf1, $printing1);
				$printing1[1] = str_replace("<A HREF=/", "<A HREF=http://www.google.com/", $printing1[1]);
				$printing1[1] = str_replace("<a href=/", "<A HREF=http://www.google.com/", $printing1[1]);
				if ($printing1[1] == "") {
    					echo "&nbsp;&nbsp;&nbsp;<b><font size=\"2\" color=\"#FF0000\">No Results</font></b>";
				} else {
					echo $printing1[1];
				}

	echo "          </td>
	      </tr>
	    </table>
	  </div>
	<br>
	<p align=\"center\">
        <b><font size=\"2\" color=\"#FF0000\">Like this 
        script?</font><font size=\"2\" color=\"#000000\"> Please <a href=\"clicks_counter.php?http://www.hotscripts.com/cgi-bin/rate.cgi?ID=8096\">vote 
        for it on HotScripts.com!</a></font></b>
	</p>
	<!-- AltaVista -->
	  	<table width=\"100%\">
	    	<tr>
	      	<td width=\"30%\"><b><font size=\"2\">Results: AltaVista</font></b></td>
	    	</center>
	    	<td width=\"70%\">
	      	<p align=\"right\"><a name=\"AltaVista\"></a><b><font size=\"2\">Other Results: <a href=\"#Google\">Google</a> <a href=\"#Webcrawler\">Webcrawler</a> </font><font size=\"2\"><a href=\"#Thunderstone\">Thunderstone</a> <a href=\"#FastSearch\">FastSearch</a> <a href=\"#Top\">Top of Page</a></font></b></td>
	  	</tr>
	  	</table>
				<hr color=\"#000000\" noshade>
	  <div align=\"left\">
	    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
	      <tr>
	        <td width=\"100%\">
	          <p align=\"left\">";

				$file2 = fopen("http://www.altavista.com/cgi-bin/query?q=$query&kl=XX&pg=q&Translate=on", "r");
				$rf2 = fread($file2, 40000);
				fclose($file2);
				$grab2 = ereg("<div class=txt>(.*)<p>R", $rf2, $printing2);
				$printing2[1] = str_replace("<a href=\"/cgi", "<a href=\"http://www.altavista.com/cgi", $printing2[1]);
				$printing2[1] = str_replace("<img src=\"http://a12.g.akamai.net/7/12/282/8620b1d20ecace/av.com/g/rp.gif\" width=\"9\" height=\"11\">", " - ", $printing2[1]);
				if ($printing2[1] == "") {
    					echo "&nbsp;&nbsp;&nbsp;<b><font size=\"2\" color=\"#FF0000\">No Results</font></b>";
				} else {
					echo $printing2[1];
				}
	echo "     </td>
	 </tr>
	</table>
	  </div>
	<br>
	<p align=\"center\">
        <b><font size=\"2\" color=\"#FF0000\">Like this 
        script?</font><font size=\"2\" color=\"#000000\"> Please <a href=\"clicks_counter.php?http://www.hotscripts.com/cgi-bin/rate.cgi?ID=8096\">vote 
        for it on HotScripts.com!</a></font></b>
	</p>
	<!-- WebCrawler -->
	  	<table width=\"100%\">
	    	<tr>
	      	<td width=\"30%\"><b><font size=\"2\">Results: Webcrawler</font></b></td>
	    	</center>
	    	<td width=\"70%\">
	      	<p align=\"right\"><a name=\"Webcrawler\"></a><b><font size=\"2\">Other Results: <a href=\"#AltaVista\">AltaVista</a> <a href=\"#Google\">Google</a> </font><font size=\"2\"><a href=\"#Thunderstone\">Thunderstone</a> <a href=\"#FastSearch\">FastSearch</a> <a href=\"#Top\">Top of Page</a></font></b></td>
	  	</tr>
	  	</table>
				<hr color=\"#000000\" noshade>
	  <div align=\"left\">
	    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
	      <tr>
	        <td width=\"100%\">
	          <p align=\"left\">";

				$file3 = fopen("http://www.webcrawler.com/cgi-bin/WebQuery?search=$query&showSummary=true&start=0&perPage=25", "r");	
				$rf3 = fread($file3, 40000);
				fclose($file3);
				$grab3 = ereg("hese results.(.*)<BR><B><FONT SIZE=3>News", $rf3, $printing3);
				$printing3[1] = eregi_replace("<P>(.*)</TABLE>","", $printing3[1]);
				$printing3[1] = eregi_replace("<FORM(.*)</FORM>","", $printing3[1]);
				$printing3[1] = str_replace("<A HREF=\"/cgi", "<A HREF=\"http://www.webcrawler.com/cgi", $printing3[1]);
				if ($printing3[1] == "") {
    					echo "&nbsp;&nbsp;&nbsp;<b><font size=\"2\" color=\"#FF0000\">No Results</font></b>";
				} else {
					echo $printing3[1];
				}

	echo "          </td>
	      </tr>
	    </table>
	  </div>
	<br>
	<p align=\"center\">
        <b><font size=\"2\" color=\"#FF0000\">Like this 
        script?</font><font size=\"2\" color=\"#000000\"> Please <a href=\"clicks_counter.php?http://www.hotscripts.com/cgi-bin/rate.cgi?ID=8096\">vote 
        for it on HotScripts.com!</a></font></b>
	</p>
	<!-- Thunderstone -->
	  	<table width=\"100%\">
	    	<tr>
	      	<td width=\"30%\"><b><font size=\"2\">Results: Thunderstone</font></b></td>
	    	</center>
	    	<td width=\"70%\">
	      	<p align=\"right\"><a name=\"Thunderstone\"></a><b><font size=\"2\">Other Results: <a href=\"#AltaVista\">AltaVista</a> <a href=\"#Google\">Google</a> </font><font size=\"2\"><a href=\"#Webcrawler\">Webcrawler</a> <a href=\"#FastSearch\">FastSearch</a> <a href=\"#Top\">Top of Page</a></font></b></td>
	  	</tr>
	  	</table>
				<hr color=\"#000000\" noshade>
	  <div align=\"left\">
	    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
	      <tr>
	        <td width=\"100%\">
	          <p align=\"left\">";

				$file4 = fopen("http://go2net.thunderstone.com/texis/websearch/?q=$query", "r");
				$rf4 = fread($file4, 40000);
				fclose($file4);
				$grab4 = ereg("<dl>(.*)</dl>", $rf4, $printing4);
				$printing4[1] = str_replace("http://search.thunderstone.com/texis/redir/main.bin?q=$query&u=", "http://", $printing4[1]);
				$printing4[1] = str_replace("=/", "=http://search.thunderstone.com/", $printing4[1]);
				if ($printing4[1] == "") {
    					echo "&nbsp;&nbsp;&nbsp;<b><font size=\"2\" color=\"#FF0000\">No Results</font></b>";
				} else {
					echo $printing4[1];
				}

	echo "          </td>
	      </tr>
	    </table>
	  </div>
	<br>
	<p align=\"center\">
        <b><font size=\"2\" color=\"#FF0000\">Like this 
        script?</font><font size=\"2\" color=\"#000000\"> Please <a href=\"clicks_counter.php?http://www.hotscripts.com/cgi-bin/rate.cgi?ID=8096\">vote 
        for it on HotScripts.com!</a></font></b>
	</p>
	<!-- FastSearch -->
	  	<table width=\"100%\">
	    	<tr>
	      	<td width=\"30%\"><b><font size=\"2\">Results: FastSearch</font></b></td>
	    	</center>
	    	<td width=\"70%\">
	      	<p align=\"right\"><a name=\"FastSearch\"></a><b><font size=\"2\">Other Results: <a href=\"#AltaVista\">AltaVista</a> <a href=\"#Google\">Google</a> </font><font size=\"2\"><a href=\"#Webcrawler\">Webcrawler</a> <a href=\"#Thunderstone\">Thunderstone</a> <a href=\"#Top\">Top of Page</a></font></b></td>
	  	</tr>
	  	</table>
				<hr color=\"#000000\" noshade>
	  <div align=\"left\">
	    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
	      <tr>
	        <td width=\"100%\">
	          <p align=\"left\">";

				$file5 = fopen("http://www.bos2.alltheweb.com/cgi-bin/search?exec=FAST+Search&type=all&query=$query", "r");
				$rf5 = fread($file5, 40000);
				fclose($file5);
				$grab5 = ereg("<dl>(.*)</dl>", $rf5, $printing5);
				$printing5[1] = str_replace("/go/1/", "", $printing5[1]);
				$printing5[1] = str_replace("/go/2/", "", $printing5[1]);
				$printing5[1] = str_replace("/go/3/", "", $printing5[1]);
				$printing5[1] = str_replace("/go/4/", "", $printing5[1]);
				$printing5[1] = str_replace("/go/5/", "", $printing5[1]);
				$printing5[1] = str_replace("/go/6/", "", $printing5[1]);
				$printing5[1] = str_replace("/go/7/", "", $printing5[1]);
				$printing5[1] = str_replace("/go/8/", "", $printing5[1]);
				$printing5[1] = str_replace("/go/9/", "", $printing5[1]);
				$printing5[1] = str_replace("/go/10/", "", $printing5[1]);
				$printing5[1] = str_replace("H/", "http://", $printing5[1]);

				if ($printing5[1] == "") {
    					echo "&nbsp;&nbsp;&nbsp;<b><font size=\"2\" color=\"#FF0000\">No Results</font></b>";
				} else {
					echo $printing5[1];
				}

	echo "          </td>
	      </tr>
	    </table>
	  </div>
	<br>
	<p align=\"center\">
        <b><font size=\"2\" color=\"#FF0000\">Like this 
        script?</font><font size=\"2\" color=\"#000000\"> Please <a href=\"clicks_counter.php?http://www.hotscripts.com/cgi-bin/rate.cgi?ID=8096\">vote 
        for it on HotScripts.com!</a></font></b>
	</p>
				<hr color=\"#000000\" noshade>
	  	<table width=\"100%\">
	    	<tr>
	      	<td width=\"33%\"><b><font size=\"2\">";

			$data_file = "searchcount.dat";  
			$data_in = file($data_file); 
			$visits = trim($data_in[0]); 
			if ($visits != "") {  
			 $visits++; 
			 $data_out = fopen($data_file,"w");  
			 fputs($data_out,$visits); 
			 fclose($data_out); 
			 echo "<b><font size=\"2\">$visits searches since 11/5/00</font></b>"; 
			}

	echo "		</font></b>
			</td>
	    	</center>
			<td width=\"33%\">
			<p align=\"center\"><b><font size=\"2\"><a href=\"#Top\">Top of Page</a></font></b></td>
	    	<td width=\"33%\">
	      	<p align=\"right\"><b><font size=\"2\">Copyright 2000 <a href=\"mailto:crazymofo@email.com\">Alan Dipert</a></font></b></td>
	  	</tr>
	  	</table>
	</body>
	</html>";
	}
?>

