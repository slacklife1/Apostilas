<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<META name="description" content="Completely free, completely kickass web metasearch. Get A LOT of results.">
<META name="keywords" content="web search, search engine, metasearch, meta search, infoseek, lycos, excite, yahoo, google, thunderstone">
<title>Big Meta meta search: searches google, altavista, webcrawler, thunderstone, fastsearch</title>
<style TYPE="text/css">
<!--
	A {text-decoration: none}
	A:link {color:"#0000FF";}
	A:visited {color:"#800080";}
	A:hover {color: "#0066FF";}
-->
</style>
<script>
<!--
	function setfocus() {
	document.form.query.focus();
	}
// -->
</script>
</head>

<body link="#0000FF" vlink="#800080" alink="#FF0000" onLoad=setfocus()>

	<p align="center">
        <a href="http://www.paanet.com/bigmeta"><img border="0" src="bigmeta.gif" width="300" height="75"></a><br>
		<b>
		<font color="#000000" size="2">&quot;Search <a href="http://www.altavista.com">AltaVista</a>, <a href="http://www.google.com">Google</a>, <a href="http://www.webcrawler.com">Webcrawler</a>, <a href="http://www.thunderstone.com">Thunderstone</a>, and <a href="http://www.fastsearch.com">FastSearch</a> all at once.&quot;</font>
		</b>
	</p>

<hr color="#000000" noshade>

	<p align="center">
		<form method="GET" action="webmeta.php" name="form">
		<font size="2" color="#000000"><b>Search for: </b></font>
		<input type="text" name="query" size="55"><input type="submit" value="Go!">
		</form>

<hr color="#000000" noshade>

    <p align="center">
    	<font size="2" color="#000000">
    	<b>Powered by gnomes on hamster wheels, along with a little help from<br>
    	<a href="http://www.php.net">The PHP Scripting Language</a><br><br>
		<? include "searchcount.dat"; ?> searches since 11/5/00<br><br>
		Copyright 2000 <a href="mailto:info@bigmeta.com">Alan Dipert</a>
  		</b></font>
    </p>

</body>

</html>
