Title: AS simple counter v1.0
Description: AS Simple Counter is a 100% Customizable counter. It uses a IP Detection to track all unique hits and then stores everything in a MySQL database.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=523&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
