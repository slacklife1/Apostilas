A total of <b>
<? include "counter.php"; ?>
</b> have visited our website.