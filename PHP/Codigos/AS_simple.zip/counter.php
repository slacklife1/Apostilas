<?	
				
//	AS Simple Counter
//	version 1.0.0
//	http://www.Anarky-Studios.ca.tc/

	include "counter.func";
	$exit_now = "0";

if ( log_is_empty("$REMOTE_ADDR") == "true" && $unique_hits == "1" && $exit_now != "1") {
	
	add_log("$REMOTE_ADDR");
	
	update_counter();
 
	echo get_counter();

	$exit_now = "1";

}

if ( log_is_empty("$REMOTE_ADDR") == "false" && $unique_hits == "1" && $exit_now != "1") {
	 
	echo get_counter();
	
}

if ( $unique_hits == "0" && $exit_now != "1") {
	
	update_counter(); 
	echo get_counter();
	
}

?>