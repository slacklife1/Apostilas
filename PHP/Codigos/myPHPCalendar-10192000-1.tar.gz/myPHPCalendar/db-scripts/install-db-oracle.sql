----------------------------------------------------------
--
-- Table structure for table 'calendar'
--

CREATE TABLE calendar (
   id number(11),
   title varchar(255),
   body varchar(1800),
   "user" number(11),
   "date" varchar(100),
   time varchar(20),
   duration varchar(20),
   permissions varchar(255),
   datetime number(11),
   special number(11) default 0,
   agenda varchar(255),
   recurrence number(50) default 0 not null, 
   recurr_days varchar(50), 
   recurr_options varchar(50), 
   startdate number(50), 
   enddate number(50)
);

----------------------------------------------------------
--
-- Table structure for table 'contacts'
--

CREATE TABLE contacts (
   id number(11) NOT NULL,
   owner number(11) NOT NULL,
   permissions varchar(255),
   lname varchar(255),
   fname varchar(255),
   title varchar(255),
   company varchar(255),
   "work" varchar(30),
   home varchar(30),
   fax varchar(30),
   other varchar(30),
   email varchar(100),
   address varchar(255),
   city varchar(100),
   state varchar(100),
   zip varchar(20),
   country varchar(100),
   custom1 varchar(255),
   custom2 varchar(255),
   custom3 varchar(255),
   custom4 varchar(255),
   note varchar(1800),
   type number(11),
   category varchar(255),
   PRIMARY KEY (id)
);


----------------------------------------------------------
--
-- Table structure for table 'groups'
--

CREATE TABLE groups (
   id number(11) NOT NULL,
   name varchar(255),
   "user" number(11),
   users varchar(255),
   moderate varchar(1800),
   canwrite varchar(1800),
   na_users varchar(1800),
   dec_users varchar(1800),
   PRIMARY KEY (id)
);


----------------------------------------------------------
--
-- Table structure for table 'users'
--

CREATE TABLE users (
   id number(11) NOT NULL,
   fname char(255),
   lname char(255),
   username char(255),
   password char(255),
   email char(255),
   permissions varchar(255)
);


CREATE TABLE sessions ( sess_id varchar(255), sess_vars varchar(255), datetime number(11));

create table user_prefs(id number(11), cdaycolor varchar(20), cell varchar(5), tcellcolor varchar(20), ttextcolor varchar(20), cellspacing varchar(5), bordercolor varchar(20), bordersize varchar(5), cellcolor varchar(20), background_color varchar(20), background_image varchar(255), language varchar(50));
