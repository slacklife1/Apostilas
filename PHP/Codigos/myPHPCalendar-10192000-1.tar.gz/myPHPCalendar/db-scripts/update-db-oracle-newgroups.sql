alter table groups add moderate varchar(1800), add canwrite varchar(1800), add na_users varchar(1800), add dec_users varchar(1800);
