alter table calendar add recurrence number(50) default 0 not null, add recurr_days varchar(50), add recurr_options varchar(50), add startdate number(50), add enddate number(50);
