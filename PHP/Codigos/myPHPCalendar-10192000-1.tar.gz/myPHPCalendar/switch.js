<?php
// myPHPCalendar - Online Calendaring Software
// Copyright (C) 2000 David van der Bokke

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// switch.js
// Javascript functions that are included for use on the edit and add date
// screens for the user list and group options.

?>


<SCRIPT LANGUARE="JavaScript">
<!-- Begin
sortitems = 1; 

<?php
	$ct = sql_command("select count(ID) from users");
	$ct = current($ct);
	for ($x = 1; $x <= $ct; $x++) {
		if ($uid != $x) {
			$temp = sql_command("select fname, lname from users where id = $x");
			$names1 = "$names1".$x.",".$temp[fname]." ".$temp[lname].":";
		}
	}
	$ct = sql_command("select count(ID) from groups");
        $ct = current($ct);
	global $uid;
        for ($x = 1; $x <= $ct; $x++) {
		if (guser_status($uid, $x) >= 1) {
	                $temp = sql_command("select name from groups where id = $x");
			$groups = "$groups".current($temp).":";
		}
        }
	for ($x = 1; $x <= 7; $x++) {
		$weekdays = "$weekdays".$daynames[$x].":";
	}
	for ($x = 1; $x <= 4; $x++) {
		$rep_one = "$rep_one".$rep_once_types[$x].":";
	}
?>

var names = "<?php echo $names1; ?>";
var grps = "<?php echo $groups; ?>";
var daytmp = "<?php echo $weekdays; ?>";
var onetmp = "<?php echo $rep_one; ?>";
var users = names.split(":");
var groups = grps.split(":");
var daynames = daytmp.split(":");
var rep_one_types = onetmp.split(":");

function switch_recurr(fbox, tbox) {
	for (var x = 0; x < fbox.options.length; x++) {
		if (fbox.options[x].selected && fbox.options[x].value == 1) {
			clearbox(tbox);
			tbox.options.length = 1;
                        tbox.options[0].value = "na";
                        tbox.options[0].text = "-Not Applicable-";
		} else if (fbox.options[x].selected && fbox.options[x].value == 2) {
			clearbox(tbox);
			for (var i = 0; i <= rep_one_types.length - 2; i++) {
                                        tmp = tbox.options.length;
                                        tbox.options.length = tbox.options.length + 1;
                                        tbox.options[tbox.options.length - 1].value = tbox.options.length;
                                        tbox.options[tbox.options.length - 1].text = rep_one_types[i];
                        }
		} else if (fbox.options[x].selected && fbox.options[x].value == 3) {
			clearbox(tbox);
                        tbox.options.length = 1;
                        tbox.options[0].value = "na";
                        tbox.options[0].text = "-Not Applicable-";
		} else if (fbox.options[x].selected && fbox.options[x].value == 4) {
                        clearbox(tbox);
                        tbox.options.length = 1;
                        tbox.options[0].value = "na";
                        tbox.options[0].text = "-Not Applicable-";
                }
	}
}

function switch_text(fbox, tbox) {
	for (var x = 0; x < fbox.options.length; x++) {
		if (fbox.options[x].selected && fbox.options[x].value == 1) {
			clearbox(tbox);
			tbox.options.length = 1;
			tbox.options[0].value = "na";
			tbox.options[0].text = "-Not Applicable-";
		} else if (fbox.options[x].selected && fbox.options[x].value == 2) {
			clearbox(tbox);
			tbox.options.length = 1;
			tbox.options[0].value = "na";
			tbox.options[0].text = "-Not Applicable-";
		} else if (fbox.options[x].selected && fbox.options[x].value == 3) {
			clearbox(tbox);
			for (var i = 0; i <= users.length - 2; i++) {
				var tmp = users[i].split(",");
				tbox.options.length = i + 1;
				tbox.options[i].value = tmp[0];
				tbox.options[i].text = tmp[1];
			}
		} else if (fbox.options[x].selected && fbox.options[x].value == 4) {
			clearbox(tbox);
			var b = 0;
                        for (var i = 0; i <= groups.length - 2; i++) {
				if (groups[i] != "Deleted") {
					tmp = tbox.options.length;
					tbox.options.length = tbox.options.length + 1;
	                                tbox.options[tbox.options.length - 1].value = b + 1;
        	                        tbox.options[tbox.options.length - 1].text = groups[i];  
				}
				b++;
                        }
                }
	}
}

function clearbox(box) {
	for (var x=0; x < box.options.length; x++) {
		box.options[x].value = "";
		box.options[x].text = "";
	}
	box.options.length = 0;
}

function SortD(box)  {
	var temp_opts = new Array();
	var temp = new Object();
	for(var i=0; i<box.options.length; i++)  {
		temp_opts[i] = box.options[i];
	}
	for(var x=0; x<temp_opts.length-1; x++)  {
		for(var y=(x+1); y<temp_opts.length; y++)  {
			if(temp_opts[x].text > temp_opts[y].text)  {
				temp = temp_opts[x].text;
				temp_opts[x].text = temp_opts[y].text;
				temp_opts[y].text = temp;
			}
		}
	}
	for(var i=0; i<box.options.length; i++)  {
		box.options[i].value = temp_opts[i].value;
		box.options[i].text = temp_opts[i].text;
	}
}
// End -->
</script>

