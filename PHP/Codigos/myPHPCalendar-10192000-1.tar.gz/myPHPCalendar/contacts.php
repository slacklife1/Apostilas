<?php
// myPHPCalendar - Online Calendaring Software
// Copyright (C) 2000 David van der Bokke

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// contacts.php
// This file controls all aspects of the contacts page.
// It determines what the user wants the script to do and displays
// data accordingly by including other files or running functions from
// globals.inc or contacts.inc

include ("globals.inc");
if (! function_exists(session_start)) {
        include("session.inc");
}
include("sql.inc");
$conn = sql_connect ($mysql_server, $mysql_username, $mysql_pass, $database_name);
include("contacts.inc");
session_start();
if (! empty($LoggedIn)) {
      register_prefs($sess_id, $uid);
      include("lang/".$language.".inc");
}
$result = strcmp(session_id(), $sess_id);
if ($result) {
        $sid = session_id();
        header("Location: $url$mainscript?sess_id=$sid");
        nice_exit();
}

if (! $LoggedIn) {
        $sid = session_id();
        print_header("myPHPCalendar Contacts: Not Logged In");
        echo "$please_login\n<br>\n";
        print_login($sid);
        echo "</body></html>";
        nice_exit();
} else {
        $sid = session_id();
//        if (check_LoggedIn($sid, $LoggedIn) == 1) {
//                print_header("myPHPCalendar Contacts: Attempted Session Hijack");
//                echo "<h4><blink><font color = RED>!WARNING! Attempted session hijacking.<br>\nYour systems administrator will be notified<br>\n</h4></blink>";
//                echo "</body></html>";
//                sql_close($conn);
//                nice_exit();
//        }
}

if ($DELETECONTACT == 1) {
        $sid = session_id();
        $row = sql_command("select owner from contacts where id = $id");
        if (current($row) != $uid) {
                echo "<font color = RED><h4>You Cannot Delete This Contact</h4></font>\n";
        } else {
                sql_query("update contacts set fname = 'Deleted', lname = 'Deleted' where id = $id");
        }
}

if ($VIEW == 1) {
        $sid = session_id();
        $row = sql_command("select * from contacts where id = $id");
        print_header("myPHPCalendar: View Contact: $row[fname] $row[lname]");
        include('viewcontact.inc');
} elseif (isset($ADDCONTACT)) {
        $sid = session_id();
        if ($ADDCONTACT == 1) {
                print_header("myPHPCalendar: $add_contact");
                include('addcontact.inc');
        } elseif ($ADDCONTACT == 2) {
                if (empty($fname) || empty($lname)) {
                        print_header("myPHPCalendar: $add_contact");
                        echo "<font color = RED><h4>You are missing a required field</h4></font>\n";
                        include('addcontact.inc');
                        nice_exit();
                }
                $ct = sql_command("select count(ID) from contacts");
                $ct = current($ct) + 1;
                $note = addslashes(eregi_replace("\n", "\n", $note));
                $address = eregi_replace("\n", "\n", $address);
                $query = "insert into contacts (id, owner, permissions, lname, fname, title, company, \"work\", home, fax, other, email, address, city, state, zip, country, custom1, custom2, custom3, custom4, note, type, category) values ($ct, $uid, '$uid', '$lname', '$fname', '$title', '$company', '$work', '$home', '$fax', '$other', '$email', '$address', '$city', '$state', '$zip', '$country', '$custom1', '$custom2', '$custom3', '$custom4', '$note', 0, 'Unfiled')";
                sql_query($query);
                header("Location: $url$scriptname?sess_id=$sid");
                nice_exit();
        }
} elseif (isset($EDITCONTACT)) {
        $sid = session_id();
        if ($EDITCONTACT == 1) {
                $row = sql_command("select * from contacts where id = $id");
                if ($row[owner] != $uid) {
                        print_header("myPHPCalendar: Edit Contacts: Error");
                        echo "<font color = RED><h4>You cannot edit this contact</h4></font>";
                } else {
                        print_header("myPHPCalendar: Edit $row[fname] $row[lname]");
                        include('editcontact.inc');
                }
        } elseif ($EDITCONTACT == 2) {
                $row = sql_command("select * from contacts where id = $id");
                if ($row[owner] != $uid) {
                        print_header("myPHPCalendar: Edit Contacts: Error");
                        echo "<font color = RED><h4>You cannot edit this contact</h4></font>";
                } else {
                        $note = addslashes(eregi_replace("\n", "\n", $note));
                        $address = eregi_replace("\n", "\n", $address);
                        $query = "update contacts set lname = '$lname', fname = '$fname', title = '$title', company = '$company', \"work\" = '$work', home = '$home', fax = '$fax', other = '$other', email = '$email', address = '$address', city = '$city', state = '$state', zip = '$zip', country = '$country', custom1 = '$custom1', custom2 = '$custom2', custom3 = '$custom3', custom4 = '$custom4', note = '$note' where id = $id";
                        sql_query($query);
                        header("Location: $url$scriptname?sess_id=$sid");
                        nice_exit();
                }
        }
} else {
        print_header("myPHPCalendar: Contact List");
        list_all_contacts(session_id());
        echo "<a href = \"$scriptname?sess_id=$sid&ADDCONTACT=1\">$add_contact</a>";
}

echo "<hr><center>\n";
$sid = session_id();

if (!isset($DATEADD))        print_newdate($sid);
if (isset($LoggedIn)) {
        print_logout($sid);
        print_options($sid);
} elseif (! isset($LoggedIn) && empty($SLOGIN)) {
        echo "<a href = \"$mainscript?sess_id=$sid&SLOGIN=1\">Login</a>\n";
        echo "<br><a href = \"$mainscript?sess_id=$sid&NEWU=1\">New User</a>\n";
}
if (! isset($date)) $date = getdate();
echo "<a href = \"$mainscript?sess_id=$sid&PRINTCAL=1&month=$date[mon]&year=$date[year]\">$calendar</a>$menu_delimiter\n";
echo "<a href = \"$contactscript?sess_id=$sid\">$contacts</a></center>\n";
if (isset($uid) && !empty($uid) && $uid != 0) {
        $row = sql_command("select permissions from users where id = $uid");
        if (strcmp(current($row), "ga") == 0) {
                echo "<a href =
\"$adminscript?sess_id=$sid\">$admin</a></center>\n";
        }
}
if (isset($footer_text)) echo $footer_text;
echo "</body></html>";
nice_exit();
?>