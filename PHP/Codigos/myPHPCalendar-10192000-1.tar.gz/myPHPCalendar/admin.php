<?php
// myPHPCalendar - Online Calendaring Software
// Copyright (C) 2000 David van der Bokke

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// admin.php
// this file is the beggiing administration page

include ("globals.inc");
if (! function_exists(session_start)) {
        include("session.inc");
}
include("sql.inc");
include("admin.inc");
$conn = sql_connect ($mysql_server, $mysql_username, $mysql_pass, $database_name);
session_start();
if (! empty($LoggedIn)) {
      register_prefs($sess_id, $uid);
      include("lang/".$language.".inc");
}
$result = strcmp(session_id(), $sess_id);
if ($result) {
        $sid = session_id();
        sql_close($conn);
        header("Location: $url$mainscript?sess_id=$sid");
        exit;
}

if (! $LoggedIn) {
        $sid = session_id();
        print_header("myPHPCalendar Contacts: Not Logged In");
        echo "$please_login\n<br>\n";
        print_login($sid);
        echo "</body></html>";
        sql_close($conn);
        exit;
} else {
        $sid = session_id();
        if (check_LoggedIn($sid, $LoggedIn) == 1) {
                print_header("myPHPCalendar Admin: Attempted Session Hijack");
                echo "<h4><blink><font color = RED>!WARNING! Attempted session hijacking.<br>\nYour systems administrator will be notified<br>\n</h4></blink>";
                echo "</body></html>";
                sql_close($conn);
                exit;
        }
}

if (isset($uid) && !empty($uid) && $uid != 0) {
        $row = sql_command("select permissions from users where id = $uid");
        if (strcmp(current($row), "ga") != 0) {
                print_header("myPHPCalendar Admin: Attempted Hack");
                echo "<h4><font color = RED>!WARNING! Attempted admin hacking</font></h4>\n";
                echo "</body></html>";
                sql_close($conn);
                exit;
        }
}

if (isset($USERS)) {
        if ($USERS == 1) {
                print_header("myPHPCalendar: Admin: User Administration");
                print_user($sid);
        } elseif ($USERS == 2) {
                print_header("myPHPCalendar: Admin: Edit user #$id");
                $row = sql_command("select * from users where id = $id");
                include("admin_user.inc");
        } elseif ($USERS == 3) {
                $row = sql_command("select password from users where id = $id");
                $pw = current($row);
                if (strcmp(substr($pw, 0, 3), "###") == 0 && $auth == 0) {
                        $pw = substr($pw, 3, strlen($pw) - 3);
                        sql_query("update users set password = '$pw' where id = $id");
                } elseif (strcmp(substr($pw, 0, 3), "###") != 0 && $auth == 1) {
                        $pw = "###$pw";
                        sql_query("update users set password = '$pw' where id = $id");
                }
                print_header("myPHPCalendar: Admin: User Administration");
                echo "<font color = BLUE><h4>Successfully Update User</h4></font>\n";
                print_user($sid);
        }
} else {
        print_header("myPHPCalendar: Admin");
        echo "<table border = $bordersize cellspacing=$cellspacing bordercolor=\"$bordercolor\"><tr><td valign = top bgcolor = $tcellcolor colspan = 2>Administration Options</td>\n";
        echo "<tr><td valign = top><a href = \"$adminscript?sess_id=$sid&USERS=1\">User Administration</a></td>\n";
        echo "<td valign = top>Control users</td>\n";
        echo "</table>\n";
}


echo "<hr>\n";
$sid = session_id();

if (!isset($DATEADD))        print_newdate($sid);
if (isset($LoggedIn)) {
        print_logout($sid);
        echo "<br>";
        print_options($sid);
} elseif (! isset($LoggedIn) && empty($SLOGIN)) {
        echo "<a href = \"$mainscript?sess_id=$sid&SLOGIN=1\">Login</a>\n";
        echo "<br><a href = \"$mainscript?sess_id=$sid&NEWU=1\">New User</a>\n";
}
if (! isset($date)) $date = getdate();
echo "<a href = \"$mainscript?sess_id=$sid&PRINTCAL=1&month=$date[mon]&year=$date[year]\">Calendar</a>\n";
echo "<a href = \"$contactscript?sess_id=$sid\">Contacts</a>\n";
if (isset($uid) && !empty($uid) && $uid != 0) {
        $row = sql_command("select permissions from users where id = $uid");
        if (strcmp(current($row), "ga") == 0) {
                echo "<a href = \"$adminscript?sess_id=$sid\">Admin</a>\n";
        }
}
if (isset($footer_text)) echo $footer_text;
echo "</body></html>";
sql_close($conn);
exit;
?>