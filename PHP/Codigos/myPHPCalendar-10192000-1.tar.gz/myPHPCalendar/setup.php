<?php
// myPHPCalendar - Online Calendaring Software
// Copyright (C) 2000 David van der Bokke

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// setup.php
// Provides an easy way for systems administrators to setup
// and upgrade myPHPCalendar

	if ($EDIT == 1) {
		$fp = fopen("setup.inc", "w+");
		fputs($fp, "<?php\n");
		fputs($fp, "\$url = \"".$URL."\";\n");
		fputs($fp, "\$mainscript = \"".$MAINSCRIPT."\";\n");
		fputs($fp, "\$mysql_server = \"".$MYSQL_SERVER."\";\n");
		fputs($fp, "\$mysql_username = \"".$MYSQL_USERNAME."\";\n");
		fputs($fp, "\$mysql_pass = \"".$MYSQL_PASS."\";\n");
		fputs($fp, "\$database_name = \"".$DATABASE_NAME."\";\n");
		fputs($fp, "\$db_type = \"".$DB_TYPE."\";\n");
		fputs($fp, "\$user_text = \"".$USER_TEXT."\";\n");
		fputs($fp, "\$crypt_type = \"".$CRYPT_TYPE."\";\n");
		fputs($fp, "\$display_username = \"".$DISPLAY_USERNAME."\";\n");
		fputs($fp, "\$maxdisplay = \"".$MAXDISPLAY."\";\n");
		fputs($fp, "\$admin_email = \"".$ADMIN_EMAIL."\";\n");
		fputs($fp, "\$agenda_dir = \"".$AGENDA_DIR."\";\n");
		fputs($fp, "\$lock_newu = \"".$LOCK_NEWU."\";\n");
		fputs($fp, "\$lock_rep = \"".$LOCK_REP."\";\n");
		fputs($fp, "\$sess_usedb = \"".$SESS_USEDB."\";\n");
		fputs($fp, "\$language = \"".$language."\";\n");
		fputs($fp, "\$VRF_G_ADDITION = \"".$VRF_G_ADDITION."\";\n");
		fputs($fp, "\$ALLOW_PUBLIC = \"".$ALLOW_PUBLIC."\";\n");
		$user_text = addslashes($user_text);
		$footer_text = "<hr>\$user_text<br><font size = 1 color = BLUE><center><a href = \\\"http://myphpcalendar.sourceforge.net\\\">myPHPCalendar</a> - Version \$version";
		$footer_text = "$footer_text<br>Copyright 2000 by David van der Bokke<br>";
		$footer_text = "$footer_text Released under the GNU General Public License</center></font>";
		fputs($fp, "\$footer_text = \"".$footer_text."\";\n");
		fputs($fp, "?>\n");
		fclose($fp);
		$fp = fopen("prefs.inc", "w+");
                fputs($fp, "<?php\n");
		fputs($fp, "\$cdaycolor = \"".$CDAYCOLOR."\";\n");
		fputs($fp, "\$cell = \"".$CELL."\";\n");
                fputs($fp, "\$tcellcolor = \"".$TCELLCOLOR."\";\n");
		fputs($fp, "\$ttextcolor = \"".$TTEXTCOLOR."\";\n");
		fputs($fp, "\$cellspacing = \"".$CELLSPACING."\";\n");
		fputs($fp, "\$bordercolor = \"".$BORDERCOLOR."\";\n");
		fputs($fp, "\$bordersize = \"".$BORDERSIZE."\";\n");
		fputs($fp, "\$cellcolor = \"".$CELLCOLOR."\";\n");
		fputs($fp, "\$background_color = \"".$BACKGROUND_COLOR."\";\n");
		fputs($fp, "\$background_image = \"".$BACKGROUND_IMAGE."\";\n");
		fputs($fp, "?>\n");
                fclose($fp);
?>
setup.inc Update Sucessful<br>
Please proceed to install the database(if you have not done so already) by creating a new database:<br>
mysqladmin -uuser -ppass create database<br>
Setup any user/pass stuff you set in the setup<br>
mysql -uuser -ppass database < install-db<br>
<br><br>
You may want to move this script(setup.php) to another location for safety/security.
<br>
<?php
	} elseif ($EDIT == 2) {
		include("setup.inc");
		include("sql.inc");
		$conn = sql_connect($mysql_server, $mysql_username, $mysql_pass, $database_name);
		$id = sql_command("select id from users where username = '$USERNAMEFORADD'");
		$id = current($id) || die("Oooppss.. can't find that user..");
		sql_query("update users set permissions = 'ga' where id = $id");
		echo "Updated...";
		sql_close($conn);
	} else {
		if (file_exists("setup.inc")) {
			include("setup.inc");
		}
		if (file_exists("prefs.inc")) {
                        include("prefs.inc");
                }

?>
<h3>myPHPCalendar Setup</h3><hr>
<form action = "setup.php?EDIT=1" method = POST>
Site URL(with trailing /): <input type = text name = "URL" value = "<?php echo $url ?>">
<br>
<?php
	if (empty($mainscript)) {
		$mainscript = "index.php";
	}
?>
Site Scriptname: <input type = text name = "MAINSCRIPT" value = "<?php echo $mainscript ?>">
<br>
mySQL Server(address): <input type = text name = "MYSQL_SERVER" value = "<?php echo $mysql_server ?>">
<br>
mySQL Database: <input type = text name = "DATABASE_NAME" value = "<?php echo $database_name ?>">
<br>
mySQL Username: <input type = text name = "MYSQL_USERNAME" value = "<?php echo $mysql_username ?>">
<br>
mySQL Password: <input type = password name = "MYSQL_PASS" value = "<?php echo $mysql_pass ?>">
<br>
<h3>DO NOT CHANGE THIS TO A NEW TYPE IF YOU ALREADY HAVE USERS</h3>
Encryption type: <select name = "CRYPT_TYPE">
<?php
	if (! isset($crypt_type) || $crypt_type == 1) {
		echo "<option value = \"1\" selected>mcrypt</option>";
	} else {
		echo "<option value = \"1\">mcrypt</option>";
	}
	if ($crypt_type == 2) {
		echo "<option value = \"2\" selected>unix crypt</option>";
	} else {
		echo "<option value = \"2\">unix crypt</option>";
	}
	if ($crypt_type == 3) {
		echo "<option value = \"3\" selected>plain text</option>";
	} else {
		echo "<option value = \"3\">plain text</option>";
	}
?>
</select>
<br>
Database type: <select name = "DB_TYPE">
<?php
        if (! isset($db_type) || $db_type == 1) {
                echo "<option value = \"1\" selected>mySQL</option>";
        } else {
                echo "<option value = \"1\">mySQL</option>";
        }
        if ($db_type == 2) { 
                echo "<option value = \"2\" selected>PostgreSQL</option>";
        } else {
                echo "<option value = \"2\">PostgreSQL</option>";
        }
        if ($db_type == 3) {
                echo "<option value = \"3\" selected>MS SQL Server 7</option>";
        } else {
                echo "<option value = \"3\">MS SQL Server 7</option>";
	}
	if ($db_type == 4) {
                echo "<option value = \"4\" selected>Oracle 8</option>";
        } else {
                echo "<option value = \"4\">Oracle 8</option>";
        }
?>
</select>
<br>
Display username on view date: <select name = "DISPLAY_USERNAME">
<?php
	if ($display_username == 0) {
		echo "<option value = \"0\" selected>No</option>\n";
	} else {
		echo "<option value = \"0\">No</option>\n";
	}
	if ($display_username == 1) {
                echo "<option value = \"1\" selected>Yes</option>\n";
        } else {
                echo "<option value = \"1\">Yes</option>\n";
        }
?>
</select>
<br>
Page Footer Text(optional.. can include HTML):<br> <textarea name = "USER_TEXT" rows = 5 cols = 50><?php echo $user_text ?></textarea>
<br>
<?php
        if (empty($lock_rep)) {
                $lock_rep = "10";
        }
?>
Lock repetitive dates to this many repeats: <input type = text name = "LOCK_REP" value = "<?php echo $lock_rep ?>">
<br>
Use database for sessions(PHP3 Only): <select name = "SESS_USEDB">
<?php
        if ($sess_usedb == 0) {
                echo "<option value = \"0\" selected>No</option>\n";
        } else {
                echo "<option value = \"0\">No</option>\n";
        }
        if ($sess_usedb == 1) {
                echo "<option value = \"1\" selected>Yes</option>\n";
        } else {
                echo "<option value = \"1\">Yes</option>\n";
        }
?>
</select>
<br>
<?php
	if (empty($cdaycolor)) {
		$cdaycolor = "#ffa0da";
	}
?>
Current Day Highlight Color: <input type = text name = "CDAYCOLOR" value = "<?php echo $cdaycolor ?>">
<br>
<?php
        if (empty($cell)) {
                $cell = "80";
        }
?>
Table cell size for month view: <input type = text name = "CELL" value = "<?php echo $cell ?>">
<br>
<?php
        if (empty($tcellcolor)) {     
                $tcellcolor = "green";          
        }
?>
Color for TITLE cells: <input type = text name = "TCELLCOLOR" value = "<?php echo $tcellcolor ?>">
<br>
Color for TITLE text: <input type = text name = "TTEXTCOLOR" value = "<?php echo $ttextcolor ?>">
<br>
Amount of space between cells: <input type = text name = "CELLSPACING" value = "<?php echo $cellspacing ?>">
<br>
Table border color: <input type = text name = "BORDERCOLOR" value = "<?php echo $bordercolor ?>">
<br>
Size of table border: <input type = text name = "BORDERSIZE" value = "<?php echo $bordersize ?>">
<br>
Normal Day Color: <input type = text name = "CELLCOLOR" value = "<?php echo $cellcolor; ?>">
<br>
Background Color: <input type = text name = "BACKGROUND_COLOR" value = "<?php echo $background_color; ?>">
<br>
Background Image: <input type = text name = "BACKGROUND_IMAGE" value = "<?php echo $background_image; ?>">
<br>
<br>
<?php     
        if (empty($maxdisplay)) {
                $cell = "0";
        }
?>   
Display X items on month calendar(0 is ALL): <input type = text name = "MAXDISPLAY" value = "<?php echo $maxdisplay ?>">
<br>
Administrator Email: <input type = text name = "ADMIN_EMAIL" value = "<?php echo $admin_email ?>">
<br>
Item Attachments Dir(ie: "user_files/"): <input type = text name = "AGENDA_DIR" value = "<?php echo $agenda_dir ?>">
<br>
Autmatically disable accounts for new users: <select name = "LOCK_NEWU">
<?php
        if ($lock_newu == 0) {
                echo "<option value = \"0\" selected>No</option>\n";
        } else {
                echo "<option value = \"0\">No</option>\n";
        }
        if ($lock_newu == 1) {
                echo "<option value = \"1\" selected>Yes</option>\n";
        } else {
                echo "<option value = \"1\">Yes</option>\n";
        }
?>  
</select>
<br>
Setting Verify Group Additions to Yes allows a user to accept or decline an invitation into a group of users(on the group options form, the user will be emailed the request so this means that if a user has a bad email address, they are out of luck).  If this option is set to No, the user will automatically be added to the group.
<br>
Verify Group Additions: <select name = "VRF_G_ADDITION">
<?php
	if ($VRF_G_ADDITION == 0) {
                echo "<option value = \"0\" selected>No</option>\n";
        } else {
                echo "<option value = \"0\">No</option>\n";
        }
        if ($VRF_G_ADDITION == 1) {
                echo "<option value = \"1\" selected>Yes</option>\n";
        } else {
                echo "<option value = \"1\">Yes</option>\n";
        }
?>
</select>
<br>
Allow Public Posting: <select name = "ALLOW_PUBLIC">
<?php
	if ($ALLOW_PUBLIC == 0) {
                echo "<option value = \"0\" selected>No</option>\n";
        } else {
                echo "<option value = \"0\">No</option>\n";
        }
        if ($ALLOW_PUBLIC == 1) {
                echo "<option value = \"1\" selected>Yes</option>\n";
        } else {
                echo "<option value = \"1\">Yes</option>\n";
        }
?>
</select>
<br>
Language: <select name = language>
<option value = "english">English</option>
<option value = "espanol">Spanish</option>
<option value = "french">French</option>
<option value = "german">German</option>
<option value = "czech">Czech</option>
<option value = "swedish">Swedish</option>
</select>
<br>
<input type = submit>
</form>

<?php
	}
?>
<hr>
<form action = "setup.php?EDIT=2" method = POST>
<BR>
DO NOT USE THIS UNTIL YOU HAVE RUN THE CHANGE DATABASE SCRIPTS!!!<br>
Add Global Admin to: <input type = text name = "USERNAMEFORADD">
<br>
<input type = submit>
</form>
