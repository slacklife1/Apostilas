<?php_track_vars?>
<?
// myPHPCalendar - Online Calendaring Software
// Copyright (C) 2000 David van der Bokke

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

include('globals.inc');
include('sql.inc');
$conn = sql_connect($mysql_server, $mysql_username, $mysql_pass, $database_name);
$cnt = sql_command("select count(ID) from calendar");
echo "<html><head></head><body>\n";
echo "<h4><font color = BLUE>Successfully Updated.. Results are as follows..</h4></font>\n";
echo "<table border = 1>\n";
echo "<tr bgcolor = TEAL><td>Month</td><td>Day</td><td>Year</td><td>Hour</td><td>Minutes</td><td>Timestamp</td>\n";
for ($x = 1; $x <= current($cnt); $x++) {
	$row = sql_command("select date, time from calendar where id = $x");
	$date = split(",", $row[date]);
	$tme = split(",", $row[time]);
	$tm = split(":", $tme[0]);
	if ($minutes != "") {
		$minutes = $tm[1];
	} else {
		$minutes = 0;
	}
	if (strcmp("am", $tme[1]) == 0 && $tm[0] == 12) $hour = 0;
	if (strcmp("pm", $tme[1]) == 0 && $tm[0] != 12) $hour = $tm[0] + 12;
	if (strcmp("pm", $tme[1]) == 0 && $tm[0] == 12) $hour = 12;
	if (strcmp("am", $tme[1]) == 0 && $tm[0] != 12) $hour = $tm[0];
	for ($d = 1; $d <= 12; $d++ ) {
		if (strcmp($monthnames[$d], $date[0]) == 0 ) $month = $d;
	}
	$day = $date[1];
	$year = $date[2];
	echo "<tr><td>$month</td><td>$day</td><td>$year</td><td>$hour</td><td>$minutes</td>";
	$time = mktime($hour, $minutes, 0, $month, $day, $year);
	echo "<td>$time</td>\n";
	sql_query("update calendar set datetime = '$time' where id = $x");
}
echo "</table></body>";


sql_close($conn);
?>
