<?php
// myPHPCalendar - Online Calendaring Software
// Copyright (C) 2000 David van der Bokke

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// index.php
// This file is what runs the Calendar.
// It determines what a user is trying to see and also determines whether or
// not someone is trying to use someone elses session id.

$timeparts = explode(" ", microtime());
$starttime = $timeparts[1].substr($timeparts[0],1);

include ($cal_dir."globals.inc");
if (! function_exists(session_start)) {
        include($cal_dir."session.inc");
}
include($cal_dir."sql.inc");
$conn = sql_connect ($mysql_server, $mysql_username, $mysql_pass, $database_name);

session_start();
if (! empty($LoggedIn)) {
      register_prefs($sess_id, $uid);
      include($cal_dir."lang/".$language.".inc");
}
$result = strcmp(session_id(), $sess_id);
if ($result) {
        $sid = session_id();
        if ($num == 4) {
                echo "You do not have cookies turned on.  Without cookies this application will not work properly.";
                nice_exit();
        }
        $num++;
        if (isset($AUTHUGC) && isset($AUTHUGID) && isset($AUTHGID)) {
                header("Location: $url$mainscript?sess_id=$sid&num=$num&AUTHUGC=$AUTHUGC&AUTHUGID=$AUTHUGID&AUTHGID=$AUTHGID&UPDOPT=3");
        } else {
                header("Location: $url$mainscript?sess_id=$sid&num=$num");
        }
        nice_exit();
}

// if (isset($LoggedIn)) {
//        $sid = session_id();
//        if (check_LoggedIn($sid, $LoggedIn) == 1) {
//                print_header("myPHPCalendar: Attempted Session Hijack");
//                echo "<h4><blink>!WARNING! Attempted session hijacking.<br>\nYour systems administrator will be notified</blink></h4>\n";
//                echo "</body></html>";
//                sql_close($conn);
//                nice_exit();
//        }
//}

if ($LOGIN == 1) {
        $sid = session_id();
        $un = $UNAME;
        $row = sql_command("Select * from users where username = '$UNAME'");
        if ($crypt_type == 1) {
		if (function_exists(ob_start)) ob_start();
                $PW = mcrypt_ecb(MCRYPT_BlowFish, $row[fname], $PW, MCRYPT_ENCRYPT);
		if (function_exists(ob_end_clean)) ob_end_clean();
        } elseif($crypt_type == 2) {
                $pw = $row[password];
                $salt = "$pw[0]$pw[1]";
                $PW = crypt($PW, $salt);
        } elseif($crypt_type == 3) {
                $pw = $row[password];
        }
        if (strcmp($PW, $row[password]) == 0) {
                session_register('LoggedIn');
                if ($crypt_type == 1) {
			if (function_exists(ob_start)) ob_start();
                        $LoggedIn = mcrypt_ecb(MCRYPT_BlowFish, session_id(), $UNAME, MCRYPT_ENCRYPT);
			if (function_exists(ob_end_clean)) ob_end_clean();
                } elseif ($crypt_type == 2) {
                        $LoggedIn = crypt(session_id(), $UNAME);
                } elseif ($crypt_type == 3) {
                        $LoggedIn = base64_encode(session_id());
                }
                $LoggedIn = "yeah";
                session_register('uid');
                $uid = $row[id];
                register_prefs($sid, $uid);
		$new = 0;
		list($result, $rows) = sql_query("select id from groups");
		for ($x = 0; $x < $rows; $x++) {
			$row = sql_fetch_array($result, $x);
			if (is_in_nagroup($uid, $row[id]) == true) {
				$new = 1;
				break;
			}
		}
		sql_free_result($result);
		if ($new == 1) {
			echo "You have been invited to join a group(s), click <a href = \"$mainscript?sess_id=$sid&NAGROUPS=1\">here</a> to accept or decline the invitation.";
		}
        } else {
                session_register('UNAME');
                $UNAME = $un;
                header("Location: $url$mainscript?sess_id=$sid&FAILEDL=1");
        }
} elseif ($DELETE == 1) {
        $sid = session_id();
        $row = sql_command("select * from calendar where id = $id");
        if (isset($uid) && ! empty($uid) && $uid != 0) {
                $perm = sql_command("select permissions from users where id = $uid");
                $perm = current($perm);
        }
        if (strcmp($row[user], $uid) == 0 || strcmp($perm, "ga") == 0) {
                sql_query("update calendar set title = 'Deleted' where id = $id");
        }
        $date = split(",", $row[date]);
        $month = month_num($date[0]);
        header("Location: $url$mainscript?sess_id=$sid&PRINTCAL=1&month=$month&year=$date[2]");
} elseif ($Logout == 1) {
        session_start();
        session_unregister('uid');
        session_unregister('LoggedIn');
        session_destroy();
        session_start();
        session_id(uniqid(rand()));
        $sid = session_id();
        header("Location: $url$mainscript?sess_id=$sid");
}

if ($NEWU == 1) {
        $sid = session_id();
        print_header("myPHPCalendar: New User");
        print_newuser($sid);
} elseif ($ADD == 1) {
        $sid = session_id();
        $row = sql_command("select * from users where username = '$UNAME'");
        if ($row[username] == "") {
                print_header("myPHPCalendar: User Added");
                if ($crypt_type == 1) {
			if (function_exists(ob_start)) ob_start();
                        $PW = mcrypt_ecb(MCRYPT_BlowFish, $FNAME, $PW, MCRYPT_ENCRYPT);
			if (function_exists(ob_end_clean)) ob_end_clean();
                } elseif ($crypt_type == 2) {
                        $PW = crypt($PW);
                } elseif ($crypt_type == 3) {
                        $PW = $PW;
                }
                if ($lock_newu == 1) $PW = "###$PW";
                $count = sql_command("Select COUNT(ID) from users");
                $count = current($count) + 1;
                sql_query("insert into users (id, fname, lname, username, password, email) values ($count, '$FNAME', '$LNAME', '$UNAME', '$PW', '$EMAIL')");
                sql_query("insert into user_prefs (id, cdaycolor, cell, tcellcolor, ttextcolor, cellspacing, bordercolor, bordersize, cellcolor, background_color, background_image, language) values ($count, '$cdaycolor', '$cell', '$tcellcolor', '$ttextcolor', '$cellspacing', '$bordercolor', '$bordersize', '$cellcolor', '$background_color', '$background_image', '$language')");
                echo "<center><h4>Successfully Registered User #$count</h4></center>\n";
                print_login($sid);
        } else {
                print_header("myPHPCalendar: User Add Unsucessful");
                echo "<center><h4>Username Taken</h4></center>\n";
                print_newuser($sid);
        }
} elseif ($PRINTCAL == 1) {
        $sid = session_id();
        $date[mon] = $month;
        $date[year] = $year;
        $date[month] = $monthnames[$month];
        $dt = getdate();
        if ($dt[mon] == $date[mon] && $dt[year] == $date[year]) {
                $date[mday] = $dt[mday];
        }
        print_header("myPHPCalendar: Public Calendar");
        print_all_cal($date, $sid);
} elseif ($VIEWDATE == 1) {
        $sid = session_id();
        $row = sql_command("select * from calendar where id = $id");
        $date = getdate($row[datetime]);
        $date[mon] = $month;
        $date[mday] = $day;
        $date[year] = $year;
        print_header("myPHPCalendar: $row[title]");
        include ("viewdate.inc");
} elseif (isset($DATEADD)) {
        $sid = session_id();
        if(! $LoggedIn) {
                session_register('DATEADD');
                $dateadd = 1;
                print_header("myPHPCalendar: Please Login");
                print_login($sid);
        } elseif ($DATEADD == 2) {
                $errors = 0;
                if (empty($hour) && $special == 0) {
                        $msg = "Please enter the hour for the assigned date.";
                        print_header("myPHPCalendar: $new_date", 'switch.js');
                        include ('adddate.inc');
                        nice_exit();
                }
                if (strlen($minute) == 1) {
                        $msg = "Please enter 2 digits in the minute field for the assigned date.";
                        print_header("myPHPCalendar: $new_date", 'switch.js');
                        include('adddate.inc');
                        nice_exit();
                }
                if (empty($title)) {
                        $msg = "Please enter the title for the assigned date.";
                        print_header("myPHPCalendar: $new_date", 'switch.js');
                        include('adddate.inc');
                        nice_exit();
                }
                if (empty($day)) {
                        $msg = "Please enter the day for the assigned date.";
                        print_header("myPHPCalendar: $new_date", 'switch.js');
                        include('adddate.inc');
                        nice_exit();
                }
                $max = date("t", mktime(0, 0, 0, $month, 1, $year));
                if ($day > $max) {
                        $msg = "Please enter a valid day for the assigned date.";
                        print_header("myPHPCalendar: $new_date", 'switch.js');
                        include('adddate.inc');
                        nice_exit();
                }
                if (isset($userfile) && ! empty($userfile) && strcmp($userfile, "none") != 0) {
                        if (file_exists($agenda_dir.$userfile_name)) {
                                $msg = "The filename you are trying to input is already taken.  Please change the name and try again.  If you are not sure what to do please email: <a href = \"mailto:$admin_email\">$admin_email</a>.";
                                print_header("myPHPCalendar: $new_date", 'switch.js');
                                include ('adddate.inc');
                                nice_exit();
                        } else {
                                $file = fread(fopen($userfile, "r"), 1000000);
                                $fp = fopen($agenda_dir.$userfile_name, "w+");
                                fputs($fp, $file);
                                fclose($fp);
                                unlink($userfile);
                        }
                }
                if (empty($duration)) {
                        $duration = NULL;
                }
                        $username = sql_command("select username from users where id = $uid");
                        $username = current($username);
                        $count = sql_command("select count(id) from calendar");
                        $count = $count[0] + 1;
                        if ($type == 1) {
                                $type = "*";
                        } elseif ($type == 2) {
                                $type = $uid;
                        } elseif ($type == 3 || $type == 4) {
                                $temp = count($names);
                                if ($type == 4) $type = "g:";
                                if ($type == 3) $type = "$uid:";
                                for ($x = 0; $x < $temp; $x++) {
                                        $type = "$type$names[$x]:";
                                }
                        }
                        if (strcmp($ampm, "am") == 0 && $hour == 12) $hour = 0;
                        if (strcmp($ampm, "pm") == 0 && $hour != 12) $hour += 12;
                        for ($x = 1; $x <= 12; $x++) {
                                if (strcmp($month, $monthnames[$x]) == 0) {
                                        $mth = $x;
                                }
                        }
                        if ($special == 0) {
                                $date = mktime($hour, $minute, 0, $mth, $day, $year);
                        } else {
                                $date = mktime(0, 0, 0, $mth, $day, $year);
                        }
                        $body = addslashes(htmlentities($body));
                        $title = strip_tags($title, "<bold>,<font>");
                        $title = addslashes(htmlentities($title));
                        if (count($rep_days) > 0 || $rep_type == 4) {
				if (is_array($rep_days)) {
	                                while (list($key, $val) = each($rep_days)) {
        	                                $days = "$days$val:";
                	                }
				}
                                $rec_enddate = mktime(0, 0, 0, $rep_month, $rep_day + 1, $rep_year);
                                $rec_startdate = mktime(0, 0, 0, $mth, $day, $year);
                                if ($rep_type == 1) {
                                        $rec_options = "";
                                        $rec_type = 1;
                                        $rec_days = $days;
                                } elseif ($rep_type == 2) {
                                        list($key, $val) = each($rep_other);
                                        $rec_options = $val;
                                        $rec_type = 2;
                                        $rec_days = $days;
                                } elseif ($rep_type == 3) {
                                        $rec_options = "";
                                        $rec_type = 3;
                                        $rec_days = $days;
				} elseif ($rep_type == 4) {
					$rec_options = "";
					$rec_type = 4;
					$rec_days = "";
					$rec_enddate = mktime(0, 0, 0, $mth, $day, 1970);
                                } elseif (empty($rep_type)) {
                                        $rec_type = NULL;
                                        $rec_enddate = NULL;
                                        $rec_startdate = NULL;
                                }
                        } else {
                                $rec_type = 0;
                                $rec_enddate = 0;
                                $rec_startdate = 0;
                                $rec_days = "";
                        }
                           sql_query("insert into calendar (id, title, body, \"user\", \"date\", duration, permissions, datetime, special, agenda, recurrence, recurr_days, recurr_options, startdate, enddate) values ($count, '$title', '$body', '$uid', '$month,$day,$year', '$duration', '$type', '$date', $special, '$userfile_name', $rec_type, '$rec_days', '$rec_options', $rec_startdate, $rec_enddate)");
                        header("Location: $url$mainscript?sess_id=$sid&PRINTCAL=1&year=$year&month=$mth");
        } else {
                session_unregister('DATEADD');
                print_header("myPHPCalendar: $new_date", 'switch.js');
                include ("adddate.inc");
        }
} elseif (isset($DATEDIT)) {
        $sid = session_id();
        if(! $LoggedIn) {
                session_register('DATEDIT');
                session_register('id');
                $dateedit = 1;
                $id = $id;
                print_header("myPHPCalendar: Please Login");
                print_login($sid);
                echo "<a href = \"$mainscript?sess_id=$sid&NEWU=1\">$new_user</a>\n";
        } elseif($DATEDIT == 2) {
                if ($type == 1) {
                        $type = "*";
                } elseif ($type == 2) {
                        $type = $uid;
                } elseif ($type == 3 || $type == 4) {
                        $temp = count($names);
                        if ($type == 4) $type = "g:";
                        if ($type == 3) $type = "$uid:";
                        for ($x = 0; $x < $temp; $x++) {
                                $type = "$type$names[$x]:";
                        }
			if (strcmp($type[0], "g") == 0) {
				for ($x = 1; $x <= count($other_groups); $x++) {
					$type = "$type$other_groups[$x]:";
				}
			}
                }
                if (strcmp($ampm, "am") == 0 && $hour == 12) $hour = 0;
                if (strcmp($ampm, "pm") == 0 && $hour < 12) $hour += 12;
                for ($x = 1; $x <= 12; $x++) {
                        if (strcmp($month, $monthnames[$x]) == 0) {
                                $mth = $x;
                        }
                }
                $date = mktime($hour, $minute, 0, $mth, $day, $year);
                $title = strip_tags($title, "<bold>,<font>");
                $title = addslashes(htmlentities($title));
                $body = addslashes(htmlentities($body));
                if (count($rep_days) > 0 || $rep_type == 4) {
                        if (is_array($rep_days)) {
				while (list($key, $val) = each($rep_days)) {
                                	$days = "$days$val:";
	                        }
 			}       
	                $rec_enddate = mktime(0, 0, 0, $rep_month, $rep_day + 1, $rep_year);
                        $rec_startdate = mktime(0, 0, 0, $mth, $day, $year);
                        if ($rep_type == 1) {
                                $rec_options = "";
                                $rec_type = 1;
                                $rec_days = $days;
                        } elseif ($rep_type == 2) {
                                list($key, $val) = each($rep_other);
                                $rec_options = $val;
                                $rec_type = 2;
                                $rec_days = $days;
                        } elseif ($rep_type == 3) {
                                $rec_options = "";
                                $rec_type = 3;
                                $rec_days = $days;
			} elseif ($rep_type == 4) {
                                        $rec_options = "";
                                        $rec_type = 4;
                                        $rec_days = "";
                                        $rec_enddate = mktime(0, 0, 0, $mth, $day, 1970);
                        } elseif (empty($rep_type)) {
                                $rec_type = NULL;
                                $rec_enddate = NULL;
                                $rec_startdate = NULL;
                        }
                  } else {
                        $rec_type = 0;
                        $rec_enddate = 0;
                        $rec_startdate = 0;
                        $rec_days = "";
                }
                $query = "update calendar set title = '$title', body = '$body', \"date\" = '$month,$day,$year', datetime = '$date', duration = '$duration', permissions = '$type', special = $special, recurrence = $rec_type, recurr_days = '$rec_days', recurr_options = '$rec_options', startdate = $rec_startdate, enddate = $rec_enddate where id = $id";
                sql_query($query);
                header("Location: $url$mainscript?sess_id=$sid&PRINTCAL=1&year=$year&month=$mth");
        } else {
                session_unregister('DATEDIT');
                session_unregister('id');
                $row = sql_command("select * from calendar where id = $id");
                $date = getdate($row[datetime]);
                if (isset($uid) && ! empty($uid) && $uid != 0) {
                        $perm = sql_command("select permissions from users where id = $uid");
                        $perm = current($perm);
                }
		list($result, $rows) = sql_query("select id from groups where name <> 'Deleted'");
	        $ed = 0;
        	for ($x = 0; $x < $rows; $x++) {
			$row1 = sql_fetch_array($result, $x);
				$temp = guser_status($uid, $row1[id]);
				
                        	if ($temp >= 2) {
					$d = count($mod_array);
					$mod_array[$d] = $row1[id];
				} elseif ($temp == 1) {
					$d = count($write_array);
					$write_array[$d] = $row1[id];
				} elseif ($temp == 0) {
					$d = count($read_array);
					$read_array[$d] = $row1[id];
				} elseif ($temp == -1) {
					$d = count($none_array);
					$none_array[$d] = $row1[id];
				}
                } 
		sql_free_result($result);
                if ($row[user] == $uid || strcmp($perm, "ga") == 0 || $ed = 1) {
                        print_header("myPHPCalendar: $row[title]", 'switch.js');
                        include("editdate.inc");
                } else {
                        print_header("myPHPCalendar: $row[title]");
                        echo "<h4><center>You cannot edit this object.</h4></center>\n";
                        include ("viewdate.inc");
                }
        }
} elseif ($SLOGIN == 1) {
        $sid = session_id();
        print_header("myPHPCalendar: Login");
        print_login($sid);
} elseif (isset($UPDOPT)) {
        $sid = session_id();
        if ($UPDOPT == 0) {
                print_header("myPHPCalendar: Options Menu");
                print_options_menu($sid);
        } elseif ($UPDOPT == 1) {
                $row = sql_command("select * from users where id = $uid");
                if ($crypt_type == 1) {
			if (function_exists(ob_start)) ob_start();
                        $password = mcrypt_ecb(MCRYPT_BlowFish, $row[fname], $row[password], MCRYPT_DECRYPT);
			if (function_exists(ob_end_clean)) ob_end_clean();
                } elseif ($crypt_type == 2) {
                        $password = "";
                } elseif ($crypt_type == 3) {
                        $password = $row[password];
                }
                print_header("myPHPCalendar: User Options", "verification.js");
                include("user_options.inc");
        } elseif ($UPDOPT == 2) {
                if ($crypt_type == 1) {
			if (function_exists(ob_start)) ob_start();
                        $PW = mcrypt_ecb(MCRYPT_BlowFish, $fname, $PW, MCRYPT_ENCRYPT);
			if (function_exists(ob_end_clean)) ob_end_clean();
                } elseif ($crypt_type == 2) {
                        if (! empty($PW)) {
                                $PW = crypt($PW);
                        } else {
                                $PW = sql_command("select password from users where id = $uid");
                                $PW = current($PW);
                        }
                } elseif ($crypt_type == 3) {
                        $PW = $PW;
                }
                sql_query("update users set fname = '$fname', lname = '$lname', email = '$email', password = '$PW' where id = $uid");
                sql_query("update user_prefs set background_color = '$upd_background_color', background_image = '$upd_background_image', cellcolor = '$upd_cellcolor', cdaycolor = '$upd_cdaycolor', cell = '$upd_cell', tcellcolor = '$upd_tcellcolor', ttextcolor = '$upd_ttextcolor', cellspacing = '$upd_cellspacing', bordersize = '$upd_bordersize', bordercolor = '$upd_bordercolor', language = '$upd_language' where id = $uid");
                register_prefs($sid, $uid);
                include("lang/".$language.".inc");
                print_header("myPHPCalendar: Options Updated");
                echo "<h4>Options Updated</h4>";
                $date = getdate();
                print_all_cal($date, $sid);
        } elseif ($UPDOPT == 3) {
                print_header("myPHPCalendar: Group Options");
                include ("group_options.inc");
        }
} elseif (isset($FAILEDL)) {
        $sid = session_id();
        print_header("myPHPCalendar: Failed Login");
        $row = sql_command("select password from users where username = '$UNAME'");
        if (substr(current($row), 0, 3) != "###") {
                if ($crypt_type != 2) {
                        echo "<a href = \"$script?sess_id=$sid&MAILPW=$UNAME\">Mail me my password</a>\n";
                }
                echo "<h4>Login Failed</h4>\n";
        } else {
                echo "<h4>You have not been authorized to login.</h4>\n";
        }
        $date = getdate();
        session_unregister('UNAME');
        print_all_cal($date, $sid);
} elseif (isset($MAILPW)) {
        $row = sql_command("select * from users where username = '$MAILPW'");
        if ($crypt_type == 1) {
		if (function_exists(ob_start)) ob_start();
                $password = mcrypt_ecb(MCRYPT_BlowFish, $row[fname], $row[password], MCRYPT_DECRYPT);
		if (function_exists(ob_end_clean)) ob_end_clean();
        } elseif ($crypt_type == 2) {

        } elseif ($crypt_type == 3) {
                $password = $row[password];
        }
        $message = "The password for accout name $row[username] is $password";
        mail ("$row[email]", "Your password for the Calendar", $message, "From: $admin_email");
        print_header("myPHPCalendar: Sent Password");
        echo "<h4>Password Sent</h4>\n";
        $date = getdate();
        print_all_cal($date, $sid);
} elseif (isset($VIEWLITTLE)) {
        if ($VIEWLITTLE == 1) {
                $sid = session_id();
                if (isset($cmonth)) {
                        $month = $cmonth;
                }
                $date[mon] = $month;
                $date[year] = $year;
                $date[month] = $monthnames[$month];
                $date[day] = $day;
                print_header("myPHPCalendar: Public Calendar");
                print_little_cal($date);
        }
} elseif (isset($VIEWPERIOD)) {
        if ($VIEWPERIOD == 1) {
                $sid = session_id();
                print_header("myPHPCalendar: View Period of $monthnames[$startmonth] $startday, $startyear to $monthnames[$endmonth] $endday, $endyear");
                echo "<table border=$bordersize cellspacing=$cellspacing bordercolor=\"$bordercolor\"><tr bgcolor = $tcellcolor><td width = 40 class=\"headerText\">$event_time</td>\n";
                echo "<td width = 400 class=\"headerText\">$subject</td>\n";
                for ($year = $startyear; $year <= $endyear; $year++) {
                        $sm = ($year > $startyear) ? 1: $startmonth;
                        $em = ($year < $endyear) ? 12 : $endmonth;
                        for ($x = $sm; $x <= $em; $x++) {
                                $sd = ($x == $startmonth && $year == $startyear) ? $startday : 1;
                                $ed = ($x == $endmonth && $year == $endyear) ? $endday : date("t", mktime(0,0,0,$x,1,$year));
                                for ($d = $sd; $d <= $ed; $d++) {
                                        $date[mon] = $x;
                                        $date[year] = $year;
                                        $date[month] = $monthnames[$x];
                                        $date[day] = $d;
                                        print_period_day($date);
                                }
                        }
                }
                echo "</table>\n";
                $date[mon] = $startmonth;
                $date[year] = $startyear;
                $date[month] = $monthnames[$startmonth];
                $date[mday] = $startday;
        }
} elseif (isset($SEARCH)) {
        $sid = session_id();
        print_header("myPHPCalendar: Search Results");
        if ($search_type == 1) $like = "title like '%$stext%'";
        if ($search_type == 2) $like = "body like '%$stext%'";
        if ($search_type == 3) $like = "title like '%$stext%' or body like '%$stext'";
        $temp = print_search_results($sid, $like);
        $items = $temp[1];
        $sitems = $temp[0];
        echo "<table><tr><td valign = top>";
        echo "<table border=$bordersize cellspacing=$cellspacing bordercolor=\"$bordercolor\"><tr bgcolor = $tcellcolor><td colspan=3 class = \"headerText\">Search Results</td>\n";
        echo "<tr bgcolor = $tcellcolor><td width = 40 class=\"headerText\">$event_date</td>\n";
        echo "<td width = 40 class=\"headerText\">$event_time</td>\n";
        echo "<td width = 400 class=\"headerText\">$subject</td>\n";
        for ($d = 0; $d < count($items) + count($sitems); $d++) {
                if ($d >= count($sitems)) {
                        $row = $items[$d - count($sitems)];
                } else {
                        $row = $sitems[$d];
                }
                $dt = getdate($row[datetime]);
                $mon = $dt[mon];
                echo "<tr><td valign = top>$monthnames[$mon] $dt[mday], $dt[year]</td>";
                if ($dt[minutes] == 0) $dt[minutes] = "00";
                if (strlen($dt[minutes]) == 1) $dt[minutes] = "0$dt[minutes]";
                if ($clock_type == 1) {
                        if ($dt[hours] >= 12) $ampm = "pm";
                        if ($dt[hours] < 12) $ampm = "am";
                        if ($dt[hours] > 12) $dt[hours] -= 12;
                        if ($dt[hours] == 0) $dt[hours] = 12;
                } elseif ($clock_type == 2) {
                        $ampm = "";
                }
                echo "<td valign = top>";
                if ($row[special] == 1) {
                        echo "<span class=\"special\">$spcl</span>";
                } else {
                        echo "<span class=\"time\">$dt[hours]:$dt[minutes]$ampm</span>\n";
                }
                echo "</td><td valign = top><a href  = \"$mainscript?sess_id=$sid&VIEWDATE=1&id=$row[id]&month=$date[mon]&day=$date[day]&year=$date[year]\">$row[title]</a></td>\n";
        }
        echo "</table>";
        echo "</td><td valign = top>";
        $date = getdate();
        print_all_sideoptions($date, $sid);
        echo "</td></table>\n";
} elseif ($NAGROUPS == 1) {
	$sid = session_id();
	print_header("myPHPCalendar: Group Invitations");
	include ("accept_groups.inc");
} else {
        $sid = session_id();
        print_header("myPHPCalendar: Public Calendar");
        $date = getdate();
        // print_little_cal($date);
        print_all_cal($date, $sid);
}
echo "<hr><center>\n";
$sid = session_id();

if (!isset($DATEADD))        print_newdate($sid);
if (isset($LoggedIn)) {
        print_logout($sid);
        print_options($sid);
} elseif (! isset($LoggedIn) && empty($SLOGIN)) {
        echo "<a href =
\"$mainscript?sess_id=$sid&SLOGIN=1\">$login</a>$menu_delimiter\n";
        echo "<a href =
\"$mainscript?sess_id=$sid&NEWU=1\">$new_user</a>$menu_delimiter\n";
}
if (! isset($date)) $date = getdate();
echo "<a href = \"$mainscript?sess_id=$sid&PRINTCAL=1&month=$date[mon]&year=$date[year]\">$calendar</a>$menu_delimiter\n";
echo "<a href = \"$contactscript?sess_id=$sid\">$contacts</a>\n";
if (isset($uid) && !empty($uid) && $uid != 0) {
        $row = sql_command("select permissions from users where id = $uid");
        if (strcmp(current($row), "ga") == 0) {
                echo "$menu_delimiter<a href = \"$adminscript?sess_id=$sid\">Admin</a>\n";
        }
}
echo "</center>\n";
if (isset($footer_text)) echo $footer_text;
nice_exit();
?>

</body>
