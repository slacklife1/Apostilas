<?php
// myPHPCalendar - Online Calendaring Software
// Copyright (C) 2000 David van der Bokke

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

// verification.js
// Javascript that is included for form verification

?>


<SCRIPT LANGUAGE="JavaScript">
<!--
function checkPw(form) {
	pw1 = form.PW.value;
	pw2 = form.chkpass.value;

	if (pw1 != pw2) {
		alert ("\nYou did not enter the same new password twice. Please re-enter your password.")
		return false;
	}
	else return true;
}


function emailCheck(form) {
txt=form.email.value;
if (txt.indexOf("@")<3){
alert("I'm sorry. This email address seems wrong. Please"+" check the prefix and '@' sign.");
return false;
}
if ((txt.indexOf(".com")<5)&&(txt.indexOf(".org")<5)&&(txt.indexOf(".gov")<5)&&(txt.indexOf(".net")<5)&&(txt.indexOf(".mil")<5)&&(txt.indexOf(".us")<5)&&(txt.indexOf(".uk")<5)&&(txt.indexOf(".edu")<5)){
alert("I'm sorry. This email address seems wrong. Please"+" check the suffix for accuracy. (It should include a "+".com, .edu, .net, .org, .gov, .us, .uk or .mil)");
		return false;
	}
	return true;
}


// -->


</script>
