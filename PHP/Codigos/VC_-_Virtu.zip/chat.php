<?php
/*---------------------------------------------------
            	Virtual Chatter
            		version 2
            	   Copyright 2002
            	   Cornelius Herzog
                cornelius.herzog@gmx.de
-----------------------------------------------------
	THIS SCRIPT IS NOT FREE. YOU JUST ARE ALLOWED
	TO TEST IT YOURSELF. IF YOU WANT TO USE IT ON
		YOUR PAGE FOR ALL USERS YOU HAVE TO PAY.
-----------------------------------------------------
 	DIESES SCRIPT IST NICHT KOSTENLOS. ES DARF
 	NUR ZUM TESTEN BENUTZT WERDEN. SOBALD ES ALLEN
 	USERN AUF DER HOMEPAGE ZUG�NGLICH GEMACHT WIRD,
 			MUSS DAF�R BEZAHLT WERDEN
---------------------------------------------------*/

  $db_server = "localhost"; 				//your db login informations
  $db_login = "root";
  $db_passwort = "";
  $db_name = "vc";
  $db_table = "vc";


$reasonone = "warum";								//a word with it the user can ask for the reason eg: why
$reasontwo = "wieso";								//a second word with it the user can ask for the reason eg: why
$notunderstand = "Ich verstehe dich nicht.";		//if the phrase is not in the database tell the user that the vc dont understand him
$statementans = "aha/soso/interessant";				//some words to confirm a statement. split them by "/"

if($action == "message") {							//if the action is message
	$msg = stripcslashes($msg);						//strip slashes
	$output = answer($msg);							//give the message the the function answers
	echo '<head><link rel="stylesheet" type="text/css" href="index.css"></head>';
	echo "<p><b>$user:</b> $msg</p>";
	echo "<p><b>vc:</b> $output</p>";
}
function answer($msg) {
	global $lastaction;								//use the global vars
	global $sid;
	global $reasonone;
	global $reasontwo;
	global $notunderstand;
	global $statementans;
	global $db_table;
	$msg = strtolower($msg);						//set all to lower case
	$msg = stripcslashes($msg);
	session_register("lastaction");					//register the session var
	$db = connect_database();						//connect database
	if(stristr($msg,$reasonone) OR stristr($msg,$reasontwo)) {		//if the user asks for a reason
		$data = file("session/$sid/id.dat");
		$last = sizeof($data) - 1;
		$lastid = $data[$last];
		$sql = "SELECT `reason`,`numberreasons` FROM `$db_table` WHERE `id`='$lastid';";
		$erg = mysql_db_query("vc",$sql,$db);
		list($reason,$numberreasons) = mysql_fetch_row($erg);
		$number = getrand($numberreasons - 1);
		$temp = explode("/",$reason);
		$thisanswer = $temp[$number];
	}else{
	$sql = "SELECT `id`,`question` FROM `$db_table`;";
	$erg = mysql_db_query("vc",$sql,$db);
		if($lastaction == "statement") {
			while(list($id,$question) = mysql_fetch_row($erg)) {
				$temp = explode("/",$question);
				if($temp[0] == ">") {
					if(stristr($question,$msg)) { $queid = $id; }
				}else{
					if(stristr($msg,$temp[1])) { $queid = $id; }
				}
			}
			if($queid == "") {
				$erg = mysql_db_query("vc",$sql,$db);
				$msgmeta = metaphone($msg);
				while(list($id,$question) = mysql_fetch_row($erg)) {
					$temp = explode("/",$question);
					if($temp[0] == ">") {
						$quemeta = metaphone($question);
						if(stristr($quemeta,$msgmeta)) { $queid = $id; }
					}else{
						$quemeta = metaphone($temp[1]);
						if(stristr($msgmeta,$quemeta)) { $queid = $id; }
					}
				}
			}
			if($queid == "") {
				$thisanswer = $notunderstand;
				$fp = fopen("notunderstood.dat","a");
				flock($fp,2);
				fputs($fp,$msg . "\n");
				flock($fp,3);
				fclose($fp);
			}else{
				$sql = "SELECT * FROM `$db_table` WHERE `id`='$queid';";
				$erg = mysql_db_query("vc",$sql,$db);
				list($id,$question,$answer,$numberanswers,$questionback,$reason,$numberreasons,$profile) = mysql_fetch_row($erg);
				if($numberanswers != "1") {
					$number = getrand($numberanswers-1);
					$temp = explode("/",$answer);
					$thisanswer = $temp[$number];
					$forprofile = $thisanswer;
				}else{
					$thisanswer = $answer;
				}
				if($questionback != "") {
				$thisanswer.= " " . $questionback;
				$lastaction = $profile;
				}else{
				$lastaction = "statement";
				}
			}
			$fp = fopen("session/$sid/id.dat","a");
			fputs($fp,"$queid\n");
			fclose($fp);
		}else{
			session_register("lastaction");
			$file="session/$sid/profile.dat";
			$profiledata = file($file);
			for($x=0;$x<sizeof($profiledata);$x++) {
				if(stristr($profiledata[$x],"[$lastaction]")) { $treffer = "yes"; }
			}
			if($treffer != "yes") {
			$data = "[$lastaction]\n$msg\n";
			$fp = fopen("session/$sid/profile.dat","a");
			fputs($fp,$data);
			fclose($fp);
			}
			$lastaction = "statement";
			$temp = explode("/",$statementans);
			$number = getrand(sizeof($temp) -1);
			$thisanswer = $temp[$number];
		}
	}
	mysql_close($db);
	return $thisanswer;
}








function getrand($max) {
srand ((double)microtime()*1000000);
$randval = rand();
$aa = rand("0",$max);
return $aa;
}






function connect_database() {
$db_connection=@mysql_connect($db_server, $db_login, $db_password);
if(! $db_connection){
	die("Error when connecting the database. Please check your login information!");
}
return $db_connection;
}






?>