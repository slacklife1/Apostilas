VC - Virtual Chatter

The VC is a program based on mysql and php. I think the name tells a lot. But anyway I explain ;-)
The user can chat with a virtual chat partner. He gives him answers.
I already put in some data in the database. But its just german. ;-))
You can try the following:
- Wie geht's?
- Was sind deine hobbys?
- Warum?

IMPORTANT: THIS SCRIPT IS NOT FREE. YOU JUST ARE ALLOWED TO TEST IT YOURSELF. IF YOU WANT TO USE IT ON YOUR PAGE FOR ALL USERS YOU HAVE TO PAY.
 
Features:
- The user can ask for the reason
- There are often more than one answer possibilitys
- The vc collects data (for eg his hobbies) of the user in a profile file
- Understands by spelling (eg hobbys, hobbies or when the user makes a writing mistake hobies)
- Collects all he dont understand in the notunderstood.dat

What are the files for:
- index.php: This is the start page to login and make a frameset
- chat.php: here is the main program
- add.php: here you can learn the vc new things
- notunderstood.dat: you find in this file the questions which the vc did not understand

Needs:
- PHP (needs sessions, and filewriting/reading permissions)
- Mysql (one table)

How to install:
-Use the vc.sql to create a table with some sampledata. 
-Set the vars in the chat.php and add.php (They are explained there)
-Upload and start the index.php


FAQS:

Que:There is a dir called session and in it are several dirs with sessionids as names. there are 4 files in it. What are they for?
Ans:In this for files are saved user informations. In the log.dat is saved the chat dialog.In the profile.dat are the user informations saved. In the user.dat is saved the usersname, ip, remote host and logintime and in the id.dat are the question ids saved.

Que:How can I "learn" the vc new questions and answers?
Ans:Set in the add.php the vars for the db login. The use the add.php. There is all explained.