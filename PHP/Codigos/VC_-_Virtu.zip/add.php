<?php
/*---------------------------------------------------
            	Virtual Chatter
            		version 2
            	   Copyright 2002
            	   Cornelius Herzog
                cornelius.herzog@gmx.de
-----------------------------------------------------
	THIS SCRIPT IS NOT FREE. YOU JUST ARE ALLOWED
	TO TEST IT YOURSELF. IF YOU WANT TO USE IT ON
		YOUR PAGE FOR ALL USERS YOU HAVE TO PAY.
-----------------------------------------------------
 	DIESES SCRIPT IST NICHT KOSTENLOS. ES DARF
 	NUR ZUM TESTEN BENUTZT WERDEN. SOBALD ES ALLEN
 	USERN AUF DER HOMEPAGE ZUG�NGLICH GEMACHT WIRD,
 			MUSS DAF�R BEZAHLT WERDEN
---------------------------------------------------*/
function connect_database() {
$db_connection=@mysql_connect($db_server, $db_login, $db_password);
if(! $db_connection){
	die("Error when connecting the database. Please check your login information!");
}
return $db_connection;
}
  $db_server = "localhost";
  $db_login = "root";
  $db_passwort = "";
  $db_name = "vc";
  $db_table = "vc";

echo '<head><link rel="stylesheet" type="text/css" href="index.css"></head><body><form action="add.php?action=add" method="post" name="add" id="add">
<table>
<tr>
	<td>Question</td>
	<td><input type="text" name="question"></td>
	<td>Enter here the question. Its a bit complicated ;-) I try to explain: There are to possibilites the recognize a question of the user: 1. Just an easy comparison or 2. looking for keyswords. You have to decide here which on to use in this question. Do it like the following: Begin the question with &lt;/ for the keyword search or with &gt;/ for the comparison. For example: if the user asks for the hobbies there are more than one possibilities he can ask: what are your hobbies? or what hobbies do you do?. So here we use a keyword recognazition: &lt;/hobbies. But if the user says hello we do it by this way: &gt;/hello/hy/hey/hi here we add even more than one possibility. Always split by "/". Hope you understood *g*</td>
</tr>
<tr>
	<td>Answer</td>
	<td><input type="text" name="answer"></td>
	<td>Enter here one or more answers to this question. Split the answer by "/". The answers are random choosen</td>
</tr>
<tr>
	<td>number of answers</td>
	<td><input type="text" name="numberanswers"></td>
	<td>Enter here the number of the answers (eg 1, 2, 3....)</td>
</tr>
<tr>
	<td>Question back</td>
	<td><input type="text" name="questionback"></td>
	<td>Enter here a question back. (eg if the question is how are you and the answer fine then is the questioback eg and you?)</td>
</tr>
<tr>
	<td>Reason</td>
	<td><input type="text" name="reason"></td>
	<td>Enter here one or more reasons for this answer</td>
</tr>
<tr>
	<td>Number of reasons</td>
	<td><input type="text" name="numberreasons"></td>
	<td>Enter here the number of the reasons</td>
</tr>
<tr>
	<td>To Profile?</td>
	<td><input type="text" name="profile"></td>
	<td>Enter here the profile name section. (eg for the emailadress of the user email). If you leave empty, the answer isnt put to the profile)</td>
</tr>
</table>
<input type="submit" name="Go" value="Go"><input type="submit" name="Delete" value="Delete all">

</form>
</body>';

if($action == "add") {
$db = connect_database();
$sql = "INSERT INTO `$db_table` (`id`, `question`, `answer`, `numberanswers`, `questionback`, `reason`, `numberreasons`, `profile`) VALUES ('', '$question', '$answer','$numberanswers','$questionback','$reason','$numberreasons','$profile');";
$erg = mysql_db_query("vc",$sql,$db);
if($erg) {
echo "ok";
}else{
echo "error:   ";
echo mysql_error();
}
}


?>