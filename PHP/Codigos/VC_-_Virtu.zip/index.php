<?php

/*---------------------------------------------------
            	Virtual Chatter
            		version 2
            	   Copyright 2002
            	   Cornelius Herzog
                cornelius.herzog@gmx.de
-----------------------------------------------------
	THIS SCRIPT IS NOT FREE. YOU JUST ARE ALLOWED
	TO TEST IT YOURSELF. IF YOU WANT TO USE IT ON
		YOUR PAGE FOR ALL USERS YOU HAVE TO PAY.
-----------------------------------------------------
 	DIESES SCRIPT IST NICHT KOSTENLOS. ES DARF
 	NUR ZUM TESTEN BENUTZT WERDEN. SOBALD ES ALLEN
 	USERN AUF DER HOMEPAGE ZUG�NGLICH GEMACHT WIRD,
 			MUSS DAF�R BEZAHLT WERDEN
---------------------------------------------------*/










$query = getenv("QUERY_STRING");
parse_url($query);
if($action == "") {

echo '<html><head><title>VC-Login</title><link rel="stylesheet" type="text/css" href="index.css"></head><body>
<h1>Welcome to VC,</h1>';
echo '<form action="index.php?action=login" method="post" name="login" id="login">
<p>Username:&nbsp;<input type="text" name="username"></p>
<input type="submit" name="submit" value="Los...">
</form>
';

}

if($action == "login") {
session_start();
$id = session_id();
$thisdir = "$DOCUMENT_ROOT/vc/v2/session/$id";
dir("$DOCUMENT_ROOT/vc/v2/");
@mkdir($thisdir,777);

$wann =  date("d.m.Y | G:i:s");
$fp = fopen("session/$id/user.dat","w");
fputs($fp, "Log gestartet: $wann\n$username\n$REMOTE_HOST\n$REMOTE_ADDR");
fclose($fp);
$fp = fopen("session/$id/log.dat","w");
fclose($fp);
$fp = fopen("session/$id/profile.dat","w");
fclose($fp);
session_register("lastaction");
$lastaction = "statement";
echo '
<frameset  rows="85%,*">
    <frame name="output" src="chat.php?action=output" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
    <frame name="input" src="index.php?action=input&sid='.$id.'&user='.$username.'" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
';


}


if($action == "input") {
echo '<html><head><title>VC-Login</title><link rel="stylesheet" type="text/css" href="index.css">
<script language="JavaScript" type="text/javascript">
function send() {
var msg = document.input.msg.value;
if(msg != "") {
document.input.msg.value = "";
window.parent.output.location.href = "chat.php?action=message&msg=" + msg + "&sid='.$sid.'&user='.$user.'";
}
return false;
}</script>
</head><body bgcolor="#c0c0c0">
<form action="index.php?action=input" name="input" id="input" onsubmit="return send()">
<input type="text" name="msg" size="60" value="">&nbsp;<input type="Submit" value="Los...">
<a href="index.php?action=logout" target="_top">Logout</a>
</form>
</body></html>';
}


if($action == "logout") {
session_destroy;
session_unset;
session_unregister;

}
?>


</body>
</html>
