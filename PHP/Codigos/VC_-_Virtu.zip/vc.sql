# phpMyAdmin MySQL-Dump
# version 2.2.3
# http://phpwizard.net/phpMyAdmin/
# http://phpmyadmin.sourceforge.net/ (download page)
#
# Host: localhost
# Erstellungszeit: 17. Sep 2002 um 00:43
# Server Version: 3.23.43
# PHP Version: 4.0.6
# Datenbank : `vc`
# --------------------------------------------------------

#
# Tablestructure for table `vc`
#

CREATE TABLE vc (
  id int(11) NOT NULL auto_increment,
  question text NOT NULL,
  answer text NOT NULL,
  numberanswers int(10) NOT NULL default '0',
  questionback text NOT NULL,
  reason text NOT NULL,
  numberreasons text NOT NULL,
  profile text NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY id (id),
  KEY id_2 (id)
) TYPE=MyISAM;

#
# Sampledata for table vc
#

INSERT INTO vc VALUES (2, '>/hi/hallo/hey/salut', 'hi/hallo/hey/salut', 4, '', '', '', '');
INSERT INTO vc VALUES (3, '</hobbies', 'Tja da ich nur virtuell existiere habe ich keine realen Hobbies. Aber chatte gerne *g*', 1, 'und was sind deine hobbies?', '', '', 'hobbies');
INSERT INTO vcVALUES (4, '>/wie gehts', 'gut/schlecht/super', 3, 'und dir?', 'weil sch�nes wetter ist/weil ich heute nicht mit dem linken bein aufgestanden bin/weil mein fr�hst�ck gut war', '3', 'zustand');
INSERT INTO vc VALUES (5, '</email', 'Meine emailadresse ist vc@localhost', 1, 'Hast du auch eine?', '', '', 'email');

