Title: VC - Virtual Chatter
Description: The vc is a virtual chat partner. you can ask him things in full sentences and he answers. 
i put in some nice other extras. for example he collects user informations etc.
this is the right tool for a webpage to help users to navigate.
theres a helpfile in the zip.
please remember the copyright informations
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=744&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
