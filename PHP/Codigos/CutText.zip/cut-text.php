<?php
/*****************************************
* Script: 	CUT-TEXT.PHP				 *
* Author: 	Alberto "RaS!" Sartori       *
* Contact: 	ras78@caltanet.it		     *
* Version: 	1.0 						 *
* Created:  03/07/2002 12:23:44		     *
* Revision: //							 *
*****************************************/

function CutText($text_to_cut,$words_to_display) {

 //Checking main argouments phase 1
 if (trim($text_to_cut)=="") {
   $text_cutted="";
   return false;
 }

 //Checking main argouments phase 2
 if ($text_to_cut=="" && (!is_numeric($words_to_display))) {
   $text_cutted="";
   return false;
 } else {
   $words_to_display=(integer)$words_to_display;
 }

 //Cutting text
 $vectors=explode(" ",$text_to_cut);
 if ($words_to_display>=(count($vectors)+1)) {
    $text_cutted="";
    return false;
 } else {
  $LimUP=($words_to_display-1);
  $exitLoop=false;
   do {
	   $c=substr($vectors[$LimUP],strlen($vectors[$LimUP])-1,1);
	   if (($c==",") or ($c==".") or ($c==";") or ($c==":") or ($c=="+") or ($c=="-") or ($c=="@")) {
	      $LimUP-=1;
	   } else {
	      $exitLoop=true;
	   }
  } while ($exitLoop=false and $LimUP >= 0);
   $FinalText="";
   for ($i=0;$i<=$LimUP;$i++) {
    $FinalText.=$vectors[$i]." ";   
   }
   $FinalText.="...";
   return $FinalText;
 }
}
?>