<?php
 $title		="kcEnterprise";
 $bgcolor	="black";
 $table_one	="#c0c0c0";
 $table_two	="white";
 $link		="dimgray";
 $active	="black"; 
 $hover		="black";
 $visited	="dimgray";
 $board_name	="kcEnterprise";
 $board_logo    ="http://ais.cms.k12.nm.us/~cmerrill/metal/images/kcE_logo.jpg";
 $font_size 	="2";
 $font_color	="black";
 $font_face	="verdena";
 $extension	=".kcTHEgreat";
 $email		="kcmerrill@hotmail.com";
 $font = "<font face=$font_face size=$font_size color=$font_color>"
 ?>
