<?php include("../config/layout.php"); ?>
<?php
 
$miscinfo = fopen("../misc/info.txt" , "r+");
  $minfo = fgets($miscinfo , 20000);
  chop($minfo);
  $minfo = explode ("*", $minfo);
fclose($miscinfo) ;


$feedinfo = fopen("../feedback/info.txt" , "r+");
  $finfo = fgets($feedinfo , 20000);
  chop($finfo);
  $finfo = explode ("*", $finfo);
fclose($feedinfo);


$geninfo = fopen("../general/info.txt" , "r+");
  $ginfo = fgets($geninfo , 20000);
  chop($ginfo);
  $ginfo = explode ("*", $ginfo);
fclose($geninfo) ;

$info = fopen("../info.txt" , "r+");
  $iinfo = fgets($info , 20000);
  chop($iinfo);
  $iinfo = explode ("*", $iinfo);
fclose($info) ;





echo "
<html>
<head>
<title>$title</title>
<style type=\"text/css\">
<!--
A:link
{ text-decoration: value none; color:$link }
A:visited
{ text-decoration: value none; color:$visited }
A:active
{ text-decoration: value none; color:$active }
A:hover
{ text-decoration: value underline; color:$hover;
-->
</style>
</head>
<body bgcolor=$bgcolor>
<div  align = right>
<table>
<tr>
 <td>
 <img src=$board_logo>
 </td>
</tr>
<tr>
<td>
 <div align=right>
 <table cellpadding=1 cellspacing=1 border=0 bgcolor=black>
 <tr>
   <td bgcolor=$table_one>
    $font
    <b>Newest user: </b>
  </td>
   <td bgcolor=$table_one>
    <font color=black size=1 face=verdena>
    <b>$iinfo[0]</b>
  </td>
 </tr>

 <tr>
   <td bgcolor=$table_two>
    $font
    <b>Total Posts: </b>
  </td>
   <td bgcolor =$table_two>
    $font
    <b>$iinfo[1]</b>
  </td>
 </tr>

 <tr>
   <td bgcolor=$table_one>
    $font
    <b>Total users: </b>
  </td>
   <td bgcolor=$table_one>
    $font
    <b>$iinfo[2]</b>
  </td>
 </tr>
</table>
</td>
</tr>
<tr>
 <Td bgcolor=$table_two>
  $font
  <div align=right><b>[</b><a href=../index.php> Forums </a><b>][</b><a href=../reg.php> Register </a><b>][</b><a href=../profiles.php> Member Profiles </a><b>][</b></b><a href=../faq.php> Faq </a><b>][</b><a href=../search.php> Search </a><b>]<b>[</b><a href=newgentopic.php> New Topic </a><b>]</div>
 </td>
</tr>
</table>
<Br>
<br>
</div>
<center>
";


$filename   = $id;
$filename  .=$extension;
$opentopic = fopen($filename , "r");
$data = fgets($opentopic , 20000);
chop($data);
$data = explode ("*", $data);
fclose($opentopic);

$opentopic = fopen($filename , "w");
$data[2]++;
fputs($opentopic,"$data[0]*$data[1]*$data[2]*$data[3]*$data[4]");
fclose($opentopic);


$filename   = $id;
$filename  .="topic";
$filename  .=$extension;
$opentopic = fopen($filename , "r");
$bleh = "";
while ((!feof($opentopic)))
{
$bleh .= fgets($opentopic , 20000);
}
fclose($opentopic);

$sigfile   = "../users/";
$sigfile .= $data[1];
$sigfile .= $extension;
$opensig = fopen($sigfile , "r");
$signa = fgets($opensig , 20000);
chop($signa);
$signa = explode ("*", $signa);

echo "
<table width=50% cellspacing=1 cellpadding=1 bgcolor=$bgcolor border=0>
<tr><td colspan=2><font face=$font_face size=$font_size color=$table_two><a href=../index.php>kcEnterprise</a> >> <a href=index.php>Feedback</a> >> $data[0]</td></tr>
  <tr><td bgcolor=$table_one width=20%><hr color=$table_two width=100%><center>$font <a href=../profile.php?user=$data[1]>$data[1]</a><hr color=$table_two width=100%></td><td valign =top bgcolor=$table_one>$font $bleh <br><br>--<Br> $signa[8]</td></tr>
 
";




$counter=1;
for ($x=1;$x<=$data[3];$x++)
 {
  $filename = $id;
  $filename .= "_c";
  $filename .= $x;
  $filename .=$extension;
  $openc = fopen($filename , "r");
  $creator = fgets($openc , 200000);
  fclose($openc);


  $filename = $id;
  $filename .= "_";
  $filename .= $x;
  $filename .=$extension;
  $openc = fopen($filename , "r");
  $message ="";
  while (!feof($openc))
   {
    $message .= fgets($openc , 200000); 
   }
  fclose($openc);





$sigfile   = "../users/";
$sigfile .= $creator;
$sigfile .= $extension;
$opensig = fopen($sigfile , "r");
$signa = fgets($opensig , 20000);
chop($signa);
$signa = explode ("*", $signa);
fclose($opensig);

  if ($counter%2==0)
   {
     echo "<tr><td bgcolor=$table_one width=25%><hr color=$table_two width=100%><center>$font <a href=../profile.php?user=$creator>$creator</a><hr color=$table_two width=100%></td><td valign =top bgcolor=$table_one>$font $message <br><Br>--<br> $signa[8] </td></tr>";
   }
  else
   {
     echo "<tr><td bgcolor=$table_two width=25%><hr color=$table_one width=100%><center>$font <a href=../profile.php?user=$creator>$creator</a><hr color=$table_one width=100%></td><td valign =top bgcolor=$table_two>$font $message <br><Br>--<br> $signa[8]</td></tr>";
   }
$counter++;
}


echo "
<Tr>
<Td>
$font
</td>
</tr>
<tr><td colspan=2 bgcolor=$table_two>$font<a href=reply.php?id=$id>Post Reply</a></td></tr>
</table>
<center>
<br><Br><br>
<font face=$font_face size=$font_size color=$table_two>
<b>
�kcEnterprise<br>
2000-2002 All rights reserved</body>
</html>
"



 ?>