<?php include("../config/layout.php"); ?>
<?php
 
$miscinfo = fopen("../misc/info.txt" , "r+");
  $minfo = fgets($miscinfo , 20000);
  chop($minfo);
  $minfo = explode ("*", $minfo);
fclose($miscinfo) ;


$feedinfo = fopen("../feedback/info.txt" , "r+");
  $finfo = fgets($feedinfo , 20000);
  chop($finfo);
  $finfo = explode ("*", $finfo);
fclose($feedinfo);


$geninfo = fopen("../general/info.txt" , "r+");
  $ginfo = fgets($geninfo , 20000);
  chop($ginfo);
  $ginfo = explode ("*", $ginfo);
fclose($geninfo) ;

$info = fopen("../info.txt" , "r+");
  $iinfo = fgets($info , 20000);
  chop($iinfo);
  $iinfo = explode ("*", $iinfo);
fclose($info) ;





echo "
<html>
<head>
<title>$title</title>
<style type=\"text/css\">
<!--
A:link
{ text-decoration: value none; color:$link }
A:visited
{ text-decoration: value none; color:$visited }
A:active
{ text-decoration: value none; color:$active }
A:hover
{ text-decoration: value underline; color:$hover;
-->
</style>
</head>
<body bgcolor=$bgcolor>
<div  align = right>
<table>
<tr>
 <td>
 <img src=$board_logo>
 </td>
</tr>
<tr>
<td>
 <div align=right>
 <table cellpadding=1 cellspacing=1 border=0 bgcolor=black>
 <tr>
   <td bgcolor=$table_one>
    $font
    <b>Newest user: </b>
  </td>
   <td bgcolor=$table_one>
    <font color=black size=1 face=verdena>
    <b>$iinfo[0]</b>
  </td>
 </tr>

 <tr>
   <td bgcolor=$table_two>
    $font
    <b>Total Posts: </b>
  </td>
   <td bgcolor =$table_two>
    $font
    <b>$iinfo[1]</b>
  </td>
 </tr>

 <tr>
   <td bgcolor=$table_one>
    $font
    <b>Total users: </b>
  </td>
   <td bgcolor=$table_one>
    $font
    <b>$iinfo[2]</b>
  </td>
 </tr>
</table>
</td>
</tr>
<tr>
 <Td bgcolor=$table_two>
  $font
  <div align=right><b>[</b><a href=../index.php> Forums </a><b>][</b><a href=../reg.php> Register </a><b>][</b><a href=../profiles.php> Member Profiles </a><b>][</b></b><a href=../faq.php> Faq </a><b>][</b><a href=../search.php> Search </a><b>]<b>[</b><a href=newgentopic.php> New Topic </a><b>]</div>
 </td>
</tr>
</table>
<Br>
<br>
</div>
<center>

<table width=70% cellspacing=1 cellpadding=1 bgcolor=$bgcolor border=0>
<tr><td><font face=$font_face size=$font_size color=$table_two><a href=../index.php>kcEnterprise</a> >> Misc...</td></tr>

<tr>  <td bgcolor=$table_two width=20%>$font<b>Subject</td>
      <td bgcolor=$table_one width=20%>$font<center><b>Creater</td>
      <td bgcolor=$table_two width=5%>$font<center><b>Views</td>
      <td bgcolor=$table_one width=5%>$font<center><b>Replies</td>
      <td bgcolor=$table_two width=20%>$font<center><b>Last post by</td>
</tr>";


$openinfo = fopen("info.txt" ,"r");
$counter = fgets($openinfo , 20);
chop($counter);
$counter = explode ("*", $counter);
for ($x=$counter[0];$x>0;$x--)
 {
$filename = $x;
$filename .=$extension;
$opentopic = fopen($filename , "r");
$data = fgets($opentopic , 200000);
chop($data);
$data = explode ("*", $data);
echo "
<tr>  <td bgcolor=$table_two width=20%>$font<b><a href=viewtopic.php?id=$x>$data[0]</a></td>
      <td bgcolor=$table_one width=20%>$font<center><b><a href=../profile.php?user=$data[1]>$data[1]</a></td>
      <td bgcolor=$table_two width=5%>$font<center><b>$data[2]</td>
      <td bgcolor=$table_one width=5%>$font<center><b>$data[3]</td>
      <td bgcolor=$table_two width=20%>$font<center><b>$data[4]</td>
</tr>";
 }



echo "
</table>
<center>
<br><Br><br>
<font face=$font_face size=$font_size color=$table_two>
<b>
�kcEnterprise<br>
2000-2002 All rights reserved</body>
</html>
"



 ?>