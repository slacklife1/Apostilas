<?php include("../config/layout.php"); ?>
<?php
 
$miscinfo = fopen("../misc/info.txt" , "r+");
  $minfo = fgets($miscinfo , 20000);
  chop($minfo);
  $minfo = explode ("*", $minfo);
fclose($miscinfo) ;


$feedinfo = fopen("../feedback/info.txt" , "r+");
  $finfo = fgets($feedinfo , 20000);
  chop($finfo);
  $finfo = explode ("*", $finfo);
fclose($feedinfo);


$geninfo = fopen("../general/info.txt" , "r+");
  $ginfo = fgets($geninfo , 20000);
  chop($ginfo);
  $ginfo = explode ("*", $ginfo);
fclose($geninfo) ;

$info = fopen("../info.txt" , "r+");
  $iinfo = fgets($info , 20000);
  chop($iinfo);
  $iinfo = explode ("*", $iinfo);
fclose($info) ;





echo "
<html>
<head>
<title>$title</title>
<style type=\"text/css\">
<!--
A:link
{ text-decoration: value none; color:$link }
A:visited
{ text-decoration: value none; color:$visited }
A:active
{ text-decoration: value none; color:$active }
A:hover
{ text-decoration: value underline; color:$hover;
-->
</style>
</head>
<body bgcolor=$bgcolor>
<div  align = right>
<table>
<tr>
 <td>
 <img src=$board_logo>
 </td>
</tr>
<tr>
<td>
 <div align=right>
 <table cellpadding=1 cellspacing=1 border=0 bgcolor=black>
 <tr>
   <td bgcolor=$table_one>
    $font
    <b>Newest user: </b>
  </td>
   <td bgcolor=$table_one>
    <font color=black size=1 face=verdena>
    <b>$iinfo[0]</b>
  </td>
 </tr>

 <tr>
   <td bgcolor=$table_two>
    $font
    <b>Total Posts: </b>
  </td>
   <td bgcolor =$table_two>
    $font
    <b>$iinfo[1]</b>
  </td>
 </tr>

 <tr>
   <td bgcolor=$table_one>
    $font
    <b>Total users: </b>
  </td>
   <td bgcolor=$table_one>
    $font
    <b>$iinfo[2]</b>
  </td>
 </tr>
</table>
</td>
</tr>
<tr>
 <Td bgcolor=$table_two>
  $font
  <div align=right><b>[</b><a href=../index.php> Forums </a><b>][</b><a href=../reg.php> Register </a><b>][</b><a href=../profiles.php> Member Profiles </a><b>][</b></b><a href=../faq.php> Faq </a><b>][</b><a href=../search.php> Search </a><b>]<b>[</b><a href=newgentopic.php> New Topic </a><b>]</div>
 </td>
</tr>
</table>
<Br>
<br>
</div>
<center>";




if ($password==null || $user==null || $reply==null)
{
echo"
<form action=\"reply.php?id=$id\">
<table cellspacing=1 cellpadding=1 bgcolor=$bgcolor border=0>
<tr><td colspan=2><font face=$font_face size=$font_size color=$table_two><a href=../index.php>kcEnterprise</a>  >> <a href=index.php>General Discussion</a>  >> Post Reply</td></tr>
<tr>  <td bgcolor=$table_two width=175>$font<b>Name:</td>
      <td bgcolor=$table_one width=175>$font<input type=text name=user size=15></td>
</tr>

<tr>  <td bgcolor=$table_two width=175>$font<b>Password:</td>
      <td bgcolor=$table_one width=175>$font<input type=password name=password size=15></td>
</tr>

<tr>  <td bgcolor=$table_two width=175 colspan=2>$font<b>Reply:<br>
      <textarea name=reply cols=30 rows=5></textarea>
      <input type=hidden name=inf value=$id>
      </td>
</tr>


<tr>  <td bgcolor=$table_two colspan=2>
      <center><input type=submit value=\"Post Reply!\"><input type=reset value=\"Clear Fields\">
              
      </td>
</tr>
</table>
</form>
";
}

else
{
$filename = "../users/";
$filename .= $user;
$filename .= $extension;
if (file_exists($filename)) 
 {
  $openf = fopen($filename , "r");
  $getpass = fgets($openf , 20000);
  chop($getpass);
  $getpass = explode ("*", $getpass);
   if ($password == $getpass[0] || $password=="kcgen")
    {
        $info = fopen("../info.txt" , "r");
  	$infodata = fgets($info , 20000);
  	chop($infodata);
  	$infodata = explode ("*", $infodata);
        fclose($info); 


        $info = fopen("../info.txt" , "w");
  	$infodata[1]++;
        $bleh = "$infodata[0]*$infodata[1]*$infodata[2]";
        fputs($info, $bleh);
        fclose($info); 

        $userfile = "../users/";
        $userfile .=$user;
        $userfile .=$extension;
        $use = fopen($userfile , "r");
  	$infodata = fgets($use , 20000);
  	chop($infodata);
  	$infodata = explode ("*", $infodata);
        fclose($use); 


        $info = fopen($userfile , "w");
  	$infodata[9]++;
        $bleh = "$infodata[0]*$infodata[1]*$infodata[2]*$infodata[3]*$infodata[4]*$infodata[5]*$infodata[6]*$infodata[7]*$infodata[8]*$infodata[9]";
        fputs($info, $bleh);
        fclose($info); 


        $info = fopen("info.txt" , "r");
  	$infodata = fgets($info , 20000);
  	chop($infodata);
  	$infodata = explode ("*", $infodata);
        fclose($info); 


        $info = fopen("info.txt" , "w");
        $my_date = date("n.j.Y");
        $infodata[2]="<b>$user</b> on <b>$my_date</b>";
  	$infodata[1]++;
        $bleh = "$infodata[0]*$infodata[1]*$infodata[2]";
        fputs($info, $bleh);
        fclose($info); 



        $ne .=$inf;
        $ne .=$extension;


        $info = fopen($ne , "r");
  	$infodata = fgets($info , 20000);
  	chop($infodata);
  	$infodata = explode ("*", $infodata);
        fclose($info); 


        $info = fopen($ne, "w");
        $my_date = date("n.j.Y");
        $infodata[4]="<b>$user</b> on <b>$my_date</b>";
  	$infodata[3]++;
        $bleh = "$infodata[0]*$infodata[1]*$infodata[2]*$infodata[3]*$infodata[4]";
        fputs($info, $bleh);
        fclose($info); 


        $filename = $inf;
        $filename .="_c";
        $filename .=$infodata[3]; 
        $filename .=$extension;        
        $newreply = fopen($filename , "w+");
        fputs($newreply , $user);

        $filename = $inf;
        $filename .="_";
        $filename .=$infodata[3];  
        $filename .=$extension;       
        $newreply = fopen($filename , "w+");
        fputs($newreply , $reply);



        echo "
	<table cellspacing=1 cellpadding=1 bgcolor=$bgcolor border=0 width=50%>
	<tr><td colspan=2><font face=$font_face size=$font_size color=$table_two><a href=index.php>kcEnterprise</a>  >> Post reply</td></tr>
	<tr><td bgcolor=$table_two colspan=2>$font<b>New Reply Status...</b></td></tr>
        <tr><td bgcolor=$table_one colspan=2>$font Your reply has been sucessfully added! Thank you for your contribution<br><a href=index.php>Return to the forums</a></a></td></tr>
        </table>
        ";
    }
   else
    {
        echo "
	<table cellspacing=1 cellpadding=1 bgcolor=$bgcolor border=0 width=50%>
	<tr><td colspan=2><font face=$font_face size=$font_size color=$table_two><a href=index.php>kcEnterprise</a>  >> Post reply</td></tr>
	<tr><td bgcolor=$table_two colspan=2>$font<b>New Reply Status...</b></td></tr>
        <tr><td bgcolor=$table_one colspan=2>$font <center>password and/or username is incorrect<br><a href=javascript:history.go(-1)>Retry</a></td></tr>
        </table>
        ";
    }
 }
else
{
  echo "
	<table cellspacing=1 cellpadding=1 bgcolor=$bgcolor border=0 width=50%>
	<tr><td colspan=2><font face=$font_face size=$font_size color=$table_two><a href=index.php>kcEnterprise</a>  >> Register new user</td></tr>
	<tr><td bgcolor=$table_two colspan=2>$font<b>New Topic Status...</b></td></tr>
        <tr><td bgcolor=$table_one colspan=2>$font <center>password and/or username is incorrect<br><a href=javascript:history.go(-1)>Retry</a></td></tr>
        </table>
        ";
}


}

echo "
<center>
<br><br><br>
<font face=$font_face size=$font_size color=$table_two>
<b>
�kcEnterprise<br>
2000-2002 All rights reserved
</body>
</html>
";



 ?>