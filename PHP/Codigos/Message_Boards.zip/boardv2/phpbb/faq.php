<?php include("config/layout.php"); ?>
<?php
 
$miscinfo = fopen("misc/info.txt" , "r+");
  $minfo = fgets($miscinfo , 20000);
  chop($minfo);
  $minfo = explode ("*", $minfo);
fclose($miscinfo);


$feedinfo = fopen("feedback/info.txt" , "r+");
  $finfo = fgets($feedinfo , 20000);
  chop($finfo);
  $finfo = explode ("*", $finfo);
fclose($feedinfo);

$geninfo = fopen("general/info.txt" , "r+");
  $ginfo = fgets($geninfo , 20000);
  chop($ginfo);
  $ginfo = explode ("*", $ginfo);
fclose($geninfo);

$info = fopen("info.txt" , "r+");
  $iinfo = fgets($info , 20000);
  chop($iinfo);
  $iinfo = explode ("*", $iinfo);
fclose($info);





echo "
<html>
<head>
<title>$title</title>
<style type=\"text/css\">
<!--
A:link
{ text-decoration: value none; color:$link }
A:visited
{ text-decoration: value none; color:$visited }
A:active
{ text-decoration: value none; color:$active }
A:hover
{ text-decoration: value underline; color:$hover;
-->
</style>
</head>
<body bgcolor=$bgcolor>
<div  align = right>
<table>
<tr>
 <td>
 <img src=$board_logo>
 </td>
</tr>
<tr>
<td>
 <div align=right>
 <table cellpadding=1 cellspacing=1 border=0 bgcolor=black>
 <tr>
   <td bgcolor=$table_one>
    $font
    <b>Newest user: </b>
  </td>
   <td bgcolor=$table_one>
    <font color=black size=1 face=verdena>
    <b>$iinfo[0]</b>
  </td>
 </tr>

 <tr>
   <td bgcolor=$table_two>
    $font
    <b>Total Posts: </b>
  </td>
   <td bgcolor =$table_two>
    $font
    <b>$iinfo[1]</b>
  </td>
 </tr>

 <tr>
   <td bgcolor=$table_one>
    $font
    <b>Total users: </b>
  </td>
   <td bgcolor=$table_one>
    $font
    <b>$iinfo[2]</b>
  </td>
 </tr>
</table>
</td>
</tr>
<tr>
 <Td bgcolor=$table_two>
  $font
  <div align=right><b>[</b><a href=index.php> Forums </a><b>][</b><a href=reg.php> Register </a><b>][</b><a href=profiles.php> Member Profiles </a><b>][</b></b><a href=faq.php> Faq </a><b>][</b><a href=search.php> Search </a><b>]</div>
 </td>
</tr>
</table>
<Br>
<br>
</div>
<center>
<table cellspacing=1 cellpadding=1 bgcolor=$bgcolor border=0 width=50%>
<tr>
 <Td>
 <font face=$font_face size=$font_size color=$table_two>
 <a href=index.php>$board_name</a> >> Faq
 </td>
</tr>

<tr>
 <td><Br><Br>
 <font face=$font_face size=$font_size color=$table_two>
 <b>Q.) Is registration free?</b><Br>
 <blockquote>Yes! registration is free! All that we ask is that you post. Maybe not on a regular basis but enough to make your presence felt!</blockquote>
 <Td>
 </td>
</tr>

<tr>
 <td><Br><Br>
 <font face=$font_face size=$font_size color=$table_two>
 <b>Q.) How secure is this board?</b><Br>
 <blockquote>This board is just for kicks and giggles. Now secure, It has not been thouroghly(sp) tested, but the testing that has been done, it's fairly secure. Noone will know your password except the Administrator. That is unless they \"<i>figure</i>\" out how this works by foul play. So try not to make your password something you use for everything. Make it original yet diffrent ;)</blockquote>
 <Td>
 </td>
</tr>

<tr>
 <td><Br><Br>
 <font face=$font_face size=$font_size color=$table_two>
 <b>Q.) Will people see my user profile?</b><Br>
 <blockquote>Yes! That is what this board is for. Meet new people that share intrest that you do! View, email or chat with fellow members!</blockquote>
 <Td>
 </td>
</tr>

<tr>
 <td><Br><Br>
 <font face=$font_face size=$font_size color=$table_two>
 <b>*NOTE* </b><Br>
 <blockquote>This board is meant for having fun, relaxing and venting, meeting other people. The administration is in no way possible for the members actions. Try to have fun and play by the rules and everything will be just peachy ^_^ </blockquote>
 <Td>
 </td>
</tr>


</table>
<center>
<br><br><br>
<font face=$font_face size=$font_size color=$table_two>
<b>
�kcEnterprise<br>
2000-2002 All rights reserved
</body>
</html>
";



 ?>