********************************************
*PHPmyPagers 1.0 - Collection of PHP Pagers*
*					   *
*    Price:Free(GPL)    Date:12.4.2001     *
********************************************

This package contains the following files:

index.php			>the main file
pager.php			>the file for paging
options.inc.php			>a file all the options
master.cc			>the stylesheet file
/language/english.inc.php	>the english language file
/language/german.inc.php	>the german language file
README.txt			>this file


*********INSTALL*********

Edit the options.inc.php

<If needed, translate one of the language files to yout language>
<So if you do so, could you please mail this file to me <marc@giombetti.com>
<Thx's>

Edit the master.css file if needed


Upload all the files to one directory!

CHMOD pager.php to 777


enjoy!

If there are Problems using this script, check out the forums on www.giombetti.com/?cat=PHP
mail me marc@giombetti.com and RTFM.



Marc Giombetti

