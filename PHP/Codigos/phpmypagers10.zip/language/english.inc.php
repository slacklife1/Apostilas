<?
/*
PHPmyPagers 1.0 - Collection of PHP Pager Scripts
Author: Marc Giombetti <marc@giombetti.com> <www.giombetti.com/?cat=PHP>
Date: 12.04.2001  Price: Free (GPL)
*/
/*if you translate this language file into your language - please mail it to marc@giombetti.com - Thx's */
//english language file

$message = "Message:";
$yourname = "Your Name:";

if($id == "SMS"){$shownumber = "Phone Number";}
if($id == "ICQ"){$shownumber = "ICQ Number";}
if($id == "Skyper"){$shownumber = "Skyper Number";}

if($id == "SMS"){$sendok = "The SMS was send successfully";}
if($id == "ICQ"){$sendok = "The ICQ-Message was send successfully";}
if($id == "Skyper"){$sendok = "The Skyper was contacted successfully";}

if($id == "SMS"){$another = "Send another SMS";}
if($id == "ICQ"){$another = "Send another ICQ Message";}
if($id == "Skyper"){$another = "Send another Skyper Message";}

$allowed1 = "You are allowed to write";
$allowed2 = "more chars";

//errors
if($id == "SMS"){$error = "SMS could not be send! Please check all the fields";}
if($id == "ICQ"){$error = "ICQ Message Could not be send! Please check all the fields";}
if($id == "Skyper"){$error = "Skyper Message could not be send! Please check all the fields";}

//
$back = "Back";

?>