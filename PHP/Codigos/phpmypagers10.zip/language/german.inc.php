<?
/*
PHPmyPagers 1.0 - Collection of PHP Pager Scripts
Author: Marc Giombetti <marc@giombetti.com> <www.giombetti.com/?cat=PHP>
Date: 12.04.2001  Price: Free (GPL)
*/

/*wenn Sie diese Sprach Datei in Ihre Sprache �bersetzen, bitte mailen Sie sie dann an
marc@giombetti.com - Danke im Voraus */

//german language file
$message = "Nachricht:";
$yourname = "Ihr Name:";

if($id == "SMS"){$shownumber = "Nummer:";}
if($id == "ICQ"){$shownumber = "ICQ Nummer:";}
if($id == "Skyper"){$shownumber = "Skyper Nummer:";}

if($id == "SMS"){$sendok = "Die SMS wurde erfolgreich versandt";}
if($id == "ICQ"){$sendok = "Die ICQ Nachricht wurde erfolgreich versandt";}
if($id == "Skyper"){$sendok = "Die Skyper Nachricht wurde erfolgreich versandt";}

if($id == "SMS"){$another = "Wollen Sie eine weitere SMS verschicken?";}
if($id == "ICQ"){$another = "Wollen Sie eine weitere ICQ Nachricht verschicken?";}
if($id == "Skyper"){$another = "Wollen Sie eine weitere Skyper Nachricht verschicken";}

$allowed1 = "Sie k�nnen noch";
$allowed2 = "Zeichen schreiben";

//errors
if($id == "SMS"){$error = "Die SMS konnte nicht versandt werden! Bitte �berpr�fen Sie alle Felder";}
if($id == "ICQ"){$error = "Die ICQ Nachricht konnte nicht versandt werden! Bitte �berpr�fen Sie alle Felder";}
if($id == "Skyper"){$error = "Die Skyper Nachricht konnte nicht versandt werden! Bitte �berpr�fen Sie alle Felder";}

//
$back = "Zur�ck";

?>