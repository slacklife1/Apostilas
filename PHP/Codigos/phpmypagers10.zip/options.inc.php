<?
/*
PHPmyPagers 1.0 - Collection of PHP Pager Scripts
Author: Marc Giombetti <marc@giombetti.com> <www.giombetti.com/?cat=PHP>
Date: 12.04.2001  Price: Free (GPL)
*/

//chose your language
//options - english - german
//for the include include("language/xxxxx.inc.php");
$language = "english";

//color definitions
$bgcolor = "#cc9966";
$text = "#333333";
$link = "#333333";
$vlink = "#333333";
$alink = "#333333";

//css files
$cssfile = "master.css";

//table background
$tback = "#cccccc";

//select kind of pager (SMS - ICQ - Skyper)
//$id = "SMS";
$id = "ICQ";
//$id = "Skyper";

$maxchars = "350";

//ass example - if the syntax of the paging service of your service provider is
//number.mail@sms.tango.lu put only .mail@sms.tango.lu 


$pagerservice = "@pager.icq.com";
//$pagerservice = ".mail@sms.tango.lu";

/*do not change anything above this line */
include("language/$language.inc.php");


?>