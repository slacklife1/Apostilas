<?php
/*
PHPmyPagers 1.0 - Collection of PHP Pager Scripts
Author: Marc Giombetti <marc@giombetti.com> <www.giombetti.com/?cat=PHP>
Date: 12.04.2001  Price: Free (GPL)
*/
include("options.inc.php");

?>
<html> 
<head> 
<link rel="stylesheet" href="master.css" type="text/css">
<title><?php echo"$id Pager"; ?></title></head>
<?
echo "<body bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">";


if($mes && $name && $number) { 
mail("$number$pagerservice","From $name","$mes","From: $name@noreply.giombetti.com\nReply-To:noreply@giombetti.com\nX-Mailer: PHP/" . phpversion());
?>
<center>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="50">&nbsp;</td>
    <td width="415" height="50"> 
      <table width="415" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td bgcolor="#000000" width="1" height="1"></td>
          <td bgcolor="#000000" height="1"></td>
          <td bgcolor="#000000" width="1" height="1"></td>
        </tr>
        <tr> 
          <td bgcolor="#000000" ></td>
          <td width="415" height ="19" class="bignewgray" bgcolor="<?php echo"$tback"; ?>"> 
            <table width="409" border="0" cellspacing="2" cellpadding="0" align="center">
              <tr> 
                <td height="53"><b> <br>
                  <center><p><? echo"$sendok"; ?></p>
                  <br>
				<a href="javascript:history.back(-1)" class="bignewgray"><? echo "$another"; ?></b></center></a>
	      </tr>
            </table>
          </td>
          <td bgcolor="#000000"></td>
        </tr>
        <tr> 
          <td bgcolor="#000000" width="1" height="1"></td>
          <td bgcolor="#000000" height="1"></td>
          <td bgcolor="#000000" width="1" height="1"></td>
        </tr>
      </table>
    </td>
    <td height="50">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<?php

} else { ?>
<center>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="50">&nbsp;</td>
    <td width="415" height="50"> 
      <table width="415" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td bgcolor="#000000" width="1" height="1"></td>
          <td bgcolor="#000000" height="1"></td>
          <td bgcolor="#000000" width="1" height="1"></td>
        </tr>
        <tr> 
          <td bgcolor="#000000" ></td>
          <td width="415" height ="19" class="bignewgray" bgcolor="<?php echo"$tback"; ?>"> 
            <table width="409" border="0" cellspacing="2" cellpadding="0" align="center">
              <tr> 
                <td height="53"><b> <br>
                  <center><?php echo"$error"; ?><br><br><a href="javascript:history.back(-1)" class="bignewgray"><?php echo"$back"; ?></a></b>
	      </tr>
            </table>
          </td>
          <td bgcolor="#000000"></td>
        </tr>
        <tr> 
          <td bgcolor="#000000" width="1" height="1"></td>
          <td bgcolor="#000000" height="1"></td>
          <td bgcolor="#000000" width="1" height="1"></td>
        </tr>
      </table>
    </td>
    <td height="50">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<?php
}
//thank you for don't leaving this comment
echo "<br><br><center><span class=\"copyright\"><a href=\"http://www.giombetti.com/?cat=PHP\" class=\"copyright\"> PHPmyPagers - Get your copy at www.giombetti.com</span>
</center>"
//thx's
?>
</body>
</html> 