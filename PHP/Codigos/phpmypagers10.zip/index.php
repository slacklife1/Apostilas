<?
/*
PHPmyPagers 1.0 - Collection of PHP Pager Scripts
Author: Marc Giombetti <marc@giombetti.com> <www.giombetti.com/?cat=PHP>
Date: 12.04.2001  Price: Free (GPL)
*/
include("options.inc.php");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<!-- Designed by Marc Giombetti -->
<script LANGUAGE="JavaScript">
<!--

var running = false
var endTime = null
var timerID = null

var width = 130;
var pos = 1 - width;

function startTimer() {
        running = true
        now = new Date()
        now = now.getTime()
        endTime = now + (1000 * 0.1 * 1)
        ShowCountDown()
        }

function ShowCountDown() {
        var now = new Date()
        now = now.getTime()
        if(endTime - now <=0) {
            if (navigator.appName == 'Netscape') {
                document.forms[0].num.focus()
                document.forms[0].mes.focus()
               }
                bav(document.forms[0].mes.value)
                }
        else {
                var delta = new Date(endTime-now)
                var theMin = delta.getMinutes()
                var theSec = delta.getSeconds()
                var theTime = theMin
                theTime += ((theSec <10) ? ":0" : ":") + theSec
                if(running) {
                        timerID = setTimeout("ShowCountDown()",1000)
                        }
                }
        }

function stopTimer() {
        clearTimeout(timerID)
        running = false
        }


function bav(inputStr) {
        strlength=inputStr.length
        if (strlength ><?php echo"$maxchars"; ?>)     {
                document.forms[0].mes.value=inputStr.substring(0,<?php echo"$maxchars"; ?>)
                charleft=0
                }
        else    {
                charleft=<?php echo"$maxchars"; ?>-strlength}
        document.forms[0].num.value=charleft
        startTimer()
        }

function bavform(form) {
        inputStr = form.mes.value
        strlength = inputStr.length
        if (strlength > <?php echo"$maxchars"; ?> ) {
                form.mes.value=inputStr.substring(0,<?php echo"$maxchars"; ?>)
                charleft=0
                }
        else    {
                charleft=<?php echo"$maxchars"; ?>-strlength}
        form.num.value=charleft
        stopTimer()
        }
        


//-->
</script>

<title><?php echo"$id Pager";?></title>
<link rel="stylesheet" href="master.css" type="text/css">
</head>
<?
echo "<body bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">";

?>

<form method="POST" action="pager.php">

 <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="50">&nbsp;</td>
    <td width="415" height="50"> 
      <table width="415" border="0" cellspacing="0" cellpadding="0">
        <tr><p align="center"><span class="header"><? echo"<center>\{$id Pager}</center>"; ?></span><br>
          <td bgcolor="#000000" width="1" height="1"></td>
          <td bgcolor="#000000" height="1"></td>
          <td bgcolor="#000000" width="1" height="1"></td>
        </tr>
        <tr> 
          <td bgcolor="#000000" ></td>
          <td width="415" height ="19" class="bignewgray" bgcolor="<?php echo"$tback"; ?>"> 


            <table width="409" border="0" cellspacing="2" cellpadding="0" align="center">
              <tr> 
                <td height="53"> <div align="center">
    <table border="0" width="485">
      <tr> 
        <td width="120" align="right"> 
          <div align="left"><font size="3"><span class="bignewgray">
            <? echo"$shownumber"; ?>
            </span></font></div>
        </td>
        <td width="355" align="left" valign="top"> 
                            <input type="text" name="number" size="25">
        </td>
      </tr>
      <tr> 
        <td width="120" align="right" valign="top"> 
          <div align="left"><span class="bignewgray"><? echo"$mes"; ?></span><br>
          </div>
        </td>
        <td width="355" align="left" valign="top"><strong> 
          <!--webbot bot="Validation" B-Value-Required="TRUE" -->
                            <textarea WARP="VIRTUAL" rows="4" name="mes" cols="38" onFocus="bav(this.value)" onChange="bavform(this.form)"
      onBlur="bavform(this.form)"></textarea>
          </strong></td>
      </tr>
      <tr> 
        <td width="120" align="right"> 
          <div align="left"></div>
        </td>
        <td width="355" align="left" valign="top"> </td>
      </tr>
      <tr> 
        <td width="120" align="right" height="27"> 
          <div align="left"><font size="3"><span class="bignewgray"> 
            <? echo"$yourname"; ?>
            </span></font></div>
        </td>
        <td width="355" align="left" valign="top" height="27"> 
          <!--webbot bot="Validation" B-Value-Required="TRUE" -->
                            <input type="text" name="name" size="25">
        </td>
      </tr>
      <tr> 
        <td width="120" align="right"></td>
        <td width="355" align="left" valign="top"> </td>
      </tr>
      <tr> 
        <td width="120" align="right"></td>
        <td width="355" align="left" valign="top"> <font size="3"><span class="bignewgray"> 
          <? echo"$allowed1"; ?>
          </span></font> <span class="bignewgray"> 
          <input TYPE="text" SIZE="3" name="num" value="<?php echo"$maxchars"; ?>"
      onChange="bavform(this.form)">
          <font size="3" class="bignewgray"> </font><font size="3"><span class="bignewgray">
          <? echo"$allowed2"; ?>
          </span></font></span></td>
      </tr>
      <tr> 
        <td width="120" align="right"></td>
        <td width="355" align="left" valign="top"> </td>
      </tr>
      <tr> 
        <td width="120" align="right"> 
          <div align="right"></div>
        </td>
        <td width="355" align="left" valign="top"> 
          <table border="0" width="100%">
            <tr> 
              <td width="7%">&nbsp;</td>
              <td width="93%"> 
                <input type="submit" value="Senden" name="sendmes">
                <img src="../../1pix.gif" width="7" height="1"> 
                <input

      type="reset" value="L�schen" name="B2">
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </div>
	      </tr>
            </table>
          </td>
          <td bgcolor="#000000"></td>
        </tr>
        <tr> 
          <td bgcolor="#000000" width="1" height="1"></td>
          <td bgcolor="#000000" height="1"></td>
          <td bgcolor="#000000" width="1" height="1"></td>
        </tr>
      </table>
    </td>
    <td height="50">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
  </form>
<div align="center">
</div>
<?php
//thank you for don't leaving this comment
echo "<br><br><center><span class=\"copyright\"><a href=\"http://www.giombetti.com/?cat=PHP\" class=\"copyright\"> PHPmyPagers - Get your copy at www.giombetti.com</span>
</center>"
//thx's
?>
</body>

</html>
