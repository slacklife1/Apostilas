Title: Virtual Places Gesture Decompiler/Manager
Description: There are several gesture makers for the Virtual places chat client at talk.excite.com but nothing for them when it comes to scripts. A gesture is an animated graphic, with music, or a sound file, and a line of text, or tag that shows in the chat room. This script completely decompiles these gestures, and returns the Animation, the button picture, the sound file, the gesture tag, and the option to download the gesture. As far as managment, this script allows users to Upload their personal gestures, or any other gesture they would like to share.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=280&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
