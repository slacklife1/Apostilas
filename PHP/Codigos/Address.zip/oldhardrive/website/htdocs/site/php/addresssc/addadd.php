<HTML>

<HEAD>
  <TITLE>Add your address</TITLE>
  <META name="description" content="">
  <META name="keywords" content="">
  <META name="revisit-after" content="7days">
  <META name="robots" content="index, follow"> 

</HEAD>

<BODY BGCOLOR="FFFFFF" TEXT="000000" LINK="0000FF" VLINK="0000FF">

      <p><b>Add your address</b><BR>
        <BR>
	Just type in your address, phone numbers, and other info.
        <BR>
      </p>
      <p>Fill this out.</p>
      <form action = "added.php" method ="post">
	  Full Name : <input type = "text" name = "name" SIZE="45"><br>
	  street : <input type= "text" size="50" NAME = "street"><br>
	  city: <input type = "text" name = "city" SIZE="25"><br>
	  state: <input type= "text" size="4" NAME = "state"><br>
	  zip code : <input type = "text" name = "zipcode" SIZE="20"><br>
	  home phone: <input type= "text" size="15" NAME = "hphone"><br>
	  cell phone: <input type = "text" name = "cphone" SIZE="15"><br>
	  e-mail: <input type= "text" size="50" NAME = "email"><br>
	  other info: <TEXTAREA ROWS="5" COLS="60" NAME = "other"></TEXTAREA><BR><BR>
	  User Name: <input type = "text" name = "user" SIZE="45"><br>
	  Password: <input type = "password" name = "passw" SIZE="45"><br>
	  <BR>
	  <input type = "submit" value = "submit info">
	  </form>
      <p>&nbsp;</p>
      <p><BR>
	<a href="addview.html">Click here</a> to see the addresses currently listed.
      </p>


<BR>
<CENTER>
<FONT SIZE=1> http://www.bandddesigns.com</FONT></cENTER>
</BODY>
</HTML> 

