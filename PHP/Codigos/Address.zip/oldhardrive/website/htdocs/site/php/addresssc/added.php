<HTML>

<HEAD>
  <TITLE>Thanks for adding your link</TITLE>
  <META name="description" content="">
  <META name="keywords" content="">
  <META name="revisit-after" content="7days">
  <META name="robots" content="index, follow"> 

</HEAD>

<BODY BGCOLOR="FFFFFF" TEXT="000000" LINK="0000FF" VLINK="0000FF">


      <BR>
      <BR>
     <?php
	 //open our file
	 $fp = fopen("addresses.txt" , "a+");
	 //add details from form
	 fputs($fp ,"<P align= \"Center\"><b>Full Name: $name <BR>
	  address: <BR><BR> $name <BR> $street<br>$city , $state  $zipcode <br><BR>
	  home phone: $hphone <br>
	  cell phone: $cphone <br>
	  e-mail: $email <br>
	  other info: $other <BR>
          <BR><BR></P>");
	  //close file
	 fclose($fp); 

	//password file
	$ft = fopen("user.txt" , "a+");
	$password = md5("$passw"); # let salt be generated
	fputs($ft, " :$user,$password;");
	fclose($ft);


	 //display message and link
	 echo ("Thanks for adding your adress. It was successfully submitted. ");
	 echo ("<a href='addview.html'>View all of the addresses</a>");
	 ?>
	 
      <BR>
      <BR>




<CENTER>
<FONT SIZE=1>
http://www.bandddesigns.com</FONT></cENTER>
</BODY>
</HTML> 

