<HTML>
<HEAD>
<TITLE>Viewing address the book.</TITLE>
</HEAD>
<body>
<P>Fill in your  user name and password.
 <form action = "showadd2.php" Target="bottom" method ="post">
	  User Name: <input type = "text" name = "user" SIZE="20"><BR>
	  Pass Word: <input type = "password" name = "pw" SIZE="20"><BR>
	  <input type = "submit" value = "submit">
	  </form>
</p>

</body>
<HTML>