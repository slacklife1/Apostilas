<HTML>
<HEAD>
<TITLE>Viewing address the book.</TITLE>
</HEAD>
<body>
<p align="center">
<?php

	 $str="";
	 $user2="";
	 $waste="";
	 $endname=0;
	 $num2=0;
	 $length=0;
	 $ct=0;
	 $ct2=0;
	 $fur=0;
	 $ct4=0;
	 $first=0;
	 
	 $fp = fopen("user.txt" , "r"); //read file length
	 do{
	 $length++;
	 $waste=fgetc($fp);
	 } while (feof($fp)!=TRUE);
         fclose($fp); 

	do{ //outer loop to find name
	 $ct4=0;
	 $fp = fopen("user.txt" , "r");//read to furthest point in file
	 do{ 
	 if($ct4<$length)
	   $waste=fgetc($fp);
	 $ct4++;
	 } while ($ct4<$fur && $ct4<$length); //read as far as ct3 saves

	 //find start of user name
         $ct=$ct4; //add length so far
	 do{
	 $ct++;
	 $fur++;
	 } while (fgetc($fp)!=":" && $fur<=$length);
//41	 
	 //find end of user name
	 do{
	 $endname++;
	 $fur++;
	 } while (fgetc($fp)!="," && $fur<=$length);
	 $ct4=$fur; //store end of user name from beging of file
	 //close file
	 fclose($fp);  

         if($fur<$length)
{
	 $fp = fopen("user.txt" , "r");
	 //grab user name
         do{  //go to begining of name
	   $waste=fgetc($fp);
	 $ct--;
	 } while ($ct);
 	 
	 $user2="";
	 if($first!=0)//fix for multi loops
  	   $endname--;

	 do{ //store name until end of name
	 $endname--;
	 $user2= $user2 . fgetc($fp);	 
	 } while ($endname>1);
	 //close file
	 fclose($fp);
}
	$first++;
	} while(($user2!=$user)&&($length>$fur)); //user2 not it and total < length
	
//compare passwords
	if($user2==$user)
{
	echo("User Name: $user2 , ");
	$fp = fopen("user.txt" , "r");
	$fur=0;
	$ct2=0;
	do{
	  $fur++;
	  $waste=fgetc($fp);
	  } while($ct4!=$fur);
	
        do{ //find the end of the password
	$ct2++;
	} while(fgetc($fp)!=";");
	fclose($fp);	

	$fp = fopen("user.txt" , "r"); //should know how far till password
	$fur=0;

	if($first>1) //fix for multiloops
         $fur++;

	do{
	$fur++;
	$waste=fgetc($fp);
	} while($ct4>=$fur);//get to begining of password

	$str="";
//90
	if($first>1)//fix for multiloops
	 $ct2++;

	do{  //read and store pass till end
	$str=$str . fgetc($fp);
	$ct2--;
	} while($ct2>2);
}
else
{
echo("invalid user name , ");
}

if (md5("$pw")==$str){

echo ("Password Valid <BR>");

echo ("<hr>");
include  ("addresses.txt");
echo ("</hr>");

} else{
echo ("Incorrect password try again.");
}

echo ("<p align=\"center\"><BR><BR><a href='http://www.bandddesigns.com'>back to Bandd Designs main page.</a></p>");
?>
</p>
</body>
<HTML>