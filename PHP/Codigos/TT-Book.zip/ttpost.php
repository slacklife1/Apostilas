<?php include("ttbook.conf"); ?>

<html>
<head>
<title><?php print $title; ?>: TT-Book Guestook</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="<?php print $bgimage; ?>" bgcolor="<?php print $bgcolor; ?>" text="<?php print $textcolor; ?>" link="<?php print $linkcolor; ?>" alink="<?php print $alinkcolor; ?>" vlink="<?php print $vlinkcolor; ?>">
<div align="center">

<?php

if (!$HTTP_POST_VARS['name'] || !$HTTP_POST_VARS['message']) {
	print "You need to enter a name and message to post in this guestbook.<br><br>\n";
	}
else {
	$datetime=date("D, j/M Y g:ia",time());

	$entriesfile="../" . $flatfiledir . "entries.dat";
	@$entries=file($entriesfile);

	$last="1";

	if ($entries[0]) {
		foreach ($entries as $entr) {
			$entry= preg_split('/\|<>\|/', $entr);
			$last=($entry[0]);
			}
		}

	if (strlen ($last) == 1) {
		$last="000" . $last;
		}
	if (strlen ($last) == 2) {
		$last="00" . $last;
		}
	if (strlen ($last) == 3) {
		$last="0" . $last;
		}

	$HTTP_POST_VARS['message'] = str_replace("\\\"","\"",$HTTP_POST_VARS['message']);
	$HTTP_POST_VARS['message'] = str_replace("\'","'",$HTTP_POST_VARS['message']);
	$HTTP_POST_VARS['message'] = str_replace("\\\\","\\",$HTTP_POST_VARS['message']);
	$HTTP_POST_VARS['message'] = str_replace("\n","<br>",$HTTP_POST_VARS['message']);
	$HTTP_POST_VARS['message'] = str_replace("\r","",$HTTP_POST_VARS['message']);
	$HTTP_POST_VARS['message'] = str_replace("\\\|","\|",$HTTP_POST_VARS['message']);

	$HTTP_POST_VARS['name'] = str_replace("\\\"","\"",$HTTP_POST_VARS['name']);
	$HTTP_POST_VARS['name'] = str_replace("\'","'",$HTTP_POST_VARS['name']);
	$HTTP_POST_VARS['name'] = str_replace("\\\\","\\",$HTTP_POST_VARS['name']);
	$HTTP_POST_VARS['name'] = str_replace("\\\|","\|",$HTTP_POST_VARS['name']);

	$HTTP_POST_VARS['mail'] = str_replace("\\\"","\"",$HTTP_POST_VARS['mail']);
	$HTTP_POST_VARS['mail'] = str_replace("\'","'",$HTTP_POST_VARS['mail']);
	$HTTP_POST_VARS['mail'] = str_replace("\\\\","\\",$HTTP_POST_VARS['mail']);
	$HTTP_POST_VARS['mail'] = str_replace("\\\|","\|",$HTTP_POST_VARS['mail']);

	$HTTP_POST_VARS['url'] = str_replace("\\\"","\"",$HTTP_POST_VARS['url']);
	$HTTP_POST_VARS['url'] = str_replace("\'","'",$HTTP_POST_VARS['url']);
	$HTTP_POST_VARS['url'] = str_replace("\\\\","\\",$HTTP_POST_VARS['url']);
	$HTTP_POST_VARS['url'] = str_replace("\\\|","\|",$HTTP_POST_VARS['url']);

	$HTTP_POST_VARS['subject'] = str_replace("\\\"","\"",$HTTP_POST_VARS['subject']);
	$HTTP_POST_VARS['subject'] = str_replace("\'","'",$HTTP_POST_VARS['subject']);
	$HTTP_POST_VARS['subject'] = str_replace("\\\\","\\",$HTTP_POST_VARS['subject']);
	$HTTP_POST_VARS['subject'] = str_replace("\\\|","\|",$HTTP_POST_VARS['subject']);

	$addentryinfo=$last . "|<>|" . $HTTP_POST_VARS['name'] . "|<>|" . $HTTP_POST_VARS['mail'] . "|<>|" . $HTTP_POST_VARS['url'] . "|<>|" . $HTTP_POST_VARS['subject'] . "|<>|" . $HTTP_POST_VARS['message'] . "|<>|" . $datetime . "|<>|" . $HTTP_SERVER_VARS['REMOTE_ADDR'] . "\n";
	$addentriesfile="../" . $flatfiledir . "entries.dat";

	@$addentry1 = file($addentriesfile);
	$addentry = fopen($addentriesfile,"w+");

	if ($entries[0]) {
		foreach ($entries as $entry) {
			fwrite($addentry, "$entry");
			}
		}

	fwrite($addentry, "$addentryinfo");

	fclose($addentry);
	
	print "<font size=\"4\">Your Guestbook Entry has been Added.</font><br><br>\n";
	}
?>

  <a href="<?php print $siteurl; ?>">Back to <?php print $title; ?></a><br>
  <a href="<?php print $siteurl . $ttbookdir . "ttview.php"; ?>">View Guestbook Entries</a><br><br>
  <font size="1">TT-Book Guestbook by <a href="http://www.twintopsoft.f2s.com/">Twintop Soft</a></font>
</div>
</body>
</html>