<?php include("ttbook.conf"); ?>

<html>
<head>
<title><?php print $title; ?>: TT-Book Guestook Controls</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="<?php print $bgimage; ?>" bgcolor="<?php print $bgcolor; ?>" text="<?php print $textcolor; ?>" link="<?php print $linkcolor; ?>" alink="<?php print $alinkcolor; ?>" vlink="<?php print $vlinkcolor; ?>">
<div align="center">
  <font size="4"><?php print $title; ?>: TT-Book Guestook Controls</font>
  <br>

<?php
if ($HTTP_GET_VARS['u'] != $username || $HTTP_GET_VARS['p'] != $password) {
	print "<table border=\"0\">\n";
	print "<form method=\"get\" action=\"" . $siteurl . $ttbookdir . "ttcontrol.php\">\n";
	print "<tr>\n";
	print "<td><b>Username</b></td>\n";
	print "<td><input type=\"text\" name=\"u\"></td>\n";
	print "</tr>\n";
	print "<tr>\n";
	print "<td><b>Password</b></td>\n";
	print "<td><input type=\"password\" name=\"p\"></td>\n";
	print "</tr>\n";
	print "<tr>\n";
	print "<td></td>\n";
	print "<td><input type=\"submit\" value=\"Login\"></td>\n";
	print "</tr>\n";
	print "</form>\n";
	print "</table>\n";

	print "  <a href=\"" . $siteurl . "\">Back to " . $title . "</a><br>\n";
	print "  <font size=\"1\">TT-Book Guestbook by <a href=\"http://www.twintopsoft.f2s.com/\">Twintop Soft</a></font>\n";
	print "</div>\n";
	print "</body>\n";
	print "</html>\n";
	
	exit();
	}	
?>	

<table width="100%" border="1">
  <tr> 
    <td> 
      <div align="center"><b>Delete?</b></div>
    </td>
    <td> 
      <div align="center"><b>#</b></div>
    </td>
    <td> 
      <div align="center"><b>Name</b></div>
    </td>
    <td> 
      <div align="center"><b>E-mail</b></div>
    </td>
    <td> 
      <div align="center"><b>URL</b></div>
    </td>
    <td> 
      <div align="center"><b>Subject</b></div>
    </td>
    <td> 
      <div align="center"><b>Message</b></div>
    </td>
    <td> 
      <div align="center"><b>Date</b></div>
    </td>
    <td> 
      <div align="center"><b>IP</b></div>
    </td>
  </tr>

<?php

if ($HTTP_GET_VARS['delete']) {
	$messageinfofile="../" . $flatfiledir . "entries.dat";
	$removemessage = file($messageinfofile);
	$removemessageto = fopen($messageinfofile,"w+");
	
	foreach ($removemessage as $message) {
		$message = str_replace("\n","",$message);
	
		$about= preg_split('/\|<>\|/', $message);
		
		if ($about[0] != $HTTP_GET_VARS['delete']) {
			fwrite($removemessageto, "$message\n");
			}
		}
	fclose($removemessageto);
	}

$entriesfile="../" . $flatfiledir . "entries.dat";
@$entries=file($entriesfile);

foreach ($entries as $entr) {
	if ($entr) {
		$entry= preg_split('/\|<>\|/', $entr);

		print "  <tr> \n";
		print "  <form method=\"post\" action=\"" . $siteurl . $ttbookdir . "ttcontrol.php?delete=" . $entry[0] . "&u=" . $username . "&p=" . $password . "\">\n";
		print "    <td> \n";
		print "      <input type=\"submit\" value=\"Delete Entry\">\n";
		print "    </td>\n";
		print "  </form>\n";
		print "    <td> \n";
		print "      <div align=\"center\">" . $entry[0] . "</div>\n";
		print "    </td>\n";
		print "    <td> \n";
		print "      <div align=\"center\">" . $entry[1] . "</div>\n";
		print "    </td>\n";
		print "    <td> \n";
		print "      <div align=\"center\">" . $entry[2] . "</div>\n";
		print "    </td>\n";
		print "    <td> \n";
		print "      <div align=\"center\">" . $entry[3] . "</div>\n";
		print "    </td>\n";
		print "    <td> \n";
		print "      <div align=\"center\">" . $entry[4] . "</div>\n";
		print "    </td>\n";
		print "    <td> \n";
		print "      <div align=\"center\">" . $entry[5] . "</div>\n";
		print "    </td>\n";
		print "    <td> \n";
		print "      <div align=\"center\">" . $entry[6] . "</div>\n";
		print "    </td>\n";
		print "    <td> \n";
		print "      <div align=\"center\">" . $entry[7] . "</div>\n";
		print "    </td>\n";
		print "  </tr>\n";
		}
	}
?>

  <tr> 
    <td> 
      <div align="center"><b>Delete?</b></div>
    </td>
    <td> 
      <div align="center"><b>#</b></div>
    </td>
    <td> 
      <div align="center"><b>Name</b></div>
    </td>
    <td> 
      <div align="center"><b>E-mail</b></div>
    </td>
    <td> 
      <div align="center"><b>URL</b></div>
    </td>
    <td> 
      <div align="center"><b>Subject</b></div>
    </td>
    <td> 
      <div align="center"><b>Message</b></div>
    </td>
    <td> 
      <div align="center"><b>Date</b></div>
    </td>
    <td> 
      <div align="center"><b>IP</b></div>
    </td>
  </tr>
  </table>
  
  <a href="<?php print $siteurl; ?>">Back to <?php print $title; ?></a><br>
  <a href="<?php print $siteurl . $ttbookdir . "ttview.php"; ?>">View Guestbook Entries</a><br><br>
  <font size="1">TT-Book Guestbook by <a href="http://www.twintopsoft.f2s.com/">Twintop Soft</a></font>
</div>
</body>
</html>