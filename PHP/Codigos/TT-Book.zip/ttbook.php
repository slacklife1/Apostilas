<?php include("ttbook.conf"); ?>

<html>
<head>
<title><?php print $title; ?>: TT-Book Guestook</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="<?php print $bgimage; ?>" bgcolor="<?php print $bgcolor; ?>" text="<?php print $textcolor; ?>" link="<?php print $linkcolor; ?>" alink="<?php print $alinkcolor; ?>" vlink="<?php print $vlinkcolor; ?>">
<div align="center">
  <font size="4"><?php print $title; ?>: TT-Book Guestook</font>
  <br>
  <table width="400" border="1">
    <form method="post" action="<?php print $siteurl . $ttbookdir; ?>/ttpost.php">
    <tr> 
      <td width="110" valign="top" align="left"><b>Your Name</b></td>
      <td width="290"> 
        <input type="text" name="name" size="20" <?php if ($anon) { print "value=\"Anonymous\""; } ?>>
      </td>
    </tr>
    <tr> 
      <td width="110" valign="top" align="left"><b>Your E-mail</b></td>
      <td width="290"> 
        <input type="text" name="mail" size="20">
      </td>
    </tr>

<?php
if ($showweb) {
	print "    <tr> \n";
	print "      <td width=\"110\" valign=\"top\" align=\"left\"><b>Internet URL</b></td>\n";
	print "      <td width=\"290\"> \n";
	print "		<input type=\"text\" name=\"url\" value=\"http://\" size=\"20\">\n";
	print "      </td>\n";
	print "    </tr>\n";
	}

if ($showsubject) {
	print "    <tr> \n";
	print "      <td width=\"110\" valign=\"top\" align=\"left\"><b>Subject</b></td>\n";
	print "      <td width=\"290\"> \n";
	print "		<input type=\"text\" name=\"subject\" size=\"20\">\n";
	print "      </td>\n";
	print "    </tr>\n";
	}
?>

	    <tr> 
	      <td width="110" valign="top" align="left">
		<p><b>Message</b>
		<br>
		  <font size="2">(HTML <b>


<?php
if ($html) { print "Enabled"; }
else { print "Disabled"; }
?>

	</b>)</font></p>
      </td>
      <td width="290"> 
        <textarea name="message" cols="30" rows="5"></textarea>
      </td>
    </tr>
    <tr>
      <td width="110" valign="top" align="left">&nbsp;</td>
      <td width="290">
        <input type="submit" name="Submit" value="Submit">
      </td>
    </tr>
    </form>
  </table>
  
  <a href="<?php print $siteurl; ?>">Back to <?php print $title; ?></a><br>
  <a href="<?php print $siteurl . $ttbookdir . "ttview.php"; ?>">View Guestbook Entries</a><br><br>
  <font size="1">TT-Book Guestbook by <a href="http://www.twintopsoft.f2s.com/">Twintop Soft</a></font>
</div>
</body>
</html>