Name    : TT-Book Guestbook: Flatfile Edition
Author  : David C. Uhrig
Contact : E-mail - david@eysle.cruciblegames.com
          ICQ# - 8876126
          AOL IM - Doomduer
Version : 1.0
Released: November 11, 2001

 INSTALLATION 
--------------

Open ttbook.conf in a text editor and make changes to the variables so that
this program will run propperly on our server. Be sure to set a username and
password so that you can remove less-than wanted entries!

Once you've finished editing ttbook.conf, upload the following file to your
website in the directory you associated the variable $ttbookdir with. Create
this directory if needed and also create the directory you associated the
variable $flatfiledir with.

You're all set!

     USE
-------------

To have someone sign your guestbook, link to ttbook.php

To read the entries in your guestbook, link to ttview.php

To edit entries in your guestbook, goto ttcontrol.php and enter your username
and password (these can be changed in the ttbook.conf file).

Enjoy!