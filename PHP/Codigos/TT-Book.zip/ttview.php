<?php include("ttbook.conf"); ?>

<html>
<head>
<title><?php print $title; ?>: TT-Book Guestook</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="<?php print $bgimage; ?>" bgcolor="<?php print $bgcolor; ?>" text="<?php print $textcolor; ?>" link="<?php print $linkcolor; ?>" alink="<?php print $alinkcolor; ?>" vlink="<?php print $vlinkcolor; ?>">
<div align="center">

<font size="4"><?php print $title; ?>: TT-Book Guestook Entries</font><br><br>

<?php

$entriesfile="../" . $flatfiledir . "entries.dat";
@$entries=file($entriesfile);

$ent="0";

if ($entries[0]) {
	foreach ($entries as $entry) {
		$ent++;
		}
	}

if ($showfirst) {
	if ($HTTP_GET_VARS['current']) {
		$last=($HTTP_GET_VARS['current'])+($ppp)-(1);
		$first=$HTTP_GET_VARS['current'];
		}
	else {
		$last=$ppp;
		$first="1";
		}
	
	foreach ($entries as $entr) {
		$entry= preg_split('/\|<>\|/', $entr);
		if ($x >= $first && $x <= $last) {
			if (!$html) {
				$entry[5] = str_replace("<","</",$entry[5]);
				}
			
			print "<table width=\"100%\">\n";
			print "  <tr>\n";
			print "    <td width=\"110\" valign=\"top\"><b>Entry Number</b></td>\n";
			print "    <td>" . $entry[0] . "</td>\n";
			print "  </tr>\n";
			print "  <tr> \n";
			print "    <td width=\"110\" valign=\"top\"><b>Name</b></td>\n";
			print "    <td>" . $entry[1] . "</td>\n";
			print "  </tr>\n";
			
			if ($showemail) {
				print "  <tr> \n";
				print "    <td width=\"110\" valign=\"top\"><b>E-mail</b></td>\n";
				print "    <td>" . $entry[2] . "</td>\n";
				print "  </tr>\n";
				}

			print "  <tr> \n";
			print "    <td width=\"110\" valign=\"top\"><b>Date Posted</b></td>\n";
			print "    <td>" . $entry[6] . "</td>\n";
			print "  </tr>\n";
			
			if ($showurl) {
				print "  <tr> \n";
				print "    <td width=\"110\" valign=\"top\"><b>Internet URL</b></td>\n";
				print "    <td><a href=\"" . $entry[3] . "\">" . $entry[3] . "</a></td>\n";
				print "  </tr>\n";
				}
			if ($showip) {
				print "  <tr> \n";
				print "    <td width=\"110\" valign=\"top\"><b>IP Number</b></td>\n";
				print "    <td>" . $entry[7] . "</td>\n";
				print "  </tr>\n";
				}
			if ($showsubject) {
				print "  <tr> \n";
				print "    <td width=\"110\" valign=\"top\"><b>Subject</b></td>\n";
				print "    <td>" . $entry[4] . "</td>\n";
				print "  </tr>\n";
				}
			print "  <tr> \n";
			print "    <td width=\"110\" valign=\"top\"><b>Message</b></td>\n";
			print "    <td>" . $entry[5] . "</td>\n";
			print "  </tr>\n";
			print "</table>\n";
			print "<hr id=\"000000\" size=\"2\" width=\"100%\" align=\"left\">\n";
			}
		$x++;
		}
	if (1 < $first) {
		$back=($first)-(10);
		print "<a href=\"" . $siteurl . $ttbookdir . "ttview.php?current=" . $back . "\">&lt;&lt; Previous 10</a> \n";
		}
	else { print "&lt;&lt; Previous 10 \n"; }
	
	if ($last < $ent) {
		$forward=($last)+(1);
		print " <a href=\"" . $siteurl . $ttbookdir . "ttview.php?current=" . $forward . "\">Next 10 &gt;&gt;</a>\n";
		}
	else { print " Next 10 &gt;&gt;\n"; }
	}
else {
	if ($HTTP_GET_VARS['current']) {
		$first=($HTTP_GET_VARS['current'])+($ppp)-(1);
		$last=$HTTP_GET_VARS['current'];
		}
	else {
		$first=$ent;
		$last=($ent)-(10)+(1);
		}

	rsort ($entries);
	
	$x=$ent;
	
	foreach ($entries as $entr) {
		$entry= preg_split('/\|<>\|/', $entr);
		if ($x >= $last && $x <= $first) {
			if (!$html) {
				$entry[5] = str_replace("<","</",$entry[5]);
				}

			print "<table width=\"100%\">\n";
			print "  <tr>\n";
			print "    <td width=\"110\" valign=\"top\"><b>Entry Number</b></td>\n";
			print "    <td>" . $entry[0] . "</td>\n";
			print "  </tr>\n";
			print "  <tr> \n";
			print "    <td width=\"110\" valign=\"top\"><b>Name</b></td>\n";
			print "    <td>" . $entry[1] . "</td>\n";
			print "  </tr>\n";
			
			if ($showemail) {
				print "  <tr> \n";
				print "    <td width=\"110\" valign=\"top\"><b>E-mail</b></td>\n";
				print "    <td>" . $entry[2] . "</td>\n";
				print "  </tr>\n";
				}

			print "  <tr> \n";
			print "    <td width=\"110\" valign=\"top\"><b>Date Posted</b></td>\n";
			print "    <td>" . $entry[6] . "</td>\n";
			print "  </tr>\n";
			
			if ($showurl) {
				print "  <tr> \n";
				print "    <td width=\"110\" valign=\"top\"><b>Internet URL</b></td>\n";
				print "    <td><a href=\"" . $entry[3] . "\">" . $entry[3] . "</a></td>\n";
				print "  </tr>\n";
				}
			if ($showip) {
				print "  <tr> \n";
				print "    <td width=\"110\" valign=\"top\"><b>IP Number</b></td>\n";
				print "    <td>" . $entry[7] . "</td>\n";
				print "  </tr>\n";
				}
			if ($showsubject) {
				print "  <tr> \n";
				print "    <td width=\"110\" valign=\"top\"><b>Subject</b></td>\n";
				print "    <td>" . $entry[4] . "</td>\n";
				print "  </tr>\n";
				}
			print "  <tr> \n";
			print "    <td width=\"110\" valign=\"top\"><b>Message</b></td>\n";
			print "    <td>" . $entry[5] . "</td>\n";
			print "  </tr>\n";
			print "</table>\n";
			print "<hr id=\"000000\" size=\"2\" width=\"100%\" align=\"left\">\n";
			}
		$x=($x)-(1);
		}
	if ($first < $ent) {
		$back=($first)+(1);
		print "<a href=\"" . $siteurl . $ttbookdir . "ttview.php?current=" . $back . "\">&lt;&lt; Previous 10</a> \n";
		}
	else { print "&lt;&lt; Previous 10 \n"; }
	
	if (1 < $last) {
		$forward=($last)-(10);
		print " <a href=\"" . $siteurl . $ttbookdir . "ttview.php?current=" . $forward . "\">Next 10 &gt;&gt;</a>\n";
		}
	else { print " Next 10 &gt;&gt;\n"; }
	}
?>


  <br><br>
  <a href="<?php print $siteurl; ?>">Back to <?php print $title; ?></a><br>
  <a href="<?php print $siteurl . $ttbookdir . "ttview.php"; ?>">Sign Guestbook</a><br><br>
  <font size="1">TT-Book Guestbook by <a href="http://www.twintopsoft.f2s.com/">Twintop Soft</a></font>
</div>
</body>
</html>