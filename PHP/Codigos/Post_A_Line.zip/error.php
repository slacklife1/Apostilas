<?
	require("include/process.inc");	
?>
<link rel="stylesheet" href="../style/link.css" type="text/css">

<title>Error In a Required Field</title><b><font color="#003366">Error In a Required Field </font></b> 
<table width="90%" border="1" align="center" bordercolor="#000000" cellpadding="5" cellspacing="0" bgcolor="#FFFFFF">
  <tr> 
    <td>Please press the back button on your browser and insure that you have 
      completed the following &quot;Required&quot; fields: 
      <ul>
        <? echo $Error ; ?>
      </ul>
    </td>
  </tr>
</table>
