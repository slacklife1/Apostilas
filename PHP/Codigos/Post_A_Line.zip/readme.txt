Thank you for downloading my Links Page!

This is my first submission to Planet Source Code; 
I felt that it was about time to try to give a little 
something back to all those that have helped me through their 
submissions. I hope that I am able to contribute a little to you.


1.) Setup
-Create a database where you want your �Links Table� located
-Open the �Links.sql� file to create the table structure.
-Open the �db.inc� file located in the include folder and 
     change the �DBName� to the name of your database, �DBUserName� 
     to your database user name and �DBPassword� to your database password, 
     then save the file.
-Open �setup.inc� and edit it�s contents to suit your needs.

2.) Use
-Upload all files to your website and point to the index.php file.
-Enjoy.


If you have any questions/comments please contact me at:
jwright@ps-hosting.com
