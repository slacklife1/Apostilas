<?
require ("include/setup.inc");
?>

<html>
<head>
<title><?echo $Title?> Link Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="include/link.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td colspan="2"> 
      <div align="center"> 
        <h2><font color="#003366"><?echo $PageTitle?><br>
          Link Page</font></h2>
      </div>
    </td>
  </tr>
  <tr> 
    <td width="50%"> 
      <div align="center"><a class=bodyLink href="add.php">Add a Link</a></div>
    </td>
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
<br>
    
    <? 
	require ("include/db.inc");
    // Number of entries per page 
    
	
    //  Query
    $sql_text = ("SELECT * FROM linkpages WHERE Approved = '1'"); 
    // Set page #, if no page isspecified, assume page 1 
    
	if (!$page) { 
    $page = 1; 
    } 
    $prev_page = $page - 1; 
    $next_page = $page + 1; 
    $query = mysql_query($sql_text);
    // Set up specified page 
    $page_start = ($per_page * $page) - $per_page; 
    $num_rows = mysql_num_rows($query); 
    if ($num_rows <= $per_page) { 
    $num_pages = 1; 
    } else if (($num_rows % $per_page) == 0) { 
    $num_pages = ($num_rows / $per_page); 
    } else { 
    $num_pages = ($num_rows / $per_page) + 1; 
    } 
    $num_pages = (int) $num_pages; 
    if (($page > $num_pages) || ($page < 0)) { 
    error("You have specified an invalid page number"); 
    } 
    // 
    // Now the pages are set right, we can 
    // perform the actual displaying... 
    $sql_text = $sql_text . " LIMIT $page_start, $per_page"; 
    $query = mysql_query($sql_text); 
    
	print ("<table width=100% border=0 cellspacing=0 cellpadding=0>");
	if (!$Count) { 
    	$Count = 0; 
    } 
	while ($result = mysql_fetch_array($query)) { 
    $Count++;	
		print ("<tr>");
    	print ("<td width=1 valign=top>$Count.</td>");
    	print ("<td valign=top><a class=bodyLink href=$result[Location] target=_blank>$result[Title]</a> - $result[Description]<br><font color=#999999 size=-1><b>$result[Location]</b></font><br><br></td>");
    	print ("</tr>");
    }
	print ("</table><br>
");

   if ($prev_page) {
    	print ("<a class=bodyLink href=\"javascript:history.back(1)\">Prev</a>");
    }

    // Page # direct links 
    for ($i = 1; $i <= $num_pages; $i++) { 
		if ($i != $page) { 
			} else { 
			echo " Page $i "; 
		} 
    } 
    // Next 
    if ($page != $num_pages) { 
		print ("<a class=bodyLink href=\"$PHP_SELF?page=$next_page&Count=$Count\">Next</a>"); 
    }
?> 

 <div align=center><font size=1>Copyright &copy;2001 - <? echo date("Y");?> P S Hosting All Rights Reserved.<br>
  This site is hosted and maintained by <a href=http://www.ps-hosting.com>Public 
  Safety Hosting</a></font></div>

</body>
</html>
