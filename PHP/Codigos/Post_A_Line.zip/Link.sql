CREATE TABLE linkpages (
   ID int(11) NOT NULL auto_increment,
   Title varchar(45) NOT NULL,
   Description blob NOT NULL,
   Location varchar(50) NOT NULL,
   Contact varchar(50) NOT NULL,
   Approved int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (ID),
   UNIQUE Title (Title),
   UNIQUE ID (ID),
   KEY ID_2 (ID)
);
