<?
require ("include/setup.inc");
?>
<html>
<head>
<title><?echo $PageTitle?> Add a Link Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="include/link.css" type="text/css">
</head>
<body bgcolor="#FFFFFF" text="#000000">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td> 
      <div align="center"> 
        <h2><font color="#003366"><?echo $PageTitle?><br>
          Add a Link Page</font></h2>
      </div>
    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td>Thank you for adding your web page to our site. We strive to make this 
      website informative and up to date. If you have a web site or know of a 
      site that you would like seen posted please complete this form. Each site 
      will be reviewed and posted accordingly. </td>
  </tr>
  <tr> 
    <td> 
      <form method="post" action="error.php">
        <table width="50%" border="0" cellspacing="0" cellpadding="5" align="center">
          <tr> 
            <td> 
              <div align="right">Title of Site:</div>
            </td>
            <td> 
              <input type="text" name="Title" maxlength="45">
            </td>
          </tr>
          <tr> 
            <td> 
              <div align="right">Description:</div>
            </td>
            <td> 
              <textarea width="100%" name="Description"></textarea>
            </td>
          </tr>
          <tr> 
            <td> 
              <div align="right">URL:</div>
            </td>
            <td> 
              <input type="text" name="Location" maxlength="50" value="http://" size="35">
            </td>
          </tr>
          <tr> 
            <td> 
              <div align="right">E-Mail Address:</div>
            </td>
            <td> 
              <input type="text" name="Email" maxlength="50" size="35">
            </td>
          </tr>
          <tr> 
            <td> 
              <div align="right"></div>
            </td>
            <td> 
              <input type="submit" name="Submit" value="Add Link">
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
</table>
<div align=center><font size=1><br>
  Copyright &copy;2001 - 2002 P S Hosting All Rights Reserved.<br>
  This site is hosted and maintained by <a href=http://www.ps-hosting.com>Public 
  Safety Hosting</a></font></div>
</body>
</html>
