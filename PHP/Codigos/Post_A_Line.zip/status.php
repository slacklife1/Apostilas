<?
require ("include/setup.inc");
?>
<link rel="stylesheet" href="include/link.css" type="text/css">
<title><?echo $PageTitle?> Add a Link Page Admin</title><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td> 
      <div align="center"> 
        <h2><font color="#003366"><?echo $PageTitle?><br>
          Add a Link Page Admin</font></h2>
      </div>
    </td>
  </tr>
</table>
<?
	//Site Not Approved
	if (trim($Title) > '' AND $Approved == 'Deny'){
		require ("include/db.inc");
		$sql = "DELETE FROM linkpages WHERE Approved = '$Title'";
		mysql_query($sql,$db_link);
		print ("<p>The site has been removed from the database</p>\n");
	}
	if (trim($Title) > '' AND $Approved == 'Approved'){
		require ("include/db.inc");
		$sql = "UPDATE linkpages SET Approved = '1' WHERE Approved = '$Title'";

		mysql_query($sql,$db_link);
		print ("<p>The site has been Added</p>\n");
	}
?>