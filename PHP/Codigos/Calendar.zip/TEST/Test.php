<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Untitled</title>
<script language="JavaScript1.3">
// ************************* Programmed by sOul- ************
// setDateToday to some element;
// Use: writeToday (formName,elementName);
//***********************************************************
function writeToday(formName, elementName, nextElement){
	var tmpObj = eval("document." +formName+ "." +elementName);
	if (tmpObj.value == "") {
		var today = new Date();
		var tmpDay =  String(today.getDate());
		var tmpMonth = String(today.getMonth()+ 1); 
		var tmpYear = String(today.getFullYear()); 
    	tmpDay  = ((tmpDay.length==1)? '0':'')  + String(tmpDay);
		tmpMonth = ((tmpMonth.length==1)? '0':'') +  String(tmpMonth);
		var tmpDate = tmpDay + tmpMonth + tmpYear;
		tmpObj.value = tmpDate;
	} else {
		return;
	}
}
//************************* Programmed by sOul- ************
// isNumber -> USE: 
// NewWindow (
// 	myPage (string url)
//  myName	(string titel)
//	Width	(integer breedte)
//	Height (integer hoogte)
//	Scroll (yes/no)
//	Resizable (yes/no)	 
//	);
//**********************************************************
function NewWindow(myPage, myName, Width, Height, Scroll, Resizable) {
	var winTop = ((screen.height - Height) / 2);
	var winLeft= ((screen.width - Width) / 2);
	winProps = 'top=' +winTop+ ',left=' +winLeft+ ',height=' +Height+ ',width=' +Width+ ',Scrollbars=' +Scroll+ ',Resizable=' +Resizable+ ';'
	Win = window.open(myPage, myName, winProps);
		
		if (parseInt(navigator.appVersion) >= 4) { 
			Win.window.focus(); //set focus to the window
		}
}
</script>
</head>

<body onload="writeToday('frmInput','dateIndienst','strContract');" Onunload="CloseCalandar();">
<form name="frmInput">
<input 
type="text" 
id="dateIndienst"
name="dateIndienst" 
maxLength=8
style="width:'100';"
onclick="NewWindow('calendar.php?frmName=frmInput&fieldName=dateIndienst&nextFieldName=dateUitdienst','Datum','229','205','noscrollbars','yes','noresize');"
>
<br>
<input 
type="text" 
id="dateUitdienst"
name="dateUitdienst" 
maxLength=8
style="width:'100';"
onclick="NewWindow('calendar.php?frmName=frmInput&fieldName=dateUitdienst&nextFieldName=','Datum','229','205','noscrollbars','yes','noresize');"
>
</form>
</body>
</html>
<script language="JavaScript">
function CloseCalandar() {
	try {
		Win.close();
	} catch(e) {}
}
</script>