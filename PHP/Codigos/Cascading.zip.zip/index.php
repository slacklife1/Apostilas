<html>
<head>
<title>graphical navigation menu</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<frameset rows="*" cols="150,*">
  <frame src="nav.php" name="nav" frameborder="NO" scrolling="NO" marginwidth="10" marginheight="10">
  <frame src="main.php" name="main" frameborder="NO" scrolling="NO" marginwidth="10" marginheight="10">
</frameset>

<noframes>
   <body bgcolor="#FFFFFF">
     Your browser does not support frames.
   </body>
</noframes>
</html>