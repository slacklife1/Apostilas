<?php
// -----------------------------------------------------------------------------------------------
// nested_menu.php
// -----------------------------------------------------------------------------------------------
// Project:   Cascading menu with image buttons using on-the-fly image creation.
// Author:    Copyright (c) Urs <admin@circle.ch>
// Version:   1.0.0
// Update:    20-7-2000
// Licence:   ?
// PHP:       php-4.0.0-win32
//
// Source:    http://www.circle.ch/scripts/code/button_menu.zip
// Reference: "menu class" written by:                  <zakj@i.am>,
//            modified "menu class" for image use by:   <admin@circle.ch>
// Syntax:    for testing:
//               http://localhost/nested_menu.php
//            for inclusion (see also nested_menu.php):
//               <img src="button.php?fg=990000&bg=ffffff&txt=button one" border="0" alt="">
// Settings:  $bg = background color , hexadecimal
//            $fg = foreground color , hexadecimal
//            hexadecimal order : RGB (each 2byte)
//
// Enjoy!
// -----------------------------------------------------------------------------------------------
// Be aware of the patented GIF format! Adapt the routines to PNG. <http://www.libpng.org/pub/png>
// -----------------------------------------------------------------------------------------------

  include('menu.php');

  $sub =  new menu('<img src="button.php?fg=666666&bg=eeeeee&txt=%20submenu%201_4" border="0" alt="sub 1_1">', 'sub 1 1');
  $sub->add('<img src="button.php?fg=aaaaaa&bg=eeeeee&txt=%20%20subsub%201_4_1" border="0" alt="subsub 1_1_1">', 'link4.html', 'main');
  $sub->add('<img src="button.php?fg=aaaaaa&bg=eeeeee&txt=%20%20subsub%201_4_2" border="0" alt="subsub 1_1_1">', 'link5.html', 'main');

  $main = new menu('<img src="button.php?fg=f00000&bg=dddddd&txt=menu%201" border="0" alt="menu 1">', 'menu 1');
  $main->add('<img src="button.php?fg=666666&bg=eeeeee&txt=%20submenu%201_1" border="0" alt="submenu 1_1">', 'link1.html', 'main');
  $main->add('<img src="button.php?fg=666666&bg=eeeeee&txt=%20submenu%201_2" border="0" alt="submenu 1_2">', 'link2.html', 'main');
  $main->add('<img src="button.php?fg=666666&bg=eeeeee&txt=%20submenu%201_3" border="0" alt="submenu 1_3">', 'link3.html', 'main');
  $main->add($sub);

  $sub2 =  new menu('<img src="button.php?fg=666666&bg=eeeeee&txt=%20submenu%202_4" border="0" alt="sub 2_1">', 'sub 2 1');
  $sub2->add('<img src="button.php?fg=aaaaaa&bg=eeeeee&txt=%20%20subsub%202_4_1" border="0" alt="subsub 2_1_1">', 'link4.html', 'main');
  $sub2->add('<img src="button.php?fg=aaaaaa&bg=eeeeee&txt=%20%20subsub%202_4_2" border="0" alt="subsub 2_1_1">', 'link5.html', 'main');

  $main2 = new menu('<img src="button.php?fg=f00000&bg=dddddd&txt=menu%202" border="0" alt="menu 2">', 'menu 2');
  $main2->add('<img src="button.php?fg=666666&bg=eeeeee&txt=%20submenu%202_1" border="0" alt="submenu 2_1">', 'link1.html', 'main');
  $main2->add('<img src="button.php?fg=666666&bg=eeeeee&txt=%20submenu%202_2" border="0" alt="submenu 2_2">', 'link2.html', 'main');
  $main2->add('<img src="button.php?fg=666666&bg=eeeeee&txt=%20submenu%202_3" border="0" alt="submenu 2_3">', 'link3.html', 'main');
  $main2->add($sub2);

  ?>
  <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
  <HTML>
  <HEAD>
  <TITLE>Title</TITLE>
  </HEAD>
  <BODY BGCOLOR="#DDDDDD">
  <?php
  $main->show();
  $main2->show();
  ?>
  </BODY>
  </HTML>