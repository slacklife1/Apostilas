<html>
<head>
<title>graphical navigation menu</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF">
<table align="left">
  <tr><td>This is the start page</td>
  </table>
</body>
</html>