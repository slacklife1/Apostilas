
CREATE TABLE authors (
  author varchar(50) NOT NULL default '',
  pass varchar(8) NOT NULL default '',
  email varchar(50) NOT NULL default '',
  PRIMARY KEY  (author),
  UNIQUE KEY author (author)
) TYPE=MyISAM;

CREATE TABLE bbs (
  id int(11) NOT NULL auto_increment,
  title varchar(64) default NULL,
  poster varchar(64) default NULL,
  created datetime default NULL,
  parent int(11) default NULL,
  body blob,
  expire int(20) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

CREATE TABLE bbsen (
  id int(11) NOT NULL auto_increment,
  title varchar(64) default NULL,
  poster varchar(64) default NULL,
  created datetime default NULL,
  parent int(11) default NULL,
  body blob,
  expire int(20) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

CREATE TABLE bbsfr (
  id int(11) NOT NULL auto_increment,
  title varchar(64) default NULL,
  poster varchar(64) default NULL,
  created datetime default NULL,
  parent int(11) default NULL,
  body blob,
  expire int(20) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

CREATE TABLE contact (
  name varchar(70) NOT NULL default '',
  email varchar(50) NOT NULL default '',
  address varchar(80) default NULL,
  city varchar(50) NOT NULL default '',
  state varchar(50) default NULL,
  zip varchar(15) default NULL,
  country varchar(50) default NULL,
  os varchar(50) default NULL,
  ip varchar(15) default NULL,
  id int(5) NOT NULL auto_increment,
  UNIQUE KEY id (id),
  KEY city (city),
  KEY email (email),
  KEY name (name)
) TYPE=MyISAM;

CREATE TABLE edifr (
  id int(11) NOT NULL auto_increment,
  acode varchar(50) default NULL,
  dval int(20) default NULL,
  push varchar(15) default NULL,
  author varchar(50) default NULL,
  authemail varchar(50) default NULL,
  atitle varchar(50) default NULL,
  article blob,
  hfont varchar(30) NOT NULL default 'Arial,Helvetica,sans',
  hcol varchar(10) NOT NULL default 'black',
  hsize tinyint(1) NOT NULL default '3',
  afont varchar(30) NOT NULL default 'Arial,Helvetica,sans',
  acol varchar(10) NOT NULL default 'black',
  asize tinyint(1) NOT NULL default '2',
  tsize int(4) default NULL,
  tbcol varchar(10) default NULL,
  tbor tinyint(2) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

CREATE TABLE edito (
  id int(11) NOT NULL auto_increment,
  acode varchar(50) default NULL,
  dval int(20) default NULL,
  push varchar(15) default NULL,
  author varchar(50) default NULL,
  authemail varchar(50) default NULL,
  atitle varchar(50) default NULL,
  article blob,
  hfont varchar(30) NOT NULL default 'Arial,Helvetica,sans',
  hcol varchar(10) NOT NULL default 'black',
  hsize tinyint(1) NOT NULL default '3',
  afont varchar(30) NOT NULL default 'Arial,Helvetica,sans',
  acol varchar(10) NOT NULL default 'black',
  asize tinyint(1) NOT NULL default '2',
  tsize int(4) default NULL,
  tbcol varchar(10) default NULL,
  tbor tinyint(2) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

CREATE TABLE forum (
  id int(11) NOT NULL auto_increment,
  title varchar(64) default NULL,
  poster varchar(64) default NULL,
  created datetime default NULL,
  parent int(11) default NULL,
  body blob,
  expire int(20) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

CREATE TABLE refer (
  id tinyint(4) NOT NULL auto_increment,
  ref varchar(150) NOT NULL default '',
  hits int(10) NOT NULL default '0',
  last datetime NOT NULL default '0000-00-00 00:00:00',
  ip varchar(15) NOT NULL default '',
  uri varchar(150) NOT NULL default '',
  PRIMARY KEY  (id),
  UNIQUE KEY ref_2 (ref),
  UNIQUE KEY id (id)
) TYPE=MyISAM;

CREATE TABLE rlist (
  rtbl varchar(20) NOT NULL default '',
  rgroup varchar(10) NOT NULL default '',
  rdesc varchar(50) NOT NULL default '',
  PRIMARY KEY  (rtbl),
  UNIQUE KEY rtbl (rtbl)
) TYPE=MyISAM;


INSERT INTO rlist VALUES ('edito', 'everyone', 'Main public site');
INSERT INTO rlist VALUES ('edifr', 'users', 'version fran�aise');

CREATE TABLE trakx (
  id varchar(24) NOT NULL default '',
  lasthit datetime NOT NULL default '0000-00-00 00:00:00',
  ip varchar(16) NOT NULL default '',
  os varchar(50) NOT NULL default '',
  ref varchar(60) NOT NULL default '',
  PRIMARY KEY  (id),
  UNIQUE KEY sid_2 (id),
  KEY sid (id)
) TYPE=MyISAM;

CREATE TABLE users (
  user varchar(50) NOT NULL default '',
  pass varchar(50) NOT NULL default '',
  email varchar(100) NOT NULL default '',
  id int(5) unsigned NOT NULL auto_increment,
  UNIQUE KEY id (id),
  UNIQUE KEY user (user),
  KEY email (email)
) TYPE=MyISAM;

    