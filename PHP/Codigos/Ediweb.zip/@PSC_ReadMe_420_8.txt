Title: Ediweb, website administration and editor
Description: UPDATED 23/04/2002:
Complete update in this release
added file manager
added full multilingual support
new template system
donne a lot of debugging
UPDATED 29/11/2001:
New icons have been added for link bars and a complete set is located in the icons directory.
Public site now also has language options for navigation, contact, forum and news sections.
An install script is provided, installs in 2 minutes !
UPDATED 15/11/2001: 
- Added HTTP authentication to admin script
- Added database manager in admin script 
- Included dBfunk library of simple database functions 
(edit ediwebadmin.php to see how simple it is)
- Included a refering script and top referer display script 
- Fixed article deletion bug 
- Fixed search function bug making search case sensitive 
- Fixed news and forum manager bug confusing tables 
20/09/2001 :New features added : mailing manager and news manager in admin script, news on display script.Ediweb is a very easy to use database powered web site editor. Ediweb is coded in PHP and relies on MySQL for database tables.
Multi author : Lets many authors co-edit the site in a simple and easy way. Each author can only edit or delete his own pages.
Template driven : One single HTML design job is needed for the whole site. Or you can use templates from freebies site on the web. You can provide different 'look and feel' for your site, at the choice of your visitors.
Multi language support : Currently only french and english language file are available, any help in translation to other languages welcome !
Contact database : For mailing list support, custommer support, etc...
Integrated search facility : Visitors can search thru your whole site.
Complete online documentation can be found at :
http://www.maxi-web.net/~ediweb/

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=420&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
