<?

include ("scripts/config.php");
	
$mkedito = "CREATE TABLE edito (
   id int(11) NOT NULL auto_increment,
   acode varchar(50),
   dval int(20),
   push varchar(15),
   author varchar(50),
   authemail varchar(50),
   atitle varchar(50),
   article blob,
   hfont varchar(30) DEFAULT 'Arial,Helvetica,sans' NOT NULL,
   hcol varchar(10) DEFAULT 'black' NOT NULL,
   hsize tinyint(1) DEFAULT '3' NOT NULL,
   afont varchar(30) DEFAULT 'Arial,Helvetica,sans' NOT NULL,
   acol varchar(10) DEFAULT 'black' NOT NULL,
   asize tinyint(1) DEFAULT '2' NOT NULL,
   tsize int(4),
   tbcol varchar(10),
   tbor tinyint(2) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id)
) ";

$mkedifr = "CREATE TABLE edifr (
   id int(11) NOT NULL auto_increment,
   acode varchar(50),
   dval int(20),
   push varchar(15),
   author varchar(50),
   authemail varchar(50),
   atitle varchar(50),
   article blob,
   hfont varchar(30) DEFAULT 'Arial,Helvetica,sans' NOT NULL,
   hcol varchar(10) DEFAULT 'black' NOT NULL,
   hsize tinyint(1) DEFAULT '3' NOT NULL,
   afont varchar(30) DEFAULT 'Arial,Helvetica,sans' NOT NULL,
   acol varchar(10) DEFAULT 'black' NOT NULL,
   asize tinyint(1) DEFAULT '2' NOT NULL,
   tsize int(4),
   tbcol varchar(10),
   tbor tinyint(2) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id)
) ";

$mkauthors = "CREATE TABLE authors (
   author varchar(50) NOT NULL,
   pass varchar(8) NOT NULL,
   email varchar(50) NOT NULL,
   PRIMARY KEY (author),
   UNIQUE author (author)
) ";

$mkbbsfr = "CREATE TABLE bbsfr (
   id int(11) NOT NULL auto_increment,
   title varchar(64),
   poster varchar(64),
   created datetime,
   parent int(11),
   body blob,
   expire int(20) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id)
) ";

$mkbbsen = "CREATE TABLE bbsen (
   id int(11) NOT NULL auto_increment,
   title varchar(64),
   poster varchar(64),
   created datetime,
   parent int(11),
   body blob,
   expire int(20) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id)
) ";

$mkforum = "CREATE TABLE forum (
   id int(11) NOT NULL auto_increment,
   title varchar(64),
   poster varchar(64),
   created datetime,
   parent int(11),
   body blob,
   expire int(20) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id)
) ";

$mkcontact = "CREATE TABLE contact (
   name varchar(70) NOT NULL,
   email varchar(50) NOT NULL,
   address varchar(80),
   city varchar(50) NOT NULL,
   state varchar(50),
   zip varchar(15),
   country varchar(50),
   os varchar(50),
   ip varchar(15),
   id int(5) NOT NULL auto_increment,
   KEY city (city),
   KEY email (email),
   UNIQUE id (id),
   KEY name (name)
) ";

$mkusers = "CREATE TABLE users (
   user varchar(10) NOT NULL,
   pass varchar(10) NOT NULL,
   email varchar(80) NOT NULL,
   cat varchar(30),
   fname varchar(50),
   lname varchar(50),
   occup varchar(50),
   agroup varchar(50),
   rgroup varchar(50),
   mstatus varchar(50),
   saddr varchar(50),
   city varchar(100),
   state varchar(50),
   zip int(10),
   pays varchar(50),
   date_s date,
   heard varchar(100),
   user_id int(7) NOT NULL auto_increment,
   UNIQUE user (user),
   PRIMARY KEY (user),
   KEY email (email),
   KEY user_id (user_id)
) ";

$mktraxs = "CREATE TABLE trakx (
   id varchar(24) NOT NULL,
   lasthit datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   ip varchar(16) NOT NULL,
   os varchar(50) NOT NULL,
   ref varchar(60) NOT NULL,
   PRIMARY KEY (id),
   KEY sid (id),
   UNIQUE sid_2 (id)
) ";

$mkrefer = "CREATE TABLE refer (
   id tinyint(4) NOT NULL auto_increment,
   ref varchar(150) NOT NULL,
   hits int(10) DEFAULT '0' NOT NULL,
   last datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   ip varchar(15) NOT NULL,
   uri varchar(150) NOT NULL,
   PRIMARY KEY (id),
   UNIQUE id (id),
   UNIQUE ref_2 (ref)
) ";

$mkrlist = "CREATE TABLE rlist (
  rtbl varchar(20) NOT NULL default '',
  rgroup varchar(10) NOT NULL default '',
  rdesc varchar(50) NOT NULL default '',
  PRIMARY KEY  (rtbl),
  UNIQUE KEY rtbl (rtbl)
) ";


$mkrlistv1 = "INSERT INTO rlist VALUES ('edito', 'everyone', 'Main public site') ";
$mkrlistv2 = "INSERT INTO rlist VALUES ('edifr', 'users', 'version fran�aise') ";




if ($dbpass) {
	$sid = mysql_connect($dbhost, $dbuser, $dbpass);
	}
	else {
	$sid = mysql_connect($dbhost, $dbuser);
	}

mysql_select_db($dbuser, $sid);

$query = $mkedito;
	mysql_query($query, $sid);
$query = $mkedifr;
	mysql_query($query, $sid);
$query = $mkauthors;
	mysql_query($query, $sid);
$query = $mkbbsen;
	mysql_query($query, $sid);
$query = $mkbbsfr;
	mysql_query($query, $sid);
$query = $mkforum;
	mysql_query($query, $sid);
$query = $mkcontact;
	mysql_query($query, $sid);
$query = $mktraxs;
	mysql_query($query, $sid);
$query = $mkrefer;
	mysql_query($query, $sid);
$query = $mkrlist;
	mysql_query($query, $sid);
$query = $mkrlistv1;
	mysql_query($query, $sid);
$query = $mkrlistv2;
	mysql_query($query, $sid);

header("Location: $adminsc");

?>
