<? 
include("scripts/config.php");
$fid.= " Manager";
$maxbadlogin = 10;
$pagehead = "top2.htm";
$pagefoot = "foot2.htm";
// $db = $dbuser;
if ($etable) {
	$tbl = $etable;
}

if (!$tbl) {
	$tbl = $main_table;
}
elseif ($etable != "") {
	$tbl = $etable;
}
 


$dlbg = "#ccccff";
$bcolor = "#ffffff";

    $ip = $REMOTE_ADDR;
	$os = $HTTP_USER_AGENT;
	$ref = $HTTP_REFERER;
	$doc = $REQUEST_URI;


if (!$lg) {
	$lg = "fr";
}

if ($nlg) {
	setcookie("lg"); 
	setcookie("lg", "$nlg", time()+10800, "/");
	header("Location: $PHP_SELF");
	exit;
}

include("scripts/lang.$lg");

if ($logout) {	
unset($PHP_AUTH_USER);	
unset($PHP_AUTH_PW);
unset ($author);
unset ($authemail);
unset ($session);
setcookie("session"); 
setcookie("lg"); 
setcookie("cdb"); 
setcookie("author"); 
setcookie("authemail"); 
header("Location: http://$administrator:$adminpass@$sitbaseeurl/ediwebadmin.php");
exit;
}
elseif (isset($PHP_AUTH_USER)) {
$administrator = $PHP_AUTH_USER;
$adminpass = $PHP_AUTH_PW;
	if ($administrator != "") {
	$author = $administrator;
	}
	if (isset($PHP_AUTH_PW)) {
	$login = 1;
	}	
}
 	
if ($nlg) {
	setcookie("lg"); 
	setcookie("lg", "$nlg", time()+10800, "/");
	header("Location: $PHP_SELF");
	exit;
}

if (!$cdb || $logout) {
	$author = "";
	$authemail = "";
	$cdb = "";
	$auth = 0;
setcookie("lg"); 
setcookie("cdb"); 
setcookie("author"); 
setcookie("authemail"); 

if ($login && $administrator == "$siteadmin" && $adminpass == "$sitepass") {
$author = "$administrator";
$authemail = "$siteadminemail";
$auth = 1;
$loggedin = "Administrator";

setcookie("cdb", "$db", time()+10800, "/");
setcookie("author", "$author", time()+10800, "/");
setcookie("authemail", "$authemail", time()+10800, "/");
setcookie("lg", "$lg", time()+10800, "/");
setcookie("blg");
}

elseif ($login && $administrator != "$siteadmin" && $adminpass != "$sitepass" && $administrator != "" && $adminpass != "") {
// include("scripts/dbinfo.php");

	if ($dbpass) {
	$sid = mysql_connect($dbhost, $dbuser,$dbpass);
	}
	else {
	$sid = mysql_connect($dbhost, $dbuser);
	}
	
mysql_select_db($db, $sid);
$query = "SELECT author, email FROM authors ";
$query.= "WHERE author = \"$administrator\" ";
$query.= "AND pass = \"$adminpass\" ";
$reponse = mysql_query($query, $sid);
	if ($row = mysql_fetch_row($reponse))  {
	$auth++;
	$author = "$row[0]";
	$authemail = "$row[1]";

	setcookie("cdb", "$db", time()+10800, "/");
	setcookie("author", "$author", time()+10800, "/");
	setcookie("authemail", "$authemail", time()+10800, "/");
	setcookie("lg", "$lg", time()+10800, "/");
	setcookie("blg");
	}
}

if ($auth == 0 ) {
	$author = "";
	$authemail = "";
	$cdb = "";
setcookie("cdb"); 
setcookie("author"); 
setcookie("authemail"); 

	$blg++;
setcookie("blg"); 
setcookie("blg", "$blg", time()+3600, "/");
if ($blg < $maxbadlogin) {
	Header("status: 401 Unauthorized");
    Header("HTTP/1.0 401 Unauthorized");
    Header("WWW-authenticate: basic realm=\"ediwebadmin.php\"");
    echo "<HTML><HEAD><TITLE>$sitename Control Panel</TITLE></HEAD>\n";
    echo "<BODY BGCOLOR=#FFFFFF><BR><BR><CENTER><img src=http://www.maxi-web.net/ediweb/ediweb_w.gif><br><H1>$sitename Control Panel</h1><h2>Access denied</H2>
    <h3>Bad login or password</h3>\n";
    echo "</CENTER></BODY></HTML>";
    exit;

}
else {
include("scripts/$pagehead");
echo "<h2>Too many bad login retries.<br>Trop de mauvais login</h2><h1>Bye !<br>Au revoir !</h1>";
}
include("scripts/$pagefoot");
exit;
}

}
 else {
$loggedin = "$author_label: $author";

 }
// database connection

if ($dbpass) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
}
else {
$sid = mysql_connect($dbhost, $dbuser);
}

mysql_select_db($db, $sid);
 
include("scripts/datetime.php");
$atool = "ed";
	

include("scripts/lang.$lg");
if ($shop == 1) {
	$helptxt = "$edish_help";
}

$authid = "$aut";
if ($author == $siteadmin) {
	$loggedin = "Administrator";
include("scripts/adminlib.php");
}

if ($updt) {
include("scripts/eupdate.php");
}
	
$found = 0;


if ($newcode) {
$dval1 = $exval + (60 * 60 * 24 * 30);
// insert a blank record and set that record to be edited
// (id, acode, dval, push, author, authemail, atitle, article, hfont, hcol, hsize, afont, acol, asize, tsize, tbcol, tbor)

$query = "INSERT INTO $tbl VALUES ( ";
$query.= "0, \"$newcode\", \"$dval1\", \"\", \"$author\", \"$authemail\", \"$newcode\", \"\", ";
$query.= "\"arial,helvetica,sans\", \"brown\", \"3\", ";
$query.= "\"arial,helvetica,sans\", \"black\", \"2\", ";
$query.= "\"\", \"white\", \"0\") ";

	if ($dbpass) {
	$sid = mysql_connect($dbhost, $dbuser,$dbpass);
	}
	else {
	$sid = mysql_connect($dbhost, $dbuser);
	}

mysql_select_db($db, $sid);
mysql_query($query, $sid);

$edito = "$newcode";
}

		
if ($edito != "") {
$query = "SELECT acode, author, authemail, atitle, push, article, dval, ";
$query.= "hfont,hcol,hsize,afont,acol,asize,tsize,tbcol,tbor, id ";
$query.= "from $tbl ";
$query.= "WHERE acode = \"$edito\" ";

	if ($author != "$siteadmin") {
	$query.= "HAVING author = \"$author\" ";
	}

// this is the validity check and it sometimes bugs
// $query.= "AND dval < \"$exval\" ";
$query.= "ORDER BY acode ASC ";

}
elseif (!$clist) {
$query = "select acode, dval, author, id from $tbl ";

	if ($author != "$siteadmin") {
	 $query.= "WHERE author = \"$author\" ";
	}

	if ($search) {
	$query.= "WHERE acode like \"$search%\" ";
	$query.= "OR atitle like \"%$search%\" ";
	$query.= "OR article like \"%$search%\" ";

		if ($author != "$siteadmin") {
 		$query.= "HAVING author = \"$author\" ";
		}

		$sres = "Found <b><i>$search</i></b><p>";	
		}
		
 		if ($author == "$siteadmin") {
		$query.= "ORDER BY acode ASC ";
 		}
 		else {
		$query.= "ORDER BY acode ASC ";
 		}
	 		
	$edt = "<form action=$PHP_SELF method=post>$sres";
	$edt.= "<center><input type=hidden name=authemail value=\"$authemail\">
	<input type=hidden name=tbl value=\"$tbl\">";
	
	$edt.= "<table align=center cellspacing=0 cellpadding=2 width=100%>
	<tr><td align=center bgcolor=$dlbg><table align=center cellspacing=0 cellpadding=0 width=100%>
	<tr><td align=center bgcolor=$bcolor><table border=0 cellspacing=0 width=100%>";
	$edt.= "<tr><td colspan=3 bgcolor=$dlbg><b>$m38</b></td><td bgcolor=$dlbg>$m4</td><td bgcolor=$dlbg><input type=text size=20 name=newcode></td><td bgcolor=$dlbg><input type=submit value=$am2></td></tr>";
	
	$edt.= "</table>
	<table width=100% border=1 cellspacing=0 bordercolor=$dlbg>
	<tr><th>#</th><th width=100>$m4</th><th>ID</th><th>$m7</th><th>Expire</th><th colspan=2>Action</th></tr>";
	}

	if ($dbpass) {
	$sid = mysql_connect($dbhost, $dbuser,$dbpass);
	}
	else {
	$sid = mysql_connect($dbhost, $dbuser);
	}

	mysql_select_db($db, $sid);
	$reponse = mysql_query($query, $sid);

//	if ($reponse == 0) {
//	echo "<center><h3>DATABASE EMPTY</h3></center>";
//	include("scripts/$pagefoot");
//	exit;
//	}

	while ($row = @mysql_fetch_row($reponse))  {
	$found++;
			
		if ($edito) {		
		$acode = $row[0];
		$author = $row[1];	
		$authemail = $row[2];	
		$atitle = $row[3];
			if (substr($acode,0,1) == "_") {
			$alen = strlen($acode)-1;
			$acode	= substr($row[0],1,$alen);
			$chk = "checked";
			$hlb = "$m39";	
			}
			else {
			$chk = "";	
			}	
			
		$push = $row[4];
		$article = $row[5];
		$cst = getdate($row[6]);
			
		$expire = "$cst[year]";
		$expire.= "-";
		$expire.= "$cst[mon]";
		$expire.= "-";
		$expire.= "$cst[mday]";
			
		$hfont = $row[7];	
		$hcol = $row[8];
		$hsize = $row[9];
		$afont = $row[10];	
		$acol = $row[11];
		$asize = $row[12];
			
		$id = $row[16];
			
			if ($row[13] > 0) {
			$tsize = "width=$row[13]";	
			}
				
		$tbcol = $row[14];
		$tbor = $row[15];
			
			if ($tbor == "") {
			$tbor = 0;
			}
		}
		else {
		$cst = getdate($row[1]);
		
		$expire = "$cst[year]";
		$expire.= "-";
		$expire.= "$cst[mon]";
		$expire.= "-";
		$expire.= "$cst[mday]";
		$lto = urlencode($row[0]);	
		$preview1 = "<font size=1><a href=ediweb.php?sa=1&view=$cdb&edito=$row[0] target=_blank>$m33</a>&nbsp;
		<a href=ediweb.php?sa=1&view=$cdb&edito=$row[0]&rawformat=1 target=_blank>$m34</a>&nbsp;
		<a href=template1.php?&view=$cdb&edito=$row[0] target=_blank>$m35</a>&nbsp;
		<a href=template2.php?&view=$cdb&edito=$row[0] target=_blank>$m35b</a></font>";
				$pvl = htmlentities($row[0]);
			if ($tbl == "edifr") {
			$tv = "fr";
			}	
			else {
			$tv = "en";
			}	

	
		$edt.= "<tr><td><font size=-1>$found</font></td>
		<td><font size=-1><a href=http://$sitbaseeurl/index.php?edito=$pvl&lng=$tv target=_blank><b>$row[0]</b></a></font></td>
		<td><font size=-1>$row[3]</font></td><td><font size=1>$row[2]</font></td>
		<td><font color=$dlbg size=1>$expire</font></font></td>
		<td><font size=-1><a href=\"$PHP_SELF?tbl=$tbl&edito=$lto\">Edit</a></font></td><td><font size=-1><a href=\"$PHP_SELF?tbl=$tbl&edito=$lto&id=$row[3]&updt=Update&dele=1\">$am3</a></font></td>
		</tr>";		
		}
	}

	if ($edito) {
	$article = stripslashes($article);

	$edt = "<form action=$PHP_SELF method=post>
	<input type=hidden name=id value=$id><input type=hidden name=tbl value=$tbl>
	<table border=0 cellpadding=1 cellspacing=0 align=center bordercolor=\"$dlbg\" valign=top palign=top width=100%>
	<tr><td valign=top>
	<table width=100% border=$tbor cellspacing=0>
	<tr><td bgcolor=$dlbg>";

	$edt.= "<table width=100% border=0 cellspacing=0>";

	$edt.= "<tr><th bgcolor=$dlbg><font size=-1>$m4: <input type=text name=acode size=15 value=\"$acode\"> <input type=submit name=updt value=$m2> </td></tr>";
		
	$edt.= "<tr><td><i>$hlb</i></font></td></tr>";
	$edt.= "<tr><td><font size=-1><input type=checkbox name=hide value=\"_\" $chk>$m5 <input type=checkbox name=showdate value=\"1\" checked>$m6</font></td></tr>";
	$edt.= "<tr><td align=left><font size=-1>$m0:<input type=text size=30 name=atitle value=\"$atitle\">&nbsp;expire:<input type=text size=12 name=expire value=\"$expire\"></font></td></tr>";
				
	$edt.= "<tr><td align=left><font size=-1><b>$m8</b><input type=radio name=nohtml value=\"0\" checked><b>$mess[48]</b> <input type=radio name=nohtml value=1><b>$mess[49]</b></font>
	<br><font size=-1 color=brown><B>$m9: </B>$m10</font></td></tr>
	<tr><td align=center><textarea name=article rows=14 cols=45>$article</textarea></td></tr><tr><td>&nbsp;</td></tr>";
		
	$edt.= "<tr><td ><font size=-1><input type=checkbox name=img value=1> $m11
	<br>URL: <input size=40 type=text name=iurl value=\"http://$sitbaseeurl/\"><br>";
				
	$edt.= "$m12:<select name=vert><option selected value=top>$m13</option selected><option value=bottom>$m14</option></select>&nbsp;";
	$edt.= "<select name=hori><option selected value=left>$m15</option selected><option value=right>$m16</option></select>&nbsp;";
	$edt.= "$m17:&nbsp;";
	$edt.= "$m18: <input type=text name=width size=4> $m19: <input type=text name=height size=4></font></td></tr>";
		
	$edt2.= "<tr>
	<td bgcolor=#ccccff><p>&nbsp;</p><p><b>$m20</b> ($m21)<br><font size=-1>
	$m22:<input type=text name=hfont size=12 value=$hfont> $m23:<input type=text name=hcol size=8 value=$hcol> $m24:<input type=text name=hsize size=2 value=$hsize><br>
	$m26:<input type=text name=afont size=12 value=$afont> $m27:<input type=text name=acol size=8 value=$acol> $m28:<input type=text name=asize size=2 value=$asize>
	<br>$m29:<input type=text name=tsize size=3 value=$tsize> $m30:<input type=text name=tbor size=2 value=$tbor> $m31: <input type=text name=tbcol size=8 value=$tbcol></font></td></tr>";
		
	$edt.= "</table></td></tr></table></td></tr>";
	
	$preview = "<b>$m32: </B>
	|&nbsp;<a href=ediweb.php?sa=1&view=$cdb&edito=$edito target=_blank>$m33</a>&nbsp;|
	|&nbsp;<a href=ediweb.php?sa=1&view=$cdb&edito=$edito&rawformat=1 target=_blank>$m34</a>&nbsp;|
	|&nbsp;<a href=template1.php?&view=$cdb&edito=$edito target=_blank>$m35</a>&nbsp;|
	|&nbsp;<a href=$PHP_SELF?&logout=1>$m36</a>&nbsp;|
	";
	
	$preview.= "<font size=-1><b>&nbsp; Date: $annee-$mois-$jour $heure:$minute:$seconde</b></font>";
	
	$edt.= "</table></form>";
	}
				
	else {
			
	$edt.= "</table><p>
	<table border=0 cellspacing=0 width=100%>
	<tr><td colspan=4 bgcolor=$dlbg><b>$m37</b></td><td bgcolor=$dlbg><input type=text size=20 name=search></td><td bgcolor=$dlbg><input type=submit value=$am4></td></tr>
	</table></td></tr></table>";

	$edt.= "</td></tr></table></form>";
	}

	if ($clist) {
	$t1 = "$ewa_ct";
	$edt = $clist;
	}	



	if ($mk_etable && $author == $siteadmin) {
	$mkedito = "CREATE TABLE $mk_etable (
   id int(11) NOT NULL auto_increment,
   acode varchar(50),
   dval int(20),
   push varchar(15),
   author varchar(50),
   authemail varchar(50),
   atitle varchar(50),
   article blob,
   hfont varchar(30) DEFAULT 'Arial,Helvetica,sans' NOT NULL,
   hcol varchar(10) DEFAULT 'black' NOT NULL,
   hsize tinyint(1) DEFAULT '3' NOT NULL,
   afont varchar(30) DEFAULT 'Arial,Helvetica,sans' NOT NULL,
   acol varchar(10) DEFAULT 'black' NOT NULL,
   asize tinyint(1) DEFAULT '2' NOT NULL,
   tsize int(4),
   tbcol varchar(10),
   tbor tinyint(2) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id)
	) ";

		if (!$rgroup) {
		$rgroup = "users";
		}
		if (!$rdesc) {
		$rdesc = "Restricted to registered users";
		}

	$mkrestricted = "INSERT INTO rlist VALUES (
   \"$mk_etable\",
   \"$rgroup\",
   \"$rdesc\" 
	) ";

	$query = $mkedito;
	mysql_query($query, $sid);

	$query = $mkrestricted;
	mysql_query($query, $sid);
	}

	if ($shop == 1 && $author == $siteadmin) {
	unset ($tman);
	$t1 = "$ewa_shop";
	$table = "users";
// lsi version
//	$creafile = "/usr/local/apache/htdocs/commercial/lsi-fr/userdb/users";
// local version
//	$creafile = "/home/lsi/users";
	
	if (!$dbfunk) {
	include("scripts/dbfunk.php");
	}
	
	if ($act == "view") {
	$result = db_view($table);			// view table content
 	}
	elseif ($act == "insfrm") {
	$result = db_add($table);			// insert form
	}
	elseif ($act == "Insert") {
	$result = db_ins($table,R);			// insert action
	}
	elseif ($act == "modif") {
	$result = db_form($table,$finame,$record);			// update form
	}
	elseif ($act == "Update") {
 	$result = db_update($table,R);		// update action
 	}
 	elseif ($act == "del") {
 	$result = db_del($table,$finame,$record);			// delete action
 	}
 	elseif($search) {
 	$result = db_meta_search($search);					// search all tables
 	}	
 	elseif ($mkfile == 1) {
 // create users file
	$crea = fopen($creafile, w);
	$query = "SELECT user,pass,email FROM $table ";
	$reponse = mysql_query ($query, $sid);
		while ($row = mysql_fetch_row($reponse)) {
		fputs($crea, "$row[0]::$row[1]::$row[2]\n");
		$result.= "$row[0]::$row[1]::$row[2]\n";	
		}
	fclose($crea);
	$result = "<pre>$result</pre>";
// end crea file
 	}
 	else {
	$result = db_view($table);			// view table content
 	}
 	
$edt = "<table border=1 cellspacing=0 cellpadding=2 align=center bordercolor=$dlbg width=100%>
<tr><td align=center><a href=$adminsc?shop=$shop&act=insfrm&table=$table>$crea_ins</A> <a href=$adminsc?shop=$shop&mkfile=1>$crea_mk</A> <a href=$adminsc?shop=1>$crea_list</a></td></tr></table><br>$sq
<table border=1 cellspacing=0 cellpadding=2 align=center bordercolor=$dlbg width=100%>
$result
</table>";	
}

elseif ($vftp == 1) {
	if ($author != $siteadmin) {
	$scr = "<h3>Access restricted to site administrator</h3><p>Bye !</p>";
	include("scripts/$pagehead");
	echo "$scr";
	include("scripts/$pagefoot");
	exit;
}
$username = $dbuser;
$userpass = $dbpass;
if (!$cmd) {
$cmd = "List Files";
}
include("scripts/vftp.php");
// $t1 = $ewa_vftp;

}
elseif ($tman == 1) {
	$t1 = "$ewa_db";
	if ($author != $siteadmin) {
	$scr = "<h3>Access restricted to site administrator</h3><p>Bye !</p>";
	include("scripts/$pagehead");
	echo "$scr";
	include("scripts/$pagefoot");
	exit;
}
	if (!$dbfunk) {
	include("scripts/dbfunk.php");
	}
	
 if ($act == "view") {
 $result = db_view($table);			// view table content
 }
 elseif ($act == "insfrm") {
 $result = db_add($table);			// insert form
 }
 elseif ($act == "Insert") {
 $result = db_ins($table,R);			// insert action
 }
 elseif ($act == "modif") {
 $result = db_form($table,$finame,$record);			// update form
 }
 elseif ($act == "Update") {
 $result = db_update($table,R);		// update action
 }
 elseif ($act == "del") {
 $result = db_del($table,$finame,$record);			// delete action
 }
 elseif($search) {
 $result = db_meta_search($search);					// search all tables
 }	
 elseif ($rawq && $sqlquery != "") {
 $result = db_rawq($sqlquery);					// run raw query
 $sq = "<pre>$sqlquery</pre><hr size=1>";
 }
 elseif ($act == "list") {
 $result = db_list();					// list tables
 }
 else {
 $result = db_list();					// list tables
 }
$edt = "<table border=1 cellspacing=0 cellpadding=2 align=center bordercolor=$dlbg width=100%>
<tr><td align=center>
<form action=$PHP_SELF method=post><b>Search in all tables </b>: <input type=text name=search> <input type=submit value=Go></form>
</td></tr></table><br>$sq
<table border=1 cellspacing=0 cellpadding=2 align=center bordercolor=$dlbg width=100%>
$result
</table><form action=$PHP_SELF method=post><input type=hidden name=tman value=1><h5>Type in a valid SQL query :</h5>
<table border=1 cellspacing=0 cellpadding=2 align=center bordercolor=$dlbg width=100%>
<tr><td align=center>
<textarea name=sqlquery rows=3 cols=34></textarea>
</td><td align=center>
<input type=submit name=rawq value=\"Submit SQL query\"></form>
</td></tr></table>";
}




$a4 = $mkauthor;
$lgselect = "<font size=-1>$db@$dbhost &nbsp;</font><font size=1> <a href=$PHP_SELF?nlg=en>English</A> &nbsp; <a Href=$PHP_SELF?nlg=fr>Fran&ccedil;ais</A>";
$lgselect1.= "&nbsp; <a Href=$PHP_SELF?nlg=es>Espagnol</A> &nbsp; <a Href=$PHP_SELF?nlg=ct>Catalan</A></font>";
$pagename = "<table width=100%><tr><td align=left class=button bgcolor=#000000>&nbsp; <img src=\"ic_section.gif\" vspace=1 align=top> &nbsp; <font size=-1>$lgselect</font></td></tr></table>";
$a3 = "<font size=-1><b>$m7: </b>$author</font><br><font size=1>$authemail</font>";
$news ="<table><tr><td class=button>$helptxt</td></tr></table>";
$copyr ="<font face='arial,helvetica,sans' size=-1 color=$linkcolor>Powered by: <a href=http://www.maxi-web.net/~ediweb/><b><i>E</i>diweb</b></a> &copy; <a href=http://www.maxi-web.net>Maxi-web Network</a> 2001 by <a href=http://www.maxi-web.net/home/index.php?edito=Home&contact=Webmaster><i>W</i>ize<i>k</i>at</A></font>";
$copyr.= "<br><font size=1>html & graphics by: <a href=http://www.aplustemplates.com>A+ Templates</a> - spanish & catalan translation by: <a href=mailto:krl@informaticos.com>Krl.</A></font>";

$tbselect = "<form action=$adminsc method=post>";
$query = "SELECT rdesc FROM rlist where rtbl = \"$tbl\" ";
	$reponse = mysql_query ($query, $sid);
		if ($row = mysql_fetch_row($reponse)) {
		$svr = $row[0];
		}
		else {
		$svr = $tbl;
		}
$tbselect.= " <select name=etable>";
// $tbselect.= "<option selected value=$tbl> $site_area</OPTION selected>";
$query = "SELECT * FROM rlist ";
	$reponse = mysql_query ($query, $sid);
		while ($row = mysql_fetch_row($reponse)) {
		$tbselect.= "<option value=$row[0]> [$row[2]] $row[1] </option>";
		}
		$tbselect.= "</select>
		<input type=submit name=change_tbl value=Select>&nbsp; [<a href=$adminsc?mkzone=1><b>$am2 $site_area</b></A>]</form>";
if ($mkzone == 1) {
$edt = "<form action=$adminsc method=post>
		<b>$am2 $site_area</b> 
<br>$m4: <input name=mk_etable size=10> 
<br>Group: <input type=text name=rgroup value=users size=10>
<br>Description: <input type=text name=rdesc>
<p><input type=submit value=$am2><br>
		</form>";
}

if ($vftp || $edito || $tman || $tb || $mailing) {
unset($tbselect);
}		
// if ($vftp || $edito || $tman || $tb || $clist || $mkzone) {
unset($mkauthor);
// }		
include("scripts/$pagehead");
echo "$edt";
include("scripts/$pagefoot");
?>
