<?
$edw_ver = "Ediweb 2.01";
include("scripts/config.php");

if (!$lg) {
	$lg = "en";
}

if (!$hv) {
	if ($main_table == "edifr") {
	$hv = "Accueil";
	$Contact_us = "Contactez-nous";
	$lg = "fr";
	}
	else {
	$hv = "Home";	// default sub articles page name for articles having no sub articles
	$Contact_us = "Contact us";
	}
}

if ($main_table == "edifr") {
$fid = "Quoi d'neuf ?"; //news section heading
$lg = "fr";
$lvr = "Version fran�aise";
}
else {
$main_table = "edito";
$fid = "What's New"; //news section heading
$lg = "en";
$lvr = "English version";
}


$fpage = $PHP_SELF;
$lm = date("d/m/Y - H:i", filemtime($PATH_TRANSLATED));
include("scripts/lang.$lg");
include("scripts/ediweb.php");

// sub articles names
$v1 = "_".$edito."_v1";
$v2 = "_".$edito."_v2";
$v3 = "_".$edito."_v3";

// default sub articles are the ones from
// the default sub article page (usually Home)
$hv1 = "_".$hv."_v1";
$hv2 = "_".$hv."_v2";
$hv3 = "_".$hv."_v3";

// colors
$c_titre = "black";	// heading color
$c_texte1 = "#005984"; // text color
$bgcolor = "#CCCCFF"; // background color
$face = "Arial";
$fsize = "-1";
$dcolor = "#ccccff";
$dlbg = "#666699";
$dcolor = "#666699";

// generate links to all articles
$tbl = $main_table;
mklinkbar("$excl");
// get articles

if ($siterefer == "Go" && $refmail != "") {
// refer site to a friend
$rcpt = $refmail;	
$sender = $siteadminemail;	
$name = $sitename;

$subject = "Check out this great web site";
$body = "$today at $thetime\n";
$body.= "A friend of yours refered to $pauthor: \n";
$body.= "$comment";

mail($rcpt,$subject, $body, "From: ".$name."<".$sender.">");


}

 // main article ----------
if (!$search) {
	$atitle = "";
	$article = "";
	$showauthor = 1;	
	getarticle ("$edito");
	$t1 = $atitle;
	$a1 = $article;
	if ($datpub) {
		$lm = $datpub;
	}

	if ($edito == $forumname) {
$showauthor = 0;
// public forum config	
$fname = $forumname;
// display options
$tblwidth = ""; // set the display width
$showlink = 1;	// set to 1 to show links to toc
$showtitle = 0;	// set to 1 to show forum title
$showposter = 1;

	include("scripts/ediforum.php");
	$t1 = $fname;
	$a1 = "$frm";	
	}
	else {
//	$mwf = "<table border=0 cellspacing=0 cellpadding=2><tr><td class=button>$frm</td></tr></table>";	
	}
 }
 //-------------------------
 
 // sub-article 1 ----------
	$atitle = "";
	$article = "";
	getarticle ("$v1");
	if ($found == 0) {
	getarticle ("$hv1");
	}
		if ($article != "") {
		$a2 = $article;
			if ($atitle != "") {
			$t2 = $atitle;
			}
		}
		else {
		getarticle ("_Home_v1");	
		$a2 = $article;
			if ($atitle != "") {
			$t2 = $atitle;
			}
		}
 //-------------------------
 
 // sub-article 2 ----------
	$atitle = "";
	$article = "";
	getarticle ("$v2");
	if ($found == 0) {
	getarticle ("$hv2");
	}
		
		if ($article != "") {
		$a3 = $article;
			if ($atitle != "") {
			$t3 = $atitle;
			}
		}
		else {
		getarticle ("_Home_v2");	
		$a3 = $article;
			if ($atitle != "") {
			$t3 = $atitle;
			}
		}
		
		
 //-------------------------
 
 // sub-article 3 ----------
	if ($edito != $forumname) {
	$atitle = "";
	$article = "";
	getarticle ("$v3");
	if ($found == 0) {
	getarticle ("$hv3");
	}
		if ($article != "") {
		$a4 = $article;
			if ($atitle != "") {
			$t4 = $atitle;
			}
		}
		else {
		getarticle ("_Home_v3");	
		$a4 = $article;
			if ($atitle != "") {
			$t4 = $atitle;
			}
		}
	}
 //-------------------------
 
 // if search data was posted, get
 // search result ----------
if ($search) {
	include("scripts/search/dbsearch.php");

	$article = "";
	$atitle = "";
	$article = fouine($search, $target, "no");
//	$article = searcharticle($search);
	$t1 = $atitle;
	$a1 = $article;
	}
 //-------------------------
 
 // if someone posted a comment or contact request
 // email contact ----------
elseif ($contact) {
	if ($rqi) {
	contactme($contact, $rqi);
	}
	else {
	contactme($contact);
	}
 
}


// this is optional preormating of a sub article
// include news
include("scripts/edinews.php");

$news1 = "<table align=center border=0 cellspacing=0 cellpadding=0 width=100%>
<tr><td bgcolor=#ddddff class=button>$news</td></tr></table>";

$news2 = "<table align=center border=0 cellspacing=0 cellpadding=0 width=100%>
<tr><td bgcolor=#ddddff class=button>$news</td></tr></table>";

$pagename = "<table align=center border=0 cellspacing=0 cellpadding=0 width=98%><tr>
<th align=left abgcolor=#000000>&nbsp; <img src=\"ic_section.gif\" vspace=1 align=top> &nbsp; <font size=-1>$t1</font></td><td>&nbsp;</td><td align=right width=160><font size=1>Paris, $today $thetime CEST</font>
</td></tr>$newstk</table>";

$mwlogo = " <table border=0 cellspacing=0 cellpadding=1 width=100%>
<tr><td>&nbsp;</td><th align=left aclass=button abgcolor=#eeeeee>
<a href=http://$adlogourl target=_blank><img src=\"$adlogo\" border=0></a>
</td></tr></table>";

$searchbox = "
 <table align=center border=0 cellspacing=0 cellpadding=10 width=100%>
 <tr><form method=post action=index.php>
 <td class=button><input type=text name=search size=14><br>
<input type=radio name=target value=doc>Site &nbsp;&nbsp;<input type=radio name=target value=usr checked>Users<br><input type=submit name=Submit value='&nbsp;&nbsp;&nbsp;[&nbsp;Search&nbsp;]&nbsp;&nbsp;&nbsp;'></td></tr></form></table>";

$searchboxh = "
 <table border=0 cellspacing=0 cellpadding=1 width=100%>
 <tr><form method=post action=index.php>
 <td class=button bgcolor=#ddddff align=center height=34 valign=middle><b>$searchboxh_label:</b> <input type=text name=search size=14>
";
if ($user_manager == 1) {
$searchboxh.= "
&nbsp;
<input type=radio name=target value=doc>Site &nbsp;&nbsp;<input type=radio name=target value=usr checked>$searchboxh_label_u &nbsp; 
";
}
$searchboxh.= "
<input type=submit name=Submit value=Go></td><td>&nbsp;</td><td class=button bgcolor=#ddddff align=center valign=middle><a href=index.php?lng=fr><img border=0 align=absmiddle src=/home/FR.gif></A>&nbsp;&nbsp;&nbsp;&nbsp;<a href=index.php?lng=en><img border=0  align=absmiddle src=/home/UK.gif></A></td><td>&nbsp;</td></tr></form></table>";

$datebox = "<table cellspacing=0 cellpadding=5 border=0 width=100%><tr>
<td class=button bgcolor=#ddddff align=center><font size=-1 face=arial>$today &nbsp;<font size=1>$thetime</font></font></td></tr></table>
";

$datebox1 = "<font size=-1>$today &nbsp;<font size=1>$thetime</font></font>";
$refbox = "
<form action=index.php method=post>
Suggest this site to a friend:<br>
email: <input type=text name=refmail size=12> <input type=submit name=siterefer value=Go>
</form>";

$upl_form = "<table cellpadding=1 boder=0  cellspacing=0 align=center><tR>
<form ENCTYPE=multipart/form-data action=$PHP_SELF method=post>
<input type=hidden name=vftp value=1>
<input type=hidden name=cmd value='Send File'>
<td align=right bgcolor=silver>
<b>$mess[25]:</b> <input type=file name=source_file><br><input type=submit value=$mess[27]>
</td></form></TR></table>";


$ls_form = "<form action=$PHP_SELF method=post><input type=hidden name=vftp value=1>
<input type=hidden name=cmd value='List Files'>
<input type=submit name=ls value=$mess[86]>
</form>";



$lm = "$updtext: $lm";


if ($ref != "") {
include("scripts/topref.php");
}
$thtxt = "our Top 12 referers";
include("scripts/showtop.php");


// Now you need to place <? echo ".." tags within the template
// where you want your articles to be displayed
?>
