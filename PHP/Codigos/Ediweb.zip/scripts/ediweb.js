
<script language="JavaScript"><!--
function popadv() {
var win=window.open("http://www.maxi-web.net/home/popad.htm","Sponsors","width=468,height=140");
}
 //--></script>

<script language="JavaScript"><!--
function mwPOPINFO() {
var win=window.open("http://www.maxi-web.net/home/popinfo.htm","Important_Information","width=468,height=440, scrollbars, resizable");
}
 //--></script>


<script language="JavaScript"><!--
function FTPlogin() {
var win=window.open("ftp://ftp.maxi-web.net","Maxiweb_FTP_server","width=600,height=410, scrollbars, resizable");
}
 //--></script>

<script language="JavaScript"><!--
function nws(jsurl) {

var win=window.open(jsurl, 'Ediweb_news', 'width=250,height=280, scrollbars=yes,')
}
 //--></script>

<script language="JavaScript"><!--
function mwMYSQL() {
var win=window.open('http://www.maxi-web.net/mysql?logout=1', 'MySQL', 'width=600,height=410, scrollbars, resizable')
}
 //--></script>

<script language="JavaScript"><!--
function myEMAIL() {
var win=window.open('http://www.maxi-web.net/mail', 'MyEmail', 'width=700,height=450, scrollbars, resizable')
}
 //--></script>

<script language="JavaScript"><!--
function mwEUP() {
var win=window.open('http://www.maxi-web.net/home/edprofile.php?chg_profile=1', 'EditProfile', 'width=600,height=410, scrollbars, resizable')
}
 //--></script>

<script language="JavaScript" type="text/javascript">
<!--
// original code by Bill Trefzger 12/12/96
function go(){
if (document.selecter.select1.options[document.selecter.select1.selectedIndex].value != "none") {
location = document.selecter.select1.options[document.selecter.select1.selectedIndex].value
		}
	}
//-->
</script>
