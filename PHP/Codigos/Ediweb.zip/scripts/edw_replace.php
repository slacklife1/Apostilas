<?
// head  section
$tcontent = eregi_replace("<!--%EDW_STY%-->",$bstyle,$tcontent); // style
$tcontent = eregi_replace("<!--%EDW_JS%-->",$jssource,$tcontent); // javascript
$tcontent = eregi_replace("<!--%EDW_JSURL%-->",$jsurl,$tcontent); // javascript
$tcontent = eregi_replace("<!--%EDW_VER%-->",$edw_ver,$tcontent); // ProgID
$tcontent = eregi_replace("<!--%EDW_TL%-->",$t1,$tcontent); 

// body
$tcontent = eregi_replace("<!--%EDW_BAN%-->",$lban,$tcontent); // banner

$tcontent = eregi_replace("<!--%EDW_popinfo%-->",$popinfo,$tcontent); // onload popup
$tcontent = eregi_replace("<!--%EDW_new_today%-->",$new_today,$tcontent); // new users

$tcontent = eregi_replace("<!--%EDW_linkbarv%-->","<table cellspacing=0 cellpadding=10>$linkbarv</table>",$tcontent); // link bar V
$tcontent = eregi_replace("<!--%EDW_lm%-->",$lm,$tcontent); // banner
$tcontent = eregi_replace("<!--%EDW_topcolor%-->",$topcolor,$tcontent);
$tcontent = eregi_replace("<!--%EDW_mwlogo%-->",$logoT,$tcontent);
$tcontent = eregi_replace("<!--%EDW_adlogo%-->",$mwlogo,$tcontent);

$tcontent = eregi_replace("<!--%EDW_lvr%-->",$news_heading,$tcontent);

$tcontent = eregi_replace("<!--%EDW_datebox%-->",$datebox1,$tcontent);
$tcontent = eregi_replace("<!--%EDW_searchboxh%-->",$searchboxh,$tcontent);

$tcontent = eregi_replace("<!--%EDW_maincolor%-->",$maincolor,$tcontent); 
$tcontent = eregi_replace("<!--%EDW_leftcolor%-->",$leftcolor,$tcontent); 
$tcontent = eregi_replace("<!--%EDW_pagename%-->",$pagename,$tcontent); 

$tcontent = eregi_replace("<!--%EDW_t1%-->",$t1,$tcontent); 
$tcontent = eregi_replace("<!--%EDW_a1%-->",$a1,$tcontent); 
$tcontent = eregi_replace("<!--%EDW_t2%-->",$t2,$tcontent); 
$tcontent = eregi_replace("<!--%EDW_a2%-->",$a2,$tcontent); 
$tcontent = eregi_replace("<!--%EDW_t3%-->",$t3,$tcontent); 
$tcontent = eregi_replace("<!--%EDW_a3%-->",$a3,$tcontent); 
$tcontent = eregi_replace("<!--%EDW_t4%-->",$t4,$tcontent); 
$tcontent = eregi_replace("<!--%EDW_a4%-->",$a4,$tcontent); 
$tcontent = eregi_replace("<!--%EDW_refered%-->",$refered,$tcontent); 

$tcontent = eregi_replace("<!--%EDW_news%-->",$news,$tcontent); 
$tcontent = eregi_replace("<!--%EDW_linkbar%-->",$linkbar,$tcontent); 

$tcontent = eregi_replace("<!--%EDW_quicknav%-->",$quicknav,$tcontent); 

$tcontent = eregi_replace("<!--%EDW_copyr%-->",$copyr,$tcontent); 

?>