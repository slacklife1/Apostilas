<?
// showtop.php
// show top referers

if (!$thcolor) {
	$thcolor = "#A3A3D6";
}
if (!$thtxt) {
$thtxt = "Today's Top 12 Referers";
}
if (!$hcolor) {
	$hcolor = "#ffffff";
}

$jr = date("l");
switch($jr) {
case "Monday":
  $jrf = "lundi";
  break;

case "Tuesday":
  $jrf = "Mardi";
  break;
  
case "Wednesday":
  $jrf = "Mercredi";
  break;

case "Thursday":
  $jrf = "Jeudi";
  break;
  
 case "Friday":
  $jrf = "Vendredi";
  break;

case "Saturday":
  $jrf = "Samedi";
  break;
  
case "Sunday":
  $jrf = "Dimanche";
  break;
 }
 
$date = date("d/m/Y");
$jour = date("d");
$jour2 = date("d");
$mois = date("m");
$mois2 = date("m");
$annee = date("Y");
$nmois = date("F");
	$heure = date("H");
	$minute = date("i");
	$seconde = date("s");
	$heure2 = date("H");
	$minute2 = date("i");
	$seconde2 = date("s");
if (substr($heure,0,1) == "0") {
$heure2 = substr($heure,1,1);
}
if (substr($seconde,0,1) == "0") {
$seconde2 = substr($seconde,1,1);
}
if (substr($minute,0,1) == "0") {
$minute2 = substr($minute,1,1);
}

if (substr($mois2,0,1) == "0") {
$mois2 = substr($mois2,1,1);
}
if (substr($jour,0,1) == "0") {
$jour2 = substr($jour,1,1);
}

$today = "$jour/$mois/$annee";
$thetime = "$heure:$minute:$seconde";

$exval = mktime ($heure,$minute,$seconde,$mois,$jour,$annee);

	if ($dbpass) {
	$sid = mysql_connect($dbhost, $dbuser,$dbpass);
	}
	else {
	$sid = mysql_connect($dbhost, $dbuser);
	}
	$db = "maxi2";
mysql_select_db($db, $sid);
$query = "SELECT ref, hits, last, uri FROM refer ORDER by hits DESC ";
$reponse = mysql_query($query,$sid);
$show = 0;

// $reftbl0.= "<tr>";
//$reftbl.= "<td width=30>#</td>";
//$reftbl.= "<th><font face=arial,helvetica size=-1>Site</font></td>";
//$reftbl.= "<th width=160><font face=arial,helvetica size=-1>Request</font></td>";
//$reftbl.= "<th><font face=arial,helvetica size=-1>Last connection</font></td>";
// $reftbl.= "</tr>\n";
$col =1;

	while (($row = mysql_fetch_row($reponse)) && ($cnt < 12)) {
		
		$col++;
		$cnt++;
if ($cnt == 1) {
	$mrq = $row[3];
}
if ($cnt < 7) {
	$reftbl.= "<tr>";
$reftbl.= "<td align=right width=30><font face=arial,helvetica size=-1 color=#A3A3D6><i>$row[1]</i></font></td>";
$reftbl.= "<td>&nbsp;<font face=arial,helvetica size=-1><a href=http://$row[0] target=_blank>$row[0]</a></font>&nbsp;&nbsp;</td>";
// $reftbl.= "<td  width=160><i><font face=arial,helvetica size=-1>$row[1] &nbsp; <i>($row[3] hits)</i></font></i>&nbsp;</td>";
// $reftbl.= "<td><font face=arial,helvetica size=-1> $row[2]</font></td>";
$reftbl.= "</tr>\n";
	}
if ($cnt > 6) {
	$reftbl1.= "<tr>";
$reftbl1.= "<td align=right width=30><font face=arial,helvetica size=-1 color=#A3A3D6><i>$row[1]</i></font></td>";
$reftbl1.= "<td>&nbsp;<font face=arial,helvetica size=-1><a href=http://$row[0] target=_blank>$row[0]</a></font>&nbsp;&nbsp;</td>";
// $reftbl.= "<td  width=160><i><font face=arial,helvetica size=-1>$row[1] &nbsp; <i>($row[3] hits)</i></font></i>&nbsp;</td>";
// $reftbl.= "<td><font face=arial,helvetica size=-1> $row[2]</font></td>";
$reftbl1.= "</tr>\n";
	}

if ($cnt > 12) {
	$reftbl2.= "<tr>";
$reftbl2.= "<td align=right width=30><font face=arial,helvetica size=-1 color=#A3A3D6><i>$row[1]</i></font></td>";
$reftbl2.= "<td>&nbsp;<font face=arial,helvetica size=-1><a href=http://$row[0] target=_blank>$row[0]</a></font>&nbsp;&nbsp;</td>";
// $reftbl.= "<td  width=160><i><font face=arial,helvetica size=-1>$row[1] &nbsp; <i>($row[3] hits)</i></font></i>&nbsp;</td>";
// $reftbl.= "<td><font face=arial,helvetica size=-1> $row[2]</font></td>";
$reftbl2.= "</tr>\n";
	}
}
	
$refered = "<table border=0 cellspacing=0 cellpadding=0 align=center>
<tr>
<th bgcolor=$thcolor colspan=3><font face=arial,helvetica color=$hcolor size=-1>$thtxt</font></th>
</tr>\n
<tr>
<td bgcolor=$dlbg2><table border=0 cellspacing=0 cellpadding=0 align=center width=90%>$reftbl</table></td>
<td bgcolor=$dlbg2><table border=0 cellspacing=0 cellpadding=0 align=center width=90%>$reftbl1</table></td>
</tr>

</table>";


?>
