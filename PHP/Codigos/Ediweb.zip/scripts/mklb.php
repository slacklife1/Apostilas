<?
$pg = urlencode($page);
if ($page == "$edito" && $edito != $menu_index) {
$icbg = 1;	
}
			
$linkbar.= "&nbsp;<A HREF=\"$href\">$page</A></b> ";

$linkbarv.= "<tr><td  align=left class=\"button\" align=left>
		<img src=\"ic_category.gif\" width=15 height=12 alt=\"%s\" vspace=1 align=top> <b>
		<A HREF=\"$href\">$page</A></b></td></tr>";

$dlinkbar2.= "<tr><TD align=center WIDTH=14 BGCOLOR=\"$dlinkcolor\"><A HREF=\"$href\"><img src=$icon border=$icbg align=middle></A></td><TD id='$tdid' WIDTH=85 BGCOLOR=\"$dlinkcolor\">
		<A HREF=\"$href\" onmouseover=\"highlight('$tdid')\" style=\"COLOR: $linkcolor; TEXT-DECORATION: none\" 
		onmouseout=\"unhighlight('$tdid')\"><FONT SIZE=\"-1\" FACE=\"verdana, tahoma, arial, ms sans serif, helvetica, helv\">$page</FONT></A>
		</TD></tr>";
		
$dlinkbar3.= "<TD id='$tdid' WIDTH=101 BGCOLOR=\"$dlbg\"><CENTER>
		<A HREF=\"$href\" onmouseover=\"highlight('$tdid')\" style=\"COLOR: #000000; TEXT-DECORATION: none\" onmouseout=\"unhighlight('$tdid')\">
		<FONT SIZE=\"-2\" FACE=\"verdana, tahoma, arial, ms sans serif, helvetica, helv\">$page</FONT></A></CENTER></TD>";
		
$icon = "icons/html.gif";
$icbg = 0;	
		

?>
