<?
$pg = urlencode($page);
if ($page == "$edito" && $edito != $menu_index) {
$icbg = 1;	
}
if (eregi("members", $REQUEST_URI, $match)) {
	$icon = "../$icon";
}
			
$linkbar.= "[<A HREF=\"$href\">$page</A>]&nbsp;&nbsp;";

$linkbarv.= "<img src=\"$icon\" width=20 height=20 alt=\"$tdid\" vspace=1 align=absmiddle> <b>
		<A HREF=\"$href\" 
		style=\"COLOR: $lcolor; font-size: 10px; HOVER: TEXT-DECORATION: none\"$btarget>$page</A></b><br>";

$dlinkbar2.= "<tr>
<TD align=center WIDTH=14 BGCOLOR=\"$dlinkcolor\"><A HREF=\"$href\"><img src=$icon border=$icbg align=middle></A></td>
<TD id='$tdid' WIDTH=116 BGCOLOR=\"$dlinkcolor\">
<A HREF=\"$href\" onmouseover=\"highlight('$tdid')\" 
style=\"COLOR: $linkcolor; TEXT-DECORATION: none\" 
onmouseout=\"unhighlight('$tdid')\"><FONT SIZE=\"-1\" FACE=\"verdana, tahoma, arial, ms sans serif, helvetica, helv\">&nbsp;$page</FONT></A>
</TD>
		</tr>";
		
$dlinkbar3.= "<TD id='$tdid' WIDTH=101 BGCOLOR=\"$dlinkcolor\"><CENTER>
		<A HREF=\"$href\" onmouseover=\"highlight('$tdid')\" style=\" TEXT-DECORATION: none\" onmouseout=\"unhighlight('$tdid')\">
		<FONT SIZE=\"-2\" FACE=\"verdana, tahoma, arial, ms sans serif, helvetica, helv\">$page</FONT></A></CENTER></TD>";

$quicknav.= "<option value=\"$href\">$page</option>\n";
		
$icon = "icons/html.gif";
$icbg = 0;	
unset($btarget);		

?>
