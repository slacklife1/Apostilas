<?

if (!$cmd) {
header("Location: $PHP_SELF?vftp=1&cmd=List+Files");
}
// $ftp_server = "localhost";
function fitype($filename,$quoi) {
global $mess;

	if(is_dir($filename)){$icon="dossier.gif";$nom_type=$mess[8];}
	else if(eregi("\.mid$",$filename)){$icon="mid.gif";$nom_type=$mess[9];}
	else if(eregi("\.txt$",$filename)){$icon="txt.gif";$nom_type=$mess[10];}
	else if(eregi("\.sql$",$filename)){$icon="txt.gif";$nom_type=$mess[10];}
	else if(eregi("\.js$",$filename)){$icon="js.gif";$nom_type=$mess[11];}
	else if(eregi("\.gif$",$filename)){$icon="gif.gif";$nom_type=$mess[12];}
	else if(eregi("\.jpg$",$filename)){$icon="jpg.gif";$nom_type=$mess[13];}
	else if(eregi("\.html$",$filename)){$icon="html.gif";$nom_type=$mess[14];}
	else if(eregi("\.htm$",$filename)){$icon="html.gif";$nom_type=$mess[15];}
	else if(eregi("\.rar$",$filename)){$icon="rar.gif";$nom_type=$mess[60];}
	else if(eregi("\.gz$",$filename)){$icon="zip.gif";$nom_type=$mess[61];}
	else if(eregi("\.tgz$",$filename)){$icon="zip.gif";$nom_type=$mess[61];}
	else if(eregi("\.z$",$filename)){$icon="zip.gif";$nom_type=$mess[61];}
	else if(eregi("\.ra$",$filename)){$icon="ram.gif";$nom_type=$mess[16];}
	else if(eregi("\.ram$",$filename)){$icon="ram.gif";$nom_type=$mess[17];}
	else if(eregi("\.rm$",$filename)){$icon="ram.gif";$nom_type=$mess[17];}
	else if(eregi("\.pl$",$filename)){$icon="pl.gif";$nom_type=$mess[18];}
	else if(eregi("\.zip$",$filename)){$icon="zip.gif";$nom_type=$mess[19];
	$vzip = "<font size=1>view</font>";}
	else if(eregi("\.wav$",$filename)){$icon="wav.gif";$nom_type=$mess[20];}
	else if(eregi("\.php$",$filename)){$icon="php.gif";$nom_type=$mess[21];}
	else if(eregi("\.php3$",$filename)){$icon="php.gif";$nom_type=$mess[22];}
	else if(eregi("\.phtml$",$filename)){$icon="php.gif";$nom_type=$mess[22];}
	else if(eregi("\.exe$",$filename)){$icon="exe.gif";$nom_type=$mess[50];}
	else if(eregi("\.bmp$",$filename)){$icon="bmp.gif";$nom_type=$mess[56];}
	else if(eregi("\.png$",$filename)){$icon="gif.gif";$nom_type=$mess[57];}
	else if(eregi("\.css$",$filename)){$icon="css.gif";$nom_type=$mess[58];}
	else if(eregi("\.mp3$",$filename)){$icon="mp3.gif";$nom_type=$mess[59];}
	else if(eregi("\.xls$",$filename)){$icon="xls.gif";$nom_type=$mess[64];}
	else if(eregi("\.doc$",$filename)){$icon="doc.gif";$nom_type=$mess[65];}
	else if(eregi("\.pdf$",$filename)){$icon="pdf.gif";$nom_type=$mess[79];}
	else if(eregi("\.mov$",$filename)){$icon="mov.gif";$nom_type=$mess[80];}
	else if(eregi("\.avi$",$filename)){$icon="avi.gif";$nom_type=$mess[81];}
	else if(eregi("\.mpg$",$filename)){$icon="mpg.gif";$nom_type=$mess[82];}
	else if(eregi("\.mpeg$",$filename)){$icon="mpeg.gif";$nom_type=$mess[83];}
	else {
        $icon="defaut.gif";$nom_type=$mess[23];
        }
	if($quoi=="icon"){
        return $icon;
        } elseif($quoi=="vzip"){
        return $vzip;
        } else {
        return $nom_type;
        }
}

function finfo($file, $st="") {

	$fistat = stat($list[$i]);
	
	if ($st == "mod") {
	$fimod = date("H:i:s F d, Y",$fistat[9]);
	return $fimod;
	}
	else {
	$fisize = $fistat[7];
	$ksize = $fisize/1024;
	$msize = $ksize/1024;
	$fslabel = "$fisize K";
	if ($ksize >= 1) {
	$fslabel = "$ksize Ko";
	}
	elseif ($msize >= 1) {
	$fslabel = "$msize Mo";
	}
	return $fslabel;
	}
}

function view_dir($directory) {
global $ftp_server;
global $username;
global $userpass;
global $conn_id;
global $sub_dir;
global $thisdir;
global $mess;


$fldr = "
<input type=hidden name=cmd value='NewFolder'>
<input type=hidden name=mynewpath value=\"$directory\"><input type=text name=mynewdir size=10>&nbsp;<input type=submit name=mk value=\"$mess[26]\">
<hr color=orange size=1>$directory<br>
";
if ($directory != "/home/$username") {
$fldr.= "<img src=/home/icons/parent.gif align=middle border=0>&nbsp; <a href=$PHP_SELF?vftp=1&cmd=List+Files&up_dir=><i><b>.Home</b></I></A><br>";
}

if ($sub_dir && $thisdir != "/home/$username" && $thisdir != "/home/$username") {
$icon = "fleche1.gif";

$fldr.= "<img src=/home/icons/$icon align=middle border=0>&nbsp; 
<a href=$PHP_SELF?vftp=1&cmd=List+Files&sub_dir=$thisdir><i><b>.. Up</b></i></A>
<br>";
}

$list=Array(); 
$list=ftp_nlist($conn_id, "$dir");
if ($list != "") {
sort($list);
reset($list);
}
$i=0;
$webpath = ereg_replace("/home", "", $directory);

while($list[$i]) {
	 chop($list[$i]);
	if (is_dir("/$directory/$list[$i]")) {
	$icon = "dossier.gif";

	$fldr.= "<img src=/home/icons/$icon border=0 align=middle><b>";
	$fldr.= "&nbsp;<a href=$PHP_SELF?vftp=1&cmd=List+Files&thisdir=$directory&sub_dir=$directory/$list[$i]>$list[$i]</A>
	</b><br>";
	}
	else {
	$icon = fitype($list[$i],"icon");
//	$vzip = fitype($list[$i],"vzip");
	$addinfo = fitype($list[$i],"");
//	$fslabel = finfo($list[$i]);
//	$fimod = finfo($list[$i], "mod");
	$fls.= "<tr>";
	$fls.= "<td width=20 bgcolor=#DDDDFF><img src=/home/icons/$icon border=0 alt=\"$addinfo\"></td>";
	$fls.= "<td width=280 bgcolor=#DDDDFF>&nbsp;<a href=\"ftp://$username:$userpass@ftp.maxi-web.net/home/$username/$list[$i]\"><font face=arial,helvetica size=-1>$list[$i]</font></A> &nbsp;<font size=1>(<a href=\"http://www.maxi-web.net$webpath/$list[$i]\">view</A>)</font> <a href=$PHP_SELF?vftp=1&cmd=zip&file=$list[$i]>$vzip</A></td>";
	$fls.= "<td align=left bgcolor=#DDDDFF><font size=1 color=brown face=arial>$addinfo</font></td>";
//	$fls.= "<td bgcolor=#DDDDFF><font face=arial size=1>&nbsp;$fslabel</font></td>";
//	$fls.= "<td bgcolor=#DDDDFF><font face=arial size=1>&nbsp;$fimod</font></td>";
	$fls.= "<td width=20 bgcolor=#DDDDFF><a href=$PHP_SELF?vftp=1&cmd=Rename&file=$list[$i]><img src=/home/icons/renommer.gif border=0 alt=\"$mess[6]\"></A></td>";
	$fls.= "<td width=20 bgcolor=#DDDDFF><a href=$PHP_SELF?vftp=1&cmd=Delete&file=$list[$i]><img src=/home/icons/supprimer.gif border=0 alt=\"$mess[7]\"></A></td>";
  	$fls.= "</tr>";
	}
$i++;
}

$tbl = "<table border=0 cellspacing=2 cellpadding=2 width=100%>
<tr>
<td align=center bgcolor=#ddddff valig=top><font color=#666699><!--%EDWA_top_form%--></font>
</td></form>
</tr><tr>
<td ><table border=0 cellspacing=0 cellpadding=1 width=100%>
<tr><form action=$PHP_SELF method=post>
<input type=hidden name=vftp value=1>
<td bgcolor=#DDDDFF valign=top><font face=verdana size=-1>$fldr</font></form>
</td><td align=right valign=top bgcolor=#DDDDFF>
<!--%EDWA_ls_form%--><br>
<table border=0 cellspacing=0 cellpadding=0 width=100%>
<tr><tr><td valign=top colspan=5><hr color=orange size=1></td></tr>
<td width=20><img src=/home/icons/defaut.gif border=0></td>
<th width=280 align=left><font face=arial size=-1>$mess[1]</font></td>
<th align=left><font face=arial size=-1>$mess[3]</font></td>
<th width=20><font face=arial size=1>";
$tbl.= substr($mess[6],0,3);
$tbl.= "</font></td>
<th width=20><font face=arial size=1>";
$tbl.= substr($mess[7],0,3);
$tbl.= "</font></td>

</tr>
$fls</table>
</td>
</tr></table></form></td></tr>
<tr><td bgcolor=silver valign=top>
</td></tr>
</table>";

return $tbl;
}

$top_form = "
<form ENCTYPE=multipart/form-data action=$PHP_SELF method=post>
<input type=hidden name=vftp value=1>
<input type=hidden name=cmd value='Send File'>
<b>$mess[25]:</b><input type=file name=source_file>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=submit value=$mess[27]>
";


$ls_form = "<form action=$PHP_SELF method=post>
<input type=hidden name=vftp value=1>
<input type=hidden name=cmd value='List Files'>
<input type=submit name=ls value='$mess[86] / $mess[85]'>
";

if ($cmd) {
// set up basic connection
$conn_id = ftp_connect($ftp_server); 

// login with username and password
$login_result = ftp_login($conn_id, $username, $userpass); 

	// check connection
	if ((!$conn_id) || (!$login_result)) { 
        $err = "$mess[75]";
//        $err.= "Attempted to connect to server for user $username"; 
        die; 
    	} 
	else {
        $err = "$mess[72]";
    	} 
switch ($cmd) {

case "Send File" :
// upload the file
if ($destination_file == "") {
$destination_file = $source_file_name;
}
$upload = ftp_put($conn_id, $destination_file, $source_file, ftp_BINARY); 
// $upload = ftp_put($conn_id, $source_file_name, $source_file, FTP_BINARY); 

// check upload status
if (!$upload) { 
$err = "FTP upload has failed!";
} 
else {
$err = "$destination_file Uploaded  to server";
}
break;	

case "List Files" :
if ($sub_dir) {
ftp_chdir($conn_id, $sub_dir);
}
elseif($up_dir) {
ftp_cdup($conn_id);
}
$dir=ftp_pwd($conn_id);
$listing = view_dir($dir);
break;

case "NewFolder" :
ftp_chdir($conn_id, $mynewpath);

if (!ftp_mkdir($conn_id, $mynewdir)) {
$err = "ERROR creating Directory $mynewdir";
}
else {
$err = "$mess[38] $mynewdir $mess[39]";
}

// ftp_cdup($conn_id);
$dir=ftp_pwd($conn_id);
$listing = view_dir($dir);

break;

case "Delete" :

if ($cmdconfirm == 1) {

ftp_delete($conn_id, $file);
$errf = "<p>File $file was deleted !";
if ($sub_dir) {
ftp_chdir($conn_id, $sub_dir);
}
elseif($up_dir) {
ftp_cdup($conn_id);
}
$dir=ftp_pwd($conn_id);
$listing = view_dir($dir);

}
else {
$listing = "
<table cellpadding=10 cellspacing=0 border=0 align=center><tr><td align=center bgcolor=#ddddff>
<table align=center><tr><th>Delete $file ?
<p><img src=/icons/alert.red.gif alt=\"Rename $file\"> &nbsp; 
<a href=$PHP_SELF?vftp=1&cmd=$cmd&file=$file&cmdconfirm=1>YES</a> &nbsp; <a href=$PHP_SELF?vftp=1&cmd=List+Files>NO</a></p>
</td></tr></table>
</td></tr></table>
";

}
break;

case "Rename" :

if ($cmdconfirm == 1) {

ftp_rename($conn_id, $file, $newfilename);
$errf = "<p>File $file was renamed to $newfilename !";
if ($sub_dir) {
ftp_chdir($conn_id, $sub_dir);
}
elseif($up_dir) {
ftp_cdup($conn_id);
}
$dir=ftp_pwd($conn_id);
$listing = view_dir($dir);

}
else {

$top_form = "<table cellpadding=1 boder=0  cellspacing=0 align=center>

<tR><form action=$PHP_SELF method=post><input type=hidden name=vftp value=1>
<td align=left bgcolor=silver><img src=/icons/alert.red.gif alt=\"Rename $file\">

<b>Rename <font color=red>$file</font></b> to: <input type=text size=10 name=newfilename>
<input type=hidden name=cmdconfirm value=1>
<input type=hidden name=file value=$file> &nbsp; 
<input type=submit name=cmd value=$cmd>
</td></form></tr></table>
";

if ($sub_dir) {
ftp_chdir($conn_id, $sub_dir);
}
elseif($up_dir) {
ftp_cdup($conn_id);
}
$dir=ftp_pwd($conn_id);
$listing = view_dir($dir);

}


break;

case "zip" :
$zip = zip_open("$file");


    while ($zip_entry = zip_read($zip)) {
        $listing.=  "Name:               " . zip_entry_name($zip_entry) . "\n";
        $listing.=  "Actual Filesize:    " . zip_entry_filesize($zip_entry) . "\n";
        $listing.=  "Compressed Size:    " . zip_entry_compressedsize($zip_entry) . "\n";
        $listing.=  "Compression Method: " . zip_entry_compressionmethod($zip_entry) . "\n";

        if (zip_entry_open($zip, $zip_entry, "r")) {
            $listing.=  "File Contents:\n";
            $buf = zip_entry_read($zip_entry, zip_entry_filesize($zip_entry));
            $listing.=  "$buf\n";

            zip_entry_close($zip_entry);
        }
        $listing.= "\n";

    }

    zip_close($zip);

break;

}
// close the FTP stream 
ftp_quit($conn_id); 

}

$t1 = "$err $errf";
// $edt = "<table cellpadding=1 boder=0  cellspacing=0 align=center>";
// $edt.= "<tr><td align=left bgcolor=#666699 colspan=2><font color=white size=1 face=fixedsys><i>$err $errf</i></font></td></tr>";
// $edt.= "<tr><td>$top_form</td><td>$ls_form</td></tr>";
// $edt.= "<tr><td align=center bgcolor=orange colspan=2>$listing</td></tr>";
// $edt.= "<tr><td align=left bgcolor=#666699 colspan=2><font color=orange size=-1 face=verdana,arial,helvetica><b>MWVftp></b></font> <font color=white size=-1 face=fixedsys><i>$err</i></font></td></tr>";
$edt = "$listing<center>$toph</center>";

$buttons = "$top_form $ls_form";
$edt = eregi_replace("<!--%EDWA_top_form%-->",$top_form,$edt); 
$edt = eregi_replace("<!--%EDWA_ls_form%-->",$ls_form,$edt); 

?>

