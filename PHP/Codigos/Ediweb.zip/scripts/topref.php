<?
// topref.php
// maintain a top referer database


$jr = date("l");
switch($jr) {
case "Monday":
  $jrf = "lundi";
  break;

case "Tuesday":
  $jrf = "Mardi";
  break;
  
case "Wednesday":
  $jrf = "Mercredi";
  break;

case "Thursday":
  $jrf = "Jeudi";
  break;
  
 case "Friday":
  $jrf = "Vendredi";
  break;

case "Saturday":
  $jrf = "Samedi";
  break;
  
case "Sunday":
  $jrf = "Dimanche";
  break;
 }
 
$date = date("d/m/Y");
$jour = date("d");
$jour2 = date("d");
$mois = date("m");
$mois2 = date("m");
$annee = date("Y");
$nmois = date("F");
	$heure = date("H");
	$minute = date("i");
	$seconde = date("s");
	$heure2 = date("H");
	$minute2 = date("i");
	$seconde2 = date("s");
if (substr($heure,0,1) == "0") {
$heure2 = substr($heure,1,1);
}
if (substr($seconde,0,1) == "0") {
$seconde2 = substr($seconde,1,1);
}
if (substr($minute,0,1) == "0") {
$minute2 = substr($minute,1,1);
}

if (substr($mois2,0,1) == "0") {
$mois2 = substr($mois2,1,1);
}
if (substr($jour,0,1) == "0") {
$jour2 = substr($jour,1,1);
}

$today = "$jour/$mois/$annee";
$thetime = "$heure:$minute:$seconde";

$exval = mktime ($heure,$minute,$seconde,$mois,$jour,$annee);

if (!$sid) {
	if ($dbpass) {
	$sid = mysql_connect($dbhost, $dbuser,$dbpass);
	}
	else {
	$sid = mysql_connect($dbhost, $dbuser);
	}
}
	
mysql_select_db($db, $sid);

$rf = split("/",$ref,4);
$rfdomain = $rf[2];
    
    if ($rfdomain != "www.maxi-web.net" 
    && $rfdomain != "maxi-web.net" 
    && $rfdomain != "www.qq2001.hn.org"
    && $rfdomain != "194.250.150.250"
    && $rfdomain != "qq2001.hn.org") {
	$query = "SELECT hits FROM refer WHERE ref = \"$rfdomain\" ";
	$reponse = mysql_query($query, $sid);
		if (mysql_num_rows($reponse)) {
			while ($row = mysql_fetch_row($reponse)) {
			$qry = "UPDATE refer SET hits = $row[0]+1, ";
			$qry.= "last = \"$annee-$mois-$jour $heure:$minute:$seconde\" ";
			$qry.= "WHERE ref = \"$rfdomain\" ";
			}
		}
		else {
		$qry = "INSERT INTO refer VALUES ( ";
		$qry.= "0, \"$rfdomain\", 1, \"$annee-$mois-$jour $heure:$minute:$seconde\", \"$ip\", \"$doc\") ";
		}
	$reponse = mysql_query($qry, $sid);
	}
	
?>
