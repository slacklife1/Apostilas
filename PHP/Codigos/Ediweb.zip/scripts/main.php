<?

$ip = $REMOTE_ADDR;
$os = $HTTP_USER_AGENT;
$ref = $HTTP_REFERER;
$doc = $REQUEST_URI;

function read_file($strfile) {
	if(!file_exists($strfile)) return;
	$thisfile = file($strfile);
	while(list($line,$value) = each($thisfile)) {
		$value = ereg_replace("\r","",$value);
		$value = ereg_replace("\n","",$value);
		$result .= "$value\r\n";
	}
	return $result;
}


if (!$lg) {
$lg = "fr";
$main_table = "edifr";
$Contact_us = "Contactez-nous";
$hv = "Accueil";
setcookie("main_table");
setcookie("main_table", "$main_table", time()+1008000, "/");
setcookie("lg");
setcookie("lg", "$lng", time()+1008000, "/");
}

if ($lng == "en") {
$lg = $lng;
$main_table = "edito";
$Contact_us = "Contact us";
$hv = "Home";
setcookie("main_table");
setcookie("main_table", "$main_table", time()+1008000, "/");
setcookie("lg");
setcookie("lg", "$lng", time()+1008000, "/");
}

elseif ($lng == "fr") {
$lg = $lng;
$main_table = "edifr";
$Contact_us = "Contactez-nous";
$hv = "Accueil";
setcookie("main_table");
setcookie("main_table", "$main_table", time()+1008000, "/");
setcookie("lg");
setcookie("lg", "$lng", time()+1008000, "/");
}


if ($si) {
$incdir ="/var/www/includes";
include("scripts/$incdir/ha.php");
$regres = "<font face=arial,helvetica,sans>$prt</font>";
}
include("scripts/icode.php");
if ($regres) {
$a1 = $regres;
}

// include("scripts/show_new_users.php");
$jssource = read_file($js_template);
$tcontent = read_file("themes/$edw_theme/$page_template");

include("scripts/edw_replace.php");
echo($tcontent);

?>

