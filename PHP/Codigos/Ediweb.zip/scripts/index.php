<? 
// include("config.php");
header("Location: ../");
exit;
?>