<?
// Ediweb config
// ver. 2.03

// upload the distribution to your web site's root directory
// Make sure this file and all scripts are located in the scripts
// sub directory and all themes are in the themes sub directory.

// Files index.php, ediwebadmin.php, jwin.php and jwin.jtml
// should be left in the root directory.

// You must at least go through section 1 to 3 and setup the
// required values for your web site. The other sections can
// be left to their default values. Section 11 and below should
// only be modified by advanced users.

// Once you have setup at least section 1 and 2, you can run the install.php script
// to create the tables and launch the site administration control panel. Delete or
// move the install.php file after running it.
// Alternatively, you can create the database tables from the ediweb.sql file
// supplied in the distribution.

// enjoy !


// 1 MySQL database connection info
$dbhost = "localhost";					// database server hostname or ip
$dbuser = "username";					// database server username
$dbpass = "password";					// database server password
$db = $dbuser;						// database name

// 2 user, website and domain
$user_domain = "domain.com";				// domain name
$siteadminemail = "email@domain.com";			// site administrator email
$sitbaseeurl = "www.domain.com";	 		// web site URL (without the http://)
$sitename= "Ediweb";					// web site name

// 3 FTP conection
$ftp_server = "localhost";				// FTP server hostname or ip
$username = $dbuser;					// FTP username
$userpass = $dbpass;					// FTP password

// 3b logos and links
$logo = "http://www.maxi-web.net/ediweb/ediweb.gif";	// logo image src URL
$adlogo = "http://www.maxi-web.net/home/mw1logo.gif";	// additional logo image src URL
$adlogourl = "http://www.maxi-web.net";			// additional logo link URL




// 4 exclude links
// list of word or partial word separated by a white space
// the navigation engine will not show links to articles containing
// these words in their name (acode field)
$excl = "edito edifr ediwebsupport";

if ($REMOTE_ADDR != "194.250.150.253") {
$excl.= " admin";
}

// 5 template engine configuration
$page_template = "page1.html";
$js_template = "ediweb.js";

// 5b banner code
$lban = "<center>
<!-- Banniere ClickFR --><center><IFRAME NAME=iclickfr SRC=http://www4.click-fr.com/printk.cgi?a=1023-1908723&b=20 width=468 height=60 MARGINWIDTH=0 MARGINHEIGHT=0 HSPACE=0 VSPACE=0 FRAMEBORDER=0 SCROLLING=no>
<SCRIPT LANGUAGE=JavaScript> var nbre = Math.round(Math.random()*100000);
var chaine=\"<a href=http://www4.click-fr.com/clickj.cgi?a=1023-1908723&b=\" + nbre + \" target=clickfr><img border=0  height=60 width=468  SRC=http://www4.click-fr.com/printj.cgi?a=1023-1908723&b=\" + nbre +\" alt='*** Visitez notre Sponsor ! ***'></a>\";
document.write(chaine);
</SCRIPT></IFRAME><font size=1><br><a href=http://www.click-fr.com>Membre de ClickFR, Reseau francophone Paie-Par-Click</a></font></center>
<!-- Fin Banniere ClickFR -->
</center>";

$logoT = "<br><table cellspacing=0 cellpadding=2 align=center>
<tr><td align=center valign=middle><a href=http://$sitbaseeurl target=_blank><img src=\"$logo\" border=0></a>
</td></tr></table><br>";


// 6 default theme
$edw_theme = "default";




// 7 news options
$news_ttl = 0;	// TimeToLive number of days to keep news messages, set to 0 to keep forever
$news_post = 0;	// set to 1 to allow new messages threads
$news_reply = 0;	// set to 1 to allow replies to messages

// 8 forum options
$forumname = "Forum";	// forum page name
$ttl = 0;	// TimeToLive number of days to keep messages, set to 0 to keep forever
$post = 1;	// set to 1 to allow new messages threads
$reply = 1;	// set to 1 to allow replies to messages

// 9 basic programm options
$multi = 1;		// set to 1 to use sub articles
$useexpire = "no";	// set to no to display expired articles in link bars

// 10 colors
$tcolor = "#006666";
$bcolor = "#FFFFFF";
$lhcolor = 'orange';
$lvcolor = "brown"; // visited link color
$lcolor = "brown";
$textcolor = $tcolor;
$bgcolor = "#ffffff"; // background color

$leftcolor = "#006666";
$topcolor = "#FFFFFF";
$maincolor = "#FFFFFF";

$c_titre = "black";	// heading color
$c_texte1 = "#005984"; // text color
$ol = "navy";	// oredered list color
$ul = "#005984";	// list color
$dlbg = "#A3A3D6";

$bstyle = "body {
scrollbar-face-color:#6699CC;
scrollbar-arrow-color:#000000;
scrollbar-track-color:#99CCFF;
scrollbar-shadow-color:'#000000';
scrollbar-highlight-color:'#99CCFF';
scrollbar-3dlight-color:'#000000';
scrollbar-darkshadow-Color:'#000000';
td { font-family:arial,helvetica,sans; font-size: 12px; color:$textcolor}";
$bstyle.= ".button       { border: 1 solid $lcolor; }";
$bstyle.=  ".button-Over { background-color: $lcolor; border: 1 solid $textcolor }";
$bstyle.= "A { COLOR: $lcolor; TEXT-DECORATION: none }";
$bstyle.= "A:hover { color: $lhcolor; TEXT-DECORATION:underline }";

$tbl_style1 = "class=\"button\"";



// 11 online administration
$siteadmin = $dbuser;
$sitepass = $dbpass;
$adminsc = "ediwebadmin.php";			# admin script name
$pagehead = "top2.htm";
$pagefoot = "foot2.htm";

// 12 optional configuration for advanced usage
$adminrealm = "";
$fpage = "news.php";
$head = $pagehead; 	// used only if $sa is set to 2
$foot = $pagefoot;	// used only if $sa is set to 2

// 12b user login
$usertable = "user";
$userfieldnum = 2;
$emailfieldnum = 2;
$passfieldnum = 16;
$userfieldname = "nickname";
$emailfieldname = "email";
$passfieldname = "password";


// 12c member section
$realm = "/members";




// end config
$lup = date("d/m/Y - H:i", filemtime($PATH_TRANSLATED)); 

?>