<?
// ediweb 2
// adminlib.php

$authid = "$admi";
// admin functions
if ($addauthor) {

	if (!$npass || !$nemail || $nauthor == "" || $nemail == "") {
	$mkauthor = "<form action=$PHP_SELF method=post>
	<b>$am0</b><br>
	$m4:<br><input type=text name=nauthor value=\"$nauthor\"><br>
	$am1:<br><input type=text name=npass value=\"$npass\"><br>
	Email:<br><input type=text name=nemail value=\"$nemail\"><p>
	<input type=submit name=addauthor value=$am2></form>"; 
	
	}
	else {
	$query = "INSERT INTO authors ";
	$query.= "VALUES ( ";
	$query.= "\"$nauthor\", ";
	$query.= "\"$npass\", ";
	$query.= "\"$nemail\") ";
	$done = "ADDED";
	$acq = mysql_query($query, $sid);
	// $acq = mysql_insert_id($sid);

		if ($acq == 0) {
		$mkauthor =  "<font size=1>ERROR: $m7 $nauthor NOT $done !</font><p>$mkauthor";
		}
		else {
		$mkauthor =  "$m7 $nauthor is $done ! <p>$mkauthor";
		$edito = "";	
		}	
	}
	
}	// end addauthor


	
elseif ($searchauthor) {
$query = "SELECT * FROM authors ";
$query.= "WHERE author LIKE \"%$nauthor%\" ";
$query.= "OR pass LIKE \"%$nauthor%\" ";
$query.= "OR email LIKE \"%$nauthor%\" ";
	
$reponse = mysql_query($query, $sid);

$alist = "<font size=1><table>";
$alist2.= "<tr><td><font size=1><b>$m4</b></font></td>
			<td><font size=1>Email</font></td>
			<td><font size=1>$am3</font></td>
			<td><font size=1>Edit</font></td>
			</tr>";
	
	while ($row = @mysql_fetch_row($reponse))  {
	$found++;
	$alist.= "<tr><td><font size=1><b>$row[0]</b></font></td>
			<td><font size=1>$row[2]</font></td>
			<td><font size=1><a href=$PHP_SELF?deleteauthor=1&nauthor=$row[0]>$am3</A></font></td>
			<td><font size=1><a href=$PHP_SELF?editauthor=1&nauthor=$row[0]>Edit</A></font></td></tr>";
	}

$alist.= "</table>";
		
$mkauthor = "$alist<form action=$PHP_SELF method=post>
	$m7: <input type=text name=nauthor value=\"$nauthor\"><br>
	<input type=submit name=searchauthor value=$am4>&nbsp;
	<input type=submit name=addauthor value=$am2>&nbsp;
	<input type=submit name=delauthor value=$am3>
	</form><br>$mkauthor";
}	// end searchauthor



elseif ($editauthor) {
$query = "SELECT * FROM authors ";
$query.= "WHERE author = \"$nauthor\" ";
	
$reponse = mysql_query($query, $sid);
$alist = "<font size=1>Edit author:<form action=$PHP_SELF method=post><br>";
	while ($row = @mysql_fetch_row($reponse))  {
	$found++;
	$alist.= "
	$m4:<br><input type=text name=nauthor value=\"$nauthor\"><br>
	$am1:<br><input type=text name=npass value=\"$row[1]\"><br>
	Email:<br><input type=text name=nemail value=\"$row[2]\"><p>
	<input type=submit name=modauthor value=$m2></form>";
	}
$alist.= "</font>";
		
$mkauthor = "$alist<br>$mkauthor";
}	// end editauthor



elseif ($modauthor) {
$query = "UPDATE authors ";
$query.= "SET ";
$query.= "author = \"$nauthor\", ";
$query.= "pass = \"$npass\", ";
$query.= "email = \"$nemail\" ";
$done = "UPDATED";

$acq = mysql_query($query, $sid);
// $acq = mysql_insert_id($sid);

	if ($acq != 0) {
	$mkauthor =  "<font size=1>ERROR: author $nauthor NOT $done !</font><p>$mkauthor";
	}
	else {
	$mkauthor =  "$m7 $nauthor is $done ! <form action=$PHP_SELF method=post>
	$m7: <input type=text name=nauthor value=\"$nauthor\"><br>
	<input type=submit name=searchauthor value=$am4>&nbsp;
	<input type=submit name=addauthor value=$am2>&nbsp;
	<input type=submit name=delauthor value=$am3>
	</form>";
	$edito = "";	
	}	

}	// end modautor


elseif ($deleteauthor) {
$query = "DELETE FROM authors ";
$query.= "WHERE author = \"$nauthor\" ";
	
$done = "DELETED";

$acq = mysql_query($query, $sid);
// $acq = mysql_insert_id($sid);

	if ($acq == 0) {
	$mkauthor =  "<font size=1>ERROR: author $nauthor NOT $done !</font><p>$mkauthor";
	}
	else {
	$mkauthor =  "$m7 $nauthor is $done ! <form action=$PHP_SELF method=post>
	$m7: <input type=text name=nauthor value=\"$nauthor\"><br>
	<input type=submit name=searchauthor value=$am4>&nbsp;
	<input type=submit name=addauthor value=$am2>&nbsp;
	<input type=submit name=delauthor value=$am3>
	</form>";
	$edito = "";	
	}	
}	// end deleteauthor


else {
$query = "SELECT * FROM authors ";

$reponse = mysql_query($query, $sid);

$alist = "<font size=1><table>";
$alist2.= "<tr><td><font size=1><b>$m4</b></font></td>
			<td><font size=1>Email</font></td>
			<td><font size=1>$am3</font></td>
			<td><font size=1>Edit</font></td>
			</tr>";
	while ($row = @mysql_fetch_row($reponse))  {
	$found++;
	$alist.= "<tr><td><font size=1><b>$row[0]</b></font></td>
			<td><font size=1>$row[2]</font></td>
			<td><font size=1><a href=$PHP_SELF?deleteauthor=1&nauthor=$row[0]>$am3</A></font></td>
			<td><font size=1><a href=$PHP_SELF?editauthor=1&nauthor=$row[0]>Edit</A></font></td>
			</tr>";
	}
$alist.= "</table>";
		
$mkauthor = "$alist
	$m7: <input type=text name=nauthor value=\"$nauthor\">&nbsp;
	<input type=submit name=searchauthor value=$am4>&nbsp;
	<input type=submit name=addauthor value=$am2>&nbsp;
	<input type=submit name=delauthor value=$am3>
	<br>$mkauthor";
$alst = "&nbsp;<b>$found</b> $m7(s) $am6";

$mkauthor = "<table border=0 cellspacing=0 cellpadding=2 width=100%>
<tr><form action=$PHP_SELF method=post><th bgcolor=$dlbg>$am5 $alst</th></tr>
<tr><td valign=top bgcolor=#eeeeee> $mkauthor</font></td></form></tr></table>";
} // end author


if ($mailing) {
$t1 ="Ediweb Contact Manager";
$clist = "<font size=2>";
$found = 0;

	if ($showlist || $deletecontact || $editcontact) {
	$query = "SELECT id, name, email, city, country FROM contact ";
		if ($select) {
		$query.= "WHERE email != \"\" ";

			if ($Sname) {
			$query.= "OR name like \"%$select%\" ";
			}
			if ($Semail) {
			$query.= "OR email like \"%$select%\" ";
			}
			if ($Saddress) {
			$query.= "OR address like \"%$select%\" ";
			}
			if ($Scity) {
			$query.= "OR city like \"%$select%\" ";
			}
			if ($Szip) {
			$query.= "OR zip like \"%$select%\" ";
			}
			if ($Scountry) {
			$query.= "OR country like \"%$select%\" ";
			}
			if ($Sos) {
			$query.= "OR os like \"%$select%\" ";
			}
			if ($Sip) {
			$query.= "OR ip like \"%$select%\" ";
			}
		}	// end select != ""
	
		if ($contact) {
		$query = "SELECT id, name, email, city, country FROM contact ";
		if ($deletecontact) {
		$query = "DELETE from contact ";	
		}
		$query.= "WHERE ";
		$query.= "id = \"$contact\" ";
		}
	
		$reponse = mysql_query($query, $sid);
	
		$clist = "<table border=1 bordercolor=$dlbg cellspacing=0><form action=$PHP_SELF method=post>
		<input type=hidden name=smail value=1>
		<input type=hidden name=select value=$select>";

		if ($contact) {
		$clist.= "<input type=hidden name=contact value=$contact>";
		}
		else {
		$clist.= "<input type=hidden name=Semail value=$Semail>
		<input type=hidden name=Saddress value=$Saddress>
		<input type=hidden name=Scity value=$Scity>
		<input type=hidden name=Szip value=$Szip>
		<input type=hidden name=Scountry value=$Scountry>
		<input type=hidden name=Sos value=$Sos>
		<input type=hidden name=Sip value=$Sip>
		";
		}
		
	$clist.= "<tr>
	<td colspan=5 bgcolor=$dlbg>&nbsp;</td>
	</tr>
	<tr>
	<th bgcolor=$dlbg><font size=-1>#</font></td>
	<th ><font size=-1><b>$m4</b></font></td>
	<th ><font size=-1>Email</font></td>
	<th colspan=2 ><font size=1>Action</font></td>
			</tr>";
		while ($row = @mysql_fetch_row($reponse))  {
		$found++;
		$rcpt1 = $row[1];
		$rcpt2 = $row[2];
		$clist.= "<tr>
			<td ><font size=-1>$row[0]</font></td>
			<td ><font size=1>$row[1]<br>$row[3] ($row[4])</font></td>
			<td><font size=-1><b>$row[2]</b></font></td>
			<td ><font size=-1><a href=$PHP_SELF?deletecontact=1&contact=$row[0]&mailing=1>$am3</A></font><br>
			<font size=-1><a href=$PHP_SELF?editcontact=1&contact=$row[0]&mailing=1>Edit</A></font></td>
			<th><font size=-1><a href=$PHP_SELF?mailing=1&contact=$row[0]&select=1>Mail</A></font></td>
			</tr>";
			if ($smail == 1) {
			$rcpt = $row[2];
			$name = $siteadmin;
			$sender = $siteadminemail;
			$body = "$today $thetime\n$gmsg\n$sitename\n$siteadmin\n$siteadminemail";
			mail($rcpt,$subject, $body, "From: ".$name."<".$sender.">");
			}
		}
		
	$clist.= "<tr><td colspan=7 bgcolor=$dlbg>&nbsp;</td></tr>";
				
		if ($smail == 1) {
		$rcpt = $siteadminemail;
		$name = $siteadmin;
		$sender = $siteadminemail;
	
		$body = "Message sent to $found contacts\n$today $thetime\n$gmsg\n$sitename\n$siteadmin\n$siteadminemail";
		mail($rcpt,$subject, $body, "From: ".$name."<".$sender.">");
	
		$clist.= "<tr><th colspan=5>Message below was sent to $found contact(s)</th></tr>";
		$clist.= "<tr><td bgcolor=$dlbg>&nbsp;</td><th colspan=3>$subject</th><td bgcolor=$dlbg>&nbsp;</td></tr>";
		$clist.= "<tr><td bgcolor=$dlbg>&nbsp;</td><td colspan=3>$today $thetime\n$gmsg<br>$sitename\n$siteadmin<br>$siteadminemail</th><td bgcolor=$dlbg>&nbsp;</td></tr>";
		}
		else {
			if (!$contact) {
			$clist.= "<tr><th colspan=5 >Send Message to selection of $found contact(s)</th></tr>";
			}
			if ($contact) {
			$clist.= "<tr><th colspan=6 >Send Message to $rcpt1 ($rcpt2)</th></tr>";
			}
		$clist.= "<tr><td colspan=2 bgcolor=$dlbg>Subject:</td><td colspan=3 bgcolor=$dlbg><input name=subject type=text size=45></td></tr>";
		$clist.= "<tr><td colspan=4 bgcolor=$dlbg><textarea name=gmsg rows=5 cols=45></textarea></td><td bgcolor=$dlbg><input type=submit name=mailing value=Send></td></tr>";
		}
				
	$clist.= "</form></table>";

	} // end elect

	else {
	$t1 = $mm0;
	$clist.= "<center><font size=-1>$mm0</font></center>

	<form action=$PHP_SELF method=post><input type=hidden name=showlist value=1>
	<table cellspacing=0 width=100%>
	<tr><th bgcolor=$dlbg>$mm1</td><th bgcolor=$dlbg width=60>$mm2:</td><th bgcolor=$dlbg rowspan=9 valign=top><b>$am4:</b><br><input type=text name=select value=\"\"><p><input type=submit name=mailing value=$am4></td></tr>
	<tr><td bgcolor=$dlbg>Name: </td><td bgcolor=$dlbg>$mm3 <input type=checkbox checked name=Sname value=\"1\"></td></tr> 
	<tr><td bgcolor=$dlbg>Email: </td><td bgcolor=$dlbg>$mm3 <input type=checkbox checked name=Semail value=\"1\"></td></tr> 
	<tr><td bgcolor=$dlbg>Address: </td><td bgcolor=$dlbg>$mm3 <input type=checkbox checked name=Saddress value=\"1\"></td></tr> 
	<tr><td bgcolor=$dlbg>City: </td><td bgcolor=$dlbg>$mm3 <input type=checkbox checked name=Scity value=\"1\"></td></tr> 
	<tr><td bgcolor=$dlbg>Zip: </td><td bgcolor=$dlbg>$mm3 <input type=checkbox checked name=Szipl value=\"1\"></td></tr> 
	<tr><td bgcolor=$dlbg>Country: </td><td bgcolor=$dlbg>$mm3 <input type=checkbox checked name=Scountry value=\"1\"></td></tr> 
	<tr><td bgcolor=$dlbg>OS: </td><td bgcolor=$dlbg>$mm3 <input type=checkbox checked name=Sos value=\"1\"></td></tr> 
	<tr><td bgcolor=$dlbg>IP: </td><td bgcolor=$dlbg>$mm3 <input type=checkbox checked name=Sip value=\"1\"></td></tr> 
	<tr></table>
	</form>";
	}
}




?>
