<?
$table = "bbs$lg";

// display options
$tblwidth = ""; // set the display width
// colors
$lcolor = "brown";	// link color
$lvcolor = "brown"; // visited link color
$lhcolor = "blue"; // hover link color
// font
$face = "Arial";
$fsize = "-1";
// language
$lang = "en";

$showlink = 0; // set to 1 to show link to message list in message view
$showposter = 0; // set to 1 to show poster in the list

if ($lang = "en") {
$close_label = "Close";
$reply_label = "Reply";
$title_label = "Title";
$author_label = "Author";
}
elseif ($lang = "fr") {
$close_label = "Fermer";
$title_label = "Titre";
$author_label = "Auteur";
$reply_label = "R&eacute;pondre";
}


 	
if ($tblwidth == "") {
	$tblwidth = "100%";
}

$scr = "";

$sid = mysql_connect($dbhost, $dbuser, $dbpass);
mysql_select_db($db, $sid);

// expire messages older than $news_ttl days	
if ($news_ttl > 0) {
$exval = Date("U") - ($news_ttl *(24*3600)/2);
$query = "DELETE from $table ";
$query.= "WHERE expire < \"$exval\" ";

mysql_query($query, $sid);
}

function showmsg($parentid) {
global $table;
global $sid;
global $scr;
global $face;
global $fsize;
global $lang;
global $edito;

$datetouse = Date("U");

$nexr = ($maxr + $nxt);
$query = "select id, title,created,parent, poster ";
$query.= "from $table ";
$query.= "where parent=$parentid ";
$query.= "order by created DESC ";
$scr.= "<table border=0 cellspacing=0 cellpadding=1>";
$reponse = mysql_query($query, $sid);
	while ($row = mysql_fetch_row($reponse)) {
	
	$messageid = $row[0];
	$messagetitle = $row[1];
	$messagecreated = substr($row[2],0,10);
	$messageparent = $row[3];
	$poster = $row[4];
	
if ($showposter == 1) {
		$sposter = "&nbsp; $poster &nbsp;";
	}
	$scr.= "<tr><td width=40 align=right valign=top><font face=$face size=1 color=#A3A3D6>$messagecreated</font></td><td><font face=$face size=$fsize><a href=\"javascript:nws('jwin.php?messageid=$messageid&lang=$lang&edito=$edito')\"> $messagetitle</a>$sposter</font></td></tr>\n";

//	showmsg($messageid);
//	$rowcount++;
	}
	$scr.= "</table>";
	$thcnt = 0;
}

function showform($parentid,$usetitle) {
global $scr;
global $tblwidth;
global $fpage;
global $a1;

$a1.= "\n<table cellspacing=0 cellpadding=5 width=$tblwidth>";
$a1.= "<form action=$fpage method=post>";
$a1.= "<input type=hidden name=inputparent value=$parentid>";
$a1.= "<input type=hidden name=action value=post>";

$a1.= "\n<tr><th  align=right width=100><b>$title_label</b></td><td ><input type=text name=inputtitle size=40 maxlength=64 value=\"$usetitle\"></td></tr>";
$a1.= "\n<tr><th  align=right><b>$author_label</b></td><td ><input type=text name=inputposter size=40 maxlength=64></td></tr>";
$a1.= "\n<tr><td  colspan=2><textarea name=inputbody cols=60 rows=5></textarea></td></tr>";
$a1.= "\n<tr><td  colspan=2 align=middle><input type=submit value=post></td></tr>";
$a1.= "\n</table></form>";
}


if ($action != "") {
$ts = Date("U");
if ($news_post == 1 || $news_reply == 1) {
	$pst = 1;
}
if ($action == "post" && $pst == 1) {
$inputtitle = ereg_replace("'","''",$inputtitle);
$inputbody = ereg_replace("'","''",$inputbody);

$query = "insert into $table ";
$query.= "values ( ";
$query.= "0, \"$inputtitle\", \"$inputposter\", now(), $inputparent, \"$inputbody\", \"$ts\" ) ";

mysql_query($query,$sid);

}

}


if ($messageid > 0) {
$query = "select * from $table ";
$query.= "where id=$messageid ";
$reponse = mysql_query($query,$sid);

	if ($row = mysql_fetch_row($reponse)) {
	$messagetitle = $row[1];
	$messageposter = $row[2];
	$messagecreated = $row[3];
	$messageparent = $row[4];
	$messagebody = stripslashes($row[5]);
	$t1 = $fid;
	$a1 = "\n<table cellpadding=5 width=100%><tr><td>
		<table border=0 cellspacing=0 cellpadding=2 width=100%>";
	$a1.= "\n<tr><td BACKGROUND=tablebg.gif align=left width=20><img src=icons/editer.gif border=0 align=absmiddle></td>
<td bgcolor=#FFFFFF align=left><font face=$face size=$fsize>$messagecreated </td></tr>";
	$a1.= "\n<tr><th BACKGROUND=tablebg.gif align=left><img  alt=\"$title_label\" src=icons/css.gif border=0 align=absmiddle>";
	// $a1.= " <font face=$face size=$fsize color=#A3A3D6><b>$title_label</b></font>";
	$a1.= "</td><td bgcolor=#FFFFFF><b><font face=$face size=$fsize>$messagetitle</font></b>";
	$a1.= "</td></tr>";
	$a1.= "\n<tr><th BACKGROUND=tablebg.gif align=left><img src=icons/aim.gif border=0 align=absmiddle alt=\"$author_label\">";
	// $a1.= " <font face=$face size=$fsize color=#A3A3D6><b>$author_label</b></font>";
	$a1.= "</td><td bgcolor=#FFFFFF><font face=$face size=$fsize><i>$messageposter</i></font></td></tr>";
	
$a1.= "\n<tr><td BACKGROUND=tablebg.gif valign=top><br><img src=icons/txt.gif border=0 align=absmiddle>
<br><br><br><br><br><br><font face=$face size=$fsize>";
	if ($news_reply == 1) {
	$a1.= "<a href=\"$PHP_SELF?messageid=$messageid&r=1\">$reply_label</A>";
	}
	//	$a1.= "</font><br><br><br><br><br><br><br><br><a href=javascript:bye()><img src=icons/supprimer.gif border=0 align=absmiddle></A>";
	// $a1.= " <font face=$face size=$fsize color=#A3A3D6><b>$close_label</b></font>";
	$a1.= "</td><td bgcolor=#FFFFFF valign=top><br><font face=$face size=$fsize>$messagebody</font></p></td></tr>";

$a1.= "\n<tr><td BACKGROUND=tablebg.gif valign=bottom><a href=javascript:bye()><img src=icons/supprimer.gif border=0 align=absmiddle alt=\"$close_label\"></A>";
	$a1.= "</td><th bgcolor=#FFFFFF valign=bottom><font face=$face size=$fsize><a href=javascript:bye()>$close_label</A></font></td></tr>";
	$a1.= "\n</td></tr></table></center></td></tr></table>";
		if ($r == 1) {
		showform($messageid, "Re: $messagetitle");
		}
	}

}

 $scr.= "<table cellspacing=0 cellpadding=0 border=0 width=$tblwidth>\n";
// $scr.= "<tr><th><font face=$face>&nbsp; $fid &nbsp; ";
	if ($news_post == 1) {
	$scr.= " <a href=$PHP_SELF?p=1>Post new message</A>";
	}
	if ($showlink == 1) {
	$scr.= " <a href=$PHP_SELF>Message list</a>";
	}
// $scr.= "</font></td></tr>";	
$scr.= "<tr><td>";
$scr.= "<table width=100% cellspacing=0 cellpadding=0 border=0><tr><td>";

showmsg(0);

$scr.= "</td></tr></table>";
$news = "$scr</td></tr></table>\n";
$news_heading = $fid;
if ($p == 1) {
	showform(0, "");
}
elseif ($p == 2) {
	showform(0, "Re: $r");
}
