<?
// ediweb.php
//include("scripts//usr/local/httpd/includes/dbinfo.php");
// include("scripts//home/demo1/lib/dbinfo.php");
$view = $dbuser;

$ip = $REMOTE_ADDR;
$os = $HTTP_USER_AGENT;
$ref = $HTTP_REFERER;
$doc = $REQUEST_URI;
$ltv = (3600*24*30*12);

// $view = "$dbuser";
 



if (!$main_table) {
$main_table = "edito";
$Contact_us = "Contact us";
}

if (!$edito) {
$edito = $hv;
$popinfo = "onload=\"mwPOPINFO()\"";
}


//------ functions --------------------------------------
function contactme($pauthor,$cmt="My comments:") {
// send contact request to home page owner and update contact database
global $lg;	
global $t1;	
global $a1;
global $sid;	
global $db;
global $name;
global $email;
global $address;
global $city;
global $state;
global $zip;
global $country;
global $comment;
global $os;
global $ip;
global $snd;
global $pauthemail;
global $siteadminemail;
global $sitename;
global $today;
global $thetime;
global $dlbg;
global $siteadmin;
global $sitbaseeurl;
global $publiclib;
global $adminrealm;
global $realm;
global $racine;
global $name;
global $email;
global $address;
global $tbl_style;
global $edw_vt;

	include("scripts/lang.$lg");
	include("scripts/datetime.php");

$os2 = addslashes($os);




if ($snd) {
if ($name != "") {
setcookie("edw_vt");
setcookie("edw_vt", "$name", time()+1008000, "/"); 
}
$query = "SELECT email FROM contact WHERE email = \"$email\" ";
$reponse = mysql_query($query, $sid);

	if ($row = mysql_fetch_row($reponse))  {
	$qy = "UPDATE contact SET ip = \"$ip\", os = \"$os2\"";

		if ($name != "") {
		$qy.= ", name =\"$edw_vt\"";
		}
		if ($address != "") {
		$qy.= ", address =\"$address\"";
		}
		if ($city != "") {
		$qy.= ", city =\"$city\"";
		}
		if ($state != "") {
		$qy.= ", state =\"$state\"";
		}
		if ($zip != "") {
		$qy.= ", zip =\"$zip\"";
		}
		if ($country  != "") {
		$qy.= ", country =\"$country \"";
		}
	
	$qy.= " WHERE email = \"$email\" ";
	mysql_query($qy, $sid);
	$a1 = "<i>$contact_ok</i>";
	$edito = "";	
	}

	else {
	$query = "INSERT INTO contact VALUES ( ";
	$query.= "\"$name\", ";
	$query.= "\"$email\", ";
	$query.= "\"$address\", ";
	$query.= "\"$city\", ";
	$query.= "\"$state\", ";
	$query.= "\"$zip\", ";
	$query.= "\"$country\", ";
	$query.= "\"$os2\", ";
	$query.= "\"$ip\", ";
	$query.= "0) ";

	mysql_query($query, $sid);
	$acq = mysql_insert_id($sid);
	$t1 = "Contact";
		if ($acq == 0) {
		$a1 = "ERROR: no information submitted !";
		}
//	}

// $contact = $pauthor;
// include("scripts/lang.$lg");
$a1 = $contact_ok;
$edito = "";
	
}
// else {
$query = "SELECT email FROM authors ";
$query.= "WHERE author = \"$pauthor\" ";
	
	if ($reponse = mysql_query($query, $sid)) {
		while ($row = mysql_fetch_row($reponse))  {
		$rcpt = "$row[0]";
		}
	}
	else {
	$rcpt = $siteadminemail;	
	}
	
$rcpt = $siteadminemail;	
$sender = $email;	

	if ($name == "") {
	$name = "Unknown";
	}
	if ($email == "") {
	$sender = $siteadminemail;	
	}

$subject = "Contact request from $name";
$body = "on $today at $thetime\n";
$body.= "$name ($email) said to $pauthor: \n";
$body.= "$comment";

mail($rcpt,$subject, $body, "From: ".$name."<".$sender.">");
$subject = "Contact request sent to $siteadmin";
$body = "URL: http://$sitbaseeurl\n $comment";
mail($email,$subject, $body, "From: ".$name."<".$sender.">");

}

elseif (!$snd) {
if ($edw_vt != "") {
$query = "SELECT name,email,address,city,state,zip,country FROM contact WHERE name = \"$edw_vt\" ";
$reponse = mysql_query($query, $sid);
if ($row = mysql_fetch_row($reponse))  {
$name = $row[0];
$email = $row[1];
$address = $row[2];
$city = $row[3];
$state = $row[4];
$zip = $row[5];
$country = $row[6];

}

}
$t1 = $contact_heading;
$a1 = "<form action=\"$PHP_SELF\" method=post><input type=hidden name=contact value=$pauthor>
<table cellspacing=0 cellpadding=2 border=0><tr><td valign=bottom><font size=-1>
<b>$contact_subhead</b><p><table border=0 cellspacing=0>";
$a1.= "<tr><td>$contact_f1: </td><td><input type=text size=16 name=name value=\"$name\"></td></tr>";
$a1.= "<tr><td>$contact_f2: </td><td><input type=text size=16 name=email value=\"$email\"></td></tr>";
$a1.= "<tr><td>$contact_f3: </td><td><input type=text size=16 name=address value=\"$address\"></td></tr>";
$a1.= "<tr><td>$contact_f4: </td><td><input type=text size=16 name=city value=\"$city\"></td></tr>";
$a1.= "<tr><td>$contact_f5: </td><td><input type=text size=12 name=state value=\"$state\"></td></tr>";
$a1.= "<tr><td>$contact_f6: </td><td><input type=text size=8 name=zip value=\"$zip\"></td></tr>";
$a1.= "<tr><td>$contact_f7: </td><td><input type=text size=16 name=country value=\"$country\"></td></tr></table></font></td>

<td valign=bottom><img src=images_3/secrtel.gif><br><font size=-1>
$contact_f8:</font><br><textarea name=comment name=name rows=4 cols=26>$cmt</textarea>
</td></tr><tr><td colspan=2 align=center background=/home/bg2.jpg>
<input type=submit name=snd value=\"&nbsp;&nbsp;&nbsp;&nbsp; $post_button &nbsp;&nbsp;&nbsp;&nbsp;\"></td></tr>";
$a1.= "</table></form>";


}

}
function mklinkbar($exclude="") {
global $publiclib;
global $lg;	
global $lng;	
global $useexpire;
global $sid;
global $sa;
global $linkbar;
global $dlinkbar;
global $dlinkbar2;
global $dlinkbar3;
global $quicknav;
global $linkbarv;
global $linkbarv1;
global $dlbg;
global $rawformat;
global $exval;
global $edt;
global $pauthor;
global $contact;
global $forumname;
global $hv;
global $edito;
global $menu_index;
global $menu_login;
global $menu_forum;
global $menu_contact;
global $menu_index;
global $dlinkcolor;
global $lcolor;
global $hcolor;
global $tbl;
global $sitbaseeurl;
global $siteadminemail;
global $siteadmin;
global $dlinkbartop;
global $adminrealm;
global $realm;
global $REQUEST_URI;
global $m36;
global $user;
global $main_table;
$icbg = 0;
$icon = "ic_section.gif";
$chkpg = urlencode ($menu_index);
include("scripts/lang.$lg");

$expval = date("U");
$query = "SELECT acode, tbcol, author FROM $tbl ";
	if ($useexpire == "yes") {
	$query.= "WHERE dval > \"$expval\" ";
	}
$query.= "ORDER by acode ASC ";
$reponse = mysql_query($query, $sid);

$linkbarv = "<tr><td align=left $tbl_style align=left>";
	
		$tdid = $hv;
		$page = "<b>$hv</b>";
		$icon = "icons/parent.gif";
		$hvl = urlencode($hv);
		$href= "http://$sitbaseeurl/?edito=$hvl";
		include("scripts/mklb2.php");	

		if (!eregi("forum",$exclude, $match)) {
		$tdid = "help";
		$page = "<b>$menu_forum</b>";
		$icon = "icons/help.gif";
		$href ="?edito=$forumname";
		if ($edito == "$forumname") {
		$icbg = 1;	
		}
		include("scripts/mklb2.php");		
		}

		if (!eregi("contact",$exclude, $match)) {
		$tdid = "Contact";
		$page = "<b>$menu_contact</b>";
		$icon = "icons/editer.gif";
		$href= "index.php?contact=$siteadmin";
		include("scripts/mklb2.php");		
		}

		$linkbarv.= "</td></tr>";
$quicknav.= "<option value=none> --------------------------- </option>\n";

// make links to restricted areas

		$linkbarv.= "<tr><td align=left $tbl_style align=left>";
		$quicknav.= "<option value=none> --------------------------- </option>\n";
if ($addlnl) {

		$tdid = "Email";
		$page = "&reg; $adfm2 ";
		$icon = "icons/editer.gif";
		$href= "javascript:myEMAIL()";
		include("scripts/mklb2.php");		
			
		$tdid = "Files";
		$page = "&reg; $adfm0";
		$icon = "icons/refresh.gif";
		$href= "javascript:mwFTP()";
		include("scripts/mklb2.php");		
				
		$tdid = "Profile";
		$page = "&reg; $adfm3";
		$icon = "icons/css.gif";
		$href= "javascript:mwEUP()";
		include("scripts/mklb2.php");		

		$tdid = "MySQL";
		$page = "&reg; $adfm1";
		$icon = "icons/js.gif";
		$href= "javascript:mwMYSQL()";
		include("scripts/mklb2.php");		

}
	$qr1 = "SELECT rtbl FROM rlist WHERE rgroup != \"all\" ";
	$rep = mysql_query($qr1, $sid);
	while ($rw = mysql_fetch_row($rep)) {
		if (!eregi($rw[0],$exclude, $match)) {
		$tdid = "$rw[0]";
		$tdid = ucfirst($tdid);
		$page = "<b><font color=yellow>&reg;</font> $tdid</b>";
		$icon = "icons/help.gif";
		$href= "http://$sitbaseeurl/$rw[0]/restricted.php";
		include("scripts/mklb2.php");		
		}
	}
		
		if (!eregi("admin",$exclude, $match)) {
		$tdid = "admin";
		$page = "<b>&reg; $menu_login</b>";
		$icon = "icons/refresh.gif";
		$href= "http://$sitbaseeurl$adminrealm/ediwebadmin.php?logout=1";
		$btarget = " target=_blank";
		include("scripts/mklb2.php");		
		}

		$dlinkbartop = $dlinkbar3;
		$dlinkbar2 = "";
		
		$linkbarv.= "</td></tr>";
		$linkbarv.= "<tr><td align=left $tbl_style align=left>";

		$tdid = "id0";
		while ($row = mysql_fetch_row($reponse))  {
		$bl = substr($row[0],0,1);
			if ($bl != "_") {	
			$page = "$row[0]";
			
				if ($page != $hv) {
				$tdid = "$row[0]";
				$row[0] = urlencode($row[0]);
//				$tdid++;
				$href ="?edito=$row[0]";
			
//				if (
//				eregi("tools",$row[0], $match)
//				|| eregi("mysql",$row[0], $match)
//				|| eregi("admin",$row[0], $match)
//				|| eregi("Chg.",$row[0], $match)
//							
//				) {
//				$page = "&reg; $page";	
//				}
//				else {
//				$page = "&nbsp;&nbsp;&nbsp; $page";	
//				}

				if (
				eregi("Documentation",$row[0], $match)
				|| eregi("help",$row[0], $match)
				|| eregi("aide",$row[0], $match)				|| $row[0] == "help" 
				|| eregi("support",$row[0], $match) 
				|| eregi("tutorial",$row[0], $match)
				|| eregi("lost",$row[0], $match)
				|| eregi("Chg.",$row[0], $match)
				|| eregi("perdu",$row[0], $match)
				|| eregi("manual",$row[0], $match)
				) {
				$icon = "icons/help.gif";	
				}
				
				if (
				eregi("screenshots",$row[0], $match)
				|| eregi("pict",$row[0], $match)
				|| eregi("image",$row[0], $match)				|| $row[0] == "help" 
				|| eregi("graphic",$row[0], $match) 
				|| eregi("preview",$row[0], $match)
				) {
				$icon = "icons/jpg.gif";	
				}
				
				if (
				eregi("download",$row[0], $match)
				|| eregi("t�l�char",$row[0], $match)
				|| eregi("update",$row[0], $match)				|| $row[0] == "help" 
				) {
				$icon = "icons/download.gif";	
				}

				if (
				eregi("setup",$row[0], $match)
				|| eregi("inscript",$row[0], $match)
				|| eregi("register",$row[0], $match)
				|| eregi("activ",$row[0], $match)
				|| eregi("tools",$row[0], $match)				|| $row[0] == "help" 
				) {
				$icon = "icons/exe.gif";	
				}

				
				if (
				$row[0] == "Source" 
				|| $row[0] == "source" 
				
				) {
				$icon = "icons/txt.gif";	
				}
			
				include("scripts/mklb2.php");
				}

			} // end if not bl	
		
		} // end while

$linkbarv.= "</td></tr><tr><th><font color=orange size=-1>&reg; <font size=1 color=#ccccff>$adfmreg</font></font></td></tr>";

//		if ($bl != "_") {
			$linkbar.= "&nbsp;"; //  <b>&#149;</b>";			
//		}
$quicknav.= "</select>";
$quicknav = "<form name=\"selecter\"><table cellspacing=0 cellpadding=5 border=0><tr>
<td class=button bgcolor=#ddddff align=center height=34>
<select name=\"select1\" onChange=go()>
<option value=none>$qlname</option>
<option value=none>---------------------------</option>
$quicknav</td></tr></form></table>";
	
} // end mklinkbar


function getarticle($art) {
global $sid;
global $sa;
global $rawformat;
global $exval;
global $edt;
global $linkbar;
global $linkbarv;
global $today;
global $thetime;

global $acode;	
global $author;	
global $authemail;	
global $atitle;	
global $found;	
global $main_table;
global $showauthor;	
global $sitename;	



global $push;
global $datpub;
global $article;
global $hfont;	
global $hcol;
global $hsize;
global $afont;	
global $acol;
global $asize;
global $tbcol;
global $tbor;

if (!$art || $art == "") {
	$art = "Home";
}

if ($edito == "Register" || $edito == "Inscription") {
setcookie("email");

}
	$query = "SELECT acode, author,authemail, atitle, push, article, dval, ";
	$query.= "hfont,hcol,hsize,afont,acol,asize,tsize,tbcol,tbor ";
	$query.= "FROM $main_table ";
	$query.= "WHERE acode = \"$art\" ";
	$reponse = mysql_query($query, $sid);
	while ($row = mysql_fetch_row($reponse))  {
	//	if ($exval < $row[6]) {
		$found++;
		$acode = $row[0];	
	//	$author = $row[1];	
	//	$authemail = $row[2];	
		$pauthor = $row[1];	
		$pauthemail = $row[2];	
		$atitle = $row[3];	
		
		$push = $row[4];
		if ($push != "") {
		$datpub = $push;
		}
		$article = stripslashes($row[5]);

	if ($showauthor == 1) {
		$article.= "<p align=right><i><font size=1>&copy; <a href=mailto:$pauthemail>$sitename</A> $datpub </i></font>";
	}
		$hfont = $row[7];	
		$hcol = $row[8];
		$hsize = $row[9];
		$afont = $row[10];	
		$acol = $row[11];
		$asize = $row[12];
		
			if ($row[13] > 0) {
			$tsize = "width=$row[13]";	
			}
				
		$tbcol = $row[14];
		$tbor = $row[15];
			
			if ($tbor == "") {
			$tbor = 0;
			}
				
		
		//	}
	} // end while
		
	if ($found > 0 ) {

	$edt = "
	<table $tsize border=$tbor cellspacing=0>
	<tr><th align=left bgcolor=$hcol><font color=$tbcol size=-1>$today $thetime</font>  $linkbar</th></tr><tr><td bgcolor=$tbcol>";
	
	$edt.= "<table $tsize border=$tbor cellspacing=0>";
	$edt.= "<tr><td bgcolor=$tbcol><font face=\"$hfont\" color=$hcol size=$asize>$acode</font></td>
	<th bgcolor=$tbcol><font face=\"$hfont\" size=$hsize color=$hcol>$atitle</th></tr></table>";
	
	$edt.= "</td></tr>";
	$edt.= "<tr><td bgcolor=$tbcol><font face=$afont size=$asize color=$acol>$article</font></td></tr>";
	$edt.= "<tr><th align=right bgcolor=$tbcol><font face=$afont size=$asize color=$acol>$author</font></th></tr>";
	$edt.= "<tr><td align=right bgcolor=$tbcol><a href=mailto:$authemail>$authemail</A></td></tr><tr><th bgcolor=$hcol>$linkbar</th></tr><tr><td><font size=1 face=arial,helvetica,sans><i>Powered by <font color=$hcol size=2><b>Edito lite</b></font>, free data
base application at <a href=http://www.maxi-web.net>www.maxi-web.net</A></font></td></tr></table>";
	
		if ($rawformat) {
		$edt = "[<i>$acode</i>] <b>$linkbar</b> �� $jour/$mois/$annee $heure:$minute:$seconde<hr><h3>$atitle</h3><p>$article<p>$author ($authemail)</p><hr><b>$linkbar</b><p><font size=1 face=arial,helvetica,sans><i>Powered by <font size=2><b>Edito lit
e</b></font>, free database application at <a href=http://www.maxi-web.net>www.maxi-web.net</A></font>";	
		}
		
	} // end if found


} // end getarticle()


function searcharticle($search) {
global $sid;
global $sa;
global $rawformat;
global $exval;
global $atitle;
global $article;
global $found;	
global $scp;	
global $target;
global $main_table;

	$query = "SELECT acode, tbcol FROM $main_table ";
	$query.= "WHERE atitle like \"%$search%\" ";
	$query.= "OR article like \"%$search%\" ";
	$query.= "OR author like \"%$search%\" ";
	$query.= "OR authemail like \"%$search%\" ";
	$query.= "ORDER by push DESC ";

if ($scp == "parts") {
	$query = "SELECT * FROM partslist ";
	$query.= "WHERE PARTNUMBER like \"%$search%\" ";
	$query.= "OR MANUFACTURER like \"%$search%\" ";
//	$query.= "OR author like \"%$search%\" ";
//	$query.= "OR authemail like \"%$search%\" ";
	$query.= "ORDER by PARTNUMBER ASC ";

}

	$reponse = mysql_query($query, $sid);
	$count = mysql_num_rows($reponse);
	
		if ($deb == "") {
		$deb = 10;
		}
		if ($start == "") {
		$start = 0;
		}
	
	$show = 0;
	$flist = "";
	while (($row = mysql_fetch_row($reponse)) && ($show < $deb)) {
	$show++;
		if ($show > $start) {
			if ($scp == "site") {
			$bl = substr($row[0],0,1);
				if ($bl != "_") {
					$hits++;	
				$page = "$row[0]";
				$flist.= "<li><a ";
				$flist.= "href=\"$PHP_SELF?edito=$row[0]";
				
					if ($rawformat) { 
					$flist.= "&rawformat=1"; 
					}
					if ($sa) { 
					$flist.= "&sa=1"; 
					}
			
				$flist.= "\">$page</A>";
				
				} // end if not bl	
			}
			else {
				$flist.= "<tr>";
				for ($f=0; $f < 8; $f++) {
				$flist.= "<td><font size=-1>$row[$f]</font></td>";
				}
				$flist.= "</tr>";	
			}
		} // end show > start

	} // end while
	if ($scp == "parts") {
	$flist = "<table border=1 cellspacing=0 cellpadding=1>
	<tr><th><font size=-1>PART #</font></th>
	<th><font size=-1>PRICE</font></th>
	<th><font size=-2>CONDITIONING</font></th>
	<th><font size=-2>CASING</font></th>
	<th><font size=-2>DATECODE</font></th>
	<th><font size=-2>MANUFACTURER</font></th>
	<th><font size=-2>DELAY</font></th>
	<th><font size=-1>QUANTITY</font></th></tr>
	<tr>$flist</table>";
	$article = "Search returned <b>$count</b> record(s) for <b>$search</b>:<br>$flist</font>";		
	
	}
	if ($scp == "site" && $bl != "_") {
	$flist.= "</li>";
	$flist = "<ol>$flist</ol>";
	$article = "<b>$hits document(s)</b> found containing <b>$search</b>:<br>$flist</font>";		
	}

	$start = $show;
	$deb = ($deb + 10);

	$atitle = "Search results for <i>$search</i>";

}	// end searcharticle();

//
//
//------ end of functions --------------------------------




//---- main ------------------------------------------
//
//

if ($view) {
$udb = $view;	
if (!$si) {
	setcookie("udb");
setcookie("udb", "$udb", $ltv, "/edito/");
}
}

elseif (!$udb) {
$atitle = "Not found";
$article = "<p>This document was not found or doesn't exist";
$edt.= "$atitle<p>$article";
if ($sa == 1 && !$multi) {
	// this flag is needed to use this script as stand alone 
	// (not embedded in a html file)
	// you cannot use the multi body feature
	echo "<html><head><title>www.maxi-web.net/~$udb - $atitle</title></head>";
    echo "<body>$edt</body></html>";
}
exit;
}
   
$db = $udb;
$uid = 1;
$jr = date("l");
switch($jr) {
case "Monday":
  $jrf = "lundi";
  break;

case "Tuesday":
  $jrf = "Mardi";
  break;
  
case "Wednesday":
  $jrf = "Mercredi";
  break;

case "Thursday":
  $jrf = "Jeudi";
  break;
  
 case "Friday":
  $jrf = "Vendredi";
  break;

case "Saturday":
  $jrf = "Samedi";
  break;
  
case "Sunday":
  $jrf = "Dimanche";
  break;
 }
 
$date = date("d/m/Y");
$jour = date("d");
$jour2 = date("d");
$mois = date("m");
$mois2 = date("m");
$annee = date("Y");
$nmois = date("F");
	$heure = date("H");
	$minute = date("i");
	$seconde = date("s");
	$heure2 = date("H");
	$minute2 = date("i");
	$seconde2 = date("s");
if (substr($heure,0,1) == "0") {
$heure2 = substr($heure,1,1);
}
if (substr($seconde,0,1) == "0") {
$seconde2 = substr($seconde,1,1);
}
if (substr($minute,0,1) == "0") {
$minute2 = substr($minute,1,1);
}

if (substr($mois2,0,1) == "0") {
$mois2 = substr($mois2,1,1);
}
if (substr($jour,0,1) == "0") {
$jour2 = substr($jour,1,1);
}

$today = "$jour/$mois/$annee";
$thetime = "$heure:$minute:$seconde";

$exval = mktime ($heure,$minute,$seconde,$mois,$jour,$annee);
$found = 0;

// if (!$edito) {
	$edt = "";
//	}
	
	if ($dbpass) {
	$sid = mysql_connect($dbhost, $dbuser,$dbpass);
	}
	else {
	$sid = mysql_connect($dbhost, $dbuser);
	}

mysql_select_db($db, $sid);




// if (!$search && !$multi) {
if ($sa == 1) {
getarticle($edito);
// make linkbar
if (!$nolb) {
mklinkbar();
} 
}

if (!$multi) {
if(!$edito || $found == 0) {
$atitle = "Not found";
$article = "<p>This document was not found or doesn't exist";
$author = "Jean-Marc Leli�vre";	
$authemail = "webmaster@maxi-web.net";

		$edt = "";
		$edt.= "<table $tsize border=$tbor cellspacing=0>
		<tr><th align=left bgcolor=$hcol><font color=$tbcol size=-1>$jour/$mois/$annee $heure:$minute:$seconde</font> ����$linkbar</th></tr><tr><td bgcolor=$tbcol>";
		
		$edt.= "<table $tsize border=$tbor cellspacing=0>";
		$edt.= "<tr><td bgcolor=$tbcol><font face=\"$hfont\" color=$hcol size=$asize>$acode</font></td>
		<th bgcolor=$tbcol><font face=\"$hfont\" size=$hsize color=$hcol>$atitle</th></tr></table>";
		
		$edt.= "</td></tr>";
		$edt.= "<tr><td bgcolor=$tbcol><font face=$afont size=$asize color=$acol>$article</font></td></tr>";
		$edt.= "<tr><th align=right bgcolor=$tbcol><font face=$afont size=$asize color=$acol>$author</font></th></tr>";
		$edt.= "<tr><td align=right bgcolor=$tbcol><a href=mailto:$authemail>$authemail</A><br><i>$datepub</i></td></tr><tr><th bgcolor=$hcol>$linkbar</th></tr><tr><td><font size=1 face=arial,helvetica,sans><i>Powered by <font color=$hcol size=2><b>Edito</b></font>, free dat
abase application at <a href=http://www.maxi-web.net>www.maxi-web.net</A></font></td></tr></table>";
		
		if ($rawformat) {
		$edt = "[<i>$acode</i>] <b>$linkbar</b> �� $jour/$mois/$annee $heure:$minute:$seconde<hr><h3>$atitle</h3><p>$article<p>$author ($authemail)<br>$datpub</p><hr><b>$linkbar</b><p><font size=1 face=arial,helvetica,sans><i>Powered by <font size=2><b>Edito</b></font>, free database application at <a href=http://www.maxi-web.net>www.maxi-web.net</A></font>";	
		}

}

}

if ($sa == 1 && !$multi) {
	// this flag is needed to use this script as stand alone 
	// (not embedded in a html file)
	// you cannot use the multi body feature
	echo "<html><head><title>www.maxi-web.net/~$udb - $atitle</title></head>";
    echo "<body>$edt</body></html>";
}
$copyr ="<font face='arial,helvetica,sans' size=-1 color=$linkcolor>Powered by: <a href=http://www.maxi-web.net/~ediweb/><b><i>E</i>diweb</b></a> &copy; <a href=http://www.maxi-web.net>Maxi-web Network</a> 2001 by <a href=http://www.maxi-web.net/home/index.php?edito=Home&contact=Webmaster><i>W</i>ize<i>k</i>at</A></font>";

?>
