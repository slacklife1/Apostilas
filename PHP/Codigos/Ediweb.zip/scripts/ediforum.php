<?
if (!$dbuser) {
	include("scripts/config.php");
}

$ftable = "forum";

$today = date("j/m/Y");
$thetime = date("H:i:s");


if (!$sa) {
$sa = 0;	//  set to 2 to display a header html pagebefore the forum dispaly and a footer page below
// 				set to 1 to use script as stand alone (will display full html page)
//				if set to 0, you will need to embed in a html page and use
//				<? echo "$frm";... tag to show forum display where
//				you want it to appear in your page
}

$head = "haut3.htm"; 	// used only if $sa is set to 2
$foot = "bas2.htm";	// used only if $sa is set to 2

if (!$nxt) {
 	$nxt = 0;	
 	}
 	
if ($tblwidth == "") {
	$tblwidth = "100%";
}
$frm = "";

if ($sa == 1) {
$frm = "<html><head><title>$dbuser Forum</title>";
$frm.= "$style</head><body bgcolor=$bgcolor>";
}


if ($showtitle == 1) {
$frm.= "<h1>$dbuser forum</h1>";
}

$sid = mysql_connect($dbhost, $dbuser, $dbpass);
mysql_select_db($db, $sid);

// expire messages older than $ttl days	
if ($ttl > 0) {
$exval = Date("U") - ($ttl *(24*3600));
$query = "DELETE from $ftable ";
$query.= "WHERE expire < \"$exval\" ";

mysql_query($query, $sid);
}

function showMessages($parentid) {
global $ftable;
global $sid;
global $frm;
global $face;
global $fsize;
global $fpage;
global $forumname;
global $dcolor;

$datetouse = Date("U");

$nexr = ($maxr + $nxt);
$query = "select id, title,created,parent, poster ";
$query.= "from $ftable ";
$query.= "where parent=$parentid ";
$query.= "order by created DESC ";

$reponse = mysql_query($query, $sid);
$frm.= "<ul>";
	while ($row = mysql_fetch_row($reponse)) {
	$edfid = $row[0];
	$messagetitle = $row[1];
	$messagecreated = $row[2];
	$messageparent = $row[3];
	$poster = $row[4];
	
if ($showposter == 1) {
		$sposter = "&nbsp; $poster &nbsp;";
	}
$icn = "";
if ($messageparent == 0) {
$icn = "<img src=/home/icons/txt.gif align=absmiddle> ";
}
	$frm.= "<li>$icn<font face=$face size=1 $fsize>$messagecreated <font color=orange>$poster</font><br><font size=$fsize> &nbsp;<a href=\"$PHP_SELF?edito=$forumname&edfid=$edfid\">$messagetitle</a></font></font><br>\n";

	showMessages($edfid);
	$rowcount++;
	}
	$nexr = ($nexr + $thcnt);
	$thcnt = 0;
$frm.= "</ul>";
}

function postform($parentid,$usetitle) {
global $frm;
global $tblwidth;
global $fpage;
global $forumname;
global $dcolor;
	
$frm = "\n<table cellspacing=0 cellpadding=5 width=$tblwidth>";
$frm.= "<form faction=$fpage method=post>";
$frm.= "<input type=hidden name=inputparent value=$parentid>";
$frm.= "<input type=hidden name=faction value=post>";
$frm.= "<input type=hidden name=edito value=$forumname>";

$frm.= "\n<tr><th align=right><b>Title</b></td>
<td><input type=text name=inputtitle size=40 maxlength=64 value=\"$usetitle\"></td></tr>";
$frm.= "\n<tr><th  align=right><b>Author</b></td>
<td><input type=text name=inputposter size=40 maxlength=64></td></tr>";
$frm.= "\n<tr><td  colspan=2><textarea name=inputbody cols=60 rows=5></textarea></td></tr>";
$frm.= "\n<tr><td colspan=2 align=middle><input type=submit value=post></td></tr>";
$frm.= "\n</table></form>
<p align=center><b><a href=$PHP_SELF?edito=$forumname>Message list</a></b>";

}


if ($faction != "") {
$ts = Date("U");
if ($post == 1 || $reply == 1) {
	$pst = 1;
}
if ($faction == "post" && $pst == 1) {

$inputtitle = ereg_replace("'","''",$inputtitle);
	$inputbody = ereg_replace("'","''",$inputbody);

$inputtitle = htmlentities($inputtitle);
	$inputbody = htmlentities($inputbody);
	$inputbody = nl2br($inputbody);

$query = "insert into $ftable ";
$query.= "values ( ";
$query.= "0, \"$inputtitle\", \"$inputposter\", now(), $inputparent, \"$inputbody\", \"$ts\" ) ";

mysql_query($query,$sid);

}

}


if ($edfid > 0) {
$query = "select * from $ftable ";
$query.= "where id=$edfid ";
$reponse = mysql_query($query,$sid);

	if ($row = mysql_fetch_row($reponse)) {
	$messagetitle = $row[1];
	$messageposter = $row[2];
	$messagecreated = $row[3];
	$messageparent = $row[4];
	$messagebody = $row[5];

	$frm.= "\n<table cellpadding=5 width=$tblwidth>
	<tr><td><table border=0 cellspacing=1 cellpadding=1 width=100%>";
	$frm.= "\n<tr><td  width=50><font face=$face size=$fsize>$fname</font></td><td  align=right><font face=$face size=$fsize><a href=$PHP_SELF?edito=$forumname>Back to list</a></font></td></tr>";
	$frm.= "\n<tr><th  align=right><font face=$face size=$fsize><b>Title</b></font></td><td ><font face=$face size=$fsize>$messagetitle</font></td></tr>";
	$frm.= "\n<tr><th  align=right><font face=$face size=$fsize><b>Author</b></font></td><td ><font face=$face size=$fsize>$messageposter</font></td></tr>";
	$frm.= "\n<tr><th  align=right><font face=$face size=$fsize><b>Date</b></font></td><td ><font face=$face size=$fsize>$messagecreated</font></td></tr>";
	$frm.= "\n<tr><td><font face=$face size=$fsize>";
	if ($reply == 1) {
	$frm.= "<a href=\"$PHP_SELF?edito=$forumname&edfid=$edfid&r=1\">Reply</A>";
	}
	$frm.= "</font></td><td ><p><font face=$face size=$fsize>$messagebody</font></p></td></tr>";
	
	$frm.= "\n</td></tr></table></table>";
		if ($r == 1) {
		postform($edfid, "Re: $messagetitle");
		}
	}

}

else {
// $frm.= "<h2> Message List</h2>\n";
 $frm.= "<table cellspacing=0 border=0 width=$tblwidth>\n";
 
 $frm.= "<tr><th><font size=-1>$fname &nbsp; ";
	if ($post == 1) {
	$frm.= " <a href=$PHP_SELF?edito=$forumname&p=1>Post new message</A>";
	}
	if ($showlink == 1) {
	$frm.= " <a href=$PHP_SELF?edito=$forumname>Message list</a>";
	}
$frm.= "</font></td></tr>";	

$frm.= "<tr><td>";
 	$frm.= "<table width=100%><tr><td>";
 	
	showMessages(0);
	$frm.= "</td></tr></table>";
	
$frm.= "</td></tr></table>\n";

	if ($p == 1) {
	postform(0, "");
	$p = 0;
	}
	elseif ($p == 2) {
	postform(0, "Re: $r");
	}

}

