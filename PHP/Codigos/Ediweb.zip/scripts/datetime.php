<?
// Ediweb 2

// datetime.php


$date = date("d/m/Y");
$jour = date("d");
$jour2 = date("d");
$mois = date("m");
$mois2 = date("m");
$annee = date("Y");
$nmois = date("F");
	$heure = date("H");
	$minute = date("i");
	$seconde = date("s");
	$heure2 = date("H");
	$minute2 = date("i");
	$seconde2 = date("s");
if (substr($heure,0,1) == "0") {
$heure2 = substr($heure,1,1);
}
if (substr($seconde,0,1) == "0") {
$seconde2 = substr($seconde,1,1);
}
if (substr($minute,0,1) == "0") {
$minute2 = substr($minute,1,1);
}

if (substr($mois2,0,1) == "0") {
$mois2 = substr($mois2,1,1);
}
if (substr($jour,0,1) == "0") {
$jour2 = substr($jour,1,1);
}

$today = "$jour/$mois/$annee";
$thetime = "$heure:$minute:$seconde";

$exval = mktime ($heure,$minute,$seconde,$mois,$jour,$annee);

$jr = date("l");
switch($jr) {
case "Monday":
  $jrf = $jr1;
  break;

case "Tuesday":
  $jrf = $jr2;
  break;
  
case "Wednesday":
  $jrf = $jr3;
  break;

case "Thursday":
  $jrf = $jr4;
  break;
  
 case "Friday":
  $jrf = $jr5;
  break;

case "Saturday":
  $jrf = $jr6;
  break;
  
case "Sunday":
  $jrf = $jr7;
  break;
 }
 
$date = date("d/m/Y");
$jour = date("d");
$jour2 = date("d");
$mois = date("m");
$mois2 = date("m");
$annee = date("Y");

$nmois = date("F");
switch($nmois) {
case "January":
  $fmois = $fm1;
  break;

case "February":
  $fmois = $fm2;
  break;

case "March":
  $fmois = $fm3;
  break;

case "April":
  $fmois = $fm4;
  break;

case "May":
  $fmois = $fm5;
  break;

case "June":
  $fmois = $fm6;
  break;

case "July":
  $fmois = $fm7;
  break;

case "August":
  $fmois = $fm8;
  break;

case "September":
  $fmois = $fm9;
  break;

case "October":
  $fmois = $fm10;
  break;

case "November":
  $fmois = $fm11;
  break;

case "December":
  $fmois = $fm12;
  break;
}

?>
