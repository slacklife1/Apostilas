<?
// Ediweb 2
// eupdate.php


	if ($nohtml == 1) {
	 $article = htmlentities($article);
	 $article = nl2br($article);
	}


// this is where we place the image and links
// this part needs some more attention and
// I'll get back to this when I'll have the time...
// Meanwhile, it just puts the img tag above or under the text
// and align it left or right or center

	if ($img) {
	// $itag = "<table border=0 cellspacing=1 cellpadding=0>";

	$imtag = "<img src=$iurl ";
		if ($width != "" && $height != "") {
		$itag.= "width=$width height=$height ";
		}	
	$imtag.= "border=0>";

		if ($hori == "left") {
		$article = "<table border=0 cellspacing=1 cellpadding=1><tr><td valign=$vert>$imtag</td><td valign=$vert>$article</td></tr></table>";	
		}
		elseif ($hori == "right") {
		$article = "<table border=0 cellspacing=1 cellpadding=0><tr><td valign=$vert>$article</td><td valign=$vert>$imtag</td></tr></table>";	
		}
	}

$cr = split("-",$expire,3);
$dval = mktime (0,0,1,$cr[1],$cr[2],$cr[0]);

	if ($showdate == 1) {
	$push = "$annee-$mois-$jour $heure:$minute:$seconde";	
	}
	else {
	$push = "";	
	}

$article = addslashes($article);

$query = "UPDATE $tbl ";
$query.= "\n";
$query.= "SET acode = \"$hide$acode\", ";
$query.= "\n";
$query.= "dval = \"$dval\", ";
$query.= "\n";
$query.= "push = \"$push\", ";
$query.= "\n";
// $query.= "author = \"$author\", ";
// $query.= "\n";
// $query.= "authemail = \"$authemail\", ";
// $query.= "\n";
$query.= "atitle = \"$atitle\", ";
$query.= "\n";
$query.= "article = \"$article\", ";
$query.= "\n";
$query.= "hfont = \"$hfont\", ";
$query.= "\n";
$query.= "hcol = \"$hcol\", ";
$query.= "\n";
$query.= "hsize = \"$hsize\", ";
$query.= "\n";
$query.= "afont = \"$afont\", ";
$query.= "\n";
$query.= "acol = \"$acol\", ";
$query.= "\n";
$query.= "asize = \"$asize\", ";
$query.= "\n";
$query.= "tsize = \"$tsize\", ";
$query.= "\n";
$query.= "tbcol = \"$tbcol\", ";
$query.= "\n";
$query.= "tbor = \"$tbor\" ";
$query.= "\n";
$query.= "WHERE id = \"$id\" ";
	
	if ($author != $siteadmin) {
	$query.= "AND author = \"$author\" ";
	}
	
$done = "UPDATED";

	if ($dele) {
	$query = "DELETE FROM $tbl ";
	$query.= "WHERE id = \"$id\" ";

		if ($author != $siteadmin) {
	 	$query.= "AND author = \"$author\" ";
		}
	
	if (!$conf) {
	$conf = 1;
	}
	$done = "DELETED";
	}
	
	if ($updt == "$m2" && $conf != 1) {
		
		if ($dbpass) {
		$sid = mysql_connect($dbhost, $dbuser,$dbpass);
		}
		else {
		$sid = mysql_connect($dbhost, $dbuser);
		}

	mysql_select_db($db, $sid);

	$acq = mysql_query($query, $sid);
	// $acq = mysql_insert_id($sid);

		if ($acq == 0) {
		$dbreply = "ERROR: article $acode NOT $done !";
		}
		else {
		$dbreply = "article $acode is $done ! ";
		$edito = "";	
		}
		
	}
	
	elseif ($conf == 1) {
	include("scripts/$pagehead");
	echo "<b>Confirm deletion</b><p>do you want to delete article ID # $id <i>\"$edito\"</i> ?<p>
	<a href=\"$PHP_SELF?edito=$linkto&id=$id&updt=Update&dele=1&conf=yes&tbl=$tbl\">YES</a> &nbsp;&nbsp; <a href=javascript:history.back()>NO</A>";
	include("scripts/$pagefoot");
	exit;
	}
	

?>
