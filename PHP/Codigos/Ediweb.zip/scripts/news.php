<?
$ip = $REMOTE_ADDR;
$os = $HTTP_USER_AGENT;
$ref = $HTTP_REFERER;
$doc = $REQUEST_URI;

include("scripts/config.php");
//$db = $dbuser;	
include("scripts/lang.$lg");
	$svr = "$fsvr";

if ($tb == "news" || $tb == "bbs") {
	$table = "bbs$lg";
	$fid2 = $fid;
}
else {
	$table = $tb;
$fid2 = "Forum";
}
$today = date("j/m/Y");
$thetime = date("H:i:s");

// display options

$tblwidth = ""; // set the display width
$showlink = 1;
$showtitle = 0;	// set to 1 to show forum title
if (!$sa) {
$sa = 2;	//  set to 2 to display a header html pagebefore the forum dispaly and a footer page below
// 				set to 1 to use script as stand alone (will display full html page)
//				if set to 0, you will need to embed in a html page and use
//				<? echo "$scr";... tag to show forum display where
//				you want it to appear in your page
}

$head = "top2.htm"; 	// used only if $sa is set to 2
$foot = "foot2.htm";	// used only if $sa is set to 2

// forum options
$ttl = 10;	// TimeToLive number of days to keep messages
$post = 1;	// set to 1 to allow new messages threads
$reply = 1;	// set to 1 to allow replies to messages
$showposter = 0;
// style sheet
$style = "<style type=\"text/css\">
TD {
font-family: helvetica;
color: $c_texte1;
font-size: 12px;
align: left;
}
Th {
font-family: verdana;
color: $c_titre;
font-size: 12px;
}
HR {
color: red;
}

H1 {
    color: $c_titre;
    font-family: verdana;
    font-size: 26px;
    font-style: oblique;
}
H2 {
    color: $c_titre;
    font-family: verdana;
    font-size: 22px;
    font-style: oblique;
}
H3 {
    color: $c_titre;
    font-family: verdana;
    font-size: 18px;
    font-style: oblique;
}
H4 {
    color: $c_titre;
    font-family: verdana;
    font-size: 14px;
    font-style: bold;
}
P {
font-family: Arial,helvetica;
font-size: 12px;
color: $c_texte1;
}
ul {
font-family: Arial,helvetica;
font-size: 12px;
color: $ul;
}
ol {
font-family: Arial,helvetica;
font-size: 12px;
color: $ol;
}
A:link {font-family: Arial,helvetica; color: $lcolor; text-decoration: underline;}
A:visited {font-family: Arial,helvetica; color: $lvcolor; text-decoration: underline;}
A:hover {font-family: Arial,helvetica; color: $lhcolor; text-decoration: underline;}

</style>";
if (!$nxt) {
 	$nxt = 0;	
 	}
 	
if ($tblwidth == "") {
	$tblwidth = "100%";
}
$scr = "";

if (!$u) {
	$scr = "<h3>Access restricted to site administrator</h3><p>Bye !</p>";
	include("scripts/$head");
	echo "$scr";
	include("scripts/$foot");
	exit;
}
elseif ($author != $u) {
	$scr = "<h3>Access restricted to site administrator</h3><p>Bye !</p>";
	include("scripts/$head");
	echo "$scr";
	include("scripts/$foot");
	exit;
}

else {
	// time()+10800
setcookie("u", "$u", "", "/");
}

if ($sa == 1) {
$scr = "<html><head><title>$dbuser Forum</title>";
$scr.= "$style</head><body bgcolor=$bgcolor>";
}


if ($showtitle == 1) {
$scr.= "<h1>$dbuser forum</h1>";
}

$sid = mysql_connect($dbhost, $dbuser, $dbpass);
mysql_select_db($db, $sid);

// expire messages older than $ttl days	

$exval = Date("U") - ($ttl *(24*3600)/2);
$query = "DELETE from $table ";
$query.= "WHERE expire < \"$exval\" ";

mysql_query($query, $sid);

if ($delete == 1) {
	$query = "DELETE from $table ";
$query.= "WHERE id = \"$messageid\" ";

mysql_query($query, $sid);

}

function showMessages($parentid) {
global $table;
global $sid;
global $scr;
global $lg;
include("scripts/lang.$lg");
$datetouse = Date("U");

$nexr = ($maxr + $nxt);
$query = "select id, title,created,parent, poster ";
$query.= "from $table ";
$query.= "where parent=$parentid ";
$query.= "order by created DESC ";

$reponse = mysql_query($query, $sid);
$scr.= "<ul>";
	while ($row = mysql_fetch_row($reponse)) {
	$messageid = $row[0];
	$messagetitle = $row[1];
	$messagecreated = $row[2];
	$messageparent = $row[3];
	$poster = $row[4];
	if ($showposter == 1) {
		$sposter = "&nbsp; $poster &nbsp;";
	}
	$scr.= "<li><a href=\"$PHP_SELF?messageid=$messageid&tb=$table\">$messagetitle</a> $sposter $messagecreated <a href=\"$PHP_SELF?tb=$table&delete=1&messageid=$messageid\">$mess[7]</a><br>\n";

	showMessages($messageid);
	$rowcount++;
	}
	$nexr = ($nexr + $thcnt);
	$thcnt = 0;
$scr.= "</ul>";
}

function postform($parentid,$usetitle) {
global $scr;
global $tblwidth;
global $fpage;
global $u;
global $tb;
global $lg;
include("scripts/lang.$lg");
	
$scr.= "\n<table cellspacing=0 cellpadding=5 width=$tblwidth>";
$scr.= "<form action=$fpage method=post>";
$scr.= "<input type=hidden name=inputparent value=$parentid>";
$scr.= "<input type=hidden name=action value=post><input type=hidden name=tb value=$tb";

$scr.= "\n<tr><th bgcolor=#c0c0c0 align=right width=100><b>$m0</b></td><td bgcolor=#c0c0c0><input type=text name=inputtitle size=40 maxlength=64 value=\"$usetitle\"></td></tr>";
$scr.= "\n<tr><th bgcolor=#c0c0c0 align=right><b>$m7</b></td><td bgcolor=#c0c0c0><input type=hidden name=inputposter value=$u>$u &nbsp;  language: <b>$lg</b> &nbsp; <input type=checkbox name=htmlformat value=1> HTML encode</td></tr>";
$scr.= "\n<tr><td bgcolor=#c0c0c0 colspan=2><textarea name=inputbody cols=60 rows=5></textarea></td></tr>";
$scr.= "\n<tr><td bgcolor=#c0c0c0 colspan=2 align=middle><input type=submit value=post></td></tr>";
$scr.= "\n</table></form>";
}


if ($action != "") {
$ts = Date("U");
if ($post == 1 || $reply == 1) {
	$pst = 1;
}
if ($action == "post" && $pst == 1) {
	
// $inputtitle = ereg_replace("'","''",$inputtitle);
// $inputbody = ereg_replace("'","''",$inputbody);
$inputbody = addslashes($inputbody);

if ($htmlformat == 1) {
$inputbody = htmlentities($inputbody);
$inputbody = nl2br($inputbody);

}

$query = "insert into $table ";
$query.= "values ( ";
$query.= "0, \"$inputtitle\", \"$inputposter\", now(), $inputparent, \"$inputbody\", \"$ts\" ) ";

mysql_query($query,$sid);

}

}


if ($messageid > 0) {
$query = "select * from $table ";
$query.= "where id=$messageid ";
$reponse = mysql_query($query,$sid);

	if ($row = mysql_fetch_row($reponse)) {
	$messagetitle = $row[1];
	$messageposter = $row[2];
	$messagecreated = $row[3];
	$messageparent = $row[4];
	$messagebody = $row[5];

	$scr.= "\n<table cellpadding=5 width=$tblwidth><tr><td bgcolor=#c0c0c0><table border=0 cellspacing=1 cellpadding=1 width=100%>";
	$scr.= "\n<tr><td bgcolor=$bcolor width=100>$fid2</td><td bgcolor=#c0c0c0 align=right><a href=$PHP_SELF?tb=$table>$list_label</a></td></tr>";
	$scr.= "\n<tr><th bgcolor=$bcolor align=right><b>$m0</b></td><td bgcolor=$bcolor>$messagetitle</td></tr>";
	$scr.= "\n<tr><th bgcolor=$bcolor align=right><b>$m7</b></td><td bgcolor=$bcolor>$messageposter</td></tr>";
	$scr.= "\n<tr><th bgcolor=$bcolor align=right><b>Date</b></td><td bgcolor=$bcolor>$messagecreated</td></tr>";
	$scr.= "\n<tr><td bgcolor=#c0c0c0>";
	if ($reply == 1) {
	$scr.= "<a href=\"$PHP_SELF?messageid=$messageid&r=1&tb=$tb\">$reply_label</A>";
	}
	$scr.= "</td><td bgcolor=$bcolor><blockquote>$messagebody</blockquote></td></tr>";
	
	$scr.= "\n</td></tr></table></table>";
		if ($r == 1) {
		postform($messageid, "Re: $messagetitle");
		}
	}

}

else {
// $scr.= "<h2> $list_label</h2>\n";
 $scr.= "<table cellspacing=0 border=0 width=$tblwidth>\n";
 
 $scr.= "<tr><th bgcolor=#c0c0c0>$fid2 &nbsp; ";
	if ($post == 1) {
	$scr.= " <a href=$PHP_SELF?p=1&tb=$tb>$post_label</A>";
	}
	if ($showlink == 1) {
	$scr.= " <a href=$PHP_SELF?tb=$tb>$list_label</a>";
	}
$scr.= "</td></tr>";	

$scr.= "<tr><td bgcolor=#c0c0c0>";
 	$scr.= "<table width=100%><tr><td bgcolor=$bcolor>";
 	
	showMessages(0);
	$scr.= "</td></tr></table>";
	
$scr.= "</td></tr></table>\n";

if ($p == 1) {
	postform(0, "");
}
elseif ($p == 2) {
	postform(0, "Re: $r");
}

}

if ($sa == 2) {
	include("scripts/$head");
	echo "$scr";
	include("scripts/$foot");
	exit;
}
elseif ($sa == 1) {
	echo "$scr\n</body></html>\n";
}
