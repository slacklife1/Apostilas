Ediweb version 2.0.1b
by wizekat (wizekat@mac.com)
######################################################
Released 23/04/2002
######################################################
Official Ediweb site : http://www.maxi-web.net/ediweb
######################################################

Welcome to this new release of Ediweb !

This is a mostly a "cleanup" release, all functions have been checked some bugs were fixed.

New icons have been added for link bars and a complete set is located in the icons directory.

Public site now also has language options for navigation, contact, forum and news sections.

An install script is provided, installs in 2 minutes !

DISCLAIMER
THIS APPLICATION IS PROVIDED AS IS WITH NO WARANTY WHATSOEVER AS TO EVEN THE FACT THAT IT ACTUALLY WORKS FOR YOU OR THAT IT MAY BE USEFULL TO OTHERS AND I TAKE NO RESPONSABLITY OVER WHAT MAY BE DONE OR PUBLISHED THRU THIS APPLICATION; THIS APPLICATION DOES NOT CRYPT OR OTHERWISE SECURE ITS DATA IN ANY FORM. SPAM, ANNONYMOUS COMMUNICATION, PRIVATE DATA COLLECTION, FILING AND SEARCH CAPABILITIES ARE POSSIBLE USING THIS APPLICATION, HERE AGAIN, I TAKE NO RESPONSABILITY FOR THE PRIVATE DATA COLLECTED OR PUBLISHED OR OFFERED TO PUBLIC SEARCH, INCLUDING EMAIL ADDRESSES AND UCE MAIL THAT MAY BE ROUTED BY THIS APPLICATION; USE IT AT YOUR OWN RISKS IF YOU PLAN TO SPAM, AND MAKE SURE I DON'T HEAR ABOUT IT...



INSTALALTION AND SETUP

A fully functional layout is given as an example, just edit the files index.php and icode.php to understand the basics (most configuration options are commented in the source code of icode.php).

STEP ONE: Pre-installation
#########################
(skip this if you have a working MySQL database access) :
setup a valid MySQL database and user access. 
See your server administrator or ISP for this if you do not run or manage your own server. 
If you do run your own server or if you have administrator access, follow these steps 
(tested on MySQL 3.23 on Linux), replacing <database_name>, <database_user>, 
<database_password> and <database_host> with the apropriate values:

a) login on the server console or over a telnet session.
b) run mysql client as admin (usually root).
c) issue the SQL command : CREATE DATABASE <database_name>
d) issue the SQL command : USE <database_name>
e) issue the SQL command : GRANT ALL ON <database_name>.* TO <database_user>@<database_host> identified by '<database_password>'
f) exit mysql client
g) run as admin (usually root) : mysqladmin reload
h) test your new database access :
- run the mysql client as the new user
- issue the SQL command : USE <database_name>
You should have a reply from the server saying "database changed" or equivalent.


STEP TWO: Ediweb setup
#########################
1 unpack the distribution in your web server directory

2 edit file config.php in the scripts directory and setup required values.

3 point your browser to install.php

Finished! 

Let me know about bugs and stuff you'd like to see implemented or modified...

Thank's for using Ediweb
Jean-Marc "Wizekat@mac.com"
