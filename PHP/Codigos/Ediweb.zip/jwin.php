<?

// template engine configuration
$win_template = "jwin.html";
$js_template = "ediweb.js";




$ip = $REMOTE_ADDR;
$os = $HTTP_USER_AGENT;
$ref = $HTTP_REFERER;
$doc = $REQUEST_URI;

function read_file($strfile) {
	if(!file_exists($strfile)) return;
	$thisfile = file($strfile);
	while(list($line,$value) = each($thisfile)) {
		$value = ereg_replace("\r","",$value);
		$value = ereg_replace("\n","",$value);
		$result .= "$value\r\n";
	}
	return $result;
}


if (!$lg) {
$lban1 = "<img src=/home/maxiweb-ad1.gif width=468 height=60>";
$lg = "en";
$main_table = "edito";
$Contact_us = "Contact us";
$hv = "Home";
setcookie("main_table");
setcookie("main_table", "$main_table", time()+1008000, "/");
setcookie("lg");
setcookie("lg", "$lg", time()+1008000, "/");
}

if ($lng == "en") {
$lban1 = "<img src=/home/maxiweb-ad1.gif width=468 height=60>";
$lg = $lng;
$main_table = "edito";
$Contact_us = "Contact us";
$hv = "Home";
setcookie("main_table");
setcookie("main_table", "$main_table", time()+1008000, "/");
setcookie("lg");
setcookie("lg", "$lng", time()+1008000, "/");
}

elseif ($lng == "fr") {
$lban1 = "<img src=/home/maxiweb-ad2-fr.gif width=468 height=60>";
$lg = $lng;
$main_table = "edifr";
$Contact_us = "Contactez-nous";
$hv = "Accueil";
setcookie("main_table");
setcookie("main_table", "$main_table", time()+1008000, "/");
setcookie("lg");
setcookie("lg", "$lng", time()+1008000, "/");
}
if ($lg == "fr") {
$lban1 = "<img src=/home/maxiweb-ad2-fr.gif width=468 height=60>";
}
if ($lg == "en") {
$lban1 = "<img src=/home/maxiweb-ad1.gif width=468 height=60>";
}


if ($si) {
$incdir ="/var/www/includes";
include("scripts/$incdir/ha.php");
$regres = "<font face=arial,helvetica,sans>$prt</font>";
}
include("scripts/icode.php");
if ($regres) {
$a1 = $regres;
}

// include("scripts/show_new_users.php");
$jssource = read_file($js_template);
$tcontent = read_file($win_template);

include("scripts/edw_replace.php");
echo($tcontent);

?>

