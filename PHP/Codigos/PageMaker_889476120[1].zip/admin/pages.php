<?php
// ScriptName: pages.php
// Author: Jordie Bodlay
// Date Started: Friday, 24 May 2002 
// Date Finished: Friday, 24 May 2002 
// Date Last Modified: Friday, 24 May 2002 
// Visit: http://www.i2media.net/pagemaker
 
include("includes/db_connect.php");
include("includes/checker.php");
include("includes/menu.php");

if($acc[pages] == "0"){
echo "Sorry you do no have access to view this page";
die();
}

if(!$action){
	//default viewing - list of pages
	?><BR><BR><CENTER><B><A HREF="<?=$PHP_SELF?>?action=addpage">Add Page</A></B></CENTER><BR><BR>
	<CENTER><TABLE border=1 cellspacing=0 cellpadding=3>
	<TR>
		<TD><B>ID</B></TD>
		<TD><B>Title</B></TD>
		<TD><B>Author</B></TD>
		<TD><B>Made</B></TD>
		<TD><B>Edited</B></TD>
		<TD><B>Delete</B></TD>
	</TR><?
		$query = mysql_query("SELECT * FROM $tpages");
		while($row = mysql_fetch_array($query)){

		$author = $row[author];
		$aq = mysql_fetch_array(mysql_query("SELECT * FROM $tadmin WHERE id='$author'"));
		$author = $aq[username];
		

		echo "<TR>";
		echo "<TD><A HREF='$PHP_SELF?action=editpage&id=".$row[id]."'>".$row[id]."</A></TD>";
		echo "<TD><A HREF='$PHP_SELF?action=editpage&id=".$row[id]."'>".$row[title]."</A></TD>";
		echo "<TD>".$author."</TD>";
		echo "<TD>".date("jS F Y",$row[dmade])."</TD>";
		echo "<TD>".date("jS F Y",$row[dedit])."</TD>";
		echo "<TD><A HREF='$PHP_SELF?action=deletepage&id=".$row[id]."&page=".$row[title]."'>Delete</A></TD>";
		echo "</TR>";
		}
		echo "</TABLE></CENTER>";
}elseif($action == "addpage"){
	// print out form for adding a page
	?>
	<FORM METHOD=POST ACTION="<?=$PHP_SELF?>">
	<TABLE border=0>
	<TR>
		<TD>Author</TD>
		<TD><B><?=$username?><INPUT TYPE="hidden" name="author" value="<?=$userid?>"></B></TD>
	</TR>
	<TR>
		<TD>Date:</TD>
		<TD><B><?=date("jS F Y")?></B><INPUT TYPE="hidden" name="date" value="<?=date("U")?>"></TD>
	</TR>
	<TR>
		<TD>Title:</TD>
		<TD><INPUT TYPE="text" NAME="title"></TD>
	</TR>
	<TR>
		<TD>Content:</TD>
		<TD><TEXTAREA NAME="content" ROWS="15" COLS="60"></TEXTAREA></TD>
	</TR>

	<TR>
		<TD colspan=2><INPUT TYPE="submit" value="add page"></TD>
		
	</TR>
			
	</TABLE><INPUT TYPE="hidden" name="action" value="addpage2">
	</FORM>
	<?


}elseif($action == "addpage2"){


	$content = addslashes($content);
	$title   = addslashes($title);
	
	//stop multiple pages with the same title
	$query = mysql_query("SELECT * FROM $tpages WHERE title='$title'");
	if(mysql_num_rows($query) > 0){
		echo "The title needs to be unique.";
		die();
	}
	
	// insert into the database
	mysql_query("INSERT INTO $tpages (title,content,author,dmade,dedit) VALUES ('$title','$content','$author','$date','$date')");
	echo mysql_error();
	echo "Page <B>$title</B> has been added.<BR><A HREF='$PHP_SELF'>Click Here to return</A>.";


}elseif($action == "editpage"){
// print out form to edit page
$info = mysql_fetch_array(mysql_query("SELECT * FROM $tpages WHERE id='$id'"));

		$author = $info[author];
		$aq = mysql_fetch_array(mysql_query("SELECT * FROM $tadmin WHERE id='$author'"));
		$author = $aq[username];


?>
	<FORM METHOD=POST ACTION="<?=$PHP_SELF?>">
	<TABLE border=0>
	<TR>
		<TD>Author</TD>
		<TD><B><?=$author?></B></TD>
	</TR>
	<TR>
		<TD>Made:</TD>
		<TD><B><?=date("jS F Y",$info[dmade])?></b></TD>
	</TR>
		<TR>
		<TD>Last Edited:</TD>
		<TD><B><?=date("jS F Y",$info[dedit])?></b><INPUT TYPE="hidden" name="date" value="<?=date("U")?>"></TD>
	</TR>
	<TR>
		<TD>Title:</TD>
		<TD><INPUT TYPE="text" NAME="title" value="<?=stripslashes($info[title])?>"></TD>
	</TR>
	<TR>
		<TD>Content:</TD>
		<TD><TEXTAREA NAME="content" ROWS="15" COLS="60"><?=stripslashes($info[content])?></TEXTAREA></TD>
	</TR>

	<TR>
		<TD colspan=2><INPUT TYPE="submit" value="edit page"></TD>
		
	</TR>
			
	</TABLE><INPUT TYPE="hidden" name="action" value="editpage2"><INPUT TYPE="hidden" name="id" value="<?=$id?>">
	</FORM>
	<?

}elseif($action == "editpage2"){
	$content = addslashes($content);
	$title   = addslashes($title);
	
	//stop multiple pages with the same title
	$query = mysql_query("SELECT * FROM $tpages WHERE title='$title'");
	if(mysql_num_rows($query) > 0){
		echo "The title needs to be unique.";
		die();
	}
	
	// insert into the database
	mysql_query("UPDATE $tpages SET title='$title',content='$content',dedit='$date' WHERE id='$id'");
	echo mysql_error();
	echo "Page <B>$title</B> has been edited.<BR><A HREF='$PHP_SELF'>Click Here to return</A>.";
}elseif($action == "deletepage"){
	echo "Are you sure you want to delete <B>$page</B>?&nbsp;&nbsp;&nbsp;<A HREF='$PHP_SELF?id=$id&action=deletepage2&page=$page'>Yes</A>&nbsp;&nbsp;|&nbsp;&nbsp;<a href='$PHP_SELF'>No</a>";
}elseif($action == "deletepage2"){
	mysql_query("DELETE FROM $tpages WHERE id='$id'");
		if(file_exists("../$page.html")){
			unlink("../$page.html");
		}
		if(file_exists("../$id.html")){
			unlink("../$id.html");
		}
		echo "Page <B>$page</B> has been deleted.<BR><A HREF='$PHP_SELF'>Click Here to return</A>.";
}
?>