<?php
// ScriptName: menu.php
// Author: Jordie Bodlay
// Date Started: Friday, 24 May 2002 
// Date Finished: Friday, 24 May 2002 
// Date Last Modified: Friday, 24 May 2002 
// Visit: http://www.i2media.net/pagemaker
 
if(!isset($gpath)){
	$gpath = "../admin/";
}elseif($gpath == " "){
$gpath = "";
}
?>

<STYLE TYPE="text/css">
body,td,tr {font-family: arial,verdana; font-size: 10pt;}
input,textarea, {font-family: arial,verdana; font-size: 10pt;}
a:link {color: #FF6600; text-decoration: none} 
a:visited {color: #FF6600; text-decoration: none} 
a:hover {color: #FF6600; text-decoration: underline} 
a:active {color: #FF0000; text-decoration: underline} 
</STYLE>
<CENTER><IMG SRC="<?=$gpath?>images/logo.gif" BORDER=0 ALT="PageMaker"><BR></CENTER>