<?php
// ScriptName: menu.php
// Author: Jordie Bodlay
// Date Started: Friday, 24 May 2002 
// Date Finished: Friday, 24 May 2002 
// Date Last Modified: Friday, 24 May 2002 
// Visit: http://www.i2media.net/pagemaker
 
$acc = mysql_fetch_array(mysql_query("SELECT * FROM $tadmin WHERE id='$userid'"));
echo mysql_error();
include("includes/css.php");
?>

<CENTER>
<A HREF="main.php">Main</A>&nbsp;&nbsp;|&nbsp;&nbsp;
<A HREF="options.php">Edit Options</A>&nbsp;&nbsp;|&nbsp;&nbsp;
<? if($acc[users] == "1"){ ?><A HREF="users.php">Admin Users</A>&nbsp;&nbsp;|&nbsp;&nbsp;<? } ?>
<? if($acc[news] == "1"){ ?><A HREF="news.php">News</A>&nbsp;&nbsp;|&nbsp;&nbsp;<? } ?>
<? if($acc[pages] == "1"){ ?><A HREF="pages.php">Pages</A>&nbsp;&nbsp;|&nbsp;&nbsp;<? } ?>
<? if(($acc[news] == "1") OR ($acc[pages] == "1")){ ?><A HREF="generate.php">Generate Pages</A>&nbsp;&nbsp;|&nbsp;&nbsp;<? } ?>
<A HREF="logout.php">Logout</A>
</CENTER>