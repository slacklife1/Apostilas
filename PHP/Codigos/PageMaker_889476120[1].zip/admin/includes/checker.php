<?php
// ScriptName: checker.php
// Author: Jordie Bodlay
// Date Started: Friday, 24 May 2002 
// Date Finished: Friday, 24 May 2002 
// Date Last Modified: Friday, 24 May 2002 
// Visit: http://www.i2media.net/pagemaker
 
 session_start();
	if(!session_is_registered(username)){
	echo "You are not supposed to be here, go away";
	die();
	}
?>