<?php
// ScriptName: db_connect.php
// Author: Jordie Bodlay
// Date: Friday, 17 August 2001
// Visit: http://www.i2media.net/pagemaker

$db_host	 = "localhost";
$db_user	 = "";
$db_pass	 = "";
$db_database = "pagemaker";

// table names. if you have different names
// for your tables then edit these:
$tpages   = "pages";
$tadmin   = "admin";
$toptions = "options";
$tnews	  = "news";

mysql_pconnect("$db_host", "$db_user", "$db_pass") or die("<font color=red><B>Error:</B>Cannot connect to database.</font>");
mysql_select_db("$db_database");

?>