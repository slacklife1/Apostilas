<?php
// ScriptName: pages.php
// Author: Jordie Bodlay
// Date Started: Friday, 24 May 2002 
// Date Finished: Friday, 24 May 2002 
// Date Last Modified: Friday, 24 May 2002 
// Visit: http://www.i2media.net/pagemaker
 
include("includes/db_connect.php");
include("includes/checker.php");
include("includes/menu.php");

if($acc[news] == "0"){
echo "Sorry you do no have access to view this page";
die();
}


if(!$action){
	//default viewing - list of news
	?><BR><BR><CENTER><B><A HREF="<?=$PHP_SELF?>?action=addnews">Add News</A></B></CENTER><BR><BR>
	<CENTER><TABLE border=1 cellspacing=0 cellpadding=3>
	<TR>
		<TD><B>ID</B></TD>
		<TD><B>Subject</B></TD>
		<TD><B>Author</B></TD>
		<TD><B>Date</B></TD>
		<TD><B>Delete</B></TD>
	
	</TR><?
		$query = mysql_query("SELECT * FROM $tnews");
		while($row = mysql_fetch_array($query)){

		$author = $row[author];
		$aq = mysql_fetch_array(mysql_query("SELECT * FROM $tadmin WHERE id='$author'"));
		$author = $aq[username];
		

		echo "<TR>";
		echo "<TD><A HREF='$PHP_SELF?action=editnews&id=".$row[id]."'>".$row[id]."</A></TD>";
		echo "<TD><A HREF='$PHP_SELF?action=editnews&id=".$row[id]."'>".$row[subject]."</A></TD>";
		echo "<TD>".$author."</TD>";
		echo "<TD>".date("jS F Y",$row[date])."</TD>";
		echo "<TD><A HREF='$PHP_SELF?action=deletenews&id=".$row[id]."&news=".$row[subject]."'>Delete</A></TD>";

		echo "</TR>";
		}
		echo "</TABLE></CENTER>";
}elseif($action == "addnews"){
	// print out form for adding some news
	?>
	<FORM METHOD=POST ACTION="<?=$PHP_SELF?>">
	<TABLE border=0>
	<TR>
		<TD>Author</TD>
		<TD><B><?=$username?><INPUT TYPE="hidden" name="author" value="<?=$userid?>"></B></TD>
	</TR>
	<TR>
		<TD>Date:</TD>
		<TD><B><?=date("jS F Y")?></B><INPUT TYPE="hidden" name="date" value="<?=date("U")?>"></TD>
	</TR>
	<TR>
		<TD>Subject:</TD>
		<TD><INPUT TYPE="text" NAME="subject"></TD>
	</TR>
	<TR>
		<TD>Content:</TD>
		<TD><TEXTAREA NAME="content" ROWS="15" COLS="60"></TEXTAREA></TD>
	</TR>

	<TR>
		<TD colspan=2><INPUT TYPE="submit" value="add news"></TD>
		
	</TR>
			
	</TABLE><INPUT TYPE="hidden" name="action" value="addnews2">
	</FORM>
	<?


}elseif($action == "addnews2"){


	$content = addslashes($content);
	$subject = addslashes($subject);
	
	
	// insert into the database
	mysql_query("INSERT INTO $tnews (subject,content,author,date) VALUES ('$subject','$content','$author','$date')");
	echo mysql_error();
	echo "News <B>$subject</B> has been added.<BR><A HREF='$PHP_SELF'>Click Here to return</A>.";


}elseif($action == "editnews"){
// print out form to edit news
$info = mysql_fetch_array(mysql_query("SELECT * FROM $tnews WHERE id='$id'"));

		$author = $info[author];
		$aq = mysql_fetch_array(mysql_query("SELECT * FROM $tadmin WHERE id='$author'"));
		$author = $aq[username];


?>
	<FORM METHOD=POST ACTION="<?=$PHP_SELF?>">
	<TABLE border=0>
	<TR>
		<TD>Author</TD>
		<TD><B><?=$author?></B></TD>
	</TR>
	<TR>
		<TD>Posted:</TD>
		<TD><B><?=date("jS F Y",$info[date])?></b></TD>
	</TR>
	
	<TR>
		<TD>Subject:</TD>
		<TD><INPUT TYPE="text" NAME="subject" value="<?=stripslashes($info[subject])?>"></TD>
	</TR>
	<TR>
		<TD>Content:</TD>
		<TD><TEXTAREA NAME="content" ROWS="15" COLS="60"><?=stripslashes($info[content])?></TEXTAREA></TD>
	</TR>

	<TR>
		<TD colspan=2><INPUT TYPE="submit" value="edit news"></TD>
		
	</TR>
			
	</TABLE><INPUT TYPE="hidden" name="action" value="editnews2"><INPUT TYPE="hidden" name="id" value="<?=$id?>">
	</FORM>
	<?

}elseif($action == "editnews2"){
	$content = addslashes($content);
	$subject = addslashes($subject);
	
	
	// insert into the database
	mysql_query("UPDATE $tnews SET subject='$subject',content='$content' WHERE id='$id'");
	echo mysql_error();
	echo "News <B>$subject</B> has been edited.<BR><A HREF='$PHP_SELF'>Click Here to return</A>.";

}elseif($action == "deletenews"){
	echo "Are you sure you want to delete <B>$news</B>?&nbsp;&nbsp;&nbsp;<A HREF='$PHP_SELF?id=$id&action=deletenews2&news=$news'>Yes</A>&nbsp;&nbsp;|&nbsp;&nbsp;<a href='$PHP_SELF'>No</a>";

}elseif($action == "deletenews2"){
	mysql_query("DELETE FROM $tnews WHERE id='$id'");
		
		echo "News <B>$news</B> has been deleted.<BR><A HREF='$PHP_SELF'>Click Here to return</A>.";
}
?>