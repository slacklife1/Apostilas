<?php
// ScriptName: generate.php
// Author: Jordie Bodlay
// Date Started: Friday, 24 May 2002 
// Date Finished: Friday, 24 May 2002 
// Date Last Modified: Friday, 24 May 2002 
// Visit: http://www.i2media.net/pagemaker
 
include("includes/db_connect.php");
include("includes/checker.php");
include("includes/menu.php");



if($action == "makefiles"){
	$query = mysql_query("SELECT * FROM $tpages");
	
	$q2 = mysql_fetch_array(mysql_query("SELECT * FROM $toptions WHERE name='layout'"));
	$layout = $q2[value];
	



	while($row = mysql_fetch_array($query)){

		if($by == "title"){
			$title = strtolower($row[title]);
			$title = str_replace(" ","_",$title);
			$title = str_replace(",","",$title);
			$title = str_replace(";","",$title);
			$title = str_replace("?","",$title);
			$title = str_replace("!","",$title);
			$title = str_replace("'","",$title);
			$title = str_replace("\"","",$title);
			$title = str_replace("\\","",$title);
			$title = str_replace("/","",$title);
			$name = $title;
		}else{
			$name = $row[id];
		}

		$id = $row[id];
		$title = $row[title];
		$content = stripslashes($row[content]);

		$author = $row[author];
		$aq = mysql_fetch_array(mysql_query("SELECT * FROM $tadmin WHERE id='$author'"));
		$author = $aq[username];
		
		$data = str_replace("<page:title>","$title",$layout);
		$data = str_replace("<page:content>","$content",$data);
		$data = str_replace("<page:author>","$author",$data);
		$data = str_replace("<page:dmade>",date("jS F Y",$row[dmade]),$data);
		$data = str_replace("<page:dedit>",date("jS F Y",$row[dedit]),$data);
		if($name  != "index"){
			if(file_exists("../$name.html")){
			unlink("../$name.html");
		}
		
		$fp = fopen ("../$name.html", "w+");
		fwrite($fp,$data);
		fclose($fp);
		echo "<B>$name.html</B> done!<BR>";
		}else{
		echo "<B>index</B> is an invalid name, could not create.<BR>";
		}

	}
}elseif($action == "makeindex"){
	$info = mysql_fetch_array(mysql_query("SELECT * FROM $tpages WHERE id='$page'"));

	$q = mysql_fetch_array(mysql_query("SELECT * FROM $toptions WHERE name='newslimit'"));
	$limit = $q[value];
	$q2 = mysql_fetch_array(mysql_query("SELECT * FROM $toptions WHERE name='newslayout'"));
	$layout = $q2[value];

	$news ="";

	$news_query = mysql_query("SELECT * FROM $tnews ORDER BY id DESC LIMIT $limit");

	while($row = mysql_fetch_array($news_query)){
		$author = $row[author];
		$aq = mysql_fetch_array(mysql_query("SELECT * FROM $tadmin WHERE id='$author'"));
		$author = $aq[username];

		$date = date("jS F Y",$row[date]);

		$temp = str_replace("<news:subject>",stripslashes($row[subject]),$layout);
		$temp = str_replace("<news:author>","$author",$temp);
		$temp = str_replace("<news:content>",stripslashes($row[subject]),$temp);
		$temp = str_replace("<news:date>","$date",$temp);
		$news .= $temp;
		$temp = "";
		$author = "";
		$date = "";

	}
	$q22 = mysql_fetch_array(mysql_query("SELECT * FROM $toptions WHERE name='layout'"));
	$layout2 = $q22[value];


		$id = $page;
		$title = $info[title];
		$content = stripslashes($info[content]);

		$data = str_replace("<page:title>","$title",$layout2);
		$data = str_replace("<page:content>","$content",$data);
		$data = str_replace("<page:author>","$author",$data);
		$data = str_replace("<page:dmade>",date("jS F Y",$info[dmade]),$data);
		$data = str_replace("<page:dedit>",date("jS F Y",$info[dedit]),$data);
		$data = str_replace("<news>","$news",$data);
		
		$fp = fopen ("../index.html", "w+");
		fwrite($fp,$data);
		fclose($fp);
		echo "<B>index.html</B> done!<BR>";

}elseif(!$action){
	if($acc[pages] == "1"){?>
	<CENTER><B>Before generating the files please make sure the folder below this is writeable</B><BR>
	<FORM METHOD=POST ACTION="<?=$PHP_SELF?>">
	<INPUT TYPE="hidden" name="action" value="makefiles">
		<INPUT TYPE="hidden" name="by" value="title">
	<INPUT TYPE="submit" value="Generate files with title">
		<BR>e.g. Your Title becomes your_title.html
	</FORM><HR width="80"> <? }

	if($acc[news] == "1"){ ?>

		<FORM METHOD=POST ACTION="<?=$PHP_SELF?>">
	<INPUT TYPE="hidden" name="action" value="makefiles">
		<INPUT TYPE="hidden" name="by" value="id">
	<INPUT TYPE="submit" value="Generate files with id">
		<BR>e.g. ID 4 becomes 4.html
	</FORM><HR width="80">
		<FORM METHOD=POST ACTION="<?=$PHP_SELF?>">
	<INPUT TYPE="hidden" name="action" value="makeindex">
		Select Page: <SELECT NAME="page">
	<?
		$query = mysql_query("SELECT * FROM $tpages");
	while($row = mysql_fetch_array($query)){
		echo "<option value='".$row[id]."'>".$row[id]." - ".$row[title]."</option>";
	}
	?>
	</SELECT>
	<INPUT TYPE="submit" value="Generate index">
		<BR>Generates the main page with the selected page
	</FORM></CENTER>
	<? }
}
?>