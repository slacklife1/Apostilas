<?php
// ScriptName: users.php
// Author: Jordie Bodlay
// Date Started: Friday, 24 May 2002 
// Date Finished: Friday, 24 May 2002 
// Date Last Modified: Friday, 24 May 2002 
// Visit: http://www.i2media.net/pagemaker
 
include("includes/db_connect.php");
include("includes/checker.php");
include("includes/menu.php");

if($acc[users] == "0"){
echo "Sorry you do no have access to view this page";
die();
}



if(!$action){
	//default viewing - list of users
	?><BR><BR><CENTER><B><A HREF="<?=$PHP_SELF?>?action=adduser">Add User</A></B></CENTER><BR><BR>
	<CENTER><TABLE border=1 cellspacing=0 cellpadding=3>
	<TR>
		<TD><B>ID</B></TD>
		<TD><B>Username</B></TD>
		<TD><B>Real Name</B></TD>
		<TD><B>Email</B></TD>
		<TD><B>News*</B></TD>
		<TD><B>Pages*</B></TD>
		<TD><B>Users*</B></TD>
		<TD><B>Delete</B></TD>
	
	</TR><?
		$query = mysql_query("SELECT * FROM $tadmin");
		while($row = mysql_fetch_array($query)){

		echo "<TR>";
		echo "<TD><A HREF='$PHP_SELF?action=edituser&id=".$row[id]."'>".$row[id]."</A></TD>";
		echo "<TD><A HREF='$PHP_SELF?action=edituser&id=".$row[id]."'>".$row[username]."</A></TD>";
		echo "<TD>".$row[realname]."</TD>";
		echo "<TD><a href='mailto:".$row[email]."'>".$row[email]."</a></TD>";
		echo "<TD>";
			if($row[news] == "1"){ echo "Y"; }else{ echo "N"; }
		echo "</TD>";
		echo "<TD>";
			if($row[pages] == "1"){ echo "Y"; }else{ echo "N"; }
		echo "</TD>";
		echo "<TD>";
			if($row[users] == "1"){ echo "Y"; }else{ echo "N"; }
		echo "</TD>";
		echo "<TD><A HREF='$PHP_SELF?action=deleteuser&id=".$row[id]."&user=".$row[username]."'>Delete</A></TD>";

		echo "</TR>";
		}
		echo "</TABLE><BR><BR> * = Access to</CENTER>";
}elseif($action == "adduser"){
	// print out form for adding a user
	?>
	<FORM METHOD=POST ACTION="<?=$PHP_SELF?>">
	<TABLE border=0>
	<TR>
		<TD>Username</TD>
		<TD><INPUT TYPE="text" name="user" ></TD>
	</TR>
	<TR>
		<TD>Password:</TD>
		<TD><INPUT TYPE="text" name="pass" ></TD>
	</TR>
	<TR>
		<TD>Real Name:</TD>
		<TD><INPUT TYPE="text" NAME="realname"></TD>
	</TR>
	<TR>
		<TD>Email:</TD>
		<TD><INPUT TYPE="text" NAME="email"></TD>
	</TR>
	<TR>
		<TD>Access to:</TD>
		<TD>
		<INPUT TYPE="checkbox" NAME="news" value="1"> News<BR>
		<INPUT TYPE="checkbox" NAME="pages" value="1"> Pages<BR>
		<INPUT TYPE="checkbox" NAME="users" value="1"> Users</TD>
	</TR>
	<TR>
		<TD colspan=2><INPUT TYPE="submit" value="add user"></TD>
		
	</TR>
			
	</TABLE><INPUT TYPE="hidden" name="action" value="adduser2">
	</FORM>
	<?


}elseif($action == "adduser2"){
	
	if($news){
		$news = "1";
	}else{
		$news = "0";
	}
	
	if($pages){
		$pages = "1";
	}else{
		$pages = "0";
	}

	if($users){
		$users = "1";
	}else{
		$users = "0";
	}
	
	// insert into the database
	mysql_query("INSERT INTO $tadmin (username,password,realname,email,news,pages,users) VALUES ('$user','$pass','$realname','$email','$news','$pages','$users')");
	echo mysql_error();
	echo "User <B>$user</B> has been added.<BR><A HREF='$PHP_SELF'>Click Here to return</A>.";


}elseif($action == "edituser"){
// print out form to edit user
$row = mysql_fetch_array(mysql_query("SELECT * FROM $tadmin WHERE id='$id'"));



?>Note: If you are editing your own username, you will need to logout and login again for it to take effect.<BR><BR>
<FORM METHOD=POST ACTION="<?=$PHP_SELF?>">
	<TABLE border=0>
	<TR>
		<TD>Username</TD>
		<TD><INPUT TYPE="text" name="user" value="<?=$row[username]?>"></TD>
	</TR>
	<TR>
		<TD>Password:</TD>
		<TD><INPUT TYPE="text" name="pass" value="<?=$row[password]?>"></TD>
	</TR>
	<TR>
		<TD>Real Name:</TD>
		<TD><INPUT TYPE="text" NAME="realname" value="<?=$row[realname]?>"></TD>
	</TR>
	<TR>
		<TD>Email:</TD>
		<TD><INPUT TYPE="text" NAME="email" value="<?=$row[email]?>"></TD>
	</TR>
	<TR>
		<TD>Access to:</TD>
		<TD>
		<INPUT TYPE="checkbox" NAME="news" value="1" <? if($row[news] == "1"){ echo "checked"; } ?>> News<BR>
		<INPUT TYPE="checkbox" NAME="pages" value="1" <? if($row[pages] == "1"){ echo "checked"; } ?>> Pages<BR>
		<INPUT TYPE="checkbox" NAME="users" value="1" <? if($row[users] == "1"){ echo "checked"; } ?>> Users</TD>
	</TR>
	<TR>
		<TD colspan=2><INPUT TYPE="submit" value="edit user"></TD>
		
	</TR>
	
	</TABLE><INPUT TYPE="hidden" name="action" value="edituser2"><INPUT TYPE="hidden" name="id" value="<?=$id?>">
	</FORM>
	<?

}elseif($action == "edituser2"){

	if($news){
		$news = "1";
	}else{
		$news = "0";
	}
	
	if($pages){
		$pages = "1";
	}else{
		$pages = "0";
	}

	if($users){
		$users = "1";
	}else{
		$users = "0";
	}
	
	// insert into the database
	mysql_query("UPDATE $tadmin SET username='$user',password='$pass',realname='$realname',email='$email',news='$news',pages='$pages',users='$users' WHERE id='$id'");
	echo mysql_error();
	echo "User <B>$user</B> has been edited.<BR><A HREF='$PHP_SELF'>Click Here to return</A>.";
}elseif($action == "deleteuser"){
	if(mysql_num_rows(mysql_query("SELECT * FROM $tadmin")) == "1"){
		echo "You can not remove the last user.";
		die();
	}
	echo "Are you sure you want to delete <B>$user</B>?&nbsp;&nbsp;&nbsp;<A HREF='$PHP_SELF?id=$id&action=deleteuser2&user=$user'>Yes</A>&nbsp;&nbsp;|&nbsp;&nbsp;<a href='$PHP_SELF'>No</a>";

}elseif($action == "deleteuser2"){
	if(mysql_num_rows(mysql_query("SELECT * FROM $tadmin")) == "1"){
		echo "You can not remove the last user.";
		die();
	}
	mysql_query("DELETE FROM $tadmin WHERE id='$id'");
		
		echo "User <B>$user</B> has been deleted.<BR><A HREF='$PHP_SELF'>Click Here to return</A>.";
}
?>