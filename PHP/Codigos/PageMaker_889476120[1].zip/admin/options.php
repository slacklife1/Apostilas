<?php
// ScriptName: options.php
// Author: Jordie Bodlay
// Date Started: Friday, 24 May 2002 
// Date Finished: Friday, 24 May 2002 
// Date Last Modified: Friday, 24 May 2002 
// Visit: http://www.i2media.net/pagemaker
 
include("includes/db_connect.php");
include("includes/checker.php");
include("includes/menu.php");
if(!$action){
	//default viewing - list of options
	?><CENTER><B>Editing Options</B></CENTER><BR>
	<CENTER><TABLE border=0 cellspacing=0 cellpadding=3>
	<TR>
		<TD><B>Options (Click to edit)</B></TD>
		
	</TR><?
		$query = mysql_query("SELECT * FROM $toptions");
		while($row = mysql_fetch_array($query)){
		echo "<TR>";

		echo "<TD><A HREF='$PHP_SELF?action=edit&id=".$row[id]."'>".$row[name]."</A></TD>";

		echo "</TR>";
		}
		echo "</TABLE></CENTER>";
}elseif($action == "edit"){
	// display editing form
	$info = mysql_fetch_array(mysql_query("SELECT * FROM $toptions WHERE id='$id'"));

	$type = $info[type];
	$value = stripslashes($info[value]);
	switch ($type) {
    case "text":
        $field = "<INPUT TYPE='text' NAME='value' value='$value'>";
        break;
    case "textarea":
        $field = "<TEXTAREA NAME='value' ROWS='15' COLS='60'>$value</TEXTAREA>";
        break;
    default:
        $field = "<TEXTAREA NAME='value' ROWS='15' COLS='60'>$value</TEXTAREA>";
	}
	?>
	<FORM METHOD=POST ACTION="<?=$PHP_SELF?>">
	<TABLE>
	<TR>
		<TD>Option:</TD>
		<TD><B><?=$info[name]?></B></TD>
	</TR>
	<TR>
		<TD>Value:</TD>
		<TD><?=$field?></TD>
	</TR>
	<TR>
		<TD colspan=2><CENTER><INPUT TYPE="submit" value="edit option"></CENTER></TD>

	</TR>
	</TABLE><INPUT TYPE="hidden" name="id" value="<?=$id?>"><INPUT TYPE="hidden" name="name" value="<?=$info[name]?>"><INPUT TYPE="hidden" name="action" value="edit2">
	</FORM>
	<?
}elseif($action == "edit2"){

		mysql_query("UPDATE $toptions SET value='$value' WHERE id='$id'");
		echo mysql_error();
		echo "Option <B>$name</B> has been added.<BR><A HREF='$PHP_SELF'>Click Here to return</A>.";

}
?>