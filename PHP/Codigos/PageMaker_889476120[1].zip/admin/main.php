<?php
// ScriptName: main.php
// Author: Jordie Bodlay
// Date Started: Friday, 24 May 2002 
// Date Finished: Friday, 24 May 2002 
// Date Last Modified: Friday, 24 May 2002 
// Visit: http://www.i2media.net/pagemaker
 
include("includes/db_connect.php");
include("includes/checker.php");
include("includes/menu.php");
echo "Welcome to the admin! Use the menu above to navigate your way around.<BR>You are logged in as <B>$username</B> and your id is <B>$userid</B>";
?><BR><BR>
<B>Quick Guide:</B><BR>
<B>1.</B> Make a page with &lt;news&gt; where you want the news to be displayed<BR>
<B>2.</B> Go to generate pages an at the bottom select the page you just made and press "Generate Index"<BR>
<B>3.</B> This would of made index.html in the directory below this one. <BR>
<B>4.</B> Use the News feature to post news. <BR>
<B>5.</B> Once you have posted news follow step 2 again.<BR>
<B>6.</B> You can edit the page layout and news layout in the options.<BR>
<B>7.</B> The page layout ("layout") can have the follwing tags/features in it:<BR>
&lt;page:title&gt;   - title of the page<BR>
&lt;page:content&gt; - the main body content of the page<BR>
&lt;page:author&gt;  - username of the person who wrote it<BR>
&lt;page:dmade&gt;   - date the page was made <BR>
&lt;page:dedit&gt;   - date the page was last updated<BR>
<B>8.</B> The news layout ("newslayout") can have the follwing tags/features in it:<BR>
&lt;news:subject&gt; - subject of the news item<BR>
&lt;news:content&gt; - main body text of news item<BR>
&lt;news:author&gt;  - username of person who posted it<BR>
&lt;news:date&gt;    - date of when news item was posted<BR>
<B>9.</B> The layout can contain all normal HTML.<BR><BR>
Any questions/comments to <A HREF="mailto:jordie@eenc.net">jordie@eenc.net</A> or <A HREF="mailto:jordie@i2media.net">jordie@i2media.net</A> (which ever works).
