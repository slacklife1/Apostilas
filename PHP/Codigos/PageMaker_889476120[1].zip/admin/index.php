<?php
// ScriptName: index.php
// Author: Jordie Bodlay
// Date Started: Friday, 24 May 2002 
// Date Finished:Friday, 24 May 2002  
// Date Last Modified: Friday, 24 May 2002 
// Comments: Main login page for the admin
// Visit: http://www.i2media.net/pagemaker
 
$gpath = "";
include("includes/db_connect.php");

if(!$action){
	
	//display login form
	session_start();
	include("includes/css.php");
	?>
	<CENTER><FORM METHOD=POST ACTION="<?=$PHP_SELF?>">
	<TABLE border=0>
	<TR>
		<TD>Username:</TD>
		<TD><INPUT TYPE="text" NAME="username"></TD>
	</TR>
	<TR>
		<TD>Password:</TD>
		<TD><INPUT TYPE="password" name="password"></TD>
	</TR>
	<TR>
		<TD colspan=2><INPUT TYPE="submit" value="Login"></TD>

	</TR>
	</TABLE>
	<INPUT TYPE="hidden" name="action" value="login">
	</FORM></CENTER>

	<?
}elseif($action == "login"){
		session_start();
	$query = mysql_query("SELECT * FROM $tadmin WHERE username='$username' AND password='$password'");
	if(mysql_num_rows($query) > 0){
		$quick = mysql_fetch_array($query);
		$userid = $quick[id];
		session_register(username);
		session_register(userid);
		echo "<html><head><meta http-equiv=\"Refresh\" content=\"0; URL=main.php?s=$PHPSESSID\"></head><body>";
		
		echo "hang on a sec...";
		echo "</body></html>";
	}else{
		echo "Sorry ether the username or password that you entered is incorrect.";
	}
}

?>