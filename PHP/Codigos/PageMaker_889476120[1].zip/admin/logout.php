<?php
// ScriptName: logout.php
// Author: Jordie Bodlay
// Date Started: Friday, 24 May 2002 
// Date Finished: Friday, 24 May 2002 
// Date Last Modified: Friday, 24 May 2002 
// Visit: http://www.i2media.net/pagemaker
 

include("includes/checker.php");
session_unregister("username");
session_unregister("userid");
session_destroy();
	echo "<html><head><meta http-equiv=\"Refresh\" content=\"0; URL=../index.html\"></head><body>";
	echo "logging you out...";
	echo "</body></html>";
?>