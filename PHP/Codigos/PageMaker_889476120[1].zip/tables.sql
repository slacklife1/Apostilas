CREATE TABLE admin (
  id int(11) NOT NULL auto_increment,
  username varchar(255) NOT NULL default '',
  password varchar(255) NOT NULL default '',
  realname varchar(255) NOT NULL default '',
  email varchar(255) NOT NULL default '',
  news tinyint(4) NOT NULL default '1',
  pages tinyint(4) NOT NULL default '1',
  users tinyint(4) NOT NULL default '0',
  PRIMARY KEY (id),
  UNIQUE KEY id(id)
);

INSERT INTO admin VALUES (1, 'admin', 'pass', '', '', 1, 1, 1);

CREATE TABLE news (
  id int(11) NOT NULL auto_increment,
  subject text NOT NULL,
  content longblob NOT NULL,
  date varchar(255) NOT NULL default '',
  author varchar(255) NOT NULL default '',
  PRIMARY KEY (id),
  UNIQUE KEY id(id)
);


CREATE TABLE options (
  id int(11) NOT NULL auto_increment,
  name varchar(255) NOT NULL default '',
  value longtext NOT NULL,
  type varchar(255) NOT NULL default '',
  PRIMARY KEY (id),
  UNIQUE KEY id(id,name)
) ;


INSERT INTO options VALUES (1, 'layout', '<html>\r\n<head><title><page:title></title>\r\n</head>\r\n<body>\r\n  <p align="left"><font size=3><b><page:title></b></font><BR><font size=2><page:content></font></font></body></html>', '');
INSERT INTO options VALUES (2, 'newslayout', '<font size=3><b><news:subject></b></font><BR><font size=1><news:date> | by <news:author></font><BR><news:content><BR><BR>', '');
INSERT INTO options VALUES (3, 'newslimit', '8', 'text');

CREATE TABLE pages (
  id int(11) NOT NULL auto_increment,
  title varchar(255) NOT NULL default '',
  content longtext NOT NULL,
  author int(11) NOT NULL default '0',
  dmade varchar(255) NOT NULL default '',
  dedit varchar(255) NOT NULL default '',
  PRIMARY KEY (id),
  UNIQUE KEY title(title),
  UNIQUE KEY id(id)
);

