+ ----------------- +
+ PHP Pagemaker v1.2b +
+ ----------------- +


About
=====

This took me 4 hours to make. I made it for anyone who wants to use it 
on any site any amount of times. You may modify and edit the scripts to 
your hearts content, but please do not remove any of the credit information 
in the files. 
No links or "Made by"s are shown in the script publicly, but if you wish 
to link to us please use www.i2media.net or www.i2media.net/pagemaker.


Requirements
============

This has be made and used on Apache with PHP v4.0.5 and MySQL v3.23.32. 
It should work with any versions of PHP 4 but it cannot be guarrenteed.


Instructions
============
1. Edit tables.sql and /admin/includes/db_connect.php to your preferences 
(table names can be changed).

2. Make sure the directory below /admin is writeable. (CHMOD 777)

3. The default user and pass are "admin" and "pass". You can change this in
the sql file.

4. To include news into a page for the index page just put <news> where you
wish the news to appear. This will only work for the index page though.

5. Page format can have the following tags:
<page:title>   - title of the page
<page:content> - the main body content of the page
<page:author>  - username of the person who wrote it
<page:dmade>   - date the page was made 
<page:dedit>   - date the page was last updated

6. News format can have the following tags:
<news:subject> - subject of the news item
<news:content> - main body text of news item
<news:author>  - username of person who posted it
<news:date>    - date of when news item was posted


Other Notes
===========

This was not made to be a supported script. This may be the only version
I ever release, or it my be the first of many.

Any comments/questions/praise to jordie@eenc.net.


                     ##       
           ########  ###      
         ########## ####      
        #####   ### ## ##     
      ### ##     #####  ##    
      ##           ##   ##    
    ###                 ####  
  ####                    ### 
###  -------------------   ## 
##    MADE IN AUSTRALIA     ##
###  -------------------     #
###                          #
 ###         ##             ##
  ##$    ######## #         ##
   ## #####    #####       ## 
   #####         ###      ##  
                   ########   
                     ##### 
		     
                      ###
		       #

