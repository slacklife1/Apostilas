<?php
echo "Cesar Encryption Method<br><br>";

$texto = 'text to encrypt'; 
$key = 12; 

/* CESAR ALGORITHM */

$i = 0;
for(;;) {
	if ($i >= strlen($texto)) { break; }
$CH = ord($texto[$i])+$key;
$resultado = $resultado . chr($CH);

$i++;
}

/* OUTPUT */
echo "<b>Result : </b>$resultado <br><b>Key</b> : $key<br>";
echo "<b>Original Text :</b> $texto";
?>