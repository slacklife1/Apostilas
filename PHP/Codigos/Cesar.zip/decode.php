<?php
echo "Cesar Encryption Method<br><br>";

/* you can remove these two lines, and input the text you want from the browser  */
$texto = '�q��,�{,qzo~�|�';
$key = 12;

/* CESAR ALGORITHM */

$i = 0;
for(;;) {
	if ($i >= strlen($texto)) { break; }
$CH = ord($texto[$i])-$key;
$resultado = $resultado . chr($CH);

$i++;
}

/* OUTPUT */
echo "<b>Result : </b>$resultado <br><b>Key</b> : $key<br>";
echo "<b>Encrypted Text :</b> $texto";
?>