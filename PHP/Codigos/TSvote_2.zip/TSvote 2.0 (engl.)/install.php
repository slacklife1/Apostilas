<?php

session_start();

include("class_support.php");
include("class_vote.php");

$vote = new TSvote();


if (isset($processVote) && !isset($voteOnce)) {

  // This is the first time the user votes.
  // A new cookie is sent to the client with the
  // ID of the actual poll. Every user only has one
  // vote for each poll.

  header ("Set-Cookie: voteOnce[0]=$ID; expires=Friday, 16-Jan-2037 00:00:00 GMT; path=/");
}
else if (isset($processVote) && isset($voteOnce)) {

  // The user has already voted in the past. We have
  // to ckeck if the user wants to vote for a poll
  // he already has voted for or if he votes for a
  // new poll.

  $vote->voteID = $ID;
  $vote->_setPermission($voteOnce);
}

?>


<!-- stylesheet -->
<link rel="stylesheet" href="vote.css" type="text/css">
<link rel="stylesheet" href="text.css" type="text/css">


<?php

$vote->_defineJumpMenu();

$vote->_displayJumpMenu();

// Get the poll information of the specific poll and display it.
if (isset($ID)) {
  
  $vote->voteID = $ID;
  $vote_info = $vote->_displayVote();

  if (isset($processVote) && isset($radiobutton)) {
    $vote->_processVote($vote_info, $radiobutton, $voteOnce);
    $vote->_displayResult($vote_info);
  }

  if (isset($action)) {
    $vote->_displayResult($vote_info);
  }

}

?>