<table cellspacing="0" class="tableVoteResult">
  <tr> 
    <td colspan="3" class="tdVoteHeadline"><?php echo($vote_info["headline"]); ?></td>
  </tr>
  <?php

  for ($i = 0; $i < sizeof($vote_info["choice"]); $i++) {
    ?>
    <tr> 
      <td class="tdVoteResultLeft"><?php echo($vote_info["choice"][$i]); ?></td>
  
      <!-- Display the bar images -->
      <td class="tdVoteResultMiddle">
        <img src="<?php echo($this->bar_images[$i]); ?>" height="10" width="<?php echo($width[$i]); ?>" alt="bar">
      </td>

      <td class="tdVoteResultRight"><?php echo($vote_info["answer_relative"][$i]); ?> %</td>
    </tr>
    <?php
  }
  ?>
  <tr> 
    <td colspan="3" class="tdVoteResultBottom"> Number of votes: <?php echo($vote_info["totalVotes"]); ?></td>
  </tr>
</table>