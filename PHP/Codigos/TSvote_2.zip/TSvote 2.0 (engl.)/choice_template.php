<form name="vote" method="post" action="<?php echo($this->pageName); ?>">
  <table cellspacing="0" class="tableVoteChoice">
    <tr> 
      <td class="tdVoteHeadline" colspan="2"><?php echo($vote_info["headline"]); ?></td>
    </tr>
    <?php
  
      for ($i = 0; $i < sizeof($vote_info["choice"]); $i++) {
        ?>
        <tr> 
          <td class="tdVoteChoiceLeft"><input type="radio" name="radiobutton" value="<?php echo($i); ?>"></td>
          <td class="tdVoteChoiceRight"><?php echo($vote_info["choice"][$i]) ?></td>
        </tr>
        <?php
      }
      ?>
    <tr> 
      <td class="tdVoteChoiceBottom" colspan="2"> 
        <input type="submit" name="processVote" value="Vote!" class="buttonVote">
        <br>
        <br>
        <input type="hidden" name="ID" value="<?php echo($this->voteID); ?>">
        <a href="<?php echo("$this->pageName?action=displayResult&ID=".$this->voteID); ?>">
          show result
        </a>
      </td>
    </tr>
  </table>
</form>