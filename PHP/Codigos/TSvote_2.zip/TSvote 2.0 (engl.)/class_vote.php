<?php


/****************************************************
*                                                   *
*  TSvote 2.0                                       *
*                                                   *
*  by Thomas Schuster                               *
*  http://www.TSinter.net                           *
*                                                   *
*  TSvote is an easy to install internet poll that  *
*  uses textfiles to store the data. The results    *
*  are displayed graphically. Every user has only   *
*  one vote. This limitation is realized through    *
*  session management and cookies.                  *
*                                                   *
****************************************************/




class TSvote extends SupportFunctions {
  
  # EDIT THE NAME OF YOUR WEBSITE #
  var $pageName = "demo.php";
  
  var $voteID;

  // The data is stored in two textfiles.
  var $question_data = "question.dat";
  var $answer_data = "answer.dat";

  // The look of the poll system can be changed with templates.
  var $choice_template = "choice_template.php";
  var $result_template = "result_template.php";

  // Define the path to the bar images.
  var $bar_images = array ( "images/aqua.gif",
                            "images/yellow.gif",
                            "images/red.gif",
                            "images/green.gif",
                            "images/pink.gif",
                            "images/orange.gif",
                            "images/darkgreen.gif",
                            "images/gold.gif",
                            "images/grey.gif",
                            "images/blue.gif" );



  function _getVoteInfo() {

    # This function gets all the information about a poll
    # from the DAT files. It returns a two dimensional array
    # which contains the headline of the poll, the possible
    # choices, the results in percent (relative), the absolute
    # results and the total number of votes.

    $question_file = file($this->question_data);
    $answer_file = file($this->answer_data);

    # Find the selected poll in the DAT file.
    for ($i = sizeof($question_file) - 1; $i >=0; $i--) {
      $question_line = explode("|", $question_file[$i]);
      if (!strcmp($question_line[0], $this->voteID)) {
        $vote_info["headline"] = $question_line[1];
        # The corresponding answers are in the same row ($i)
        # of the answer_file.
        $answer_line = explode("|", $answer_file[$i]);
        $vote_info["totalVotes"] = $answer_line[1];
        for ($j = 2; $j < sizeof($question_line) - 1; $j++) {
          $vote_info["choice"][$j - 2] = $question_line[$j];
          $vote_info["answer_absolute"][$j] = $answer_line[$j];
          if ($vote_info["totalVotes"] == 0)
            $vote_info["answer_relative"][$j - 2] = 0;
          else $vote_info["answer_relative"][$j - 2] = round(($vote_info["answer_absolute"][$j]
                                                              / $vote_info["totalVotes"]) * 100, 2);
        }
      }
    }
    return $vote_info;
  }



  function _displayVote() {
    $vote_info = $this->_getVoteInfo();

    include ($this->choice_template);
    
    return $vote_info;
  }



  function _processVote(&$vote_info, $radiobutton, $voteOnce) {

    # This function registers the vote specified by the radiobutton
    # by changing the data of the $vote_info array. This array has
    # to be handed over as a pointer. The final step is to write
    # the new data of the array to the DAT file.

    if ($this->_checkPermission($voteOnce) == 1) {
      $vote_info["totalVotes"]++;
      $vote_info["answer_absolute"][$radiobutton + 2]++;
      $vote_info["answer_relative"][$radiobutton] = round(($vote_info["answer_absolute"][$radiobutton + 2]
                                                           / $vote_info["totalVotes"]) * 100, 2);

      $answer_file = file($this->answer_data);
          
      for ($i = 0; $i < sizeof($answer_file); $i++) {
        $answer_line = explode("|", $answer_file[$i]);
        
        # Find the selected poll in the DAT file.
        if (!strcmp($answer_line[0], $this->voteID)) {
          # Register the casted vote.
          $answer_line[$radiobutton + 2] = $vote_info["answer_absolute"][$radiobutton + 2];
          # Register the new total number of votes.
          $answer_line[1] = $vote_info["totalVotes"];
          $answer_file[$i] = implode("|", $answer_line);
          $logged = $this->_writeArray($this->answer_data, $answer_file, "w");
        }

      }
    } else echo("Sorry, but you only have one vote per poll!<br><br>");
    return 0;
  }



  function _displayResult($vote_info) {
    
    # Calculate the width of the bar images.
    for ($i = 0; $i < sizeof($vote_info["answer_relative"]); $i++)
      $width[$i] = 2 * round($vote_info["answer_relative"][$i]);

    # Include a template and display the poll result.
    include($this->result_template);

  }



  function _checkPermission($voteOnce) {

    $votePermission = 1;

    # Check if the user has already voted for the actual poll.
    for ($i = 0; $i < sizeof($voteOnce); $i++) {
      if ((isset($voteOnce)) && ($voteOnce[$i] == $this->voteID)) {
        # User has already voted.
        $votePermission = 0;
      }
    }
    return $votePermission;
  }



  function _setPermission($voteOnce) {

    # This function should guarantee that every user
    # has only one vote. The client has to support
    # cookies.

    $voteCookieIndex = sizeof($voteOnce);
    $setNewCookie = 1;
    for ($i = 0; $i < $voteCookieIndex; $i++) {
      if ($voteOnce[$i] == $this->voteID)
        $setNewCookie = 0;
    }
    if ($setNewCookie == 1)
      header ("Set-Cookie: voteOnce[$voteCookieIndex]=$this->voteID;
               expires=Friday, 16-Jan-2037 00:00:00 GMT; path=/");
    return 0;
  }

  

  function _setNewVote($vote_info) {

    # Add a new poll. The $vote_info array contains
    # the information about the poll. This array is
    # made up by the user input on the vote_admin page.

    # Get the number of existing polls to add the
    # ID of the new one.
    $question_file = file($this->question_data);
    $index = sizeof($question_file);

    $newQuestion[0] = $index;
    $newQuestion[1] = $vote_info["headline"];
    $newAnswer[0] = $index;
    $newAnswer[1] = 0;

    # Write the choice possibilities in the $question_data
    # and initialize the answers with 0.
    for ($i = 1; $i <= sizeof($vote_info["choice"]); $i++) {
      if ($vote_info["choice"][$i] != "") {
        $newQuestion[$i + 1] = $vote_info["choice"][$i];
        $newAnswer[$i + 1] = 0;
      }
    }

    $newQuestion = implode("|", $newQuestion)."|\r\n";;
    $newAnswer = implode("|", $newAnswer)."|\r\n";;

    $this->_writeLine($this->question_data, $newQuestion, "a");
    $this->_writeLine($this->answer_data, $newAnswer, "a");

    return 0;
  }



  function _defineJumpMenu() {

    # Define the jump menu from which you can
    # select the desired vote. This function
    # displays JavaScript code and has to be
    # called between the <head> tags of the
    # webpage.

    echo("<script language=\"JavaScript\" type=\"text/javascript\" >\n");
    echo("<!--\n");
    echo("function JumpMenu(targ,selObj,restore){\n");
    echo("  eval(targ+\".location='\"+selObj.options[selObj.selectedIndex].value+\"'\")\n");
    echo("  if (restore) selObj.selectedIndex=0\n");
    echo("}\n");
    echo("//-->\n");
    echo("</script>\n");

    return 0;
  }



  function _displayJumpMenu() {

    # Display a jump menu to choose the desired votes.
    # This function has to be called between <form> tags.

    echo("<select class=\"selectVoteMenu\" name=\"VoteMenu\" onChange=\"JumpMenu('parent',this,0)\">");
    echo("  <option selected>Select poll...</option>");
    $question_file = file($this->question_data);

    # Now display all questions from the $question_data.
    # The newest entry is on top.

    for ($i = sizeof($question_file) - 1; $i >= 0; $i--) {
      $question_line = explode("|", $question_file[$i]);
      
      echo("<option value=\"$this->pageName?ID=$question_line[0]\">");
      echo($question_line[1]);
      echo("</option>");
    }
    
    echo("</select>");
    return 0;
  }



}

?>