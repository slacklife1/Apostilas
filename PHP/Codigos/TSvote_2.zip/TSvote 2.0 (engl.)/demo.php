<?php

include("class_support.php");
include("class_vote.php");

$vote = new TSvote();


if (isset($processVote) && !isset($voteOnce)) {

  // This is the first time the user votes.
  // A new cookie is sent to the client with the
  // ID of the actual poll. Every user only has one
  // vote foe each poll.

  header ("Set-Cookie: voteOnce[0]=$ID; expires=Friday, 16-Jan-2037 00:00:00 GMT; path=/");
}
else if (isset($processVote) && isset($voteOnce)) {

  // The user has already voted in the past. We have
  // to ckeck if the user wants to vote for a poll
  // he already has voted for or if he votes for a
  // new poll.

  $vote->voteID = $ID;
  $vote->_setPermission($voteOnce);
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php echo($PHP_SELF); ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<?php $vote->_defineJumpMenu(); ?>

<!-- stylesheet -->
<link rel="stylesheet" href="vote.css" type="text/css">

</head>

<body>

<center>
  <table cellspacing="0" class="tableVoteMain">
    <tr> 
      <td class="tdVoteMenu">
        <a href="admin.php">admin.php</a>
        <br>
        <br>
        <form action="<?php echo($PHP_SELF); ?>">
          <?php $vote->_displayJumpMenu(); ?>
        </form>
      </td>
    </tr>
    <tr> 
      <td class="tdVoteMain"> 
        <?php

        if (isset($ID)) {
            
            $vote->voteID = $ID;
            $vote_info = $vote->_displayVote();

            if (isset($processVote) && isset($radiobutton)) {
              $vote->_processVote($vote_info, $radiobutton, $voteOnce);
              $vote->_displayResult($vote_info);
            }

            if (isset($action)) {
              $vote->_displayResult($vote_info);
            }

        }

        ?>
      </td>
    </tr>
    <tr> 
      <td class="tdCopyright">
        <a href="http://www.TSinter.net/source/vote/version_2/index.php" target="_self">TS<i>vote</i></a>&#153;
        &copy; 2001 <a href="http://www.TSinter.net" target="blank">TSinter.net</a> 
      </td>
    </tr>
  </table>
</center>

</body>
</html>