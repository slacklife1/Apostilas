<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Add new poll</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<!-- stylesheet -->
<link rel="stylesheet" href="vote.css" type="text/css">

</head>

<body>
<center>
  <form name="form1" method="post" action="<?php echo($PHP_SELF); ?>">
    <table cellspacing="0" class="tableVoteAdmin">
      <tr> 
        <td colspan="2" class="tdVoteHeadline">Launch your own poll!</td>
      </tr>
      <tr> 
        <td class="tdVoteAdminLeft">headline:</td>
        <td class="tdVoteAdminRight">
          <input type="text" name="headline" class="inputVoteAdminHeadline" size="40">
        </td>
      </tr>
      <tr> 
        <td class="tdVoteAdminLeft">choice 1:</td>
        <td class="tdVoteAdminRight"> 
          <input type="text" name="choice[1]" class="inputVoteAdmin" size="40">
        </td>
      </tr>
      <tr> 
        <td class="tdVoteAdminLeft">choice 2:</td>
        <td class="tdVoteAdminRight"> 
          <input type="text" name="choice[2]" class="inputVoteAdmin" size="40">
        </td>
      </tr>
      <tr> 
        <td class="tdVoteAdminLeft">choice 3:</td>
        <td class="tdVoteAdminRight"> 
          <input type="text" name="choice[3]" class="inputVoteAdmin" size="40">
        </td>
      </tr>
      <tr> 
        <td class="tdVoteAdminLeft">choice 4:</td>
        <td class="tdVoteAdminRight"> 
          <input type="text" name="choice[4]" class="inputVoteAdmin" size="40">
        </td>
      </tr>
      <tr> 
        <td class="tdVoteAdminLeft">choice 5:</td>
        <td class="tdVoteAdminRight"> 
          <input type="text" name="choice[5]" class="inputVoteAdmin" size="40">
        </td>
      </tr>
      <tr> 
        <td class="tdVoteAdminLeft">choice 6:</td>
        <td class="tdVoteAdminRight"> 
          <input type="text" name="choice[6]" class="inputVoteAdmin" size="40">
        </td>
      </tr>
      <tr> 
        <td class="tdVoteAdminLeft">choice 7:</td>
        <td class="tdVoteAdminRight"> 
          <input type="text" name="choice[7]" class="inputVoteAdmin" size="40">
        </td>
      </tr>
      <tr> 
        <td class="tdVoteAdminLeft">choice 8:</td>
        <td class="tdVoteAdminRight"> 
          <input type="text" name="choice[8]" class="inputVoteAdmin" size="40">
        </td>
      </tr>
      <tr> 
        <td class="tdVoteAdminLeft">choice 9:</td>
        <td class="tdVoteAdminRight"> 
          <input type="text" name="choice[9]" class="inputVoteAdmin" size="40">
        </td>
      </tr>
      <tr> 
        <td class="tdVoteAdminLeft">choice 10:</td>
        <td class="tdVoteAdminRight"> 
          <input type="text" name="choice[10]" class="inputVoteAdmin" size="40">
        </td>
      </tr>
      <tr> 
        <td colspan="2" class="tdVoteResultBottom"> 
          <p> 
            <input type="submit" name="newVote" value="Add poll">
            <br>
            <a href="demo.php">back</a>
            <br>
            <br>
          </p>
        </td>
      </tr>
    </table>
</form>

<?php


if (isset($newVote)) {

    include("class_support.php");
    include("class_vote.php");
    
    $vote_info["headline"] = $headline;
    for ($i = 1; $i < sizeof($choice); $i++)
        $vote_info["choice"][$i] = $choice[$i];

    $vote = new TSvote();
    $vote->_setNewVote($vote_info);

}

?>

</center>
</body>
</html>