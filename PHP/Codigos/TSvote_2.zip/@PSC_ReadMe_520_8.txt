Title: TSvote 2.0
Description: TSvote is a poll system, which displays the results graphically. It needs no database. Every user has only one vote per poll. This restriction is realized via cookies. New polls can be added through an admin interface admin.php. Code and layout are separated through templates and can easily be modified with style sheets.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=520&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
