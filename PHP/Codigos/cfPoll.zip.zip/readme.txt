cfPoll v0.2 by Chris Flanigan 
http://www.chrisf.net/
chris@chrisf.net

Run install.php which will set up cfPoll and give the proper files the proper permissions. 

Feel free to edit the variable block at the top of poll.php to suit the poll to your needs.

