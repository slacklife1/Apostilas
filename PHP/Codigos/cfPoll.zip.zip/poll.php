<?

// THIS IS THE VARIABLE BLOCK WHICH HELPS YOU TO CUSTOMIZE YOUR SCRIPT!!!!

// FONT STYLE
$font = "<font face=Tahoma size=2>";

// POLL DATA FILE
$file = "poll.dat";

// HOSTNAME DATA FILE
$ip_file = "poll_ips.dat";

// POLL QUESTION
$question = "What is your favorite type of fry?";

// TABLE HEADINGS
$heading1 = "Restaurant";
$heading2 = "Type of Fry";

// CHOICE 1
$poll1a = "Burger King";
$poll1b = "Straight Fry";

// CHOICE 2
$poll2a = "Hardees";
$poll2b = "Curly Fry";

// CHOICE 3
$poll3a = "Rally's";
$poll3b = "Seasoned Fry";

// CHOICE 4
$poll4a = "McDonald's";
$poll4b = "Shoestring Fry";

// CHOICE 5
$poll5a = "Steak and Shake";
$poll5b = "Mini Fry";

// THIS IS THE END OF THE VARIABLE BLOCK!!!!!



// IF NO PARAMETER GIVEN, THEN DISPLAY VOTING FORM
if ($go == "" || !isset($go)) {

echo "$font $question<br><br>";

echo "<form action=poll.php?go=submit method=post><SELECT NAME=vote><option value=1>$poll1a<option value=2>$poll2a<option value=3>$poll3a<option value=4>$poll4a<option value=5>$poll5a</select><br><br><input type=submit value=Vote></form>";

echo "$font <font size=1>Click <a href=poll.php?go=display>here</a> to view current poll results.";

}

// END OF VOTING FORM

// IF DISPLAY PARAMETER GIVEN, THEN DISPLAY VOTING RESULTS
if ($go == "display") {

$fd = fopen ($file, "r");
$contents = fread ($fd, filesize ($file));
$pieces = explode ("\n", $contents);
fclose ($fd);


echo "<table width=300 cellspacing=3><tr><td width=100 align=center>$font <u>$heading1</td><td width=150 align=center>$font <u>$heading2</td><td width=50 align=center>$font <u>Votes</td></tr>";

echo "<tr><td width=100>$font $poll1a</td><td width=150>$font $poll1b</td><td width=50 align=center>$font<b> $pieces[0]</td></tr>";

echo "<tr><td width=100>$font $poll2a</td><td width=150>$font $poll2b</td><td width=50 align=center>$font<b> $pieces[1]</td></tr>";

echo "<tr><td width=100>$font $poll3a</td><td width=150>$font $poll3b</td><td width=50 align=center>$font<b> $pieces[2]</td></tr>";

echo "<tr><td width=100>$font $poll4a</td><td width=150>$font $poll4b</td><td width=50 align=center>$font<b> $pieces[3]</td></tr>";

echo "<tr><td width=100>$font $poll5a</td><td width=150>$font $poll5b</td><td width=50 align=center>$font<b> $pieces[4]</td></tr>";

echo "</table><br>";


// CALCULATE TOTAL VOTES
$total_votes = $pieces[0] + $pieces[1] + $pieces[2] + $pieces[3] + $pieces[4];

echo "$font There have been a total of <b>$total_votes</b> votes.";


}


// IF THE USER JUST VOTED, THEN WRITE THEIR VOTE TO THE FILE
if ($go == "submit") {

// CHECK TO SEE IF HOST HAS ALREADY VOTED.
$fd = fopen ($ip_file, "r");
$contents = fread ($fd, filesize ($ip_file));
$pieces = explode ("\n", $contents);
$length_file = count($pieces);
$match = 0;
fclose ($fd);

for ($index = 0; $index < $length_file; $index++) {

if($pieces[$index] == $REMOTE_ADDR) {

$match = 1;
} }

// USER HAS NOT VOTED SO PROCEED AS USUAL
if ($match == 0) {

$f = fopen($ip_file,"a+");
fwrite($f,"$REMOTE_ADDR\n");
fclose($f);

$fd = fopen ($file, "r");
$contents = fread ($fd, filesize ($file));
$pieces = explode ("\n", $contents);
fclose ($fd);


switch ($vote) {

case "1":
$pieces[0] = ($pieces[0] + 1);
break;

case "2":
$pieces[1] = ($pieces[1] + 1);
break;

case "3":
$pieces[2] = ($pieces[2] + 1);
break;

case "4":
$pieces[3] = ($pieces[3] + 1);
break;

case "5":
$pieces[4] = ($pieces[4] + 1);
break;

}

$fd = fopen ($file, "w");
$blarg = implode("\n",$pieces); 
fwrite($fd,$blarg,strlen($blarg));
fclose ($fd);

echo "$font Thanks! Your vote has been successfully cast. You can view the <a href=poll.php?go=display>current poll results</a> here.";

}

}

// USER HAS VOTED, TELL THEM SO
if ($match == 1) {

echo "$font I'm sorry, but you've already voted in this poll.";

}

?>
