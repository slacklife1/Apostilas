<? 
setcookie ("userid");
if ($email <> "" and $password <> "") {

$conn=pg_pconnect("user=username dbname=phpquicksite");
$result=pg_exec($conn, "select userid from users where email='$email' and password='$password'");

if (pg_numrows($result) == 1) {
$userid=pg_result($result,0,'userid');
$success="yes";
if ($remember == "true") {
setcookie ("userid",$userid,time()+142200000);
} else {
setcookie ("userid",$userid);
}
} else {
$success="no";
}

}
?>
<html><!-- #BeginTemplate "/Templates/template.dwt" -->
<head>
<script>
<!--

function rollover(id) {
id.className="buttonrollover"
}

function rollout(id) {
id.className="button"
}

//-->
</script>
<!-- #BeginEditable "doctitle" --> 
<title>PHP Quicksite - Log in</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">
<!--

<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
//-->
</script>
<link rel="stylesheet" href="style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#0033CC" vlink="#0033CC" alink="#0033CC">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td colspan="2" height="1" valign="top" class="links"> &nbsp;<a href="index.php">Home</a></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" height="100">
  <tr> 
    <td colspan="2" height="242" valign="top"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="4" height="100%">
        <tr> 
          <td valign="top" class="side"> <img src="images/spacer.gif" width="1" height="1"><br>
            <b> 
            <?=date("F j, Y"); ?>
            </b> <br>
            <?$conn=pg_pconnect("user=username dbname=phpquicksite");?>
            <?if ($userid=="") {?>
            <br>
            Welcome, <b>guest</b>!<br>
            &gt;<a href="login.php">Log in</a><br>
            &gt;<a href="register.php">Register</a><br>
            <?} else {
$conn=pg_pconnect("user=username dbname=phpquicksite");
$result=pg_exec($conn, "select first_name,last_name from users where userid='$userid'");

if (pg_numrows($result) <> 0) {
$first_name=pg_result($result,0,'first_name');
$last_name=pg_result($result,0,'last_name');
$loggedin="true";
}?>
            <br>
            Welcome, <b> 
            <?=$first_name?>
            <?=$last_name?>
            </b> <br>
            &gt;<a href="bugs.php">Report a Bug</a><br>
            &gt;<a href="myaccount.php">My Account</a><br>
            &gt; <a href="editaccount.php">Edit Account</a><br>
            &gt; <a href="login.php">Log out</a> <br>
            <?} 
?>
          </td>
          <td valign="top" class="contentarea"> <span class="heading"> <!-- #BeginEditable "heading"-->Log 
        in<!-- #EndEditable --> 
            </span> <br>
            <br>
            <span class="content"> <!-- #BeginEditable "content" --> 
      <?
if ($success=="yes") {
?>
      Congratulations, you are now logged in. 
      <?
}
if ($success=="no") {
?>
      Sorry, you entered an incorrect login. You might want to <a href="register.php">register</a>. 
      <?
}
if ($success<>"yes") {
?>
      <form name="form1" method="post" action="login.php">
        E-mail: 
        <input type="text" name="email">
        <br>
        Password: 
        <input type="password" name="password">
        <br>
        <br>
        <input type="checkbox" name="remember" value="true">
        Remember me<br>
        <input type="submit" name="Submit" value="Log in">
      </form>
      Please note that in order to take advantage of user authentication, you 
      must enable cookies.<br>
      In Microsoft Internet Explorer 4.0, you can enable cookies from the menu 
      View&gt;Internet Options&gt;Advanced&gt;Security. In Netscape 4.0, you can 
      enable cookies from the menu Edit&gt;Preferences&gt;Advanced.<br>
      <?
}
?>
      <br>
      <br>
      <!-- #EndEditable --> </span> </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="1" colspan="2" valign="top" bgcolor="#000000" class="footer">Copyright 
      2002 Zack Coburn</td>
  </tr>
  <tr> 
    <td height="1" width="156"><img height="1" width="121" src="/library/images/spacer.gif"></td>
    <td width="576"></td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>