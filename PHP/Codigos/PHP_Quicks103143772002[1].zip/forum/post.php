<html>
<head>
<?
$conn=pg_pconnect("user=username dbname=phpquicksite");
if ($userid<>"") {
$result=pg_exec($conn, "select first_name,last_name from users where userid='$userid'");
if (pg_numrows($result) <> 0) {
$first_name=pg_result($result,0,'first_name');
$last_name=pg_result($result,0,'last_name');
$loggedin="true";
}
}

if ($forum<>"") {
$foruminfo=pg_exec($conn,"select details,title from forums where forumid=$forum");
if (pg_numrows($foruminfo)==0) {
$success="f";
?>
<meta http-equiv="refresh" content="0;URL=index.php">
<?
} else {
$title=pg_result($foruminfo,0,'title');
$details=pg_result($foruminfo,0,'details');
?>
<title><?=$title?></title>
<?
}

} else {
$success="f";
?>
<meta http-equiv="refresh" content="0;URL=index.php">
<?
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" text="#000000">
<?if ($success=="f") {?>You have invoked an error. You are being redirected to the forums page. <?} else {?>
<h3>
  <a href="forum.php?forum=<?=$forum?>"><?=$title?></a>
</h3>
<i>
<?=$details?>
</i><br>
<br>
<?if ($loggedin<>"true") {?>
You must be logged in to post to a forum 
<?} else {?>
<?
if ($subject<>"" and $post<>"" and $forum<>"" and $postid<>"") {
$postdate=date("m/d/Y");
pg_exec($conn,"insert into posts(userid,postdate,subject,post,forumid,parent) values($userid,'$postdate','$subject','$post',$forum,$postid);");
?>
Your message was successfully posted. <a href="forum.php?forum=<?=$forum?>&topic=<?=$postid?>">Click 
here</a> to go back and see it. 
<?
}?>
<form name="post" method="post" action="post.php?forum=<?=$forum?>&postid=<?=$postid?>">
  <?
  if ($postid=="") {?>
  You must select where your message will be posted 
  <?} else {
  if ($postid==0) {
  $postto="topics";
  } else {
  $postcheck=pg_exec($conn,"select subject from posts where postid=$postid");
  $postto=pg_result($postcheck,0,'subject');
  }
  ?>
  <b>Post to:</b> 
  <?=$postto?>
  <b><br>
  Subject:</b> 
  <input type="text" name="subject" maxlength="200">
  <br>
  <br>
  <b>Message: </b><br>
  <textarea name="post" cols="60" rows="8"></textarea>
  <br>
  <input type="submit" name="Submit" value="Post">
</form>
<?}}}?>
<br>
<br>
<hr>
<?if ($loggedin=="true") {?>
You are logged in as 
<?=$first_name?>
 <?=$last_name?>
 [<a href="../login.php">log out</a>] 
<?} else {?>
You are not logged in [<a href="../login.php">log in</a>] [<a href="../register.php">register</a>] 
<?}?>
<br>
<b>Copyright 2002 <a href="http://www.zackcoburn.com">Zack Coburn</a> </b> 
</body>
</html>
