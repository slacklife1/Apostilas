<html>
<head>
<?
$conn=pg_pconnect("user=username dbname=phpquicksite");
if ($userid<>"") {
$result=pg_exec($conn, "select first_name,last_name from users where userid='$userid'");
if (pg_numrows($result) <> 0) {
$first_name=pg_result($result,0,'first_name');
$last_name=pg_result($result,0,'last_name');
$loggedin="true";
}
}

if ($forum<>"") {
$foruminfo=pg_exec($conn,"select details,title from forums where forumid=$forum");
if (pg_numrows($foruminfo)==0) {
$success="f";
?><meta http-equiv="refresh" content="0;URL=index.php"><?
} else {
$title=pg_result($foruminfo,0,'title');
$details=pg_result($foruminfo,0,'details');
?><title><?=$title?></title>
<?
}

} else {
$success="f";
?>
<meta http-equiv="refresh" content="0;URL=index.php">
<?
}
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<?if ($success=="f") {?>You have invoked an error. You are being redirected to the forums page. <?} else {?>
<h3><a href="forum.php?forum=<?=$forum?>"><?=$title?></a></h3>
<i><?=$details?></i><br><br>
<?
if ($loggedin=="true") {
$forumadmin=pg_exec($conn,"select userid from forumadmin where forumid=$forum and userid=$userid");
if (pg_numrows($forumadmin)<>0) { $forumadmin="true"; }
}
if ($forumadmin=="true" and $delete<>"") {
pg_exec($conn,"delete from posts where postid=$delete");
pg_exec($conn,"delete from posts where parent=$delete");
}
?>
<?
      if ($topic=="" or $topic==0) {?>
	  <b>Topics:</b><br>
<?$topics=pg_exec($conn,"select subject,postid,userid from posts where forumid=$forum and parent=0");
	  for ($topic=0; $topic < pg_numrows($topics); $topic++) {
	  ?>
&gt;<a href="/forum/forum.php?forum=<?=$forum?>&topic=<?=pg_result($topics,$topic,'postid')?>"><b>
<?=pg_result($topics,$topic,'subject')?>
</b></a> 
<?if ($forumadmin=="true") {?>
<a href="forum.php?forum=<?=$forum?>&delete=<?=pg_result($topics,$topic,'postid')?>">delete</a> 
<?}?>
<?
$topicuserid=pg_result($topics,$topic,'userid');
$userresult=pg_exec($conn,"select first_name,last_name,userid,email from users where userid=$topicuserid;");?>
<br>
<a href="../user.php?userinfo=<?=pg_result($userresult,0,'userid')?>"><?=pg_result($userresult,0,'first_name')?> <?=pg_result($userresult,0,'last_name')?></a>&nbsp;(<a href="mailto:<?=pg_result($userresult,0,'email')?>"><?=pg_result($userresult,0,'email')?></a>)<br>
<?}?>
<br>
<a href="post.php?forum=<?=$forum?>&postid=0">Add topic</a> 
<?} else {
$thetopic=pg_exec($conn,"select subject,post,postdate,userid,postid from posts where postid=$topic");?>
<b> 
<?=pg_result($thetopic,0,'subject')?>
</b> (<?=pg_result($thetopic,0,'postdate')?>) <br>
<?=pg_result($thetopic,0,'post')?>
<br>
<?
$postuserid=pg_result($thetopic,0,'userid');
$userresult=pg_exec($conn,"select first_name,last_name,userid,email from users where userid=$postuserid;");?>
<a href="../user.php?userinfo=<?=pg_result($userresult,0,'userid')?>"><?=pg_result($userresult,0,'first_name')?> <?=pg_result($userresult,0,'last_name')?></a>&nbsp;(<a href="mailto:<?=pg_result($userresult,0,'email')?>"><?=pg_result($userresult,0,'email')?></a>)<br><br>
<br>
<?$posts=pg_exec($conn,"select subject,post,postdate,userid,postid from posts where parent=$topic");
for ($post=0; $post < pg_numrows($posts); $post++) {
?>
<b><?=pg_result($posts,$post,'subject')?></b> (<?=pg_result($posts,$post,'postdate')?>) <?if ($forumadmin=="true") {?><a href="forum.php?forum=<?=$forum?>&topic=<?=$topic?>&delete=<?=pg_result($posts,$post,'postid')?>">delete</a> <?}?><br>
<?=pg_result($posts,$post,'post')?>
<br>
<?
$postuserid=pg_result($posts,$post,'userid');
$userresult=pg_exec($conn,"select first_name,last_name,userid,email from users where userid=$postuserid;");?>
<a href="../user.php?userinfo=<?=pg_result($userresult,0,'userid')?>"><?=pg_result($userresult,0,'first_name')?> <?=pg_result($userresult,0,'last_name')?></a>&nbsp;(<a href="mailto:<?=pg_result($userresult,0,'email')?>"><?=pg_result($userresult,0,'email')?></a>)<br><br>
<?}?>
<a href="post.php?forum=<?=$forum?>&postid=<?=$topic?>">Post response</a>
<?
}
}?>
<br>
<br>
<hr>
<?if ($loggedin=="true") {?>
You are logged in as 
<?=$first_name?> <?=$last_name?> 
[<a href="../login.php">log out</a>] 
<?} else {?>
You are not logged in [<a href="../login.php">log in</a>] [<a href="../register.php">register</a>] 
<?}?>
<br>
<b>Copyright 2002 <a href="http://www.zackcoburn.com">Zack Coburn</a> </b> 
</body>
</html>
