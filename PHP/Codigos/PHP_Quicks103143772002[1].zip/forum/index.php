<html><!-- #BeginTemplate "/Templates/template.dwt" -->
<head>
<script>
<!--

function rollover(id) {
id.className="buttonrollover"
}

function rollout(id) {
id.className="button"
}

//-->
</script>
<!-- #BeginEditable "doctitle" --> 
<title>PHP Quicksite - Forums</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">
<!--

<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
//-->
</script>
<link rel="stylesheet" href="../style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#0033CC" vlink="#0033CC" alink="#0033CC">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td colspan="2" height="1" valign="top" class="links"> &nbsp;<a href="../index.php">Home</a></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" height="100">
  <tr> 
    <td colspan="2" height="242" valign="top"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="4" height="100%">
        <tr> 
          <td valign="top" class="side"> <img src="../images/spacer.gif" width="1" height="1"><br>
            <b> 
            <?=date("F j, Y"); ?>
            </b> <br>
            <?$conn=pg_pconnect("user=username dbname=phpquicksite");?>
            <?if ($userid=="") {?>
            <br>
            Welcome, <b>guest</b>!<br>
            &gt;<a href="../login.php">Log in</a><br>
            &gt;<a href="../register.php">Register</a><br>
            <?} else {
$conn=pg_pconnect("user=username dbname=phpquicksite");
$result=pg_exec($conn, "select first_name,last_name from users where userid='$userid'");

if (pg_numrows($result) <> 0) {
$first_name=pg_result($result,0,'first_name');
$last_name=pg_result($result,0,'last_name');
$loggedin="true";
}?>
            <br>
            Welcome, <b> 
            <?=$first_name?>
            <?=$last_name?>
            </b> <br>
            &gt;<a href="../bugs.php">Report a Bug</a><br>
            &gt;<a href="../myaccount.php">My Account</a><br>
            &gt; <a href="../editaccount.php">Edit Account</a><br>
            &gt; <a href="../login.php">Log out</a> <br>
            <?} 
?>
          </td>
          <td valign="top" class="contentarea"> <span class="heading"> <!-- #BeginEditable "heading"-->Forums<!-- #EndEditable --> 
            </span> <br>
            <br>
            <span class="content"> <!-- #BeginEditable "content" --><a href="addforum.php">Add 
            Forum! </a><br>
            <br>
            <b>All forums:</b><br>
            <?
	  $forums=pg_exec($conn,"select title,details,forumid from forums order by title desc;");
	  for ($forum=0; $forum < pg_numrows($forums); $forum++) {
	  ?>
            <img src="../images/bullet.gif"><a href="forum.php?forum=<?=pg_result($forums,$forum,'forumid')?>">
            <?=pg_result($forums,$forum,'title')?>
            </a><br>
            <?}?>
            <!-- #EndEditable --> </span> </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="1" colspan="2" valign="top" bgcolor="#000000" class="footer">Copyright 
      2002 Zack Coburn</td>
  </tr>
  <tr> 
    <td height="1" width="156"><img height="1" width="121" src="/library/images/spacer.gif"></td>
    <td width="576"></td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>