<?if ($first_name<>"" and $last_name<>"" and $email<>"" and $password<>"" and $address1<>"" and $city<>"" and $state<>"" and $zip<>"" and $phone_a<>"" and $phone_b<>"" and $phone_c<>"") {
$conn=pg_pconnect("user=username dbname=phpquicksite");

pg_exec($conn, "insert into users (first_name,last_name,email,password,address1,address2,city,state,zip,phone_a,phone_b,phone_c,biography,resume) values('$first_name','$last_name','$email','$password','$address1','$address2','$city','$state','$zip','$phone_a','$phone_b','$phone_c','$biography','$resume')");
$result=pg_exec($conn, "select userid from users where email='$email'");
$userid=pg_result($result,0,'userid');
setcookie ("userid",$userid);
echo "Congratulations. You are now registered. Please <a href='index.php'>click here</a>.";
} else {
?>
<html><!-- #BeginTemplate "/Templates/template.dwt" -->
<head>
<script>
<!--

function rollover(id) {
id.className="buttonrollover"
}

function rollout(id) {
id.className="button"
}

//-->
</script>
<!-- #BeginEditable "doctitle" --> 
<title>PHP Quicksite - Register</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">
<!--

<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
//-->
</script>
<link rel="stylesheet" href="style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#0033CC" vlink="#0033CC" alink="#0033CC">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td colspan="2" height="1" valign="top" class="links"> &nbsp;<a href="index.php">Home</a></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" height="100">
  <tr> 
    <td colspan="2" height="242" valign="top"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="4" height="100%">
        <tr> 
          <td valign="top" class="side"> <img src="images/spacer.gif" width="1" height="1"><br>
            <b> 
            <?=date("F j, Y"); ?>
            </b> <br>
            <?$conn=pg_pconnect("user=username dbname=phpquicksite");?>
            <?if ($userid=="") {?>
            <br>
            Welcome, <b>guest</b>!<br>
            &gt;<a href="login.php">Log in</a><br>
            &gt;<a href="register.php">Register</a><br>
            <?} else {
$conn=pg_pconnect("user=username dbname=phpquicksite");
$result=pg_exec($conn, "select first_name,last_name from users where userid='$userid'");

if (pg_numrows($result) <> 0) {
$first_name=pg_result($result,0,'first_name');
$last_name=pg_result($result,0,'last_name');
$loggedin="true";
}?>
            <br>
            Welcome, <b> 
            <?=$first_name?>
            <?=$last_name?>
            </b> <br>
            &gt;<a href="bugs.php">Report a Bug</a><br>
            &gt;<a href="myaccount.php">My Account</a><br>
            &gt; <a href="editaccount.php">Edit Account</a><br>
            &gt; <a href="login.php">Log out</a> <br>
            <?} 
?>
          </td>
          <td valign="top" class="contentarea"> <span class="heading"> <!-- #BeginEditable "heading"-->Register<!-- #EndEditable --> 
            </span> <br>
            <br>
            <span class="content"> <!-- #BeginEditable "content" --> <b> Bold fields required</b> 
      <form action="register.php" method="post" name="register">
        <table width="600" border="1" cellspacing="0" cellpadding="0" bordercolor="#000000">
          <tr bgcolor="lightgrey"> 
            <td width="150" nowrap><b>Name</b>:&nbsp;&nbsp;</td>
            <td> 
              <input type="text" name="first_name" maxlength="32" value="<?=$first_name?>">
              <input type="text" name="last_name" maxlength="64" value="<?=$last_name?>">
            </td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="150" nowrap><b>E-mail</b>:&nbsp;&nbsp;</td>
            <td> 
              <input type="text" name="email" maxlength="200" value="<?=$email?>">
            </td>
          </tr>
          <tr bgcolor="lightgrey"> 
            <td width="150" nowrap><b>Password</b>:&nbsp;&nbsp;</td>
            <td> 
              <input type="password" name="password" maxlength="100" value="<?=$password?>">
            </td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="150" nowrap>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr bgcolor="lightgrey"> 
            <td width="150" nowrap><b>Address</b>:&nbsp;&nbsp;</td>
            <td> 
              <input type="text" name="address1" value="<?=$address1?>">
              <br>
              <input type="text" name="address2" value="<?=$address2?>">
              (optional) </td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="150" nowrap><b>City</b>:&nbsp;&nbsp;</td>
            <td> 
              <input type="text" name="city" maxlength="100" value="<?=$city?>">
            </td>
          </tr>
          <tr bgcolor="lightgrey"> 
            <td width="150" nowrap><b>State</b>:&nbsp;</td>
            <td> 
              <input type="text" name="state" size="5" value="<?=$state?>" maxlength="2">
            </td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="150" nowrap><b>Zip</b>:</td>
            <td> 
              <input type="text" name="zip" size="7" value="<?=$zip?>" maxlength="5">
            </td>
          </tr>
          <tr bgcolor="lightgrey"> 
            <td width="150" nowrap><b>Phone</b>:&nbsp;&nbsp;</td>
            <td> &nbsp; 
              <input type="text" name="phone_a" maxlength="3" value="<?=$phone_a?>" size="3">
              - 
              <input type="text" name="phone_b" maxlength="3" value="<?=$phone_b?>" size="3">
              - 
              <input type="text" name="phone_c" maxlength="4" value="<?=$phone_c?>" size="4">
            </td>
          </tr>
        </table>
        <br>
        <table width="600" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
          <tr> 
            <td width="150" bgcolor="lightgrey">Biography:</td>
            <td bgcolor="lightgrey"> 
              <textarea name="biography" rows="8" cols="60"><?=$biography?></textarea>
            </td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="150">Resume: </td>
            <td> 
              <textarea name="resume" cols="60" rows="8"><?=$resume?></textarea>
            </td>
          </tr>
        </table>
        <br>
        You will be able to edit your account at any time<br>
        <input type="submit" name="Submit" value="Register!">
      </form>
      <!-- #EndEditable --> </span> </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="1" colspan="2" valign="top" bgcolor="#000000" class="footer">Copyright 
      2002 Zack Coburn</td>
  </tr>
  <tr> 
    <td height="1" width="156"><img height="1" width="121" src="/library/images/spacer.gif"></td>
    <td width="576"></td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>
<? } ?>
