<html><!-- #BeginTemplate "/Templates/template.dwt" -->
<head>
<script>
<!--

function rollover(id) {
id.className="buttonrollover"
}

function rollout(id) {
id.className="button"
}

//-->
</script>
<!-- #BeginEditable "doctitle" -->
<title>PHP Quicksite - Edit Account</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">
<!--

<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
//-->
</script>
<link rel="stylesheet" href="style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#0033CC" vlink="#0033CC" alink="#0033CC">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td colspan="2" height="1" valign="top" class="links"> &nbsp;<a href="index.php">Home</a></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" height="100">
  <tr> 
    <td colspan="2" height="242" valign="top"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="4" height="100%">
        <tr> 
          <td valign="top" class="side"> <img src="images/spacer.gif" width="1" height="1"><br>
            <b> 
            <?=date("F j, Y"); ?>
            </b> <br>
            <?$conn=pg_pconnect("user=username dbname=phpquicksite");?>
            <?if ($userid=="") {?>
            <br>
            Welcome, <b>guest</b>!<br>
            &gt;<a href="login.php">Log in</a><br>
            &gt;<a href="register.php">Register</a><br>
            <?} else {
$conn=pg_pconnect("user=username dbname=phpquicksite");
$result=pg_exec($conn, "select first_name,last_name from users where userid='$userid'");

if (pg_numrows($result) <> 0) {
$first_name=pg_result($result,0,'first_name');
$last_name=pg_result($result,0,'last_name');
$loggedin="true";
}?>
            <br>
            Welcome, <b> 
            <?=$first_name?>
            <?=$last_name?>
            </b> <br>
            &gt;<a href="bugs.php">Report a Bug</a><br>
            &gt;<a href="myaccount.php">My Account</a><br>
            &gt; <a href="editaccount.php">Edit Account</a><br>
            &gt; <a href="login.php">Log out</a> <br>
            <?} 
?>
          </td>
          <td valign="top" class="contentarea"> <span class="heading"> <!-- #BeginEditable "heading"-->Edit 
        Account <!-- #EndEditable --> 
            </span> <br>
            <br>
            <span class="content"> <!-- #BeginEditable "content" --> 
<?if ($loggedin<>"true") {
	  ?>
      Sorry, but you must be logged in to update your account
      <?
} else {

if ($vfirst_name<>"" and $vlast_name<>"" and $vemail<>"" and $vpassword<>"" and $vaddress1<>"" and $vcity<>"" and $vstate<>"" and $vzip<>"" and $vphone_a<>"" and $vphone_b<>"" and $vphone_c<>"") {
$result=pg_exec($conn, "select password from users where userid='$userid'");

if (pg_result($result,0,'password')==$vpassword) {
if ($vnewpassword=="") { 
$vnewpassword=$vpassword; 
}
pg_exec($conn, "update users set first_name='$vfirst_name',last_name='$vlast_name',email='$vemail',password='$vnewpassword',address1='$vaddress1',address2='$vaddress2',city='$vcity',state='$vstate',zip='$vzip',phone_a='$vphone_a',phone_b='$vphone_b',phone_c='$vphone_c',biography='$vbiography',resume='$vresume' where userid='$userid'");
}

}
?>
      <?
$result=pg_exec($conn, "select first_name,last_name,password,email,address1,address2,city,state,zip,phone_a,phone_b,phone_c,biography,resume from users where userid='$userid'");

if (pg_numrows($result) <> 0) {
$first_name=pg_result($result,0,'first_name');
$last_name=pg_result($result,0,'last_name');
$password=pg_result($result,0,'password');
$email=pg_result($result,0,'email');
$address1=pg_result($result,0,'address1');
$address2=pg_result($result,0,'address2');
$city=pg_result($result,0,'city');
$state=pg_result($result,0,'state');
$zip=pg_result($result,0,'zip');
$phone_a=pg_result($result,0,'phone_a');
$phone_b=pg_result($result,0,'phone_b');
$phone_c=pg_result($result,0,'phone_c');
$biography=pg_result($result,0,'biography');
$resume=pg_result($result,0,'resume');
}
?>
      <b>Bold fields required</b> 
      <form action="editaccount.php" method="post" name="register">
        <table width="600" border="1" cellspacing="0" cellpadding="0" bordercolor="#000000">
          <tr bgcolor="lightgrey"> 
            <td width="150" nowrap><b>Name</b>:&nbsp;&nbsp;</td>
            <td> 
              <input type="text" name="vfirst_name" maxlength="50" value="<?=$first_name?>">
              <input type="text" name="vlast_name" maxlength="50" value="<?=$last_name?>">
            </td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="150" nowrap><b>E-mail</b>:&nbsp;&nbsp;</td>
            <td> 
              <input type="text" name="vemail" maxlength="200" value="<?=$email?>">
            </td>
          </tr>
          <tr bgcolor="lightgrey">
            <td width="150" nowrap><b>Password</b>:&nbsp;&nbsp;</td>
            <td>
              <input type="password" name="vpassword" maxlength="100">
            </td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="150" nowrap>New Password:</td>
            <td> 
              <input type="password" name="vnewpassword">
            </td>
          </tr>
          <tr bgcolor="lightgrey"> 
            <td width="150" nowrap bgcolor="lightgrey">&nbsp;</td>
            <td bgcolor="lightgrey">&nbsp;</td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="150" nowrap><b>Address</b>:&nbsp;&nbsp;</td>
            <td> 
              <input type="text" name="vaddress1" value="<?=$address1?>">
              <br>
              <input type="text" name="vaddress2" value="<?=$address2?>">
              (optional)</td>
          </tr>
          <tr bgcolor="lightgrey"> 
            <td width="150" nowrap><b>City</b>:&nbsp;&nbsp;</td>
            <td> 
              <input type="text" name="vcity" maxlength="100" value="<?=$city?>">
            </td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="150" nowrap><b>State</b>:&nbsp;</td>
            <td> 
              <input type="text" name="vstate" size="5" value="<?=$state?>" maxlength="2">
            </td>
          </tr>
          <tr bgcolor="lightgrey"> 
            <td width="150" nowrap><b>Zip</b>:</td>
            <td> 
              <input type="text" name="vzip" size="7" value="<?=$zip?>" maxlength="5">
            </td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="150" nowrap><b>Phone</b>:&nbsp;&nbsp;</td>
            <td> 
              <input type="text" name="vphone_a" maxlength="3" value="<?=$phone_a?>" size="3">
              - 
              <input type="text" name="vphone_b" maxlength="3" value="<?=$phone_b?>" size="3">
              - 
              <input type="text" name="vphone_c" maxlength="4" value="<?=$phone_c?>" size="4">
            </td>
          </tr>
        </table>
        <br>
        <table width="600" border="1" cellpadding="0" cellspacing="0" bordercolor="#000000">
          <tr>
            <td width="150" bgcolor="lightgrey">Biography:</td>
            <td bgcolor="lightgrey">
              <textarea name="vbiography" rows="8" cols="60"><?=$biography?></textarea>
            </td>
          </tr>
          <tr bgcolor="#999999"> 
            <td width="150">Resume: </td>
            <td> 
              <textarea name="vresume" cols="60" rows="8"><?=$resume?></textarea>
            </td>
          </tr>
        </table>
        <br>
        <a href="user.php?userinfo=<?=$userid?>">What do users see when they 
        click on me?</a><br>
        <br>
        <input type="submit" name="Submit" value="Update!">
      </form>
<?
} 
?>
<!-- #EndEditable --> </span> </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="1" colspan="2" valign="top" bgcolor="#000000" class="footer">Copyright 
      2002 Zack Coburn</td>
  </tr>
  <tr> 
    <td height="1" width="156"><img height="1" width="121" src="/library/images/spacer.gif"></td>
    <td width="576"></td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>