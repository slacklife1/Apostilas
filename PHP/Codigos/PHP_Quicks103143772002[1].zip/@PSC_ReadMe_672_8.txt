Title: PHP Quicksite 2.0
Description: <Next generation version: http://www.sourceforge.net/projects/meunity>Please rate this and send comments! PHP Quicksite is a simple site-in-a-box for PHP and Postgresql. http://www.zackcoburn.com is an example of it. It includes user authentication (register/log in/log out/edit account/my account/search users), bug reporting, and a forum. It uses Dreamweaver for easy template updates.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=672&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
