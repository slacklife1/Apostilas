<html><!-- #BeginTemplate "/Templates/template.dwt" -->
<head>
<script>
<!--

function rollover(id) {
id.className="buttonrollover"
}

function rollout(id) {
id.className="button"
}

//-->
</script>
<!-- #BeginEditable "doctitle" --> 
<title>PHP Quicksite - Home</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">
<!--

<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
//-->
</script>
<link rel="stylesheet" href="style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#0033CC" vlink="#0033CC" alink="#0033CC">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td colspan="2" height="1" valign="top" class="links"> &nbsp;<a href="index.php">Home</a></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" height="100">
  <tr> 
    <td colspan="2" height="242" valign="top"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="4" height="100%">
        <tr> 
          <td valign="top" class="side"> <img src="images/spacer.gif" width="1" height="1"><br>
            <b> 
            <?=date("F j, Y"); ?>
            </b> <br>
            <?$conn=pg_pconnect("user=username dbname=phpquicksite");?>
            <?if ($userid=="") {?>
            <br>
            Welcome, <b>guest</b>!<br>
            &gt;<a href="login.php">Log in</a><br>
            &gt;<a href="register.php">Register</a><br>
            <?} else {
$conn=pg_pconnect("user=username dbname=phpquicksite");
$result=pg_exec($conn, "select first_name,last_name from users where userid='$userid'");

if (pg_numrows($result) <> 0) {
$first_name=pg_result($result,0,'first_name');
$last_name=pg_result($result,0,'last_name');
$loggedin="true";
}?>
            <br>
            Welcome, <b> 
            <?=$first_name?>
            <?=$last_name?>
            </b> <br>
            &gt;<a href="bugs.php">Report a Bug</a><br>
            &gt;<a href="myaccount.php">My Account</a><br>
            &gt; <a href="editaccount.php">Edit Account</a><br>
            &gt; <a href="login.php">Log out</a> <br>
            <?} 
?>
          </td>
          <td valign="top" class="contentarea"> <span class="heading"> <!-- #BeginEditable "heading"-->PHP 
            Quicksite<!-- #EndEditable --> 
            </span> <br>
            <br>
            <span class="content"> <!-- #BeginEditable "content" --> 
            Welcome to PHP Quicksite! PHP Quicksite is a site-in-a-box running 
            on PHP and Postgresql. It features user authentication (register/log 
            in/log out/edit account/my account/search users), a forum, and a page 
            for bug reporting. PHP Quicksite uses Dreamweaver so that you can 
            easily change this template and add pages.<br>
            <br>
            To install, all you have to do is create a Postgresql database for 
            whatever you want this site to be. Then, go through the files, and 
            replace <br>
            <i>$conn=pg_pconnect(&quot;user=username dbname=phpquicksite&quot;); 
            </i><br>
            with your username and database name. Then, log in to Postgresql, 
            and use the following SQL commands from db.txt:<br>
            <br>
            create table users(userid serial8 primary key, first_name varchar(32) 
            not null, last_name varchar(64) not null, email varchar(200) not null 
            unique, password varchar(100) not null, address1 varchar(100) not 
            null, address2 varchar(100), city varchar(100) not null, state char(2) 
            not null, zip varchar(32) not null, phone_a varchar(3) not null, phone_b 
            varchar(3) not null, phone_c varchar(4) not null, biography text, 
            resume text);<br>
            <br>
            create table bugs(bugid serial8 primary key, userid serial8 references 
            users, bugtext text, type integer, bugdate date);<br>
            <br>
            create table forums(forumid serial8 primary key, title varchar(100), 
            details text);<br>
            <br>
            create table posts(postid serial8 primary key, parent bigint, forumid 
            serial8 references forums, subject varchar(200), post text, postdate 
            date, userid serial8 references users);<br>
            <br>
            create table forumadmin(forumadminid serial8 primary key, userid serial8 
            references users, forumid serial8 references forums);<br>
            <br>
            drop index forumadmin_userid_key;<br>
            <br>
            drop index forumadmin_forumid_key;<br>
            <br>
            drop index posts_userid_key;<br>
            <br>
            drop index posts_forumid_key;<br>
            <br>
            drop index bugs_userid_key;<br>
            <br>
            <br>
            Once you have run those SQL commands, register for your Web site (making 
            you the first user, and therefore administrator). Congratulations! 
            You did it!<br>
            <br>
            If you would like to report bugs, simply e-mail them to <a href="mailto:zack@zackcoburn.com">zack@zackcoburn.com</a>.<br><!-- #EndEditable --> </span> </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="1" colspan="2" valign="top" bgcolor="#000000" class="footer">Copyright 
      2002 Zack Coburn</td>
  </tr>
  <tr> 
    <td height="1" width="156"><img height="1" width="121" src="/library/images/spacer.gif"></td>
    <td width="576"></td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>