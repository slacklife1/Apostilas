<html><!-- #BeginTemplate "/Templates/template.dwt" -->
<head>
<script>
<!--

function rollover(id) {
id.className="buttonrollover"
}

function rollout(id) {
id.className="button"
}

//-->
</script>
<!-- #BeginEditable "doctitle" --> 
<title>PHP Quicksite - Bugs</title>
<!-- #EndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">
<!--

<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
//-->
</script>
<link rel="stylesheet" href="style.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#0033CC" vlink="#0033CC" alink="#0033CC">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td colspan="2" height="1" valign="top" class="links"> &nbsp;<a href="index.php">Home</a></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0" height="100">
  <tr> 
    <td colspan="2" height="242" valign="top"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="4" height="100%">
        <tr> 
          <td valign="top" class="side"> <img src="images/spacer.gif" width="1" height="1"><br>
            <b> 
            <?=date("F j, Y"); ?>
            </b> <br>
            <?$conn=pg_pconnect("user=username dbname=phpquicksite");?>
            <?if ($userid=="") {?>
            <br>
            Welcome, <b>guest</b>!<br>
            &gt;<a href="login.php">Log in</a><br>
            &gt;<a href="register.php">Register</a><br>
            <?} else {
$conn=pg_pconnect("user=username dbname=phpquicksite");
$result=pg_exec($conn, "select first_name,last_name from users where userid='$userid'");

if (pg_numrows($result) <> 0) {
$first_name=pg_result($result,0,'first_name');
$last_name=pg_result($result,0,'last_name');
$loggedin="true";
}?>
            <br>
            Welcome, <b> 
            <?=$first_name?>
            <?=$last_name?>
            </b> <br>
            &gt;<a href="bugs.php">Report a Bug</a><br>
            &gt;<a href="myaccount.php">My Account</a><br>
            &gt; <a href="editaccount.php">Edit Account</a><br>
            &gt; <a href="login.php">Log out</a> <br>
            <?} 
?>
          </td>
          <td valign="top" class="contentarea"> <span class="heading"> <!-- #BeginEditable "heading"-->Bugs<!-- #EndEditable --> 
            </span> <br>
            <br>
            <span class="content"> <!-- #BeginEditable "content" --> 
      <?if ($loggedin<>"true") {
	  ?>
      Sorry, but you must be logged in to report bugs 
      <?} else {?>
      <?
	  if ($delete<>"" and $userid==1) {
	  pg_exec($conn,"delete from bugs where bugid=$delete");
	  }
	  if ($bugtext<>"") {
	  $bugdate=date("m/d/Y");
	  pg_exec($conn,"insert into bugs (bugtext,bugdate,type,userid) values ('$bugtext','$bugdate',$type,$userid);");
	  }
	  ?>
      <b>Report a bug: </b> 
      <form name="bugreport" method="post" action="bugs.php">
        <select name="type">
          <option value="1" selected>Error</option>
          <option value="2">Suggestion</option>
          <option value="3">Comment</option>
          <option value="4">Typo</option>
          <option value="5">Link error</option>
          <option value="6">Other</option>
        </select>
        <br>
        <textarea name="bugtext" cols="60" rows="8"></textarea>
        <br>
        <input type="submit" name="Submit" value="Submit">
      </form>
      <br>
      <br>
      <b>Bugs:</b> <br>
      <?
	  $bugs=pg_exec($conn,"select bugtext,type,bugdate,bugid from bugs order by bugid desc");
	  for ($bugrow=0; $bugrow < pg_numrows($bugs); $bugrow++) {  
	  if (pg_result($bugs,$bugrow,'type')==1) { $type="Error";}
	  if (pg_result($bugs,$bugrow,'type')==2) { $type="Suggestion";}
	  if (pg_result($bugs,$bugrow,'type')==3) { $type="Comment";}
	  if (pg_result($bugs,$bugrow,'type')==4) { $type="Type";}
	  if (pg_result($bugs,$bugrow,'type')==5) { $type="Link error";}
	  if (pg_result($bugs,$bugrow,'type')==6) { $type="Other";}
	  ?>
      <img src="images/bullet.gif"><b> 
      <?=pg_result($bugs,$bugrow,'bugdate')?>
      </b>: 
      <?=$type?>
      <?if ($userid==1) {?>
      <a href="bugs.php?delete=<?=pg_result($bugs,$bugrow,'bugid')?>">delete</a> 
      <?}?>
      <br>
      <?=pg_result($bugs,$bugrow,'bugtext')?>
      <br>
      <?}?>
      <?}?>
      <!-- #EndEditable --> </span> </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="1" colspan="2" valign="top" bgcolor="#000000" class="footer">Copyright 
      2002 Zack Coburn</td>
  </tr>
  <tr> 
    <td height="1" width="156"><img height="1" width="121" src="/library/images/spacer.gif"></td>
    <td width="576"></td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></html>