###############################################################
# CREATE DATABASE controls
###############################################################
CREATE DATABASE controls;
USE controls;
###############################################################
# CREATE TABLE colors
###############################################################
CREATE TABLE colors(
 id_color varchar(5) NOT NULL,
 color_name varchar(30) NOT NULL,
 PRIMARY KEY (id_color)
);
###############################################################
# CREATE TABLE boxes
###############################################################
CREATE TABLE boxes(
 id_box smallint(5) NOT NULL auto_increment,
 width float NOT NULL,
 height float NOT NULL,
 length float NOT NULL,
 color varchar(5) NULL,
 new tinyint NOT NULL,
 description varchar(250) NULL,
 create_date datetime NOT NULL,
 PRIMARY KEY (id_box),
 KEY idx_color (color)
);
###############################################################
# CREATE TABLE controls
###############################################################
CREATE TABLE controls(
 id_form smallint NOT NULL,
 id_control smallint NOT NULL,
 order_by smallint NOT NULL,
 access_key varchar(255) NULL,
 alt varchar(255) NULL,
 a_type varchar(255) NULL,
 border tinyint NULL,
 cols smallint NULL,
 coords varchar(255) NULL,
 char_set varchar(255) NULL,
 checked tinyint NULL,
 class varchar(255) NULL,
 disabled tinyint NULL,
 height smallint NULL,
 href varchar(255) NULL,
 href_lang varchar(255) NULL,
 h_space smallint NULL,
 label varchar(255) NULL,
 long_desc varchar(255) NULL,
 low_src varchar(255) NULL,
 id varchar(255) NULL,
 is_map tinyint NULL,
 max_length smallint NULL,
 multiple tinyint NULL,
 name varchar(255) NULL,
 rel varchar(255) NULL,
 rev varchar(255) NULL,
 read_only tinyint NULL,
 rows smallint NULL,
 shape varchar(10) NULL,
 size smallint NULL,
 style varchar(255) NULL,
 src varchar(255) NULL,
 tab_index smallint NULL,
 target varchar(255) NULL,
 title varchar(255) NULL,
 type varchar(10) NOT NULL,
 use_map varchar(255) NULL,
 value varchar(255) NULL,
 v_space smallint NULL,
 width smallint NULL,
 on_focus varchar(255) NULL,
 on_blur varchar(255) NULL,
 on_click varchar(255) NULL,
 on_dbl_click varchar(255) NULL,
 on_mouse_down varchar(255) NULL,
 on_mouse_up varchar(255) NULL,
 on_mouse_over varchar(255) NULL,
 on_mouse_move varchar(255) NULL,
 on_mouse_out varchar(255) NULL,
 on_key_press varchar(255) NULL,
 on_key_down varchar(255) NULL,
 on_key_up varchar(255) NULL,
 field_consider tinyint NULL,
 field_key tinyint NULL,
 field_require tinyint NULL,
 field_type char(1) NULL,
 with_help tinyint NULL,
 help_label varchar(255) NULL,
 help_text varchar(255) NULL,
 start varchar(255) NULL,
 end varchar(255) NULL,
 PRIMARY KEY (id_form, id_control),
 KEY idx_form (id_form),
 KEY idx_order (order_by)
);
###############################################################
# CREATE TABLE control_type
###############################################################
CREATE TABLE control_type (
 id_type VARCHAR(10) NOT NULL,
 PRIMARY KEY (id_type)
);
###############################################################
# CREATE TABLE control_select
###############################################################
CREATE TABLE control_select (
 id_form smallint NOT NULL,
 id_control smallint NOT NULL,
 id_option smallint NOT NULL,
 value varchar(255) NULL,
 label varchar(255) NOT NULL,
 selected tinyint NULL,
 PRIMARY KEY (id_form, id_control, id_option)
);
###############################################################
# CREATE TABLE feedback
###############################################################
CREATE TABLE feedback (
 id_message smallint NOT NULL auto_increment,
 first_name varchar(100) NOT NULL,
 last_name varchar(100) NOT NULL,
 email varchar(100) NOT NULL,
 user_name varchar(50) NULL,
 subject varchar(120) NOT NULL,
 feedback varchar(255) NOT NULL,
 send_date datetime NOT NULL,
 PRIMARY KEY (id_message)
);
###############################################################
# CREATE TABLE feedback
###############################################################
CREATE TABLE users (
 id_user_name varchar(100) NOT NULL,
 user_password varchar(30) NOT NULL,
 user_display_name varchar(100) NOT NULL,
 user_country varchar(5) NOT NULL,
 PRIMARY KEY (id_user_name)
);

###############################################################
# INSERT INTO colors
###############################################################
INSERT INTO colors VALUES ('r', 'red');
INSERT INTO colors VALUES ('be', 'blue');
INSERT INTO colors VALUES ('g', 'green');
INSERT INTO colors VALUES ('y', 'yellow');
INSERT INTO colors VALUES ('p', 'pink');
INSERT INTO colors VALUES ('bn', 'brown');
INSERT INTO colors VALUES ('w', 'white');
INSERT INTO colors VALUES ('bk', 'black');
###############################################################
# INSERT INTO boxes
###############################################################
INSERT INTO boxes VALUES (1, 10.5, 10.5, 10.5, 'r', 1, 'red box', '1/1/2001');
###############################################################
# INSERT INTO controls
###############################################################
INSERT INTO controls VALUES (1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.php.net/', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'a', NULL, 'PHP - home page', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 2, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'submit', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 3, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'button', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 4, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'reset', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 5, 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'images/php.gif', NULL, NULL, NULL, 'image', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 6, 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'itext', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 7, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ipassword', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 8, 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'icheckbox', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 9, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'iradio', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 10, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'isubmit', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 11, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ireset', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 12, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ifile', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 13, 13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ihidden', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 14, 14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'images/php.gif', NULL, NULL, NULL, 'iimage', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 15, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ibutton', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 16, 16, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'select', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 17, 17, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'textarea', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (1, 18, 18, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.php.net/', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'images/php.gif', NULL, NULL, NULL, 'aimage', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

INSERT INTO controls VALUES (2, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Id', NULL, NULL, NULL, NULL, NULL, NULL, 'id_box', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'itext', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, "I", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (2, 2, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Width', NULL, NULL, NULL, NULL, NULL, NULL, 'width', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'itext', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, "I", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (2, 3, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Height', NULL, NULL, NULL, NULL, NULL, NULL, 'height', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'itext', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, "I", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (2, 4, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Length', NULL, NULL, NULL, NULL, NULL, NULL, 'length', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'itext', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, "I", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (2, 5, 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Color', NULL, NULL, NULL, NULL, NULL, NULL, 'color', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'select', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, "S", 1, "Color", "Select box color", NULL, NULL);
INSERT INTO controls VALUES (2, 6, 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'New', NULL, NULL, NULL, NULL, NULL, NULL, 'new', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'icheckbox', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, "I", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (2, 7, 7, NULL, NULL, NULL, NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Description', NULL, NULL, NULL, NULL, NULL, NULL, 'description', NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'textarea', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, "S", 1, "Description", "Describe box with max 255 signs", NULL, NULL);
INSERT INTO controls VALUES (2, 8, 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Good', NULL, NULL, NULL, NULL, NULL, NULL, 'quality', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'iradio', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, "I", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (2, 9, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 'Average', NULL, NULL, NULL, NULL, NULL, NULL, 'quality', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'iradio', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, "I", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (2, 10, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bad', NULL, NULL, NULL, NULL, NULL, NULL, 'quality', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'iradio', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, "I", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (2, 11, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'create_date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ihidden', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, "D", NULL, NULL, NULL, NULL, NULL);

INSERT INTO controls VALUES (3, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "First name", NULL, NULL, NULL, NULL, NULL, NULL, 'first_name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "First name", 'itext', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, "S", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (3, 2, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "Last name", NULL, NULL, NULL, NULL, NULL, NULL, 'last_name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "Last name", 'itext', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, "S", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (3, 3, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "email", NULL, NULL, NULL, NULL, NULL, NULL, 'email', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "email", 'itext', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, "S", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (3, 4, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "User name", NULL, NULL, NULL, NULL, NULL, NULL, 'user_name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "User name", 'itext', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, "S", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (3, 5, 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "Subject", NULL, NULL, NULL, NULL, NULL, NULL, 'subject', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "Subject", 'itext', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, "S", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (3, 6, 6, NULL, NULL, NULL, NULL, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "Feedback", NULL, NULL, NULL, NULL, NULL, NULL, 'feedback', NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, "Feedback", 'textarea', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, "S", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (3, 7, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'send_date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ihidden', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, "D", NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (3, 8, 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'submit', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'isubmit', NULL, "Submit", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO controls VALUES (3, 9, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'reset', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ireset', NULL, "Reset", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

INSERT INTO controls VALUES (4, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'User name', NULL, NULL, NULL, NULL, NULL, NULL, 'id_user_name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'itext', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, "S", NULL, NULL, NULL, '<TD>', '</TD>');
INSERT INTO controls VALUES (4, 2, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Password', NULL, NULL, NULL, NULL, NULL, NULL, 'user_password', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ipassword', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, "S", NULL, NULL, NULL, '<TD>', '</TD>');
INSERT INTO controls VALUES (4, 3, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Display name', NULL, NULL, NULL, NULL, NULL, NULL, 'user_display_name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'itext', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, "S", NULL, NULL, NULL, '<TD>', '</TD>');
INSERT INTO controls VALUES (4, 4, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Country', NULL, NULL, NULL, NULL, NULL, NULL, 'user_country', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'select', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, "S", NULL, NULL, NULL, '<TD>', '</TD>');
INSERT INTO controls VALUES (4, 5, 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'submit', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'isubmit', NULL, "Submit", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '<TD ALIGN=\"CENTER\">', NULL);
INSERT INTO controls VALUES (4, 6, 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'reset', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ireset', NULL, "Reset", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '</TD>');
###############################################################
# INSERT INTO control_type
###############################################################
INSERT INTO control_type VALUES ('a');
INSERT INTO control_type VALUES ('submit');
INSERT INTO control_type VALUES ('button');
INSERT INTO control_type VALUES ('reset');
INSERT INTO control_type VALUES ('image');
INSERT INTO control_type VALUES ('itext');
INSERT INTO control_type VALUES ('ipassword');
INSERT INTO control_type VALUES ('icheckbox');
INSERT INTO control_type VALUES ('iradio');
INSERT INTO control_type VALUES ('isubmit');
INSERT INTO control_type VALUES ('ireset');
INSERT INTO control_type VALUES ('ifile');
INSERT INTO control_type VALUES ('ihidden');
INSERT INTO control_type VALUES ('iimage');
INSERT INTO control_type VALUES ('ibutton');
INSERT INTO control_type VALUES ('select');
INSERT INTO control_type VALUES ('textarea');
###############################################################
# INSERT INTO control_select
###############################################################
INSERT INTO control_select VALUES (4, 4, 1, 'US', 'United States', 0);
INSERT INTO control_select VALUES (4, 4, 2, 'UK', 'United Kingdom', 0);
INSERT INTO control_select VALUES (4, 4, 3, 'PL', 'Poland', 0);

