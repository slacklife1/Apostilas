<HTML>
<HEAD>
<SCRIPT language=javascript src="lib/form.js" type=text/javascript></SCRIPT>
</HEAD>
<BODY ONLOAD="iniForm()">
<P><A HREF="index.html">Main page</A></P>
<BIG><B>Controls class: Example 4 - data from database table controls with SQL use but without SQL class</B></BIG>
<P>
<B>Result</B>
</P>
<P>
<FORM NAME="user" ACTION="example4.php" METHOD="POST" ONSUBMIT="return AllowSubmit('user')" ONRESET="return AllowReset()">
<?PHP
 Require "lib/databases.inc";
 Require "lib/controls.inc";
 Require "lib/a.inc";
 Require "lib/button.inc";
 Require "lib/img.inc";
 Require "lib/input.inc";
 Require "lib/select.inc";
 Require "lib/textarea.inc";
 Require "lib/tools.php";
 Require "global.php";

 // functions section
 // this function checks if user name is new in our files.
 Function CheckUserName(&$dbObj, &$Message, $id_user_name) {
  $SQLIsNew = "SELECT COUNT(*) FROM users WHERE id_user_name = '" . $id_user_name . "'";
  $rIsNew = $dbObj->Query($SQLIsNew);
  If (!$rIsNew) {
   $Message = "Sorry, there is problem with checking if you user name is correctly. Try again or contact us.";
   Return False;
  } Else {
   $recIsNew = $dbObj->MoveFirstRec($rIsNew);
   If ($recIsNew[0] > 0) {
    $Message = "Sorry, there is that user name in our files. Could you give another one?";
    $dbObj->FreeResult($rIsNew);
    Return False;
   } Else {
    $dbObj->FreeResult($rIsNew);
    Return True;
   }
  }
 }
 // this function saves new user.
 Function SaveNewUser(&$dbObj, &$Message, $fields) {
  Extract($fields, EXTR_OVERWRITE);
  $SQLNew = "INSERT INTO users (id_user_name, user_password, user_display_name, user_country)"
   . " VALUES ('" . $id_user_name . "', '" . $user_password . "', '" . $user_display_name . "', '" . $user_country . "')";
  $rNew = $dbObj->Query($SQLNew);
  If ($rNew) {
   $Message = "Your data was successfully save.";
   Return True;
  } Else {
   $Message = "Insert data error.";
   Return False;
  }
 }
 // SQL section
 Switch ($REQUEST_METHOD) {
  Case "GET":
   $answer = $HTTP_GET_VARS;
   Break;
  Case "POST":
   $answer = $HTTP_POST_VARS;
   Break;
 }
 $Error = False;
 $ctr = New mControls;
 If (SizeOf($answer) > 1) {
  If ($Verify) {
   $dbObj = New mDatabase;
   $c = $dbObj->Open($gdbType, "C", $gdbConnect, $gdbUser, $gdbPassword, $gdbName);
   If (!$c) {
    $Message = "Sorry, there is problem with connecting with database. Try again or contact us.";
    $Error = True;
   } Else {
    $fields = getFieldsName($answer, $gdbtype);
    Extract($fields, EXTR_OVERWRITE);
    If (CheckUserName($dbObj, $Message, $id_user_name)) {
     If (!SaveNewUser($dbObj, $Message, $fields)) {
      $Error = True;
     }
    } Else {
     $Error = True;
    }
   }
  }
  If ($Message) $ctr->Message = $Message;
 }
 // create form section
 $ctr->dbType = $gdbType;
 $ctr->dbConnect = $gdbConnect;
 $ctr->dbUser = $gdbUser;
 $ctr->dbPassword = $gdbPassword;
 $ctr->dbName = $gdbName;
 $ctr->SQL = "SELECT * FROM controls WHERE id_form = 4 ORDER BY order_by";
 $ctr->GetDataFromDB($SQL);
 $SQLColor = "SELECT value, label FROM control_select WHERE id_form = 4 AND id_control = 4 ORDER BY label";
 $ctr->GetSelectFromDB($SQLColor, 3);
 If ($Error) $ctr->arrayValue = Array_Merge_Recursive(getConsiderFields($answer), $ctr->arrayValue);
 $ctr->LayoutType = 8;
 $ctr->WithSQLClassName = 1;
 $ctr->WithVerifyElement = 1;
 $ctr->WithMessageElement = 1;
 Echo $ctr->Show();
?>
</FORM>
</P>
<FONT COLOR="red">*</FONT> Signify required fields
</BODY>
</HTML>
