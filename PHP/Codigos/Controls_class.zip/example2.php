<HTML>
<HEAD>
<SCRIPT language=javascript src="lib/help.js" type=text/javascript></SCRIPT>
</HEAD>
<BODY>
<P><A HREF="index.html">Main page</A></P>
<BIG><B>Controls class: Example 2 - data from database table controls without SQL use</B></BIG>
<P>
<B>Result</B>
</P>
<P>
<FORM>
<?PHP
 Require "lib/databases.inc";
 Require "lib/controls.inc";
 Require "lib/a.inc";
 Require "lib/button.inc";
 Require "lib/img.inc";
 Require "lib/input.inc";
 Require "lib/select.inc";
 Require "lib/textarea.inc";
 Require "global.php";

 $ctr = New mControls;
 $ctr->dbType = $gdbType;
 $ctr->dbConnect = $gdbConnect;
 $ctr->dbUser = $gdbUser;
 $ctr->dbPassword = $gdbPassword;
 $ctr->dbName = $gdbName;
 $ctr->SQL = "SELECT * FROM controls WHERE id_form = 2 ORDER BY order_by";
 $ctr->GetDataFromDB($SQL);
 $SQLColor = "SELECT * FROM colors ORDER BY color_name";
 $ctr->GetSelectFromDB($SQLColor, 4);
 $ctr->LayoutType = 7;
 $ctr->WithSQLClassName = 0;
 Echo $ctr->Show();
?>
</FORM>
</P>
</BODY>
</HTML>
