<?PHP
$gdbType = "mysql";
$gdbConnect = "127.0.0.1";
$gdbName = "controls";
$gdbUser = "root";
$gdbPassword = "";
?>
