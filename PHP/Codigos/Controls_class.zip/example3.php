<HTML>
<HEAD>
<SCRIPT language=javascript src="lib/form.js" type=text/javascript></SCRIPT>
</HEAD>
<BODY ONLOAD="iniForm()">
<P><A HREF="index.html">Main page</A></P>
<BIG><B>Controls class: Example 3 - data from database table controls with SQL use and SQL class</B></BIG>
<P>
<B>Result</B>
</P>
<P>
<FORM NAME="feedback" METHOD="POST" ONSUBMIT="return AllowSubmit('feedback')" ONRESET="return AllowReset()">
<?PHP
 Require "lib/databases.inc";
 Require "lib/controls.inc";
 Require "lib/a.inc";
 Require "lib/button.inc";
 Require "lib/img.inc";
 Require "lib/input.inc";
 Require "lib/select.inc";
 Require "lib/textarea.inc";
 Require "lib/sql.php";
 Require "lib/datetime.php";
 Require "global.php";

 // SQL section
 Switch ($REQUEST_METHOD) {
  Case "GET":
   $answer = $HTTP_GET_VARS;
   Break;
  Case "POST":
   $answer = $HTTP_POST_VARS;
   Break;
 }
 $ctr = New mControls;
 If (SizeOf($answer) > 1) {
  If ($Message) $this->Message = $Message;
  If ($Verify) {
   $answer[D_N_N_C_send_date] = cDateTimePL(Time());
   $SQL =  mInsert("feedback", $answer);
   $result = mExecuteSQL($gdbType, "C", $gdbConnect, $gdbUser, $gdbPassword, $gdbName, $SQL);
   If ($result) {
    $ctr->Message = "Your data was successfully save.";
   } Else {
    $ctr->Message = "Insert data error.";
   }
  }
 }
 // create form section
 $ctr->dbType = $gdbType;
 $ctr->dbConnect = $gdbConnect;
 $ctr->dbUser = $gdbUser;
 $ctr->dbPassword = $gdbPassword;
 $ctr->dbName = $gdbName;
 $ctr->SQL = "SELECT * FROM controls WHERE id_form = 3 ORDER BY order_by";
 $ctr->GetDataFromDB($SQL);
 $ctr->LayoutType = 7;
 $ctr->WithSQLClassName = 1;
 $ctr->WithVerifyElement = 1;
 $ctr->WithMessageElement = 1;
 Echo $ctr->Show();
?>
</FORM>
</P>
<FONT COLOR="red">*</FONT> Signify required fields
</BODY>
</HTML>
