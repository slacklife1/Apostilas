<HTML>
<HEAD>
</HEAD>
<BODY>
<FORM>
<?PHP
 Require "lib/controls.inc";
 Require "lib/a.inc";
 Require "lib/button.inc";
 Require "lib/img.inc";
 Require "lib/input.inc";
 Require "lib/select.inc";
 Require "lib/textarea.inc";

 $ctr = New mControls;
 $ctr->ControlsNumber = 17;
 $ctr->arrayType = Array("a", "submit", "button", "reset", "image", "itext", "ipassword", "icheckbox", "iradio", "isubmit", "ireset", "ifile", "ihidden", "iimage", "ibutton", "select", "textarea");
 $ctr->arrayHref[0] = "http://www.php.net/";
 $ctr->arraySrc[4] = "images/php.gif";
 $ctr->arraySrc[13] = "images/php.gif";
 $ctr->arrayValue = Array("PHP - home page");
 Echo $ctr->Show()
?>
</FORM>
</BODY>
</HTML>
