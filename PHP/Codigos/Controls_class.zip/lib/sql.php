<?PHP
// MAIN PART
//
// File: sql.php
// Author: Andrzej Manczyk
// email: amanczyk@poczta.onet.pl
// Project: SQL functions
// Version: 1.0.1
// PHP: 4.04
//
//Function list:
// mFieldName: returns field name without additional descriptions
// misRequire: finds out whether field is require
// misKey: finds out whether field is table key
// misConsider: finds out whether form element will use in SQL statement
// mPrepareValue: prepares value in regard of field type
// mFieldType: describes field type in "S_, D_, I_, F_, R_" notation
// mInsert: returns SQL Insert statement
// mUpdate: returns SQL Update statement
// mDelete: returns SQL Delete statement
//
// HTML elements name structure e.g S_R_K_C_firstname, I_N_N_C_age:
// 2 signs: field type: S_, D_, I_, F_, R_
//    S - string
//    D - date
//    I - integer
//    F - float
//    R - real
// 2 signs: field require: R_, N_
//    R - require
//    N - not require
// 2 signs: field key: K_, _N
//    K - is table primary key
//    N - is not table primary key
// 2 signs: form element consideration
//    C - is include in SQL statement
//    N - is omit in SQL statement
// Rest signs: real field name in database table
//
//Inputs:
// name: field name without additional descriptions
// value: field value
// tableName: name of the database table
// answer: an associative array of variables passed to the current
//         script via the HTTP POST (HTTP_POST_VARS)
//         or HTTP GET (HTTP_GET_VARS) method
//Returns:
// INSERT and UPDATE SQL statement
Function mFieldName($name) {
 Return Substr($name, 8);
}
Function misRequire($name) {
 $result = SubStr($name, 2, 2);
 If ($result == "R_") {
  Return True;
 } Else {
  Return False;
 }
}
Function misKey($name) {
 $result = SubStr($name, 4, 2);
 If ($result == "K_") {
  Return True;
 } Else {
  Return False;
 }
}
Function misConsider($name) {
 $result = SubStr($name, 6, 2);
 If ($result == "C_") {
  Return True;
 } Else {
  Return False;
 }
}
Function mPrepareValue($name, $value) {
 If ($value == "NULL") Return $value;
 $result = SubStr($name, 0, 2);
 $value = Str_Replace("'", "''", StripSlashes($value));
 Switch ($result) {
  Case "S_":
   $val = "'" . $value . "'";
   Break;
  Case "D_":
   $val = "'" . $value . "'";
   Break;
  Case "I_":
   $val = (int) $value;
   Break;
  Case "F_":
   $value = Str_Replace(",", ".", $value);
   $val = (float) $value;
   Break;
  Case "R_":
   $value = Str_Replace(",", ".", $value);
   $val = (real) $value;
   Break;
  Default:
   $val = $value;
 }
 Return $val;
}
Function mFieldType($type) {
 Switch ($type) {
  Case "char":
  Case "varchar":
  Case "string":
  Case "text":
  Case "tinytext":
  Case "mediumtext":
  Case "longtext":
   Return "S_";
  Case "datetime":
  Case "date":
   Return "D_";
  Case "int":
  Case "integer":
  Case "smallint":
  Case "tinyint":
  Case "mediumint":
  Case "bigint":
  Case "byte":
   Return "I_";
  Case "float":
   Return "F_";
  Case "double":
  Case "real":
  Case "decimal":
  Case "numeric":
   Return "R_";
 }
}
Function mInsert($tableName, $answer) {
 $elements = SizeOf($answer);
 If ($elements == 0) Return "";
 $ins = "INSERT INTO " . $tableName . " (";
 $key = Array_Keys($answer);
 For ($i = 0; $i < $elements; $i++) {
  If (misConsider($key[$i])) {
   $ins = $ins . mFieldName($key[$i]) . ", ";
  }
 }
 If (SubStr($ins, -2) == ", ") $ins = SubStr($ins, 0, -2);
 $ins = $ins . ") VALUES (";
 $value = Array_Values($answer);
 For ($i = 0; $i < $elements; $i++) {
  If (misConsider($key[$i])) {
   If (!$value[$i]) $value[$i] = "NULL";
   $ins = $ins . mPrepareValue($key[$i], $value[$i]) . ", ";
  }
 }
 If (SubStr($ins, -2) == ", ") $ins = SubStr($ins, 0, -2);
 $ins = $ins . ")";
 Return $ins;
}
Function mUpdate($tableName, $answer) {
 $elements = SizeOf($answer);
 If ($elements == 0) Return "";
 $upd = "UPDATE " . $tableName . " SET ";
 $where = " WHERE 0 = 0";
 $key = Array_Keys($answer);
 $value = Array_Values($answer);
 For ($i = 0; $i < $elements; $i++) {
  If (misConsider($key[$i])) {
   If (!$value[$i]) $value[$i] = "NULL";
   If (misKey($key[$i])) {
    $where = $where . " AND " . mFieldName($key[$i]) . " = "
     . mPrepareValue($key[$i], $value[$i]);
   } Else {
    $upd = $upd . mFieldName($key[$i]) . " = "
     . mPrepareValue($key[$i], $value[$i]) . ", ";
   }
  }
 }
 If (SubStr($upd, -2) == ", ") $upd = SubStr($upd, 0, -2);
 If (SubStr($where, -2) == ", ") $where = SubStr($where, 0, -2);
 $upd = $upd . $where;
 Return $upd;
}
Function mDelete($tableName, $answer) {
 $elements = SizeOf($answer);
 If ($elements == 0) Return "";
 $del = "DELETE FROM " . $tableName . " WHERE 0 = 0 ";
 $key = Array_Keys($answer);
 $value = Array_Values($answer);
 For ($i = 0; $i < $elements; $i++) {
  If (misConsider($key[$i]) And misKey($key[$i])) {
   If (!$value[$i]) $value[$i] = "NULL";
   $del = $del . " AND " . mFieldName($key[$i]) . " = "
    . mPrepareValue($key[$i], $value[$i]);
  }
 }
 Return $del;
}
Function mExecuteSQL($dbType, $dbConnectType, $dbConnect, $dbUser, $dbPassword, $dbName, $SQL) {
 $dbObj = New mDatabase;
 If ($dbObj->Open($dbType, $dbConnectType, $dbConnect, $dbUser, $dbPassword)) {
  If ($dbType != "pg") $dbObj->SelectDB($dbName);
  $rData = $dbObj->Query($SQL);
  If ($rData) Return True;
 }
 Return False;
}
// END MAIN PART
?>
