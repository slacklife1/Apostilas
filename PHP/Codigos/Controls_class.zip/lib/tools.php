<?PHP
Function getFieldsName($arrayFields, $dbType) {
 $key = Array_Keys($arrayFields);
 $values = Array_Values($arrayFields);
 For ($i = 0; $i < Count($arrayFields); $i++) {
  If (Substr($key[$i], 1, 1) == "_") {
   $name = Substr($key[$i], 8);
  } Else {
   $name = $key[$i];
  }
  $arrayName[$name] = StripSlashes($values[$i]);
  $arrayName[$name] = Str_Replace("'", "''", $arrayName[$name]);
 }
 Return $arrayName;
}
Function getControlsName($arrayFields) {
 $key = Array_Keys($arrayFields);
 $values = Array_Values($arrayFields);
 For ($i = 0; $i < Count($arrayFields); $i++) {
  If (Substr($key[$i], 1, 1) == "_") {
   $name = "ctr" . Substr($key[$i], 8);
  } Else {
   $name = "ctr" . $key[$i];
  }
  $arrayControl[$name] = $values[$i];
  $arrayControl[$name] = ConvertToHTMLSigns($arrayControl[$name]);
 }
 Return $arrayControl;
}
Function getConsiderFields($arrayFields) {
 $key = Array_Keys($arrayFields);
 $values = Array_Values($arrayFields);
 For ($i = 0; $i < Count($arrayFields); $i++) {
  If (Substr($key[$i], 6, 2) == "C_") {
   $arrayConsider[] = StripSlashes($values[$i]);
  }
 }
 Return $arrayConsider;
}
Function ConvertToHTMLSigns($text) {
 $text = StripSlashes($text);
 $text = Str_Replace("<", "&lt;", $text);
 $text = Str_Replace(">", "&gt;", $text);
 $text = Str_Replace("\"", "&quot;", $text);
 $text = Str_Replace("'", "&#0146;", $text);
 $text = Str_Replace("&", "&amp;", $text);
 Return $text;
}
?>