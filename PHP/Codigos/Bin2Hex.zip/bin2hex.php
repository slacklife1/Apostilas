<html>

<head>

<title>Bin 2 Hex</title>

</head>

<body bgcolor="#000000" link="#666666" vlink="#666666" alink="#666666" text="#888888">

<center><h3>Bin 2 Hex</h3>

<?

	/*
	Note: binValue is the name for the text box in bin2hex.html.
	We use the variable $binValue because it contains whatever
	was entered by the user in bin2hex.html (you should already know that;)
	*/

	//check if the text field on input page is not blank.
	//if so, report that to the user and stop executing the script
	if(!$binValue) die("<a href=bin2hex.html>Please go back and give a value!</a>");

	//the function bin2hex() returns a hex value for whatever was passed to it.
	//Here we let $hex equal the return value
	$hex = bin2hex($binValue);

	//print the output to the page
	print "The hexidecimal representation of the binary value <b>".$binValue."</b> is:&nbsp&nbsp&nbsp<b>".$hex."</b><br>";
	
	//make a link back
	print "<a href=bin2hex.html>Back</a>";	

?>

<hr width="75%">

<p>Made by Canivour</p>

</body>

</html>