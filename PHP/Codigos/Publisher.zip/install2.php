<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


include "security_functions.php";
include "functions.php";

if($pass1!=$pass2 || $pass2!=$pass1)
{
	?> <font color=black face=verdana size=2>Passwords do not match! Click <a href=install.php>here</a> to try again.</font> <? 
}
else
{	    
	if(strlen($email)<5)
	{
	    ?> <font color=black face=verdana size=2><center>Email must be at least five characters long! Click <a href=install.php>here</a> to try again.</center></font> <?
	}
	else
	{
	    addUser($username, $pass1, $email);	
		?> <font color=black face=verdana size=2><center>Install successful!<br><br>Please delete install.php and install2.php then click <a href=index.php>here</a>.</centre> <?
	}	
}
writeToFile("db/pp_url.txt", $pp_url);
?>


