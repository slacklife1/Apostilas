<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();
if(session_is_registered("arbitraryVariable"))  
{

include("menu.inc"); 

//The functions page
include "functions.php";

$fileNameWithPath="db/".$fileName;

echo "<form method=post action='edit3.php?fileName=$fileName'>"; 

  	//Reads file into string
	$fileString = readFileContents("$fileNameWithPath");
	
	$old_header = explode("[H]", $fileString);
	$old_image_url = explode("[P]", $fileString);
	$old_snippet = explode("[S]", $fileString);	
	$old_body = explode("[B]", $fileString);
	
	
	echo "
	
	<table cellspacing='0' cellpadding='0' width='100%'>

<tr>
       <td height=20>
	   	   <font color=black face=verdana size=2>Title</font>
	   </td>
	   <td height=20>
	   	   <input type=text name=title size=50 value='$old_header[1]'>
	   </td>
</tr>

<tr>
       <td height=20>
	   	   <font color=black face=verdana size=2>Image URL</font>
	   </td>
	   <td height=20>
	   	   <input type=text name=image_url size=50 value='$old_image_url[1]'>
	   </td>
</tr>

<tr>
       <td height=20>
	   	   <font color=black face=verdana size=2>Snippet</font>
	   </td>
	   <td height=20>
	   	   <textarea name=snippet cols=100 rows=6>$old_snippet[1]</textarea>
	   </td>
</tr>

<tr valign=top>
       <td height='200'>
	   	   <font color=black face=verdana size=2>Content</font>
	   </td>
	   <td height='20'>
		   <textarea name=body cols=100 rows=14>$old_body[1]</textarea>
	   </td>
</tr>
</table>


<br><center><input type=submit value=Edit></center>
</form>

";
}

else 
{
    include("menu.inc"); 
	?> <font color=black face=verdana size=2><center>You are not logged in!</center></font> <?
}

?>
