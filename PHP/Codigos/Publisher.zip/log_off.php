<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();
session_destroy(); 

include("menu.inc");
?> <font color=black face=verdana size=2><center>Logoff successful!</center></font>
<meta http-equiv='refresh' content='1;URL=index.php'>