<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


include("functions.php");



if($fileName=="")
{
    $fileName=readFileContents("db/file_count.txt");
}

$templateData = readFileContents("db/template1.txt");
$front_page_image = readFileContents("db/front_page_image.txt");
$headline_number = readFileContents("db/headline_number.txt");
$pp_url = readFileContents("db/pp_url.txt");
$count = readFileContents("db/count.txt");



$output_posts=0;
while(($fileName>0) && ($output_posts<10))
{		
	//Opens appropriate news file 
	$fileNameWithPath="db/".$fileName;
	$rawData = readFileContents($fileNameWithPath);
	//If file contains a delete marker skip 1 itteration, i.e. do not build anything for 
	//this itteration and goto the next file
	if($rawData=="[X]") 
	{	
		$fileName=$fileName-1;				
		continue;
    }
	else
	{	
	//Splits up $rawData
	$title = explode("[H]", $rawData);
	$snippet = explode("[S]", $rawData);
	$image_raw = explode("[P]", $rawData);
	$body = explode("[B]", $rawData);	
	$user = explode("[U]", $rawData);
	$day = explode("[D]", $rawData);
	$month = explode("[M]", $rawData);
	$year = explode("[Y]", $rawData);
	$time = explode("[T]", $rawData);
	$email = explode("[E]", $rawData);	
	
	//Some general settings
	$image="<img src=".$image_raw[1]." ".$front_page_image.">";
	$title_url="http://".$pp_url."/news_content.php?fileName=$fileName"; //support for older databases	
	$backpage_url="http://".$pp_url."/news_content.php?fileName=$fileName"; //the new tag
	$image_url="<a href=http://".$pp_url."/news_content.php?fileName=$fileName>".$image."</a>";	
	
	//Opens up front page template and converts the tags to varibles then saves as $newsData
	$newsData = $templateData;
	$newsData = str_replace("[title]", $title[1], $newsData);
	$newsData = str_replace("[title_url]", $title_url, $newsData); //for older databases
	$newsData = str_replace("[backpage_url]", $backpage_url, $newsData);
	$newsData = str_replace("[snippet]", $snippet[1], $newsData);
	
	if($image_raw[1]!="") 
	{
	     $newsData = str_replace("[image]", $image, $newsData);
	}
	else if($image_raw[1]=="") 
	{
		 $newsData = str_replace("[image]", $image_warning, $newsData);
	}
	
	if($image_raw[1]!="") 
	{
	     $newsData = str_replace("[image_url]", $image_url, $newsData);
	}
	else if($image_raw[1]=="") {
		 $newsData = str_replace("[image_url]", "", $newsData);
	}
		
	$newsData = str_replace("[body]", $body[1], $newsData);
	$newsData = str_replace("[user]", $user[1], $newsData);
	$newsData = str_replace("[day]", $day[1], $newsData);
	$newsData = str_replace("[month]", $month[1], $newsData);
	$newsData = str_replace("[year]", $year[1], $newsData);
	$newsData = str_replace("[time]", $time[1], $newsData);
	$newsData = str_replace("[email]", $email[1], $newsData);	     

	$output_posts=$output_posts+1;
	$fileName=$fileName-1;	
	echo($newsData);
	}
}
if($fileName>0)
{
    echo("<br><br><div align=right><a href=archive.php?fileName=$fileName>Next 10 >></a></div>");	
}
?>