#################################################################
# Publisher Pro v2.3						#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts			#
#################################################################

Clean Installaion:
==================

1) Create a new directory on your web server

2) Upload all *.php files, menu.inc and data.txt to your newly created directory

3) Upload the db directory to within your newly created directory


Your directory structure should look like this:

	root --> publisherpro --> db --> All *.txt files except for data.txt and readme.txt
	root --> publisherpro --> All *.php files
	root --> publisherpro --> data.txt
	root --> publisherpro --> menu.inc


4) CHMOD data.txt to 777

5) CHMOD the db directory and all files within it to 777

6) Locate install.php inside your Publisher Pro directory and open it in your browser. The first three options are your login settings, remember these. The forth option is your full url (without the "http://" and the last "/") to the Publisher Pro directory. Please delete install.php and install2.php after you have completed this step.

7) Now login and goto configuration to set up your options first.



Upgrading:
==========

Backup your old db directory, delete the entire Publisher Pro folder and all its contents and do exactly as it says above except upload YOUR db directory. If you have a database from very early versions of Publisher Pro that did not support time or usernames (for example) then these will not be shown on the new version.



Useage:
=======

To view the news use this:

 	HTML(SSI): 	<!-- #include file="publisherpro/db/headlines.txt" -->
	PHP:  		<? include "http://www.yourdomain_name.com/pp/db/headlines.txt"; ?>


To view the archive use this:
	

	HTML(SSI): 	<!-- #include file="publisherpro/db/archive.txt" -->
	PHP:  		<? include "http://www.yourdomain_name.com/pp/db/archive.txt"; ?>


A common method is to place a hyperlink at the bottom of your main page which leads to another file to view the archive. This is how you do it:

	<a href=http://www.yourdomain_name.com/publisherpro/archive.php>My Archive</a>



Obviously replacing the ""www.yourdomain_name.com/publisherpro" part with the value applicable to you. If you're server doesnt support SSI you will have to use the PHP method to include the 2 files.

Customisation:

To achieve a customised look on the "back page" that you cant get via the configuration you will need to edit news_content.php. This also applies to archive.php.



Notes:
======

Publisher Pro uses a twin template format. The "front page" is accessed via headlines.txt and archive.txt. When [image_url] is used in the "front page" (it cant be used on the "back page") it creates a hyperlink to the "back page ". The tag [backpage_url] is slighty different, it actually outputs the full url NOT the hyperlink, this is so you can specify what text it displays. E.g. <a href=[backpage_url]>read more...</a> would display "read more..." and link to the "back page" of that particular post.

The "front page" template can contain every piece of information you submit, however the "back page" is limited slightly as explained in the tags below. 

This twin template design allows alot of flexibility, you could for example: post news with snippets and have the news content not showing on your main page, simply produce headlines of the news on the main page or use it as an article publishing system.

Build: This builds the information from the database with the "front page" template you specified in configuration onto db/headlines.txt. The "content" of the news is a dynamic page. The build algorithm is contained in functions.php.

Users: If you delete all the users you must upload install.php and install2.php again and run install.php to create a new user. Make sure you delete them once you've used them!



Tag Descriptions:
=================

[title] = Can be used on the front or back page. Outputs the title you specified.
[backpage_url] = Can only be used for the front page. Outputs a url (not a hyperlink) to the backpage.
[snippet] = Can only be used for the front page. Outputs the snippet you specified. 
[image] = Can be used on the front or back page. Outputs the image you specified with the image options you configured.
[image_url] = Can only be used on the front page. Outputs the image you specified as a hyperlink to the "back page" with the image options you configured.
[body] = Can be used on the front or back page. Outputs the body text you specifed.
[date] = Can be used on the front or back page. Outputs the date at time of posting. 
[month] = Can be used on the front or back page. Outputs the month at time of posting.
[year] = Can be used on the front or back page. Outputs the year at time of posting.
[user] = Can be used on the front or back page. Outputs the user who posted the news/article.
[email] = Can be used on on the front or back page. Outputs an email with the email that was input when the user was created and the username as the description.



Version History:
================

2.3: Checks in index.php to make sure install has been done and to make sure the user deleted both install files, the backend menu appears in all instances now, a new tag [backpage_url] displays the url not the hyperlink (support for the old tag [title_url] is still in place), ability to edit your details, protections against, adding user when user already exists and deleting a user that doesnt exist, archive now displays posts 10 per page.

2.2: Ability to use all quotation marks, displays 15 posts at a time when editing, larger text boxes, more code notation.

2.1: Added [email] tag. Automatic building after any change to the back end. If no image or title is specified then no image or title is output, rather than an error message. Fixed two bugs in edit which causes a post to not be displayed if no title was specified and dates to be wiped if it is edited. Tweaked functions.php, more OO style programming.


2.0: Added [user], [time], [month], [day], [year] tags in both templates. Rewritten build.php fixing a rare bug. Ability to view archived news via archive.txt. Validation bug fixed.

1.1: Better installation, allows less human error. Vastly improved code and notation. Ability to add or remove users. Tweaked  looks. Automatic redirection. Improved readme.txt with more help. Improved validation, now uses encryption.

1.0: Basic version, tags supported: [title], [title_url], [snippet], [image], [image_url], [body]










