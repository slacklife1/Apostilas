<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts	                    #
# Note: A large portion of these encryption algorithms were     #
# coded by Joshua Hyrman (http://www.scienceboy.f2s.com)		#
#################################################################


    function cleanWhitespace()
	{
    	 $raw = file("data.txt");
		 
    	 $fp = fopen("data.txt", "w")
    	 or die ("Could not open file for writing");
    	 for ($i = 0; $i < count($raw); $i++) 
		 {
    	     $content[$i]=trim($raw[$i]);
			 if($content[$i]!="")
			 {
			     fwrite($fp, $content[$i]."\n");
			 }
    	 }
		 fclose ($fp);
	}
		
	
	function checkUser($user, $pass) 
	{
        $fp = fopen("data.txt", "r");
        $auth = false;
        while (!feof($fp)) 
		{
            $parts = explode("||:|:||", trim(fgets($fp, 1024)));
    	    if ($parts[0] == substr(crypt($user, "mn"), 2)) 
		    {
    	        if ($parts[1] == substr(crypt($pass, "jh"), 2)) 
			    {
    		        $auth = true;
    			    break;
    		    }
    	    }
        }
    	fclose($fp);
    	return $auth;
    }
	
    function addUser($user, $pass, $email) 
	{
        $fp = fopen("data.txt", "r");
    	$user = substr(crypt(trim($user), "mn"), 2);
    	while (!feof($fp)) 
		{
		    $parts = explode("||:|:||", trim(fgets($fp, 1024)));
    		if ($parts[0] == $user) 
			{
    		    return 0;
    			exit;
    		}
    	}
    	fclose($fp);
    	$fp = fopen("data.txt", "a");
    	$pass = substr(crypt(trim($pass), "jh"), 2);
    	$email = trim($email);
    	$string = $user."||:|:||".$pass."||:|:||".$email."\n";
    	fwrite ($fp, $string);
    	fclose($fp);
		cleanWhitespace();		
    	return 1;
    }
	
    function findUser($user) 
	{
        $fp = fopen("data.txt", "r");
        $found = false;
    	$i = 0;
    	while (!feof($fp)) 
		{
    	    $parts = explode("||:|:||", trim(fgets($fp, 1024)));
    		if ($parts[0] == substr(crypt($user, "mn"), 2)) 
			{
    		    print ("User <b><i>$user</i></b> found at line <b>$i</b>:<br>$parts[0]<br>$parts[1]<br>$parts[2]");
    			break;
    		}
    	$i++;
    	}
    }
	
    function deleteUser($user) 
	{
     	 $user = substr(crypt(trim($user), "mn"), 2);
    	 $newfile[0] = "";
    	 $content = file("data.txt");
    	 $i = 0;
		 $userFound=0;
    	 for(; $i < count($content); $i++) 
		 {
    	  	   $parts = explode("||:|:||", trim($content[$i]));
    		   if ($parts[0]==$user) 
			   {
			   	   $newfile[$i]="";
				   $userFound=1;				   
			   }
			   else	   
			   {			   	   
    			   $newfile[$i] = $content[$i];
    		   }
    	 }
    	 $fp = fopen("data.txt", "w")
    	 or die ("Could not open file for writing");
    	 for ($i = 0; $i < count($newfile); $i++) 
		 {
    	     fwrite($fp, $newfile[$i]."\n");
    	 }
		 fclose ($fp);
		 cleanWhitespace();
		 return $userFound;		 
    }
	
	function returnEmail($user) {
    $fp = fopen("data.txt", "r");
    $found = false;
    $i = 0;
    while (!feof($fp)) {
    $parts = explode("||:|:||", trim(fgets($fp, 1024)));
    if ($parts[0] == substr(crypt($user, "mn"), 2)) {
	return $parts[2];
    break;
    }
    $i++;
    }
    }
		
?>