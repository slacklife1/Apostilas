<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


include "functions.php";
$fileContents=readFileContents("db/pp_url.txt");


if($fileContents=="")
{
    ?> <font color=black face=verdana size=2>Install has not been completed, please install first! <?
}
else
{
 	if(file_exists("install.php") || file_exists("install2.php"))
	{
	    ?> <font color=black face=verdana size=2>You have not deleted install.php and install2.php. Please delete first! <?
	}
	else
	{
	    ?> <html><head><title>Publisher Pro Backend</title></head><body> <?
		include "menu.inc";
		?> <center><font color=black face=verdana size=2>Publisher Pro v2.3</font></center></body></html> <?	
    }
}

?>
