<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();
if(session_is_registered("arbitraryVariable"))  
{

include("menu.inc"); 


//The functions page
include "functions.php";

$fileNameWithPath="db/".$fileName;

$rawData = readFileContents($fileNameWithPath);

$user = explode("[U]", $rawData);
$day = explode("[D]", $rawData);
$month = explode("[M]", $rawData);
$year = explode("[Y]", $rawData);
$time = explode("[T]", $rawData);
$email = explode("[E]", $rawData);

$dataString="[H]".$title."[H][S]".$snippet."[S][P]".$image_url."[P][B]".$body."[B][U]".$user[1]."[U][D]".$day[1]."[D][M]".$month[1]."[M][Y]".$year[1]."[Y][T]".$time[1]."[T][E]".$email[1]."[E]";
$dataString = str_replace("\\", "", $dataString);
writeToFile($fileNameWithPath, $dataString);

buildDatabase();

?> <font color=black face=verdana size=2><center>Edited!</center></font>
<meta http-equiv='refresh' content='1;URL=index.php'> <?

}
else 
{
    include("menu.inc"); 
	?> <font color=black face=verdana size=2><center>You are not logged in!</center></font> <?
}

?>


