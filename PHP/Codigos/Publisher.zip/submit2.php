<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();

if(session_is_registered("arbitraryVariable"))  
{

//The functions page
include "functions.php";

//The 'validation' functions
include "security_functions.php";


session_start();
session_register("arbitraryVariable");
$user=$arbitraryVariable;

$date = getdate();

//To add on the "st", "nd", "rd" or "th" after the day of the month
$day_raw = $date['mday']; 

if($day_raw=="1" || $day_raw=="21" || $day_raw=="31")
{
     $day=$day_raw."st";	
}
elseif($day_raw=="2" || $day_raw=="22")
{
 	$day=$day_raw."nd";
}
elseif($day_raw=="3" || $day_raw=="23")
{
 	$day=$day_raw."rd";
}
else
{
 	$day=$day_raw."th";
}

//The other date attributes				  
$month = $date['month'];
$year = $date['year']; 

//Current time when posted (server time) in 12 hour am or pm format
$time = (strftime("%r.\n"));

$email = returnEmail($user);


//Sets up some variables for the entire page
$count = readFileContents("db/count.txt");
$netCount=$count+1;
$dataFile="db/".$netCount;
$dataString="[H]".$title."[H][S]".$snippet."[S][P]".$image_url."[P][B]".$body."[B][U]".$user."[U][D]".$day."[D][M]".$month."[M][Y]".$year."[Y][T]".$time."[T][E]".$email."[E]";


//Saves the overall count now that the new submission has been added
writeToFile("db/count.txt", $netCount);

//Copies what the user specified in submit.php to the datafile (datafile is always the count + 1)
$dataString = str_replace("\\", "", $dataString);
writeToFile($dataFile, $dataString);


buildDatabase(); 

include("menu.inc");

?> <font color=black face=verdana size=2><center>Submitted!</center></font>
<meta http-equiv='refresh' content='1;URL=index.php'> <?

}

else 
{
    include("menu.inc"); ?>
	<font color=black face=verdana size=2><center>You are not logged in!</center></font> <?
}

?>



