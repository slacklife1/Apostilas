<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


//The functions page
include "functions.php";


//Reads formatting and content data from files
$rawData = readFileContents("db/".$fileName);
$back_page_image = readFileContents("db/back_page_image.txt");
$templateData = readFileContents("db/template2.txt");


//Splits up $rawData
$title = explode("[H]", $rawData);
$snippet = explode("[S]", $rawData);
$image_raw = explode("[P]", $rawData);
$body = explode("[B]", $rawData);

$user = explode("[U]", $rawData);
$day = explode("[D]", $rawData);
$month = explode("[M]", $rawData);
$year = explode("[Y]", $rawData);
$time = explode("[T]", $rawData);
$email = explode("[E]", $rawData);



$image="<img src=".$image_raw[1]." ".$back_page_image.">";
$bodyData = $templateData;
$bodyData = str_replace("[title]", $title[1], $bodyData);

if($image_raw[1]!="") {
      $bodyData = str_replace("[image]", $image, $bodyData);
}
else if($image_raw[1]=="") {
	  $bodyData = str_replace("[image]", "", $bodyData);
}

$bodyData = str_replace("[body]", $body[1], $bodyData);
$bodyData = str_replace("[user]", $user[1], $bodyData);
$bodyData = str_replace("[day]", $day[1], $bodyData);
$bodyData = str_replace("[month]", $month[1], $bodyData);
$bodyData = str_replace("[year]", $year[1], $bodyData);
$bodyData = str_replace("[time]", $time[1], $bodyData);
$bodyData = str_replace("[email]", $email[1], $bodyData);

echo("$bodyData");



?>

