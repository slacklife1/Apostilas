<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


//Read contents of a file into a string and return that string
function readFileContents($fileNameAndPath)
{
 	$fp=fopen($fileNameAndPath, "r");
	$contentsOfFile = fread($fp, filesize($fileNameAndPath));
	fclose ($fp);
	return $contentsOfFile;
	
}

//Erase what was in a file and copy new contents into that file
function writeToFile($fileNameAndPath, $content)
{
 	$fp=fopen($fileNameAndPath, "w");
	fputs($fp, $content,strlen($content));
	fclose ($fp);
}

function buildDatabase()
{

//Reads the varibles in from the template, count and config files
$templateData = readFileContents("db/template1.txt");
$front_page_image = readFileContents("db/front_page_image.txt");
$headline_number = readFileContents("db/headline_number.txt");
$pp_url = readFileContents("db/pp_url.txt");
$count = readFileContents("db/count.txt");


#################################################################
# This part builds headlines.txt								#
#################################################################

//Check to see if headline file there, if it is delete
if(file_exists("db/headlines.txt")) 
{
     unlink("db/headlines.txt"); 
}

$i=$count; 
$output_headlines=0;			   

//The 2 conditions ensures you dont open a a file if you dont have any articles (if $i gets to 0 it stops)
//and it makes sure it doesnt output more headlines than what you specify
while(($i>0) && ($output_headlines<$headline_number))
{		
	//Opens appropriate news file 
	$fileNameWithPath="db/".$i;
	$rawData = readFileContents($fileNameWithPath);
	//If file contains a delete marker skip 1 itteration, i.e. do not build anything for 
	//this itteration and goto the next file
	if($rawData=="[X]") 
	{	
		$i=$i-1;				
		continue;
    }
	else
	{	
	//Splits up $rawData
	$title = explode("[H]", $rawData);
	$snippet = explode("[S]", $rawData);
	$image_raw = explode("[P]", $rawData);
	$body = explode("[B]", $rawData);	
	$user = explode("[U]", $rawData);
	$day = explode("[D]", $rawData);
	$month = explode("[M]", $rawData);
	$year = explode("[Y]", $rawData);
	$time = explode("[T]", $rawData);
	$email = explode("[E]", $rawData);	
	
	//Some general settings
	$image="<img src=".$image_raw[1]." ".$front_page_image.">";
	$title_url="http://".$pp_url."/news_content.php?fileName=$i"; //support for older databases	
	$backpage_url="http://".$pp_url."/news_content.php?fileName=$i"; //the new tag
	$image_url="<a href=http://".$pp_url."/news_content.php?fileName=$i>".$image."</a>";	
	
	//Opens up front page template and converts the tags to varibles then saves as $newsData
	$newsData = $templateData;
	$newsData = str_replace("[title]", $title[1], $newsData);
	$newsData = str_replace("[title_url]", $title_url, $newsData); //for older databases
	$newsData = str_replace("[backpage_url]", $backpage_url, $newsData);
	$newsData = str_replace("[snippet]", $snippet[1], $newsData);
	
	if($image_raw[1]!="") {
	     $newsData = str_replace("[image]", $image, $newsData);
	}
	else if($image_raw[1]=="") {
		 $newsData = str_replace("[image]", $image_warning, $newsData);
	}
	
	if($image_raw[1]!="") {
	     $newsData = str_replace("[image_url]", $image_url, $newsData);
	}
	else if($image_raw[1]=="") {
		 $newsData = str_replace("[image_url]", "", $newsData);
	}
		
	$newsData = str_replace("[body]", $body[1], $newsData);
	$newsData = str_replace("[user]", $user[1], $newsData);
	$newsData = str_replace("[day]", $day[1], $newsData);
	$newsData = str_replace("[month]", $month[1], $newsData);
	$newsData = str_replace("[year]", $year[1], $newsData);
	$newsData = str_replace("[time]", $time[1], $newsData);
	$newsData = str_replace("[email]", $email[1], $newsData);

	//Opens headlines.txt and APPENDS info to it
	$fp=fopen("db/headlines.txt", "aw");
	fputs($fp, $newsData,strlen($newsData));
	fclose ($fp);	     

	$output_headlines=$output_headlines+1;	
	//Move down to the next article
	$i=$i-1;
	}
		
}

writeToFile("db/file_count.txt", $i);

//To make sure if no articles are posted the headlines.txt file still exists so no errors pop up when trying to view it
if(!file_exists("db/headlines.txt")) 
{
   	$fp=fopen("db/headlines.txt", "w");
	fputs($fp, "No News",strlen("No News"));
	fclose ($fp);		
}


}

?>