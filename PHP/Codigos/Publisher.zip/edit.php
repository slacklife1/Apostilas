<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();
if(session_is_registered("arbitraryVariable"))  
{

include("menu.inc"); 

//The functions page
include "functions.php";


//Reads the count if we are calling edit.php from the main menu
if($count=="")
{
 		$count = readFileContents("db/count.txt");	
}


//Print out all headlines (as hyperlinks) up to and including count
echo "<form action=edit4.php method=get name=delete_form>";
echo "<table border=1 bordercolor=#000000 cellspacing=0 cellpadding=0 width=100%>";

for($fileName=$count, $counter=0;$fileName>0 && $counter<15;$fileName=$fileName-1) 
{
	$fileNameWithPath="db/".$fileName;	
	$fileString = readFileContents($fileNameWithPath);
	//If the file contains a 'deleted' marker then skip this iteration of the loop	
	if($fileString=="[X]") {		 
		 continue;
	}
	
	//Otherwise output the hyperlinks
	$counter=$counter+1;
	$title = explode("[H]", $fileString);
	if($title[1]=="")
	{
	 	$title[1]="<font color=red>[Please specify a title]</font>";
	}
	echo "<tr height=20>
         	 <td width=80%>	
			 <center><font color=black face=verdana size=2><a href='edit2.php?fileName=$fileName'>$title[1]</a></font></center>
			 </td>
       		 <td width=20%>
			 <center><input type=radio name=fileName value=$fileName></center>
			 </td>
         </tr>";	 
}
?> </table><br><center><input type=submit value=Delete></center></form> <?

if($fileName>0)
{
     echo("<font color=black face=verdana size=2><div align=right><a href=edit.php?count=$fileName>Next 15 >></a></div></font>");
}

}

else 
{
    include("menu.inc"); 
	?> <font color=black face=verdana size=2><center>You are not logged in!</center></font> <?
}

?>
