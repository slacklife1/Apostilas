<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();
if(session_is_registered("arbitraryVariable"))  
{
    include("menu.inc"); 
	include("security_functions.php");
	$old_email=returnEmail($arbitraryVariable);

	echo"

<table cellspacing= cellpadding=10 width=100%>
<tr valign=top>
       <td width=50%>	   
	   	   <center><form method=post action=users2.php>
		   <table cellspacing=0 cellpadding=5 width=100>
		   <tr>
		   	   <td><font color=black face=verdana size=2><b><center>Add a new user</center></b></td>
		   </tr>
		   <tr>
       	   	   <td><font color=black face=verdana size=2>Username: <input type=text name=username size=30></td>
           </tr>
		   <tr>
          	   <td><font color=black face=verdana size=2>Password: <input type=password name=pass1 size=30></td>
		   </tr>
		   <tr>
          	   <td><font color=black face=verdana size=2>Repeat Password: <input type=password name=pass2 size=30></td>
		   </tr>
		    <tr>
          	   <td><font color=black face=verdana size=2>Email: <input type=text name=email size=30></td>
		   </tr>
		   </table><input type=submit value='Add User'>
		   </form></center> 
		   <br>
		   <center><form method=post action=users3.php>
		   <table cellspacing=0 cellpadding=5 width=100>
		   <tr>
		   	   <td><font color=black face=verdana size=2><b><center>Delete an existing user</center></b></td>
		   </tr>
		   <tr>
       	   	   <td><font color=black face=verdana size=2>Username: <input type=text name=username size=30></td>
           </tr>
		   </table><input type=submit value='Delete User'>
		   </form></center>  
	   </td>
       <td width=50%>	   	   	
		   <center><form method=post action=users4.php>
		   <table cellspacing=0 cellpadding=5 width=100>
		   <tr>
		   	   <td><font color=black face=verdana size=2><b><center>Change your email address</center></b></td>
		   </tr>
		   <tr>
		   	   <td>				   
				   <font color=#857F7F face=verdana size=2>Old Email: $old_email</font>
			   </td>
		   <tr>
       	   	   <td><font color=black face=verdana size=2>New Email: <input type=text name=new_email size=30></td>
           </tr>
		   </table><input type=submit value='Change Email'>
		   </form></center>	
		   <br>
		   <center><form method=post action=users5.php>
		   <table cellspacing=0 cellpadding=5 width=100>
		   <tr>
		   	   <td><font color=black face=verdana size=2><b><center>Change your password</center></b></td>
		   </tr>
		   <tr>
       	   	   <td><font color=black face=verdana size=2>New Password: <input type=password name=pass1 size=30></td>
           </tr>
		   <tr>
       	   	   <td><font color=black face=verdana size=2>Repeat New Password: <input type=password name=pass2 size=30></td>
           </tr>
		   </table><input type=submit value='Change Password'>
		   </form></center>	
		   
		   	   
	   </td>
</tr>
</table>
";
}
else 
{
    include("menu.inc");    
	?> <font color=black face=verdana size=2><center>You are not logged in!</center></font> <?
}
?>
