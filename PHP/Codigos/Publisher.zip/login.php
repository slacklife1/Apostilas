<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################

		
session_start();
if(session_is_registered("arbitraryVariable"))  
{
    include("menu.inc");
	?> <font color=black face=verdana size=2><center>You are already logged in!</center></font> <?
}
else 
{
    include("menu.inc"); ?>
	
		
<html>
<head>
	<title>Publisher Pro Backend</title>
</head>

<body>

<form method=post action=login2.php> 

<center><table cellspacing=0 cellpadding=5 width=100>

<tr>
       <td><font color=black face=verdana size=2>Username: <input type=text name=username size=30></td>
</tr>
<tr>
       <td><font color=black face=verdana size=2>Password: <input type=password name=password size=30></td>
</tr>
</table>

<br><input type=submit value=Login>
</form></center>

</body>
</html>	<?	
}
?>