<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();
if(session_is_registered("arbitraryVariable"))  
{
 	include("menu.inc");     
	include("functions.php");
	
	$template1 = readFileContents("db/template1.txt");
	$template2 = readFileContents("db/template2.txt");
	$old_front_page_image = readFileContents("db/front_page_image.txt");
	$old_back_page_image = readFileContents("db/back_page_image.txt");
	$old_headline_number = readFileContents("db/headline_number.txt");
	$old_pp_url = readFileContents("db/pp_url.txt");
	
	echo"

<form method=post action=config2.php> 

<table cellspacing=0 cellpadding=0 width=100% border=1 bordercolor=black>

<tr valign=top>
       <td width=50%>	   	   
	   	   <center><font color=black face=verdana size=2><b>Front Page:</b><br><br>
		   Template:<br>		   
	   	   <textarea name=front_page cols=50 rows=5>$template1</textarea>
		   <br>-Use the following tags: [title] [backpage_url] [snippet] [image] [image_url] [body] [day] 
		   [month] [year] [user] [email] [time]
		   <br><br>
		   Image Options:<br>
		   <input type=text name=front_page_image size=50 value='$old_front_page_image'>
		   <br>-Seperate each attribute with a space, do not use quotes!<br><br>		   
		   </font></center>
	   </td>
       <td width=50%>
	   	   <center><font color=black face=verdana size=2><b>Content/Back Page:</b><br><br>
		   Template:<br>		   
	   	   <textarea name=back_page cols=50 rows=5>$template2</textarea>
		   <br>-Use the following tags: [title] [image] [body] [day] [month] [year] [user] [email] [time]<br><br>
		   Image Options:<br>
		   <input type=text name=back_page_image size=50 value='$old_back_page_image'>
		   <br>-Seperate each attribute with a space, do not use quotes!
		   </font></center>
	   </td>
</tr>
</table>
<br><br>

	   <center><font color=black face=verdana size=2><b>Other Options:</b></font></center>


<table cellspacing=0 cellpadding=0 width=100% border=1 bordercolor=black>
<tr valign=top>	  
	   <td width=50%>
	   	   <br><center><font color=black face=verdana size=2>
		   Number of headlines to display:<br>
		   <input type=text name=headline_number size=50 value='$old_headline_number'>
		   <br><br>
		   </font></center>
	   </td>
	   <td width=50%>   
	   	   <br><center><font color=black face=verdana size=2>
		   Publisher Pro Directory URL:<br>
		   http://<input type=text name=pp_url size=50 value='$old_pp_url'>/index.php
		   <br><br>
		   </font></center>
	   </td>
</tr>
</table>
<br><center><input type=submit value=submit></center>
</form>
";
}
else 
{
    include("menu.inc"); 
	?> <font color=black face=verdana size=2><center>You are not logged in!</center></font> <?
}

?>
