<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();
if(session_is_registered("arbitraryVariable"))  
{
    include("menu.inc"); 
	include "db/headlines.txt"; 
	?> <br><br>
	<div align=right><a href=archive.php>Archived News >></a></div><?
}
else 
{
    include("menu.inc"); 
	?> <font color=black face=verdana size=2><center>You are not logged in!</center></font> <?
}
?>
