<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();
if(session_is_registered("arbitraryVariable"))  
{
    include("menu.inc");
	?>


<form method=post action=submit2.php> 

<table cellspacing=0 cellpadding=0 width=100%>

<tr>
       <td height=20>
	   	   <font color=black face=verdana size=2>Title</font>
	   </td>
	   <td height=20>
	   	   <input type=text name=title size=50>
	   </td>
</tr>

<tr>
       <td height=20>
	   	   <font color=black face=verdana size=2>Image URL</font>
	   </td>
	   <td height=20>
	   	   <input type=text name=image_url size=50>
	   </td>
</tr>

<tr>
       <td height=20>
	   	   <font color=black face=verdana size=2>Snippet</font>
	   </td>
	   <td height=20>
	   	   <textarea name=snippet cols=100 rows=6></textarea>
	   </td>
</tr>

<tr valign=top>
       <td height=200>
	   	   <font color=black face=verdana size=2>Content</font>
	   </td>
	   <td height=20>
		   <textarea name=body cols=100 rows=14></textarea>
	   </td>
</tr>
</table>

<br><center><input type=submit value=submit></center>
</form>

<?

}
else 
{
    include("menu.inc"); ?>
	 <font color=black face=verdana size=2><center>You are not logged in!</center></font> <? 
}

?>
