<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();
if(session_is_registered("arbitraryVariable"))  
{
    include("menu.inc"); 
	include("functions.php");
	
	$front_page = str_replace("\\", "", $front_page);
	writeToFile("db/template1.txt", $front_page);
	$back_page = str_replace("\\", "", $back_page);
	writeToFile("db/template2.txt", $back_page);
	$front_page_image = str_replace("\\", "", $front_page_image);
	writeToFile("db/front_page_image.txt", $front_page_image);
	$back_page_image = str_replace("\\", "", $back_page_image);
	writeToFile("db/back_page_image.txt", $back_page_image);
	$headline_number = str_replace("\\", "", $headline_number);
	writeToFile("db/headline_number.txt", $headline_number);
	$pp_url = str_replace("\\", "", $pp_url);
	writeToFile("db/pp_url.txt", $pp_url);
	
	buildDatabase();
	
	?> <font color=black face=verdana size=2><center>Config edited!</center></font>
	<meta http-equiv='refresh' content='1;URL=index.php'> <?
}
else 
{
    include("menu.inc"); 
	?> <font color=black face=verdana size=2><center>You are not logged in!</center></font> <?
}
?>


