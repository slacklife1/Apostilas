<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


echo "
	   	   <form method=post action=install2.php>
		   <table cellspacing=0 cellpadding=10 width=100%>
		   <tr>
		   	   <td><font color=black face=verdana size=2><b>Add a new user</b></td>
		   </tr>
		   <tr>
       	   	   <td><font color=black face=verdana size=2>Username: <br><input type=text name=username size=30></td>
           </tr>		   
		   <tr>
          	   <td><font color=black face=verdana size=2>Password:<br> <input type=password name=pass1 size=30></td>
		   </tr>
		   <tr>
          	   <td><font color=black face=verdana size=2>Repeat Password:<br> <input type=password name=pass2 size=30></td>
		   </tr>
		    <tr>
          	   <td><font color=black face=verdana size=2>Email: <br><input type=text name=email size=30></td>
		   </tr>
		   <tr>
          	   <td><br><font color=black face=verdana size=2><b>The Publisher Pro Directory</b></td>
		   </tr>
		   <tr>
          	   <td><font color=black face=verdana size=2>http://<input type=text name=pp_url size=30>/install.php
			   <br>e.g. your.domain.here/pp</td>
		   </tr>
		   </table>
		   <br><br><input type=submit value=Install>
		   </form>  
";			 
		   
?>