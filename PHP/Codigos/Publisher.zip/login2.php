<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


include "security_functions.php";
$arbitraryVariable=$username;

if(checkUser($username, $password)) 
{
    session_start();
	session_register("arbitraryVariable"); 	

	include("menu.inc");
	?> <font color=black face=verdana size=2><center>Login successful!</center></font>
	<meta http-equiv='refresh' content='1;URL=index.php'> <?
}
else 
{
    include("menu.inc");
	?> <font color=black face=verdana size=2><center>Login was not successful!</center></font> <?
}				
?>