<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();
if(session_is_registered("arbitraryVariable"))  
{

    if($pass1!=$pass2 || $pass2!=$pass1)
    {
 	    include("menu.inc");
		?> <font color=black face=verdana size=2><center>Passwords entered are not the same, password not changed!</center></font> <?
    }
    else
    {    
	    include("menu.inc");
		include("security_functions.php");
		
		$username=$arbitraryVariable;
		$email=returnEmail($username);		
		deleteUser($username);
		addUser($username, $pass1, $email);
		
		?> <font color=black face=verdana size=2><center>Password changed!</center></font>
		<meta http-equiv='refresh' content='1;URL=index.php'> <?
    }
}
else 
{
    include("menu.inc");
	?> <font color=black face=verdana size=2><center>You are not logged in!</center></font> <?
}
?>

