Title: TXnews v2.3
Description: TXnews is a complete news or article publishing system (cms). It includes the backend, data storage system and updater. It uses "flat files" for storage so no need for a database. Templates available for titles, icons, snippets, news body, user, time, date, month, year and email. You can specify the number of headlines to be displayed and view an archive. Includes support for multiple users and automatic building.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=512&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
