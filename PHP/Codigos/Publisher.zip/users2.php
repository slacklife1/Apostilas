<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();
if(session_is_registered("arbitraryVariable"))  
{
    include("security_functions.php");
	if($pass1!=$pass2 || $pass2!=$pass1)
	{
	    include("menu.inc");
		?> <font color=black face=verdana size=2><center>Passwords do not match, user not added!</center></font> <? 
	}
	elseif(strlen($email)<5)
	{
	    include("menu.inc");
		?> <font color=black face=verdana size=2><center>Email must be at least five characters long, user not added!</center></font> <?
	}
	else
	{
		if(addUser($username, $pass1, $email)==1)
		{
		    include("menu.inc");
			?><font color=black face=verdana size=2><center>User added!</center></font>
	        <meta http-equiv='refresh' content='1;URL=index.php'> <?
		}
		else
		{
		    include("menu.inc");
			?> <font color=black face=verdana size=2><center>That user already exists, user not added!</center></font> <?
		}
	}
}
else 
{
	include("menu.inc");
	?> <font color=black face=verdana size=2><center>You are not logged in!</center></font> <?
}
?>

