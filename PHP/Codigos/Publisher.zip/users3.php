<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();
if(session_is_registered("arbitraryVariable"))  
{
    include("menu.inc");
	include("security_functions.php");
	if(deleteUser($username)==1)
	{
	    ?> <font color=black face=verdana size=2><center>User deleted!</center></font>
		<meta http-equiv='refresh' content='1;URL=index.php'> <?
	}
	else
	{
	    ?> <font color=black face=verdana size=2><center>User not found!</center></font> <?
	}	    
}
else 
{
    include("menu.inc");
	?> <font color=black face=verdana size=2><center>You are not logged in!</center></font> <?
}

?>


