<?
#################################################################
# Publisher Pro v2.3											#	
# Written and Developed by: Aaron Bishell (aragorn@gamer.net.nz)#
# Homepage: binary.gamer.net.nz/phpscripts						#
#################################################################


session_start();
if(session_is_registered("arbitraryVariable"))  
{
    include("menu.inc");
	include("functions.php");
	include("security_functions.php");
	
	$old_email=returnEmail($arbitraryVariable);
	if(strlen($new_email)<5)
	{
	    ?> <font color=black face=verdana size=2><center>Email must be at least five characters long!</center></font> <?
	}
	else
	{
	    $fileString=readFileContents("data.txt");
		$fileString=str_replace("$old_email", "$new_email", $fileString);
		writeToFile("data.txt", $fileString);
		
		?> <font color=black face=verdana size=2><center>Email changed!</center></font>
		<meta http-equiv='refresh' content='1;URL=index.php'> <?
	}	
}
else 
{
    include("menu.inc");
	?> <font color=black face=verdana size=2><center>You are not logged in!</center></font> <?
}
?>
