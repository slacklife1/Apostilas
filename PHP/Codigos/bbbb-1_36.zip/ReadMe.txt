
=============================================================

BARE BONES BULLETIN BOARD

                          
        Version 1.36
        06 February 2001/ 23 June 1998
        written by Michael Kablitz (mkab@deutschsoft.com)            
                                                   
        This script is under the GNU Public License:
        (ftp://prep.ai.mit.edu/pub/gnu/COPYING)



==============================================================


The BBBB provides an easy way to set up a BBS-style frontend                
for user input. Its usage should be fairly self-evident, even 
to the novice. You need PHP3 Version 3.0 or higher. 

Supported databases: 

mySQL (stable)
unified ODBC, Adabas D (alpha, should work)
Postgres, Sybase, msql (development only, probably faulty)

=============================================================

QUICK SETUP:
------------

- Unzip the downloaded archive.
- Edit bbbb-ini.php3: Insert your database type and name, your 
  database username/password and your URL.
- Upload everything to a directory on your server
  (/home/youracct/public_html/bbs, say)
- Telnet to your server and change to that directory:
  (cd public_html/bbs)
- Enter "cat bbbb-mysql.sql | mysql DATABASENAME --user=USERNAME --password=PASSWORD"
  on your command (telnet) prompt to setup the mySQL tables. (Mind that USERNAME
  and PASSWORD are your database username/password, not your login shell (telnet)
  ones. These may or may not differ from one another, depending on your host�s 
  setup!)
- That's it.



=============================================================

The script mimicks the look of Brian Moon's 'Phorum' available at
http://brian.threadnet.com/forum/ but the underlying code
of BBBB is completely different:

- Multiple levels are supported

- There is hardly any mySQL access or resource-intensive work
  necessary when simply reading the table or single messages.
  This job is done when messages are posted, which will happen
  much less frequently.
  
- Email notification when a new message is posted to a subscribed
  thread. Optional.
  
- HTML tags inside bodies. Optional.

- Users may delete their own postings. Optional.

- Autodetect language to send to the browser. Optional.

- Autopurge inactive old threads. Optional.

- Anti-email-harvesting facility. Optional.

- Limit the number of messages simultaniously on display. Optional.

- Admin display to modify or delete messages or threads.
  
- No cookies needed.

- No Javascript needed.

- HTML 3.2 compliant

- Known to work with PHP Apache module or, with some
  adaptions, with the PHP CGI on UNIX or NT servers.

- Backward compatibility: mySQL table layout is unchanged. 
  You can use your mySQL tables with any version of the BBBB.

- The code is modular, which makes is easy to add own functionality,
  language files of your own (en, fr, de, nl, it, hu included), or new
  database wrappers.

  If you do so, please send me your improvements. They will be added
  to the next version. 

  
The newest version of this script will usually be available at
http://amber.he.net/~dsoft/bbbb/


=================================================================

Version History:
----------------
1.36 (06 February 2000)
    - Hungarian language file added.
      Thanks to Balazs Bezeczky (e9825128@stud3.tuwien.ac.at)

1.36 (18 October 2000)
    - Fixed deleteoldthreads() in bbbb-functions.php3.
      Thanks to Fulvio Malfatto (fmal@fmal.com), as usual.

1.34 (29 June 2000)
    - New italian language file.
      Thanks to Fulvio Malfatto (fmal@fmal.com).
    - There appears to be problem with MySQL table
      locking on AIX. The offending lines have been removed.     
      Thanks to Fulvio Malfatto (fmal@fmal.com).
    - Changed the "navbar()" function in bbbb-functions.php3
      and added line 214 in bbbb.php3 to counter PHP parser
      warnings about undefined variables when running PHP
      with a high error reporting level under PHP4.
      Thanks to (markus.bertschmann@systor.com)     

1.33 (04 March 2000)
    - minor error in french language file fixed.
    - slightly rephrased german and english language files.
    - email table was not locked when using admin. That's
      not too grave, but ist's fixed now anyhow.
    - fixed orphan removal in bbbb-admin.php3, which I broke in
      1.30 by omitting an important '$'.
    - some cosmetic changes in bbbb-functions.php3.
    - fixed a parse error in the Sybase wrapper and renamed the
      file from *sql to *php3, as it should have always been.

1.32 (20 November 1999)
    - fixed a parse error in the ODBC wrapper.
    - display of some html-tags within the message body
      had a bug since version 1.30. That is fixed.

1.31 (20 June 1999)
    - changed some mySQL queries to reflect syntax changes 
      of new PHP versions. 
      Thanks to Nick Smith (nick@climbers.net).
    - New italian language file.
      Thanks to Fulvio Malfatto (fmal@fmal.com).

1.30 (01 June 1999)
    - general code cleanup and rework to avoid problems
      that arose from posting messages from pages that
      were accessed with the �Back� button and from
      several people posting simultaniously.
    - database wrappers to allow for the use of
      different database backends.
      mySQL is stable. msql, ODBC, Informix, Sybase and
      Postgress wrapper scripts are only blueprints for those
      willing to adapt them to their flavour of database.
    - new option to prevent email harvesting
    - accidental double posting with �Reload� button is now 
      recognized.
    - Fixed two errors in bbbb_admin.php3
      Thanks to Shawn Patton (shawn@fraservalleymall.com).
    - bbbb-emailtext.php3 no longer requires editing.
    - more help text.
    - new icons that I stole from kmail and KDE.

1.25 (08 April 1999)
    - fixed faulty language detetction.
    - Added dutch language file.
      Thanks to Gerhard Hoogterp (gerhard@frappe.iaf.nl).
    - removed SECUREENV(), because the required environment
      variables are sometimes lost or withheld by browsers or 
      proxies.

1.24 (04 April 1999)
    - reverted READPARSE() to pre-1.22 state since it created more 
      problems than it solved. 
    - Line breaks are now properly honoured again. Thanks to
      Braam Heerink (bram@node0883.a2000.nl).

1.23 (17 March 1999)
    - fixed a parse error in the french language file.
      Thanks to Serge Grenier (stg@chezserge.com).

1.22 (29 January 1999)
    - fixed a bug in READPARSE() which messed up some special chars
      in conjunction with mySQL's Magic quotes.
      Thanks to Simon Booth (sbooth@primedia.co.uk).

1.21 (20 December 1998)
    - fixed a bug in ADMIN_WHICHQUERY() which rendered bbbb-admin.php3
      useless when $RestrictRemoteGet = 1 was set. Sorry. Thanks to 
      Neal Ghura (nghura@primecybersys.com).

1.20 (28 October 1998)
    - improved remote-host detection for older Apache servers.
    - fixed a bug in email function that left the topic field empty.
      Thanks to Werner Avenant (werner@informsa.co.za)
    - fixed a small html error in bbbb.php3 and bbbb-admin.php3.
      Thanks again to Werner Avenant (werner@informsa.co.za)
    - reworked email notification, message and subscription revoking.
      It now works flawlessly.
    - added some security to avoid remote tampering with the board.
    - improved autopurge function (less often called, which is faster).
    - added an option to limit the number of rows on one page
      plus accompanying navigation back and forth.
          
1.12 (16 October 1998)
    - improved french language file.
      Thanks to Serge Grenier (stg@chezserge.com).

1.11 (14 August 1998)
    - fixed a bug that reset date when editing with bbbb-admin.php3
    - fixed a bug with find-function in bbbb-admin.php3

1.10 (10 August 1998)
    - fixed a security leak in bbbb-ini.php3.
    - fixed silly email error.
    - fixed a mistake in READPARSE().
    - HTML inside message bodies is now supported (within limits).
    - added simple searching facility.
    - added an option for the user to delete their own messages.
    - added an option for the user to revoke their subscription.
    - added optional query of HTTP_ACCEPT_LANGUAGE.
    - added an admin function.
    - added an option to delete threads that were inactive for
      a given number of days.
    - added a french language file. Thanks to bredlen@unci.net.
    - added option to chop article bodies to a tolerable length.

1.02 (20 July 1998)
    -fixed an error in bbbb.php3 which prevented message body
     display with some Netscape browsers.
     Thanks to Dragutin Cvetkovic (argentum@informatika.com).

1.01 (16 July 1998)
    -minor changes to circumvent empty name and topic fields.
    -added mySQL table setup instructions.
        
1.0  (23 June 1998)
    - original release.

=============================================================


Files included:
---------------

bbbb-ini.php3 (you must edit this file):
- mySQL variables
- table formatting parameters
- misc. variables
                                        
bbbb.php3 (you can edit this file):
- the main file. html-formatting

bbbb-admin.php3 (no user input):
- admin functions (password protected)

bbbb-functions.php3 (no user input):
- the intestines.

bbbb-emailtext.php3 (you can edit this file):
- the text of sent emails

bbbb-lang-XY.php3 (no user input):
- language specific screen output

bbbb-XXXX.sql (no user input):
- the database table setup

bbbb-mysql.php3 (no user input):
- mysql database wrapper

foot_inc.html and head_inc.html (you can edit these files):
- sample header and footer files.

issues.txt:
- known problems and issues.

ReadMe.txt:
- this file

new.gif, send.gif, find.gif, email.gif:
- sample pics

                                
===============================================================

Copyright (c) 1998 Michael Kablitz.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer. 

2. Redistributions must reproduce the above copyright
notice, this list of conditions and the following disclaimer in
the documentation and/or other materials provided with the
distribution.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL AUTHOR OR
HIS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
OF THE POSSIBILITY OF SUCH DAMAGE.




