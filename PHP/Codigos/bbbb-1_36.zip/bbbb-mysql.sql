#
# Table structure for the main table.
# replace names after CREATE TABLE to reflect the ones you
# chose in bbbb-ini.php3
#

CREATE TABLE bbbb_main (
  id smallint(6) NOT NULL auto_increment,
  name varchar(40),
  email varchar(60),
  topic varchar(50),
  body blob,
  host varchar(80),
  thread smallint(6) NOT NULL,
  datestamp int(11) NOT NULL,
  depth smallint(2) NOT NULL,
  childof smallint(6) NOT NULL,
  pos smallint(6) NOT NULL,
  
  PRIMARY KEY (id),
  KEY thread (thread),
  KEY childof (childof),
  KEY pos (pos)
);


#
# Table structure for email notification table.
# replace name after CREATE TABLE to reflect the one you
# chose in bbbb-ini.php3
#

CREATE TABLE bbbb_email (
  email varchar(60) NOT NULL,
  thread smallint(6) NOT NULL,
  passwd varchar(10) NOT NULL,
  
  KEY thread (thread)
);

#
# use
# cat bbbb-mysql.sql | mysql DATABASENAME --user=USERNAME --password=PASSWORD
# on the shell prompt to create the tables.

