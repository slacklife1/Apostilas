<?php

require("config.inc");

$startdir = $HTTP_GET_VARS["dir"];
function list_dir($dirname) 
{ 
if($dirname[strlen($dirname)-1]!='\\') 
$dirname.='\\'; 
static $result_array=array(); 
$handle=opendir($dirname); 
while ($file = readdir($handle)) 
{ 
if($file=='.'||$file=='..') 
continue; 
if(is_dir($dirname.$file)) 
list_dir($dirname.$file.'\\'); 
else 
$result_array[]=$dirname.$file; 
} 
closedir($handle); 
return $result_array; 

}

$results = list_dir($mp3directory . $startdir);
header("Content-type: audio/x-mpegurl");
$fname = substr(str_replace("/","_",$dir),1);
if ($fname == "")
  $fname = "root";
header("Content-Disposition: inline; filename=\"$fname.m3u\"");
echo("#EXTM3U\n");
reset($results);
while($now=current($results))
{
  $now = substr($now,strlen($mp3directory));
  $now = strtr($now,"\\","/");
  $extinfo = strrchr($now,"/");
  $extinfo = substr($extinfo,1);
  $extinfo = "#EXTINF:-1," . $extinfo;
  $now = ereg_replace(" ","%20",$now);
  $now = $webmp3directory . $now;
  echo($extinfo . "\n");
  echo($now . "\n");
  next($results);
}
?>
