<html>
<head>
<script language="JavaScript1.2" src="ftiens4.js"></script>
<title>The Ultimate Playlist Maker</title>
</head>
<body>
<h1>Playlist Generator</h1>
<?php

require("config.inc");

function list_dir($dirname) 
{ 
if($dirname[strlen($dirname)-1]!='\\') 
$dirname.='\\'; 
static $result_array=array();
static $level=0; 
$handle=opendir($dirname); 
while ($file = readdir($handle)) 
{ 
if($file=='.'||$file=='..') 
continue; 
if(is_dir($dirname.$file)) 
{
  $level++;
  $result_array[]=$dirname."!".$file."!".$level;
  list_dir($dirname.$file);
} 
}
$level--;
return $result_array;
}

$results = list_dir($mp3directory);
?>
<script language='JavaScript1.2'>
foldersTree = gFld("Root of playlist", "playlist.php?dir=/");
var lastParent = new Array(6);
lastParent[0] = foldersTree;
<?php
echo ("var Menu = new Array(" . count($results) . ");\n");
for ($y = 0; $y < count($results); $y++)
{
  $now = $results[$y];
  $ourarr = explode("!",$now);
  $now = $ourarr[0] . $ourarr[1];
  $now = substr($now,strlen($mp3directory));
  $now = strtr($now,"\\","/");
  $level = $ourarr[2];
  $link = ereg_replace(" ","%20",$now);
  $link = "playlist.php?dir=" . $link;
  echo ("Menu[" . $y . "] = new Object();\n");
  echo ("Menu[" . $y . "].title = \"$ourarr[1]\";\n");
  echo ("Menu[" . $y . "].link = \"$link\";\n");
  echo ("Menu[" . $y . "].level =$level;\n");
}
?>
Menu.sort(order);
for (i=0;i<Menu.length;i++)
{
  lvl = Menu[i].level-1;
  if ((i+1<Menu.length) && (Menu[i+1].level>lvl+1))
  {
    lastParent[lvl+1] = insFld(lastParent[lvl], gFld(Menu[i].title,Menu[i].link));
  }
  else
  {
    insDoc(lastParent[lvl], gLnk(0, Menu[i].title, Menu[i].link));
  }
}

function order(a,b)
{
  if (a.link.toUpperCase() > b.link.toUpperCase())
     return 1;
  else
     return -1; 
}

initializeDocument();
</script>
</body>
</html>
