<html>
<head><title></title>
<body>
<form name="frmInput" action="POST/save.php" method="post">
	<select ID="mRight" size="10" style="width:'100'"
	onchange="createOption('mRight','addRights', this.selectedIndex)">
	</select>
	<select ID="addRights" size="10"  style="width:'100'"
	onchange="createOption('addRights','mRight', this.selectedIndex)" multiple>
	</select>
	<input type="hidden" id="tText" name="sRights" >
	<p><A HREF="javascript:selectAll('addRights'); javascript:document.frmInput.submit();">SUBMIT</A></p>
</form>
</body>
</html>

<script language ="Javascript">
function setUP(mID, name, value, text){
	var mObj = eval("document.getElementById('"+mID+"')");
	var nOption = document.createElement("OPTION");
	nOption.text = text;
	nOption.value = value;
	nOption.name= name;
	mObj.add(nOption);
}
var tObj = document.getElementById('tText');
tObj.value ="";

setUP("mRight","right_account","on","AdminRight");
setUP("mRight","right_change","on","ChangeRight"); 
setUP("mRight","right_dispatch","on","DispatchRight");
setUP("mRight","right_read","on","ReadRight");

function createOption(mID,sID,Index) {
	var mObj = eval("document.getElementById('"+mID+"')");
	var sObj = eval("document.getElementById('"+sID+"')");
	if (Index != -1) {
		var nOption = document.createElement("OPTION");
		nOption.text = mObj.options[Index].text;
		nOption.value = mObj.options[Index].value;
		nOption.name= mObj.options[Index].name;
		sObj.add(nOption);
		mObj.options[Index]=null;
	}
}

function selectAll(sID) {
	var sObj = eval("document.getElementById('"+sID+"')");
	var tObj = document.getElementById('tText');
		for (i=0;i < sObj.options.length; i++) {
			sObj.options[i].selected=true;
			tObj.value += sObj.options(i).name + "=" + sObj.options[i].value + "#";
		}
}
</script>