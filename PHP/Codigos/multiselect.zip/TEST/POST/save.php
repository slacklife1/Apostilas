<?
echo "Posted array: " . $sRights. "<br><br>";
$mArray = split ("#", $sRights);
for ($i=0;$i < Count($mArray)-1;$i++){
	 eval("\$".$mArray[$i].";");
}
for ($i=0;$i < Count($mArray)-1;$i++){
	print "$".$mArray[$i].@eval("\$".$mArray[$i])."\n<br>";
}
?>