-------------------------------------------------
EMAIL -> SMS 0.4 (29-SEP-2001)
Keyvan Minoukadeh - keyvan@k1m.com
http://www.k1m.com/php/
-------------------------------------------------
Script intended to be run every x minutes / hours (cron)
to check a POP3 account for email and forward on to mobile
using the free web-based service at http://www.mtnsms.com/.
It can pick up subject lines of '+44987987987 sig'
and will send to that number, alternatively if it does
not contain a number it will send it to the admin mobile.

The script itself isn't that complicated, pretty much all the
work is done by the 2 classes...
jm_sms 0.6 - http://james.mcglinn.org/jm_sms/ - by: James McGlinn
POP3 - http://www.thewebmasters.net/php/POP3.phtml - by: CDI
For more information see the source files of these 2 in the
POP3 folder and the jm_sms folder

The way I've set it up is I have the email on my main
account forward a copy to another account which I've set up
for this script to check, you might want to set up an
alias which forwards a copy to your main and account
and one to a temp account for this script to check.

NOTE: as of version 0.3 you can set the script to leave
the email on the server rather than delete it, so you can
use it on your main email account rather than set up 2.

Edit global.php with your settings and make the config file
writeable (eg. chmod 777).

CRON SAMPLE:
* * * * * wget -O /dev/null http://www.domain.com/email_to_sms/sendsms.php
the above will check every minute
0 * * * * wget -O /dev/null http://www.domain.com/email_to_sms/sendsms.php
the above will check every hour
*/5 * * * * wget -O /dev/null http://www.domain.com/email_to_sms/sendsms.php
the above will check every 5 minutes

you can of course use cgi version of php to execute the script rather than wget

SITE MONITORING?
Not sure how well these work, if at all, but if
you don't have access to set up some sort of scheduling to have the
script run every x minutes, these might work...
Note: some of these will exit as soon as they get some output, if that's
the case use sendsms_silent.php, also because it usually takes a while
the site monitor tool will probably think the site is dead (but the script
should continue to run).  Anyway, not tried all of these so experiment
and see...
http://www.internetseer.com/services/index.xtp
http://www.nfiniteweb.com/
http://www.serverrat.com/
http://www.qwkmon.com/
http://www.netmonitor365.com/default.asp

-----------
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
-----------

CHANGES...

0.4 (29-SEP-2001) - jm_sms version 0.7 included,
		    random mtnsms server chosen to start
		    with incase of problems, sendsms_silent.php
		    added (might help with site monitor 
		    services), error check added for empty
		    config file.

0.3 (8-SEP-2001)  - main new feature: leave mail on server
		    this is an extra variable you can set
		    in global.php and will basically
		    store UIDLs of messages in array and
		    serialize it into config file, each
		    new message will compare it's UIDL
		    to the ones in the array to see if
		    it's already been processed or not.

0.2 (26-AUG-2001) - fixed timeout problem, and hopefully
		    problem with body of email not being
		    included with SMS.
		    Included check_email.php incase of
		    problems.

0.1 (22-AUG-2001) - original