<?php

// an array serialized
// resets it to default values

include("global.php");

update_config($config_file, array(
				'count'=>0, 
				'process_email'=>1, 
				'admin_mail_sent'=>0, 
				'prev_uidl_array'=>array()));

echo "Done..";

?>
