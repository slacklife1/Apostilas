<?php

//------------------------------------------------------------------------
//-- POP3 Class Extended by Keyvan Minoukadeh
//-- pretty lame extension at the moment
//-- http://www.k1m.com/php/ - keyvan@k1m.com
//-- 24 June 2001
//------------------------------------------------------------------------
//-- Original class in POP3 folder
//------------------------------------------------------------------------

class kPOP3 extends POP3 {

	var $delivery_date = "";		// Delivery-date: Sun, 24 Jun 2001 18:51:42 -0400
	var $x_sender = "";				// X-Sender: user@domain.net@mail.domain.net
	var $x_mailer = "";				// X-Mailer: QUALCOMM Windows Eudora Version 5.0.2
	var $date = "";					// Date: Sun, 24 Jun 2001 23:51:40 +0100
	var $to = "";					// To: john@domain.com
	var $from = "";					// From: John
	var $subject = "";				// Subject: testing 
	var $mime_version = "";			// Mime-Version: 1.0
	var $content_type = "";			// Content-Type: text/plain; charset="us-ascii"; format=flowed 
	var $body = array();


	//-------------------------------------------
	//-- COUNT HEADER ROWS
	//-------------------------------------------
	function kcount_header_rows($msgNum) {

		$header = $this->top($msgNum, "0");

		$count = count($header) - 2;

		return $count;

	}

	//-------------------------------------------
	//-- FILLS HEADER VARS
	//-------------------------------------------
	function kfill_headers($msgNum) {

		// reset header vars
		$this->delivery_date = "";
		$this->x_sender = "";
		$this->x_mailer = "";
		$this->date = "";
		$this->to = "";
		$this->from = "";
		$this->subject = "";
		$this->mime_version = "";
		$this->content_type = "";
		$this->body = array();

		$header_string = implode("", $this->top($msgNum, "0"));
		$match_count = 0;
		
		if (preg_match('/Delivery-date: ([^\n]+)/i', $header_string, $matches)) {
			$this->delivery_date = $matches[1];
			unset($matches);
			$match_count++;
		}

		if (preg_match('/X-Sender: ([^\n]+)/i', $header_string, $matches)) {
			$this->x_sender = $matches[1];
			unset($matches);
			$match_count++;
		}

		if (preg_match('/X-Mailer: ([^\n]+)/i', $header_string, $matches)) {
			$this->x_mailer = $matches[1];
			unset($matches);
			$match_count++;
		}

		if (preg_match('/Date: ([^\n]+)/i', $header_string, $matches)) {
			$this->date = $matches[1];
			unset($matches);
			$match_count++;
		}

		if (preg_match('/To: ([^\n]+)/i', $header_string, $matches)) {
			$this->to = $matches[1];
			unset($matches);
			$match_count++;
		}

		if (preg_match('/From: ([^\n]+)/i', $header_string, $matches)) {
			$this->from = $matches[1];
			unset($matches);
			$match_count++;
		}

		if (preg_match('/Subject: ([^\n]+)/i', $header_string, $matches)) {
			$this->subject = $matches[1];
			unset($matches);
			$match_count++;
		}

		if (preg_match('/Mime-Version: ([^\n]+)/i', $header_string, $matches)) {
			$this->mime_version = $matches[1];
			unset($matches);
			$match_count++;
		}

		if (preg_match('/Content-Type: ([^\n]+)/i', $header_string, $matches)) {
			$this->content_type = $matches[1];
			unset($matches);
			$match_count++;
		}

		return $match_count;

	} // end function


	//-------------------------------------------
	//-- GRABS BODY
	//-- $numLines of body into string
	//-- uses POP3 TOP
	//-------------------------------------------
	function kget_body($msgNum, $numLines) {
		$body = $this->top($msgNum, $numLines);

		reset($body);

		$return_body = "";

		if (!empty($numLines)) {

			$header_row_count = $this->kcount_header_rows($msgNum);
			$body = array_slice($body, $header_row_count);
			
			reset($body);
	
			while ($line = next($body)) {
				$line = trim($line);

				$return_body .= "$line\n";

			}
		}

		return $return_body;

	}


	//-------------------------------------------
	//-- CONNECT GRABBED FROM ORIGINAL SOURCE
	//-------------------------------------------

	//-------------------------------------------
	//-- update_timer function
	//-------------------------------------------
	//-- changes:
	//-- allow timeout to be set from global file
	//-------------------------------------------
	function update_timer()
	{
		global $time_limit;
		if ($time_limit != "") {
			set_time_limit($time_limit);
		} else {
			set_time_limit($this->TIMEOUT);
		}

		return true;
	}

	//-------------------------------------------
	//-- CONNECT function
	//-------------------------------------------
	//-- changes:
	//-- set_socket_blocking() is deprecated
	//     changed to socket_set_blocking()
	//-- RFC check always failed for me, so
	//     I commented it out, you might want
	//     to uncomment it
	//-------------------------------------------

	function connect ($server, $port = 110)
	{
		//	Opens a socket to the specified server. Unless overridden,
		//	port defaults to 110. Returns true on success, false on fail

		// If MAILSERVER is set, override $server with it's value

		if(!empty($this->MAILSERVER))
		{
			$server = $this->MAILSERVER;
		}

		if(empty($server))
		{
			$this->ERROR = "POP3 connect: No server specified";  
			unset($this->FP);
			return false;
		}

		$fp = fsockopen("$server", $port, &$errno, &$errstr);

		if(!$fp)
		{
			$this->ERROR = "POP3 connect: Error [$errno] [$errstr]";
			unset($this->FP);
			return false;
		}

		socket_set_blocking($fp,-1);
		$this->update_timer();
		$reply = fgets($fp,$this->BUFFER);
		$reply = $this->strip_clf($reply);
		if($this->DEBUG) { error_log("POP3 SEND [connect: $server] GOT [$reply]",0); }
		if(!$this->is_ok($reply))
		{
			$this->ERROR = "POP3 connect: Error [$reply]";
			unset($this->FP);
			return false;
		}
		$this->FP = $fp;
		$this->BANNER = $this->parse_banner($reply);
		$this->RFC1939 = $this->noop();
		
		/*		
		if($this->RFC1939)
		{
			$this->ERROR = "POP3: premature NOOP OK, NOT an RFC 1939 Compliant server";
			$this->quit();
			return false;
		}
		*/
		return true;
	}




}

?>