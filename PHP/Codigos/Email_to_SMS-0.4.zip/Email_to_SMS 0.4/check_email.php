<?php

/*
outputs full email message
including headers, also
runs the function which grabs
only the body of message to 
send by SMS.

will NOT delete email message
and will NOT send by SMS

most of it will be similar to
sendsms...

should not leave this on, as
people might guess it and see
your email.

comment the die(); line to enable
*/

die("DISABLED (comment this line to enable)");

include("global.php");
include("pop3/class.POP3.php3");
include("kpop3.php");
include("jm_sms/class.jm_sms.php");

set_time_limit($time_limit);

// sets output to echo
$output = "pop_echo";

$pop3 = new kPOP3();

if(!$pop3->connect($pop_server, 110))
{
	$output("Ooops $pop3->ERROR <BR>\n");
	exit;
}

$Count = $pop3->login($pop_login, $pop_pass);
if( ($Count == -1) )
{
	$output("<H1>Login Failed: $pop3->ERROR</H1>\n");
	exit;
}

if ($Count < 1)
{
	$output("Login OK: Inbox EMPTY<BR>\n");
	$pop3->quit();
	exit;
} else {
	$output("Login OK: Inbox contains [$Count] messages<BR>\n");
}

//--------------------------------------------------
//-- INITIALISE THE SMS CLASS
//--------------------------------------------------
$jm_sms = new jm_sms($sms_email, $sms_password, $sms_debug);

// Add additional accounts if required
if (count($sms_additional_login) > 0) {
	for ($x = 0; $x < count($sms_additional_login); $x++) {
		list($tmp_email, $tmp_pass) = $sms_additional_login[$x];
		$jm_sms->addLogin($tmp_email, $tmp_pass);
	}
}

// count number of email messages
$messages = $pop3->last();

// checks to see if number of messages waiting to be processed is greater than $sends_per_exec
// if it is it sets $messages to $sends_per_exec
// $messages = (!empty($sends_per_exec) && $sends_per_exec < $messages) ? $sends_per_exec : $messages;

// loop through email messages
for ($x = 1; $x <= $messages; $x++) {

	$output("<b>Message $x ...</b><br>");

	// grab header vars
	$fields_matched = $pop3->kfill_headers($x);

	$output("$fields_matched email fields matched<br><br>");

	$tmp_body = $pop3->get($x);

	$output("Complete message:<br>");
	$output(implode("", $tmp_body));

	// grab uidl of email
	$sms_uidl = $pop3->uidl($x);
	$output("<br><br><b>UIDL:</b> $sms_uidl <br><br>");

	// grab $body_lines of email body
	$sms_body = $pop3->kget_body($x, $body_lines);

	$output("<b>SMS Body found:</b> $sms_body <br><br>");

	// cut and trim body
	$sms_body = substr(trim($sms_body), 0, 160); 

	$output("<b>SMS Body trimmed:</b> $sms_body <br><br>");

/*
	// mark email deleted (will not actually be deleted until pop3->quit()
	// has been executed
	if(!$pop3->delete($x))
	{
		$output("oops $pop3->ERROR <BR>\n");
		$pop3->reset();
		exit;
	} else {
		$output("<br> - Message $x Deleted\n");
	}

	// tries to match a phone number in the subject line
	if (preg_match('/(\+[0-9]+) ?([a-zA-Z0-9_-]+)?/', $pop3->subject, $matches) && $allow_forwarded_sms) {
		$signature = (isset($matches[2])) ? $matches[2] : $sms_glob_signature;
		$sms_success = $jm_sms->sendSMS($matches[1], $signature, $sms_body);
		unset($matches);

		if ($sms_success) {
			$output("<br> - Message $x Sent");
		} else {
			$output("<br> - <b>Message $x NOT Sent</b>");
		}

	} elseif (!empty($admin_mobile)) {
		$new_sms_body = "s: $pop3->subject\n";
		$new_sms_body .= "f: $pop3->from\n";
		$new_sms_body .= "m: $sms_body";
		$signature = "*";
		$sms_success = $jm_sms->sendSMS($admin_mobile, $signature, $new_sms_body);
		
		if ($sms_success) {
			$output("<br> - Message $x Sent");
		} else {
			$output("<br> - <b>Message $x NOT Sent</b>");
		}

	} else {
		$output(" - $pop3->subject didn't match");
	}
	
*/

}

$pop3->quit();

?>
