<? require( "class.jm_sms.php" ); ?>
<html>
<head>
<title>SMS gateway</title>
</head>
<body bgcolor="#000000" text="#FFFFFF" marginwidth="0" marginheight="0" leftmargin="0" rightmargin="0" topmargin="0">
<?
if (	(strlen($HTTP_POST_VARS[email]) > 10) &&
	(strlen($HTTP_POST_VARS[password]) > 0) &&
	(strlen($HTTP_POST_VARS[phonenumber]) > 10) &&
	(strlen($HTTP_POST_VARS[message]) > 0)
	)
	{
	$jm_sms = new jm_sms( $HTTP_POST_VARS[email], $HTTP_POST_VARS[password], ( $HTTP_POST_VARS[debug] == 'on'?TRUE:FALSE ) );

	// Proxy Server Details
	// $jm_sms->setProxyServer( "proxyserver" );
	// $jm_sms->setProxyPort( 81 );
	// $jm_sms->setProxyUser( "proxyusername" );
	// $jm_sms->setProxyPass( "proxypassword" );
	// $jm_sms->setProxy( TRUE );

	echo "<pre>\n";
	ob_implicit_flush( TRUE );
	if( $jm_sms->sendSMS( $HTTP_POST_VARS[phonenumber], $HTTP_POST_VARS[signature], $HTTP_POST_VARS[message] ) )
		{
		echo "<br><b>SMS message was sent succesfully</b><br>";
		};
	echo "</pre>\n";
	};
?>
<table width="100%" height="100%" border=1 cellpadding=0 cellspacing=0>
<tr>
<td align=center valign=middle>
<table border=0 cellpadding=0 cellspacing=1>
<form method=POST>
<tr><th colspan=2 align=center>Send an SMS message</th></tr>
<tr><td colspan=2><hr></td></tr>
<tr><td align=right>email:</td><td><input type=text name="email" value="email@mtnsms.com" size=40></td></tr>
<tr><td align=right>password:</td><td><input type=password name="password" size=40></td></tr>
<tr><td align=right>phone number:</td><td><input type=text name="phonenumber" value="+31" size=40></td></tr>
<tr><td align=right>message:</td><td><textarea name="message" cols="40" rows="6"></textarea></td></tr>
<tr><td align=right>signature:</td><td><textarea name="signature" cols="40" rows="2">mysig</textarea></td></tr>
<tr><td align=right>debug:</td><td><input type=checkbox name="debug"></td></tr>
<tr><td colspan=2><hr></td></tr>
<tr><td colspan=2 align=center><input type=submit value="Send" name=""></td></tr>
</form>
</table>
</td>
</tr>
</table>
</body>
</html>
