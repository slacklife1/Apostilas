<?
	// Example script using jm_sms class
	$email = "email@domain.com";	// MTNSMS login email address
	$password = "password";		// MTNSMS password
	$number = "+64123456";		// GSM phone number to send to
	$signature = "jm_sms";		// Signature for text message
	$message = "This is a test";	// Content of text message
	$debug = FALSE;			// Debugging messages not displayed

	include( "class.jm_sms.php" );
	$jm_sms = new jm_sms( $email, $password, $debug );

	// Add additional accounts if required
	// $jm_sms->addLogin( "email2@domain.com", "password2" );
	// $jm_sms->addLogin( "email3@domain.com", "password3" );

	// Add Proxy Server details if required
	// $jm_sms->setProxyServer( "proxyserver" );
	// $jm_sms->setProxyPort( 81 );
	// $jm_sms->setProxyUser( "proxyusername" );
	// $jm_sms->setProxyPass( "proxypassword" );
	// $jm_sms->setProxy( TRUE );

	$jm_sms->sendSMS( $number, $signature, $message );
?>
