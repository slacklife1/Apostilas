<?php
/* 
V0.91 21 Dec 2000 (c) 2000 John Lim (jlim@natsoft.com.my). All rights reserved.
  Released under Lesser GPL library license. See License.txt. 
  Set tabs to 8 for best viewing.
  
  Latest version is available at http://php.weblogs.com/
  
  Microsoft Access data driver. Requires ODBC. Works only on MS Windows.
*/
if (!defined('_ADODB_ODBC_LAYER')) {
	include("$ADODB_DIR/adodb-odbc.inc.php");
}
 if (!defined('_ADODB_ACCESS')) {
 	define('_ADODB_ACCESS',1);
class  ADODB_access extends ADODB_odbc {	
var $databaseType = 'access';

var $fmtDate = "#Y-m-d#";
var $fmtTimeStamp = "#Y-m-d h:i:sA#"; // note not comma

	function BeginTrans() { return false;}
}

 
class  ADORecordSet_access extends ADORecordSet_odbc {	
	
	var $databaseType = "access";		
	
	function ADORecordSet_access($id)
	{
		return $this->ADORecordSet_odbc($id);
	}
}
} // class
?>