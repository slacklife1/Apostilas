<?php 
/*
V0.91 21 Dec 2000 (c) 2000 John Lim (jlim@natsoft.com.my). All rights reserved.
  Released under Lesser GPL library license. See License.txt.
*/ 
  
// specific code for tohtml
GLOBAL $gSQLMaxRows,$gSQLBlockRows;
	 
$gSQLMaxRows = 1000; // max no of rows to download
$gSQLBlockRows=20; // max no of rows per table block

// RecordSet to HTML Table
//------------------------------------------------------------
// Convert a recordset to a html table. Multiple tables are generated
// if the number of rows is > $gSQLBlockRows. This is because
// web browsers normally require the whole table to be downloaded
// before it can be rendered, so we break the output into several
// smaller faster rendering tables.
//
// $rs: the recordset
// $ztabhtml: the table tag attributes
// $zheaderarray: contains the replacement strings for the headers
//
// RETURNS: number of rows displayed
function rs2html(&$rs,$ztabhtml='',$zheaderarray="")
{
$s =''; $flds; $ncols; $i;$rows=0;$hdr;$docnt = false;
GLOBAL $gSQLMaxRows,$gSQLBlockRows;

	
	if (! $ztabhtml) $ztabhtml = " border='1' width='98%' ";
	else $docnt = true;
	$typearr = array();
        $ncols = $rs->FieldCount();
        $hdr = "<TABLE COLS=$ncols $ztabhtml>";
	for ($i=0; $i < $ncols; $i++) {	
		if ($zheaderarray) {
			$fname = $zheaderarray[$i];
		} else {
			$field = $rs->FetchField($i);
			$fname = htmlspecialchars($field->name);
			$typearr[$i] = $rs->MetaType($field->type,$field->max_length);
                       // print_r($field);
                }
		$hdr .= "<TH>$fname</TH>";
         }

	print $hdr;

	//print_r($typearr);
	
       	while (!$rs->EOF) {
                $s .= "<TR>";
		
                for ($i=0; $i < $ncols; $i++) {
                        $type = $typearr[$i];
                        
			if ($type == 'T')
				$s .= "<TD>".$rs->UserTimeStamp($rs->fields[$i],"D d, M Y, h:i:s") ."</TD>";
			else if ($type == 'D')
				$s .= "<TD>".$rs->UserDate($rs->fields[$i],"D d, M Y") ."</TD>";
			else
				$s .= "<TD>".htmlspecialchars(trim($rs->fields[$i])) ."&nbsp;</TD>";
                }
                $s .= "</TR>\n\n";
               
		$rows += 1;
		if ($rows >= $gSQLMaxRows) {
			$rows = "<p>Truncated at $gSQLMaxRows</p>";
			break;
		}

		$rs->MoveNext();
		
		// additional EOF check to prevent a widow header
	        if (!$rs->EOF && $rows % $gSQLBlockRows == 0) {
		
			//if (connection_aborted()) break;// not needed as PHP aborts script, unlike ASP
                        print $s . "</TABLE>\n\n";
                        $s = $hdr;
		}
        } // while
	
       	print $s."</TABLE>\n\n";

	if ($docnt) print "<H2>".$rows." Rows</H2>";
	
	return $rows;
 }
?>