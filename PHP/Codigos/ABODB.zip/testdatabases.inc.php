<?php
  
/*
V0.91 21 Dec 2000 (c) 2000 John Lim (jlim@natsoft.com.my). All rights reserved.
  Released under Lesser GPL library license. See License.txt.
*/ 
 
 /* this file is used by the ADODB test program: test.php */
 
// cannot test databases below, but we include them anyway to check
// if they parse ok...
ADOLoadCode("postgres");
ADOLoadCode("sybase");
if ($testpostgres && false) {
	//ADOLoadCode("postgres");
	$db = &ADONewConnection('postgres');
	@$db->PPConnect("host1","user1","pwd");
	@$db->PConnect("str1 str2");
}
ADOLoadCode("ibase");
if ($testibase) {
	
	$db = &ADONewConnection();
	print "<h1>Connecting $db->databaseType...</h1>";
	if (@$db->PConnect("e:\\interbase\\examples\\database\\employee.gdb", "sysdba", "masterkey", ""))
		testdb($db,"create table ADOXYZ (id integer, firstname char(24), lastname char(24),created date)");
	 else print "ERROR: Interbase test requires a database called employee.gdb".'<BR>'.$db->ErrorMsg();
	
}
ADOLoadCode("vfp");
if ($testvfp) { // ODBC
	
	$db = &ADONewConnection('vfp');
	print "<h1>Connecting $db->databaseType...</h1>";
	if (@$db->PConnect("logos2", "", "", ""))
		testdb($db,"create table d:\\inetpub\\wwwroot\\logos2\\data\\ADOXYZ (id int, firstname char(24), lastname char(24),created date)");
	 else print "ERROR: Visual FoxPro test requires a Windows ODBC DSN=logos2, VFP driver";
	
}
ADOLoadCode("ado_access");
if ($testaccess && $testado) { // ADO ACCESS
	
	$db = &ADONewConnection("ado_access");
	print "<h1>Connecting $db->databaseType...</h1>";
	
	$access = 'E:\VB\NWIND.MDB';
	$myDSN =  'PROVIDER=Microsoft.Jet.OLEDB.4.0;'
		. 'DATA SOURCE=' . $access . ';';
		//. 'USER ID=;PASSWORD=;';
	
	if (@$db->PConnect($myDSN, "", "", "")) {
		print "ADO version=".$db->_connectionID->version."<br>";
		testdb($db,"create table ADOXYZ (id int, firstname char(24), lastname char(24),created datetime)");
	} else print "ERROR: Access test requires a Access database $access".'<BR>'.$db->ErrorMsg();
	
}



ADOLoadCode("access");
// REQUIRES ODBC DSN CALLED nwind
if ($testaccess) {
	
	$db = &ADONewConnection('access');
	print "<h1>Connecting $db->databaseType...</h1>";
	
	if (@$db->PConnect("nwind", "", "", ""))
		testdb($db,"create table ADOXYZ (id int, firstname char(24), lastname char(24),created datetime)");
	else print "ERROR: Access test requires a Windows ODBC DSN=nwind, Access driver";
	
}
ADOLoadCode("mysqlt");
// REQUIRES MySQL server at localhost with database 'test'
if ($testmysql) { // MYSQL
	
	$db = &ADONewConnection();
	print "<h1>Connecting $db->databaseType...</h1>";
	if (@$db->PConnect("192.168.0.1", "", "", "test"))
		testdb($db);
	else print "ERROR: MySQL test requires a MySQL server on localhost, userid='admin', password='', database='test'".'<BR>'.$db->ErrorMsg();
	
}
ADOLoadCode("oci8");
if ($testoracle) { 
	
	$db = ADONewConnection();
	print "<h1>Connecting $db->databaseType...</h1>";
	if ($db->PConnect("", "scott", "tiger", ""))
		testdb($db,"create table ADOXYZ (id int, firstname varchar(24), lastname varchar(24),created date)");
	else print "ERROR: Oracle test requires an Oracle server setup with scott/tiger".'<BR>'.$db->ErrorMsg();

}
ADOLoadCode("oracle");
if ($testoracle) { 
	
	$db = ADONewConnection();
	print "<h1>Connecting $db->databaseType...</h1>";
	if ($db->PConnect("", "scott", "tiger", ""))
		testdb($db,"create table ADOXYZ (id int, firstname varchar(24), lastname varchar(24),created date)");
	else print "ERROR: Oracle test requires an Oracle server setup with scott/tiger".'<BR>'.$db->ErrorMsg();

}



ADOLoadCode("odbc_mssql");
if ($testmssql) { // MS SQL Server via ODBC
	
	$db = ADONewConnection();
	print "<h1>Connecting $db->databaseType...</h1>";
	if (@$db->PConnect("ai", "sa", "", ""))
		testdb($db,"create table ADOXYZ (id int, firstname char(24), lastname char(24),created datetime)");
	else print "ERROR: MSSQL test 1 requires a MS SQL 7 server setup with DSN='ai', userid='sa', password=''";

}

ADOLoadCode("mssql");
if ($testmssql) { // MS SQL Server -- the extension is buggy -- probably better to use ODBC
	$db = ADONewConnection();
	print "<h1>Connecting $db->databaseType...</h1>";
	if (@$db->PConnect("flipper2", "sa", "", "ai"))
		testdb($db,"create table ADOXYZ (id int, firstname char(24), lastname char(24),created datetime)");
	else print "ERROR: MSSQL test 2 requires a MS SQL 7 on a server='flipper', userid='sa', password='', database='ai'".'<BR>'.$db->ErrorMsg();
	
}


ADOLoadCode("ado_mssql");

if ($testmssql & $testado ) { // ADO ACCESS MSSQL -- thru ODBC -- DSN-less
	
	$db = &ADONewConnection("ado_mssql");
	print "<h1>Connecting DSN-less $db->databaseType...</h1>";
	
	$myDSN="PROVIDER=MSDASQL;DRIVER={SQL Server};"
		. "SERVER=flipper2;DATABASE=ai;UID=sa;PWD=;"  ;

		
	if (@$db->PConnect($myDSN, "", "", ""))
		testdb($db,"create table ADOXYZ (id int, firstname char(24), lastname char(24),created datetime)");
	else print "ERROR: MSSQL test 2 requires a MS SQL 7 on a server='flipper', userid='sa', password='', database='ai'";
	
}


if ($testmssql & $testado ) { // ADO ACCESS MSSQL with OLEDB provider

	$db = &ADONewConnection("ado_mssql");
	print "<h1>Connecting DSN-less OLEDB Provider $db->databaseType...</h1>";
	
	$myDSN="SERVER=flipper2;DATABASE=ai;";
		
	if (@$db->PConnect($myDSN, "sa", "", 'SQLOLEDB'))
		testdb($db,"create table ADOXYZ (id int, firstname char(24), lastname char(24),created datetime)");
	else print "ERROR: MSSQL test 2 requires a MS SQL 7 on a server='flipper', userid='sa', password='', database='ai'";

}

?>