<?php
/* 
V0.91 21 Dec 2000 (c) 2000 John Lim. All rights reserved.
  Released under Lesser GPL library license. See License.txt. 
  Set tabs to 8 for best viewing.
  
  Latest version is available at http://php.weblogs.com/
  
  Sybase driver contributed by Toni ttunkka@suomi24.fi
*/
 
class ADODB_sybase extends ADODBConnection {
	var $databaseType = "sybase";	
	var $replaceQuote = "''"; // string to use to replace quotes
	var $fmtDate = "'Y-m-d H:i:s.0'";
	var $fmtTimeStamp = "'Y-m-d H:i:s.0'";
	var $hasInsertID = true;
        var $hasAffectedRows = true;
  	var $metaTablesSQL="select name from sysobjects where type='U' or type='V'";
	var $metaColumnsSQL = "select c.name,c.type,c.length from syscolumns c join sysobjects o on o.id=c.id where o.name='%s'";
      	var $concat_operator = '+'; 
	
	function ADODB_sybase() {			
	}
 
        // might require begintrans -- committrans
        function _insertid()
        {
                $rs = $this->Execute('select @@identity');
                if ($rs == false || $rs->EOF) return false;
               $id = $rs->fields[0];
               $rs->Close();
               return $id;
        }
          // might require begintrans -- committrans
        function _affectedrows()
        {
                $rs = $this->Execute('select @@rowcount');
                if ($rs == false || $rs->EOF) return false;
               $id = $rs->fields[0];
               $rs->Close();
               return $id;
        }

              
        function BeginTrans()
	{       
               $this->Execute('BEGIN TRAN');
               return true;
	}
	// Reserved for future expansion
	function CommitTrans()
	{
                $this->Execute('COMMIT TRAN');
                return true;
	}
	// Reserved for future expansion
	function RollbackTrans()
	{
                $this->Execute('ROLLBACK TRAN');
                return true;
	}
	
        
	function SelectDB($dbName) {
		$this->databaseName = $dbName;
		if ($this->_connectionID) {
			return @sybase_select_db($dbName);		
		}
		else return false;	
	}

	/*	Returns: the last error message from previous database operation
		Note: This function is NOT available for Microsoft SQL Server.	*/	

	function ErrorMsg() {
		$this->_errorMsg = "errorMsg() is not available for Sybase SQL Server";
		return $this->_errorMsg;
	}

	// returns true or false
	function _connect($argHostname, $argUsername, $argPassword, $argDatabasename)
	{
		$this->_connectionID = sybase_connect($argHostname,$argUsername,$argPassword);
		if ($this->_connectionID === false) return false;
		if ($argDatabasename) return $this->SelectDB($argDatabasename);
		return true;	
	}
	// returns true or false
	function _pconnect($argHostname, $argUsername, $argPassword, $argDatabasename)
	{
		$this->_connectionID = sybase_pconnect($argHostname,$argUsername,$argPassword);
		if ($this->_connectionID === false) return false;
		if ($argDatabasename) return $this->SelectDB($argDatabasename);
		return true;	
	}
	
	// returns query ID if successful, otherwise false
	function _query($sql,$inputarr)
	{
		//@sybase_free_result($this->_queryID);
		return sybase_query($sql,$this->_connectionID);
	}
	
	// returns true or false
	function _close()
	{ 
		return @sybase_close($this->_connectionID);
	}
	
	
}
	
/*--------------------------------------------------------------------------------------
	 Class Name: Recordset
--------------------------------------------------------------------------------------*/

class ADORecordset_sybase extends ADORecordSet {	

	var $databaseType = "sybase";
	var $canSeek = true;
		
	function ADORecordset_sybase($id)
	{
		return $this->ADORecordSet($id);
	}
	

	/*	Returns: an object containing field information. 
		Get column information in the Recordset object. fetchField() can be used in order to obtain information about
		fields in a certain query result. If the field offset isn't specified, the next field that wasn't yet retrieved by
		fetchField() is retrieved.	*/
	function FetchField($fieldOffset = -1) 
	{
		if ($fieldOffset != -1) {
			$o = @sybase_fetch_field($this->_queryID, $fieldOffset);
		}
		else if ($fieldOffset == -1) {	/*	The $fieldOffset argument is not provided thus its -1 	*/
			$o = @sybase_fetch_field($this->_queryID);
		}
		// older versions of PHP did not support type, only numeric
		if ($o && !isset($o->type)) $o->type = ($o->numeric) ? 'float' : 'varchar';
		return $o;
	}
	
	function _initrs()
	{
	global $ADODB_COUNTRECS;
		$this->_numOfRows = ($ADODB_COUNTRECS)? @sybase_num_rows($this->_queryID):-1;
		$this->_numOfFields = @sybase_num_fields($this->_queryID);
	}
	
	function _seek($row) 
	{
		return @sybase_data_seek($this->_queryID, $row);
	}		

	function _fetch($ignore_fields=false) {
		$this->fields = @sybase_fetch_array($this->_queryID);
		return ($this->fields == true);
	}
	
	/*	close() only needs to be called if you are worried about using too much memory while your script
		is running. All associated result memory for the specified result identifier will automatically be freed.	*/
	function _close() {
		return @sybase_free_result($this->_queryID);		
	}

}
?>