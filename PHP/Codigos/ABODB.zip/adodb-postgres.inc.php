<?php
/*
 V0.91 21 Dec 2000 (c) 2000 John Lim (jlim@natsoft.com.my). All rights reserved.
  Released under Lesser GPL library license. See License.txt.
  Set tabs to 8.
  
  This version is strictly experimental and not part of the ADODB official release.

  Original version derived from Alberto Cerezal (acerezalp@dbnet.es) - DBNet Informatica & Comunicaciones. 
  08 Nov 2000 jlim - Minor corrections, removing mysql stuff
  09 Nov 2000 jlim - added insertid support suggested by "Christopher Kings-Lynne" <chriskl@familyhealth.com.au>
                    jlim - changed concat operator to || and data types to MetaType to match documented pgsql types 
	     	see http://www.postgresql.org/devel-corner/docs/postgres/datatype.htm  
  22 Nov 2000 jlim - added changes to FetchField() and MetaTables() contributed by "raser" <raser@mail.zen.com.tw>
  27 Nov 2000 jlim - added changes to _connect/_pconnect from ideas by "Lennie" <leen@wirehub.nl>
  15 Dec 2000 jlim - added changes suggested by Additional code changes by "Eric G. Werk" egw@netguide.dk. 
  To Do: Add time and date handling.
*/

class ADODB_postgres extends ADODBConnection{
	var $databaseType = 'postgres';
        var $hasInsertID = true;
        var $_resultid = false;
  	var $concat_operator='||';
	
	function ADODB_postgres() 
	{
	}

	/* Warning from http://www.php.net/manual/function.pg-getlastoid.php:
	Using a OID as a unique identifier is not generally wise. 
	Unless you are very careful, you might end up with a tuple having 
	a different OID if a database must be reloaded. */
        function _insertid()
        {
		return pg_getlastoid($this->_resultid);
        }

         function _affectedrows()
        {
		return pg_cmdTuples($this->_resultid);      
        }

// MetaTables
	function &MetaTables()
	{
		$rs = &$this->Execute('select * from pg_tables');
		if (empty($rs)) return false;
		$arr3 = &$rs->GetArray();
		$rs->Close();

		$num = sizeof($arr3);
		for ($i=0; $i<$num; $i++)
			if (!ereg("pg_.*", $arr3[$i][tablename], $regs))
				$arr[] = $arr3[$i];
		
		$arr2 = array();
		for ($i=0; $i < sizeof($arr); $i++) {
			$arr2[] = $arr[$i][0];
		}
		return $arr2;
	}
	
		// returns true/false
	function BeginTrans()
	{
		return @pg_Exec($this->_connectionID, "begin");
	}

	// returns true/false. 
	function CommitTrans()
	{
		return @pg_Exec($this->_connectionID, "commit");
	}
	
	// returns true/false
	function RollbackTrans()
	{
		return @pg_Exec($this->_connectionID, "rollback");
	}

	
	// returns true or false
	//
	// examples:
	// 	$db->Connect("host=host1 user=user1 password=secret port=4341");
	// 	$db->Connect('host1','user1','secret');
	function _connect($str,$user='',$pwd='',$db='')
	{           
		if ($user || $pwd || $db) {
           		if ($str)  {
			 	$host = split(":", $str);
				if ($host[0]) $str .= "host=$host[0]";
				if (isset($host[1])) $str .= " port=$host[1]";
			}
           		if ($user) $str .= " user=".$user;
           		if ($pwd)  $str .= " password=".$pwd;
			if ($db)   $str .= " dbname=".$db;
		}
		
		//if ($user) $linea = "user=$user host=$linea password=$pwd dbname=$db port=5432";
		$this->_connectionID = pg_connect($str);
		if ($this->_connectionID === false) return false;
                return true;
	}
	
	// returns true or false
	//
	// examples:
	// 	$db->PConnect("host=host1 user=user1 password=secret port=4341");
	// 	$db->PConnect('host1','user1','secret');
	function _pconnect($str,$user='',$pwd='',$db='')
	{
		if ($user || $pwd || $db) {
           		if ($str)  $str = "host=".$str;
           		if ($user) $str .= " user=".$user;
           		if ($pwd)  $str .= " password=".$pwd;
			if ($db)   $str .= " dbname=".$db;
		}
		//if ($user) $linea = "user=$user host=$linea password=$pwd dbname=$db port=5432";
		$this->_connectionID = pg_pconnect($str);
		if ($this->_connectionID === false) return false;
		return true;
	}

	// returns queryID or false
	function _query($sql,$inputarr)
	{
                $this->_resultid= pg_Exec($this->_connectionID,$sql);
                return $this->_resultid;
	}
	

	/*	Returns: the last error message from previous database operation	*/	
	function ErrorMsg() {
		$this->_errorMsg = @pg_errormessage($this->_connectionID);
	    return $this->_errorMsg;
	}

	// returns true or false
	function _close()
	{
		return true;
	}
		
}
	
/*--------------------------------------------------------------------------------------
	 Class Name: Recordset
--------------------------------------------------------------------------------------*/

class ADORecordSet_postgres extends ADORecordSet{

	var $databaseType = "postgres";
	var $canSeek = true;
	
	function ADORecordSet_postgres($queryID) {
		$res=$this->ADORecordSet($queryID);
                return $res;
	}

	function _initrs()
	{
	global $ADODB_COUNTRECS;
		$this->_numOfRows = ($ADODB_COUNTRECS)? @pg_numrows($this->_queryID):-1;
		$this->_numOfFields = @pg_numfields($this->_queryID);
	}



	function FetchField($fieldOffset = 0) {
		$o;
		$off=$fieldOffset; // offsets begin at 0
		
		$o= new ADODBFieldObject();
		$o->name = @pg_fieldname($this->_queryID,$off);
		$o->type = @pg_fieldtype($this->_queryID,$off);
		$o->max_length = @pg_fieldsize($this->_queryID,$off);
		//print_r($o);		
		//print "off=$off name=$o->name type=$o->type len=$o->max_length<br>";
		return $o;	
	}

	function _seek($row)
	{
		return @pg_fetch_row($this->_queryID,$row);
	}

	function _fetch($ignore_fields=false)
	{
		$this->fields = @pg_fetch_array($this->_queryID,$this->_currentRow);
		return ($this->fields == true);
	}

	function _close() {
		return @pg_freeresult($this->_queryID);
	}

	function MetaType($t,$len=-1)
	{
		$len = -1; //  max_length is not accurate for MySQL, postgres?
		switch (strtoupper($t)) {
		
		case 'CHAR':
		case 'VARCHAR':
		case 'NAME':
			if ($len <= $this->blobSize) return 'C';

		case 'TEXT':
			return 'B';

		case 'DATE': return 'D';
		case 'TIME':
		case 'DATETIME':
		case 'TIMESTAMP': return 'T';
		
		case 'INTEGER': 
		case 'INT8': 
		case 'INT2':
				return 'I';
		default: return 'N';
		}
	}

}
?>
