Title: ADODB Database Wrapper Library
Description: This is a PHP database wrapper library that allows you to port your MySQL/PostgreSQL code to other databases. It currently supports MySQL, PostgreSQL, Sybase, Interbase, Oci8, Oracle, MS SQL 7, ADO, Foxpro, Access, and generic ODBC. 
<p>
Windows programmers will find it easy adapt to because many of the conventions are similar to Microsoft's ADO. We provide support code to handle inserts and updates which can be adapted to multiple databases quickly. 
Methods are provided for date handling, string concatenation and string quoting characters for differing databases. Also, a metatype system is built in so that you can figure out that types such as CHAR, TEXT and STRING are equivalent in different databases. SQL to popup menu select and SQL to HTML table support included. Very portable. Includes PHP4 session handler using ADODB to store your session data. 
<p>
Note: PostgreSQL support still experimental. Check http://php.weblogs.com/adodb for latest version.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=247&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
