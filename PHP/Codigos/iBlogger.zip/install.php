<?
////////////////////////////////////////////////////////////////
////////////////////////////////(c)oded by Arnab Nandi//////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//////////////////////***//**///////////////////////////////////
//////////////////////***//**///////////////////////////////////
///////////////////////////**///////////////////////////////////
//////////////////////***//**///////////////////////////////////
//////////////////////***//**///////////////////////////////////
//////////////////////***//******///////////////////////////////
//////////////////////***//**///*///////////////////////////////
//////////////////////***//******///////////////////////////////
//////////////////////iBlogger v1///////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//All of This code is (c) Iota Innomedia - Do NOT edit it...////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
// load db class
  $dbclassname="DB.php";
  include($dbclassname);
?>
<html>
<head>
<title>iBlogger Install</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF">


<table width="400" height="100%" border="0" cellspacing="0" cellpadding="0" align="center" valign="center">
<tr>
<td>
<p><font color="#FF0000"><i><font size="7" color="#6633FF">i</font></i></font><font size="7">blogger</font>I N S T A L L<br>
<?

if ($step>4||$step<1) 
{
print<<<END
this will install iblogger...<br>
<a href="install.php?step=1">continue...
</a><br>
END;
}
if ($step==1) 
{
print<<<END
<i><b>STEP 1:</b></i>
database info<br>
please enter the database info of your mysql server...<br>
</p>
<form name="form" method="post">
server name:
<input type="text" name="servername">
<input type="hidden" name="step" value="2">
<br>
database name:
<input type="text" name="dbname">
<input type="hidden" name="step" value="2">
<br>
serverusername:
<input type="text" name="username">
<br>
serverpassword:
<input type="password" name="password">
<br>
blog's name:
<input type="text" name="blogname">

<br>
<div align="right">
<input type="submit" name="Submit" value="Proceed to Step 2...">
</div>
<br>
</form>
END;
}

if ($step==2) 
{

print<<<END
END;
//Collect info about the database, test it, if ok, save in setup.txt...
  $DBase=new DB;

  // initialise vars
  $DBase->name=$blogname;
  $DBase->database=$dbname;
  $DBase->server=$servername;
  $DBase->user=$username;
  $DBase->password=$password;

  // allow this script to catch errors
  $DBase->reporterror=0;

  $DBase->connect();
  // end init db

 $errno=$DBase->errno;

  if ($errno!=0)
  {
  //Try creating the database...
         $DBase->query("CREATE DATABASE $dbname");
         $DBase->select_db($dbname);
         $errno=$DBase->geterrno();
  }
  
  if ($errno!=0||$DBase->link_id==0)
  {
  $dbcon="<font color=\"#CC0000\"> error</font><p>Wierd. Couldn't do it. <a href=\"install.php\">BACK</a> <hr> <font color=\"#FFFFFF\"> ";

  }
  
  else 
  {
  $dbcon="<font color=\"#006600\"> done</font><br>";
  }

//Database OK...save settings in setup.txt...
$DBsettings="<?\n#iBlogger Settings\n\$blogname= \"$blogname\";\n\$dbname= \"$dbname\";\n\$servername= \"$servername\";\n\$username= \"$username\";\n\$password= \"$password\";\n?>";
$fp = fopen("settings.txt", "w");
fwrite($fp,$DBsettings);
fclose($fp);


//Now that the database is there, go on with Table creation...

  //BLOG STORIES TABLE 
  $DBase->query("DROP TABLE IF EXISTS iblogs");
   
  $DBase->query("CREATE TABLE iblogs ( 
  					blogid INT UNSIGNED NOT NULL,
  					title CHAR(100),
   					btext MEDIUMTEXT,
  					posttime INT UNSIGNED NOT NULL,
  					comments INT UNSIGNED NOT NULL,
   					author CHAR(30)
   					
   				      )
  		");
  //insert one blogpost...
$time=time();
$DBase->query("INSERT INTO iblogs VALUES(1,\"welcome to iblogger!\",\"this is a sample blog post\",$time,0,\"iblogger\")");  
  
  //BLOG COMMENTS TABLE  		
  $DBase->query("DROP TABLE IF EXISTS iblogcomments");
  $DBase->query("CREATE TABLE iblogcomments ( 
  					blogid INT UNSIGNED NOT NULL,
  					btext MEDIUMTEXT,
  					posttime INT UNSIGNED NOT NULL,
  					author CHAR(30),
  					email CHAR(64)
   					
   				      )
  		");

  //insert one comment...
$DBase->query("INSERT INTO iblogcomments VALUES(1,\"this is the first comment\",$time,\"iblogger\",\"iblogger\@iotaspace\.net\")");
  
  //BLOG USERS TABLE  		
  $DBase->query("DROP TABLE IF EXISTS iblogusers");
  $DBase->query("CREATE TABLE iblogusers ( 
  					userid INT UNSIGNED NOT NULL,
  					username CHAR(30),
  					password CHAR(30),
  					email CHAR(64),
  					descr MEDIUMTEXT,
  					perm CHAR(10)
   					
   				      )
  		");

  
  $errno=$DBase->geterrno();
  if ($errno!=0) {
        $prompt="<font color=\"#CC0000\"> error</font><p>Wierd. Couldn't do it. <a href=\"install.php\">BACK</a> <hr> <font color=\"#FFFFFF\"> ";
        print "\n<p>Unexpected error from the database.</p>";
        print "\n<p>Error number: ".$DBase->errno."</p>";
        print "\n<p>Error description: ".$DBase->errdesc."</p>";
        print "\n<p>Please ensure that the database and server is correctly configured and try again.</p>";
  		 }

else $prompt="<a href=\"install.php?step=3\">Congrats! all ok... Proceed to step 3</a>";
///////////////////


print<<<END
<hr>
<i><b>STEP 2:<br>
</b></i>1)connecting to database <b>"$dbname"</b>...$dbcon
2)setting up/resetting tables.............<br>
  &nbsp;&nbsp;&nbsp;&gt;&gt;table &quot;iblogs&quot;....

<br>
&nbsp;&nbsp;&nbsp;&gt;&gt;table &quot;icomments&quot;....

<br>
&nbsp;&nbsp;&nbsp;&gt;&gt;table &quot;iusers&quot;....

<br>
3)
populating tables....<br>
&nbsp;&nbsp;&nbsp;&gt;&gt;table &quot;iblogs&quot;....

<br>
&nbsp;&nbsp;&nbsp;&gt;&gt;table &quot;icomments&quot;....

<br>

<br>

<div align="right">$prompt</div>
<br>
END;
}

if ($step==3) 
{

print<<<END
<i><b>STEP 3:<br>
</b></i>Setup first superuser....<br>
<form name="form" method="post">
<br>
username:
<input type="hidden" name="step" value="4">
<input type="text" name="username2">
<br>
password:
<input type="password" name="password2">
<br>
<br>
<div align="right">
<input type="submit" name="Submit2" value="Proceed to Final Step 4...">
</div>
<br>
</form>
END;
}

if ($step==4) 
{

  include("settings.txt");
  $DBase=new DB;

  // initialise vars
  $DBase->name=$blogname;
  $DBase->database=$dbname;
  $DBase->server=$servername;
  $DBase->user=$username;
  $DBase->password=$password;

  // allow this script to catch errors
  $DBase->reporterror=0;

  $DBase->connect();
  // end init db

$DBase->query("INSERT INTO iblogusers VALUES(1,\"$username2\",\"$password2\",\"$email\",\"please enter you desc. here\",\"peuedudpcf\")");

//Database OK...save settings in setup.txt...
$text="<?\n#iBlogger Settings\n\$blogname= \"$blogname\";\n\$dbname= \"$dbname\";\n\$servername= \"$servername\";\n\$username= \"$username\";\n\$password= \"$password\";\n\n\$template=\"[headline]<hr>[body]<hr>[date] :: [time] :: [author] :: [comments]\";\n\n\$blogurl=\"blogindex.htm\";\n\$blognum=8;\n\n?>";
$fp = fopen("settings.txt", "w");
fwrite($fp,$text);
fclose($fp);

$fp = fopen("blogindex.htm", "w");
fwrite($fp,"<html>\n<h1><i>i</i>blogger</h1>\n<!--#iBlogStart#-->\n<!--#iBlogEnd#-->\n</html>");
fclose($fp);

print<<<END
<div align="center"><br>
<i><b>Step 4:</b></i>
<br>
Creating default blog page and template...<font color="#006600">done</font>
<br>
<a href="blog.php">Installation Complete!!</a>
</div>
END;
}
?>

</td>
</tr>
</table>
</body>
</html>
