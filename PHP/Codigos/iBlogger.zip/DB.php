<?php
////////////////////////////////////////////////////////////////
////////////////////////////////(c)oded by Arnab Nandi//////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//////////////////////***//**///////////////////////////////////
//////////////////////***//**///////////////////////////////////
///////////////////////////**///////////////////////////////////
//////////////////////***//**///////////////////////////////////
//////////////////////***//**///////////////////////////////////
//////////////////////***//******///////////////////////////////
//////////////////////***//**///*///////////////////////////////
//////////////////////***//******///////////////////////////////
//////////////////////iBlogger v1///////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//All of This code is (c) Iota Innomedia - Do NOT edit it...////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
// db class for mysql
// this class is used in all scripts
// do NOT fiddle unless you know what you are doing

class DB{
  var $database = "";

  var $link_id  = 0;
  var $query_id = 0;
  var $record   = array();

  var $errdesc    = "";
  var $errno   = 0;
  var $reporterror = 1;

  var $server   = "localhost";
  var $user     = "root";
  var $password = "";
  var $technicalemail ="";
  var $name ="iBlogger";
  
  function connect() {
    // connect to db server

    if ( 0 == $this->link_id ) {
      if ($this->password=="") {
        $this->link_id=mysql_connect($this->server,$this->user);
      } else {
        $this->link_id=mysql_connect($this->server,$this->user,$this->password);
      }
      if (!$this->link_id) {
        $this->halt("Link-ID == false, connect failed");
      }
      if ($this->database!="") {
        if(!mysql_select_db($this->database, $this->link_id)) {
          $this->halt("cannot use database ".$this->database);
        }
      }
    }
  }

  function geterrdesc() {
    $this->error=mysql_error();
    return $this->error;
  }

  function geterrno() {
    $this->errno=mysql_errno();
    return $this->errno;
  }

  function select_db($database="") {
    // select database
    if ($database!="") {
      $this->database=$database;
    }

    if(!mysql_select_db($this->database, $this->link_id)) {
      $this->halt("cannot use database ".$this->database);
    }

  }

  function query($query_string) {
    // do query

    $this->query_id = mysql_query($query_string,$this->link_id);
    if (!$this->query_id) {
      $this->halt("Invalid SQL: ".$query_string);
    }

    return $this->query_id;
  }

  function fetch_array($query_id=-1) {
    // retrieve row
    if ($query_id!=-1) {
      $this->query_id=$query_id;
    }
    $this->record = mysql_fetch_array($this->query_id);

    return $this->record;
  }

  function free_result($query_id=-1) {
    // retrieve row
    if ($query_id!=-1) {
      $this->query_id=$query_id;
    }
    return @mysql_free_result($this->query_id);
  }

  function query_first($query_string) {
    // does a query and returns first row
    $this->query($query_string);
    $returnarray=$this->fetch_array($this->query_id);
    $this->free_result($this->$query_id);
    return $returnarray;
  }

  function data_seek($pos,$query_id=-1) {
    // goes to row $pos
    if ($query_id!=-1) {
      $this->query_id=$query_id;
    }
    $status = mysql_data_seek($this->query_id, $pos);
    return $status;
  }

  function num_rows($query_id=-1) {
    // returns number of rows in query
    if ($query_id!=-1) {
      $this->query_id=$query_id;
    }
    return mysql_num_rows($this->query_id);
  }

  function insert_id() {
    // returns last auto_increment field number assigned

    return mysql_insert_id($this->link_id);

  }

  function halt($msg) {
    $this->errdesc=mysql_error();
    $this->errno=mysql_errno();
    // prints warning message when there is an error
    
    $message="Database error in $this->name: $msg\n";
    $message.="mysql error: $this->errdesc\n";
    $message.="mysql error number: $this->errno\n";
    $message.="Date: ".date("l dS of F Y h:i:s A")."\n";
    $message.="Script: ".getenv("REQUEST_URI")."\n";
    $message.="Referer: ".getenv("HTTP_REFERER")."\n";

//    mail ($technicalemail,"$this->name Database error!",$message);

    if ($this->reporterror==1) {
      echo "\n<!-- $message -->\n";

      echo "</td></tr></table>\n<p>There seems to have been a slight problem with the database.\n";
      echo "Please try again by pressing the refresh button in your browser.</p>";
      echo "An E-Mail has been dispatched to our <a href=\"mailto:$technicalemail\">Technical Staff</a>, who you can also contact if the problem persists.</p>";
      echo "<p>We apologise for any inconvenience.</p>";
      die("");
    }
  }
}
?>