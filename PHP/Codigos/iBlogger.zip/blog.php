<?
////////////////////////////////////////////////////////////////
////////////////////////////////(c)oded by Arnab Nandi//////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//////////////////////***//**///////////////////////////////////
//////////////////////***//**///////////////////////////////////
///////////////////////////**///////////////////////////////////
//////////////////////***//**///////////////////////////////////
//////////////////////***//**///////////////////////////////////
//////////////////////***//******///////////////////////////////
//////////////////////***//**///*///////////////////////////////
//////////////////////***//******///////////////////////////////
//////////////////////iBlogger v1///////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//All of This code is (c) Iota Innomedia - Do NOT edit it...////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

// load db class
  $dbclassname="DB.php";
  include($dbclassname);
  include("settings.txt");

//Connect to the Database
  $DBase=new DB;

  // initialise vars
  $DBase->name=$blogname;
  $DBase->database=$dbname;
  $DBase->server=$servername;
  $DBase->user=$username;
  $DBase->password=$password;

  // allow this script to catch errors
  $DBase->reporterror=0;

  $DBase->connect();
  // end init db


?>


<html>
<head>
<title>iBlogger</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF">
<font color="#FF0000"><i><font size="7" color="#6633FF">i</font></i></font><font size="7">blogger</font><br>
 
<a href="blog.php?action=post">post</a> | <a href="blog.php?action=edit">edit</a> | <a href="blog.php?action=config">config</a>  | <a href="blog.php?action=users">users</a> | <a href="blog.php?action=admin">admin</a>
| <a href="blog.php?action=delete">delete</a> | <a href="blog.php?action=regenerate">regenerate</a> | <a href="<?=$blogurl?>">The Blog</a>

<hr>

<?
if ($action == "post") 

{

if ($headline!="")
{
if (checkauth("pe")==0)
{

//add slashes...
$headline2=addslashes($headline);
$body2=htmlspecialchars($body);

//strip slashes
$headline=stripslashes($headline);
$body=stripslashes($body);

//if posted once, generate preview and dopost button...
$date= gmdate ("M d y",time());
$time= gmdate ("H:i",time());
$code=$template;
$code=str_replace("[headline]",$headline,$code);
$code=str_replace("[body]",$body,$code);
$code=str_replace("[blogno]",1,$code);
$code=str_replace("[date]",$date,$code);
$code=str_replace("[time]",$time,$code);
$code=str_replace("[author]","$ibname",$code);
$code=str_replace("[comments]","<a href=\"#\">post comments</a>",$code);

$code="<br><i>preview</i><table bgcolor=\"#FFFFDD\" width=\"100%\"><tr><td><table>$code</table></td></tr></table>";
$code=<<<END
<form method="post" action="blog.php">
<input type="hidden" name="action" value="dopost">
<input type="hidden" name="headline" value="$headline2">
<input type="hidden" name="body" value="$body2">
<input type="hidden" name="ibname" value="$ibname">
<input type="hidden" name="ibpw" value="$ibpw">
$code
<div align="right"><input type="submit" value="Publish" name="submit"></div>
</form>
<i>not satisfied? edit further..., then click submit again...</i>
END;
}

else $code="<hr><b><i>Invalid username/password</i></b><hr>";

}  

//get list of users...
$users=$DBase->query("SELECT * FROM iblogusers");

do
  {
   $user=$DBase->fetch_array($users);
   $ulist.="<option>$user[username]</option>";
  }while($user);


print <<<END
<script language="JavaScript">
<!--


function MM_findObj(n, d) { //v3.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document); return x;
}

function MM_validateForm() { //v3.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\\n';
      } else if (test!='R') { num = parseFloat(val);
        if (val!=''+num) errors+='- '+nm+' must contain a number.\\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\\n'; }
  } if (errors) alert('The following error(s) occurred:\\n'+errors);
  document.MM_returnValue = (errors == '');
}


//-->
</script>

<h3>POST BLOG</h3>
<table width="700" border="0" cellspacing="0" cellpadding="0" align="center">
<tr>
<td width="50%" bgcolor="#CCCCCC">
$code
<form method="post" action="blog.php" onSubmit="MM_validateForm('ibpw','','R','headline','','R','body','','R');return document.MM_returnValue" name="frm">
<input type="hidden" name="action" value="post">

<p><font size="2"><i>author:</i>
</font>
<select name="ibname" value="$ibname">
$ulist
</select>
 || <i><font size="2">password:</font></i>
<input type="password" name="ibpw" value="$ibpw">
<p><font size="2"><i>head:</i>
<br>
<input type="text" name="headline" width="30" value="$headline">
<p><i><font size="2">blogpost:</font></i><br>
<textarea name="body" cols="50" rows="8">$body</textarea>
</p>
<p>
<input type="submit" name="Submit" value="Submit">
</p>
</form>
</td>
<td width="5"">&nbsp;</td>
<td valign="top" width="50%" bgcolor="#CCCCCC"><i>Message from the admin:
</i><br>$message</td>
</tr>
</table>
END;

}
?>
<?
if ($action == "dopost")
{

//strip slashes...
$headline=stripslashes($headline);
$body=stripslashes($body);

 if(checkauth("pe")==0)
{$time=time();

$max=$DBase->query("SELECT MAX(blogid) from iblogs");
$max=$DBase->fetch_array($max);

$blogid=$max[0]+1;
$body=nl2br($body);

$headline=htmlspecialchars($headline);

$DBase->query("INSERT INTO iblogs VALUES($blogid,\"$headline\",\"$body\",$time,0,\"$ibname\")");

//regenerate HTML....
regenerate();

 print "<h3>POSTED BLOG</h3><br><br><a href=\"$blogurl\">Go to Blog...</a>";
 }
  else print"<hr><b><i>Invalid username/password</i></b><hr>";
 
 

}

?>

<?
if ($action == "edit") {

print "<h3>EDIT BLOG</h3>";

if ($num!=""&&$action2=="doedit")
{
$blog=$DBase->query("SELECT * FROM iblogs WHERE blogid=$num");
$blog=$DBase->fetch_array($blog); 

if ($blog == "") print "<hr><b><i>Sorry, blog not found</i></b><hr>";

else {
	if (($blog[author]==$ibname&&checkauth("pe")==0)||(checkauth("ue")==0))
	{
	 $DBase->query("UPDATE iblogs SET title =\"$headline\" WHERE blogid=$num");
	 $DBase->query("UPDATE iblogs SET btext =\"$body\" WHERE blogid=$num");
	regenerate();
	print "<hr><b><i>Blog Updated</i></b><hr>";
	}
	
	else print "<hr><b><i>Invalid username/password</i></b><hr>";
	
     }
}

if (($num!="")&&($action2=="edit"))
{

$blog=$DBase->query("SELECT * FROM iblogs WHERE blogid=$num");
$blog=$DBase->fetch_array($blog); 

if ($blog == "") print "<hr><b><i>Sorry, blog not found</i></b><hr>";

else {
	if (($blog[author]==$ibname&&checkauth("pe")==0)||(checkauth("ue")==0))
	{
	
	print<<<END
	<form method="post" action="blog.php" name="frm">
	<input type="hidden" name="action" value="edit">
	<input type="hidden" name="num" value="$num">
	<input type="hidden" name="action2" value="doedit">
	
	<p><font size="2"><i>author:</i>
	</font>
	<input type="text" name="ibname" value="$ibname">
	 || <i><font size="2">password:</font></i>
	<input type="password" name="ibpw" >
	<p><font size="2"><i>head:</i>
	<br>
	<input type="text" name="headline" width="30" value="$blog[title]">
	<p><i><font size="2">blogpost:</font></i><br>
	<textarea name="body" cols="50" rows="8">$blog[btext]</textarea>
	</p>
	<p>
	<input type="submit" name="Submit" value="Edit the Blog">
	</p>
</form>
END;
	
	}
	else print "<hr><b><i>Invalid username/password</i></b><hr>";
     }
}




print<<<END
<hr>
<form name="form" method="GET" action="blog.php">
<br>
username:
<input type="hidden" name="action" value="edit">
<input type="hidden" name="action2" value="edit">
<input type="text" name="ibname">
<br>
password:
<input type="password" name="ibpw">
<br>
<br>
blog id: <input type="text" name="num" size="2">
<br>
<div align="center">
<input type="submit" name="Submit" value="Edit post">
</div>
<br>
</form>

END
;	

}
?>

<?
if ($action == "delete") 
{
print "<h3>DELETE POSTS</h3>";

if ($num!="") {
		if(checkauth("dp")==0)		
		{
		$DBase->query("DELETE from iblogs where blogid= $num");
		print"<b><i>The post has been deleted</i></b><p>";
		}
		else print"<b><i>Invalid username/password</i></b><p>";
		}

print<<<END
<form name="form" method="post" action="blog.php">
<br>
username:
<input type="hidden" name="action" value="delete">
<input type="text" name="ibname">
<br>
password:
<input type="password" name="ibpw">
<br>
<br>
blog id: <input type="text" name="num" size="2">
<br>
<div align="center">
<input type="submit" name="Submit" value="Delete post">
</div>
<br>
</form>

END
;	

}

?>





<?
if ($action == "admin")
{

//edit permissons, if action2 is deluser...
if ($action2=="deluser")
{
if (checkauth("du")==0) {
			
			$DBase->query("DELETE from iblogusers WHERE userid=$userid AND username=\"$username2\"");
			
			$code="<b><i>User $choice deleted</i></b><p>";			
			}
			
else $code="<b><i>Invalid username/password</i></b><p>";			
}


//edit permissons, if action2 is update...
if ($action2=="update")
{
if (checkauth("du")==0) {
			$perm="$pe[$choice]$ue[$choice]$du[$choice]$dp[$choice]$cf[$choice]";
			$DBase->query("UPDATE iblogusers SET perm =\"$perm\" WHERE userid=$choice");
			
			$code="<b><i>User $choice updated</i></b><p>";			
			}
			
else $code="<b><i>Invalid username/password</i></b><p>";			
}

///Add user.....
	if ($action2=="adduser")
	  {
		if (checkauth("du")==0)
		{
		$max=$DBase->query("SELECT MAX(userid) from iblogusers");
		$max=$DBase->fetch_array($max);

		$userid=$max[0]+1;
		
		$DBase->query("INSERT INTO iblogusers VALUES($userid,\"$username2\",\"$password2\",\"\",\"please enter you desc. here\",\"pe\")");

		$code="<b><i>User \"$username2\" has been added</i></b><p>";
		}

		else $code="<b><i>Invalid username/password</i></b><p>";
	  }

//get list of users...
	$users=$DBase->query("SELECT * FROM iblogusers ORDER BY userid");
	$urec=$DBase->fetch_array($users);
	do
	  {
//make the tru false thingies...
if (eregi("pe", $urec[perm])) $pe="checked";else $pe=""; 
if (eregi("ue", $urec[perm])) $ue="checked";else $ue="";	
if (eregi("du", $urec[perm])) $du="checked";else $du="";
if (eregi("dp", $urec[perm])) $dp="checked";else $dp="";
if (eregi("cf", $urec[perm])) $cf="checked";else $cf="";

	     	     
$code.=<<<END
<tr>
<td bgcolor="#CCCCCC"><input type ="radio" name="choice" value="$urec[userid]"> 
$urec[userid]. $urec[username] </td>
<td colspan="2" align="center" bgcolor="#999999">
<input type="checkbox" name="pe[$urec[userid]]" value="pe" $pe>
</td>
<td align="center" bgcolor="#CCCCCC">
<input type="checkbox" name="ue[$urec[userid]]" value="ue" $ue>
</td>
<td align="center" bgcolor="#999999">
<input type="checkbox" name="du[$urec[userid]]" value="du" $du>
</td>
<td align="center" bgcolor="#CCCCCC">
<input type="checkbox" name="dp[$urec[userid]]" value="dp" $dp>
</td>
<td align="center" bgcolor="#999999">
<input type="checkbox" name="cf[$urec[userid]]" value="cf" $cf>
</td>
</tr>     
END;
	     
	     
	     $urec=$DBase->fetch_array($users);
	  }while($urec);

print<<<END

<h3>ADD/EDIT USERS</h3>
<hr>

<form method="post" action="blog.php">
<table width="600" border="0" cellspacing="2" cellpadding="2" align="center" bgcolor="#FFFFFF">
<tr bgcolor="#FFFFFF">
<td><b><i>User List</i></b></td>
<td colspan="2" align="center" bgcolor="#CCCCCC"><b><font face="Verdana, Arial, Helvetica, sans-serif"><i><font size="1">
post/edit
</font></i></font></b></td>
<td align="center" bgcolor="#999999"><b><font face="Verdana, Arial, Helvetica, sans-serif"><i><font size="1">
univedit
</font></i></font></b></td>
<td align="center" bgcolor="#CCCCCC"><b><font face="Verdana, Arial, Helvetica, sans-serif"><i><font size="1">
deluser
</font></i></font></b></td>
<td align="center" bgcolor="#999999"><b><font face="Verdana, Arial, Helvetica, sans-serif"><i><font size="1">
delpost
</font></i></font></b></td>
<td align="center" bgcolor="#CCCCCC"><b><font face="Verdana, Arial, Helvetica, sans-serif"><i><font size="1">
cfg
</font></i></font></b></td>
</tr>

$code

<tr>
<td colspan="7" nowrap>
adminuser:
<input type="text" name="ibname">
<input type="hidden" name="action" value="admin">
<input type="hidden" name="action2" value="update">
adminpass:
<input type="password" name="ibpw">
<input type="submit" name="Submit" value="Update Selected">
</td>
</tr>
</table>
</form>

<hr>
<table width="100%">
<tr>

<td>
<br>
<form name="form" method="post" action="blog.php">
<table bgcolor="#999999" width="100%" align="center">
<tr><td>
<b><i>Add users...</i></b><p>
new username:
<input type="hidden" name="action" value="admin">
<input type="hidden" name="action2" value="adduser">
<input type="text" name="username2">
<br>
new user's password:
<input type="password" name="password2">
<br>
<br>
<div align="right">
<br>
yourusername:<input type="text" name="ibname">
<br>yourpassword:<input type="password" name="ibpw">
<br>

<input type="submit" name="Submit" value="Add User">
</div>
<br>
</td></tr>
</table>
</form>
</td>

<td>

<br>
<form name="form" method="post" action="blog.php">
<table bgcolor="#999999" width="100%" align="center">
<tr><td>
<b><i>Delete users...</i></b><p>
deleted username:
<input type="hidden" name="action" value="admin">
<input type="hidden" name="action2" value="deluser">
<input type="text" name="username2">
<br>
deleted user's userid:
<input type="text" name="userid" size="2">
<br>
<br>
<div align="right">
<br>
yourusername:<input type="text" name="ibname">
<br>yourpassword:<input type="password" name="ibpw">
<br>

<input type="submit" name="Submit" value="Delete User">
</div>
<br>
</td></tr>
</table>
</form>

</td>
</tr>
</table>

END;

}

?>




<?
if ($action == "config"){

if($action2=="update")
{
if (checkauth("cf")==0){

//save settings in settings.txt...
$settings="<?\n#iBlogger Settings\n\$blogname= \"$blogname\";\n\$dbname= \"$dbname\";\n\$servername= \"$servername\";\n\$username= \"$username\";\n\$password= \"$password\";\n\$template=<<<END_OF_HTML\n$tp\nEND_OF_HTML;\n\n\$blogurl= \"$bu\";\n\$blognum= \"$bn\";\n\n?>";
$fp = fopen("settings.txt", "w");
fwrite($fp,$settings);
fclose($fp);

		print "<hr><b><i>Settings Saved</i></b><hr>";
		}
else print "<hr><b><i>Invalid username/password</i></b><hr>";

}

include("settings.txt");
print "<h3>CONFIGURE BLOG SETTINGS</h3>";	
print <<<END
<table width="600"><tr><td>
<b><i>Present Config:</i></b>
<br>
<form action="blog.php" method="post">
<input type="hidden" value="config" name="action">
<input type="hidden" value="update" name="action2">
Location of Blog:<br>
<input type="text" value="$blogurl" name="bu">
<p>
Number of blogs per page:<br>
<input type="text" value="$blognum" name="bn" size="2">
<p>

Template:<br>
<textarea name="tp" rows="6" cols="40">$template</textarea><br><br>
username:<br>
<input type="text" value="$ibname" name="ibname">
<br>
password<br>
<input type="password" name="ibpw">
<p>

<input type="submit" name="Submit" value="Update settings...">
</form>
</td>
<td width="20">&nbsp;</td>
<td valign="top" bgcolor="#CCCCCC">
Variables:<hr>
<br>[blogno]
<br>[comno]
<br>[headline]
<br>[body]
<br>[comments]
<br>[author]
<br>[date]
<br>[time]
</td></tr></table>
END;

}



?>



<?
if ($action == "users") {


//update..
if($action2=="update")
{
 $temp=$ibname;
 $ibname=$uname;
 
 if(checkauth("e")==0)
 {
addslashes($email);
addslashes($desc);
   $DBase->query("UPDATE iblogusers SET username='$temp' WHERE userid=$uid");
   $DBase->query("UPDATE iblogusers SET email='$tptemail' WHERE userid=$uid");
   $DBase->query("UPDATE iblogusers SET descr='$desc' WHERE userid=$uid");
   if ($newpassword!="")
   $DBase->query("UPDATE iblogusers SET password='$newpassword' WHERE userid=$uid");
   
 $prompt="<hr><b><i>User $uid info updated</i></b><hr>";
 }
 else $prompt="<hr><b><i>Invalid username/password</i></b><hr>";

$uname=$temp;
}



//get list of users...
$users=$DBase->query("SELECT * FROM iblogusers");

do
  {
   $user=$DBase->fetch_array($users);
   $ulist.="<p>$user[userid]. <a href=\"blog.php?action=users&uname=$user[username]&uid=$user[userid]\">$user[username]</a>";
  }while($user);



if ($uname != "")
{

//get info...
$users=$DBase->query("SELECT * FROM iblogusers WHERE username=\"$uname\" AND userid=$uid");
$user=$DBase->fetch_array($users);


$code=<<<END
<br>
<form name="form" method="get" action="blog.php">
<table bgcolor="#999999" width="100%" align="center">
<tr><td>
<b><i>Edit userdetails for "$uname"...</i></b><p>
username:
<input type="hidden" name="action" value="users">
<input type="hidden" name="uid" value="$user[userid]">
<input type="hidden" name="uname" value="$user[username]">
<input type="hidden" name="action2" value="update">
<input type="text" name="ibname" value="$user[username]">

<br><br>
password:
<input type="password" name="ibpw">
<br><br>
new password:<i>(leave blank if you want to keep it same)</i>
<input type="password" name="newpassword">
<br><br>email:
<input type="text" name="tptemail" value="$user[email]">
<br><br>
description:
<textarea name="desc" rows=5>$user[descr]</textarea>
<p><i>permissions:$user[perm]
<p><input type="submit" name="Submit" value="Update the info...">
<br>


<br>
</td></tr>
</table>
</form>
END;
}


print <<<END
<h3>CHANGE USER DETAILS</h3>
$prompt
<table width="500" align="center">
<tr><td width="50%" valign="top"><i>Select a user...</b></i><p><p>$ulist</td>
<td width="50%" valign="top">$code</td></tr></table>
END;

}

if ($action == "regenerate") {regenerate();print "<h3>BLOG REGENERATED</h3>";}
?>
<?
//functions.....

function checkauth($pm)
{
global $DBase;
global $ibname;
global $ibpw;

$urec=$DBase->query("SELECT * FROM iblogusers WHERE username = \"$ibname\"");
$urec=$DBase->fetch_array($urec);

if ($ibpw==$urec[password]&&$ibpw!=""&&eregi($pm, $urec[perm])) return 0;
else return 1;
}


function regenerate()
{

global $DBase;
global $blogurl;
global $blognum;
global $template;
// make the blog posts...
$blogs=$DBase->query("SELECT * FROM iblogs ORDER BY posttime DESC");

$lines=file($blogurl);
$c=0;
$fcode.="$lines[$c]";
while($lines[$c++])
{
   
   $fcode.="$lines[$c]";
   if ($lines[$c]=="<!--#iBlogStart#-->\n")
    {
     $blog=$DBase->fetch_array($blogs);
     
     for ($i=0;($i<$blognum)&&($blog);$i++)
     	{
     	
     	
     	$date= gmdate ("M d y",$blog[posttime]);
     	$time= gmdate ("H:i",$blog[posttime]);
     	$code=$template;
     	$code=str_replace("[headline]",$blog[title],$code);
     	$code=str_replace("[body]",$blog[btext],$code);
     	$code=str_replace("[blogno]",$blog[blogid],$code);
     	$code=str_replace("[comno]",$blog[comments],$code);
     	$code=str_replace("[date]",$date,$code);
     	$code=str_replace("[time]",$time,$code);
     	$code=str_replace("[author]",$blog[author],$code);
     	if ($blog[comments]==0) $code=str_replace("[comments]","<a href=\"comments.php?id=$blog[blogid]\">post comments</a>",$code);
     	else  $code=str_replace("[comments]","<a href=\"comments.php?id=$blog[blogid]\">$blog[comments] comments</a>",$code);
     	
        $fcode.="$code\n";
        
        $blog=$DBase->fetch_array($blogs);
        }
     
     while($lines[$c++]!="<!--#iBlogEnd#-->\n");
     $d=$c-1;
     $fcode.="$lines[$d]";
     $fcode.="$lines[$c]";
     
     
    } 
   
   
}
$fp = fopen($blogurl, "w");
fwrite($fp,$fcode);
fclose($fp);

 
}

?>

<br> <br> <br> <hr>
iblogger is a product of iota innomedia. it is free for non commercial use and comes with no liabilities.
</body>
</html>
