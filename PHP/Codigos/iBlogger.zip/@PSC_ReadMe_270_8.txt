Title: iBlogger - News Posting Backend
Description: iBlogger is this extremely fast, slim, lightweight web journal/log/news posting system.
It uses mySQL and has a very simple intuitive interface...(see below).
Installing is a cinch. just upload and view install.php from your browser...and the wizard will install everything!!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=270&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
