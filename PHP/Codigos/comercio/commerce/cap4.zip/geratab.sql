# Gera��o da Base (Banco fish)
# Para o MySQL

DROP TABLE operador;

CREATE TABLE operador (
  cpfOperador char(11) not null,
  priNome varchar(30) not null,
  ultNome varchar(30) not null,
  desSenha varchar(16) not null,
  numNota int,
  nivel char(1) default 'V',
  PRIMARY KEY (cpfOperador)
);

INSERT INTO operador VALUES('11111111111','Gerente','Dono',PASSWORD('fish'),999999999,'A');
INSERT INTO operador VALUES('22222222222','Vendedor','Funcion�rio',PASSWORD('venda'),999999999,'V');

DROP TABLE cliente;

CREATE TABLE cliente (
  cpfCliente char(11) not null,
  priNome varchar(30) not null,
  ultNome varchar(30) not null,
  desEndereco text not null,
  desTelefone varchar(15),
  emaCliente varchar(80),
  PRIMARY KEY (cpfCliente)
);

DROP TABLE produto;

CREATE TABLE produto (
  nidProduto char(6) not null,
  nomProduto varchar(80) not null,
  obsProduto text not null,
  desImagem varchar(80),
  valPreco double(12,2),
  perDesconto int(2),
  ligOferta char(1) default 'N',
  PRIMARY KEY (nidProduto)
);

INSERT INTO produto VALUES('PD0001','Peixe-borboleta','Peixe com tam de 6 cm prefere �gua com pH 7,0 a 6,8 para aqu�rios m�dio a grande bem plantado se alimentando de Larvas de inseto, aceita bem flocos','gp01.jpg',1.50,0, 'N');
INSERT INTO produto VALUES('PD0002','Borboleta m�rmore','Peixe com tam de 4,5 cm prefere �gua com pH 7,0 a 6,8 para aqu�rios m�dio a grande bem plantado se alimentando de Larvas de inseto, aceita bem flocos','gp02.jpg',4.00,1, 'N');
INSERT INTO produto VALUES('PD0003','Acar�','Peixe com tam de 25 cm para aqu�rios grandes se alimentando de Alimentos vivos,pat�s, aceita ra��o - on�voro(prefere vegeta��o)','gp03.jpg',6.80,0, 'N');
INSERT INTO produto VALUES('PD0004','Tetra-imperador','Peixe com tam de 6 cm prefere �gua com pH 7,0 a 6,8 para aqu�rios m�dio a grande bem plantado se alimentando de flocos (on�voro)','gp04.jpg',1.50,0, 'N');
INSERT INTO produto VALUES('PD0005','Peixe-do-para�so','Peixe com tam de 10 cm prefere �gua com pH 6,8 a 7,2 para aqu�rios m�dio se alimentando de flocos','gp05.jpg',3.50,0, 'N');
INSERT INTO produto VALUES('PD0006','Abelhinha','Peixe com tam de 4 cm prefere �gua com pH 7,0 para aqu�rios M�dio com tocas se alimentando somente de alimentos vivos, n�o aceita flocos','gp06.jpg',5.00,0, 'N');
INSERT INTO produto VALUES('PD0007','Peixe borboleta africano','Peixe com tam de 12 cm prefere �gua com pH 7,0 a 6,8 para aqu�rios m�dio a grande bem plantado se alimentando de Larvas de inseto, aceita bem flocos','gp07.jpg',1.40,0, 'N');
INSERT INTO produto VALUES('PD0008','Disco','Peixe com tam de 15 cm prefere �gua com pH 6,6 a 7,0 para aqu�rios m�dio a grande bem plantado','gp08.jpg',15.00,3, 'S');
INSERT INTO produto VALUES('PD0009','Barbo tigre','Peixe com tam de 7 cm prefere �gua com pH 7,0 a 6,8 para aqu�rios m�dio a grande bem plantado se alimentando de Larvas de inseto, aceita bem flocos (on�voro)','gp09.jpg',1.20,0, 'N');
INSERT INTO produto VALUES('PD0010','Espada','Peixe com tam de 12 cm prefere �gua com pH 7,0 a 7,5 para aqu�rios m�dio a grande bem plantado on�voro','gp10.jpg',1.00,0, 'N');

DROP TABLE nota;

CREATE TABLE nota (
  numNota int not null AUTO_INCREMENT,
  datCompra date,
  cpfOperador char(11) not null,
  prcTotVenda double(16,2),
  PRIMARY KEY (numNota)
);

DROP TABLE movimento;

CREATE TABLE movimento (
  numNota int not null,
  nidItem int(3) not null,
  nidProduto char(6) not null,
  prcUnitario double(12,2),
  qtdVendida int(4) default '1',
  PRIMARY KEY (numNota, nidItem)
);

DROP TABLE guestbook;

CREATE TABLE guestbook (
  nidBook int not null AUTO_INCREMENT,
  nomBook varchar(80),
  email varchar(100),
  funcao varchar(80),
  obsBook text,
  PRIMARY KEY(nidBook)
);