<?PHP
ob_start("ob_gzhandler");
//start the signing script
	require ("config.php"); //to get the information for switch and swapping
	global $install; //so you can use the form you filled out before
//this function will email you if you want it to. You change that in the administration form. 
function send_notification() {
	require ("config.php");
	global $install;
	//this next part sends the actual mail
	mail($install[email], 'Your guestbook has been signed', 'Your guestbook has been signed. To discontiune getting these messages simply remove your email from the configuration page.');
}

//Checks to see if you have a  header or just a body tag information. 
//Swank.. eh?
	if ("$install[header]") {
		include("$install[header]");
	} else {
		echo "<html>\n";
		echo "<head>\n";
		echo "<title>The Guestbook, powered by ZS G-Book</title>\n";
		echo "</head>\n";
		echo "<style type=\"text/css\">\n";
		echo "\t input, text, textarea {border: solid, 2px black; color: white; background; white; }\n";
		echo "</style>\n";
		echo '<body bgcolor="' . $install[background] .'" link="' . $install[link] . '" text="' . $install[text] . '" alink="' . $install[alink] . '" vlink="'.  $install[vlink] . '">';
	}

//this function is suppost to log ip address and times but sometimes it doesnt.
	function log_ip () {
		require ("config.php");
		global $install;
		if($install[logip] == "1"){
			$time = date("l F dS h:i:s A Y");
			$ipaddress = "iplog.txt";
			$do = fopen($ipaddress, 'a+');
			$entrthis = "$REMOTE_ADDR | $time \n";
			fputs($do, "$enterthis");
        		fclose($do);
		}
	}
	
//i know all these off hand... it's a shame eh?
//added in 2.6
function badwords($change){
	require("config.php");
	global $install;
	if ($install[badwords] == "on"){ // if you have selected to turn o swear filtering... do the following
		$change = str_replace('fuck '," fark! ",$change);
		$change = str_replace('shit '," poopy ",$change);
		$change = str_replace('cunt '," vagina ",$change);
		$change = str_replace('bitch '," beeeeeyatch ",$change);
		$change = str_replace('damn '," darn ",$change);
		$change = str_replace('dick '," penis ",$change);
		$change = str_replace('titties '," brest ",$change);
		$change = str_replace('pussy '," vagina ",$change);
		$change = str_replace('twat  '," vagina ",$change);
		$change = str_replace('ass '," buttock ",$change);
		$change = str_replace('fucking '," farking ",$change);
		$change = str_replace('bitches '," byatches ",$change);
		$change = str_replace('shitty '," poopy ",$change);
		$change = str_replace('cooter '," vagina ",$change);
		$change = str_replace('kooter '," vagina ",$change);
		$change = str_replace('chink '," foreign person ",$change);
		$change = str_replace('chinker '," foreign person ",$change);
		$change = str_replace('dot head '," foreign person ",$change);
		$change = str_replace('jewbag '," foreign person ",$change);	
		$change = str_replace('coons '," racoons ",$change);	
		$change = str_replace('koons '," racoons ",$change);
		$change = str_replace('niggers '," foreign person ",$change);	
		$change = str_replace('towel head '," foreign person ",$change);
		$change = str_replace('spook '," spooky ",$change);	
		$change = str_replace('slut '," dirty girl ",$change);	
		return $change; //make the output of ths function, the entry, minus the words above
	} else {
		return $change; // if you dont have swear filter turned on, just output the entry
	}
}
		
//the next part (function) displays all the forms users can fill out. 
	function display_forms(){
		require("config.php");
		global $install;
		echo 'A bold "*" indicates a required feild<br>';
		echo '<form action="guestbook-sign.php?act=signer" method="POST">';
		echo "<b>*</b><input type=text name=yourname size=30> &lt--- Your name<br>\n";
		if ($install[feild_email] == on){
			echo "&nbsp; <input type=text name=youremail size=30> &lt --- Your email address<br>\n";
		} 
		if ($install[feild_home] == on){
			echo "&nbsp; <input type=text name=home value=\"http://\" size=30> &lt --- Your homepage<br>\n";
		} 
		if ($install[feild_icq] == on) {
			echo "&nbsp; <input type=text name=icq size=30> &lt --- Your ICQ number<br>\n";
		}
		if ($install[feild_aim] == on){
			echo "&nbsp; <input type=text name=aim size=30> &lt --- Your AIM name<br>\n";
		}
		echo "<b>*</b>&nbsp; Your entry<br>\n";
		echo "<textarea name='entry' style='height:100px; width:90%;'></textarea><br>\n";
		echo "<p align='center'><input type='submit' value='Add entry'> &nbsp; <input type='reset' value='Clear it'></p>\n";
		echo "</form>\n";
	}
	
	//this next huge-ass switch function is the navagation part of the file so that it isnt in 14
	//different 1kb files strewn about. Thanks go to Rick for helping me with that.
	switch($act) {
	//these are the beginning page options. guestbook-sign.php
		default:
			echo "Please choose an option<br>\n";
			echo "-�- <a href='guestbook-sign.php?act=sign'>Sign the guestbook.</a><br>\n";
			echo "-�- <a href='guestbook-sign.php?act=view'>View the current entries</a>\n";
			break;
	//this is what shows up when a person click on sign. guestbook-sign.php?act=sign
		case "sign":
			echo"<center><small>� <a href='guestbook-sign.php?act=view'>View the current entries</a> �</small></center><br>\n";
			//this will display the forms above
				display_forms();
		break;
	//when a person goes to guestbook-sign.php?act=view this is what happens. 
		case "view":
			echo "<center><small>� <a href=\"guestbook-sign.php?act=sign\">Sign the Guestbook</a> �</small></center><br>\n";
			if (filesize("entrylog.txt") == "0") { //see if there's any addtions to the entry log file or not
				 echo 'No entries as of yet';
			 } else { 
				 include("entrylog.txt"); // well, since there is a value to the log, we get to show it off!
			}
			break;

	/* sigh, and now for the function that brings this whole project together. :-D
	It took me two months to build up to this function, and about a month to make it
	So,
	You better make good use of it. */

		case "signer":
			ob_start(); //this lets me do the code below and still set a cookie, cool eh?
		if($dontspamme){
			echo 'No spam please, try signing again later.';
		} else {
		setcookie("dontspamme", "on", time() + 60);
		//check to see if the required forms are filled in
			if (($entry == "") || ($yourname == "")) { //see if theres an entry and name is filled in
				echo 'Whoa, hang on there buddy. Try filling in all the required forms next time.';
			} else {
			$zsdate = date("$install[date]"); //get the date
	//remove unwanted HTML
			$aim = strip_tags($aim, "");
			$email = strip_tags($email, "");
			$entry = strip_tags("$entry","<a>,<i>,<img>,<center>,<b>,<s>"); 
			$homepage = strip_tags($homepage, "");
	//get rid of all those pesky back slashes in front of quotes
			$entry = stripslashes($entry);
			$name = stripslashes($yourname);
			$entry = stripslashes($entry);
	//have the message allow line breaks
			$entry = nl2br($entry);
	//Start converting the template into the actual form filled out		
	
	//Check for an ICQ number
				if ($icq) { 
					$install[template] = str_replace("%icq%","<a href=\"http://wwp.icq.com/scripts/contact.dll?msgto=$icq\"><img src=\"http://wwp.icq.com/scripts/online.dll?icq=$icq&img=7\" alt=\"$icq\" border=\"0\"> <small>$icq</small></a> ","$install[template]");
				} else {
					$install[template] = str_replace("%icq%","","$install[template]");
				}
	//Check for AIM name
				if ($aim) { 	
					$install[template] = str_replace("%aim%","<a href=\"aim:goim?screenname=$aim&message=Hi $aim\">Im $aim</a>","$install[template]"); 
				} else {
					$install[template] = str_replace("%aim%","","$install[template]"); 
				}
	//Insert the date
				$install[template] = str_replace("%zsdate%","$zsdate","$install[template]");
	//See if the home page is filled out		
				if ($home) {
					$install[template] = str_replace("%home%","<a href=\"$home\" title=\"home page\">[h]</a>","$install[template]");
				} elseif (($home == "http://") || (!$home)) {
					$install[template] = str_replace("%home%","","$install[template]");
				}
			$install[template] = str_replace("%entry%","$entry","$install[template]");
			$install[template] = str_replace("%name%","<a href=\"mailto:$youremail\">$yourname</a>","$install[template]");
	//This is the file writing 
		//Declare the files
			$file2read="entrylog.txt"; 
			$file2write2="entrylog.txt"; 
		//get the contents of entry log	
			$fp = fopen($file2read,"r"); 
			$fp_contents = fread($fp,filesize($file2read)); 
			fclose($fp); 
		//Add the curent entries to the log and remove bad words if nessicary
			$install[template] .= "$fp_contents";
			$install[template] = badwords($install[template]);
		//Write everything
			$fp2 = fopen($file2write2, "w");
			fwrite($fp2, "$install[template]");
			fclose($fp2); 
	//This sends you the mail notification... or not. Depends on you
			send_notification();
	//If you want, this is suppost to log IP's. But it's iffy sometimes
			log_ip();
			echo 'Guestbook signed successfully. Click <a href="guestbook-sign.php?act=view">here</a> to be taken to your entry!';
		} // end the checking for required crap, if else thing
	}// end the cookie spam setting
		ob_end_flush(); //ends the cookie setting process and starts doing what is actully coded above. cool eh?
			break;
	}
	
	//These check to see if you have a header or just a body tag. It's swank i think. 
	//Didnt even take me a while to do! Thought it up in world history class. No, really I did!
	if ("$install[footer]") {
		echo "<small><center>Get this guestbook script <a href='http://zokosiman.poxy.net/scripts/guestbook/'>here</a><br>\n for free today!</center></small><br>";
		include("$install[footer]");
	} else {
		echo "<small><center>Get this guestbook script <a href='http://zokosiman.poxy.net/scripts/guestbook/'>here</a><br>\n for free today!</center></small>";
		echo '</body>';
		echo '</html>';
	}
// And I'm spent. Well, actully, the scripts just over.
?>