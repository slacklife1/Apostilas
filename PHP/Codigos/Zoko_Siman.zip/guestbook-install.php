<?PHP
$purplemonster= "Tim";
ob_start("ob_gzhandler");
	if ($cookie == "yes" && $varify = $purplemonster){
		setcookie("cookiepassword", $purplemonster, time() +  30240000);
		echo "Your password has been stored in memory for 50 weeks. <a href=\"guestbook-install.php\">Back to Main</a>.";
	} elseif ($cookie == "kill") {
		setcookie ("cookiepassword", "", time() - 3600);
		echo "Your cookie has been killed (unset). Click <a href=\"guestbook-install.php\">here</a> to go back to main.";
	}
//the magic word is...... put your password inside the quotes below. remember it exactly
// because BoB isnt the same as "bob"
?>
<html>
<head>
<title>ZS-Guestbook Administration Script</title>
<style type="text/css">
	A{text-decoration: overline underline; font-weight: bold;  color: red; }
	A:Hover {text-decoration: none; color: red;}
	input, text {color: navy; background: white; border: solid 2px black;}
	A:VISITED {color: red;}
</style>
</head>
<body link="red" text="navy">
<table border="0" bordercolor="white" width="100%">
<tr>
<td><h2>ZS Guestbook Admin Script</h2></td>
<td align="right" valign="middle">PW Save:
<?PHP if ($HTTP_COOKIE_VARS[cookiepassword]) { 
		echo "yes/<a href=\"guestbook-install.php?cookie=kill\">no</a>"; 
	} else {
		echo "no/<a href=\"guestbook-install.php?act=cookie\">yes</a>";
	}
?></td></tr></table>
<center><table border=0 width="90%" style="border: solid 2px red;">
<tr valign="top" align="left">
<td>
<font face="tempus sans itc, Tahoma, Trebuchet ms, comic sans ms, arial">
<?PHP
//note to self, save early, save often ha ha ha
//require the nessicary variables
if(file_exists(config.php)){
require ("config.php");
} 
global $install;

//create the configuration file
	function create_config_file(){
		if(file_exists("config.php")) {
			print ("Error creating configuration file. A file by the name of \"config.php\" already exists i this directory. Move the file or rename it and then try again.");
		} else {
			touch("config.php");//touching a file resets the last modified date to now, if the file doesnt exist it creates it.
			chmod("config.php", 0666); //CHMODing the file to 666 makes it so that we can change it
			print("Configuration file successfully created<br>"); //yeah, ok, duh.
	}
}

//create the ip log and entries files
	function create_entryfile(){
		if(file_exists("entrylog.txt")) {
			print ("Error creating entry log file. A file by the name of \"entrylog.txt\" already exists i this directory. Move the file or rename it and then try again.");
		} else {
			touch("entrylog.txt");
			chmod("entrylog.txt", 0666);
			print("Entry log file created successfully<br>");
	}
}
	
	function create_ip(){
		if(file_exists("iplog.txt")) {
			print ("Error creating ip log file. A file by the name of \"iplog.txt\" already exists i this directory. Move the file or rename it and then try again.");
		} else {
			touch("iplog.txt");
			chmod("iplog.txt", 0666);
			print("IP log file created successfully<br>");
	}
}

	
//this is for the installation part of the script. it adds your configuration
//specks to the configuraton file.

	function add_entry($entry, $type){
		$filename = "config.php"; //define the file name
		$handle = fopen("$filename", "$type"); //open it for writing
		fwrite($handle, "$entry"); //write your shizz to it
		fclose($handle); //close the file. how it knows if somethings open or close, i dont really know.
	}
	
	/* This is your friend
	http://www.php.net/manual/en/function.fread.php */

//this archives and then deletes the old entrys
//Took me a lot longer to make then it should have. Thanks to the guys at the
//DevShed PHP forums for help
		function archive(){
			$count = time(); //get the UNIX epoch
			touch("archive$count.txt"); //create a new file
			chmod("archive$count.txt", 0666); //chmod it
			$file2read="entrylog.txt"; 
			$file2write2="archive$count.txt"; 
			
			$fp = fopen($file2read,"r"); 
			$fp_contents = fread($fp,filesize($file2read)); 
			fclose($fp); 
			
			$openFILE = fopen($file2write2,"a"); 
			fwrite($openFILE,$fp_contents); 
			fclose($openFILE);
			
			$topen = fopen($file2read, "w");
			@fwrite("$topen", "\n"); //this seemed to like to produce a nasty error when i used it, but it worked just fine. so i put an operator cap on it "@"
			fclose($topen);
			echo "Your old entries have been saved to the file \"<b>archive$count.txt</b>\". You can delete this file if you want. It's not nessicary to keep it.";
			clearstatcache();
		}
//save me an arse load of time.
	function zs_write($name, $string) {
		$fp = fopen($name, "a");
		fwrite($fp, "$string");
		fclose($fp);
	}
	
	/*This Big Ass switch statment is for browsing, the default showing part
	is somewhere in the middle, why I didnt put it on top, i dont know..
	Be glad i learned to do this, you may have ended up with about 15 
	little files every where*/
switch($act) {
	case "install":
	if (filesize("config.php") <= "4"){ //stops hacks! added in 2.6 =)
		echo "Use these forms to set up your guestbook <br> \n";
		echo "<HR> \n";
		echo "<form action=\"guestbook-install.php?act=settings\" method=\"post\"> \n";
		echo "<input type=\"text\" name=\"install[logip]\" size=30>Log IP's? Set this to 1 is yes, or 0 if no. They will be logged to \"iplog.txt\"<br>\n";
		echo "<input type=\"text\" name=\"install[email]\" size=30>Notify you via email if your book is signed? Fill this in if yes. Leave it blank if you dont wish to be notified<br>\n";
		echo "<input type=\"text\" name=\"install[header]\" size=30>If your website used a header file set this to the exact address to that file (IE: http://www.yoursite.com/header.txt) Otherwise leave this feild alone<br>\n";
		echo "<input type=\"text\" name=\"install[footer]\" size=30>If your website used a footer file set this to the exact address to that file (IE: http://www.yoursite.com/footer.txt) Otherwise leave this feild alone<br>\n";
		echo "<input type=\"radio\" name=\"install[badwords]\" value=\"on\">Do you want to filter bad words and ethnic slurs, check if so.<br>\n";
		echo "<center><small>\"Just what is a header and footer file?\" you say? <a href=\"guestbook-install.php?act=header\" target=_new> Click here to find out</a></small></center>\n";
		echo "<input type=\"text\" name=\"install[date]\" size=30 value=\"F, dS, g:i:s a\">This is how your date will appear. <a href=\"http://www.php.net/date\" target=_new>read more about the date</a> at PHP's site.<br>\n";
		echo "<h3>Fill these in if you DONT have a header file</h3><br>\n";
		echo "<input type=\"text\" name=\"install[background]\" size=30>Your background color, if hex be sure to add a hash (#) sign<br>\n";
		echo "<input type=\"text\" name=\"install[link]\" size=30>Your link color, if hex be sure to add a hash (#) sign<br>\n";
		echo "<input type=\"text\" name=\"install[text]\" size=30>Your text color, if hex be sure to add a hash (#) sign<br>\n";
		echo "<input type=\"text\" name=\"install[vlink]\" size=30>Your visited link color, if hex be sure to add a hash (#) sign<br>\n";
		echo "<input type=\"text\" name=\"install[alink]\" size=30>Your active link, if hex be sure to add a hash (#) sign<br>\n";
		echo "<b>Which <i>optional feilds</i> would you like to include: \n";
		echo "<blockquote><b>Homepage Feild <input type=\"checkbox\" value=\"on\" checked name=\"install[feild_home]\"><br>\n";
		echo "Email address <input type=\"checkbox\" value=\"on\" checked name=\"install[feild_email]\"><br>\n";
		echo "ICQ <input type=\"checkbox\" value=\"on\" checked name=\"install[feild_icq]\"><br>\n";
		echo "AIM <input type=\"checkbox\" value=\"on\" checked name=\"install[feild_aim]\"></blockquote>\n";
		echo "<b>Use these variables to customize how each entry looks. You must use <u>EXACT</u> HTML for this to work. That means &ltbr&gt's at the end of your template. Pressing the return key will not, I repeat, will not make a new line when this is published.</b>:<br>\n";  
		echo "<blockquote><b>%zsdate%</b> - this is optional, it will make the date appear<br>\n";
		echo "<b>%entry%</b> - this makes the entry itself appear<br>\n";
		echo "<b>%icq%</b> - this is optional, it will make the users ICQ number appear<br>\n";
		echo "<b>%aim%</b> - this is optional, it will make the users AIM name appear<br>\n";
		echo "<b>%name%</b> - this will make the users name and email address (if set) appear<br>\n";
		echo "<b>%home%</b> - this is optional, it will make the users homepage with a link appear<br>\n";
		echo "</blockquote>\n";
		echo "<small>If you do not wish to include a certin feild simple do not enter it into your post template</small><br>\n";
		echo "<textarea style=\"height:100px; width:400px;\" name=\"template\">Make your template here using the variables above</textarea>\n";
		echo "<br><center><input type=\"password\" name=\"enterpass\" size=\"25\"><---Enter your password<br></center>";
		echo "<center>Only press this if you have ALL the settings set----&gt<input type=\"submit\" value=\"Set my settings!\"><input type=\"reset\" value=\"Clear\"></center>\n";
		echo "</form>\n";
	} else {
		echo "Already configured, use the <a href=\"guestbook-install.php?act=modify\">modify</a> option to make changes";
	}
	clearstatcache();
		break;
	case "modify":
		require ("config.php");
		global $install;
		echo "<a href=\"guestbook-install.php\">&lt---Or go back</a><br>\n";
		echo "<form action=\"guestbook-install.php?act=mod-settings\" method=\"post\">\n";
		echo "<input type=\"text\" name=\"install[logip]\" size=30 value=\"$install[logip]\">Log IP's? Set this to 1 is yes, or 0 if no. They will be logged to \"iplog.txt\"<br>\n";
		echo "<input type=\"text\" name=\"install[email]\" size=30 value=\"$install[email]\">Notify you via email if your book is signed? Fill this in if yes. Leave it blank if you dont wish to be notified<br>\n";
				if($install[badwords] == "on"){
					$badwords_value = "value = \"on\"";
					$checked_words = "checked";
				} else {
					$checked_words = "";
		}		
		echo "<input type=\"checkbox\" $badwords_value $checked_words name=\"install[badwords]\">Do you want to filter bad words and ethnic slurs, check if so.<br>\n";
		echo "<center><b>If the following confuses you, click this link to get a more detialed explination. <a href=\"guestbook-install.php?act=header\" target=_new>THIS LINK</a></b></center><br>\n";
		echo "<input type=\"text\" name=\"install[header]\" size=30 value=\"$install[header]\">If your website used a header file set this to the exact address to that file (IE: http://www.yoursite.com/header.txt) Otherwise leave this feild alone<br>\n";
		echo "<input type=\"text\" name=\"install[footer]\" size=30 value=\"$install[footer]\">If your website used a footer file set this to the exact address to that file (IE: http://www.yoursite.com/footer.txt) Otherwise leave this feild alone<br>\n";
		echo "<input type=\"text\" name=\"install[date]\" size=30 value=\"$install[date]\">This is how your date will appear. <a href=\"http://www.php.net/date\" target=_new>read more about the date</a> at PHP's site.<br>\n";
		echo "<h3>Fill these in if you DONT have a header file</h3><br>\n";
		echo "<input type=\"text\" name=\"install[background]\" size=30 value=\"$install[background]\">Your background color, if hex be sure to add a hash (#) sign<br>\n";
		echo "<input type=\"text\" name=\"install[link]\" size=30 value=\"$install[link]\">Your link color, if hex be sure to add a hash (#) sign<br>\n";
		echo "<input type=\"text\" name=\"install[text]\" size=30 value=\"$install[text]\">Your text color, if hex be sure to add a hash (#) sign<br>\n";
		echo "<input type=\"text\" name=\"install[vlink]\" size=30 value=\"$install[vlink]\">Your visited link color, if hex be sure to add a hash (#) sign<br>\n";
		echo "<input type=\"text\" name=\"install[alink]\" size=30 value=\"$install[alink]\">Your active link, if hex be sure to add a hash (#) sign<br>\n";
		echo "<b>Which <i>optional feilds</i> would you like to include: \n";
//heh heh, this is almost like a cheap cookie system. Once i figured out how to do it I felt like i 
//had cheated the system. All it does it keep something checked if it was, or unchecked if it wasnt
		if($install[feild_home] == "on"){
			$home_value = "value = \"on\"";
			$checked_home = "checked";
		} else {
			$checked_home = "";
		}
		echo "<blockquote><b>Homepage Feild <input type=\"checkbox\" $home_value $checked_home name=\"install[feild_home]\"><br>\n";
		if($install[feild_email] == "on"){
			$email_value = "value = \"on\"";
			$checked_email = "checked";
		} else {
			$checked_email = "";
		}
		echo "Email address <input type=\"checkbox\" $email_value $checked_email name=\"install[feild_email]\"><br>\n";
		if($install[feild_icq] == "on"){
			$icq_value = "value = \"on\"";
			$checked_icq = "checked";
		} else {
			$checked_icq = "";
		}
		echo "ICQ <input type=\"checkbox\" $icq_value $checked_icq name=\"install[feild_icq]\"><br>\n";
		if($install[feild_aim] == "on"){
			$aim_value = "value = \"on\"";
			$checked_aim = "checked";
		} else {
			$checked_aim = "";
		}		
		echo "AIM <input type=\"checkbox\" $aim_value $checked_aim name=\"install[feild_aim]\"></blockquote>\n";
		
		echo "<b>Use these variables to customize how each entry looks. You must use <u>EXACT</u> HTML for this to work. That means &ltbr&gt's at the end of your template. Pressing the return key will not, I repeat, will not make a new line when this is published.</b>:<br>\n";  
		echo "<blockquote><b>%zsdate%</b> - this is optional, it will make the date appear<br>\n";
		echo "<b>%entry%</b> - this makes the entry itself appear<br>\n";
		echo "<b>%icq%</b> - this is optional, it will make the users ICQ number appear<br>\n";
		echo "<b>%aim%</b> - this is optional, it will make the users AIM name appear<br>\n";
		echo "<b>%name%</b> - this will make the users name and email address (if set) appear<br>\n";
		echo "<b>%home%</b> - this is optional, it will make the users homepage with a link appear<br>\n";
		echo "</blockquote>\n";
		echo "<small>If you do not wish to include a certin feild simple do not enter it into your post template</small><br>\n";
		echo "<center><textarea style=\"height:100px; width:400px;\" name=\"template\">$install[template]</textarea><br>\n";
		if ($HTTP_COOKIE_VARS[cookiepassword]){
			echo "<input type=\"hidden\" name=\"password\" value=\"$purplemonster\"><br>\n";
		} else {
			echo "<input type=\"password\" name=\"password\" size=\"30\">Enter your pasword<br>";
		}
		echo "Only press this if you have ALL the settings set----&gt<input type=\"submit\" value=\"Modify my settings!\"><input type=\"reset\" value=\"Clear\"></center>\n";
		echo "</form>\n";
		echo "</body>\n </html>";
		break;
	case "file":
		create_config_file();
		create_ip();
		create_entryfile();
		echo "<br><br><center><a href=guestbook-install.php?act=file>Please fix the errors and then click here to try again</a>. Or, <a href=guestbook-install.php?act=install>on to step two!</a>\n";
		break;
	case "settings":
		$install[template] = "$template";
		$entry = "<?PHP\n";
		$entry .= "\$install[logip] = \"$install[logip]\";\n";
		$entry .= "\$install[email] = \"$install[email]\";\n";
		if ($install[header] == "") { 
			} else {
				$entry .= "\$install[header] = \"$install[header]\";\n"; 
			}
		if ($install[footer] == "") {
			} else {
				$entry .= "\$install[footer] = \"$install[footer]\";\n";
			}
		$entry .= "\$install[badwords] = \"$install[badwords]\";\n";
		$entry .= "\$install[date] = \"$install[date]\";\n";
		$entry .= "\$install[background] = \"$install[background]\";\n";
		$entry .= "\$install[link] = \"$install[link]\";\n";
		$entry .= "\$install[text] = \"$install[text]\";\n";
		$entry .= "\$install[alink] = \"$install[alink]\";\n";
		$entry .= "\$install[vlink] = \"$install[vlink]\";\n";
		$entry .= "\$install[feild_home] = \"$install[feild_home]\";\n";
		$entry .= "\$install[feild_aim] = \"$install[feild_aim]\";\n";
		$entry .= "\$install[feild_email] = \"$install[feild_email]\";\n";
		$entry .= "\$install[feild_icq] = \"$install[feild_icq]\";\n";
		$entry .= "\$install[template] = \"$install[template]\";";
		$entry .= "?>";
		add_entry("$entry", "a");
		echo "Your guestbook settings have been set<br><br>\n";
		echo "Heres the HTML required for you to put on your pages\n";
		echo "<blockquote><b>A link to sign the guestbook:</b><br> \n &lta href=\"guestbook-sign.php?act=sign\"&gtSign guestbook&lt/a&gt<br>\n";
		echo "<b>View entries:</b> <br> \n &lt a href=\"guestbook-sign.php?act=view\"&gtView Entries&lt/a&gt </blockquote>\n";
		echo "<center><a href=\"guestbook-install.php\">Back to main</a></center>\n";
		break;
	case "mod-settings":
		if ($password == $purplemonster) {
			$install[template] = "$template";
			$entry = "<?PHP\n";
			$entry .= "\$install[logip] = \"$install[logip]\";\n";
			$entry .= "\$install[email] = \"$install[email]\";\n";
			if ($install[header] == "") { 
				} else {
					$entry .= "\$install[header] = \"$install[header]\";\n"; 
				}
			if ($install[footer] == "") {
				} else {
					$entry .= "\$install[footer] = \"$install[footer]\";\n";
				}
			$entry .= "\$install[badwords] = \"$install[badwords]\";\n";
			$entry .= "\$install[date] = \"$install[date]\";\n";
			$entry .= "\$install[background] = \"$install[background]\";\n";
			$entry .= "\$install[link] = \"$install[link]\";\n";
			$entry .= "\$install[text] = \"$install[text]\";\n";
			$entry .= "\$install[alink] = \"$install[alink]\";\n";
			$entry .= "\$install[vlink] = \"$install[vlink]\";\n";
			$entry .= "\$install[feild_home] = \"$install[feild_home]\";\n";
			$entry .= "\$install[feild_aim] = \"$install[feild_aim]\";\n";
			$entry .= "\$install[feild_email] = \"$install[feild_email]\";\n";
			$entry .= "\$install[feild_icq] = \"$install[feild_icq]\";\n";
			$entry .= "\$install[template] = \"$install[template]\";";
			$entry .= "?>\n";
			add_entry("$entry", "w");
			echo "<center><h2>Settings modified successfully!</h2></center>";
			echo "<b><a href=\"guestbook-install.php\">Back to main</a></b> ";
		} else {
			print ("invalid password, press Back on your browser and try again");
		}
		break;
	case "archive":
		if ($password == $purplemonster){
			archive();
			echo "<center><a href=\"guestbook-install.php\">Click here</a> to go back to the main page</center>\n";
		} else {
			print ("Invalid Password, please press your back button and try again");
		}
		break;

	case "cookie":
			echo "<form action={_SERVER['SCRIPT_FILENAME']}?cookie=yes method=post>\n";
			echo "<input type=password  size=30 name=varify value=\"Enter your password here\"><br>\n";
			echo "<input type=submit value=\"Save Password in a cookie\">\n";
			echo "</form>\n";
		break;
		

	default:
		if(file_exists("config.php") && file_exists("entrylog.txt") && file_exists("iplog.txt")){
			echo "<br>Modify current settings? Click <a href=\"guestbook-install.php?act=modify\">here</a><br> \n";
			echo "<hr>\n";
			echo "Delete all current messages and copy old ones to an archive:\n";
			echo "<form action=guestbook-install.php?act=sure method=post>\n";
				if ($HTTP_COOKIE_VARS[cookiepassword]){
					echo "<center><input type=\"hidden\" name=\"password\" value=\"$purplemonster\">\n";
				} else {
			echo "<center>You must enter your password to execute this action <input type=\"password\" name=\"password\" size=\"20\">";
			} 
			echo "<input type=\"submit\" value=\"Submit\"></center>\n";
			echo "</form>\n";					
			echo "<hr>\n";
			echo "<a href=\"guestbook-install.php?act=modifyentries\">Modify Entries</a><br><br>\n";
		} else {
			echo "<h2>\"Order of Ops\"</h2><br>";
			echo "1) Click <a href=guestbook-install.php?act=file>here</a>, and start the installation process.<br>";
		}
		break;
	case "header":
		echo "A header (or footer) file is usually a plain text document that contains the HTML code for your webpage, header files contain all the HTML *before* the content and obviously, footer file contains the HTML *after* the content. <br>\n";
		echo "These files may contain php in them! To make one just simply take the HTML before the content of your web page, and place it in a text document, save this as \"header.txt\". Then, take the HTML that is *after* the content, put it in a text file and call that \"footer.txt\".<br>\n";
		echo "Now that you have these files upload them to your webserver, then go to the options part of this script and where it asks for a header or footer file put in the <b>exact</b> addresses to these files. ex:\n";
		echo "<blockquote>Your webpage is http://www.thispage.com.<br>\n You called each file their respective names<br>\n The address to them is <i>http://www.thispage.com/header.txt</i> <b>and</b> <i>http://www.thispage.com/footer.txt</i></blockquote>\n";
		echo "Enjoy!!!!";
		break; 
	case "modifyentries":
		$file="entrylog.txt"; 
		stripslashes($fp_contents);
		stripslashes($file);
		$fp = fopen($file,"r"); 
		$fp_contents = fread($fp,filesize($file)); 
		fclose($fp); 
		echo "<form action=\"guestbook-install.php?act=modifyentries_do\" method=\"post\">\n";
		$fp_contents = stripslashes($fp_contents);
		echo "<textarea style=\"height:350px; width:90%; color: navy; border: dotted 2px black; \" name=\"modification\">$fp_contents</textarea><br><small>See Changes on save?</small><input type=\"checkbox\" name=\"preview\" checked style=\"border: solid 2px black;\"> &nbsp; \n";
			if ($HTTP_COOKIE_VARS[cookiepassword]){
				echo "<input type=\"hidden\" value=\"$purplemonster\" name=\"password\">\n";
			} else {
				echo "<small>Enter your Password</small><input type=\"password\" name=\"password\" size=\"20\"  style=\"border: dotted 2px black; background-color: white; color: navy; \"><br>\n";
			}
		echo "<input type=\"submit\" value=\"M a k e   m y   C h a n g e s\" style=\"border: solid 2px black; background-color: white;\"> &nbsp; <input type=\"reset\" value=\"Clear my changes\" style=\"border: solid 2px black; background-color: white;\"></form><br>\n";
		echo "<a href=\"guestbook-install.php\">&lt------Or back to main</a>\n";
		clearstatcache();
		break;
	case "modifyentries_do":
		if ($password == $purplemonster){
			$file = "entrylog.txt";
			$openFILE = fopen($file,"w"); 
			$file = stripslashes($file); //take spashes out of what PHP just read
			$modification = stripslashes($modification); //take out the slashes PHP puts before quotes
			fwrite($openFILE,$modification); 
			fclose($openFILE);
			echo "Your log has been edited successfully. Click <a href=guestbook-install.php>To go back to main</a><hr>\n";
			if($preview == "on"){
				echo "Your new book should look like this: <small>(only works if you have iframes enabeled)</small><br>\n";
				echo "<iframe src=\"guestbook-install.php?act=preview\" width=\"100%\" height=\"200\"></iframe>\n";
				echo "<br><br>If you cant see the above iframe then click <a href=\"guestbook-install.php?act=preview\" target=_new>here</a>\n";
			}
		} else {
			print("Invalid password, press your browsers back button and try again");
		}
		break;
	case "preview":
		include("entrylog.txt");
		break;
	case  "sure":
		echo "<h2>Are you sure....</h2><br>\n";
		echo "\t...That you want to archive all your current guestbook's entries?<br>\n";
		echo "<center><form action=\"guestbook-install.php?act=archive\" method=\"post\">\n<input type=\"hidden\" value=$password name=\"password\"><input type=submit value=\"Yes, I am\"></form> ";
		echo "<form action=guestbook-install.php method=\"post\"><input type=submit value=\"No, I'm stupid, I dont want to\"></form></center>\n";
		break;
	}	
 
?></font>
</td>
</tr>
</table>
<BR>
<a href="guestbook-install.php">Main</a></center>
</body>
</html>