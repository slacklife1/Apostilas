﻿//Copyright (c) 2005 - 2006 Allan Spartacus Mangune, allan@lexysoft.com, http://www.ajaxgear.com

//Permission is hereby granted, free of charge, to any person 
//obtaining a copy of this software and associated documentation 
//files (the "Software"), to deal in the Software without restriction, 
//including without limitation the rights to use, copy, modify, merge, 
//publish, distribute, sublicense, and/or sell copies of the Software, 
//and to permit persons to whom the Software is furnished to do so, 
//subject to the following conditions:

//The above copyright notice and this permission notice shall be included 
//in all copies or substantial portions of the Software.

//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
//IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
//DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, 
//ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE 
//OR OTHER DEALINGS IN THE SOFTWARE.

var AjaxGear = new Object();
AjaxGear.Ajax = function ()
{
    // Private members
    var xmlHttp;
    var responseText = "";
    var responseXml;
    var url = "";
    var http = "";
    var method = "GET";
    var isAsynchronous = true;
    var requestData = "";
    var elementID = "";
    var thisObj = this;
    var pagePath = "";
    var isXml = false;
    var isMozilla = false;
    
    // Properties
    
    //Gets the method to be invoked.
    this.getMethod = function () { return method; }
    //Sets the method to be invoked.
    this.setMethod = function (inparam) { method = inparam; }
    //Gets a value that indicates whether or not the call is asynchronous.
    this.getIsAsynchronous = function () { return isAsynchronous; }
    //Sets a value that indicates whether or not the call is asynchronous.
    this.setIsAsynchronous = function (inparam) { isAsynchronous = inparam; }
    //Gets the query string of the post method.
    this.getRequestData = function () { return requestData;}
    //Sets the query string of the post method.
    this.setRequestData = function (inparam) { requestData = inparam;}
    //Sets the ID of the element that will display the server's response.
    this.setElementID = function (inparam) { elementID = inparam;}
    //Gets the text reponse of the server.   
    this.getResponseText = function () { return responseText;}
    //Gets the text reponse of the server.   
    this.getResponseXml = function () { return responseXml;}
    //
    this.setPagePath = function (inparam) { pagePath = inparam; }
    //
    this.setIsXml = function (inparam) { isXml = inparam; }
    
    // Events
    this.onRequestComplete = function () {};
    
    // Methods
        
    // Starts the request to server.
    this.startRequest = function(){
        createXMLHttpRequest();
        if (method.toUpperCase() == "GET"){
            sendGetRequest();
        }
        else if (method.toUpperCase() == "POST"){
            sendPostRequest();
        }    
	   	xmlHttp.onreadystatechange = handleServerResponse;	
	}
	
	// Sends a get request.
	function sendGetRequest()
	{
	    var ampersand = "&";
	    if (requestData == "") ampersand = "";
	    xmlHttp.open(method, pagePath + "?" + requestData + ampersand + createTimestamp(), isAsynchronous);
	    if (isXml)
	    {
	        if (isMozilla) xmlHttp.overrideMimeType('text/xml');
	        xmlHttp.setRequestHeader("Content-Type", "text/xml");
	    }
        xmlHttp.send(null);
	}
	
	// Sends a post request.
	function sendPostRequest()
	{
	    xmlHttp.open(method, pagePath + "?" + createTimestamp() , isAsynchronous);
        xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        if (isXml)
        {
            xmlHttp.setRequestHeader("Content-Type", "text/xml");
        }
        
        xmlHttp.send(requestData);
	}
	
	// Creates a timestamp for querystring.
	function createTimestamp()
	{
	    return "timestamp=" + new Date().getTime().toString();
	}
	
	// Creates the XMLHttpRequest object.
    function createXMLHttpRequest (){
        if (window.ActiveXObject){
            xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
            if (xmlHttp ==  null){
                xmlHttp = new ActiveXObject ("Msxml2.XMLHTTP");            
            }
        }
        else if (window.XMLHttpRequest){
            xmlHttp = new XMLHttpRequest(); isMozilla = true;
        }
        else{
            alert("The XMLHttpRequest nor ActiveXObject object could not be created.");
       }
     }
    
    // Shows the current version of AjaxGear 
    this.showVersion = function()
    {
        alert( "AjaxGear \nVersion .04 \n(c) 2005 Allan Spartacus Mangune \nAll rights reserved." );
    } 
       
    // Handles server's response
    function handleServerResponse(){
        if(xmlHttp.readyState == 4){
            if(xmlHttp.status == 200){
                responseText = xmlHttp.responseText;
                responseXml = xmlHttp.responseXML;
            }
            thisObj.onRequestComplete();
        }
    }
}