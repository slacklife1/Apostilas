﻿//Copyright (c) 2005 Allan Spartacus Mangune, allan@lexysoft.com, http://www.ajaxgear.com

//Permission is hereby granted, free of charge, to any person 
//obtaining a copy of this software and associated documentation 
//files (the "Software"), to deal in the Software without restriction, 
//including without limitation the rights to use, copy, modify, merge, 
//publish, distribute, sublicense, and/or sell copies of the Software, 
//and to permit persons to whom the Software is furnished to do so, 
//subject to the following conditions:

//The above copyright notice and this permission notice shall be included 
//in all copies or substantial portions of the Software.

//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
//MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
//IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
//DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, 
//ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE 
//OR OTHER DEALINGS IN THE SOFTWARE.

function checkLocationSearch()
{
    if (location.search == "")
    {
        display("home.aspx");
    }
    document.getElementById("header").innerHTML = "AjaxGear Toolkit";
}
        
function display(page)
{
    var obj = document.getElementById("content");
    var ajax = new AjaxGear.Ajax();
    ajax.setMethod("Get");
    ajax.setPagePath(page);
    ajax.startRequest();
    obj.innerHtml = "Loading ... ";
    ajax.onRequestComplete = function(){   
        obj.innerHTML = ajax.getResponseText();
    }
}
        
function displayHelpContent(page, elementID, item, tableBodyID)
{
    var obj = document.getElementById(elementID);
    var ajax = new AjaxGear.Ajax();
    ajax.setMethod("Get");
    ajax.setPagePath(page);
    ajax.setIsXml(true);
    ajax.startRequest();
    obj.innerText = "";
    ajax.onRequestComplete = function(){  
        updateTable(ajax.getResponseXml(), item, tableBodyID);
    }
}

function updateTable(xmlDocument, item, tableBodyID )
{ 
    if (xmlDocument == null)
    {
        alert("Your browser returned the responseXml of the XmlHttpRequest as null. Please check the known issue of your browser.");   
    }
    var collection = xmlDocument.getElementsByTagName(item);
            
    for (var i = 0; i < collection.length; i++)
    {
        var item = collection[i];
        var name = item.getElementsByTagName("name")[0].firstChild.nodeValue;
        var description = item.getElementsByTagName("description")[0].firstChild.nodeValue;
            addTableRow(name, description, tableBodyID);
        }
    }      

function addTableRow(name, description, tableBodyID)
{
    var row = document.createElement("tr");
    var cell = addTableCell(name, "150px");
    row.appendChild(cell);
    cell = addTableCell(description, "390");
    row.appendChild(cell);
    document.getElementById(tableBodyID).appendChild(row);
}

function addTableCell(text, width)
{
    var cell = document.createElement("td");
    cell.setAttribute("width", width);
    var textNode = document.createTextNode (text);
    cell.appendChild(textNode);
    return cell;
}
        
function submitMessage(me)
{
    var reason;
    var reasons = document.getElementById("reason");
    var xml = "<message name='" + document.getElementById("name").value 
        + "' email='" + document.getElementById("email").value + "'";
    for (var i =0;  i < reasons.length; i++)
    {
        reason = reasons[i];
        if (reason.selected)
        {
            xml = xml + " reason='" + reason.text + "'";
            break;
        }
    }
    xml = xml + " body='" + document.getElementById("message").value + "'";
    xml = xml + "\ />";
            
    var ajax = new AjaxGear.Ajax();
    ajax.setMethod("Post");
    ajax.setPagePath("Message.aspx");
    ajax.setRequestData(xml);
    ajax.setIsXml(true);
    ajax.startRequest();
    ajax.onRequestComplete = function(){   
        var message = ajax.getResponseXml().getElementsByTagName("reply")[0];
        if (message != null)
        {
            document.getElementById("contactMessage").innerText = message
                .getElementsByTagName("message")[0].firstChild.nodeValue;
            document.getElementById("contactForm").style.visibility  = "hidden";
        }
        else
        {
           alert("Your browser returned the responseXml of the XmlHttpRequest as null. Please check the known issue of your browser."); 
        }
    }
}
        
function resetContactForm()
{
    document.getElementById("name").value = "";
    document.getElementById("email").value = "";
    document.getElementById("reason").selectedIndex = 0;
    document.getElementById("message").value = "";
}  

