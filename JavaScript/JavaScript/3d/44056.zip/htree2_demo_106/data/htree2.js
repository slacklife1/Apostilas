// htree2 driver by lazyhorse 2000-2005 AD
tree={
treenew:function(awin,acss){
if(!awin)awin=window;
if(awin.tree){
if(awin!=window)return awin.tree.treenew(null,acss);
if(!this.treereset){
this.treereset=function(){
this.version="2.29 lazyhorse (MSIE 4.0; MSIE 5.0; MSIE 6.0; Netscape 6.0)";
this.tree=this;
this.self=this;
this.branch=[];
this.all={branch:[],layer:[]};
this.active=true;
this.time=0;
this.rate=100;
this.view={perspective:2,back:-100,front:100};
this.scrollblock=false;
this.rad=Math.PI/180;
this.timeout=null;
this.branchreset=function(){
this.window=window;
this.tree=tree;
this.self=this;
this.branch=[];
this.description="";
this.layer=[];
this.layerselected=0;
this.layerdisplayed=null;
this.followlinks=true;
this.program=[];
this.programselected=0;
this.programindex=0;
this.position=[0,0,0];
this.positionrelative=[0,0,0];
this.positionglobal=[0,0,0];
this.size=[0,0,0];
this.scale=1;
this.scalerelative=1;
this.angle=[0,0,0];
this.rotate=[0,0,0];
this.background="";
this.color="";
this.active=true;
this.frozen=false;
this.branchfrozen=false;
this.frozenrelative=false;
this.running=false;
this.moving=false;
this.formation=false;
this.inview=false;
this.ontop=false;
this.hiding=false;
this.branchhiding=false;
this.hidingrelative=false;
this.waiting=false;
this.com=[];
this.snap="snap";
this.smooth="smooth";
this.twang="twang";
this.creeper="creeper";
this.update=tree.update;
this.treenew=tree.treenew;
this.branchnew=tree.branchnew;
this.branchset=tree.branchset;
this.branchidentify=tree.branchidentify;
this.branchnow=tree.branchnow;
this.branchrun=tree.branchrun;
this.layerset=tree.layerset;
this.layerselect=tree.layerselect;
this.programset=tree.programset;
this.programselect=tree.programselect;
this.programstep=tree.programstep;
this.now=tree.now;
this.run=tree.run;
this.stop=tree.stop;
this.wait=tree.wait;
this.loop=tree.loop;
this.activate=tree.activate;
this.deactivate=tree.deactivate;
this.freeze=tree.freeze;
this.defreeze=tree.defreeze;
this.branchfreeze=tree.branchfreeze;
this.branchdefreeze=tree.branchdefreeze;
this.show=tree.show;
this.hide=tree.hide;
this.branchshow=tree.branchshow;
this.branchhide=tree.branchhide;
this.copy=tree.copy;
this.paste=tree.paste;
this.find=tree.find;
this.pilot=tree.pilot;
this.move=tree.move;
this.movestep=tree.movestep;
this.radar=tree.radar;
this.arraycopy=tree.arraycopy;
}
this.update=function(){
var pos=[],n=(this.parent==this.tree)?-1:1,i,id,act;
this.frozenrelative=this.branchfrozen||(n==1&&this.parent.frozenrelative);
if(!(this.frozen||this.frozenrelative)){
for(i=0;i<3;i++){
if(this.rotate[i])this.angle[i]=this.angle[i]+this.rotate[i];
this.angle[i]=(this.angle[i]%360+360)%360;
}
if(this.moving)this.movestep();
if(this.program[this.programselected]){
if(this.running){
if((isNaN(this.waiting)&&eval(this.waiting))||this.waiting<=0){
this.waiting=false;
do{
id=this.programselected;act=this.programstep();
if(this.programselected==id){
if(act)this.programindex++;
else this.running=false;
}
}
while(this.running&&((isNaN(this.waiting)&&eval(this.waiting))||this.waiting<=0)&&this.program[this.programselected]!=null);
}
}
}
if(!isNaN(this.waiting)&&this.waiting>0)this.waiting--;
}
for(i=0;i<3;i++){
this.angle[i]=(this.angle[i]%360+360)%360;
}
pos=[this.position[0],this.position[1],this.position[2]];
if(n==1&&(this.angle[0]||this.angle[1]||this.angle[2]))tree.branchturn(pos,this.angle);
if(n==1&&this.formation)for(i=this.address.length-2;i>=0&&this.address[i+1].formation;i--)if(this.address[i].angle[0]||this.address[i].angle[1]||this.address[i].angle[2])tree.branchturn(pos,this.address[i].angle);
for(i=0;i<3;i++)this.positionrelative[i]=(n==1)?this.parent.positionrelative[i]+pos[i]*this.parent.scalerelative:pos[i]*-this.scale;
this.scalerelative=(n==1)?this.parent.scalerelative*this.scale:this.scale;
this.hidingrelative=this.branchhiding||(n==1&&this.parent.hidingrelative);
for(i=0;i<3;i++)this.positionglobal[i]=(n==1)?(this.positionrelative[i]-this.top.positionrelative[i])/this.top.scalerelative:this.position[i];
if(this.layerdisplayed!=this.layerselected){
if(this.layer[this.layerdisplayed]&&this.layer[this.layerdisplayed]!=this.layer[this.layerselected])this.layer[this.layerdisplayed].style.visibility="hidden";
this.layerdisplayed=this.layerselected;
}
if(this.layer[this.layerdisplayed]){
var z,w=this.size[0]*this.scalerelative,h=this.size[1]*this.scalerelative,l=this.layer[this.layerdisplayed],s=l.style;
if(n==1&&(this.top.angle[0]||this.top.angle[1]||this.top.angle[2]))pos=tree.treeturn([this.positionrelative[0],this.positionrelative[1],this.positionrelative[2]],[360-this.top.angle[0],360-this.top.angle[1],360-this.top.angle[2]]);
else pos=(n==1)?[this.positionrelative[0],this.positionrelative[1],this.positionrelative[2]]:[0,0,0];
z=Math.pow(this.tree.view.perspective,pos[2]/100);
this.inview=!(pos[2]<this.tree.view.back||pos[2]>this.tree.view.front||Math.abs(pos[0])-w/2>50/z||Math.abs(pos[1])-h/2>50/z);
if(this.inview){
s.left=Math.round(((n==1)?50+(pos[0]-w/2)*z:50-this.size[0]/2)*1000)/1000+"%";
s.top=Math.round(((n==1)?50+(pos[1]-h/2)*z:50-this.size[1]/2)*1000)/1000+"%";
s.zIndex=parseInt((pos[2]-this.tree.view.back+((this.ontop)?this.tree.view.front-this.tree.view.back+1:0))/((this.tree.view.front-this.tree.view.back)*2+1)*2147483647+((n==1)?0:1));
s.width=Math.round(((n==1)?w*z:this.size[0])*1000)/1000+"%";
s.height=Math.round(((n==1)?h*z:this.size[1])*1000)/1000+"%";
s.fontSize=Math.round(((n==1)?z*this.scalerelative*100:100)*1000)/1000+"%";
if(this.background)s.background=this.background;
if(this.color)s.color=this.color;
}
s.visibility=(this.hidingrelative||!this.inview||this.hiding)?"hidden":"visible";
l.branch=this;
}
for(i in this.branch)if(this.branch[i]&&this.branch[i].active)this.branch[i].update();
}
this.branchnew=function(aid){
var b=(aid!=null)?this.branch[aid]={}:{};
tree.all.branch[b.idglobal=tree.all.branch.length]=b;
b.branchreset=this.branchreset;
b.branchreset();
b.top=(this==tree)?b:this.top;
b.parent=this;
b.id=aid;
b.address=(this==tree)?[]:this.arraycopy(this.address);
b.address[b.address.length]=b;
return b;
}
this.branchset=function(ab,aid){
var i;
if(aid==null)this.branch[aid=this.branch.length]=null;
if(ab){
if(ab.branchreset){
this.branch[aid]=ab;
}
else this.branchnew(aid).paste(ab,0);
for(i in ab.branch)this.branch[aid].branchset(ab.branch[i],i);
}
return this.branchidentify(aid);
}
this.branchidentify=function(aid){
if(aid==null)for(aid in this.branch)this.branchidentify(aid);
else if(this.branch[aid]){
this.branch[aid].tree=this.tree;
this.branch[aid].top=(this==tree)?this.branch[aid]:this.top;
this.branch[aid].parent=this;
this.branch[aid].id=aid;
this.arraycopy((this==tree)?null:this.address,this.branch[aid].address);
this.branch[aid].address[this.branch[aid].address.length]=this.branch[aid];
this.branch[aid].branchidentify();
}
return this.branch[aid];
}
this.branchnow=function(ap,ad){
var i;
for(i in this.branch){
if(this.branch[i]){
this.branch[i].now(ap);
if(ad)this.branch[i].branchnow(ap,ad-1);
}
}
}
this.branchrun=function(aid,ad){
var i;
for(i in this.branch){
if(this.branch[i]){
this.branch[i].run(aid);
if(ad)this.branch[i].branchrun(aid,ad-1);
}
}
}
this.layerset=function(aht,aid){
var l,i;
if(aid==null)aid=this.layer.length;
if(this.layer[aid])this.layer[aid].style.visibility="hidden";
if(aht&&aht.style)l=this.layer[aid]=aht;
else if(this.layer[aid]){
if(aht==null)l=this.layer[aid]=null;
else{
l=this.layer[aid];
l.innerHTML=aht;
}
}
else if(aht!=null){
tree.all.layer[i=tree.all.layer.length]=null;
document.writeln("<div id=tree_layer_"+i+" style='visibility:hidden'>:)<\/div>");
l=this.layer[aid]=tree.all.layer[i]=(document.getElementById)?document.getElementById("tree_layer_"+i):eval("tree_layer_"+i);
l.innerHTML=aht;
}
else l=this.layer[aid]=null;
if(l){
l.branch=this;
l.style.visibility="hidden";
l.style.position="absolute";
l.onclick=function(){this.branch.now(this.branch.onclick)};
l.ondblclick=function(){this.branch.now(this.branch.ondblclick)};
l.onmousedown=function(){this.branch.now(this.branch.onmousedown)};
l.onmouseup=function(){this.branch.now(this.branch.onmouseup)};
l.onmouseover=function(){this.branch.now(this.branch.onmouseover)};
l.onmouseout=function(){this.branch.now(this.branch.onmouseout)};
l.onmousemove=function(){this.branch.now(this.branch.onmousemove)};
}
return l;
}
this.layerselect=function(aid){
if(aid!=null&&aid.split||aid.style){
this.layerset(aid,"temp");
aid="temp";
}
return this.layerselected=aid;
}
this.programset=function(ap,aid){
if(aid==null)aid=this.program.length;
return (ap)?(this.program[aid])?this.arraycopy(ap,this.program[aid]):this.program[aid]=this.arraycopy(ap):this.program[aid]=null;
}
this.programselect=function(aid){
if(aid&&aid.join){
this.programset(aid,"temp");
aid="temp";
}
this.programindex=0;
this.waiting=false;
return this.programselected=aid;
}
this.programstep=function(){
if(this.program[this.programselected][this.programindex]){
eval(this.program[this.programselected][this.programindex]);
return true;
}
}
this.now=function(){
if(!isNaN(arguments[0]))arguments[0]=this.program[arguments[0]];
if(arguments[0])eval((arguments[0].join)?arguments[0].join(";"):arguments[0]);
}
this.activate=function(){
this.active=true;
}
this.deactivate=function(){
this.active=false;
}
this.freeze=function(){
this.frozen=true;
}
this.defreeze=function(){
this.frozen=false;
}
this.branchfreeze=function(){
this.branchfrozen=true;
}
this.branchdefreeze=function(){
this.branchfrozen=false;
}
this.run=function(aid){
if(aid!=null)this.programselect(aid);
this.running=(this.program[this.programselected])?true:false;
}
this.stop=function(){
this.running=false;
}
this.wait=function(at){
this.waiting=(at!=null)?at:1;
}
this.loop=function(ai){
this.programindex=(ai)?ai-1:-1;
}
this.show=function(aid){
if(aid!=null)this.layerselect(aid);
this.hiding=false;
}
this.shownow=function(){
this.show();
if(this.layer[this.layershowing])this.layer[this.layershowing].style.visibility=(this.hidingrelative||!this.inview)?"hidden":"visible";
}
this.hide=function(){
this.hiding=true;
}
this.hidenow=function(){
this.hide();
if(this.layer[this.layershowing])this.layer[this.layershowing].style.visibility="hidden";
}
this.branchshow=function(){
this.branchhiding=false;
}
this.branchhide=function(){
this.branchhiding=true;
}
this.copy=function(ad){
var i,c={branch:[]};
if(ad==null)ad=-1;
for(i in this){
if(this[i]&&this[i].prototype){
if(!tree[i])eval("c[i]="+this[i].toString());
}
else if(i!="branch")c[i]=(this[i]&&this[i].join)?this.arraycopy(this[i]):this[i];
}
for(i in c.layer)if(c.layer[i])c.layer[i]=c.layer[i].innerHTML;
for(i in c.program)if(c.program[i])c.program[i]=this.arraycopy(c.program[i]);
if(ad--)for(i in this.branch)c.branch[i]=(this.branch[i])?this.branch[i].copy(ad):null;
return c;
}
this.paste=function(ab,ad){
var i;
if(ad==null)ad=-1;
if(ab){
for(i in ab.layer)if(ab.layer[i])this.layerset(ab.layer[i],i);
for(i in ab.program)if(ab.program[i])this.programset(ab.program[i],i);
for(i in ab){
if(ab[i]&&ab[i].prototype){
if(!tree[i])eval("this[i]="+ab[i].toString());
}
else if(i!="window"&&i!="tree"&&i!="address"&&i!="top"&&i!="parent"&&i!="self"&&i!="id"&&i!="idglobal"&&i!="branch"&&i!="layer"&&i!="layerdisplayed"&&i!="program")(ab[i]&&ab[i].join)?(this[i]&&this[i].join)?this.arraycopy(ab[i],this[i]):this[i]=this.arraycopy(ab[i]):this[i]=ab[i];
}
if(ad--)for(i in ab.branch){
if(ab.branch[i]){
if(!this.branch[i])this.branchnew(i);
this.branch[i].paste(ab.branch[i],ad);
}
}
}
return this;
}
this.find=function(af,ad){
var i1,i2,f=[],rf;
if(ad==null)ad=-1;
if(af==null||af.split){
if(af==null)f[0]=this;
else if(this!=tree){
if(this.description.indexOf(af,0)!=-1)f[0]=this;
for(i1 in this.layer)if(this.layer[i1]&&this.layer[i1].innerText.indexOf(af,0)!=-1)f[0]=this;
}
if(ad--)for(i1 in this.branch){
if(this.branch[i1]){
rf=this.branch[i1].find(af,ad);
for(i2 in rf)f[f.length]=rf[i2];
}
}
if(f.length)return f;
}
else if(af.branch){
if(af==this)return [];
if(ad--)for(i1 in this.branch){
if(this.branch[i1]){
rf=this.branch[i1].find(af,ad);
if(rf){
f[0]=this.branch[i1];
for(i2 in rf)f[f.length]=rf[i2];
return f;
}
}
}
}
else if(af.join){
f="";
for(i=0;i<af.length&&ad--;i++){
if(af[i]||af[i]==0)f+=".branch["+((isNaN(af[i]))?af[i].id:af[i])+"]";
if(!eval("this"+f))return false;
}
return eval("this"+f);
}
}
this.pilot=function(ap,aa,av){
var i,d=(ap)?(ap.join)?[ap[0]||0,ap[1]||0,ap[2]||0]:[0,0,-ap]:[0,0,0];
if(av==null)av=100;
if(aa)d=tree.branchturn(d,aa);
for(i=0;i<3;i++)d[i]=d[i]*av/100+this.position[i];
return d;
}
this.move=function(ap,asz,as,aa,at,ae,ab,ac){
if(arguments.length){
this.moving=arguments;
this.movestep();
}
else this.moving=false;
}
this.movestep=function(){
var i,ta,e=0,v=this.moving,p=0,sz=1,s=2,a=3,t=4,e=5,b=6,c=7;
if(!v[t]||v[t]<0){
this.moving=false;
v[e]=false;
}
if(v[e]){
if(v[e]=="smooth")e=1/v[t];
if(v[e]=="twang")e=0.5;
if(v[e]=="creeper")e=1/Math.pow(v[t],2);
for(i=0;i<3;i++){
if(v[p]&&v[p][i]!=null)this.position[i]+=(v[p][i]-this.position[i])*e;
if(v[sz]&&v[sz][i]!=null)this.size[i]+=(v[sz][i]-this.size[i])*e;
if(v[a]&&v[a][i]!=null){
ta=v[a][i]-this.angle[i];
this.angle[i]=((this.angle[i]+((Math.abs(ta)>180)?ta+((ta>0)?-360:360):ta)*e)%360+360)%360;
}
}
if(v[s]!=null)this.scale=this.scale+(v[s]-this.scale)*e;
if(v[b]!=null&&v[b].substring(0,1)=="#")this.background=tree.fade(v[b],this.background,e);
if(v[c]!=null&&v[c].substring(0,1)=="#")this.color=tree.fade(v[c],this.color,e);
}
else{
for(i=0;i<3;i++){
if(v[p]&&v[p][i]!=null)this.position[i]=v[p][i];
if(v[sz]&&v[sz][i]!=null)this.size[i]=v[sz][i];
if(v[a]&&v[a][i]!=null)this.angle[i]=v[a][i];
}
if(v[s]!=null)this.scale=v[s];
if(v[b]!=null)this.background=v[b];
if(v[c]!=null)this.color=v[c];
}
if(v[t])v[t]--;
}
this.radar=function(ar){
var i,r=[];
for(i in ar){
if(ar[i])r[i]=Math.pow(Math.pow(Math.abs(this.positionglobal[0]-ar[i].positionglobal[0]),3)+Math.pow(Math.abs(this.positionglobal[1]-ar[i].positionglobal[1]),3)+Math.pow(Math.abs(this.positionglobal[2]-ar[i].positionglobal[2]),3),1/3);
else r[i]=null;
}
return r;
}
this.arraycopy=function(a1,a2,ad){
var i;
if(a2==null)a2=[];
if(ad==null)ad=-1;
a2.length=(a1)?a1.length:0;
for(i in a1){
if(a1[i]&&a1[i].join&&ad){
if(a2[i]&&a2[i].join)this.arraycopy(a1[i],a2[i],ad-1);
else a2[i]=this.arraycopy(a1[i],null,ad-1);
}
else a2[i]=a1[i];
}
return a2;
}
this.restart=function(){
var i;
if(document.body){
if(window.navigator.appName=="Microsoft Internet Explorer")document.body.style.fontSize=Math.min(document.body.clientWidth/6.4,document.body.clientHeight/4.8)+"%";
else document.documentElement.style.fontSize=Math.round(Math.min(innerWidth/6.4,innerHeight/4.8)*1000)/1000+"%";
}

if(this.scrollblock)scrollTo(0,0);
if(this.active){
for(i in this.branch)if(this.branch[i]&&this.branch[i].active)this.branch[i].update();
this.time++;
}
this.timeout=setTimeout('tree.restart()',this.rate);
}
this.fade=function(ac1,ac2,as){
var h=[[],[]],d=[[],[]],c=[ac1,ac2],x,y;
for(x=0;x<=1;x++){
for(y=0;y<=5;y++){
h[x][y]=c[x].substring(y+1,y+2);
if(isNaN(h[x][y]))h[x][y]=(h[x][y].charCodeAt(0)&95)-55;
}
for(y=0;y<=2;y++)d[x][y]=parseInt(h[x][y*2])*16+parseInt(h[x][y*2+1]);
}
for(x=0;x<=2;x++)d[0][x]=d[1][x]+(d[0][x]-d[1][x])*as;
c[0]="#";
for(x=0;x<=2;x++){
for(y=0;y<=1;y++){
h[0][x*2+y]=d[0][x]/(16-15*y)&15;
if(h[0][x*2+y]>9)h[0][x*2+y]=String.fromCharCode(h[0][x*2+y]+55);
c[0]=c[0]+h[0][x*2+y];
}
}
return c[0];
}
this.treeturn=function(ap,aa){
if(aa[1])this.turn(ap,0,2,aa[1]);
if(aa[0])this.turn(ap,2,1,aa[0]);
if(aa[2])this.turn(ap,0,1,aa[2]);
return ap;
}
this.branchturn=function(ap,aa){
if(aa[2])this.turn(ap,0,1,aa[2]);
if(aa[0])this.turn(ap,2,1,aa[0]);
if(aa[1])this.turn(ap,0,2,aa[1]);
return ap;
}
this.turn=function(ap,ap1,ap2,aaa){
var a,c,r;
if(Math.abs(ap[ap1])<0.0000000000001){
a=(aaa+180*(ap[ap2]>0))*this.rad;
r=Math.abs(ap[ap2]);
}
else{
c=Math.atan(ap[ap2]/ap[ap1]);
a=(aaa+180*(ap[ap1]<0)+90)*this.rad+c;
r=Math.abs(ap[ap1]/Math.cos(c));
}
ap[ap1]=Math.sin(a)*r;
ap[ap2]=-Math.cos(a)*r;
}
};
this.treereset();
this.restart();
}
}
else{
awin.document.write("<script>tree={}<\/script>");
awin.tree.parent=this;
awin.document.writeln("<script>if(tree.parent){eval('tree.treenew='+tree.parent.treenew.toString());tree.treenew()}else tree=false<\/script>");
}
if(!(awin.document.getElementById&&awin.document.getElementById("tree_style")||awin.tree_style))awin.document.writeln("<style id=tree_style>a,abbr,acronym,address,b,bdo,big,blink,blockquote,body,button,caption,center,cite,code,colgroup,dd,del,dir,div,dl,dt,em,fieldset,font,form,h1,h2,h3,h4,h5,h6,html,i,iframe,input,ins,kbd,label,legend,li,marquee,menu,nobr,noembed,ol,optgroup,option,p,pre,q,s,samp,select,small,span,strike,strong,sub,sup,table,tbody,td,textarea,tfoot,th,thead,tr,tt,u,ul,var{font-size:100%;text-indent:0;margin:0}big{font-size:118.921%}small{font-size:84.089%}h1{font-size:400%}h2{font-size:300%}h3{font-size:200%}h4{font-size:75%}h5{font-size:50%}h6{font-size:25%}<\/style><basefont size=3>");
if(acss)awin.document.writeln("<style>"+acss+"<\/style>");
return awin.tree;
}
};
