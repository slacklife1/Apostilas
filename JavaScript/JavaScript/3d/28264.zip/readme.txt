Just check out cluster.html
Its real easy to use, you'll figure it out.
Contact me if you've got questions.

BYE . . .

Contact: cjselke@optusnet.com.au