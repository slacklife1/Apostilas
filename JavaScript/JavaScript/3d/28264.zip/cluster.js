// Author:		Clinton Jon Selke
// Description: A cool 3D rotational cluster of word
// Class:		Cluster(text_array, x_pos, y_pos, number_of_points, min_radius, max_radius, colour_array);
// Methods:		startAnimation(), stopAnimation()

function Mat4x4_timesMat4x4(mat) {
	var result, i, j, k;
	result = new Mat4x4();
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 4; j++) {
			for (k = 0, result.data[i][j] = 0; k < 4; k++) {
				result.data[i][j] += this.data[i][k] * mat.data[k][j];
			}
		}
	}
	return result;
}

function Mat4x4() {
	this.timesMat4x4 = Mat4x4_timesMat4x4;
	this.data = new Array(4);
	for (var i = 0; i < 4; i++) {
		this.data[i] = new Array(4);
	}
}

function Vec3_transformed(mat) {
	return new Vec3(mat.data[0][0] * this.x + mat.data[0][1] * this.y + mat.data[0][2] * this.z + mat.data[0][3],
				    mat.data[1][0] * this.x + mat.data[1][1] * this.y + mat.data[1][2] * this.z + mat.data[1][3],
				    mat.data[2][0] * this.x + mat.data[2][1] * this.y + mat.data[2][2] * this.z + mat.data[2][3]);
}

function Vec3_dotVec3(v) {
	return this.x * v.x + this.y * v.y + this.z * v.z;
}

function Vec3_crossVec3(v) {
	return Vec3(this.y * v.z - this.z * v.y,
				this.z * v.x - this.x * v.z,
				this.x * v.y - this.y * v.x);
}

function Vec3(x, y, z) {
	this.x = x;
	this.y = y;
	this.z = z;
	this.transformed = Vec3_transformed;
	this.dotVec3 = Vec3_dotVec3;
	this.crossVec3 = Vec3_crossVec3;
	return this;
}

function mat4x4Identity() {
	var result = new Mat4x4();
	result.data = [[1,0,0,0],
				   [0,1,0,0],
				   [0,0,1,0],
				   [0,0,0,1]];
	return result;
}

function mat4x4RotateX(a) {
	var s = Math.sin(a), c = Math.cos(a);
	var result = new Mat4x4();
	result.data = [[ 1, 0, 0, 0],
				   [ 0, c, s, 0],
				   [ 0,-s, c, 0],
				   [ 0, 0, 0, 1]];
	return result;
}

function mat4x4RotateY(a) {
	var s = Math.sin(a), c = Math.cos(a);
	var result = new Mat4x4();
	result.data = [[ c, 0,-s, 0],
				   [ 0, 1, 0, 0],
				   [ s, 0, c, 0],
				   [ 0, 0, 0, 1]];
	return result;
}

function mat4x4RotateZ(a) {
	var s = Math.sin(a), c = Math.cos(a);
	var result = new Mat4x4();
	result.data = [[ c, s, 0, 0],
				   [-s, c, 0, 0],
				   [ 0, 0, 1, 0],
				   [ 0, 0, 0, 1]];
	return result;
}

function mat4x4Scale(a) {
	var result = new Mat4x4();
	result.data = [[a,0,0,0],
				   [0,a,0,0],
				   [0,0,a,0],
				   [0,0,0,1]];
	return result;
}

function mat4x4Move(v) {
	var result = new Mat4x4();
	result.data = [[ 1, 0, 0, v.x],
				   [ 0, 1, 0, v.y],
				   [ 0, 0, 1, v.z],
				   [ 0, 0, 0,   1]];
	return result;
}

function adjustAngle(angle) {
	while (angle < -Math.PI) {
		angle += Math.PI;
	}
	while (angle > Math.PI) {
		angle -= Math.PI;
	}
}

function red(colour) {
	return (colour >> 16) & 0xFF;
}

function green(colour) {
	return (colour >> 8) & 0xFF;
}

function blue(colour) {
	return colour & 0xFF;
}

function rgb(r, g, b) {
	return ((parseInt(r) & 0xFF) << 16) +
		   ((parseInt(g) & 0xFF) << 8) +
		   (parseInt(b) & 0xFF);
}

function scaledColour(colour, a) {
	return rgb(red(colour) * a, green(colour) * a, blue(colour) * a);
}

var Cluster_Collection = new Array();
var Cluster_NextIndex = 0;

function Cluster_loop(cluster_id) {
	var cluster = Cluster_Collection[cluster_id];
	var tMatrix = mat4x4RotateX(cluster.angle.x).timesMat4x4(mat4x4RotateY(cluster.angle.y)).timesMat4x4(mat4x4RotateZ(cluster.angle.z));
	for (var i = 0; i < cluster.new_star_positions.length; i++) {
		cluster.new_star_positions[i] = cluster.original_star_positions[i].transformed(tMatrix);
	}
	cluster.positionElements();
	cluster.angle.x += 0.01;
	cluster.angle.y -= 0.02;
	cluster.angle.z += 0.03;
	adjustAngle(cluster.angle.x);
	adjustAngle(cluster.angle.y);
	adjustAngle(cluster.angle.z);
}

function Cluster_getStarElement(index) {
	return eval('Cluster' + this.cluster_id + 'Star' + index);
}

function Cluster_positionElements() {
	for (var i = 0; i < this.new_star_positions.length; i++) {
		var starElement, star;
		star = this.new_star_positions[i];
		starElement = this.getStarElement(i);
		starElement.style.left = star.x * 400.0 / (star.z + 400.0) + this.x;
		starElement.style.top = star.y * 400.0 / (star.z + 400.0) + this.y;
		starElement.style.color = scaledColour(this.star_colours[i % this.star_colours.length], (1 - star.z / this.max_radius) / 2.0);//parseInt(127.5 * (1 - star.z / this.max_radius)) & 0xFF;
	}
}

function Cluster_startAnimation() {
	if (!this.animating) {
		this.interval_id = setInterval("Cluster_loop(" + this.cluster_id + ")", 1);
		this.animating = true;
	}
}

function Cluster_stopAnimation() {
	if (this.animating) {
		clearInterval(this.interval_id);
		this.animating = false;
	}
}

function Cluster(text_array, x, y, number_of_stars, min_radius, max_radius, star_colours) {
	this.startAnimation = Cluster_startAnimation;
	this.stopAnimation = Cluster_stopAnimation;
	this.getStarElement = Cluster_getStarElement;
	this.positionElements = Cluster_positionElements;
	this.cluster_id = Cluster_NextIndex;
	this.animating = false;
	this.tMatrix = mat4x4RotateX(0.05).timesMat4x4(mat4x4RotateZ(0.02));
	this.angle = new Vec3(0,0,0);
	this.x = x;
	this.y = y;
	this.max_radius = max_radius;
	this.original_star_positions = new Array(number_of_stars);
	this.new_star_positions = new Array(number_of_stars);
	this.star_colours = star_colours;
	for (var i = 0; i < number_of_stars; i++) {
		var x, y, z, a, b, r;
		a = (2.0 * Math.random() - 1.0) * Math.PI;
		b = Math.PI * Math.random();
		r = (max_radius - min_radius) * Math.random() + min_radius;
		x = r * Math.cos(a) * Math.sin(b);
		y = r * Math.sin(a) * Math.sin(b);
		z = r * Math.cos(b);
		this.original_star_positions[i] = new Vec3(x, y, z);
		document.body.innerHTML += '<DIV ID=Cluster' + this.cluster_id + 'Star' + i + ' STYLE="position:absolute; left:0; top:0; color:#000000"><B>' + text_array[i % text_array.length] + '</B></DIV>';
	}
	Cluster_Collection[Cluster_NextIndex] = this;
	Cluster_NextIndex++;
	return this;
}
