// SITEMAPPER 3.19 (FOR TREE 2.29) BY LAZYHORSE 2002AD-2004AD

// FUNCTION FOR INITIALISATION
function sitemap_go(){
 var i, i1, v_address, v_elements=( document.getElementsByTagName)? document.getElementsByTagName( "div"): document.all;
 if(! window.sitemap_address&& document.getElementsByName) window.sitemap_address= document.getElementsByName( "sitemap_address")[ 0];

 // PROGRAM CAMERA
 window.sitemap= tree.treenew().branchset({
  branch:[ {}],
  sitemap_configure:[ "this.formation= this.top.sitemap_formation; this.move(( this.address.length> 2)?[ null,(( this.top.sitemap_expand&& this.top.sitemap_depth>= 2&& this.address.length- this.top.sitemap_locationnew.address.length+ 1== this.top.sitemap_depth)?[ -100* 3/ 4, -100* 3/ 4, -100* 3/ 6, -100* 3/ 9]:[ -100/ 3* 3, -100/ 3* 2, -100/ 3* 1.5, -100/ 3* 1])[ this.top.sitemap_size- 1], 1]: null,[ 100, 100],(( this.address.length> 2)?(( this.parent.branch.length<= 6)? 1/ 3: 2/ 3* Math.sin( Math.PI/ this.parent.branch.length)): 1)*(( this.top.sitemap_expand&& this.top.sitemap_depth>= 2&& this.address.length- this.top.sitemap_locationnew.address.length+ 1>= this.top.sitemap_depth- 1)?(( this.address.length- this.top.sitemap_locationnew.address.length+ 1== this.top.sitemap_depth)?[ 3/ 2, 3/ 2, 3/ 2, 1]:[ 3/ 2, 1, 1, 1])[this.top.sitemap_size- 1]: 1),[ null, null,( this.address.length> 2)? 360/ this.parent.branch.length* this.id: null])"],
  sitemap_depth: 3,
  sitemap_expand: false,
  sitemap_formation: true,
  program:[
   [ // go
    "if( !this.sitemap_locationnew) this.sitemap_locationnew= this.branch[ 0]; if( !this.sitemap_locationcurrent) this.sitemap_locationcurrent= this.sitemap_locationnew",
    "this.branchnow([ 'this.activate()', 'this.hide()'], -1)",
    "for( this.sitemap_i= 1; this.sitemap_i< this.sitemap_locationnew.address.length- 1; this.sitemap_i++) this.sitemap_locationnew.address[ this.sitemap_i].now( this.sitemap_configure)",
    "this.run(( this.sitemap_locationnew== this.sitemap_locationcurrent)? 3:( this.sitemap_locationnew.address.length< this.sitemap_locationcurrent.address.length)? 2: 1)"
   ],
   [ // go in
    "this.sitemap_locationnew.now([ 'this.show( 0); this.now( this.top.sitemap_configure)'])",
    "this.sitemap_locationnew.branchnow( this.sitemap_configure, this.sitemap_depth- 2)",
    "if( this.sitemap_depth> 2) this.sitemap_locationnew.branchnow([ 'this.show( Math.min( this.address.length- this.top.sitemap_locationnew.address.length, this.layer.length- 1))'], this.sitemap_depth- 3)",
    "this.wait()",
    "this.branchnow([ 'this.deactivate()'], -1)",
    "for( this.sitemap_i= 1; this.sitemap_i< this.sitemap_locationnew.address.length; this.sitemap_i++) this.sitemap_locationnew.address[ this.sitemap_i].activate()",
    "if( this.sitemap_depth> 2) this.sitemap_locationnew.branchnow([ 'this.activate()'], this.sitemap_depth- 3)",
    "this.move( this.sitemap_locationnew.positionglobal, null, this.scale/ this.sitemap_locationnew.scalerelative*[( this.sitemap_expand&& this.sitemap_depth== 2)? 1.5/ 3: 1/ 3, 1.5/ 3, 2/ 3, 3/ 3][ this.sitemap_size- 1], null, 6, 'smooth')",
    "this.wait( '!this.moving')",
    "this.sitemap_locationnew.branchnow([ 'this.activate(); this.show( Math.min( this.address.length- this.top.sitemap_locationnew.address.length, this.layer.length- 1))'], this.sitemap_depth- 2)",
    "this.run( 4)"
   ],
   [ // go out
    "this.sitemap_locationnew.now( this.sitemap_configure)",
    "this.sitemap_locationnew.branchnow( this.sitemap_configure, this.sitemap_depth- 2)",
    "this.sitemap_locationcurrent.now([ 'this.show( Math.min( this.address.length- this.top.sitemap_locationnew.address.length, this.layer.length- 1))'])",
    "if( this.sitemap_depth> 2) this.sitemap_locationcurrent.branchnow([ 'this.show( Math.min( this.address.length- this.top.sitemap_locationnew.address.length, this.layer.length- 1))'], this.sitemap_depth- 3)",
    "this.wait()",
    "this.branchnow([ 'this.deactivate()'], -1)",
    "for( this.sitemap_i= 1; this.sitemap_i< this.sitemap_locationcurrent.address.length; this.sitemap_i++) this.sitemap_locationcurrent.address[ this.sitemap_i].activate()",
    "if( this.sitemap_depth> 2) this.sitemap_locationcurrent.branchnow([ 'this.activate()'], this.sitemap_depth- 3)",
    "this.move( this.sitemap_locationnew.positionglobal, null, this.scale/ this.sitemap_locationnew.scalerelative*[( this.sitemap_expand&& this.sitemap_depth== 2)? 1.5/ 3: 1/ 3, 1.5/ 3, 2/ 3, 3/ 3][ this.sitemap_size- 1], null, 6, 'smooth')",
    "this.wait( '!this.moving')",
    "this.sitemap_locationnew.show( 0)",
    "this.sitemap_locationnew.branchnow([ 'this.activate(); this.show( Math.min( this.address.length- this.top.sitemap_locationnew.address.length, this.layer.length- 1))'], this.sitemap_depth- 2)",
    "this.run( 4)"
   ],
   [ // just go
    "this.sitemap_locationnew.now( this.sitemap_configure)",
    "this.sitemap_locationnew.branchnow( this.sitemap_configure, this.sitemap_depth- 2)",
    "this.wait()",
    "this.branchnow([ 'this.deactivate()'], -1)",
    "for( this.sitemap_i= 1; this.sitemap_i< this.sitemap_locationnew.address.length; this.sitemap_i++) this.sitemap_locationnew.address[ this.sitemap_i].activate()",
    "this.sitemap_locationnew.branchnow([ 'this.activate()'], this.sitemap_depth- 2)",
    "this.sitemap_locationnew.show( 0)",
    "this.sitemap_locationnew.branchnow([ 'this.show( Math.min( this.address.length- this.top.sitemap_locationnew.address.length, this.layer.length- 1))'], this.sitemap_depth- 2)",
    "this.move( this.sitemap_locationnew.positionglobal, null, this.scale/ this.sitemap_locationnew.scalerelative*[(( this.sitemap_expand&& this.sitemap_depth== 2)? 1.5/ 3: 1/ 3), 1.5/ 3, 2/ 3, 3/ 3][ this.sitemap_size- 1])",
    "this.wait()",
    "this.run( 4)"
   ],
   [ // finalize
    "this.wait()",
    "this.branchnow([ 'this.deactivate()'], -1)",
    "this.sitemap_locationcurrent= this.sitemap_locationnew"
   ]
  ],
  sitemap_search: function( a_search){
   var i, v_find=( a_search)? this.find( a_search): this.sitemap_locationcurrent;
   if( v_find){
    if( v_find.join) v_find=( a_search.branch)? a_search: v_find[ 0];
    if( window.sitemap_address){
     sitemap_address.value= "[0";
     for( i= 2; i< v_find.address.length; i++) sitemap_address.value+= ","+ v_find.address[ i].id;
     sitemap_address.value+= "]";
    }
    this.sitemap_locationnew=( !v_find.branch.length&& v_find!= this.branch[ 0])? v_find.parent: v_find;
    this.run( 0);
   }
   return v_find;
  },
  sitemap_size: 1
 });
 
 // READ IN LAYERS AND BUILD BRANCHES
 for( i= 0; i< v_elements.length; i++){
  if( v_elements[ i].id&& v_elements[ i].id.indexOf( "sitemap_0")== 0){
   v_address= v_elements[ i].id.substring( 8, v_elements[ i].id.length).split( "_");
   for( i1= 0; i1< v_address.length; i1++){
    if( !sitemap.find( v_address, i1+ 1)) sitemap.find( v_address, i1).branchset({}, v_address[ i1]);
   }
   sitemap.find( v_address).layerset( v_elements[ i]);
  }
 }
 if( window.sitemap_branch) sitemap.paste( sitemap_branch);

 // INITIALISE BRANCHES, DISPLAY AND MAP LOCATION
 tree.view.perspective= 1;
 sitemap.branchnow([ "this.hide()", "if( this.address.length> 2&& this.branch.length) this.onclick=[ 'if(! this.top.running){ this.top.sitemap_search(( this.top.sitemap_locationcurrent== this)? this.parent: this); if( this.sitemap_click) this.now( this.sitemap_click)}']"], -1);
 onload= function(){
  sitemap.run( 0);
  sitemap.sitemap_search( eval(( window.sitemap_address&& sitemap_address.value)? sitemap_address.value: location.search.substring( 1, location.search.length)));
  sitemap.now( sitemap.sitemap_startup)
 };
}

// LET'S GO
sitemap_go();
