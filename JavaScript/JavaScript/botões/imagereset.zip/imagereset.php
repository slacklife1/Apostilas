
<? include("../../global.php");

$headtag = '<!-- This script is brought to you by Matthew Mattson -->
<SCRIPT LANGUAGE="JavaScript">
<!-- If an old browser hide
	function resetForm() {
		document.zap.singleline.value = "";
		document.zap.bigbox.value = "";
		document.zap.dropme[0].selected = true;
		document.zap.rad[0].checked = true;
		document.zap.markme.checked = false;
	}
// End hide -->
</SCRIPT>
';

//  below is the bodytag,headtag,tablecolor	
		
head("",$headtag,"",$cat); ?>	
		
<!-- START MAIN BODY CONTENT-->	


<!--TITLE HERE-->

<DIV ALIGN="center"><FONT SIZE="4"><B>Image Reset</B></FONT>

<BR><BR><BR>

<!--DESCRIPTION HERE-->
Replace that boring reset button with this spiffy graphic version.
<BR><BR>
<!--BODY CODE HERE-->
<form name="zap">
	<p><input type="text" name="singleline"></p>
	<p><textarea rows="6" name="bigbox" cols="20"></textarea></p>
	<p><select size="1" name="dropme">
		<option>Choice One</option>
		<option>Choice Two</option>
		<option>Choice Three</option>
		<option>Choice Four</option>
	</select></p>
	<p><input type="radio" checked name="rad" value="optionOne">
	   <input type="radio" name="rad" value="optionTwo">
	   <input type="radio" name="rad" value="optionThree"></p>
	<p><input type="checkbox" name="markme" value="ON"></p>
	<p><a href="javascript:resetForm()"><img border="0" src="resetbutton.gif" width="75" height="25"></a></p>
</form>


<BR><BR>

Author: Matthew Mattson   

<BR><BR>

<A href="http://www.javafile.com/button/imagereset/imagereset.zip"><B>Download the Script</B></A></P>

</DIV>	
		
		
<!-- END MAIN BODY CONTENT-->	
		


<? footer(); ?>	