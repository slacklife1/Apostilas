
<? include("../../global.php");

$headtag = '';

//  below is the bodytag,headtag,tablecolor	
		
head("",$headtag,"",$cat); ?>	
		
<!-- START MAIN BODY CONTENT-->	


<!--TITLE HERE-->

<DIV ALIGN="center"><FONT SIZE="4"><B>Bookmark Menu</B></FONT>

<BR><BR><BR>
<!--DESCRIPTION HERE-->

This applet reads a bookmarks file (in Netscape format) and displays the corresponding menu, like the one in Netscape's toolbar. Look in the top left corner of this page for the bookmark menu window!



<BR><BR><BR>
<!--BODY CODE HERE-->

<SCRIPT LANGUAGE="JavaScript">
<!--
    function nameThisWindow(){
        if(window.name==""){
            window.name="openerWindow";
            print("Assigned new name: "+window.name);
        }else
            print("Window name is: "+window.name);
    }
    function openWindow() {
        bookmarkWindow=window.open("bookmarkWindow.html", "BookmarkWindow","width=80,height=80,left=0,top=0,resizable=1,alwaysRaised=yes");
    }
    function closeWindow() {
        bookmarkWindow.close();
    }
    function print(msg){
        java.lang.System.out.println(msg);
    }
//-->
</SCRIPT>
</head>
<body onLoad="nameThisWindow();">

<form>
    <input type="button" value="Open Bookmarks" onClick="openWindow()">
    <input type="button" value="Close Bookmarks" onClick="closeWindow()">
</form>




<BR><BR>

Author:  <a href="mailto:laza@cs.columbia.edu">Zoran Lazarevic</a>

<BR><BR>

<A href="http://www.javafile.com/menuing/bookmark/bookmark.zip"><B>Download the Script</B></A></P>

</DIV>	
		
		
<!-- END MAIN BODY CONTENT-->	
		


<? footer(); ?>	