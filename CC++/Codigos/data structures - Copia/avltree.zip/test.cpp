/*
Testing the avltree class
This program tests the avltree class in the 
companion file avltree.h
Deepak <deepak-p@eth.net>
http://www.geocities.com/acmesofties/
26-June-2002
*/

# include <iostream.h>
# include <math.h>
# include "avltree.h"

void main()
{
    avltree t;
    int ch=10;
	cout<<"\n\nTesting the AVLTREE class ver1.01";
	cout<<"\nDeepak  <deepak-p@eth.net>";
	cout<<"\n26-June-2002";
	cout<<"\nhttp://www.geocities.com/acmesofties/\n\n";
    while(ch!=20)	
    {
	cout<<"\n1.Insert Item\n2.Inorder Traversal\n3.Preorder Traversal\n4.Postorder Traversal\n5.Search\n6.Get Parent\n7.Height\n8.Balance\n9.Delete\n10.Exit";
	cout<<"\nEnter choice:";
	cin>>ch;
	switch(ch)
	{
	    case 1:
	    {
		int i;
		cout<<"\nEnter item:";
		cin>>i;
		t.insert(i);
		break;
	    }
	    case 2:
	    {
		cout<<"\nTraversing Inorder...\n";
		t.inorder(t.root);
		break;
	    }
	    case 3:
	    {
		cout<<"\nTraversing preorder...\n";
		t.preorder(t.root);
		break;
	    }
	    case 4:
	    {
		cout<<"\nTraversing postorder...\n";
		t.postorder(t.root);
		break;
	    }
	    case 5:
	    {
		int i;
		cout<<"\nEnter element to be searhced:";
		cin>>i;
		if(t.getnode(i)!=NULL)
		    cout<<"\nElement found.";
		else cout<<"\nElement not in tree.";
		break;
	    }
	    case 6:
	    {
		int i;
		cout<<"\nEnter element:";
		cin>>i;
		node *t1=t.getparent(i);
		if(t1!=NULL)
		    cout<<"\nParent at "<<t1->data;
		else cout<<"\nElement not in tree or is root";
		break;
	    }
	    case 7:
	    {
		cout<<"\nHeight of the tree:"<<t.height(t.root);
		break;
	    }
	    case 8:
	    {
		int i;
		cout<<"\nEnter the element:";
		cin>>i;
		cout<<"\nBalance:"<<t.balance(t.getnode(i));
		break;
	    }
	    case 9:
	    {
		int i;
		cout<<"\nEnter the element to be deleted:";
		cin>>i;
		t.remove(i);
		break;
	    }
	    default:
		ch=20;
	}
    }
}	
