/*****Infix to postfix convertor and evaluator 1.0**
 By Deepak<deepak-p@eth.net> and
    Sandeep<sandeep_potty@yahoo.com>
    Release Date:14-09-2001
****************************************************/
# include <stdio.h>
# include <string.h>

/************Block for in2post conversion*******************/
float stack[50],len;
char post[100],t[10];

int icp(char a)
{
	switch(a)
	{
		case '(':return 3;
		case '*':return 2;
		case '/':return 2;
		case '+':return 1;
		case '-':return 1;
		default :return 0;
	}
	//Unreachable portion of code
}
int isp(char a)
{
	switch(a)
	{
		case '(':return 0;
		case '*':return 2;
		case '/':return 2;
		case '+':return 1;
		case '-':return 1;
		case '$':return -1;
		default:return -1;
	}
	//Unreachable portion of the code
}

void initstack()
{
	stack[0]='$';
	len=1;
}
void push(float a)
{
	stack[len]=a;
	len++;
}
void pop()
{
	if(stack[len-1]!=')'&& stack[len-1]!='(')
	{
		sprintf(t,"%c",(char)stack[len-1]);
		strcat(post,t);
	}
	len--;
}
char stackop()
{
	return stack[len-1];
}
void emptystack()
{
	while(len>1)
		pop();
}
int isop(char a)
{
	if(a=='*'||a=='+'||a=='/'||a=='-'||a=='(')
		return 1;
	if(a==')')return 1;
	return 0;
}

void in2post(char *expr) //Converts infix to postfix and stores the result in post(global variable)
{
	int i=0;
	initstack();
	post[0]='\0';
	while(i<strlen(expr))
	{
		while(expr[i]==' ')i++;
		if(isop(expr[i])==1)
		{
			if(expr[i]==')')
			{
				while(stackop()!='(')pop();
				pop();
			}
			else if(icp(expr[i])>isp(stackop()))
			{
				push(expr[i]);
			}
			else
			{
				pop();
				push(expr[i]);
			}
		}
		else
		{
			sprintf(t,"%c",expr[i]);
			strcat(post,t);
		}
		i++;
	}
	emptystack();
}
/************Block for evaluation**********************/
float popper()
{
	len--;
	return stack[len];
}
float calcval(char a)
{
	switch(a)
	{
		case '+':return popper()+popper();
		case '*':return popper()*popper();
		case '-':return (-1)*(popper()-popper());
		case '/':return 1/(popper()/popper());
	}
	return -1;
}
float evaluate(char *p)
{
	int i=0;
	float temp;
	initstack();
	while(i<strlen(p))
	{
		if(isop(p[i])==1)
		{
			temp=calcval(p[i]);
			push(temp);
		}
		else
		{
			printf("\nEnter value for '%c':",post[i]);
			scanf("%f",&temp);
			push(temp);
		}
		i++;
	}
	if(len!=2)printf("\nError...");
	return stack[1];
}
/********End of all functions only main remaining*************/
void intro()
{
	printf("\nInfix to postfix convertor and evaluator 1.0");
	printf("\nThis converts an infix expression to postfix and evaluates it");
	printf("\nEnter the infix expression in variables e.g.,(r+t*b) etc and do not use numbers");
	printf("\nYou will be prompted to enter the values afterwards");
	printf("\nBy\nDeepak <deepak-p@eth.net> and \nSandeep <sandeep_potty@yahoo.com>");
	printf("\n\n");
}

main()
{
	char in[100];
	clrscr();
	intro();
	printf("\nEnter infix expression:");gets(in);
	in2post(in);
	printf("\nEquivalent Postfix expression:%s",post);
	printf("\n\n");
	printf("\nThe result is %.3f",evaluate(post));
	return 0;
}