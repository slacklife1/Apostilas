void insertionsort(int a[],int n)
{
	int i,j,t;
	for(i=1;i<n;i++)
	{
		t=a[i];
		for(j=(i-1);j>=0;j--)
		{
			if(a[j]>t)
			{
				a[j+1]=a[j];
			}
			else
			{
				break;
			}
		}
		a[j+1]=t;
	}
	return;
}
