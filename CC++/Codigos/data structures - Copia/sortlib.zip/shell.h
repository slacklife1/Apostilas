void shellsort(int a[],int n,int b)
{
	int i,j,k,t;
	for(k=0;k<b;k++)
	{
		for(i=k;i<n;i+=b)
		{
			t=a[i];
			for(j=(i-b);j>=0;j-=b)
			{
				if(a[j]>t)
				{
					a[j+b]=a[j];
				}
				else
				{
					break;
				}
			}
			a[j+b]=t;
		}
	}
	return;
}
