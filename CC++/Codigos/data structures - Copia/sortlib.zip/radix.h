void radixsort(int a[],int n)
{
	int i=1,j,t,k;
	int b[10][100];
	int bc[10];
	while(1)
	{
		for(j=0;j<10;j++)bc[j]=0;
		for(j=0;j<n;j++)
		{
			t=a[j]/i;
			while(t>9)t/=10;
			b[t][bc[t]]=a[j];
			bc[t]++;
		}
		if(bc[0]==n)break;
		t=0;
		for(j=0;j<10;j++)
		{
			for(k=0;k<bc[j];k++)
			{
				a[t]=b[j][k];
				t++;
			}
		}
		i*=10;
	}
	return;
}
