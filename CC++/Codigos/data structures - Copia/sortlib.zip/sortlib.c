/*
SortLib 1.01
A collection of sorting algorithm implementations
By Deepak <deepak-p@eth.net>
26-Mar-2002
*/

# include "radix.h"  //for module radixsort(int[],int)
# include "merge.h"  //for module mergesort(int[],int) &
		     //           mergesort_norec(int[],int)
# include "insert.h" //for module insertionsort(int[],int)
# include "select.h" //for module selectionsort(int[],int)
# include "quick.h"  //for module quicksort(int[],int)
# include "shell.h"  //for module shellsort(int[],int,int)

/* All functions mentioned above that take
int[] and int are to be supplied with the
int array and length of the array respectively.
mergesort_norec(int[],int) does mergesort without recursion
shellsort() has to be supplied with the third parameter
which is the seed or index of shellsort.*/

int main()
{
	int i,n,ch,t;
	int a[20];
	clrscr();
	printf("\nEnter number of numbers:");scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("\nEnter:");scanf("%d",&a[i]);
	}
	ab:
	clrscr();
	printf("\n1.QuickSort");
	printf("\n2.MergeSort");
	printf("\n3.MergeSort without recursion");
	printf("\n4.InsertionSort");
	printf("\n5.SelectionSort");
	printf("\n6.RadixSort");
	printf("\n7.ShellSort");
	printf("\n8.Exit\n");
	ch=getch()-'0';
	switch(ch)
	{
		case 1:
			quicksort(a,n);
			break;
		case 2:
			mergesort(a,n);
			break;
		case 3:
			mergesort_norec(a,n);
			break;
		case 4:
			insertionsort(a,n);
			break;
		case 5:
			selectionsort(a,n);
			break;
		case 6:
			radixsort(a,n);
			break;
		case 7:
			printf("\nEnter index for shellsort:");
			scanf("%d",&t);
			shellsort(a,n,t);
			break;
		case 8:
			exit(0);
	}
	clrscr();
	printf("\nDisplaying sorted");
	for(i=0;i<n;i++)
	{
		printf("\n%d",a[i]);
	}
	getch();
	goto ab;
	return;
}
