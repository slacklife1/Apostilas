void merge(int a[],int st,int m,int o)
{
	int i=0,j=0,k;
	int *c=(int *)malloc((m+o)*sizeof(int));
	for(k=0;k<(m+o);k++)
	{
		if(i==m)
		{
			c[k]=a[st+m+j];
			j++;
		}
		else if((j==o)||a[st+i]<a[st+m+j])
		{
			c[k]=a[st+i];
			i++;
		}
		else
		{
			c[k]=a[st+m+j];
			j++;
		}
	}
	for(k=0;k<(m+o);k++)
	{
		a[st+k]=c[k];
	}
	return;
}
void mergesort_norec(int a[],int n)
{
	int i=1,j,t,l;
	while(i<n)
	{
		t=(n/i);
		l=0;
		j=0;
		if((t*i)<n)
		{
			l=n-(t*i);
		}
		while(j<t)
		{
			if(j==(t-1))
			{
				merge(a,j*i,i,l);
			}
			else
			{
				merge(a,j*i,i,i);
			}
			j+=2;
		}
		i*=2;
	}
	return;
}
void mergsort(int a[],int st,int m)
{
	int t;
	if(m==1)
	{
		return;
	}
	else
	{
		t=m/2;
		mergsort(a,st,t);
		mergsort(a,st+t,m-t);
		merge(a,st,t,m-t);
		return;
	}
}
void mergesort(int a[],int n)
{
	mergsort(a,0,n);
	return;
}