int returnlargest(int a[],int c)
{
	int i,j=0;
	for(i=0;i<c;i++)
	{
		if(a[i]>a[j])
		{
			j=i;
		}
	}
	return j;
}
void swap(int a[],int c,int d)
{
	int t=a[c];
	a[c]=a[d];
	a[d]=t;
}
void selectionsort(int a[],int n)
{
	int i;
	for(i=(n-1);i>=0;i--)
	{
		swap(a,i,returnlargest(a,i+1));
	}
}
