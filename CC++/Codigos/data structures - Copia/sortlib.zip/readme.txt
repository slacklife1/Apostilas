SortLib 1.01
A collection of sorting algorithm implementations 
By Deepak
26-Mar-2002

 SortLib is a collection of sorting algorithm implementations.
It currently features the following sorting algorithms.
************************
  QuickSort
  MergeSort
  MergeSort without recursion
  InsertionSort
  SelectionSort
  RadixSort
  ShellSort
************************

I wanted to give just the header files with the necessary functions
but then i thought it would be nice to include an implementation.
So i wrote the sortlib.c file.
The EXE compiled in Turbo C++ v1.01 for MS-DOS has also been included.

Do mail me at deepak-p@eth.net if you want any further help with 
with regard to sortlib libraries.

AcmeSofties
Deepak and Sandeep.
