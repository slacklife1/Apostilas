/*****
HuffDec 1.0
Member of HuffPack 1.0
By Deepak and Sandeep
*/


/*# include */
# include <stdio.h>
# include <stdlib.h>
# include <io.h>


/*Global variable declarations ***/
struct node
{
	unsigned char c;
	unsigned long int freq;
	struct node *up,*left,*right;
};
struct ftable
{
	unsigned long int freq;
};
struct ftable ft;
struct node leaf[256];
struct node *t[256];
struct node *a,*b;
int i,j,k;
int buf[50],bc;
int buft[20],bct;
int buftv[20];
unsigned char q;
long int y=0;/*For debugging*/

/*Function prototype declarations*/
int getzero();
int sortt(int);
int maketree();
void init();
int retrieveft(char *);
void add2buff(int);
void refreshbuffer(FILE *);
//#include "h.h"

int getzero()
{
	int h=0;
	for(i=0;i<256;i++)
	{
		if(leaf[i].freq==0)
			h++;
	}
	return (255-h);
}


int sortt(int z)/*sorts upto t[z] and not t[z-1]*/
{
	for(k=0;k<=z;k++)
	for(j=(k+1);j<=z;j++)
	{
		if((t[k]->freq)<(t[j]->freq))
		{
			/*b=NULL;*/
			b=t[k];
			t[k]=t[j];
			t[j]=b;
		}
	}
	return 0;
}

int maketree()
{
	struct node *a;
	sortt(255);
	for(i=getzero();i>0;i--)
	{
		sortt(i);
		a=NULL;
		a=(struct node *)malloc(sizeof(struct node));
		if(a==NULL)
		{
			printf("\nMemory allocation error...");
			getch();
			return -1;  /*Memory allocation error*/
		}
		/*Assingning values*/
		a->freq=(t[i]->freq)+(t[i-1]->freq);
		a->right=t[i];
		a->left=t[i-1];
		a->up=NULL;
		a->c='\0';
		t[i]->up=a;
		t[i-1]->up=a;
		/*Changing the pointer*/
		t[i-1]=a;
	}
	return 0;
}
void init()
{
	int i;
	for(i=0;i<256;i++)
	{
		leaf[i].c=(unsigned char)i;
		leaf[i].freq=0;
		leaf[i].up=NULL;
		leaf[i].left=NULL;
		leaf[i].right=NULL;
		t[i]=&leaf[i];
	}
	for(i=0;i<256;i++)
	{
		t[i]=&leaf[i];
	}
	return;
}

int retrieveft(char *filename)
{
	FILE *p;
	p=fopen(filename,"rb");
	if(p==NULL)
	{
		return -1;/*Could not open file */
	}
	for(i=0;i<256;i++)
	{
		fread(&ft,sizeof(struct ftable),1,p);
		leaf[i].c=(unsigned char)i;
		leaf[i].freq=ft.freq;
		leaf[i].up=NULL;
		leaf[i].right=NULL;
		leaf[i].left=NULL;
	}
	fclose(p);
	return 0;
}
void add2buff(int c)
{
	bct=-1;
	while(c!=0)
	{
		buft[++bct]=(c%2);
		c/=2;
	}
	for(i=(bct+1);i<8;i++)
	{
		buft[i]=0;
	}
	for(i=(0);i<8;i++)
	{
		buftv[7-i]=buft[i];
	}
	for(i=0;i<8;i++)
	{
		buf[bc+i]=buftv[i];
	}
	bc+=8;
}

void refreshbuffer(FILE *p)
{
	int count=0,j,i;
	//int bcbak=bc;
	a=t[0];i=0;
	for(i=0;i<=bc;i++)
	{
		if(a->left==NULL && a->right==NULL)
		{
			fputc(a->c,p);
			/*For debugging*/
			y++;
			/*debugging over*/
			for(j=count;j<bc;j++)
			{
				buf[j-count]=buf[j];
			}
			bc-=count;
			//i=0;
			count=0;
			a=t[0];
		}
		else if(buf[count]==0)
		{
			a=a->left;
			count++;
			//i++;
		}
		else if(buf[count]==1)
		{
			a=a->right;
			count++;
			//i++;
		}
		else
		{
			printf("\nError");
		}
	}
	return;
}


main()
{
	char filename[100],outfile[100];
	FILE *p,*q;
	int ch,ct;
	long int filelen,count=1024;
	clrscr();
	printf("\nHuffDec 1.0 Member of HuffPack 1.0\n");
	printf("\nFile decompressor for files compressed with HuffEnc");
	printf("\nBy Deepak & Sandeep\n");
	printf("\nEnter the filename:");scanf("%s",filename);
	init();
	if(retrieveft(filename)==-1)
	{
		printf("\nCould not open file");
		return -1;
	}
	maketree();
	/*To retrieve the filename from the compressed file*/
	p=fopen(filename,"rb");
	fseek(p,1024,SEEK_SET);
	ct=fgetc(p);
	fread(outfile,ct,1,p);
	/***Filename retrieval finished*/
	p=fopen(filename,"rb");
	/***check for user renaming of output file*/
	printf("\nThe specified archive contains a compressed file called %s",outfile);
	printf("\nYou may choose to create this file or specify a name for the file to be created");
	printf("\nSpecify a name for the output file(y/any other key):");
	if(tolower(getch())=='y')
	{
		printf("\n\nEnter name for file to be created:");scanf("%s",outfile);
	}
	/******check for renaming complete*****/
	q=fopen(outfile,"wb");
	if(q==NULL || p==NULL)
	{
		printf("\nCould not open one or more files");
		fcloseall();
		return -1;
	}
	fseek(p,256*sizeof(struct ftable)+1+ct,SEEK_SET);
	filelen=filelength(fileno(p));
	count=1024+1+ct;
	printf("\n\nInitialization over.\nPreparing to decompress..");
	printf("\nDecompressing....");
	while(ch=fgetc(p),count++,ch!=EOF)
	{
		if(count==(filelen-1))
		{
			add2buff(ch);
			bc-=8;
			bc+=fgetc(p);
			refreshbuffer(q);
			while(bc!=0)
			{
				refreshbuffer(q);
			}
		}
		else
		{
			add2buff(ch);
			refreshbuffer(q);
		}
	}
	printf("\nDecompression complete.\n");
	printf("\nCreated output file %s ",outfile);
	printf("\n\nThank you.");
	return 0;
}



