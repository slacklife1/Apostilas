/* This program was written by Sandeep.P */
/* The program can be freely modified and redistributed */
		     /* File Attribute Manipulator */

#include <stdio.h>
#include <dos.h>


display(char *fname)
{
 FILE *fp;
 if((fp=fopen(fname,"rb"))==NULL)
  {
   printf("Error opening input file %s",fname);
   exit();
  }
 gotoxy(1,3);
 printf("FILENAME : %s",fname);
 gotoxy(1,5);
 printf("SIZE : %ld bytes",(long)filelength(fileno(fp)));
 gotoxy(30,8);
 printf("FILE ATTRIBUTES");
 gotoxy(28,9);
 printf("��������������������");
 gotoxy(28,12);
 printf("Read only : ");
 gotoxy(28,13);
 printf("Hidden    : ");
 gotoxy(28,14);
 printf("System    : ");
 gotoxy(28,15);
 printf("Archive   : ");
 fclose(fp);
}

writeatt(int a)  /* fuction displays current attributes */
{
 gotoxy(40,12);
 if((a&1)==0)
   printf("OFF");
 else
   printf("ON");
  gotoxy(40,13);
 if((a&2)==0)
   printf("OFF");
 else
   printf("ON");
 gotoxy(40,14);
 if((a&4)==0)
   printf("OFF");
 else
   printf("ON");
 gotoxy(40,15);
 if((a&32)==0)
   printf("OFF");
 else
   printf("ON");
}

int changeatt(int a)              /* function to change attributes of file */
{
 char ch;
 gotoxy(45,12);
 printf("CHANGE(Y/N) :");
 scanf("%c",&ch);
 if(ch=='y' || ch=='Y')
 a=(a^1);
 fflush(stdin);
 gotoxy(45,13);
 printf("CHANGE(Y/N) :");
 scanf("%c",&ch);
 if(ch=='y' || ch=='Y')
 a=(a^2);
 fflush(stdin);
 gotoxy(45,14);
 printf("CHANGE(Y/N) :");
 scanf("%c",&ch);
 if(ch=='y' || ch=='Y')
 a=(a^4);
 fflush(stdin);
 gotoxy(45,15);
 printf("CHANGE(Y/N) :");
 scanf("%c",&ch);
 if(ch=='y' || ch=='Y')
 a=(a^32);
 fflush(stdin);
 return(a);
}

write_error_message(int c)     /* error check */
{
 gotoxy(1,22);
 switch(c)
 {
   case 2:
	  printf("File not found ");
	  break;
   case 3:
	  printf("Invalid path ");
	  break;
   case 5:
	  printf("Access denied ");
	  break;
   case 0x11:
	  printf("Invalid drive name ");
	  break;
   default:
	  printf("Invalid request ");
	  break;
  }
  getch();
}

void main()
{
 char filename[30];
 union REGS i,o;
 int old,new;
 clrscr();
 printf("\nAttFile 1.0 - File Attribute Manipulator");
 printf("\nBy Sandeep <sandeep_potty@yahoo.com>\n\n");
 printf("Enter the filename : ");
 gets(filename);
 clrscr();
 display(filename);
 i.h.ah=67;
 i.h.al=0;
 i.x.dx=(unsigned int)filename;
 intdos(&i,&o);

 if(o.x.cflag==0)
  {
   old=new=o.x.cx;      /* collect current attribute byte in old */
   writeatt(old);
  }
 else
  write_error_message(o.x.ax);

 new=changeatt(new);
 i.h.ah=67;
 i.h.al=1;
 i.x.cx=new;
 i.x.dx=(unsigned int)filename;
 intdos(&i,&o);

 if(o.x.cflag==0)          /* error check */
  {
   clrscr();
   display(filename);
   writeatt(new);
   getch();
  }
 else
  {
   gotoxy(1,22);
   printf("Error-New attributes not set ");
  }
}
