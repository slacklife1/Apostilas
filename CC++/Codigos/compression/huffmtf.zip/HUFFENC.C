/*****
HuffEnc 1.0
Member of HuffPack 1.0
By Sandeep and Deepak
*/



/*# include */
# include <stdio.h>
# include <stdlib.h>
# include <dir.h>
# include <io.h>


/*Global variable declarations ***/
struct node
{
	unsigned char c;
	unsigned long int freq;
	struct node *up,*left,*right;
};
struct ftable
{
	unsigned long int freq;
};
struct ftable ft;
struct node leaf[256];
struct node *t[256];
struct node *a,*b;
int i,j,k;
int buf[50],bc;
int buft[15],bct;
int buftv[15];
unsigned char q;


/*Function prototype declarations*/
int init(char *);
int sortt(int);
int maketree();
void add2buff(int);
void refreshbuffer(FILE *);
int nodecmp(struct node *,struct node *);
int nodecpy(struct node *,struct node *);
int getzero();
unsigned char oddchar();
char *getname(char *);



int getzero()
{
	int h=0;
	for(i=0;i<256;i++)
	{
		if(leaf[i].freq==0)
			h++;
	}
	return (255-h);
}
char *getname(char *filepath)
{
	char drive[4],dir[67],file[15],ext[5];
	fnsplit(filepath,drive,dir,file,ext);
	strcat(file,ext);
	return file;
}

unsigned char oddchar()
{
	for(i=bc;i<8;i++)
	{
		buf[i]=0;
	}
	return ((1*buf[7])+(2*buf[6])+(4*buf[5])+(8*buf[4])+(16*buf[3])+(32*buf[2])+(64*buf[1])+(128*buf[0]));
}

int nodecmp(struct node *a,struct node *b)
{
	if(a->c==b->c && a->freq==b->freq && a->up==b->up &&a->left==b->left && a->right==b->right)
		return 0;
	return -1;
}

int nodecpy(struct node *a,struct node *b)
{
	a->c=b->c;
	a->freq=b->freq;
	a->up=b->up;
	a->left=b->left;
	a->right=b->right;
	return 0;
}

int init(char *filename)
{
	FILE *p;
	for(i=0;i<256;i++)
	{
		leaf[i].c=i;
		leaf[i].freq=0;
		leaf[i].up=NULL;
		leaf[i].left=NULL;
		leaf[i].right=NULL;
	}
	p=fopen(filename,"rb");
	if(p==NULL)
	{
		return -1; /*Could not open file */
	}
	while(j=fgetc(p),j!=EOF)
	{
		leaf[j].freq++;
		if(j<0 || j>255)
		{
			printf("\nError...");
                        getch();
		}
	}
	fclose(p);
	for(i=0;i<256;i++)
	{
		t[i]=&leaf[i];
		if((t[i]->up)!=NULL)
		{
			printf("\nError..");
			getch();
		}
	}
	bc=0;  /*Setting the global buffer counter to 0*/
	return 0;
}

int sortt(int z)/*sorts upto t[z] and not t[z-1]*/
{
	for(k=0;k<=z;k++)
	for(j=(k+1);j<=z;j++)
	{
		if((t[k]->freq)<(t[j]->freq))
		{
			//b=NULL;
			b=t[k];
			t[k]=t[j];
			t[j]=b;
		}
	}
	return 0;
}

int maketree()
{
	sortt(255);
	for(i=getzero();i>0;i--)
	{
		sortt(i);
		a=NULL;
		a=(struct node *)malloc(sizeof(struct node));
		if(a==NULL)
		{
			printf("\nMemory allocation error...");
			getch();
			return -1;  /*Memory allocation error*/
		}
		/*Assingning values*/
		a->freq=(t[i]->freq)+(t[i-1]->freq);
		a->right=t[i];
		a->left=t[i-1];
		a->up=NULL;
		a->c='\0';
		t[i]->up=a;
		t[i-1]->up=a;
		/*Changing the pointer*/
		t[i-1]=a;
	}
	return 0;
}

void add2buff(int r)
{
	bct=-1;
	if(r>255 || r<0)
	{
		printf("\nValue error...");
		getch();
	}
	a=&leaf[r];
	while((a->up)!=NULL)
	{
		if(nodecmp((a->up->left),a)==0)
		{
			buft[++bct]=0;
		}
		else if(nodecmp((a->up->right),a)==0)
		{
			buft[++bct]=1;
		}
		else
		{
			printf("\nParent Error");  /*For debugging*/
		}
		a=a->up;
	}
	for(i=0;i<=bct;i++)
	{
		buftv[bct-i]=buft[i];
	}
	for(i=0;i<=bct;i++)
	{
		buf[bc+i]=buftv[i];
	}
	bc=bc+bct+1;
	return;  /*Successful completetion of function*/
}

void refreshbuffer(FILE *p)
{
	while(bc>=8)
	{
		q=(1*buf[7])+(2*buf[6])+(4*buf[5])+(8*buf[4])+(16*buf[3])+(32*buf[2])+(64*buf[1])+(128*buf[0]);
		if(fputc(q,p)!=(unsigned)q || q<0 || q>255)printf("\nError");
		for(i=8;i<bc;i++)
		{
			buf[i-8]=buf[i];
		}
		bc-=8;
	}
}

main(int argc,char *argv[])
{
	FILE *p,*q;
	int ch;
	char filename[100],encfile[100];
	long int filesize,encfilesize;
	float ratio;
	printf("\nHuffEnc 1.0");
	printf("\nData compression by the Huffman algorithm");
	printf("\nBy Sandeep & Deepak\n");
	if(argc>=3)
	{
		strcpy(filename,argv[1]);
		strcpy(encfile,argv[2]);
	}
	else
	{
		clrscr();
		printf("\nThis version of HuffEnc is a companion of HuffMFT 1.0");
		printf("\nFor a stand alone version visit http://www.geocities.com/deepsofties");
		return 1;
	}
	if(init(filename)==-1)
	{
		printf("\nError Could not open input file..");
		fcloseall();
		return -1;
	}
	printf("\nInitialization over.\nPreparing to compress...");
	if(maketree()==-1)
	{
		printf("\nMemory allocation error..");
		fcloseall();
		return -1;
	}
	q=fopen(encfile,"wb");
	if(q==NULL)
	{
		printf("\nError Could not open output file..");
		fcloseall();
		return -1;
	}
	p=fopen(filename,"rb");
	if(p==NULL)
	{
		printf("\nError Could not open input file...");
		fcloseall();
		return -1;
	}
	filesize=filelength(fileno(p));
	/****To write the decoding table */
	/*To write the character that denotes the size of filenamelength*/
	fputc(strlen(getname(argv[3]))+1,q);
	/*To write the filename*/
	fwrite(getname(argv[3]),strlen(getname(argv[3]))+1,1,q);
	for(i=0;i<256;i++)
	{
		ft.freq=leaf[i].freq;
		fwrite(&ft.freq,sizeof(struct ftable),1,q);
	}
	/***Completed writing of decoding table*****/
	printf("\nCompressing...");
	while(ch=fgetc(p),ch!=EOF)
	{
		add2buff(ch);
		refreshbuffer(q);
	}
	fputc(oddchar(),q);
	fputc(bc,q);
	fcloseall();
	return 0;
}





