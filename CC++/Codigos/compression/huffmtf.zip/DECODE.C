/*****HuffMTF 1.0
Deepak <deepak-p@eth.net>
*/


# include <process.h>
# include <stdio.h>

main(int argc,char *argv[])
{
	char infile[20],outfile[20];
	FILE *p;int ct;
	char string[300];
	clrscr();
	printf("HuffMTF Decoder 1.0 - DECODE.EXE\n");
	if(argc<2)
	{
		printf("\nEnter input filename:");scanf("%s",infile);
	}
	else
	{
		strcpy(infile,argv[1]);
	}

	/*****Filename manipulation*************/
	p=fopen(infile,"rb");
	if(p==NULL)
	{
		printf("\nCould not open input file.Aborting operation");
		return 1;
	}
	ct=fgetc(p);
	fread(outfile,ct,1,p);
	fclose(p);
	if(ct<14 && argc<3)
	{
		printf("\nThis file has in it an encoded file named %s",outfile);
		printf("\nYou may choose to create this output file or specify another name");
		printf("\nSpecify another name(y/any other key):");
		if(tolower(getch())=='y')
		{
			printf("\nEnter new filename:");
			scanf("%s",outfile);
		}
	}
	else if(argc>=3)
	{
		strcpy(outfile,argv[2]);
	}
	else
	{
		printf("\nEnter a name for the output file:");
		scanf("%s",outfile);
	}
	/*******Filename manipulation over,at last....!!!!*******/
	sprintf(string,"HUFFDEC.EXE %s TEMP.TMP",infile);
	printf("\n\nHanding over control to Huffman Decompressor");
	printf("\nHuffman decompression done by HuffDec 1.0 - Member of HuffPack 1.0\n");
	system(string);
	printf("\nHuffDec has completed it's operation.");
	sprintf(string,"UNMTF.EXE TEMP.TMP %s",outfile);
	printf("\n\nHanding over control to MTF Decoder");
	printf("\nMTF Decoding done by UnMTF 1.0\n");
	system(string);
	printf("\nMTF decoding complete.");
	unlink("TEMP.TMP");
	printf("\n\nOutput File %s created",outfile);
	printf("\nExecution of HuffMTF complete...");
	return 0;
}
