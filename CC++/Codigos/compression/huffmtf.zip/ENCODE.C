/***HuffMTF 1.0
Deepak <deepak-p@eth.net>
*/

# include <process.h>
# include <io.h>
# include <stdio.h>

main(int argc,char *argv[])
{
	char infile[20],outfile[20];
	char string[300];
	long filelen1,filelen2;
	FILE *p;
	clrscr();
	printf("HuffMTF Encoder 1.0 - ENCODE.EXE\n");
	if(argc<3)
	{
		printf("\nEnter input filename(to be compressed):");scanf("%s",infile);
		printf("\nEnter output filename(compressed file):");scanf("%s",outfile);
	}
	else
	{
		strcpy(infile,argv[1]);
		strcpy(outfile,argv[2]);
	}
	sprintf(string,"MTF.EXE %s TEMP.TMP",infile);
	printf("\n\nHanding over control to MTF Encoder");
	printf("\nMTF Encoding done by MTF 1.0\n");
	system(string);
	printf("\nMTF encoding complete.");
	sprintf(string,"HUFFENC.EXE TEMP.TMP %s %s",outfile,infile);
	printf("\n\nHanding over control to Huffman Compressor");
	printf("\nHuffman compression done by HuffEnc 1.0 - Member of HuffPack 1.0\n");
	system(string);
	printf("\nHuffEnc has completed it's operation.");
	unlink("TEMP.TMP");
	printf("\n\nOutput File %s created",outfile);
	printf("\nExecution of HuffMTF complete...");
	p=fopen(infile,"rb");filelen1=filelength(fileno(p));fclose(p);
	p=fopen(outfile,"rb");filelen2=filelength(fileno(p));fclose(p);
	printf("\n\nCompression Summary");
	printf("\nInput File Size:%ld",filelen1);
	printf("\nOutput File Size:%ld",filelen2);
	printf("\nCompressed to %.1f%% of original size",(float)(filelen2*100/filelen1));
	return 0;
}
