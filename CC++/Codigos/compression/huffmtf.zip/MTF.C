/****MTF Encoder 1.0
Deepak <deepak-p@eth.net>
*/


# include <stdio.h>
# include <time.h>

/*Globals*/
int array[256];

void initarray()
{
	int i;
	for(i=0;i<256;i++)
	{
		array[i]=i;
	}
	return;
}
int getposition(int ch)
{
	int i;
	for(i=0;i<256;i++)
	{
		if(array[i]==ch)
			return i;
	}
	return -1;
}
void move2front(int i)
{
	int j,temp=array[i];
	for(j=i;j>0;j--)
	{
		array[j]=array[j-1];
	}
	array[0]=temp;
	return;
}

main(int argc,char *argv[])
{
	int ch;
	int t;
	char outfile[20],infile[20];
	FILE *out,*in;
	printf("\nMTF 1.0 Move To Front Encoder");
	printf("\nBy Deepak");
	initarray();
	if(argc>=3)
	{
		strcpy(infile,argv[1]);
		strcpy(outfile,argv[2]);
	}
	else
	{
		clrscr();
		printf("\nThis is a companion file of HuffMTF 1.0");
		printf("\nand not to be used alone");
		return 1;
	}
	in=fopen(infile,"rb");
	out=fopen(outfile,"wb");
	if(in==NULL || out==NULL){fclose(in);fclose(out);return 1;}
	printf("\nMTF Encoding starts...");
	while(ch=fgetc(in),ch!=EOF)
	{
		t=getposition(ch);
		if(t==-1)printf("\nError...");
		fputc(t,out);
		if(t!=0){move2front(t);}
	}
	fclose(in);
	fclose(out);
	return 0;
}
