#include <stdio.h>

void stripend(char s[],char o[],int start,int end)    /* function to omit required number of lines */
{
 int count=0;
 FILE *p1,*p2;
 int c;
 p1=fopen(s,"r");
 if(p1==NULL)
  {
   printf("\nERROR :: Error opening input file %s",s);
   exit();
  }
 p2=fopen(o,"w");
 if(p2==NULL)
  {
   printf("\nERROR ::Error creating output file %s",o);
   exit();
  }
 while((c=fgetc(p1))!=EOF)
  {
   if(c=='\n')count++;
   if(count<start || count>end)
    {
     if(c=='\n')
       fprintf(p2,"\n");
     else
      fprintf(p2,"%c",(char)c);
    }
  }
 fcloseall();
 printf("\nSTRFILE ::The File Stripper Utility-> Details Of Strip");
 printf("\n====================================================");
 printf("\nInput file :: %s",s);
 printf("\nOutput file :: %s",o);
 printf("\nNumber of lines truncated ::,%d",end-start+1);
 printf("\nNumber of lines in Output file :: %d",count-(end-start));
}


void main(int argc,char *argv[])
{
 if (argc<4)
  {
   printf("Strpline 1.0\nBy Sandeep <sandeep_potty@yahoo.com>");
   printf("\n\nThis program is used to strip the specified number of");
   printf("\nlines from a text file.Options are given within brackets");
   printf("\n\nFormat example:: c:\strfile inputfile outputfile [start] end");
   printf("\nc:\strfile x.c y.c 20");
   printf("\nThis strips the first 20 lines from the program");
   printf("\nc:\strfile x.c y.c 20 40");
   printf("\nThis strips lines from 20 to 40. ");
   exit();
  }
 if(argc<5)
  stripend(argv[1],argv[2],0,atoi(argv[3]));
 else
  stripend(argv[1],argv[2],atoi(argv[3]),atoi(argv[4]));
}





