/*********************File Lister 1.0********************
This lists all the files in the directory specified  with
in the command line and does so with  the current working
directory as default.It takes command line arguments that
specify the path and type of files to be listed.The  path
has to be a DOS path and may or may not include DOS  wild
cards such as * or ?.The second command line argument may
be l,h,s,d,a or r to include volume label, hidden  files,
system files directories archive files or read only files
respectively in the list.But it does not specify  an  the
attribute of the listed files.This can quite be something
which tha public domain can look into.The directories are
listed as files.Please work on this program.This compiled
under Turbo C++ 1.01
Please do send me the improved versions.
Deepak,Computer Engg Student,Kerala,India.
deepak-p@eth.net
********************************************************/
# include <dir.h>
# include <io.h>
# include <dos.h>

union f
{
	int a[2];
	struct ftime b;
}c;
int getdiskno(char a[])
{
	if(a[1]==':')
		return(tolower(a[0])-'a'+1);
	return (getdisk()+1);
}
long int ret(int a)
{
	struct dfree b;
	getdfree(a,&b);
	return (long int)((long int)(b.df_avail)*(long int)(b.df_sclus)*(long int)(b.df_bsec));
}

int countdig(long int a)
{
	int count=0;
	if(a==0)return 1;
	while(a!=0)
	{
		a=a/10;
		count++;
	}
	return count;
}

main(int argc,char *argv[])
{
	int count=0,mode=0,i;
	long int totsize=0;
	struct ffblk a;
	char string[15];
	if(argc>=2)
		strcpy(string,argv[1]);
	else
		strcpy(string,"*.*");
	if(argc>=3)
	{
		if(strcmp(argv[2],"r")==0)
			mode=FA_RDONLY;
		if(strcmp(argv[2],"h")==0)
			mode=FA_HIDDEN;
		if(strcmp(argv[2],"d")==0)
			mode=FA_DIREC;
		if(strcmp(argv[2],"s")==0)
			mode=FA_SYSTEM;
		if(strcmp(argv[2],"a")==0)
			mode=FA_ARCH;
		if(strcmp(argv[2],"l")==0)
			mode=FA_LABEL;
	}
	//clrscr();
	if(findfirst(string,&a,mode)!=0)
	{
		printf("\nCould not find a file to match your criterion\n");
		exit(0);
	}
	count++;
	printf("\nListing files...\n");
	totsize+=a.ff_fsize;
	printf("\n%s",a.ff_name);
	for(i=0;i<(15-strlen(a.ff_name));i++)
		printf(" ");
	printf("%ld",a.ff_fsize);
	c.a[0]=a.ff_ftime;
	c.a[1]=a.ff_fdate;
	for(i=0;i<(10-countdig(a.ff_fsize));i++)
		printf(" ");
	if(c.b.ft_day<10)printf("0");
	printf("%u-",c.b.ft_day);
	if(c.b.ft_month<10)printf("0");
	printf("%u-%u",c.b.ft_month,c.b.ft_year+1980);
	printf("  ");
	if(c.b.ft_hour<10)printf("0");
	printf("%u:",c.b.ft_hour);
	if(c.b.ft_min<10)printf("0");
	printf("%u:",c.b.ft_min);
	if(c.b.ft_tsec<10)printf("0");
	printf("%u",c.b.ft_tsec);
	while(findnext(&a)==0)
	{
		count++;
		printf("\n%s",a.ff_name);
		totsize+=a.ff_fsize;
		for(i=0;i<(15-strlen(a.ff_name));i++)
			printf(" ");
		printf("%ld",a.ff_fsize);
		c.a[0]=a.ff_ftime;
		c.a[1]=a.ff_fdate;
		for(i=0;i<(10-countdig(a.ff_fsize));i++)
			printf(" ");
		if(c.b.ft_day<10)printf("0");
		printf("%u-",c.b.ft_day);
		if(c.b.ft_month<10)printf("0");
		printf("%u-%u",c.b.ft_month,c.b.ft_year+1980);
		printf("  ");
		if(c.b.ft_hour<10)printf("0");
		printf("%u:",c.b.ft_hour);
		if(c.b.ft_min<10)printf("0");
		printf("%u:",c.b.ft_min);
		if(c.b.ft_tsec<10)printf("0");
		printf("%u",c.b.ft_tsec);
		if(count%20==0)
		{
			if(count!=20)printf("\n");
			printf("\n\nListed %d files",count);
			printf("\nPress a key for next page....");
			getch();
			clrscr();
		}
	}
	printf("\n\nListed %d files\n%ld bytes in all\n",count,totsize);
	printf("\n%ld bytes available in drive %c:",ret(getdiskno(string)),'a'+getdiskno(string)-1);
	return;
}


