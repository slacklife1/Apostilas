#include <stdio.h>
#include <conio.h>
main()
{
// program for ascii chart
FILE *fb;
int ch;
fb=fopen("Ascii.xxx","w+");
clrscr();
printf("                    Ascii code generator\n\n\n\n");
printf("Open Ascii.xxx In Bin Directory To view ASCII code corresponding to charactor\n\n");
printf("press any key to continue....");

for(ch=0;ch<=255;ch++)
{
 fprintf(fb,"SCANCODE=%d,  ASCII-Ch=//%c\n\n",ch,ch);
 fprintf(fb,"******************\n");
 //printf("\n\n");
}
fclose(fb);
getch();
}