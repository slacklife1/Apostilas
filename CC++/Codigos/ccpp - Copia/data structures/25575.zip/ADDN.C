#include <stdio.h>
#include <conio.h>

main()
 {
   int i=0,n=0,value,sum=0;
   clrscr();
   printf("Enter N:");
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
    printf("Enter %d element:",i+1);
    scanf("%d",&value);
    sum=value+sum;
   }
    printf("Sum is %d ",sum);
getch();
}


