#include <stdio.h>
#include <conio.h>

main()
 {
  long int quo,a,rem,b=2,i=1,x=0;
  clrscr();
  printf("Enter a: ");
  scanf("%ld",&a);
  printf("\n\n");
  do
  {
    rem=a%b;
    quo=a/b;
    x=x+rem*i;
    i=i*10;
    a=quo;

  }while(quo!=0);
  printf("%ld",x);
  getch();
 }