#include <stdio.h>
#include <conio.h>

main()
{
 int n,count;
 float sum,term,x;
 clrscr();
 printf("Enter X:");
 scanf("%f",&x);
 //Initialize
 term=1;
 count=-1;
 n=1;
 sum=1;
for(n=1;n<=10;n+=2)
 {
  count=count*(-1);
  term=(term*(x/n))*count;
  sum=sum+term;
  printf("(%3.0f(%d)/%d!) + ",x,n-1,n);
//  n=n+1;
 }
// printf("e(x) is %f",sum);
getch();
}