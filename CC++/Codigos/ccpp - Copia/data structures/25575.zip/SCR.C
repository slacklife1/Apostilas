#include <stdio.h>
#include <conio.h>

main()
 {
  int i=0,n,j=0,asc,x,col,bcol;
  char ch;
  clrscr();
  printf("Enter Any Number The Program will convert it to character code :");
  scanf("%d",&asc);
  printf("\nEnter color:");
  scanf("%d",&col);
  printf("\nEnter background color:");
  scanf("%d",&bcol);
  clrscr();
  ch=asc;
  for(i=1;i<=25;i++)
   {
   for(j=0;j<=80;j++)
     {
      gotoxy(0,0);
      textbackground(bcol);
      textcolor(col);
      gotoxy(j,i);
      cprintf("%c",ch);
      delay(1);
     }
   }
   do
    {
     gotoxy(25,10);
     textcolor(i+=2);
     cprintf("Hi BaBy Coool Screen Yeah!!!!!!!");

     delay(50);
     }while(i==5);
   getch();
   clrscr();
 }