#include <stdio.h>
#include <conio.h>

//Program for bubble sort

main()
{
 int i,j,n,item[50],temp,last,yn=1;
 clrscr();
 printf("Enter the number of elements:");
 scanf("%d",&n);
 for(i=1;i<=n;i++)
  {
    printf("Enter element no.%d:",i);
    scanf("%d",&item[i]);
  }
 printf("You have entered the items in the form\n\n");
 for(i=1;i<=n;i++)
   printf("%d\t",item[i]);

 printf("\n\n\n");
 last=n-1;

 for(i=0 ; i < last ; i++)
  {
   for(j=0 ; j< last-i ; j++)
     {
      if(item[j] > item[j+1])
       {
	temp= item[j];
	item[j]=item[j+1];
	item[j+1]=temp;
	yn=0;
       }
    }
   if(yn=0)
   break;
   else
   yn=1;
 }
 printf("\nSorted array is\n\n");
 for(i=1;i<=n;i++)
 printf("%d\t",item[i]);
getch();
}

