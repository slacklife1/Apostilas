#include <stdio.h>
#include <conio.h>

//maximum limit of the stack
#define MAXSTACK 20
#define Flag 0

typedef char item_type;

//This is where we declare the stack where Top points to the topmost element
//in the stack and item_type is data type of item
typedef struct stack_tag
   {
    int top;
    item_type entry[MAXSTACK];
   } stack_type;

/*Function to PUSH or insert an element onto the stack*/
 void push(char item,stack_type *stack_ptr)
  {
   if(stack_ptr->top>=MAXSTACK)
     Error("Stack is Full");
   else
     stack_ptr->entry[stack_ptr->top++]=item;
  }

/*Function to POP or extract the top-most element from the stack*/
 void pop(int *item_ptr,stack_type *stack_ptr)
  {
    if(stack_ptr->top<=0)
      Error("Stack is Empty");
    else
      *item_ptr=stack_ptr->entry[--stack_ptr->top];
  }

/*Function to initialize the stac at Empty*/
 void initialize(stack_type *stack_ptr)
  {
    stack_ptr->top=0;
  }

/*Returns non-zero if stack is Empty */
 int empty(stack_type *stack_ptr)
  {
    return stack_ptr->top<=0;
  }

/*Returns non-zero if stack is Full */
 int full(stack_type *stack_ptr)
  {
    return stack_ptr->top>=MAXSTACK;
  }
/*Function to show ERROR*/
  Error(char *s)
  {
   fprintf(stderr,"%s\n",s);
   exit(1);
  }

show_stack(int item,stack_type *stack_ptr)
 {
  while(stack_ptr->top<=0)
   {
    printf("%d\n",&item);
   }
 }

main()
 {
   int a[12],i,x;
   clrscr();
   initialize(&a[0]);

   printf("Items that have been pushed are:\n",i);
   for(i=0;i<12;i++)
   {
    push(i,&a[0]);
    printf("%d\t",i);

   }

   printf("\n");
   printf("Items that have been popped are:\n",i);
   for(i=0;i<3;i++)
   {
    pop(&x,&a[0]);
    printf("%d\n",x);
    show_stack(a[i],&a[i]);

   }
/*  printf("\n Press a key...");
  getch();
  printf("\n");
  printf("Items that are left in the stack are:\n",i);
  */
  getch();
}
