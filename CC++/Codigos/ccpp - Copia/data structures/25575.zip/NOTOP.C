#include <stdio.h>
#include <conio.h>

main()
{
int a,b,c;
clrscr();
printf("                                Program To Illustrate NOT Operations\n\n");
printf("Enter A (0 OR 1): ");
scanf("%d",&a);
if(a>1 || a<0)
printf("Inavalid Input");
else
     b= !a ;
     printf("A=%d   !A=%d  ",a,b);

getch();
}