/*Program of a singularly linked list LSL*/
#include <stdio.h>
#include <conio.h>
#include <malloc.h>

typedef struct llist
{
 int item;
 struct llist *node;
}list;

list *insert(int item,list *ptr)
{
 //For a new list 'ptr' can be said as the 'head' or 'start'
 if(ptr==NULL)
 {
   ptr=(list*)malloc(sizeof(list));
   ptr->item=item;
   ptr->node=NULL;
 }
 else
  ptr->node=insert(item,ptr->node);
  return(ptr);
}

void display(list *ptr)
{

 if(ptr==NULL)
  printf("The list is empty\n");
 else
  display(ptr->node);
  printf("\n");
  printf("%d",ptr->item);
}
main()
{
 int i,n;
 list *s=NULL; //variable declaration of the type list
 clrscr();
 printf("Enter the number of element: ");
 scanf("%d",&n);
 for(i=1;i<n;i++)
 {
  printf("Enter the element number %d: ",i);
  scanf("%d",&s);
  s=insert(item,s);
 }
 display(s);
 getch();
}
