#include "vir.h"
#include <io.h>
#include <dos.h>
#include <stdio.h>
#include <stdlib.h>

Vdcl(long,primes,4096,3);				/* Declare virtual */
							/* array of longs  */

int c_break(void)					/* Close down Vfile*/
  {							/* on ^BREAK just  */
  Vstop(primes);					/* like hitting a  */
  printf("\n");						/* key so that data*/
  return 0;						/* is not lost!    */
  }							/* ^BREAK shouldn't*/
							/* be used!        */
main()
  {
  long a;
  long p;
  long n;
  ldiv_t test;
  long divsr;

  ctrlbrk(c_break);					/* Set up to handle*/
							/* ^C & ^BREAK     */

  Vinit(primes,"primes.dat",0,VCREATopt|VWRITEopt);	/* Initialize Vfile*/

  if(VErr(primes)==VFILEerr) return 4;			/* Check for error */


    {/*** Get last prime if it exists ***/
	long length;
	length=filelength(VFile(primes));		/* Check length    */
	if(length>3L)					/* If this is a    */
	  {						/* restart, get    */
	  length/=sizeof(long);				/* the last prime  */
	  p=V_(primes,length-1L)+2L;			/* number written  */
	  a=length;					/* pick up where   */
	  }						/* we left off.    */
	else						/* Otherwise,      */
	  {						/* initialize file.*/
	  p=5L;a=2L;      				/* Starting point  */
	  V_(primes,0L)=2L;				/* Seed prime 2    */
	  V_(primes,1L)=3L;				/* Seed prime 3    */
	  }
    }

  for(;p<1999999999L;p+=2)   /* Look for primes up to 2Gig... (LOTS!) */
	{
	for(n=1L;n<a;n++)				/* For each candi- */
	  {						/* date, divide by */
	  test=ldiv(p,divsr=V_(primes,n));		/* each prime up to*/
	  if(test.quot<divsr) break;			/* it's square root*/
	  if(test.rem) continue;			/* until it divides*/
	  goto COMPOSITE_NUMBER;			/* evenly. If it   */
	  }						/* divides evenly  */
							/* It is not prime!*/
	printf("%li\r",p);				/* Show each new   */
							/* prime number as */
	V_(primes,a)=p;					/* it is added to  */
	if(kbhit()) goto QUIT;				/* the array until */
	a++;						/* a key is hit.   */
							/* Stop examining  */
	COMPOSITE_NUMBER:;				/* as soon as a    */
	}						/* number proves to*/
							/* be composite.   */
  QUIT:							/* When a key is   */
  printf("\n");						/* hit, leave the  */
  Vstop(primes);					/* last prime on   */
							/* Screen and close*/
  return 0;						/* down the V-File.*/
  }

