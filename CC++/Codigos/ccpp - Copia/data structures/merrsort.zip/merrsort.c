/*MERRSORT.C v 1.0
This is a demonstration of the merge sorting procedure
Merge sort is essentially the splitting up of an array
to be sorted to  smaller arrays recursively  and  then
sorting them separately and then meging them to get  a
sorted array.
This program compiled successfully under Turbo C++v1.01
Hope this would be useful for those looking for sorting
algorithms for academic purposes.
If you like this please send me a mail.
I look forward to comments and complaints from you.
I know that this would be child's play to professional
programmers but amateurs would certainly find it useful.
Deepak
E-mail:deepak-p@eth.net
Computer Engg: Student,Kerala,India.*/

# include <stdio.h>
# include <stdlib.h>    /*For the calloc function*/
int merge(int *a,int sa,int *b,int sb)
{
	int *c,i,count1,count2;
	if((a+sa)!=b){return -1;}
	c=(int *)calloc(sa+sb,sizeof(int));
	count1=0;
	count2=0;
	for(i=0;i<(sa+sb);i++)
	{
		if(count1==sa)
		{
			*(c+i)=*(b+count2);
			count2++;
		}
		else if(count2==sb)
		{
			*(c+i)=*(a+count1);
			count1++;
		}
		else if(*(a+count1)<*(b+count2))
		{
			*(c+i)=*(a+count1);
			count1++;
		}
		else
		{
			*(c+i)=*(b+count2);
			count2++;
		}
	}
	for(i=0;i<(sa+sb);i++)
	{
		*(a+i)=*(c+i);
	}
	free(c);        /*Restoration of allocated memory using calloc*/
	return 0;
}
int split(int *a,int size)
{
	int *b,*c,size1,size2;
	if(size>1)
	{
		b=a;
		size1=(int)(size/2);
		c=a+size1;
		size2=size-size1;
		split(b,size1);
		split(c,size2);
		if(merge(b,size1,c,size2)==-1)
			printf("\nError!!!");
	}
	return;
}
main()
{
	int *a,n,i;
	clrscr();  /*In case of error please include <conio.h>*/
	printf("\nMerrsort.c v1.0 A demonstration of merge sort\n");
	printf("\n\nInput the no. of elements:");
	scanf("%d",&n);fflush(stdin);
	a=(int *)calloc(n,sizeof(int));
	for(i=0;i<n;i++)
	{
		printf("\nEnter element:");
		scanf("%d",a+i);fflush(stdin);
	}
	split(a,n);
	printf("\n\n");
	for(i=0;i<n;i++)
	{
		printf("\n%d",*(a+i));
	}
	printf("\nPress a key to exit...");
	getch();
	return;
}

