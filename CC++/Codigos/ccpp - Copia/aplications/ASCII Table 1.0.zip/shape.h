/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Author: Ga�per Raj�ek
 * E-mail, updates & bugs report: gape.korn@volja.net
 *
 * Created: 21.8.2002 at 21.59
 *
 * Description: structure and prototype function for the SHAPE component source
 *
 */

# ifndef SHAPE_H
# define SHAPE_H


// structure for the SHAPE component
typedef struct SHAPE
{
	UINT InputCodePage, OutputCodePage;
	// structure for FRAME component
	struct
	{
		int x, y, Length, Height, DoubleLine, WithStatusLine;
		WORD Color;
	} FRAME;
	// structure for LINE component
	struct
	{
		int x, y, Length, Height, Horizontal, DoubleLine;
		WORD Color;
	} LINE;
	// structure for BAR component
	struct
	{
		int x, y, Length, Height;
		char Pattern;
		WORD Color;
	} BAR;
} SHAPE_COMPONENT;

// function prototypes
void FrameComponent (SHAPE_COMPONENT *Frame);
void LineComponent  (SHAPE_COMPONENT *Line);
void BarComponent   (SHAPE_COMPONENT *Bar);

# endif // SHAPE_H