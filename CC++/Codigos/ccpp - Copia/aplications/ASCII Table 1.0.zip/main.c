/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Author: Ga�per Raj�ek
 * E-mail, updates & bugs report: gape.korn@volja.net
 *
 * Created: 03.08.2003 at 12.00
 *
 * Description: main menu nad main functions for this program
 *
 */

# include "main.h"
# include "help.h"
# include "author.h"



int main ()
{
	int ASCII = 0, Line = 0, Row = 0, Result = 0, SpaceBetweenNumbers = 0;
	long CodePage = 0;
	SHAPE_COMPONENT *ASCIIFrame = NULL, *MainFrame = NULL, *lcLine = NULL;
	GROUPBOX_COMPONENT *gbCodePage = NULL;
	// input variables
	INPUT_RECORD ir = {0};
	DWORD Read = 0;
	// common variables
	int i = 0, j = 0; // counters
	int HelpIsDisplayed = 0; // flag which becomes true if help text is displayed in the status line
	char *HexNumber = NULL;
	// variables for menu buttons (Show ASCII Table, Help, Author, Exit)
	int MainMenuLoop = 0, xStartMenu[MAIN_MENU_NO_OF_ITEMS] = {0}, MainMenuValue = MAIN_MENU_DEFAULT_SELECTED;
	int xEndMenu[MAIN_MENU_NO_OF_ITEMS] = {0}, yStartMenu[MAIN_MENU_NO_OF_ITEMS] = {0}, ReDrawMainMenu = 0;
	int yItemNameLength = 0, xItemNameLength = 0, MenuTempIndex = 0, MenuSelected = 1;
	int WriteMenu = 0, MarkMenu = 0, MenuIndex = 0, MenuClicked = 0;
	char *MainMenuItems[MAIN_MENU_NO_OF_ITEMS] = {0}, *MainMenuHelp[MAIN_MENU_NO_OF_ITEMS] = {0};
	// edit box variables
	int ebX[CODEPAGE_EB_WHOLE_NO] = {0}, ebY[CODEPAGE_EB_WHOLE_NO] = {0}, ebLength[CODEPAGE_EB_WHOLE_NO] = {0};
	int ebSelected[CODEPAGE_EB_WHOLE_NO] = {0}, x[CODEPAGE_EB_WHOLE_NO] = {0}, ebIndex[CODEPAGE_EB_WHOLE_NO] = {0};
	WORD ebColor[CODEPAGE_EB_WHOLE_NO] = {0};
	char ebCodePage[11] = {0};
	// options
	HANDLE Stdin = GetStdHandle (STD_INPUT_HANDLE);
	WORD ItemColor = 0, ItemHighLightColor = 0, DisabledItemColor = 0, DisabledItemHighLightColor = 0;
	WORD HelpColor = 0;
	int DisabledItem[MAIN_MENU_NO_OF_ITEMS] = {0}, ShowHelp = 0;



	// initialization
	ShowScreenCursor (0);
	SetConsoleCP (1250);
	SetConsoleOutputCP (1250);
	ClrScr (0, 0, 80, 25, BACK_LIGHTGREY, ' ');
	Print (29, 1, BACK_LIGHTGREY, "A S C I I   T A B L E");
	// reload menu item colors
	ItemColor                  = BACK_LIGHTGREY;
	ItemHighLightColor         = FRONT_WHITE | BACK_LIGHTGREY;
	DisabledItemColor          = FRONT_DARKGREEN;
	DisabledItemHighLightColor = FRONT_LIGHTGREEN;
	HelpColor                  = FRONT_WHITE | BACK_LIGHTGREY;
	// enable buttons
	DisabledItem[0] = FALSE;
	DisabledItem[1] = FALSE;
	DisabledItem[2] = FALSE;
	DisabledItem[3] = FALSE;
	ShowHelp        = TRUE;
	// set console title
	ConsoleTitle (PROGRAM_TITLE);
	// group box component for code page
	if ((gbCodePage = (GROUPBOX_COMPONENT *) malloc (sizeof (GROUPBOX_COMPONENT))) != NULL)
	{
		gbCodePage->x          = 39;
		gbCodePage->y          = 9;
		gbCodePage->Color      = FRONT_DARKBLUE | BACK_LIGHTGREY;
		gbCodePage->DoubleLine = TRUE;
		gbCodePage->Height     = 13;
		gbCodePage->Length     = 39;
		gbCodePage->Pattern     = ' ';
		strncpy (gbCodePage->Title, "Codepage & ASCII code", strlen ("Codepage & ASCII code") + 1);
		gbCodePage->TitleColor = FRONT_LIGHTBLUE | BACK_LIGHTGREY;
		GroupBoxComponent (gbCodePage);
	}
	else
	{
		ErrorMsg ("Error occured while allocating space for gbCodePage variable in function main (file \"main.c\").");
	}
	// straight line
	if ((lcLine = (SHAPE_COMPONENT *) malloc (sizeof (SHAPE_COMPONENT))) != NULL)
	{
		lcLine->LINE.x          = gbCodePage->x + 2;
		lcLine->LINE.y          = gbCodePage->y + 9;
		lcLine->LINE.Height     = 1;
		lcLine->LINE.Length     = 33;
		lcLine->LINE.DoubleLine = FALSE;
		lcLine->LINE.Horizontal = TRUE;
		lcLine->LINE.Color      = FRONT_DARKBLUE | BACK_LIGHTGREY;
		LineComponent (lcLine);
		free (lcLine);
		lcLine = NULL;
	}
	else
	{
		ErrorMsg ("Error occured while allocating space for lcLine     variable in function main (file \"main.c\").");
	}
	// enter title for the edit box
	Print (gbCodePage->x + 2, gbCodePage->y + 1, BACK_LIGHTGREY, "Enter code page:");
	// text in the ASCII & codepage groupbox
	Print (gbCodePage->x + 2, gbCodePage->y + 10, BACK_LIGHTGREY, "Formula = 16 * Line + Row");
	// draws a main frame
	if ((MainFrame = (SHAPE_COMPONENT *) malloc (sizeof (SHAPE_COMPONENT))) != NULL)
	{
		MainFrame->InputCodePage        = 1250;
		MainFrame->OutputCodePage       = 1250;
		MainFrame->FRAME.x              = 0;
		MainFrame->FRAME.y              = 0;
		MainFrame->FRAME.Length         = 79;
		MainFrame->FRAME.Height         = 24;
		MainFrame->FRAME.DoubleLine     = TRUE;
		MainFrame->FRAME.WithStatusLine = TRUE;
		MainFrame->FRAME.Color          = FRONT_WHITE | BACK_LIGHTGREY;
		FrameComponent (MainFrame);
		// free memory
		free (MainFrame);
		MainFrame = NULL;
	}
	else
	{
		ErrorMsg ("Error occured while allocating space for variable   MainFrame in function main (file \"main.c\").");
	}
	// draws a frame for ASCII Table
	if ((ASCIIFrame = (SHAPE_COMPONENT *) malloc (sizeof (SHAPE_COMPONENT))) != NULL)
	{
		ASCIIFrame->FRAME.x              = vX - 1;
		ASCIIFrame->FRAME.y              = hY - 1;
		ASCIIFrame->FRAME.Color          = FRONT_DARKBLUE | BACK_LIGHTGREY;
		ASCIIFrame->FRAME.DoubleLine     = TRUE;
		ASCIIFrame->FRAME.Height         = 19;
		ASCIIFrame->FRAME.Length         = 35;
		ASCIIFrame->FRAME.WithStatusLine = FALSE;
		ASCIIFrame->InputCodePage        = 1250;
		ASCIIFrame->OutputCodePage       = 1250;
		FrameComponent (ASCIIFrame);
		free (ASCIIFrame);
		ASCIIFrame = NULL;
	}
	else
	{
		ErrorMsg ("Error occured while allocating space for ASCIIFrame variable in function DrawASCIIFramework (file       \"main.c\").");
	}
	// print numbers 0 - 15
	for (i = 0, SpaceBetweenNumbers = 0; i < 16; i++, SpaceBetweenNumbers += 2)
	{
		if      (i == 10) { Print (hX+SpaceBetweenNumbers, hY, BACK_LIGHTGREY, "A"); Print (vX, vY+i, BACK_LIGHTGREY, "A"); }
		else if (i == 11) { Print (hX+SpaceBetweenNumbers, hY, BACK_LIGHTGREY, "B"); Print (vX, vY+i, BACK_LIGHTGREY, "B"); }
		else if (i == 12) { Print (hX+SpaceBetweenNumbers, hY, BACK_LIGHTGREY, "C"); Print (vX, vY+i, BACK_LIGHTGREY, "C"); }
		else if (i == 13) { Print (hX+SpaceBetweenNumbers, hY, BACK_LIGHTGREY, "D"); Print (vX, vY+i, BACK_LIGHTGREY, "D"); }
		else if (i == 14) { Print (hX+SpaceBetweenNumbers, hY, BACK_LIGHTGREY, "E"); Print (vX, vY+i, BACK_LIGHTGREY, "E"); }
		else if (i == 15) { Print (hX+SpaceBetweenNumbers, hY, BACK_LIGHTGREY, "F"); Print (vX, vY+i, BACK_LIGHTGREY, "F"); }
		else { Print (hX+SpaceBetweenNumbers, hY, BACK_LIGHTGREY, "%d", i); Print (vX, vY+i, BACK_LIGHTGREY, "%d", i); }
	}
	// text: Show ASCII Table
	if ((MainMenuItems[0] = (char *) malloc (sizeof (char) * (strlen ("Show ASCII Table") + 1))) != NULL)
	{
		strncpy (MainMenuItems[0], "Show ASCII Table", strlen ("Show ASCII Table") + 1);
	}
	else
	{
		ErrorMsg ("Error occured while allocationg space for variable  MainMenuItems[0] in function MainMenu (file         \"menu.c\").");
	}
	// text: Help
	if ((MainMenuItems[1] = (char *) malloc (sizeof (char) * (strlen ("Help") + 1))) != NULL)
	{
		strncpy (MainMenuItems[1], "Help", strlen ("Help") + 1);
	}
	else
	{
		ErrorMsg ("Error occured while allocationg space for variable  MainMenuItems[1] in function MainMenu (file         \"menu.c\").");
	}
	// text: Author
	if ((MainMenuItems[2] = (char *) malloc (sizeof (char) * (strlen ("Author") + 1))) != NULL)
	{
		strncpy (MainMenuItems[2], "Author", strlen ("Author") + 1);
	}
	else
	{
		ErrorMsg ("Error occured while allocationg space for variable  MainMenuItems[2] in function MainMenu (file         \"menu.c\").");
	}
	// text: Exit
	if ((MainMenuItems[3] = (char *) malloc (sizeof (char) * (strlen ("Exit") + 1))) != NULL)
	{
		strncpy (MainMenuItems[3], "Exit", strlen ("Exit") + 1);
	}
	else
	{
		ErrorMsg ("Error occured while allocationg space for variable  MainMenuItems[3] in function MainMenu (file         \"menu.c\").");
	}
	// help for "Show ASCII Table"
	if ((MainMenuHelp[0] = (char *) malloc (sizeof (char) * (strlen ("Shows ASCII Table for selected code page.") + 1 + HELP_ERASE_LENGTH))) != NULL)
	{
		strncpy (MainMenuHelp[0], "Shows ASCII Table for selected code page.", strlen ("Shows ASCII Table for selected code page.") + 1 + HELP_ERASE_LENGTH);
	}
	else
	{
		ErrorMsg ("Error occured while allocationg space for variable  MainMenuHelp[0] in function MainMenu (file          \"menu.c\").");
	}
	// help for "Help"
	if ((MainMenuHelp[1] = (char *) malloc (sizeof (char) * (strlen ("Shows help about this program.") + 1 + HELP_ERASE_LENGTH))) != NULL)
	{
		strncpy (MainMenuHelp[1], "Shows help about this program.", strlen ("Shows help about this program.") + 1 + HELP_ERASE_LENGTH);
	}
	else
	{
		ErrorMsg ("Error occured while allocationg space for variable  MainMenuHelp[1] in function MainMenu (file          \"menu.c\").");
	}
	// help for "Author"
	if ((MainMenuHelp[2] = (char *) malloc (sizeof (char) * (strlen ("Shows information about the author.") + 1 + HELP_ERASE_LENGTH))) != NULL)
	{
		strncpy (MainMenuHelp[2], "Shows information about the author.", strlen ("Shows information about the author.") + 1 + HELP_ERASE_LENGTH);
	}
	else
	{
		ErrorMsg ("Error occured while allocationg space for variable  MainMenuHelp[2] in function MainMenu (file          \"menu.c\").");
	}
	// help for "Author"
	if ((MainMenuHelp[3] = (char *) malloc (sizeof (char) * (strlen ("Exit the program.") + 1 + HELP_ERASE_LENGTH))) != NULL)
	{
		strncpy (MainMenuHelp[3], "Exit the program.", strlen ("Exit the program.") + 1 + HELP_ERASE_LENGTH);
	}
	else
	{
		ErrorMsg ("Error occured while allocationg space for variable  MainMenuHelp[3] in function MainMenu (file          \"menu.c\").");
	}
	// with this, before the help gets printed, I can avoid to delete the previous text - very useful
	// I don't have to use ClrScr function
	for (i = 0; i < MAIN_MENU_NO_OF_ITEMS; i++)
	{
		for (j = 0; j < HELP_ERASE_LENGTH; j++)
		{
			if (MainMenuHelp[i][j] == '\0')
			{
				MainMenuHelp[i][j]   = ' ';
				MainMenuHelp[i][j+1] = '\0';
			}
		}
	}
	// calculate main menu coordinates
	for (i = 0, xItemNameLength = 0, yItemNameLength = 0; i < MAIN_MENU_NO_OF_ITEMS; i++)
	{
		xStartMenu[i] = MAIN_MENU_X;
		xEndMenu[i] = MAIN_MENU_X + (int) strlen (MainMenuItems[i]) - 1;
		// checking which text is the longest
		if (xEndMenu[i] - MAIN_MENU_X + 1 > xItemNameLength) xItemNameLength = xEndMenu[i] - MAIN_MENU_X + 1;
		yStartMenu[i] = MAIN_MENU_Y + yItemNameLength;
		// count the length of menu button names -> that is 1 + space between items
		yItemNameLength += 1;
		if (i != MAIN_MENU_NO_OF_ITEMS-1) yItemNameLength += 0 + MAIN_MENU_SPACE_BETWEEN_ITEMS;
	}
	// print main menu
	for (i = 0; i < MAIN_MENU_NO_OF_ITEMS; i++)
	{
		if (MAIN_MENU_DEFAULT_SELECTED == i)
		{
			// checking if the menu item is disabled. If it is then color it diferently
			if (DisabledItem[i]) Print (xStartMenu[i], yStartMenu[i], DisabledItemHighLightColor, "%s", MainMenuItems[i]);
			else Print (xStartMenu[i], yStartMenu[i], ItemHighLightColor, "%s", MainMenuItems[i]);
			MarkMenu = MenuSelected = 1;
			MenuTempIndex = i;
			// print help in the status line
			if (ShowHelp)
			{
				Print (HELP_X, HELP_Y, HelpColor, "%s", MainMenuHelp[i]);
				HelpIsDisplayed = 1;
			}
		}
		else
		{
			if (DisabledItem[i]) Print (xStartMenu[i], yStartMenu[i], DisabledItemColor, "%s", MainMenuItems[i]);
			else Print (xStartMenu[i], yStartMenu[i], ItemColor, "%s", MainMenuItems[i]);
		}
	}
	// file name edit box initialization
	ebX[CODEPAGE_EB_CODEPAGE]      = 41;
	ebY[CODEPAGE_EB_CODEPAGE]      = 11;
	ebLength[CODEPAGE_EB_CODEPAGE] = 10;
	ebColor[CODEPAGE_EB_CODEPAGE]  = BACK_WHITE;
	for (i = 0; i < ebLength[CODEPAGE_EB_CODEPAGE]; i++)
	{
		Print (ebX[CODEPAGE_EB_CODEPAGE]+i, ebY[CODEPAGE_EB_CODEPAGE], ebColor[CODEPAGE_EB_CODEPAGE], " ");
	}
	// main menu loop
	MainMenuLoop = 1;
	while (MainMenuLoop)
	{
		if (ReDrawMainMenu)
		{
			// reload menu item colors
			ItemColor                  = BACK_LIGHTGREY;
			ItemHighLightColor         = FRONT_WHITE | BACK_LIGHTGREY;
			DisabledItemColor          = FRONT_DARKGREEN;
			DisabledItemHighLightColor = FRONT_LIGHTGREEN;
			HelpColor                  = FRONT_WHITE | BACK_LIGHTGREY;
			// enable buttons
			DisabledItem[0] = FALSE;
			DisabledItem[1] = FALSE;
			DisabledItem[2] = FALSE;
			DisabledItem[3] = FALSE;
			// text: Show ASCII Table
			if ((MainMenuItems[0] = (char *) malloc (sizeof (char) * (strlen ("Show ASCII Table") + 1))) != NULL)
			{
				strncpy (MainMenuItems[0], "Show ASCII Table", strlen ("Show ASCII Table") + 1);
			}
			else
			{
				ErrorMsg ("Error occured while allocationg space for variable  MainMenuItems[0] in function MainMenu (file         \"menu.c\").");
			}
			// text: Help
			if ((MainMenuItems[1] = (char *) malloc (sizeof (char) * (strlen ("Help") + 1))) != NULL)
			{
				strncpy (MainMenuItems[1], "Help", strlen ("Help") + 1);
			}
			else
			{
				ErrorMsg ("Error occured while allocationg space for variable  MainMenuItems[1] in function MainMenu (file         \"menu.c\").");
			}
			// text: Author
			if ((MainMenuItems[2] = (char *) malloc (sizeof (char) * (strlen ("Author") + 1))) != NULL)
			{
				strncpy (MainMenuItems[2], "Author", strlen ("Author") + 1);
			}
			else
			{
				ErrorMsg ("Error occured while allocationg space for variable  MainMenuItems[2] in function MainMenu (file         \"menu.c\").");
			}
			// text: Exit
			if ((MainMenuItems[3] = (char *) malloc (sizeof (char) * (strlen ("Exit") + 1))) != NULL)
			{
				strncpy (MainMenuItems[3], "Exit", strlen ("Exit") + 1);
			}
			else
			{
				ErrorMsg ("Error occured while allocationg space for variable  MainMenuItems[3] in function MainMenu (file         \"menu.c\").");
			}
			// help for "Show ASCII Table"
			if ((MainMenuHelp[0] = (char *) malloc (sizeof (char) * (strlen ("Shows ASCII Table for selected code page.") + 1 + HELP_ERASE_LENGTH))) != NULL)
			{
				strncpy (MainMenuHelp[0], "Shows ASCII Table for selected code page.", strlen ("Shows ASCII Table for selected code page.") + 1 + HELP_ERASE_LENGTH);
			}
			else
			{
				ErrorMsg ("Error occured while allocationg space for variable  MainMenuHelp[0] in function MainMenu (file          \"menu.c\").");
			}
			// help for "Help"
			if ((MainMenuHelp[1] = (char *) malloc (sizeof (char) * (strlen ("Shows help about this program.") + 1 + HELP_ERASE_LENGTH))) != NULL)
			{
				strncpy (MainMenuHelp[1], "Shows help about this program.", strlen ("Shows help about this program.") + 1 + HELP_ERASE_LENGTH);
			}
			else
			{
				ErrorMsg ("Error occured while allocationg space for variable  MainMenuHelp[1] in function MainMenu (file          \"menu.c\").");
			}
			// help for "Author"
			if ((MainMenuHelp[2] = (char *) malloc (sizeof (char) * (strlen ("Shows information about the author.") + 1 + HELP_ERASE_LENGTH))) != NULL)
			{
				strncpy (MainMenuHelp[2], "Shows information about the author.", strlen ("Shows information about the author.") + 1 + HELP_ERASE_LENGTH);
			}
			else
			{
				ErrorMsg ("Error occured while allocationg space for variable  MainMenuHelp[2] in function MainMenu (file          \"menu.c\").");
			}
			// help for "Author"
			if ((MainMenuHelp[3] = (char *) malloc (sizeof (char) * (strlen ("Exit the program.") + 1 + HELP_ERASE_LENGTH))) != NULL)
			{
				strncpy (MainMenuHelp[3], "Exit the program.", strlen ("Exit the program.") + 1 + HELP_ERASE_LENGTH);
			}
			else
			{
				ErrorMsg ("Error occured while allocationg space for variable  MainMenuHelp[3] in function MainMenu (file          \"menu.c\").");
			}
			// with this, before the help gets printed, I can avoid to delete the previous text - very useful
			// I don't have to use ClrScr function
			for (i = 0; i < MAIN_MENU_NO_OF_ITEMS; i++)
			{
				for (j = 0; j < HELP_ERASE_LENGTH; j++)
				{
					if (MainMenuHelp[i][j] == '\0')
					{
						MainMenuHelp[i][j]   = ' ';
						MainMenuHelp[i][j+1] = '\0';
					}
				}
			}
			// calculate main menu coordinates
			for (i = 0, xItemNameLength = 0, yItemNameLength = 0; i < MAIN_MENU_NO_OF_ITEMS; i++)
			{
				xStartMenu[i] = MAIN_MENU_X;
				xEndMenu[i] = MAIN_MENU_X + (int) strlen (MainMenuItems[i]) - 1;
				// checking which text is the longest
				if (xEndMenu[i] - MAIN_MENU_X + 1 > xItemNameLength) xItemNameLength = xEndMenu[i] - MAIN_MENU_X + 1;
				yStartMenu[i] = MAIN_MENU_Y + yItemNameLength;
				// count the length of menu button names -> that is 1 + space between items
				yItemNameLength += 1;
				if (i != MAIN_MENU_NO_OF_ITEMS-1) yItemNameLength += 0 + MAIN_MENU_SPACE_BETWEEN_ITEMS;
			}
			// flags and values
			MainMenuValue = MAIN_MENU_DEFAULT_SELECTED;
			WriteMenu     = 1;
			MarkMenu      = 1;
			MenuSelected  = 1;
			MenuClicked   = 0;
			ReDrawMainMenu = FALSE;
		} // end if ReDrawMainMenu
		ReadConsoleInput (Stdin, &ir, 1, &Read);
		// mouse
		if (ir.EventType == MOUSE_EVENT)
		{
			if (ir.Event.MouseEvent.dwEventFlags == MOUSE_MOVED)
			{
				// within the range of a main menu items
				if ( (ir.Event.MouseEvent.dwMousePosition.X >= xStartMenu[MenuIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.X <= xEndMenu[MenuIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.Y == yStartMenu[MenuIndex]) )
				{
					// print the menu button only once
					if ( (MenuTempIndex != MenuIndex) || (!MenuSelected) )
					{
						WriteMenu = 1;
						MarkMenu = MenuSelected = 1;
						MenuTempIndex = MenuIndex;
						MenuIndex++;
						if (MenuIndex >= MAIN_MENU_NO_OF_ITEMS) MenuIndex = 0;
					}
					// CODEPAGE edit box
					if (ebSelected[CODEPAGE_EB_CODEPAGE])
					{
						ebSelected[CODEPAGE_EB_CODEPAGE] = 0;
						ShowScreenCursor (0);
					}
				}
				else
				{
					MenuClicked = 0;
					MenuIndex++;
					if (MenuIndex >= MAIN_MENU_NO_OF_ITEMS) MenuIndex = 0;
				}
			} // end if MOUSE_MOVED
			if (ir.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED) // left mouse click
			{
				// within the range of a vertical menu buttons
				if ( (ir.Event.MouseEvent.dwMousePosition.X >= xStartMenu[MenuTempIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.X <= xEndMenu[MenuTempIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.Y == yStartMenu[MenuTempIndex]) )
				{
					if (!MenuClicked)
					{
						// simulating key return
						keybd_event	(VK_RETURN,	0x1c, 0, 0);
						keybd_event	(VK_RETURN,	0x1c, KEYEVENTF_KEYUP, 0);
					}
				}
				else
				{
					if (MenuSelected)
					{
						// menu
						WriteMenu = 1; MarkMenu = 0; MenuSelected = 0;
					}
				}
				if ( (ir.Event.MouseEvent.dwMousePosition.X >= hX) &&
					 (ir.Event.MouseEvent.dwMousePosition.X <= hX+30) &&
					 (ir.Event.MouseEvent.dwMousePosition.Y >= PRINT_ASCII_Y+1) &&
					 (ir.Event.MouseEvent.dwMousePosition.Y <= PRINT_ASCII_Y+16) )
				{
					if ( (ASCII) && (ir.Event.MouseEvent.dwMousePosition.X % 2 == 0) )
					{
						Row    = (ir.Event.MouseEvent.dwMousePosition.X - hX) / 2;
						Line   = ir.Event.MouseEvent.dwMousePosition.Y - (hY + 2);
						Result = 16 * Line + Row;
						if ((HexNumber = DecToHex (Result)) != NULL)
						{
							// if Result = 0, than %c cannot show the character, that's why I print space instead
							if (Result != 0) Print (gbCodePage->x + 2, gbCodePage->y + 11, FRONT_WHITE | BACK_LIGHTGREY, "ASCII code for '%c' is %03d (0x%s).", Result, Result, HexNumber);
							else Print (gbCodePage->x + 2, gbCodePage->y + 11, FRONT_WHITE | BACK_LIGHTGREY, "ASCII code for '%c' is %03d (0x%s).", Result+32, Result, HexNumber);
							free (HexNumber);
							HexNumber = NULL;
						}
						else
						{
							ErrorMsg ("Error occured while allocating space for variable   HexNumber in function DecToHex (file \"main.c\").");
						}
					}
				}
				// CODEPAGE edit box
				if ( (ir.Event.MouseEvent.dwMousePosition.X >= ebX[CODEPAGE_EB_CODEPAGE]) &&
					 (ir.Event.MouseEvent.dwMousePosition.X <= ebX[CODEPAGE_EB_CODEPAGE]+ebLength[CODEPAGE_EB_CODEPAGE]-1) &&
					 (ir.Event.MouseEvent.dwMousePosition.Y == ebY[CODEPAGE_EB_CODEPAGE]) )
				{
					// show screen cursor and select edit box
					ShowScreenCursor (1);
					ebSelected[CODEPAGE_EB_CODEPAGE] = 1;
					// x[CODEPAGE_EB_CODEPAGE] value is equal to the "mouse click" x[CODEPAGE_EB_CODEPAGE] coordinate
					x[CODEPAGE_EB_CODEPAGE] = ir.Event.MouseEvent.dwMousePosition.X;
					GotoXY (x[CODEPAGE_EB_CODEPAGE], ebY[CODEPAGE_EB_CODEPAGE]); // set the screen cursor to the right position
					// ebIndex[CODEPAGE_EB_CODEPAGE] must be between 0 and Edit->Length-1
					ebIndex[CODEPAGE_EB_CODEPAGE] = x[CODEPAGE_EB_CODEPAGE] - ebX[CODEPAGE_EB_CODEPAGE];
				}
				else
				{
					ebSelected[CODEPAGE_EB_CODEPAGE] = 0;
					ShowScreenCursor (0);
				}
			} // end if FROM_LEFT_1ST_BUTTON_PRESSED
		} // end if MOUSE_EVENT
		if ( (MenuSelected) || (ebSelected[CODEPAGE_EB_CODEPAGE]) )
		{
			if (ir.EventType == KEY_EVENT && ir.Event.KeyEvent.bKeyDown)
			{
				// key F10 for menu
				if (ir.Event.KeyEvent.wVirtualKeyCode == VK_F10)
				{
					// menu
					MenuSelected  = 1;
					WriteMenu     = 1;
					MarkMenu      = 1;
					MenuClicked   = 0;
					// Unselect edit boxes
					ebSelected[CODEPAGE_EB_CODEPAGE] = 0;
					ShowScreenCursor (0);
				}
				// key LEFT_ALT + ('c' or 'C') for codepage edit box
				else if ( ((ir.Event.KeyEvent.wVirtualKeyCode   == 'c') ||
					       (ir.Event.KeyEvent.wVirtualKeyCode   == 'C')) &&
						   (ir.Event.KeyEvent.dwControlKeyState == LEFT_ALT) )
				{
					if (!ebSelected[CODEPAGE_EB_CODEPAGE])
					{
						// menu
						WriteMenu    = 1;
						MarkMenu     = 0;
						MenuSelected = 0;
						// edit box
						ebSelected[CODEPAGE_EB_CODEPAGE] = 1;
						ShowScreenCursor (1);
						// x[CODEPAGE_EB_CODEPAGE] value is equal to the "mouse click" x[CODEPAGE_EB_CODEPAGE] coordinate
						x[CODEPAGE_EB_CODEPAGE] = ebX[CODEPAGE_EB_CODEPAGE];
						GotoXY (x[CODEPAGE_EB_CODEPAGE], ebY[CODEPAGE_EB_CODEPAGE]); // set the screen cursor to the right position
						// ebIndex[CODEPAGE_EB_CODEPAGE] must be between 0 and Edit->Length-1
						ebIndex[CODEPAGE_EB_CODEPAGE] = x[CODEPAGE_EB_CODEPAGE] - ebX[CODEPAGE_EB_CODEPAGE];
					}
				}
				// up arrow key
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_UP)
				{
					if (MenuSelected)
					{
						WriteMenu = 1;
						MarkMenu  = 1;
						MenuTempIndex -= 1;
						MenuClicked = 0;
						if (MenuTempIndex < 0) MenuTempIndex = MAIN_MENU_NO_OF_ITEMS-1;
					}
				}
				// down arrow key
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_DOWN)
				{
					if (MenuSelected)
					{
						WriteMenu = 1;
						MarkMenu  = 1;
						MenuTempIndex += 1;
						MenuClicked = 0;
						if (MenuTempIndex >= MAIN_MENU_NO_OF_ITEMS) MenuTempIndex = 0;
					}
				}
				// left arrow key
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_LEFT)
				{
					if (ebSelected[CODEPAGE_EB_CODEPAGE])
					{
						// screen cursor is moving left
						if (ebIndex[CODEPAGE_EB_CODEPAGE] > 0)
						{
							GotoXY (--x[CODEPAGE_EB_CODEPAGE], ebY[CODEPAGE_EB_CODEPAGE]);
							--ebIndex[CODEPAGE_EB_CODEPAGE];
						}
					}
				}
				// right arrow key
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_RIGHT)
				{
					if (ebSelected[CODEPAGE_EB_CODEPAGE])
					{
						// screen cursor is moving right
						if (ebIndex[CODEPAGE_EB_CODEPAGE] < ebLength[CODEPAGE_EB_CODEPAGE]-1)
						{
							GotoXY (++x[CODEPAGE_EB_CODEPAGE], ebY[CODEPAGE_EB_CODEPAGE]);
							++ebIndex[CODEPAGE_EB_CODEPAGE];
						}
					}
				}
				// return and space key
				else if ( (ir.Event.KeyEvent.wVirtualKeyCode == VK_RETURN) ||
					      (ir.Event.KeyEvent.wVirtualKeyCode == VK_SPACE) )
				{
					if (!ebSelected[CODEPAGE_EB_CODEPAGE])
					{
						// if menu item is enabled then continue else do nothing
						if ( (!DisabledItem[MenuTempIndex]) && (!MenuClicked) )
						{
							MainMenuValue = MenuTempIndex;
							MarkMenu = 1;
							MenuClicked = 1;
							if (MainMenuValue == MAIN_MENU_SHOW_ASCII_TABLE)
							{
								CodePage = atol (ebCodePage);
								if ( (CodePage <= 65001) && (CodePage > 0) )
								{
									ASCII = TRUE;
									ASCII_Table (CodePage);
								}
								else
								{
									ASCII = FALSE;
									ErrorMsg ("       Code page must be between 65001 and 1 !!");
								}
							}
							else if (MainMenuValue == MAIN_MENU_HELP)
							{
								// free memory
								for (i = 0; i < MAIN_MENU_NO_OF_ITEMS; i++)
								{
									free (MainMenuItems[i]);
									MainMenuItems[i] = NULL;
									free (MainMenuHelp[i]);
									MainMenuHelp[i] = NULL;
								}
								// help dialog
								HelpDialog ();
								// redraw main menu
								ReDrawMainMenu = TRUE;
							}
							else if (MainMenuValue == MAIN_MENU_AUTHOR)
							{
								// free memory
								for (i = 0; i < MAIN_MENU_NO_OF_ITEMS; i++)
								{
									free (MainMenuItems[i]);
									MainMenuItems[i] = NULL;
									free (MainMenuHelp[i]);
									MainMenuHelp[i] = NULL;
								}
								// author dialog
								AuthorDialog ();
								// redraw main menu
								ReDrawMainMenu = TRUE;
							}
							else if (MainMenuValue == MAIN_MENU_EXIT)
							{
								// free memory
								for (i = 0; i < MAIN_MENU_NO_OF_ITEMS; i++)
								{
									free (MainMenuItems[i]);
									MainMenuItems[i] = NULL;
									free (MainMenuHelp[i]);
									MainMenuHelp[i] = NULL;
								}
								free (gbCodePage);
								gbCodePage = NULL;
								// disable main menu loop and exit the program
								MainMenuLoop = FALSE;
							}
						}
					}
					if (ir.Event.KeyEvent.wVirtualKeyCode == VK_SPACE)
					{
						if (ebSelected[CODEPAGE_EB_CODEPAGE])
						{
							if (ebIndex[CODEPAGE_EB_CODEPAGE] < ebLength[CODEPAGE_EB_CODEPAGE]) 
							{
								// filling array with the character
								ebCodePage[ebIndex[CODEPAGE_EB_CODEPAGE]] = (char) ir.Event.KeyEvent.uChar.AsciiChar;
								// printing character on the screen
								SetColor (ebColor[CODEPAGE_EB_CODEPAGE]);
								GotoXY (x[CODEPAGE_EB_CODEPAGE]++, ebY[CODEPAGE_EB_CODEPAGE]);
								putchar (ebCodePage[ebIndex[CODEPAGE_EB_CODEPAGE]++]);
							}
							ebCodePage[ebLength[CODEPAGE_EB_CODEPAGE]] = '\0';
						}
					}
				} // end if key return or space was pressed
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_BACK) // backspace key
				{
					if ( (ebIndex[CODEPAGE_EB_CODEPAGE] > 0) && (ebSelected[CODEPAGE_EB_CODEPAGE]) )
					{
						Print (--x[CODEPAGE_EB_CODEPAGE], ebY[CODEPAGE_EB_CODEPAGE], ebColor[CODEPAGE_EB_CODEPAGE], " ");
						GotoXY (x[CODEPAGE_EB_CODEPAGE], ebY[CODEPAGE_EB_CODEPAGE]);
						ebCodePage[--ebIndex[CODEPAGE_EB_CODEPAGE]] = ' ';
					}
				}
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_HOME) // home key
				{
					// move screen cursor to the start of the EDIT component only if the edit box is selected
					if (ebSelected[CODEPAGE_EB_CODEPAGE])
					{
						x[CODEPAGE_EB_CODEPAGE] = ebX[CODEPAGE_EB_CODEPAGE];
						GotoXY (x[CODEPAGE_EB_CODEPAGE], ebY[CODEPAGE_EB_CODEPAGE]);
						ebIndex[CODEPAGE_EB_CODEPAGE] = 0;
					}
				}
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_END) // end key
				{
					// move screen cursor to the end of the EDIT component only if the edit box is selected
					if (ebSelected[CODEPAGE_EB_CODEPAGE])
					{
						x[CODEPAGE_EB_CODEPAGE] = ebX[CODEPAGE_EB_CODEPAGE]+ebLength[CODEPAGE_EB_CODEPAGE]-1;
						GotoXY (x[CODEPAGE_EB_CODEPAGE], ebY[CODEPAGE_EB_CODEPAGE]);
						ebIndex[CODEPAGE_EB_CODEPAGE] = ebLength[CODEPAGE_EB_CODEPAGE]-1;
					}
				}
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_DELETE) // delete key
				{
					if (ebSelected[CODEPAGE_EB_CODEPAGE])
					{
						ebCodePage[ebIndex[CODEPAGE_EB_CODEPAGE]] = ' ';
						Print (x[CODEPAGE_EB_CODEPAGE], ebY[CODEPAGE_EB_CODEPAGE], ebColor[CODEPAGE_EB_CODEPAGE], "%c", ebCodePage[ebIndex[CODEPAGE_EB_CODEPAGE]]);
					}
				}
				else if ( (ir.Event.KeyEvent.wVirtualKeyCode == VK_SHIFT) ||
				          (ir.Event.KeyEvent.wVirtualKeyCode == VK_UP) ||
					      (ir.Event.KeyEvent.wVirtualKeyCode == VK_DOWN) ||
						  (ir.Event.KeyEvent.wVirtualKeyCode == VK_ESCAPE) ||
						  (ir.Event.KeyEvent.dwControlKeyState == LEFT_ALT) )
				{
					// do nothing !!
				}
				else
				{
					if (ebSelected[CODEPAGE_EB_CODEPAGE])
					{
						// only accept numbers
						if ( (ir.Event.KeyEvent.uChar.AsciiChar >= '0') && (ir.Event.KeyEvent.uChar.AsciiChar <= '9') )
						{
							if (ebIndex[CODEPAGE_EB_CODEPAGE] < ebLength[CODEPAGE_EB_CODEPAGE]) 
							{
								// filling array with the character
								ebCodePage[ebIndex[CODEPAGE_EB_CODEPAGE]] = (char) ir.Event.KeyEvent.uChar.AsciiChar;
								// printing character on the screen
								SetColor (ebColor[CODEPAGE_EB_CODEPAGE]);
								GotoXY (x[CODEPAGE_EB_CODEPAGE]++, ebY[CODEPAGE_EB_CODEPAGE]);
								putchar (ebCodePage[ebIndex[CODEPAGE_EB_CODEPAGE]++]);
							}
							ebCodePage[ebLength[CODEPAGE_EB_CODEPAGE]] = '\0';
						}
					}
				}
			} // end if keyboard
		}
		else // end if MenuSelected
		{
			if ( (ShowHelp) && (HelpIsDisplayed) )
			{
				Print (HELP_X, HELP_Y, HelpColor, "Press F10 for menu.                                                          ");
				HelpIsDisplayed = FALSE;
			}
			// key F10 is available only when the menu is unselected
			if (ir.EventType == KEY_EVENT && ir.Event.KeyEvent.bKeyDown)
			{
				// key F10
				if (ir.Event.KeyEvent.wVirtualKeyCode == VK_F10)
				{
					MenuSelected = 1;
					WriteMenu = 1;
					MarkMenu = 1;
					MenuClicked = 0;
					// edit box
					ebSelected[CODEPAGE_EB_CODEPAGE] = 0;
					ShowScreenCursor (0);
				}
				// key LEFT_ALT + ('c' or 'C') for file name edit box
				else if ( ((ir.Event.KeyEvent.wVirtualKeyCode   == 'c') ||
					       (ir.Event.KeyEvent.wVirtualKeyCode   == 'C')) &&
						   (ir.Event.KeyEvent.dwControlKeyState == LEFT_ALT) )
				{
					// menu
					WriteMenu    = 1;
					MenuSelected = 0;
					// edit box
					ebSelected[CODEPAGE_EB_CODEPAGE] = 1;
					ShowScreenCursor (1);
					// x[CODEPAGE_EB_CODEPAGE] value is equal to the "mouse click" x[CODEPAGE_EB_CODEPAGE] coordinate
					x[CODEPAGE_EB_CODEPAGE] = ebX[CODEPAGE_EB_CODEPAGE];
					GotoXY (x[CODEPAGE_EB_CODEPAGE], ebY[CODEPAGE_EB_CODEPAGE]); // set the screen cursor to the right position
					// ebIndex[CODEPAGE_EB_CODEPAGE] must be between 0 and Edit->Length-1
					ebIndex[CODEPAGE_EB_CODEPAGE] = x[CODEPAGE_EB_CODEPAGE] - ebX[CODEPAGE_EB_CODEPAGE];
				}
			}
		}
		if (WriteMenu)
		{
			for (i = 0; i < MAIN_MENU_NO_OF_ITEMS; i++)
			{
				if (MainMenuItems[i] != NULL)
				{
					if (DisabledItem[i]) Print (xStartMenu[i], yStartMenu[i], DisabledItemColor, "%s", MainMenuItems[i]);
					else Print (xStartMenu[i], yStartMenu[i], ItemColor, "%s", MainMenuItems[i]);
				}
			}
			if (MarkMenu)
			{
				if (MainMenuItems[MenuTempIndex] != NULL)
				{
					if (DisabledItem[MenuTempIndex]) Print (xStartMenu[MenuTempIndex], yStartMenu[MenuTempIndex], DisabledItemHighLightColor, "%s", MainMenuItems[MenuTempIndex]);
					else Print (xStartMenu[MenuTempIndex], yStartMenu[MenuTempIndex], ItemHighLightColor, "%s", MainMenuItems[MenuTempIndex]);
					// print help in the status line
					if (ShowHelp)
					{
						Print (HELP_X, HELP_Y, HelpColor, "%s", MainMenuHelp[MenuTempIndex]);
						HelpIsDisplayed = TRUE;
					}
				}
				MarkMenu = 0;
			}
			WriteMenu = 0;
		}
	} // end of while (MainMenuLoop)
	return 0;
}
/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Function name:    GotoXY
 * Function version: 1.0
 * Input parameters: - x (int)
 *                   - y (int)
 * Return value:     none
 * Description:      moving screen cursor
 * Example:          GotoXY (0, 0);
 * Limits:           0 <= x <= 78
 *                   0 <= y <= 24
 * Warnings:         If the x value is 79 and y value is 24 and if you're using this function with printf
 *                   function then there will be problems beacuse of the screen cursor. When the character
 *                   is displayed on the screen, then the screen cursor will always automatically move forward
 *                   and beacuse of that the new line will occur and corrupt the output. To avoid this then you
 *                   must use Print function.
 *
 * Updates:
 *   - (!! here you write the updates - do not remove this line !!)
 *
 */
void GotoXY (int x, int y)
{
	COORD coord = {0};



	// limits
	if ( (x >= 0) && (x <= 78) && (y >= 0) && (y <= 24) )
	{
		coord.X = (short) x;
		coord.Y = (short) y;
		SetConsoleCursorPosition (GetStdHandle (STD_OUTPUT_HANDLE), coord);
	}
	else
	{
		if ( !((x >= 0) && (x <= 78)) )
		{
			ErrorMsg ("Error occured in function GotoXY (file \"main.c\").   Value x is not between 0 and 78 (x = %02d).", x);
		}
		if ( !((y >= 0) && (y <= 24)) )
		{
			ErrorMsg ("Error occured in function GotoXY (file \"main.c\").   Value y is not between 0 and 24 (y = %02d).", y);
		}
	}
}
/*
 * Calculate ASCII table for certain codepage and print it on the screen
 */
void ASCII_Table (unsigned int CodePage)
{
	int i = 0, j = 0, SpaceBetweenNumbers = 0;

	// set codepage for ASCII table
	SetConsoleCP (CodePage);
	SetConsoleOutputCP (CodePage);
	// print it on the screen
	for (i = 0, SpaceBetweenNumbers = 0; i < 256; i++, SpaceBetweenNumbers += 2)
	{
		if (i % 16 == 0) { SpaceBetweenNumbers = 0; j++; }
		Print (hX + SpaceBetweenNumbers, PRINT_ASCII_Y + j, BACK_LIGHTGREY, "%c", i);
	}
}
/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Function name:    TimeAndDate
 * Function version: 1.0
 * Input parameters: none
 * Return value:     char *
 * Description:      gets current time and date
 * Example:          char *GetTimeAndDate = NULL;
 *                   if ((GetTimeAndDate = (char *) malloc (sizeof (char) * 80)) != NULL
 *                   {
 *						sprintf (GetTimeAndDate, TimeAndDate);
 *                      free (GetTimeAndDate);
 *                      GetTimeAndDate = NULL;
 *                   } else ErrorMsg ("Error occured");
 * Limits:           none
 * Warnings:         none
 *
 * Updates:
 *   - (!! here you write the updates - do not remove this line !!)
 *
 */
char *TimeDate ()
{
	char *TD = NULL;
	time_t Now = 0;



	if ((TD = (char *) malloc (sizeof (char) * 80)) != NULL)
	{
		Now = time (NULL);
		// get time and date
		strftime (TD, 80, "%x %X", localtime (&Now));
	}
	else
	{
		ErrorMsg ("Error occured while allocating space for TD variable in function TimeAndDate (file \"main.c\").");
	}
	return TD;
}
/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Function name:    ClrScr
 * Function version: 1.0
 * Input parameters: - x (int)
 *                   - y (int)
 *                   - EraseLength (int)
 *                   - NoOfLines (int)
 *                   - EraseColor (WORD)
 *                   - ErasePattern (char)
 * Return value:     none
 * Description:      clearing the specified region on the screen
 * Example:          ClrScr (0, 0, 80, 25, FRONT_LIGHTGREY, ' ');
 * Limits:           0 <= x <= 79
 *                   0 <= y <= 24
 *                   x+EraseLength <= 80
 *                   y+NoOfLines <= 25
 * Warnings:         Read the GotoXY function, section Warnings, for more details.
 *
 * Updates:
 *   - (!! here you write the updates - do not remove this line !!)
 *
 */
void ClrScr (int x, int y, int EraseLength, int NoOfLines, WORD EraseColor, char ErasePattern)
{
	int i	= 0, j = 0;
	char Erase[26][81] = {0};



	// limits
	if ( (x >= 0) && (x <= 79) && (x+EraseLength <= 80) &&
		 (y >= 0) && (y <= 24) && (y+NoOfLines <= 25) )
	{
		for	(i = 0; i < NoOfLines; i++)
		{
			for	(j = 0; j < EraseLength; j++)
			{
				Erase[i][j] = ErasePattern;
			}
			Erase[i][j] = '\0';
			Print (x, y+i, EraseColor, "%s", Erase);
		}
	}
	else
	{
		if ( !((x >= 0) && (x <= 79)) )
		{
			ErrorMsg ("Error occured in function ClrScr (file \"main.c\").   Value x is not between 0 and 79 (x = %02d)", x);
		}
		if ( !((y >= 0) && (y <= 24)) )
		{
			ErrorMsg ("Error occured in function ClrScr (file \"main.c\").   Value y is not between 0 and 24 (y = %02d)", y);
		}
		if ( !(x+EraseLength <= 80) )
		{
			ErrorMsg ("Error occured in function ClrScr (file \"main.c\").   Value x+EraseLength is greater than 80              (x+EraseLength = %02d)", x+EraseLength);
		}
		if ( !(y+NoOfLines <= 25) )
		{
			ErrorMsg ("Error occured in function ClrScr (file \"main.c\").   Value y+NoOfLines is greater than 25                (y+NoOfLines = %02d)", y+NoOfLines);
		}
	}
}
/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Function name:    SetColor
 * Function version: 1.0
 * Input parameters: - Color (WORD)
 * Return value:     BOOL
 * Description:      setting the console color
 * Example:          Color (FRONT_WHITE | BACK_LIGHTGREY);
 *                   You'll find color names in the header file color.h
 * Limits:           none
 * Warnings:         none
 *
 * Updates:
 *   - (!! here you write the updates - do not remove this line !!)
 *
 */
BOOL SetColor (WORD Color)
{
	return SetConsoleTextAttribute (GetStdHandle (STD_OUTPUT_HANDLE), Color);
}
/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Function name:    ConsoleTitle
 * Function version: 1.0
 * Input parameters: - String (char *)
 *                   - ...
 * Return value:     none
 * Description:      setting the console title
 * Example:          ConsoleTitle ("MyTitle");
 * Limits:           none
 * Warnings:         none
 *
 * Updates:
 *   - (!! here you write the updates - do not remove this line !!)
 *
 */
void ConsoleTitle (char *String, ...)
{
	va_list List;
	char FormattedString[80] = {0};


	
    va_start (List, String);
		vsprintf (FormattedString, String, List);
	va_end (List);
	SetConsoleTitle (FormattedString);
}
/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Function name:    Print
 * Function version: 1.0
 * Input parameters: - x      (int)
 *                   - y      (int)
 *                   - Color  (WORD)
 *                   - String (char *)
 *                   - ...
 * Return value:     none
 * Description:      prints text on the screen
 * Example:          Print (0, 0, FRONT_LIGHTGREY, "MyText");
 * Limits:           none
 * Warnings:         none
 *
 * Updates:
 *   - (!! here you write the updates - do not remove this line !!)
 *
 */
void Print (int x, int y, WORD Color, char *String, ...)
{
	COORD screenPosition = {0};
    int i = 0, FormattedStringLength = 0;
    va_list List;
	char FormattedString[100] = {0};
	HANDLE hOutput;
	DWORD  NoOfCharsWritten = 0, NoOfAttrsWritten = 0;

	

    va_start (List, String);
		vsprintf (FormattedString, String, List);
		FormattedStringLength = (short) strlen (FormattedString);
	va_end (List);
	if ( (x >= 0) && (x <= 79) && (y >= 0) && (x+FormattedStringLength <= 80) && (y <= 25) )
	{
		hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
		for (i = 0; i < FormattedStringLength; i++)
		{
			screenPosition.X = (short) (x + i);
			screenPosition.Y = (short) y;
			WriteConsoleOutputCharacter (hOutput, &FormattedString[i], 1, screenPosition, &NoOfCharsWritten);
			WriteConsoleOutputAttribute (hOutput, &Color, 1, screenPosition, &NoOfAttrsWritten);
		}
		if (NoOfAttrsWritten != NoOfCharsWritten)
		{
			ErrorMsg ("Error occured while writting characters and         attributes on the screen in function Print (file    \"main.c\"). NoOfCharsWritten = %02d ; NoOfAttrsWritten = %02d.", NoOfCharsWritten, NoOfAttrsWritten);
		}
	}
	else
	{
		if ( !(x >= 0 && x <= 79) )
		{
			ErrorMsg ("Error occured in function Print (file \"main.c\").    Value x is not between 0 and 79 (x = %02d).", x);
		}
		if ( !(y >= 0 && y <= 24)  )
		{
			ErrorMsg ("Error occured in function Print (file \"main.c\").    Value y is not between 0 and 24 (y = %02d).", y);
		}
		if ( !(x+FormattedStringLength <= 80) )
		{
			ErrorMsg ("Error occured in function Print (file \"main.c\").    Value x+FormattedStringLength is over 80            (x+FormattedStringLength = %02d).", x+FormattedStringLength);
		}
	}
}
/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Function name:    ShowScreenCursor
 * Function version: 1.0
 * Input parameters: - Show (BOOL)
 * Return value:     none
 * Description:      setting the console screen cursor
 * Example:          ShowScreenCursor (TRUE); // this will turn on the screen cursor
 * Limits:           none
 * Warnings:         none
 *
 * Updates:
 *   - (!! here you write the updates - do not remove this line !!)
 *
 */
BOOL ShowScreenCursor (BOOL Show)
{
	CONSOLE_CURSOR_INFO cci = {0};
	BOOL StatusCCI = 0;



	if (Show) // show screen cursor
	{
		cci.dwSize   = 30;
		cci.bVisible = 1;
		StatusCCI    = SetConsoleCursorInfo (GetStdHandle (STD_OUTPUT_HANDLE), &cci);		
	}
	else // hide screen cursor
	{
		cci.dwSize   = 100;
		cci.bVisible = 0;
		StatusCCI    = SetConsoleCursorInfo (GetStdHandle (STD_OUTPUT_HANDLE), &cci);
	}
	if (!StatusCCI)
	{
		ErrorMsg ("Error occured in function ShowScreenCursor (file    \"main.c\"). Error code number = %u.", GetLastError ());
	}
	return StatusCCI;
}
/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Function name:    ErrorMsg
 * Function version: 1.0
 * Input parameters: - Message (char *)
 *                   - ...
 * Return value:     none
 * Description:      displays error message
 * Example:          ErrorMsg ("Error No.: %d", 5);
 * Limits:           dbErrMsg->Height+10+MsgCharY-1 < 25 --> look at the code for more information
 * Warnings:         programmer must properly format the text, otherwise some characters might get lost :(
 *
 * Updates:
 *   - (!! here you write the updates - do not remove this line !!)
 *
 */
void ErrorMsg (char *Message, ...)
{
	// input variables
	HANDLE Stdin = 0;
	INPUT_RECORD ir = {0};
	DWORD Read = 0;
	// component variables
	DIALOGBOX_COMPONENT *dbErrMsg = NULL;
	// common variables
	int i = 0, j = 0; // counters
	int MsgCharY = 0, MsgCharX2 = 0, MsgCharX1 = 0, MsgCharCount = 0; // variables used for formatting the text
	int HelpIsDisplayed = 0; // flag which becomes true if help text is displayed in the status line
	int xItemNameLength = 0, MsgLength = 0;
	va_list List;
	char FormattedMessage[1000] = {0};
	// variables for menu buttons (Close, Save To File and Exit)
	int ErrMsgDialogLoop = 0, xStartMenu[ERRMSG_MENU_NO_OF_ITEMS] = {0}, ErrMsgMenuValue = ERRMSG_MENU_DEFAULT_SELECTED;
	int xEndMenu[ERRMSG_MENU_NO_OF_ITEMS] = {0}, yStartMenu[ERRMSG_MENU_NO_OF_ITEMS] = {0};
	int WriteMenu = 0, MarkMenu = 0, MenuIndex = 0, MenuClicked = 0;
	int MenuTempIndex = ERRMSG_MENU_DEFAULT_SELECTED, MenuSelected = 0;
	char *ErrMsgMenuItems[ERRMSG_MENU_NO_OF_ITEMS] = {0}, *ErrMsgMenuHelp[ERRMSG_MENU_NO_OF_ITEMS] = {0};
	// options
	WORD ItemColor = 0, ItemHighLightColor = 0, DisabledItemColor = 0, DisabledItemHighLightColor = 0;
	WORD HelpColor = 0;
	int DisabledItem[3] = {0}, ShowHelp = 0;
	// Save To File variables
	FILE *FileSave = NULL;
	// time and date
	char *DateTime = NULL;



	// reload menu item colors
	ItemColor                  = FRONT_LIGHTGREY;
	ItemHighLightColor         = FRONT_WHITE;
	DisabledItemColor          = FRONT_DARKGREEN;
	DisabledItemHighLightColor = FRONT_LIGHTGREEN;
	HelpColor                  = FRONT_WHITE | BACK_LIGHTGREY;
	// enable button Close and Save To File
	DisabledItem[0] = FALSE;
	DisabledItem[1] = FALSE;
	DisabledItem[2] = FALSE;
	ShowHelp        = TRUE;
	Stdin           = GetStdHandle (STD_INPUT_HANDLE);
	va_start (List, Message);
		vsprintf (FormattedMessage, Message, List);
	va_end (List);
	// initialize ErrMsg dialog
	if ((dbErrMsg = (DIALOGBOX_COMPONENT *) malloc (sizeof (DIALOGBOX_COMPONENT))) != NULL)
	{
		MsgLength = (int) strlen (FormattedMessage);
		dbErrMsg->Length = 65;
		dbErrMsg->x = ((CONSOLE_LENGTH - 1 - dbErrMsg->Length) / 2);
		dbErrMsg->y = 6;
		dbErrMsg->Height = 0;
		// analyzing text
		MsgCharY = 0;
		for (i = 0; i < MsgLength; i++)
		{
			if (MsgCharCount + dbErrMsg->x + 8 >= dbErrMsg->Length - dbErrMsg->x + 8)
			{
				MsgCharX1++;
				MsgCharY++;
				MsgCharX2 = -1;
				MsgCharCount = -1;
			}
			MsgCharX2++;
			MsgCharCount++;
		}
		if (dbErrMsg->Height+10+MsgCharY-1 < 25) dbErrMsg->Height = 10+MsgCharY-1;
		else
		{
			Print (0, 0, FRONT_LIGHTGREY, "Error message is too long!");
			Print (0, 2, FRONT_LIGHTGREY, "Press any key to exit to the system ...");
			
		}
		i = MsgCharY = MsgCharX2 = MsgCharX1 = MsgCharCount = 0;
		dbErrMsg->BorderColor        = FRONT_WHITE;
		dbErrMsg->IconColor          = FRONT_LIGHTGREY;
		dbErrMsg->IconHighLightColor = FRONT_WHITE;
		dbErrMsg->TitleColor         = FRONT_WHITE | BACK_DARKBLUE;
		dbErrMsg->ShadowColor        = BACK_DARKGREY;
		dbErrMsg->Active             = TRUE;
		dbErrMsg->EnableExitIcon     = TRUE;
		dbErrMsg->EnableHelpIcon     = FALSE;
		dbErrMsg->DoubleLineBorder   = FALSE;
		dbErrMsg->ExitIconClicked    = FALSE;
		dbErrMsg->HelpIconClicked    = FALSE;
		dbErrMsg->IsInitialized      = FALSE;
		dbErrMsg->Pattern            = ' ';
		dbErrMsg->TitlePattern       = ' ';
		dbErrMsg->ShadowPattern      = ' ';
		dbErrMsg->LeftAlignedTitle   = TRUE;
		dbErrMsg->CenterAlignedTitle = FALSE;
		dbErrMsg->RightAlignedTitle  = FALSE;
		dbErrMsg->EnableShadow       = TRUE;
		dbErrMsg->InputCodePage      = 1250;
		dbErrMsg->OutputCodePage     = 1250;
		sprintf (dbErrMsg->Title, "Error message");
		dbErrMsg = DialogBoxComponent (dbErrMsg, ir, TRUE);
	}
	else
	{
		Print (0, 0, FRONT_LIGHTGREY, "Error occured while allocating space for dbErrMsg variable");
		Print (0, 1, FRONT_LIGHTGREY, "in function ErrorMsg (file \"main.c\").");
		Print (0, 3, FRONT_LIGHTGREY, "Press any key to exit to the system ...");
		Wait ();
		exit (1);
	}
	// text: Close
	if ((ErrMsgMenuItems[0] = (char *) malloc (sizeof (char *) * (strlen ("Close") + 1))) != NULL)
	{
		strncpy (ErrMsgMenuItems[0], "Close", strlen ("Close") + 1);
	}
	else
	{
		Print (0, 0, FRONT_LIGHTGREY, "Error occured while allocating space for variable");
		Print (0, 1, FRONT_LIGHTGREY, "ErrMsgMenuItems[0] in function ErrMsg (file");
		Print (0, 2, FRONT_LIGHTGREY, "\"main.c\").");
		Print (0, 4, FRONT_LIGHTGREY, "Press any key to exit to the system ...");
		Wait ();
		exit (1);
	}
	// text: Save To File
	if ((ErrMsgMenuItems[1] = (char *) malloc (sizeof (char *) * (strlen ("Save To File") + 1))) != NULL)
	{
		strncpy (ErrMsgMenuItems[1], "Save To File", strlen ("Save To File") + 1);
	}
	else
	{
		Print (0, 0, FRONT_LIGHTGREY, "Error occured while allocating space for variable");
		Print (0, 1, FRONT_LIGHTGREY, "ErrMsgMenuItems[1] in function ErrMsg (file");
		Print (0, 2, FRONT_LIGHTGREY, "\"main.c\").");
		Print (0, 4, FRONT_LIGHTGREY, "Press any key to exit to the system ...");
		Wait ();
		exit (1);
	}
	// text: Exit
	if ((ErrMsgMenuItems[2] = (char *) malloc (sizeof (char *) * (strlen ("Exit") + 1))) != NULL)
	{
		strncpy (ErrMsgMenuItems[2], "Exit", strlen ("Exit") + 1);
	}
	else
	{
		Print (0, 0, FRONT_LIGHTGREY, "Error occured while allocating space for variable");
		Print (0, 1, FRONT_LIGHTGREY, "ErrMsgMenuItems[2] in function ErrMsg (file");
		Print (0, 2, FRONT_LIGHTGREY, "\"main.c\").");
		Print (0, 4, FRONT_LIGHTGREY, "Press any key to exit to the system ...");
		Wait ();
		exit (1);
	}
	// load menu help for each item
	// help: ErrMsg & close the dialog.
	if ((ErrMsgMenuHelp[0] = (char *) malloc (sizeof (char *) * (strlen ("Closes the dialog.") + 1 + HELP_ERASE_LENGTH))) != NULL)
	{
		strncpy (ErrMsgMenuHelp[0], "Closes the dialog.", strlen ("Closes the dialog.") + 1 + HELP_ERASE_LENGTH);
	}
	else
	{
		Print (0, 0, FRONT_LIGHTGREY, "Error occured while allocating space for variable");
		Print (0, 1, FRONT_LIGHTGREY, "ErrMsgMenuHelp[0] in function ErrMsg (file");
		Print (0, 2, FRONT_LIGHTGREY, "\"main.c\").");
		Print (0, 4, FRONT_LIGHTGREY, "Press any key to exit to the system ...");
		Wait ();
		exit (1);
	}
	if ((ErrMsgMenuHelp[1] = (char *) malloc (sizeof (char *) * (strlen ("Saves error message into a file \"error.log\" and closes the dialog box.") + 1 + HELP_ERASE_LENGTH))) != NULL)
	{
		strncpy (ErrMsgMenuHelp[1], "Saves error message into a file \"error.log\" and closes the dialog box.", strlen ("Saves error message into a file \"error.log\" and closes the dialog box.") + 1 + HELP_ERASE_LENGTH);
	}
	else
	{
		Print (0, 0, FRONT_LIGHTGREY, "Error occured while allocating space for variable");
		Print (0, 1, FRONT_LIGHTGREY, "ErrMsgMenuHelp[1] in function ErrMsg (file");
		Print (0, 2, FRONT_LIGHTGREY, "\"main.c\").");
		Print (0, 4, FRONT_LIGHTGREY, "Press any key to exit to the system ...");
		Wait ();
		exit (1);
	}
	if ((ErrMsgMenuHelp[2] = (char *) malloc (sizeof (char *) * (strlen ("Exits the program.") + 1 + HELP_ERASE_LENGTH))) != NULL)
	{
		strncpy (ErrMsgMenuHelp[2], "Exits the program.", strlen ("Exits the program.") + 1 + HELP_ERASE_LENGTH);
	}
	else
	{
		Print (0, 0, FRONT_LIGHTGREY, "Error occured while allocating space for variable");
		Print (0, 1, FRONT_LIGHTGREY, "ErrMsgMenuHelp[2] in function ErrMsg (file");
		Print (0, 2, FRONT_LIGHTGREY, "\"main.c\").");
		Print (0, 4, FRONT_LIGHTGREY, "Press any key to exit to the system ...");
		Wait ();
		exit (1);
	}
	// with this, before the help gets printed, I can avoid to delete the previous text - very useful
	// I don't have to use ClrScr function
	for (i = 0; i < ERRMSG_MENU_NO_OF_ITEMS; i++)
	{
		for (j = 0; j < HELP_ERASE_LENGTH; j++)
		{
			if (ErrMsgMenuHelp[i][j] == '\0')
			{
				ErrMsgMenuHelp[i][j] = ' ';
				ErrMsgMenuHelp[i][j+1] = '\0';
			}
		}
	}
	// calculate load menu coordinates
	for (i = 0, xItemNameLength = 0; i < ERRMSG_MENU_NO_OF_ITEMS; i++)
	{
		xStartMenu[i] = ERRMSG_MENU_X + xItemNameLength;
		xEndMenu[i] = xStartMenu[i] + (int) strlen (ErrMsgMenuItems[i]) - 1;
		yStartMenu[i] = ERRMSG_MENU_Y;
		xItemNameLength += 0 + (int) strlen (ErrMsgMenuItems[i]);
		// do not count the space for the last menu button
		if (i != ERRMSG_MENU_NO_OF_ITEMS-1) xItemNameLength += 0 + ERRMSG_MENU_SPACE_BETWEEN_ITEMS;
	}
	// print ErrMsg menu
	for (i = 0; i < ERRMSG_MENU_NO_OF_ITEMS; i++)
	{
		if (ERRMSG_MENU_DEFAULT_SELECTED == i)
		{
			// checking if the menu item is disabled. If it is then color it diferently
			if (DisabledItem[i]) Print (xStartMenu[i], yStartMenu[i], DisabledItemHighLightColor, "%s", ErrMsgMenuItems[i]);
			else Print (xStartMenu[i], yStartMenu[i], ItemHighLightColor, "%s", ErrMsgMenuItems[i]);
			MarkMenu = MenuSelected = 1;
			// print help in the status line
			if (ShowHelp)
			{
				Print (HELP_X, HELP_Y, HelpColor, "%s", ErrMsgMenuHelp[i]);
				HelpIsDisplayed = 1;
			}
		}
		else
		{
			if (DisabledItem[i]) Print (xStartMenu[i], yStartMenu[i], DisabledItemColor, "%s", ErrMsgMenuItems[i]);
			else Print (xStartMenu[i], yStartMenu[i], ItemColor, "%s", ErrMsgMenuItems[i]);
		}
	}
	// print exclamation mark
	Print (dbErrMsg->x + 2, dbErrMsg->y + 3, FRONT_WHITE | BACK_LIGHTRED, "    ");
	Print (dbErrMsg->x + 2, dbErrMsg->y + 4, FRONT_WHITE | BACK_LIGHTRED, " !! ");
	Print (dbErrMsg->x + 2, dbErrMsg->y + 5, FRONT_WHITE | BACK_LIGHTRED, "    ");
	// formating text in a dialog box
	MsgCharY = 0;
	for (i = 0; i < MsgLength; i++)
	{
		if (MsgCharCount + dbErrMsg->x + 8 >= dbErrMsg->Length - dbErrMsg->x + 8)
		{
			Print (dbErrMsg->x + 8 + MsgCharX1, dbErrMsg->y + 5 + MsgCharY, FRONT_LIGHTGREY, "%c", FormattedMessage[i]);
			MsgCharX1++;
			MsgCharY++;
			MsgCharX2 = -1;
			MsgCharCount = -1;
		}
		else Print (dbErrMsg->x+8+MsgCharX2, dbErrMsg->y+4+MsgCharY, FRONT_LIGHTGREY, "%c", FormattedMessage[i]);
		MsgCharX2++;
		MsgCharCount++;
	}
	// load main loop
	ErrMsgDialogLoop = 1;
	while (ErrMsgDialogLoop)
	{
		ReadConsoleInput (Stdin, &ir, 1, &Read);
		dbErrMsg = DialogBoxComponent (dbErrMsg, ir, FALSE);
		if (dbErrMsg->ExitIconClicked)
		{
			// same as Close button
			ErrMsgDialogLoop = 0;
			// free memory
			for (i = 0; i < ERRMSG_MENU_NO_OF_ITEMS; i++)
			{
				free (ErrMsgMenuItems[i]);
				ErrMsgMenuItems[i] = NULL;
				free (ErrMsgMenuHelp[i]);
				ErrMsgMenuHelp[i] = NULL;
			}
			free (dbErrMsg);
			dbErrMsg = NULL;
		}
		// mouse
		if (ir.EventType == MOUSE_EVENT)
		{
			if (ir.Event.MouseEvent.dwEventFlags == MOUSE_MOVED)
			{
				// within the range of a load menu items
				if ( (ir.Event.MouseEvent.dwMousePosition.X >= xStartMenu[MenuIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.X <= xEndMenu[MenuIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.Y == yStartMenu[MenuIndex]) )
				{
					// print the menu button only once
					if ( (MenuTempIndex != MenuIndex) || (!MenuSelected) )
					{
						WriteMenu = 1;
						MarkMenu = MenuSelected = 1;
						MenuTempIndex = MenuIndex;
						MenuIndex++;
						if (MenuIndex >= ERRMSG_MENU_NO_OF_ITEMS) MenuIndex = 0;
					}
				}
				else
				{
					MenuClicked = 0;
					// menu
					MenuIndex++;
					if (MenuIndex >= ERRMSG_MENU_NO_OF_ITEMS) MenuIndex = 0;
				}
			} // end if MOUSE_MOVED
			if (ir.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED) // left mouse click
			{
				// within the range of a horizontal menu button
				if ( (ir.Event.MouseEvent.dwMousePosition.X >= xStartMenu[MenuTempIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.X <= xEndMenu[MenuTempIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.Y == yStartMenu[MenuTempIndex]) )
				{
					if (!MenuClicked)
					{
						// simulating key return
						keybd_event	(VK_RETURN,	0x1c, 0, 0);
						keybd_event	(VK_RETURN,	0x1c, KEYEVENTF_KEYUP, 0);
					}
				}
				else
				{
					if (MenuSelected)
					{
						// menu
						WriteMenu = 1; MarkMenu = MenuSelected = 0;
					}
				}
			} // end if FROM_LEFT_1ST_BUTTON_PRESSED
		} // end if MOUSE_EVENT
		// if component is selected
		if (MenuSelected)
		{
			if (ir.EventType == KEY_EVENT && ir.Event.KeyEvent.bKeyDown)
			{
				// key F10 for menu
				if (ir.Event.KeyEvent.wVirtualKeyCode == VK_F10)
				{
					// menu
					MenuSelected  = 1;
					WriteMenu     = 1;
					MarkMenu      = 1;
					MenuClicked   = 0;
				}
				// left arrow key
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_LEFT)
				{
					if (MenuSelected)
					{
						WriteMenu = 1;
						MarkMenu  = 1;
						MenuTempIndex -= 1;
						MenuClicked = 0;
						if (MenuTempIndex < 0) MenuTempIndex = ERRMSG_MENU_NO_OF_ITEMS-1;
					}
				}
				// right arrow key
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_RIGHT)
				{
					if (MenuSelected)
					{
						WriteMenu = 1;
						MarkMenu  = 1;
						MenuTempIndex += 1;
						MenuClicked = 0;
						if (MenuTempIndex >= ERRMSG_MENU_NO_OF_ITEMS) MenuTempIndex = 0;
					}
				}
				// return and space key
				else if ( (ir.Event.KeyEvent.wVirtualKeyCode == VK_RETURN) ||
					      (ir.Event.KeyEvent.wVirtualKeyCode == VK_SPACE) )
				{
					if (!MenuClicked)
					{
						ErrMsgMenuValue = MenuTempIndex;
						if (ErrMsgMenuValue == ERRMSG_MENU_CLOSE)
						{
							MenuClicked = 1;
							MarkMenu = 1;
							ErrMsgDialogLoop = 0;
							dbErrMsg->Active = 0;
							// write previous data back on the screen
							WriteDialogBoxData (dbErrMsg->Data, dbErrMsg->x, dbErrMsg->y, dbErrMsg->Length, dbErrMsg->Height);
							// free memory
							for (i = 0; i < ERRMSG_MENU_NO_OF_ITEMS; i++)
							{
								free (ErrMsgMenuItems[i]);
								ErrMsgMenuItems[i] = NULL;
								free (ErrMsgMenuHelp[i]);
								ErrMsgMenuHelp[i] = NULL;
							}
							free (dbErrMsg);
							dbErrMsg = NULL;
						}
						else if (ErrMsgMenuValue == ERRMSG_MENU_SAVETOFILE)
						{
							MenuClicked = 1;
							MarkMenu = 1;
							ErrMsgDialogLoop = 0;
							dbErrMsg->Active = 0;
							// save error message into a file
							if ((FileSave = fopen ("error.log", "at+")) != NULL)
							{
								if ((DateTime = TimeDate ()) != NULL)
								{
									fprintf (FileSave, "------------------ Error message generated at %s ------------------\n", DateTime); 
									fprintf (FileSave, "%s\n", FormattedMessage);
									fprintf (FileSave, "----------------------------------------------------------------------------------\n\n");
									fclose (FileSave);
									free (DateTime);
									DateTime = NULL;
								}
								else
								{
									Print (0, 0, FRONT_LIGHTGREY, "Can not read date and time from function TimeDate () in function");
									Print (0, 1, FRONT_LIGHTGREY, "ErrorMsg (file \"main.c\").");
									Print (0, 3, FRONT_LIGHTGREY, "Press any key to exit to the system ...");
									Wait ();
									exit (1);
								}
							}
							else
							{
								Print (0, 0, FRONT_LIGHTGREY, "Can not create file \"error.log\".");
								Print (0, 2, FRONT_LIGHTGREY, "Press any key to exit to the system ...");
								Wait ();
								exit (1);
							}
							// write previous data back on the screen
							WriteDialogBoxData (dbErrMsg->Data, dbErrMsg->x, dbErrMsg->y, dbErrMsg->Length, dbErrMsg->Height);
							// free memory
							for (i = 0; i < ERRMSG_MENU_NO_OF_ITEMS; i++)
							{
								free (ErrMsgMenuItems[i]);
								ErrMsgMenuItems[i] = NULL;
								free (ErrMsgMenuHelp[i]);
								ErrMsgMenuHelp[i] = NULL;
							}
							free (dbErrMsg);
							dbErrMsg = NULL;
						}
						else if (ErrMsgMenuValue == ERRMSG_MENU_EXIT)
						{
							MenuClicked = 1;
							MarkMenu = 1;
							ErrMsgDialogLoop = 0;
							dbErrMsg->Active = 0;
							// write previous data back on the screen
							WriteDialogBoxData (dbErrMsg->Data, dbErrMsg->x, dbErrMsg->y, dbErrMsg->Length, dbErrMsg->Height);
							// free memory
							for (i = 0; i < ERRMSG_MENU_NO_OF_ITEMS; i++)
							{
								free (ErrMsgMenuItems[i]);
								ErrMsgMenuItems[i] = NULL;
								free (ErrMsgMenuHelp[i]);
								ErrMsgMenuHelp[i] = NULL;
							}
							free (dbErrMsg);
							dbErrMsg = NULL;
							exit (1);
						}
					}
				} // end if key return or space was pressed
			} // end if keyboard
		}
		else // end if MenuSelected
		{
			if ( (ShowHelp) && (HelpIsDisplayed) )
			{
				Print (HELP_X, HELP_Y, HelpColor, "Press F10 for menu.                                                          ");
				HelpIsDisplayed = FALSE;
			}
			// these keys are available only when the component is unselected
			if (ir.EventType == KEY_EVENT && ir.Event.KeyEvent.bKeyDown)
			{
				// key F10 for menu
				if (ir.Event.KeyEvent.wVirtualKeyCode == VK_F10)
				{
					// menu
					MenuSelected  = 1;
					WriteMenu     = 1;
					MarkMenu      = 1;
					MenuClicked   = 0;
				}
			} // end if (ir.EventType == KEY_EVENT && ir.Event.KeyEvent.bKeyDown)
		} // end if !MenuSelected
		// printing menu items
		if (WriteMenu)
		{
			for (i = 0; i < ERRMSG_MENU_NO_OF_ITEMS; i++)
			{
				if (ErrMsgMenuItems[i] != NULL)
				{
					if (DisabledItem[i]) Print (xStartMenu[i], yStartMenu[i], DisabledItemColor, "%s", ErrMsgMenuItems[i]);
					else Print (xStartMenu[i], yStartMenu[i], ItemColor, "%s", ErrMsgMenuItems[i]);
				}
			}
			if (MarkMenu)
			{
				if (ErrMsgMenuItems[MenuTempIndex] != NULL)
				{
					if (DisabledItem[MenuTempIndex]) Print (xStartMenu[MenuTempIndex], yStartMenu[MenuTempIndex], DisabledItemHighLightColor, "%s", ErrMsgMenuItems[MenuTempIndex]);
					else Print (xStartMenu[MenuTempIndex], yStartMenu[MenuTempIndex], ItemHighLightColor, "%s", ErrMsgMenuItems[MenuTempIndex]);
					// print help in the status line
					if (ShowHelp)
					{
						Print (HELP_X, HELP_Y, HelpColor, "%s", ErrMsgMenuHelp[MenuTempIndex]);
						HelpIsDisplayed = 1;
					}
				}
				MarkMenu = 0;
			}
			WriteMenu = 0;
		}
	} // end of while (ErrMsgDialogLoop)
}
char *DecToHex (int Dec)
{
	char *HexNumber = NULL;
	int Temp = 0, i = 0, Number = 0;



	if ((HexNumber = (char *) malloc (sizeof (char) * 3)) != NULL)
	{
		for (i = 0; i < BIT_HEX; i++)
		{
			Temp = Dec;
			Dec = Dec / 16;
			Number = Temp - (Dec * 16);
			if      (Number < 10)  HexNumber[BIT_HEX-1-i] = 48 + (char) Number;
			if      (Number == 10) HexNumber[BIT_HEX-1-i] = 'A';
			else if (Number == 11) HexNumber[BIT_HEX-1-i] = 'B';
			else if (Number == 12) HexNumber[BIT_HEX-1-i] = 'C';
			else if (Number == 13) HexNumber[BIT_HEX-1-i] = 'D';
			else if (Number == 14) HexNumber[BIT_HEX-1-i] = 'E';
			else if (Number == 15) HexNumber[BIT_HEX-1-i] = 'F';
		}
		HexNumber[BIT_HEX] = '\0';
	}
	else
	{
		ErrorMsg ("Error occured while allocating space for variable   HexNumber in function DecToHex (file \"main.c\").");
	}
	return HexNumber;
}
void Wait ()
{
	getch ();
}