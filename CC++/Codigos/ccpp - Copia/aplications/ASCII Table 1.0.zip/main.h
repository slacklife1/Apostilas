/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Author: Ga�per Raj�ek
 * E-mail, updates & bugs report: gape.korn@volja.net
 *
 * Created: 03.08.2003 at 12.04
 *
 * Description: main function prototypes and constants for this program
 *
 */

# ifndef MAIN_H
# define MAIN_H



# include <windows.h>
# include <stdio.h>
# include <string.h>
# include <conio.h>
# include <time.h>
# include "colors.h"
# include "shape.h"
# include "groupbox.h"
# include "dialogbox.h"



// program title
# define PROGRAM_TITLE "ASCII Table 1.0"
// ASCII graphical elements for drawing a frame
# define RIGHT_DOWN_LINE            218
# define RIGHT_DOWN_DOUBLELINE      201
# define RIGHT_UP_LINE              192
# define RIGHT_UP_DOUBLELINE        200
# define LEFT_DOWN_LINE             191
# define LEFT_DOWN_DOUBLELINE       187
# define LEFT_UP_LINE               217
# define LEFT_UP_DOUBLELINE         188
# define HORIZONTAL_LINE            196
# define HORIZONTAL_DOUBLELINE      205
# define HORIZONTAL_DOWN_LINE       194
# define HORIZONTAL_DOWN_DOUBLELINE 203
# define HORIZONTAL_UP_LINE         193
# define HORIZONTAL_UP_DOUBLELINE   202
# define VERTICAL_LINE              179
# define VERTICAL_DOUBLELINE        186
# define VERTICAL_RIGHT_LINE        195
# define VERTICAL_RIGHT_DOUBLELINE  204
# define VERTICAL_LEFT_LINE         180
# define VERTICAL_LEFT_DOUBLELINE   185
# define ALL_DIRECTIONS_LINE        197
# define ALL_DIRECTIONS_DOUBLELINE  206

// constant for ALT key
# define LEFT_ALT 34

// console length and height constants
# define CONSOLE_LENGTH 80
# define CONSOLE_HEIGHT 25

// help constants
# define HELP_X                 2 
# define HELP_Y                 23
# define HELP_ERASE_LENGTH      77
# define HELP_ERASE_NO_OF_LINES 1
# define HELP_ERASE_COLOR       BACKGROUND_COLOR
# define HELP_COLOR             FRONT_LIGHTGREY | BACKGROUND_COLOR
# define HELP_ERASE_PATTERN     ' '

// main menu constants
# define MAIN_MENU_X                   60
# define MAIN_MENU_Y                   11
# define MAIN_MENU_NO_OF_ITEMS         4
# define MAIN_MENU_SPACE_BETWEEN_ITEMS 1
# define MAIN_MENU_DEFAULT_SELECTED    0
// main menu item values
# define MAIN_MENU_SHOW_ASCII_TABLE 0
# define MAIN_MENU_HELP             1
# define MAIN_MENU_AUTHOR           2
# define MAIN_MENU_EXIT             3
// constants for edit box
# define CODEPAGE_EB_WHOLE_NO 1
# define CODEPAGE_EB_CODEPAGE 0

// ERROR MESSAGE DIALOG CONSTANTS
// menu constants
# define ERRMSG_MENU_X                   (dbErrMsg->x + ((dbErrMsg->Length - 5 - (int) strlen ("Close") - (int) strlen ("Save To File") - (int) strlen ("Exit")) / 2))
# define ERRMSG_MENU_Y                   ((dbErrMsg->y + dbErrMsg->Height) - 3)
# define ERRMSG_MENU_NO_OF_ITEMS         3
# define ERRMSG_MENU_SPACE_BETWEEN_ITEMS 5
# define ERRMSG_MENU_DEFAULT_SELECTED    0
// menu item values
# define ERRMSG_MENU_CLOSE      0
# define ERRMSG_MENU_SAVETOFILE 1
# define ERRMSG_MENU_EXIT       2

// constants for starting horizontal and vertical x and y coordinates
# define hX                 6
# define hY                 3
# define vX            (hX-3)
# define vY            (hY+2)
# define PRINT_ASCII_Y (hY+1)

// HEX
# define BIT_HEX 2

// structure for console characters
typedef struct _CONSOLE_CHARACTER
{
	char Characters[80][80];
	WORD Colors[80][80];
} CONSOLE_CHARACTER;


// function prototypes
void GotoXY (int x, int y);
void ClrScr (int x, int y, int EraseLength, int NoOfLines, WORD EraseColor, char ErasePattern);
BOOL SetColor (WORD Color);
void ConsoleTitle (char *String, ...);
void Print (int x, int y, WORD Color, char *String, ...);
BOOL ShowScreenCursor (BOOL Show);
void ErrorMsg (char *Message, ...);
CONSOLE_CHARACTER ReadData (CONSOLE_CHARACTER cc, int ReadX, int ReadY, int ReadLength, int ReadHeight);
void WriteData (CONSOLE_CHARACTER cc, int WriteX, int WriteY, int WriteLength, int WriteHeight);
void ProgramInit (void);
void DrawASCIIFramework (void);
void ASCII_Table (unsigned int CodePage);
char *TimeDate (void);
char *DecToHex (int Dec);
void Wait (void);

# endif // MAIN_H