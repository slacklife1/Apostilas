/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Author: Ga�per Raj�ek
 * E-mail, updates & bugs report: gape.korn@volja.net
 *
 * Created: 03.08.2003 at 15.00
 *
 * Description: Shows help about the program
 *
 */

# include "main.h"
# include "help.h"



/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Function name:    HelpDIalog
 * Function version: 1.0
 * Input parameters: none
 * Return value:     none
 * Description:      displays help
 * Example:          HelpDialog ();
 * Limits:           none
 * Warnings:         none
 *
 * Updates:
 *   - (!! here you write the updates - do not remove this line !!)
 *
 */
void HelpDialog ()
{
	// input variables
	HANDLE Stdin = GetStdHandle (STD_INPUT_HANDLE);
	INPUT_RECORD ir = {0};
	DWORD Read = 0;
	// component variables
	DIALOGBOX_COMPONENT *dbHelp = NULL;
	// common variables
	int i = 0, j = 0; // counters
	int HelpIsDisplayed = 0; // flag which becomes true if help text is displayed in the status line
	int xItemNameLength = 0;
	// variables for menu button (Close)
	int HelpDialogLoop = 0, xStartMenu[HELP_MENU_NO_OF_ITEMS] = {0}, HelpMenuValue = HELP_MENU_DEFAULT_SELECTED;
	int xEndMenu[HELP_MENU_NO_OF_ITEMS] = {0}, yStartMenu[HELP_MENU_NO_OF_ITEMS] = {0};
	int WriteMenu = 0, MarkMenu = 0, MenuIndex = 0, MenuClicked = 0;
	int MenuTempIndex = HELP_MENU_DEFAULT_SELECTED, MenuSelected = 0;
	char *HelpMenuItems[HELP_MENU_NO_OF_ITEMS] = {0}, *HelpMenuHelp[HELP_MENU_NO_OF_ITEMS] = {0};
	// options
	WORD ItemColor = 0, ItemHighLightColor = 0, DisabledItemColor = 0, DisabledItemHighLightColor = 0;
	WORD HelpColor = 0;
	int DisabledItem[2] = {0}, ShowHelp = 0;



	// reload menu item colors
	ItemColor                  = FRONT_LIGHTGREY;
	ItemHighLightColor         = FRONT_WHITE;
	DisabledItemColor          = FRONT_DARKGREEN;
	DisabledItemHighLightColor = FRONT_LIGHTGREEN;
	HelpColor                  = FRONT_WHITE | BACK_LIGHTGREY;
	// enable button Close and Save To File
	DisabledItem[0] = FALSE;
	ShowHelp        = TRUE;
	// initialize Help dialog
	if ((dbHelp = (DIALOGBOX_COMPONENT *) malloc (sizeof (DIALOGBOX_COMPONENT))) != NULL)
	{
		dbHelp->Length             = 68;
		dbHelp->x                  = ((CONSOLE_LENGTH - 1 - dbHelp->Length) / 2);
		dbHelp->y                  = 3;
		dbHelp->Height             = 17;
		dbHelp->BorderColor        = FRONT_WHITE;
		dbHelp->IconColor          = FRONT_LIGHTGREY;
		dbHelp->IconHighLightColor = FRONT_WHITE;
		dbHelp->TitleColor         = FRONT_WHITE | BACK_DARKBLUE;
		dbHelp->ShadowColor        = BACK_DARKGREY;
		dbHelp->Active             = TRUE;
		dbHelp->EnableExitIcon     = TRUE;
		dbHelp->EnableHelpIcon     = FALSE;
		dbHelp->DoubleLineBorder   = FALSE;
		dbHelp->ExitIconClicked    = FALSE;
		dbHelp->HelpIconClicked    = FALSE;
		dbHelp->IsInitialized      = FALSE;
		dbHelp->Pattern            = ' ';
		dbHelp->TitlePattern       = ' ';
		dbHelp->ShadowPattern      = ' ';
		dbHelp->LeftAlignedTitle   = TRUE;
		dbHelp->CenterAlignedTitle = FALSE;
		dbHelp->RightAlignedTitle  = FALSE;
		dbHelp->EnableShadow       = TRUE;
		dbHelp->InputCodePage      = 1250;
		dbHelp->OutputCodePage     = 1250;
		sprintf (dbHelp->Title, "Help");
		dbHelp = DialogBoxComponent (dbHelp, ir, TRUE);
	}
	else
	{
		ErrorMsg ("Error occured while allocating space for dbHelp     variable in function HelpDialog (file \"help.c\").");
	}
	// text: Close
	if ((HelpMenuItems[0] = (char *) malloc (sizeof (char *) * (strlen ("Close") + 1))) != NULL)
	{
		strncpy (HelpMenuItems[0], "Close", strlen ("Close") + 1);
	}
	else
	{
		ErrorMsg ("Error occured while allocating space for            HelpMenuItems[0] variable in function HelpDialog    (file \"help.c\").");
	}
	// load menu help for each item
	// help: Help & close the dialog.
	if ((HelpMenuHelp[0] = (char *) malloc (sizeof (char *) * (strlen ("Closes the dialog.") + 1 + HELP_ERASE_LENGTH))) != NULL)
	{
		strncpy (HelpMenuHelp[0], "Closes the dialog.", strlen ("Closes the dialog.") + 1 + HELP_ERASE_LENGTH);
	}
	else
	{
		ErrorMsg ("Error occured while allocating space for            HelpMenuHelp[0] variable in function HelpDialog    (file \"help.c\").");
	}
	// with this, before the help gets printed, I can avoid to delete the previous text - very useful
	// I don't have to use ClrScr function
	for (i = 0; i < HELP_MENU_NO_OF_ITEMS; i++)
	{
		for (j = 0; j < HELP_ERASE_LENGTH; j++)
		{
			if (HelpMenuHelp[i][j] == '\0')
			{
				HelpMenuHelp[i][j] = ' ';
				HelpMenuHelp[i][j+1] = '\0';
			}
		}
	}
	// calculate load menu coordinates
	for (i = 0, xItemNameLength = 0; i < HELP_MENU_NO_OF_ITEMS; i++)
	{
		xStartMenu[i] = HELP_MENU_X + xItemNameLength;
		xEndMenu[i] = xStartMenu[i] + (int) strlen (HelpMenuItems[i]) - 1;
		yStartMenu[i] = HELP_MENU_Y;
		xItemNameLength += 0 + (int) strlen (HelpMenuItems[i]);
		// do not count the space for the last menu button
		if (i != HELP_MENU_NO_OF_ITEMS-1) xItemNameLength += 0 + HELP_MENU_SPACE_BETWEEN_ITEMS;
	}
	// print Help menu
	for (i = 0; i < HELP_MENU_NO_OF_ITEMS; i++)
	{
		if (HELP_MENU_DEFAULT_SELECTED == i)
		{
			// checking if the menu item is disabled. If it is then color it diferently
			if (DisabledItem[i]) Print (xStartMenu[i], yStartMenu[i], DisabledItemHighLightColor, "%s", HelpMenuItems[i]);
			else Print (xStartMenu[i], yStartMenu[i], ItemHighLightColor, "%s", HelpMenuItems[i]);
			MarkMenu = MenuSelected = 1;
			// print help in the status line
			if (ShowHelp)
			{
				Print (HELP_X, HELP_Y, HelpColor, "%s", HelpMenuHelp[i]);
				HelpIsDisplayed = 1;
			}
		}
		else
		{
			if (DisabledItem[i]) Print (xStartMenu[i], yStartMenu[i], DisabledItemColor, "%s", HelpMenuItems[i]);
			else Print (xStartMenu[i], yStartMenu[i], ItemColor, "%s", HelpMenuItems[i]);
		}
	}
	// texts in the dialog
	Print (dbHelp->x + 1, dbHelp->y + 3,  FRONT_LIGHTGREY, "ASCII Table 1.0 program works only on Win9x and WinNT OS's.");
	Print (dbHelp->x + 1, dbHelp->y + 4,  FRONT_LIGHTGREY, "You can choose between all of the code page's that OS supports.");
	Print (dbHelp->x + 1, dbHelp->y + 5,  FRONT_LIGHTGREY, "Code page can be between 1 and 65001.");
	Print (dbHelp->x + 1, dbHelp->y + 6,  FRONT_LIGHTGREY, "Note: - In Win9x is only the default code page available.");
	Print (dbHelp->x + 1, dbHelp->y + 8,  FRONT_LIGHTRED,  "SHORTCUTS");
	Print (dbHelp->x + 5, dbHelp->y + 10, FRONT_LIGHTGREY, "F10         - selects menu");
	Print (dbHelp->x + 5, dbHelp->y + 11, FRONT_LIGHTGREY, "ALT + C     - selects edit box");
	Print (dbHelp->x + 5, dbHelp->y + 12, FRONT_LIGHTGREY, "ALT + ENTER - toggle between fullscreen and window mode");
	// load main loop
	HelpDialogLoop = 1;
	while (HelpDialogLoop)
	{
		ReadConsoleInput (Stdin, &ir, 1, &Read);
		dbHelp = DialogBoxComponent (dbHelp, ir, FALSE);
		if (dbHelp->ExitIconClicked)
		{
			// same as Close button
			HelpDialogLoop = 0;
			// free memory
			for (i = 0; i < HELP_MENU_NO_OF_ITEMS; i++)
			{
				free (HelpMenuItems[i]);
				HelpMenuItems[i] = NULL;
				free (HelpMenuHelp[i]);
				HelpMenuHelp[i] = NULL;
			}
			free (dbHelp);
			dbHelp = NULL;
		}
		// mouse
		if (ir.EventType == MOUSE_EVENT)
		{
			if (ir.Event.MouseEvent.dwEventFlags == MOUSE_MOVED)
			{
				// within the range of a load menu items
				if ( (ir.Event.MouseEvent.dwMousePosition.X >= xStartMenu[MenuIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.X <= xEndMenu[MenuIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.Y == yStartMenu[MenuIndex]) )
				{
					// print the menu button only once
					if ( (MenuTempIndex != MenuIndex) || (!MenuSelected) )
					{
						WriteMenu = 1;
						MarkMenu = MenuSelected = 1;
						MenuTempIndex = MenuIndex;
						MenuIndex++;
						if (MenuIndex >= HELP_MENU_NO_OF_ITEMS) MenuIndex = 0;
					}
				}
				else
				{
					MenuClicked = 0;
					// menu
					MenuIndex++;
					if (MenuIndex >= HELP_MENU_NO_OF_ITEMS) MenuIndex = 0;
				}
			} // end if MOUSE_MOVED
			if (ir.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED) // left mouse click
			{
				// within the range of a horizontal menu button
				if ( (ir.Event.MouseEvent.dwMousePosition.X >= xStartMenu[MenuTempIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.X <= xEndMenu[MenuTempIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.Y == yStartMenu[MenuTempIndex]) )
				{
					if (!MenuClicked)
					{
						// simulating key return
						keybd_event	(VK_RETURN,	0x1c, 0, 0);
						keybd_event	(VK_RETURN,	0x1c, KEYEVENTF_KEYUP, 0);
					}
				}
				else
				{
					if (MenuSelected)
					{
						// menu
						WriteMenu = 1; MarkMenu = MenuSelected = 0;
					}
				}
			} // end if FROM_LEFT_1ST_BUTTON_PRESSED
		} // end if MOUSE_EVENT
		// if component is selected
		if (MenuSelected)
		{
			if (ir.EventType == KEY_EVENT && ir.Event.KeyEvent.bKeyDown)
			{
				// key F10 for menu
				if (ir.Event.KeyEvent.wVirtualKeyCode == VK_F10)
				{
					// menu
					MenuSelected  = 1;
					WriteMenu     = 1;
					MarkMenu      = 1;
					MenuClicked   = 0;
				}
				// left arrow key
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_LEFT)
				{
					if (MenuSelected)
					{
						WriteMenu = 1;
						MarkMenu  = 1;
						MenuTempIndex -= 1;
						MenuClicked = 0;
						if (MenuTempIndex < 0) MenuTempIndex = HELP_MENU_NO_OF_ITEMS-1;
					}
				}
				// right arrow key
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_RIGHT)
				{
					if (MenuSelected)
					{
						WriteMenu = 1;
						MarkMenu  = 1;
						MenuTempIndex += 1;
						MenuClicked = 0;
						if (MenuTempIndex >= HELP_MENU_NO_OF_ITEMS) MenuTempIndex = 0;
					}
				}
				// return and space key
				else if ( (ir.Event.KeyEvent.wVirtualKeyCode == VK_RETURN) ||
					      (ir.Event.KeyEvent.wVirtualKeyCode == VK_SPACE) )
				{
					if (!MenuClicked)
					{
						HelpMenuValue = MenuTempIndex;
						if (HelpMenuValue == HELP_MENU_CLOSE)
						{
							MenuClicked = 1;
							MarkMenu = 1;
							HelpDialogLoop = 0;
							dbHelp->Active = 0;
							// write previous data back on the screen
							WriteDialogBoxData (dbHelp->Data, dbHelp->x, dbHelp->y, dbHelp->Length, dbHelp->Height);
							// free memory
							for (i = 0; i < HELP_MENU_NO_OF_ITEMS; i++)
							{
								free (HelpMenuItems[i]);
								HelpMenuItems[i] = NULL;
								free (HelpMenuHelp[i]);
								HelpMenuHelp[i] = NULL;
							}
							free (dbHelp);
							dbHelp = NULL;
						}
					}
				} // end if key return or space was pressed
			} // end if keyboard
		}
		else // end if MenuSelected
		{
			if ( (ShowHelp) && (HelpIsDisplayed) )
			{
				Print (HELP_X, HELP_Y, HelpColor, "Press F10 for menu.                                                          ");
				HelpIsDisplayed = FALSE;
			}
			// these keys are available only when the component is unselected
			if (ir.EventType == KEY_EVENT && ir.Event.KeyEvent.bKeyDown)
			{
				// key F10 for menu
				if (ir.Event.KeyEvent.wVirtualKeyCode == VK_F10)
				{
					// menu
					MenuSelected  = 1;
					WriteMenu     = 1;
					MarkMenu      = 1;
					MenuClicked   = 0;
				}
			} // end if (ir.EventType == KEY_EVENT && ir.Event.KeyEvent.bKeyDown)
		} // end if !MenuSelected
		// printing menu items
		if (WriteMenu)
		{
			for (i = 0; i < HELP_MENU_NO_OF_ITEMS; i++)
			{
				if (HelpMenuItems[i] != NULL)
				{
					if (DisabledItem[i]) Print (xStartMenu[i], yStartMenu[i], DisabledItemColor, "%s", HelpMenuItems[i]);
					else Print (xStartMenu[i], yStartMenu[i], ItemColor, "%s", HelpMenuItems[i]);
				}
			}
			if (MarkMenu)
			{
				if (HelpMenuItems[MenuTempIndex] != NULL)
				{
					if (DisabledItem[MenuTempIndex]) Print (xStartMenu[MenuTempIndex], yStartMenu[MenuTempIndex], DisabledItemHighLightColor, "%s", HelpMenuItems[MenuTempIndex]);
					else Print (xStartMenu[MenuTempIndex], yStartMenu[MenuTempIndex], ItemHighLightColor, "%s", HelpMenuItems[MenuTempIndex]);
					// print help in the status line
					if (ShowHelp)
					{
						Print (HELP_X, HELP_Y, HelpColor, "%s", HelpMenuHelp[MenuTempIndex]);
						HelpIsDisplayed = 1;
					}
				}
				MarkMenu = 0;
			}
			WriteMenu = 0;
		}
	} // end of while (HelpDialogLoop)
}