/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Author: Ga�per Raj�ek
 * E-mail, updates & bugs report: gape.korn@volja.net
 *
 * Created: 16.8.2002 at 19->05
 *
 * Description: SHAPE component source
 *
 */

# include "main.h"

/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Function name:    FrameComponent
 * Function version: 1.0
 * Input parameters: - Frame (SHAPE_COMPONENT)
 * Return value:     none
 * Description:      draws a frame
 * Warnings:         none
 *
 * Updates:
 *   - (!! here you write the updates - do not remove this line !!)
 *
 */
void FrameComponent (SHAPE_COMPONENT *Frame)
{
	int i = 0, RightDownLine = 0, RightUpLine = 0, LeftDownLine = 0, LeftUpLine = 0;
	int HorizontalLine = 0, VerticalLine = 0, VerticalRightLine = 0, VerticalLeftLine = 0;



	// limits
	if ( (Frame->FRAME.x >= 0) && (Frame->FRAME.x <= 77) && (Frame->FRAME.x+Frame->FRAME.Length <= 79) && (Frame->FRAME.Length > 0) &&
		 (Frame->FRAME.y >= 0) && (Frame->FRAME.y <= 24) && (Frame->FRAME.y+Frame->FRAME.Height <= 24) && (Frame->FRAME.Height > 0) )
	{
		// hide screen cursor
		ShowScreenCursor (FALSE);
		// set codepage
		SetConsoleCP       (Frame->InputCodePage);
		SetConsoleOutputCP (Frame->OutputCodePage);
		// setting the graphical ASCII constants
		if (Frame->FRAME.DoubleLine)
		{
			// double line frame
			RightDownLine     = RIGHT_DOWN_DOUBLELINE;
			RightUpLine       = RIGHT_UP_DOUBLELINE;
			LeftDownLine      = LEFT_DOWN_DOUBLELINE;
			LeftUpLine        = LEFT_UP_DOUBLELINE;
			HorizontalLine    = HORIZONTAL_DOUBLELINE;
			VerticalLine      = VERTICAL_DOUBLELINE;
			VerticalRightLine = VERTICAL_RIGHT_DOUBLELINE;
			VerticalLeftLine  = VERTICAL_LEFT_DOUBLELINE;
		}
		else
		{
			// one line frame
			RightDownLine     = RIGHT_DOWN_LINE;
			RightUpLine       = RIGHT_UP_LINE;
			LeftDownLine      = LEFT_DOWN_LINE;
			LeftUpLine        = LEFT_UP_LINE;
			HorizontalLine    = HORIZONTAL_LINE;
			VerticalLine      = VERTICAL_LINE;
			VerticalRightLine = VERTICAL_RIGHT_LINE;
			VerticalLeftLine  = VERTICAL_LEFT_LINE;
		}
		// drawing a frame
		Print (Frame->FRAME.x, Frame->FRAME.y, Frame->FRAME.Color, "%c", RightDownLine);
		Print (Frame->FRAME.x, Frame->FRAME.y+Frame->FRAME.Height, Frame->FRAME.Color, "%c", RightUpLine);
		Print (Frame->FRAME.x+Frame->FRAME.Length, Frame->FRAME.y, Frame->FRAME.Color, "%c", LeftDownLine);
		Print (Frame->FRAME.x+Frame->FRAME.Length, Frame->FRAME.y+Frame->FRAME.Height, Frame->FRAME.Color, "%c", LeftUpLine);
		// loop for horizontal lines
		for (i = 1; i < Frame->FRAME.Length; i++)
		{
			Print (Frame->FRAME.x+i, Frame->FRAME.y, Frame->FRAME.Color, "%c", HorizontalLine);
			Print (Frame->FRAME.x+i, Frame->FRAME.y+Frame->FRAME.Height, Frame->FRAME.Color, "%c", HorizontalLine);
			// if the status line is true, then draw it
			if (Frame->FRAME.WithStatusLine) Print (Frame->FRAME.x+i, Frame->FRAME.y+Frame->FRAME.Height-2, Frame->FRAME.Color, "%c", HorizontalLine);
		}
		// loop for vertical lines
		for (i = 1; i < Frame->FRAME.Height; i++)
		{
			Print (Frame->FRAME.x, Frame->FRAME.y+i, Frame->FRAME.Color, "%c", VerticalLine);
			Print (Frame->FRAME.x+Frame->FRAME.Length, Frame->FRAME.y+i, Frame->FRAME.Color, "%c", VerticalLine);
			// status line
			if ( (Frame->FRAME.WithStatusLine) && (i == Frame->FRAME.Height-2) )
			{
				Print (Frame->FRAME.x, Frame->FRAME.y+Frame->FRAME.Height-2, Frame->FRAME.Color, "%c", VerticalRightLine);
				Print (Frame->FRAME.x+Frame->FRAME.Length, Frame->FRAME.y+Frame->FRAME.Height-2, Frame->FRAME.Color, "%c", VerticalLeftLine);
			}
		}
	}
	else
	{
		// error checking
		if ( !((Frame->FRAME.x >= 0) && (Frame->FRAME.x <= 77)) )
		{
			ErrorMsg ("Frame->FRAME.x is not between 0 and 77              (Frame->FRAME.x = %02d).", Frame->FRAME.x);
		}
		if ( !((Frame->FRAME.y >= 0) && (Frame->FRAME.y <= 24)) )
		{
			ErrorMsg ("Frame->FRAME.y is not between 0 and 74              (Frame->FRAME.y = %02d).", Frame->FRAME.y);
		}
		if ( !(Frame->FRAME.Length > 0) )
		{
			ErrorMsg ("Frame->FRAME.Length is not greater than 0           (Frame->FRAME.Length = %02d).", Frame->FRAME.Length);
		}
		if ( !(Frame->FRAME.Height > 0) )
		{
			ErrorMsg ("Frame->FRAME.Height is not greater than 0           (Frame->FRAME.Height = %02d).", Frame->FRAME.Height);
		}
		if ( !(Frame->FRAME.x+Frame->FRAME.Length < 79) )
		{
			ErrorMsg ("Frame->FRAME.x+Frame->FRAME.Length is greater       than 78 (Frame->FRAME.x+Frame->FRAME.Length = %02d).", Frame->FRAME.x+Frame->FRAME.Length);
		}
		if ( !(Frame->FRAME.y+Frame->FRAME.Height <= 24) )
		{
			ErrorMsg ("Frame->FRAME.y+Frame->FRAME.Height is greater       than 24 (Frame->FRAME.y+Frame->FRAME.Height = %02d).", Frame->FRAME.y+Frame->FRAME.Height);
		}
	}
}
void LineComponent (SHAPE_COMPONENT *Line)
{
	int i = 0, HorizontalLine = 0, VerticalLine = 0;



	// limits
	if ( (Line->LINE.x >= 0) && (Line->LINE.x <= 79) && (Line->LINE.x+Line->LINE.Length <= 80) &&
		 ( (Line->LINE.Length > 0 && Line->LINE.Horizontal) || (Line->LINE.Height > 0 && !(Line->LINE.Horizontal)) ) &&
		   (Line->LINE.y >= 0) && (Line->LINE.y <= 24) && (Line->LINE.y+Line->LINE.Height <= 25) )
	{
		// hide screen cursor
		ShowScreenCursor (FALSE);
		// set codepage
		SetConsoleCP (Line->InputCodePage);
		SetConsoleOutputCP (Line->OutputCodePage);
		// setting the graphical ASCII constants
		if (Line->LINE.DoubleLine)
		{
			// double line frame
			HorizontalLine    = HORIZONTAL_DOUBLELINE;
			VerticalLine      = VERTICAL_DOUBLELINE;
		}
		else
		{
			// one line frame
			HorizontalLine    = HORIZONTAL_LINE;
			VerticalLine      = VERTICAL_LINE;
		}
		if (Line->LINE.Horizontal)
		{
			// loop for horizontal lines
			for (i = 0; i < Line->LINE.Length; i++)
			{
				Print (Line->LINE.x+i, Line->LINE.y, Line->LINE.Color, "%c", HorizontalLine);
			}
		}
		else
		{
			// loop for vertical lines
			for (i = 0; i < Line->LINE.Height; i++)
			{
				Print (Line->LINE.x, Line->LINE.y+i, Line->LINE.Color, "%c", VerticalLine);
			}
		}
	}
	else
	{
		// error checking
		if ( !((Line->LINE.x >= 0) && (Line->LINE.x <= 78)) )
		{
			ErrorMsg ("Line->LINE.x is not between 0 and 78                (Line->LINE.x = %02d).", Line->LINE.x);
		}
		if ( !((Line->LINE.y >= 0) && (Line->LINE.y <= 24)) )
		{
			ErrorMsg ("Line->LINE.y is not between 0 and 24                (Line->LINE.y = %02d).", Line->LINE.y);
		}
		if ( !(Line->LINE.Length > 0) && (Line->LINE.Horizontal) )
		{
			ErrorMsg ("Line->LINE.Length is not greater than 0             (Line->LINE.Length = %02d).", Line->LINE.Length);
		}
		if ( !(Line->LINE.Height > 0) && !(Line->LINE.Horizontal) )
		{
			ErrorMsg ("Line->LINE.Height is not greater than 0             (Line->LINE.Height = %02d).", Line->LINE.Height);
		}
		if ( !(Line->LINE.x+Line->LINE.Length <= 80) )
		{
			ErrorMsg ("Line->LINE.x+Line->LINE.Length is greater than 79   (Line->LINE.x+Line->LINE.Length = %02d).", Line->LINE.x+Line->LINE.Length);
		}
		if ( !(Line->LINE.y+Line->LINE.Height <= 25) )
		{
			ErrorMsg ("Line->LINE.y+Line->LINE.Height is greater than 25   (Line->LINE.y+Line->LINE.Height = %02d).", Line->LINE.y+Line->LINE.Height);
		}
	}
}
void BarComponent (SHAPE_COMPONENT *Bar)
{
	int i = 0, j = 0;



	// limits
	if ( (Bar->BAR.x >= 0) && (Bar->BAR.x <= 78) && (Bar->BAR.x+Bar->BAR.Length <= 80) && (Bar->BAR.Length > 0) &&
		 (Bar->BAR.Height > 0) && (Bar->BAR.y >= 0) && (Bar->BAR.y <= 24) && (Bar->BAR.y+Bar->BAR.Height <= 25) )
	{
		// hide screen cursor
		ShowScreenCursor (FALSE);
		// set codepage
		SetConsoleCP (Bar->InputCodePage);
		SetConsoleOutputCP (Bar->OutputCodePage);
		// loop for drawing a bar
		for	(i = 0; i < Bar->BAR.Height; i++)
		{
			for	(j = 0; j < Bar->BAR.Length; j++)
			{
				Print (Bar->BAR.x+j, Bar->BAR.y+i, Bar->BAR.Color, "%c", Bar->BAR.Pattern);
			}
		}
	}
	else
	{
		// error checking
		if ( !((Bar->BAR.x >= 0) && (Bar->BAR.x <= 78)) )
		{
			ErrorMsg ("Bar->BAR.x is not between 0 and 78                  (Bar->BAR.x = %02d).", Bar->BAR.x);
		}
		if ( !((Bar->BAR.y >= 0) && (Bar->BAR.y <= 24)) )
		{
			ErrorMsg ("Bar->BAR.y is not between 0 and 24                  (Bar->BAR.y = %02d).", Bar->BAR.y);
		}
		if ( !(Bar->BAR.Length > 0) )
		{
			ErrorMsg ("Bar->BAR.Length is not greater than 0               (Bar->BAR.Length = %02d).", Bar->BAR.Length);
		}
		if ( !(Bar->BAR.Height > 0)  )
		{
			ErrorMsg ("Bar->BAR.Height is not greater than 0               (Bar->BAR.Height = %02d).", Bar->BAR.Height);
		}
		if ( !(Bar->BAR.x+Bar->BAR.Length <= 80) )
		{
			ErrorMsg ("Bar->BAR.x+Bar->BAR.Length is greater than 79       (Bar->BAR.x+Bar->BAR.Length = %02d).", Bar->BAR.x+Bar->BAR.Length);
		}
		if ( !(Bar->BAR.y+Bar->BAR.Height <= 25) )
		{
			ErrorMsg ("Bar->BAR.y+Bar->BAR.Height is greater than 25       (Bar->BAR.y+Bar->BAR.Height = %02d).", Bar->BAR.y+Bar->BAR.Height);
		}
	}
}