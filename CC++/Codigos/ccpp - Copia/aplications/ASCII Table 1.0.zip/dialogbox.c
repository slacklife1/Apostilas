/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Author: Ga�per Raj�ek
 * E-mail, updates & bugs report: gape->korn@volja->net
 *
 * Created: 22->8->2002 at 16->20
 *
 * Description: GROUPBOX component source
 *
 */

# include "main.h"

/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Function name:    DialogBoxComponent
 * Function version: 1.0
 * Input parameters: - DialogBox (DIALOGBOX_COMPONENT)
 * Return value:     dialogbox structure
 * Description:      draws a dialog box
 * Example:          Before you use it, you have to initialize it's variables
 *               
 *                   DialogBoxComponent (DialogBox, ir, TRUE);
 * Limits:           
 * Warnings:         none
 *
 * Updates:
 *   - (!! here you write the updates - do not remove this line !!)
 *
 */
DIALOGBOX_COMPONENT *DialogBoxComponent (DIALOGBOX_COMPONENT *DialogBox, INPUT_RECORD ir, int Initialize)
{
	int i = 0, j = 0, RightDownLine = 0, RightUpLine = 0, LeftDownLine = 0, LeftUpLine = 0;
	int HorizontalLine = 0, VerticalLine = 0, VerticalLeftLine = 0, VerticalRightLine = 0;
	static int SelectedExitIcon = 0, UnSelectedExitIcon = 0;
	static int SelectedHelpIcon = 0, UnSelectedHelpIcon = 0;


	// limits
	if ( (DialogBox->x >= 0) && (DialogBox->x <= 73) && (DialogBox->x+DialogBox->Length <= 80) &&
		 (DialogBox->Length > 3) && (DialogBox->y >= 0) && (DialogBox->y <= 22) &&
		 (DialogBox->y+DialogBox->Height <= 25) && (DialogBox->Height > 2)/* &&
		 (strlen (DialogBox->Title) >= 1) && ((int) strlen (DialogBox->Title)+6 <= DialogBox->Length)*/ )
	{
		if (Initialize)
		{
			// hide screen cursor
			ShowScreenCursor (FALSE);
			// set codepage
			SetConsoleCP (DialogBox->InputCodePage);
			SetConsoleOutputCP (DialogBox->OutputCodePage);
			// save previous data
			DialogBox->Data = ReadDialogBoxData (DialogBox->Data, DialogBox->x, DialogBox->y, DialogBox->Length, DialogBox->Height);
			// setting the graphical ASCII constants
			if (DialogBox->DoubleLineBorder)
			{
				// double line border
				RightDownLine     = RIGHT_DOWN_DOUBLELINE;
				RightUpLine       = RIGHT_UP_DOUBLELINE;
				LeftDownLine      = LEFT_DOWN_DOUBLELINE;
				LeftUpLine        = LEFT_UP_DOUBLELINE;
				HorizontalLine    = HORIZONTAL_DOUBLELINE;
				VerticalLine      = VERTICAL_DOUBLELINE;
				VerticalLeftLine  = VERTICAL_LEFT_DOUBLELINE;
				VerticalRightLine = VERTICAL_RIGHT_DOUBLELINE;
			}
			else
			{
				// one line border
				RightDownLine     = RIGHT_DOWN_LINE;
				RightUpLine       = RIGHT_UP_LINE;
				LeftDownLine      = LEFT_DOWN_LINE;
				LeftUpLine        = LEFT_UP_LINE;
				HorizontalLine    = HORIZONTAL_LINE;
				VerticalLine      = VERTICAL_LINE;
				VerticalLeftLine  = VERTICAL_LEFT_LINE;
				VerticalRightLine = VERTICAL_RIGHT_LINE;
			}
			// draw corner elements
			Print (DialogBox->x, DialogBox->y, DialogBox->BorderColor, "%c", RightDownLine);
			Print (DialogBox->x, DialogBox->y+DialogBox->Height - 2, DialogBox->BorderColor, "%c", RightUpLine);
			Print (DialogBox->x+DialogBox->Length - 3, DialogBox->y, DialogBox->BorderColor, "%c", LeftDownLine);
			Print (DialogBox->x+DialogBox->Length - 3, DialogBox->y+DialogBox->Height - 2, DialogBox->BorderColor, "%c", LeftUpLine);
			// draw horizontal lines
			for (i = 1; i < DialogBox->Length; i++)
			{
				if ( (i == X_HELPICON - DialogBox->x) && (DialogBox->EnableHelpIcon) ) // help icon
				{
					Print (X_HELPICON, Y_ICON, DialogBox->IconColor, "%c", HELPICON);
				}
				else if ( (i == X_EXITICON - DialogBox->x) && (DialogBox->EnableExitIcon) ) // exit icon
				{
					Print (X_EXITICON, Y_ICON, DialogBox->IconColor, "%c", EXITICON);
				}
				else
				{
					if (i < DialogBox->Length - 3) Print (DialogBox->x + i, DialogBox->y, DialogBox->BorderColor, "%c", HorizontalLine);
				}
				if (i < DialogBox->Length - 3)
				{
					Print (DialogBox->x + i, DialogBox->y + 2, DialogBox->BorderColor, "%c", HorizontalLine);
					Print (DialogBox->x + i, DialogBox->y+DialogBox->Height - 2, DialogBox->BorderColor, "%c", HorizontalLine);
				}
				// draw horizontal shadow if enabled
				if ( (i > 1) && (DialogBox->EnableShadow) ) Print (DialogBox->x + i, DialogBox->y+DialogBox->Height - 1, DialogBox->ShadowColor, "%c", DialogBox->ShadowPattern);
			}
			// draw inside the dialogbox and draw the title line too
			for	(i = 0; i < DialogBox->Height - 3; i++)
			{
				if (i == 0) // title line
				{
					for	(j = 0; j < DialogBox->Length - 3; j++)
					{
						Print (DialogBox->x+j+1, DialogBox->y+i+1, DialogBox->TitleColor, "%c", DialogBox->TitlePattern);
					}
				}
				else
				{
					if (i != 1) // line below the title line
					{
						for	(j = 0; j < DialogBox->Length - 3; j++)
						{
							Print (DialogBox->x+j+1, DialogBox->y+i+1, DialogBox->BorderColor, "%c", DialogBox->Pattern);
						}
					}
				}
			}
			// draw vertical lines
			for (i = 0; i < DialogBox->Height - 1; i++)
			{
				if (i == 1) // |- and -| character
				{
					Print (DialogBox->x, DialogBox->y + 1 + i, DialogBox->BorderColor, "%c", VerticalRightLine);
					Print (DialogBox->x+DialogBox->Length - 3, DialogBox->y + 1 + i, DialogBox->BorderColor, "%c", VerticalLeftLine);
				}
				if ( (i != 1) && (i < DialogBox->Height - 3) ) // vertical lines
				{
					Print (DialogBox->x, DialogBox->y + 1 + i, DialogBox->BorderColor, "%c", VerticalLine);
					Print (DialogBox->x+DialogBox->Length - 3, DialogBox->y + 1 + i, DialogBox->BorderColor, "%c", VerticalLine);
				}
				// draw vertical shadow if enabled
				if (DialogBox->EnableShadow)
				{
					Print (DialogBox->x+DialogBox->Length - 2, DialogBox->y + 1 + i, DialogBox->ShadowColor, "%c", DialogBox->ShadowPattern);
					Print (DialogBox->x+DialogBox->Length - 1, DialogBox->y + 1 + i, DialogBox->ShadowColor, "%c", DialogBox->ShadowPattern);
				}
			}
			// display title of the dialog
			if      (DialogBox->LeftAlignedTitle)   Print (DialogBox->x + 1, DialogBox->y + 1, DialogBox->TitleColor, "%s", DialogBox->Title);
			else if (DialogBox->RightAlignedTitle)  Print (DialogBox->x+DialogBox->Length - 1 - (int) strlen (DialogBox->Title), DialogBox->y + 1, DialogBox->TitleColor, "%s", DialogBox->Title);
			else if (DialogBox->CenterAlignedTitle) Print (DialogBox->x+((DialogBox->Length - 1 - (int) strlen (DialogBox->Title)) / 2), DialogBox->y + 1, DialogBox->TitleColor, "%s", DialogBox->Title);
			// dialogbox is initialized
			DialogBox->IsInitialized = TRUE;
		}
		else
		{
			if (DialogBox->IsInitialized)
			{
				if (DialogBox->Active)
				{
					// set codepage
					SetConsoleCP (DialogBox->InputCodePage);
					SetConsoleOutputCP (DialogBox->OutputCodePage);
					// mouse
					if (ir.EventType == MOUSE_EVENT)
					{
						if ( (ir.Event.MouseEvent.dwEventFlags == MOUSE_MOVED) ||
							 (ir.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED) )
						{
							// exit icon if enabled
							if (DialogBox->EnableExitIcon)
							{
								if ( (ir.Event.MouseEvent.dwMousePosition.X == X_EXITICON) &&
									 (ir.Event.MouseEvent.dwMousePosition.Y == Y_ICON) )
								{
									if (!SelectedExitIcon)
									{
										Print (X_EXITICON, Y_ICON, DialogBox->IconHighLightColor, "%c", EXITICON);
										UnSelectedExitIcon = FALSE;
										SelectedExitIcon = TRUE;
									}
								}
								else
								{
									if (!UnSelectedExitIcon)
									{
										Print (X_EXITICON, Y_ICON, DialogBox->IconColor, "%c", EXITICON);
										UnSelectedExitIcon = TRUE;
										SelectedExitIcon = FALSE;
										DialogBox->ExitIconClicked = FALSE;
									}
								}
							} // end if EnableExitIcon
							// help icon if enabled
							if (DialogBox->EnableHelpIcon)
							{
								if ( (ir.Event.MouseEvent.dwMousePosition.X == X_HELPICON) &&
									 (ir.Event.MouseEvent.dwMousePosition.Y == Y_ICON) )
								{
									if (!SelectedHelpIcon)
									{
										Print (X_HELPICON, Y_ICON, DialogBox->IconHighLightColor, "%c", HELPICON);
										UnSelectedHelpIcon = FALSE;
										SelectedHelpIcon = TRUE;
									}
								}
								else
								{
									if (!UnSelectedHelpIcon)
									{
										Print (X_HELPICON, Y_ICON, DialogBox->IconColor, "%c", HELPICON);
										UnSelectedHelpIcon = TRUE;
										SelectedHelpIcon = FALSE;
										DialogBox->HelpIconClicked = FALSE;
									}
								}
							} // end if EnableHelpIcon
						} // end if MOUSE_MOVED
						if (ir.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED)
						{
							// exit icon
							if (DialogBox->EnableExitIcon)
							{
								if ( (ir.Event.MouseEvent.dwMousePosition.X == X_EXITICON) &&
									 (ir.Event.MouseEvent.dwMousePosition.Y == Y_ICON) )
								{
									if (!DialogBox->ExitIconClicked)
									{
										DialogBox->ExitIconClicked = TRUE;
										// close (overwrite) dialog with previous data and deactivate it
										WriteDialogBoxData (DialogBox->Data, DialogBox->x, DialogBox->y, DialogBox->Length, DialogBox->Height);
										DialogBox->Active = FALSE;
									}
								}
							}
							// help icon
							if (DialogBox->EnableHelpIcon)
							{
								if ( (ir.Event.MouseEvent.dwMousePosition.X == X_HELPICON) &&
									 (ir.Event.MouseEvent.dwMousePosition.Y == Y_ICON) )
								{
									if (!DialogBox->HelpIconClicked)
									{
										DialogBox->HelpIconClicked = TRUE;
									}
								}
							}
						} // end if FROM_LEFT_1ST_BUTTON_PRESSED
					} // end if MOUSE_EVENT
				} // end if Active					
			} // end if DialogBox->IsInitialized
			else
			{
				// error checking
				ErrorMsg ("Dialog box component was not initialized.");
			}
		} // end if Initialized
	} // end if limits
	else
	{
		// error checking
		if ( !((DialogBox->x >= 0) && (DialogBox->x <= 73)) )
		{
			ErrorMsg ("DialogBox->x is not between 0 and 73                (DialogBox->x = %02d).", DialogBox->x);
		}
		if ( !((DialogBox->y >= 0) && (DialogBox->y <= 22)) )
		{
			ErrorMsg ("DialogBox->x is not between 0 and 22                (DialogBox->y = %02d).", DialogBox->y);
		}
		if ( !(DialogBox->Length > 6) )
		{
			ErrorMsg ("DialogBox->Length is not greater than 6             (DialogBox->Length = %02d).", DialogBox->Length);
		}
		if ( !(DialogBox->Height > 2) )
		{
			ErrorMsg ("DialogBox->Height is not greater than 2             (DialogBox->Height = %02d).", DialogBox->Height);
		}
		if ( !(DialogBox->x+DialogBox->Length <= 80) )
		{
			ErrorMsg ("DialogBox->x+DialogBox->Length is greater than 79   (DialogBox->x+DialogBox->Length = %02d).", DialogBox->x+DialogBox->Length);
		}
		if ( !(DialogBox->y+DialogBox->Height <= 25) )
		{
			ErrorMsg ("DialogBox->y+DialogBox->Height is greater than 24   (DialogBox->y+DialogBox->Height = %02d).", DialogBox->y+DialogBox->Height);
		}
		if ( !((int) strlen (DialogBox->Title) >= 1) )
		{
			ErrorMsg ("strlen (DialogBox->Title) is not greater than 1     (strlen (DialogBox->Title) = %02d).", strlen (DialogBox->Title));
		}
		if ( !(((int) strlen (DialogBox->Title)+6) <= DialogBox->Length) )
		{
			ErrorMsg ("strlen (DialogBox->Title)+6 is not less or equal to DialogBox->Length (strlen (DialogBox->Title)+6 =    %02d).", strlen (DialogBox->Title)+6);
		}
	}
	return DialogBox;
}
CONSOLE_DATA ReadDialogBoxData (CONSOLE_DATA cc, int ReadX, int ReadY, int ReadLength, int ReadHeight)
{
	HANDLE hOutput;
	COORD ReadScreenPosition = {0};
	DWORD NoOfCharsRead = 0, NoOfAttrsRead = 0;
	BOOL StatusReadAttr = 0, StatusReadChar = 0;
	int i = 0, j = 0;



	hOutput = GetStdHandle (STD_OUTPUT_HANDLE);
	for	(i = 0; i < ReadLength; i++)
	{
		for	(j = 0; j < ReadHeight; j++)
		{
			// read characters from console window
			ReadScreenPosition.X = (short) (ReadX + i);
			ReadScreenPosition.Y = (short) (ReadY + j);
			StatusReadChar = ReadConsoleOutputCharacter (hOutput, &cc.Characters[i][j], 1, ReadScreenPosition, &NoOfCharsRead);
			StatusReadAttr = ReadConsoleOutputAttribute (hOutput, &cc.Colors[i][j], 1, ReadScreenPosition, &NoOfAttrsRead);
		}
	}
	if (NoOfAttrsRead != NoOfCharsRead)
	{
		ErrorMsg ("Error occured while reading characters and          attributes of the screen in function                ReadDialogBoxData (file \"dialogbox.c\").             NoOfCharsRead = %02d ; NoOfAttrsRead = %02d.", NoOfCharsRead, NoOfAttrsRead);
	}
	if ( (!StatusReadChar) || (!StatusReadAttr) )
	{
		ErrorMsg ("Error occured while reading characters and          attributes of the screen in function                ReadDialogBoxData (file \"dialogbox.c\").             Error code = %u.", GetLastError ());
	}
	return cc;
}
void WriteDialogBoxData (CONSOLE_DATA cc, int WriteX, int WriteY, int WriteLength, int WriteHeight)
{
	HANDLE hOutput;
	COORD WriteScreenPosition = {0};
	DWORD NoOfAttrsWritten = 0, NoOfCharsWritten = 0;
	BOOL StatusWriteAttr = 0, StatusWriteChar = 0;
	int i = 0, j = 0;



	hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	for	(i = 0; i < WriteLength; i++)
	{
		for	(j = 0; j < WriteHeight; j++)
		{
			// write readed characters
			WriteScreenPosition.X = (short) (WriteX + i);
			WriteScreenPosition.Y = (short) (WriteY + j);
			StatusWriteChar = WriteConsoleOutputCharacter (hOutput, &cc.Characters[i][j], 1, WriteScreenPosition, &NoOfCharsWritten);
			StatusWriteAttr = WriteConsoleOutputAttribute (hOutput, &cc.Colors[i][j], 1, WriteScreenPosition, &NoOfAttrsWritten);
		}
	}
	if (NoOfAttrsWritten != NoOfCharsWritten)
	{
		ErrorMsg ("Error occured while writing characters and          attributes on the screen in function                WriteDialogBoxData (file \"dialogbox.c\").            NoOfCharsWritten = %02d ; NoOfAttrsWritten = %02d.", NoOfCharsWritten, NoOfAttrsWritten);
	}
	if ( (!StatusWriteChar) || (!StatusWriteAttr) )
	{
		ErrorMsg ("Error occured while writing characters and          attributes on the screen in function                WriteDialogBoxData (file \"dialogbox.c\").            Error code = %u.", GetLastError ());
	}
}