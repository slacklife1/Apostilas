/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Author: Ga�per Raj�ek
 * E-mail, updates & bugs report: gape.korn@volja.net
 *
 * Created: 22.8.2002 at 16.15
 *
 * Description: structure and prototype function for the GROUPBOX component source
 *
 */

# ifndef GROUPBOX_H
# define GROUPBOX_H


// structure for the GROUPBOX component
typedef struct GROUPBOX
{
	int x, y, Length, Height, DoubleLine;
	UINT InputCodePage, OutputCodePage;
	WORD Color, TitleColor;
	char Title[80], Pattern;
} GROUPBOX_COMPONENT;

// function prototype
void GroupBoxComponent (GROUPBOX_COMPONENT *GroupBox);

# endif // GROUPBOX_H