/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Author: Ga�per Raj�ek
 * E-mail, updates & bugs report: gape.korn@volja.net
 *
 * Created: 03.08.2003 at 15.38
 *
 * Description: Shows information about the author
 *
 */

# include "main.h"
# include "author.h"



/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Function name:    AuthorDIalog
 * Function version: 1.0
 * Input parameters: none
 * Return value:     none
 * Description:      displays author information
 * Example:          AuthorDialog ();
 * Limits:           none
 * Warnings:         none
 *
 * Updates:
 *   - (!! here you write the updates - do not remove this line !!)
 *
 */
void AuthorDialog ()
{
	// input variables
	HANDLE Stdin = GetStdHandle (STD_INPUT_HANDLE);
	INPUT_RECORD ir = {0};
	DWORD Read = 0;
	// component variables
	DIALOGBOX_COMPONENT *dbAuthor = NULL;
	// common variables
	int i = 0, j = 0; // counters
	int AuthorIsDisplayed = 0; // flag which becomes true if help text is displayed in the status line
	int xItemNameLength = 0;
	// variables for menu button (Close)
	int AuthorDialogLoop = 0, xStartMenu[AUTHOR_MENU_NO_OF_ITEMS] = {0}, AuthorMenuValue = AUTHOR_MENU_DEFAULT_SELECTED;
	int xEndMenu[AUTHOR_MENU_NO_OF_ITEMS] = {0}, yStartMenu[AUTHOR_MENU_NO_OF_ITEMS] = {0};
	int WriteMenu = 0, MarkMenu = 0, MenuIndex = 0, MenuClicked = 0;
	int MenuTempIndex = AUTHOR_MENU_DEFAULT_SELECTED, MenuSelected = 0;
	char *AuthorMenuItems[AUTHOR_MENU_NO_OF_ITEMS] = {0}, *AuthorMenuHelp[AUTHOR_MENU_NO_OF_ITEMS] = {0};
	// options
	WORD ItemColor = 0, ItemHighLightColor = 0, DisabledItemColor = 0, DisabledItemHighLightColor = 0;
	WORD HelpColor = 0;
	int DisabledItem[2] = {0}, ShowAuthor = 0;



	// reload menu item colors
	ItemColor                  = FRONT_LIGHTGREY;
	ItemHighLightColor         = FRONT_WHITE;
	DisabledItemColor          = FRONT_DARKGREEN;
	DisabledItemHighLightColor = FRONT_LIGHTGREEN;
	HelpColor                  = FRONT_WHITE | BACK_LIGHTGREY;
	// enable button Close and Save To File
	DisabledItem[0] = FALSE;
	ShowAuthor        = TRUE;
	// initialize Author dialog
	if ((dbAuthor = (DIALOGBOX_COMPONENT *) malloc (sizeof (DIALOGBOX_COMPONENT))) != NULL)
	{
		dbAuthor->Length             = 30;
		dbAuthor->x                  = ((CONSOLE_LENGTH - 1 - dbAuthor->Length) / 2);
		dbAuthor->y                  = 3;
		dbAuthor->Height             = 17;
		dbAuthor->BorderColor        = FRONT_WHITE;
		dbAuthor->IconColor          = FRONT_LIGHTGREY;
		dbAuthor->IconHighLightColor = FRONT_WHITE;
		dbAuthor->TitleColor         = FRONT_WHITE | BACK_DARKBLUE;
		dbAuthor->ShadowColor        = BACK_DARKGREY;
		dbAuthor->Active             = TRUE;
		dbAuthor->EnableExitIcon     = TRUE;
		dbAuthor->EnableHelpIcon     = FALSE;
		dbAuthor->DoubleLineBorder   = FALSE;
		dbAuthor->ExitIconClicked    = FALSE;
		dbAuthor->HelpIconClicked    = FALSE;
		dbAuthor->IsInitialized      = FALSE;
		dbAuthor->Pattern            = ' ';
		dbAuthor->TitlePattern       = ' ';
		dbAuthor->ShadowPattern      = ' ';
		dbAuthor->LeftAlignedTitle   = TRUE;
		dbAuthor->CenterAlignedTitle = FALSE;
		dbAuthor->RightAlignedTitle  = FALSE;
		dbAuthor->EnableShadow       = TRUE;
		dbAuthor->InputCodePage      = 1250;
		dbAuthor->OutputCodePage     = 1250;
		sprintf (dbAuthor->Title, "Author");
		dbAuthor = DialogBoxComponent (dbAuthor, ir, TRUE);
	}
	else
	{
		ErrorMsg ("Error occured while allocating space for dbAuthor   variable in function AuthorDialog (file             \"author.c\").");
	}
	// text: Close
	if ((AuthorMenuItems[0] = (char *) malloc (sizeof (char *) * (strlen ("Close") + 1))) != NULL)
	{
		strncpy (AuthorMenuItems[0], "Close", strlen ("Close") + 1);
	}
	else
	{
		ErrorMsg ("Error occured while allocating space for            AuthorMenuItems[0] variable in function             AuthorDialog (file \"author.c\").");
	}
	// load menu help for each item
	// help: Author & close the dialog.
	if ((AuthorMenuHelp[0] = (char *) malloc (sizeof (char *) * (strlen ("Closes the dialog.") + 1 + HELP_ERASE_LENGTH))) != NULL)
	{
		strncpy (AuthorMenuHelp[0], "Closes the dialog.", strlen ("Closes the dialog.") + 1 + HELP_ERASE_LENGTH);
	}
	else
	{
		ErrorMsg ("Error occured while allocating space for            AuthorMenuHelp[0] variable in function              AuthorDialog (file \"author.c\").");
	}
	// with this, before the help gets printed, I can avoid to delete the previous text - very useful
	// I don't have to use ClrScr function
	for (i = 0; i < AUTHOR_MENU_NO_OF_ITEMS; i++)
	{
		for (j = 0; j < HELP_ERASE_LENGTH; j++)
		{
			if (AuthorMenuHelp[i][j] == '\0')
			{
				AuthorMenuHelp[i][j] = ' ';
				AuthorMenuHelp[i][j+1] = '\0';
			}
		}
	}
	// calculate load menu coordinates
	for (i = 0, xItemNameLength = 0; i < AUTHOR_MENU_NO_OF_ITEMS; i++)
	{
		xStartMenu[i] = AUTHOR_MENU_X + xItemNameLength;
		xEndMenu[i] = xStartMenu[i] + (int) strlen (AuthorMenuItems[i]) - 1;
		yStartMenu[i] = AUTHOR_MENU_Y;
		xItemNameLength += 0 + (int) strlen (AuthorMenuItems[i]);
		// do not count the space for the last menu button
		if (i != AUTHOR_MENU_NO_OF_ITEMS-1) xItemNameLength += 0 + AUTHOR_MENU_SPACE_BETWEEN_ITEMS;
	}
	// print Author menu
	for (i = 0; i < AUTHOR_MENU_NO_OF_ITEMS; i++)
	{
		if (AUTHOR_MENU_DEFAULT_SELECTED == i)
		{
			// checking if the menu item is disabled. If it is then color it diferently
			if (DisabledItem[i]) Print (xStartMenu[i], yStartMenu[i], DisabledItemHighLightColor, "%s", AuthorMenuItems[i]);
			else Print (xStartMenu[i], yStartMenu[i], ItemHighLightColor, "%s", AuthorMenuItems[i]);
			MarkMenu = MenuSelected = 1;
			// print help in the status line
			if (ShowAuthor)
			{
				Print (HELP_X, HELP_Y, HelpColor, "%s", AuthorMenuHelp[i]);
				AuthorIsDisplayed = 1;
			}
		}
		else
		{
			if (DisabledItem[i]) Print (xStartMenu[i], yStartMenu[i], DisabledItemColor, "%s", AuthorMenuItems[i]);
			else Print (xStartMenu[i], yStartMenu[i], ItemColor, "%s", AuthorMenuItems[i]);
		}
	}
	// texts in the author dialog
	Print (dbAuthor->x + 6,  dbAuthor->y + 3,  FRONT_WHITE,    "ASCII Table 1.0");
	Print (dbAuthor->x + 11, dbAuthor->y + 5,  FRONT_LIGHTRED, "Author:");
	Print (dbAuthor->x + 8,  dbAuthor->y + 7,  FRONT_WHITE,    "Ga�per Raj�ek");
	Print (dbAuthor->x + 10, dbAuthor->y + 9,  FRONT_LIGHTRED, "E-mail:");
	Print (dbAuthor->x + 5,  dbAuthor->y + 11, FRONT_WHITE,    "gape.korn@volja.net");
	// load main loop
	AuthorDialogLoop = 1;
	while (AuthorDialogLoop)
	{
		ReadConsoleInput (Stdin, &ir, 1, &Read);
		dbAuthor = DialogBoxComponent (dbAuthor, ir, FALSE);
		if (dbAuthor->ExitIconClicked)
		{
			// same as Close button
			AuthorDialogLoop = 0;
			// free memory
			for (i = 0; i < AUTHOR_MENU_NO_OF_ITEMS; i++)
			{
				free (AuthorMenuItems[i]);
				AuthorMenuItems[i] = NULL;
				free (AuthorMenuHelp[i]);
				AuthorMenuHelp[i] = NULL;
			}
			free (dbAuthor);
			dbAuthor = NULL;
		}
		// mouse
		if (ir.EventType == MOUSE_EVENT)
		{
			if (ir.Event.MouseEvent.dwEventFlags == MOUSE_MOVED)
			{
				// within the range of a load menu items
				if ( (ir.Event.MouseEvent.dwMousePosition.X >= xStartMenu[MenuIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.X <= xEndMenu[MenuIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.Y == yStartMenu[MenuIndex]) )
				{
					// print the menu button only once
					if ( (MenuTempIndex != MenuIndex) || (!MenuSelected) )
					{
						WriteMenu = 1;
						MarkMenu = MenuSelected = 1;
						MenuTempIndex = MenuIndex;
						MenuIndex++;
						if (MenuIndex >= AUTHOR_MENU_NO_OF_ITEMS) MenuIndex = 0;
					}
				}
				else
				{
					MenuClicked = 0;
					// menu
					MenuIndex++;
					if (MenuIndex >= AUTHOR_MENU_NO_OF_ITEMS) MenuIndex = 0;
				}
			} // end if MOUSE_MOVED
			if (ir.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED) // left mouse click
			{
				// within the range of a horizontal menu button
				if ( (ir.Event.MouseEvent.dwMousePosition.X >= xStartMenu[MenuTempIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.X <= xEndMenu[MenuTempIndex]) &&
					 (ir.Event.MouseEvent.dwMousePosition.Y == yStartMenu[MenuTempIndex]) )
				{
					if (!MenuClicked)
					{
						// simulating key return
						keybd_event	(VK_RETURN,	0x1c, 0, 0);
						keybd_event	(VK_RETURN,	0x1c, KEYEVENTF_KEYUP, 0);
					}
				}
				else
				{
					if (MenuSelected)
					{
						// menu
						WriteMenu = 1; MarkMenu = MenuSelected = 0;
					}
				}
			} // end if FROM_LEFT_1ST_BUTTON_PRESSED
		} // end if MOUSE_EVENT
		// if component is selected
		if (MenuSelected)
		{
			if (ir.EventType == KEY_EVENT && ir.Event.KeyEvent.bKeyDown)
			{
				// key F10 for menu
				if (ir.Event.KeyEvent.wVirtualKeyCode == VK_F10)
				{
					// menu
					MenuSelected  = 1;
					WriteMenu     = 1;
					MarkMenu      = 1;
					MenuClicked   = 0;
				}
				// left arrow key
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_LEFT)
				{
					if (MenuSelected)
					{
						WriteMenu = 1;
						MarkMenu  = 1;
						MenuTempIndex -= 1;
						MenuClicked = 0;
						if (MenuTempIndex < 0) MenuTempIndex = AUTHOR_MENU_NO_OF_ITEMS-1;
					}
				}
				// right arrow key
				else if (ir.Event.KeyEvent.wVirtualKeyCode == VK_RIGHT)
				{
					if (MenuSelected)
					{
						WriteMenu = 1;
						MarkMenu  = 1;
						MenuTempIndex += 1;
						MenuClicked = 0;
						if (MenuTempIndex >= AUTHOR_MENU_NO_OF_ITEMS) MenuTempIndex = 0;
					}
				}
				// return and space key
				else if ( (ir.Event.KeyEvent.wVirtualKeyCode == VK_RETURN) ||
					      (ir.Event.KeyEvent.wVirtualKeyCode == VK_SPACE) )
				{
					if (!MenuClicked)
					{
						AuthorMenuValue = MenuTempIndex;
						if (AuthorMenuValue == AUTHOR_MENU_CLOSE)
						{
							MenuClicked = 1;
							MarkMenu = 1;
							AuthorDialogLoop = 0;
							dbAuthor->Active = 0;
							// write previous data back on the screen
							WriteDialogBoxData (dbAuthor->Data, dbAuthor->x, dbAuthor->y, dbAuthor->Length, dbAuthor->Height);
							// free memory
							for (i = 0; i < AUTHOR_MENU_NO_OF_ITEMS; i++)
							{
								free (AuthorMenuItems[i]);
								AuthorMenuItems[i] = NULL;
								free (AuthorMenuHelp[i]);
								AuthorMenuHelp[i] = NULL;
							}
							free (dbAuthor);
							dbAuthor = NULL;
						}
					}
				} // end if key return or space was pressed
			} // end if keyboard
		}
		else // end if MenuSelected
		{
			if ( (ShowAuthor) && (AuthorIsDisplayed) )
			{
				Print (HELP_X, HELP_Y, HelpColor, "Press F10 for menu.                                                          ");
				AuthorIsDisplayed = FALSE;
			}
			// these keys are available only when the component is unselected
			if (ir.EventType == KEY_EVENT && ir.Event.KeyEvent.bKeyDown)
			{
				// key F10 for menu
				if (ir.Event.KeyEvent.wVirtualKeyCode == VK_F10)
				{
					// menu
					MenuSelected  = 1;
					WriteMenu     = 1;
					MarkMenu      = 1;
					MenuClicked   = 0;
				}
			} // end if (ir.EventType == KEY_EVENT && ir.Event.KeyEvent.bKeyDown)
		} // end if !MenuSelected
		// printing menu items
		if (WriteMenu)
		{
			for (i = 0; i < AUTHOR_MENU_NO_OF_ITEMS; i++)
			{
				if (AuthorMenuItems[i] != NULL)
				{
					if (DisabledItem[i]) Print (xStartMenu[i], yStartMenu[i], DisabledItemColor, "%s", AuthorMenuItems[i]);
					else Print (xStartMenu[i], yStartMenu[i], ItemColor, "%s", AuthorMenuItems[i]);
				}
			}
			if (MarkMenu)
			{
				if (AuthorMenuItems[MenuTempIndex] != NULL)
				{
					if (DisabledItem[MenuTempIndex]) Print (xStartMenu[MenuTempIndex], yStartMenu[MenuTempIndex], DisabledItemHighLightColor, "%s", AuthorMenuItems[MenuTempIndex]);
					else Print (xStartMenu[MenuTempIndex], yStartMenu[MenuTempIndex], ItemHighLightColor, "%s", AuthorMenuItems[MenuTempIndex]);
					// print help in the status line
					if (ShowAuthor)
					{
						Print (HELP_X, HELP_Y, HelpColor, "%s", AuthorMenuHelp[MenuTempIndex]);
						AuthorIsDisplayed = 1;
					}
				}
				MarkMenu = 0;
			}
			WriteMenu = 0;
		}
	} // end of while (AuthorDialogLoop)
}