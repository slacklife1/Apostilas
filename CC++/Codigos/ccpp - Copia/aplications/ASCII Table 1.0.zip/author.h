/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Author: Ga�per Raj�ek
 * E-mail, updates & bugs report: gape.korn@volja.net
 *
 * Created: 03.08.2003 at 16.04
 *
 * Description: constants for author dialog
 *
 */

# ifndef AUTHOR_H
# define AUTHOR_H



// AUTHOR DIALOG CONSTANTS
// menu constants
# define AUTHOR_MENU_X                   (dbAuthor->x + ((dbAuthor->Length - 5 - (int) strlen ("Close")) / 2))
# define AUTHOR_MENU_Y                   ((dbAuthor->y + dbAuthor->Height) - 3)
# define AUTHOR_MENU_NO_OF_ITEMS         1
# define AUTHOR_MENU_SPACE_BETWEEN_ITEMS 0
# define AUTHOR_MENU_DEFAULT_SELECTED    0
// menu item values
# define AUTHOR_MENU_CLOSE 0

void AuthorDialog (void);

# endif // AUTHOR_H