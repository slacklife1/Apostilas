/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Author: Ga�per Raj�ek
 * E-mail, updates & bugs report: gape.korn@volja.net
 *
 * Created: 01.06.2003 at 14.46
 *
 * Description: structure and prototype function for the DIALOGBOX component source
 *
 */

# ifndef DIALOGBOX_H
# define DIALOGBOX_H


// structure for console characters
typedef struct _CONSOLE_DATA
{
	char Characters[80][80];
	WORD Colors[80][80];
} CONSOLE_DATA;

// structure for the DIALOGBOX component
typedef struct DIALOGBOX
{
	int x, y, EnableShadow, Active, DoubleLineBorder, Length, Height;
	int EnableExitIcon, EnableHelpIcon, LeftAlignedTitle, RightAlignedTitle, CenterAlignedTitle;
	int ExitIconClicked, HelpIconClicked, IsInitialized;
	unsigned int InputCodePage, OutputCodePage;
	unsigned short BorderColor, IconColor, IconHighLightColor, TitleColor, ShadowColor;
	char Pattern, Title[80];
	char TitlePattern, ShadowPattern;
	CONSOLE_DATA Data;
} DIALOGBOX_COMPONENT;

// constants for the exit and help icon
# define X_EXITICON (DialogBox->x + DialogBox->Length - 4)
# define X_HELPICON (DialogBox->x + DialogBox->Length - 6)
# define Y_ICON     (DialogBox->y)
# define EXITICON   'X'
# define HELPICON   '?'

// function prototype
DIALOGBOX_COMPONENT *DialogBoxComponent (DIALOGBOX_COMPONENT *DialogBox, INPUT_RECORD ir, int Initialize);
CONSOLE_DATA ReadDialogBoxData (CONSOLE_DATA cc, int ReadX, int ReadY, int ReadLength, int ReadHeight);
void WriteDialogBoxData (CONSOLE_DATA cc, int WriteX, int WriteY, int WriteLength, int WriteHeight);

# endif // DIALOGBOX_H