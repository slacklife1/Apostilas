/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Author: Ga�per Raj�ek
 * E-mail, updates & bugs report: gape.korn@volja.net
 *
 * Created: 03.08.2003 at 15.04
 *
 * Description: constants for help dialog
 *
 */

# ifndef HELP_H
# define HELP_H



// HELP DIALOG CONSTANTS
// menu constants
# define HELP_MENU_X                   (dbHelp->x + ((dbHelp->Length - 5 - (int) strlen ("Close")) / 2))
# define HELP_MENU_Y                   ((dbHelp->y + dbHelp->Height) - 3)
# define HELP_MENU_NO_OF_ITEMS         1
# define HELP_MENU_SPACE_BETWEEN_ITEMS 0
# define HELP_MENU_DEFAULT_SELECTED    0
// menu item values
# define HELP_MENU_CLOSE      0

// function prototype
void HelpDialog (void);

# endif // HELP_H