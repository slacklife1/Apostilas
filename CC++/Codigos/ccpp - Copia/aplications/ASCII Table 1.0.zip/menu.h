/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Author: Ga�per Raj�ek
 * E-mail, updates & bugs report: gape.korn@volja.net
 *
 * Created: 03.08.2003 at 12.00
 *
 * Description: constants and prototype function for the main menu source
 *
 */
# ifndef MENU_H
# define MENU_H


// main menu constants
# define MAIN_MENU_X                   60
# define MAIN_MENU_Y                   11
# define MAIN_MENU_NO_OF_ITEMS         4
# define MAIN_MENU_SPACE_BETWEEN_ITEMS 1
# define MAIN_MENU_DEFAULT_SELECTED    0
// main menu item values
# define MAIN_MENU_SHOW_ASCII_TABLE 0
# define MAIN_MENU_HELP             1
# define MAIN_MENU_AUTHOR           2
# define MAIN_MENU_EXIT             3
// constants for edit boxe
# define CODEPAGE_EB_WHOLE_NO 1
# define CODEPAGE_EB_CODEPAGE 0

// function prototype
void MainMenu (void);

# endif // MENU_H