/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Author: Ga�per Raj�ek
 * E-mail, updates & bugs report: gape.korn@volja.net
 *
 * Created: 22.8.2002 at 16.20
 *
 * Description: GROUPBOX component source
 *
 */

# include "main.h"

/* !! DO NOT REMOVE THIS COMMENT !!
 *
 * Function name:    GroupBoxComponent
 * Function version: 1.0
 * Input parameters: - GroupBox (GROUPBOX_COMPONENT)
 * Return value:     groupbox structure
 * Description:      draws a group box with a title
 * Example:          Before you use it, you have to initialize it's variables
 *                   GroupBox.x = 0;
 *                   GroupBox.y = 0;
 *                   GroupBox.Length = 78;
 *                   GroupBox.Height = 24;
 *                   GroupBox.DoubleLine = TRUE;
 *                   GroupBox.Color = FRONT_WHITE;
 *                   GroupBox.Title = "Files";
 *                   GroupBoxComponent (GroupBox);
 * Limits:           0 <= GroupBox.x <= 78
 *                   0 <= GroupBox.y <= 24
 *                   GroupBox.x+GroupBox.Length <= 79
 *                   GroupBox.y+GroupBox.Height <= 24
 *                   GroupBox.Height > 0
 *                   GroupBox.Length > 0
 *                   strlen (GroupBox.Title) >= 1
 *                   strlen (GroupBox.Title)+5 <= GroupBox.Length
 * Warnings:         Beware of the screen cursor problem ;)
 *
 * Updates:
 *   - (!! here you write the updates - do not remove this line !!)
 *
 */
void GroupBoxComponent (GROUPBOX_COMPONENT *GroupBox)
{
	int i = 0, j = 0, RightDownLine = 0, RightUpLine = 0, LeftDownLine = 0, LeftUpLine = 0;
	int HorizontalLine = 0, VerticalLine = 0;


	// limits
	if ( (GroupBox->x >= 0) && (GroupBox->x <= 73) && (GroupBox->x+GroupBox->Length <= 80) &&
		 (GroupBox->Length > 3) && (GroupBox->y >= 0) && (GroupBox->y <= 22) &&
		 (GroupBox->y+GroupBox->Height <= 25) && (GroupBox->Height > 2) &&
		 (strlen (GroupBox->Title) >= 1) && ((int) strlen (GroupBox->Title)+6 <= GroupBox->Length) )
	{
		// hide screen cursor
		ShowScreenCursor (FALSE);
		// set codepage
		SetConsoleCP (GroupBox->InputCodePage);
		SetConsoleOutputCP (GroupBox->OutputCodePage);
		// setting the graphical ASCII constants
		if (GroupBox->DoubleLine)
		{
			// double line frame
			RightDownLine  = RIGHT_DOWN_DOUBLELINE;
			RightUpLine    = RIGHT_UP_DOUBLELINE;
			LeftDownLine   = LEFT_DOWN_DOUBLELINE;
			LeftUpLine     = LEFT_UP_DOUBLELINE;
			HorizontalLine = HORIZONTAL_DOUBLELINE;
			VerticalLine   = VERTICAL_DOUBLELINE;
		}
		else
		{
			// one line frame
			RightDownLine  = RIGHT_DOWN_LINE;
			RightUpLine    = RIGHT_UP_LINE;
			LeftDownLine   = LEFT_DOWN_LINE;
			LeftUpLine     = LEFT_UP_LINE;
			HorizontalLine = HORIZONTAL_LINE;
			VerticalLine   = VERTICAL_LINE;
		}
		// draw a frame
		Print (GroupBox->x, GroupBox->y, GroupBox->Color, "%c", RightDownLine);
		Print (GroupBox->x, GroupBox->y+GroupBox->Height-1, GroupBox->Color, "%c", RightUpLine);
		Print (GroupBox->x+GroupBox->Length-1, GroupBox->y, GroupBox->Color, "%c", LeftDownLine);
		Print (GroupBox->x+GroupBox->Length-1, GroupBox->y+GroupBox->Height-1, GroupBox->Color, "%c", LeftUpLine);
		// draw horizontal lines
		for (i = 0; i < GroupBox->Length-2; i++)
		{
			// the title must have at least one space at the start and at the end of the string
			if ( !((i > 0) && (i <= (int) strlen (GroupBox->Title)+2)) )
			{
				Print (GroupBox->x+i+1, GroupBox->y, GroupBox->Color, "%c", HorizontalLine);
			}
			// print the group box title and two spaces
			else
			{
				Print (GroupBox->x+2, GroupBox->y, GroupBox->Color, " ");
				Print (GroupBox->x+(int) strlen (GroupBox->Title)+3, GroupBox->y, GroupBox->Color, " ");
				Print (GroupBox->x+3, GroupBox->y, GroupBox->TitleColor, "%s", GroupBox->Title);
			}
			Print (GroupBox->x+i+1, GroupBox->y+GroupBox->Height-1, GroupBox->Color, "%c", HorizontalLine);
		}
		// draw vertical lines
		for (i = 0; i < GroupBox->Height-2; i++)
		{
			Print (GroupBox->x, GroupBox->y+i+1, GroupBox->Color, "%c", VerticalLine);
			Print (GroupBox->x+GroupBox->Length-1, GroupBox->y+i+1, GroupBox->Color, "%c", VerticalLine);
		}
		// draw inside the groupbox
		for	(i = 0; i < GroupBox->Height-2; i++)
		{
			for	(j = 0; j < GroupBox->Length-2; j++)
			{
				Print (GroupBox->x+j+1, GroupBox->y+i+1, GroupBox->Color, "%c", GroupBox->Pattern);
			}
		}
	}
	else
	{
		// error checking
		if ( !((GroupBox->x >= 0) && (GroupBox->x <= 73)) )
		{
			ErrorMsg ("GroupBox->x is not between 0 and 73                (GroupBox->x = %02d).", GroupBox->x);
		}
		if ( !((GroupBox->y >= 0) && (GroupBox->y <= 22)) )
		{
			ErrorMsg ("GroupBox->y is not between 0 and 22                (GroupBox->y = %02d).", GroupBox->y);
		}
		if ( !(GroupBox->Length > 6) )
		{
			ErrorMsg ("GroupBox->Length is not greater than 6              (GroupBox->Length = %02d).", GroupBox->Length);
		}
		if ( !(GroupBox->Height > 2) )
		{
			ErrorMsg ("GroupBox->Height is not greater than 2              (GroupBox->Height = %02d).", GroupBox->Height);
		}
		if ( !(GroupBox->x+GroupBox->Length <= 80) )
		{
			ErrorMsg ("GroupBox->x+GroupBox->Length is greater than 79     (GroupBox->x+GroupBox->Length = %02d).", GroupBox->x+GroupBox->Length);
		}
		if ( !(GroupBox->y+GroupBox->Height <= 25) )
		{
			ErrorMsg ("GroupBox->y+GroupBox->Height is greater than 24     (GroupBox->y+GroupBox->Height = %02d).", GroupBox->y+GroupBox->Height);
		}
		if ( !((int) strlen (GroupBox->Title) >= 1) )
		{
			ErrorMsg ("strlen (GroupBox->Title) is not greater than 1     (strlen (GroupBox->Title) = %02d).", strlen (GroupBox->Title));
		}
		if ( !(((int) strlen (GroupBox->Title)+6) <= GroupBox->Length) )
		{
			ErrorMsg ("strlen (GroupBox->Title)+6 is not less or equal to  GroupBox->Length (strlen (GroupBox->Title)+6 = %02d).", strlen (GroupBox->Title)+6);
		}
	}
}