# include "main.h"
# include "menu.h"



void MainMenu ()
{
	// input variables
	INPUT_RECORD ir = {0};
	DWORD Read = 0;
	// common variables
	short i = 0, j = 0; // counters
	short HelpIsDisplayed = 0; // flag which becomes true if help text is displayed in the status line
	// variables for menu buttons (Show ASCII Table, Help, Author, Exit)
	short MainMenuLoop = 0, xStartMenu[MAIN_MENU_NO_OF_ITEMS] = {0}, MainMenuValue = MAIN_MENU_DEFAULT_SELECTED;
	short xEndMenu[MAIN_MENU_NO_OF_ITEMS] = {0}, yStartMenu[MAIN_MENU_NO_OF_ITEMS] = {0}, ReDrawMainMenu = 0;
	short yItemNameLength = 0, xItemNameLength = 0, MenuTempIndex = 0, MenuSelected = 1;
	short WriteMenu = 0, MarkMenu = 0, MenuIndex = 0, MenuClicked = 0;
	char *MainMenuItems[MAIN_MENU_NO_OF_ITEMS] = {0}, *MainMenuHelp[MAIN_MENU_NO_OF_ITEMS] = {0};
	// edit box variables
	short ebX[CODEPAGE_EB_WHOLE_NO] = {0}, ebY[CODEPAGE_EB_WHOLE_NO] = {0}, ebLength[CODEPAGE_EB_WHOLE_NO] = {0};
	short ebSelected[CODEPAGE_EB_WHOLE_NO] = {0}, x[CODEPAGE_EB_WHOLE_NO] = {0}, ebIndex[CODEPAGE_EB_WHOLE_NO] = {0};
	WORD ebColor[CODEPAGE_EB_WHOLE_NO] = {0};
	char ebCodePage[11] = {0};
	// options
	HANDLE Stdin = {0};
	WORD ItemColor = 0, ItemHighLightColor = 0, DisabledItemColor = 0, DisabledItemHighLightColor = 0;
	WORD HelpColor = 0;
	short DisabledItem[MAIN_MENU_NO_OF_ITEMS] = {0}, ShowHelp = 0;


	
	
	