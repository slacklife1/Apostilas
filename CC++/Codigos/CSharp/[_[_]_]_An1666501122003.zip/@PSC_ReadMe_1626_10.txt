Title: [ [ ] ] Ant Hill Sim (Scent AI)
Description: I recently stumbled across Scent Trail AI, and found a fairly
good VB application that demostrated it. This was:
Ant Farm Simulator, by Roberto Aguirre, 
	available at http://www.geocities.com/chamonate/hormigas/antfarm/
I really thought it had potential, and combining this with my own ideas
and other sources I decided to try a object oriented approach (not that this
version is really that OO), anyway I rewrote it from scatch in C#, 
partly as a turtorial for others and just as an exercise in AI for myself.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=1626&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
