/* This is my Ant Hill Simualator the Version can be found in the AssemblyInfo.cs
 * 
 * The goal of this project is to experiment with different AI models in a simulation type
 *	environment, then as I get closer to a useable gaming model, then I'll use this in
 *  a MORPG with minimal graphic front-end, mainly experimental, or research for other new developers.
 * 
 * Feel free to change or modify the code, and use it as a tool, it sure would be nice to
 *  give me credit for something if you do use this in something that you make for yourself
 *  or others, but what you do if up to you.
 * 
 * Questions or Comments may be addressed to Spot <NorthSpot@Hotmail.com>, and you can find more
 *  information or get current version of this on my web-site (http://www16.brinkster.com/spotshome/).  
 *  This code is free to use modify and distribute, so long as what your doing with it is also free, 
 *  I'd like to here about any interesting modifications that other programmers come up with.
 */

using System;
using System.Drawing;
using Microsoft.DirectX;
using Container = System.ComponentModel.Container;
using System.Windows.Forms;

namespace AI
{
	/// <summary>
	/// The main windows form for the application.
	/// </summary>
	public class MainClass : System.Windows.Forms.Form
	{

		//private const float spriteSize = 50;
		private System.Windows.Forms.PictureBox pbTarget;
		private System.Windows.Forms.GroupBox groupBox1;
		private int iRenderFreq = 100;

		public Point destination = new Point(0, 0);
	
		private GraphicsClass graphics = null;
		private Container components = null;
		private Control target = null; // Target for rendering operations.

		private Hive ocHive = new Hive();
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtPop;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtFood;
		private System.Windows.Forms.TextBox txtTicks;
		private System.Windows.Forms.Label label3;
		private Grid ocGrid = new Grid(250,30);			

		/// <summary>
		// Main entry point of the application.
		/// </summary>
		public static void Main()
		{
			MainClass m = new MainClass();
			Application.Exit();
		}

		public MainClass()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			target = pbTarget;
			graphics = new GraphicsClass(target);
			InitObj();

			Show();
			StartLoop();
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		// This is the main loop of the application.
		/// </summary>
		private void StartLoop()
		{
			while(Created)
			{
				//CheckBounds();
				if (ocGrid.GridFood > 0)
				{
					double fFood  = ocHive.HiveFood;
					World.Time += World.TickInc;
					if ((int)(World.Time*10) % iRenderFreq == 0)
					{
						Console.WriteLine("*** Time : {0} ***", World.Time);
						Console.WriteLine("Grid: (Food:={0})", ocGrid.GridFood);
						Console.WriteLine("Hive: (Food:={0}) (Pop:={1}) (Gen:={2})", ocHive.HiveFood, ocHive.Population, ocHive.GenerationCounter);
						//Console.WriteLine(ocGrid.ToString());
						txtTicks.Text = Convert.ToString((int)(World.Time*10));
						txtFood.Text = ocGrid.GridFood.ToString();
						txtPop.Text = ocHive.Population.ToString();
						graphics.RenderGraphics(ocGrid, ocHive);
					}
					ocGrid.TimeTick();
					ocHive.TimeTick();
				}
				Application.DoEvents();
			}
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pbTarget = new System.Windows.Forms.PictureBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.txtPop = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtFood = new System.Windows.Forms.TextBox();
			this.txtTicks = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// pbTarget
			// 
			this.pbTarget.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.pbTarget.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pbTarget.Location = new System.Drawing.Point(136, 8);
			this.pbTarget.Name = "pbTarget";
			this.pbTarget.Size = new System.Drawing.Size(264, 264);
			this.pbTarget.TabIndex = 0;
			this.pbTarget.TabStop = false;
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left)));
			this.groupBox1.Controls.Add(this.txtTicks);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.txtFood);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.txtPop);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(128, 288);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label1.Location = new System.Drawing.Point(8, 40);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Current Pop";
			// 
			// txtPop
			// 
			this.txtPop.Location = new System.Drawing.Point(72, 40);
			this.txtPop.Name = "txtPop";
			this.txtPop.Size = new System.Drawing.Size(48, 20);
			this.txtPop.TabIndex = 1;
			this.txtPop.Text = "";
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label2.Location = new System.Drawing.Point(8, 64);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(72, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "Grid Food";
			// 
			// txtFood
			// 
			this.txtFood.Location = new System.Drawing.Point(72, 64);
			this.txtFood.Name = "txtFood";
			this.txtFood.Size = new System.Drawing.Size(48, 20);
			this.txtFood.TabIndex = 3;
			this.txtFood.Text = "";
			// 
			// txtTicks
			// 
			this.txtTicks.Location = new System.Drawing.Point(40, 16);
			this.txtTicks.Name = "txtTicks";
			this.txtTicks.Size = new System.Drawing.Size(80, 20);
			this.txtTicks.TabIndex = 5;
			this.txtTicks.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 16);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(72, 16);
			this.label3.TabIndex = 4;
			this.label3.Text = "Time";
			// 
			// MainClass
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(408, 294);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.pbTarget);
			this.KeyPreview = true;
			this.Name = "MainClass";
			this.Text = "Prj-DirDraw";
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainClass_KeyDown);
			this.Resize += new System.EventHandler(this.Repaint);
			this.Activated += new System.EventHandler(this.Repaint);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
		/// <summary>
		// Handles keyboard events.
		/// </summary>
		private void MainClass_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			int iSpd = 3;
			switch (e.KeyCode)
			{
				case Keys.Up:
				{
					destination.Y -= iSpd;
					break;
				}
				case Keys.Down:
				{
					destination.Y += iSpd; 
					break;
				}
				case Keys.Left:
				{
					destination.X -= iSpd; 
					break;
				}
				case Keys.Right:
				{
					destination.X += iSpd; 
					break;
				}
			}
			//CheckBounds();
			graphics.RenderGraphics(ocGrid, ocHive);
		}

		/// <summary>
		// Checks the boundaries of graphics
		// objects to ensure they stay in bounds.
		/// </summary>
		//    private void CheckBounds()
		//    {
		//        if (destination.X < 0)
		//            destination.X = 0;
		//        if (destination.X > target.ClientSize.Width - spriteSize)
		//            destination.X = target.ClientSize.Width  - (int)spriteSize;
		//        if (destination.Y < 0)
		//            destination.Y = 0;
		//        if (destination.Y > target.ClientSize.Height - spriteSize)
		//            destination.Y = target.ClientSize.Height - (int)spriteSize;
		//    }

		private void Repaint(object sender, System.EventArgs e)
		{
			if (graphics != null)
				graphics.RenderGraphics(ocGrid, ocHive);       
		}

		public void InitObj()
		{
			ocHive.Map = ocGrid;
			ocHive.Population = 1;
		}

	}
}
