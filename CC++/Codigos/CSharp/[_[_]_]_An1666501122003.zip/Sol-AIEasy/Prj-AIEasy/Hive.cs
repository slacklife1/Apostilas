/* This is my Hive class, part of the Ant Hill Simualator the 
 *  Version can be found in the AssemblyInfo.cs
 * 
 * Questions or Comments may be addressed to Spot <NorthSpot@Hotmail.com>, and you can find more
 *  information or get current version of this on my web-site (http://www16.brinkster.com/spotshome/).  
 *  This code is free to use modify and distribute, so long as what your doing with it is also free, 
 *  I'd like to here about any interesting modifications that other programmers come up with.
 */

using System;
using System.Drawing;
using System.Collections;
using Toolkit;

namespace AI
{
	/// <summary>
	/// Summary description for Hive.
	/// </summary>
	public class Hive
	{
		private Hashtable mo_Creature = new Hashtable();
		
		public Grid Map;

		public int GenerationCounter=0;
		public int PopulationInit;
		public double HiveFood;
		public PointF Location;
		public int HiveQuad;
		public double CreatureSize = 10;
		public Creature Queen;
		
		public int Population 
		{
			get {return mo_Creature.Count;}
			set 
			{
				PopulationInit = value;
				Populate(PopulationInit);
			}
		}

		public Hive()
		{
			InitHive(new PointF(0,0));
		}
		public Hive(PointF ptLoc)
		{
			InitHive(ptLoc);
		}

		private void InitHive(PointF ptLoc)
		{
			Queen = new Creature(CreatureSize, this);

			Location = ptLoc;
		}

		private void Populate(int iPop)
		{
			GenerationCounter += 1;
			HiveQuad = Map.GetQuadIndex(Location);
			for (int iLoop = 0; iLoop < iPop; iLoop++)
			{
				MateWithQueen(Queen);
			}
		}

		public void TimeTick()
		{
			IEnumerator IList = mo_Creature.GetEnumerator();
			Creature ocCur;
			Map[this.HiveQuad].HiveScent = World.MaxScentTrace;

			if (this.Population==0)
			{
				Populate(PopulationInit);
			}

			try
			{
				while (IList.MoveNext())
				{
					DictionaryEntry oDE = (DictionaryEntry) IList.Current;
					ocCur = (Creature) oDE.Value;
					ocCur.TimeTick();
				}
			}
			catch 
			{
			}
			//MoveHive();
		}

		public Creature MateWithQueen(Creature oLucky)
		{
			World.DebugMessage(3, "{0} Has returned with enough food to mate", oLucky.Name);

			Creature ocHiveMember = new Creature(CreatureSize, this);
			string sID = World.NewID(ocHiveMember);
			ocHiveMember.Name = sID;
			ocHiveMember.HiveScent = World.MaxScentTrace;

			mo_Creature.Add(sID, ocHiveMember);
			
			Map[HiveQuad].CreatureCount +=1;

			return ocHiveMember;
		}

		public void HiveMemberDeath(Creature oKenny)
		{
			mo_Creature.Remove(oKenny.Name);
		}

		private void MoveHive()
		{
			Location.X += 0.001F;
			Location.Y += 0.002F;
			HiveQuad = Map.GetQuadIndex(Location);
		}

		public bool Draw(GraphicsClass g)
		{
			IEnumerator IList = mo_Creature.GetEnumerator();
			Creature ocCur;
			Map[this.HiveQuad].HiveScent = World.MaxScentTrace;
			g.DrawCircle(Map.CoordPoint(this.Location), 5, Color.Chocolate, Color.Crimson);

			try
			{
				while (IList.MoveNext())
				{
					DictionaryEntry oDE = (DictionaryEntry) IList.Current;
					ocCur = (Creature) oDE.Value;
					if (World.Time-ocCur.Birthdate > ocCur.LifeSpan*0.8)
						g.DrawCircle(Map.CoordPoint(ocCur.Location), (int)6, Color.Blue, Color.Brown);
					else
						g.DrawCircle(Map.CoordPoint(ocCur.Location), (int)4, Color.Goldenrod, Color.Brown);

					if (ocCur.Food > 0)
						g.DrawCircle(Map.CoordPoint(ocCur.Location), (int)2, Color.DarkOliveGreen, Color.DarkSeaGreen);
				}
			}
			catch 
			{
			}

			return true;
		}
	}
}
