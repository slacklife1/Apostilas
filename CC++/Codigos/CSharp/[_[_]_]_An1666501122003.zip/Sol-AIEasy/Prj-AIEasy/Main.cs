/* This is my (Old) Main class (from when it was a console app), part of the Ant Hill Simualator the 
 *  Version can be found in the AssemblyInfo.cs
 * 
 * Questions or Comments may be addressed to Spot <NorthSpot@Hotmail.com>, and you can find more
 *  information or get current version of this on my web-site (http://www16.brinkster.com/spotshome/).  
 *  This code is free to use modify and distribute, so long as what your doing with it is also free, 
 *  I'd like to here about any interesting modifications that other programmers come up with.
 */

using System;
using System.Drawing;
using Toolkit;

namespace AI
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class StartApp
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		
		[STAThread]
		static void MainCmd(string[] args)
		{
			//TestGrid oTestGrid = new TestGrid();
			TestHive oTestHive = new TestHive();
		}
	}

	class TestGrid
	{
		public TestGrid()
		{
			Grid ocGrid = new Grid(100,10);
			PointF ptOrigin = new PointF(0,0);
			Quadrant oCenter = ocGrid.Quad[ocGrid.GetQuadIndex(ptOrigin)];
			Console.WriteLine(oCenter.ToString());
			Console.WriteLine(ocGrid.RandomDirection(ptOrigin, 100).Index.ToString());
			Console.WriteLine(ocGrid.RandomDirection(ptOrigin, 250).Index.ToString());
			Console.WriteLine(ocGrid.RandomDirection(ptOrigin, 450).Index.ToString());
			Console.WriteLine(ocGrid.RandomDirection(ptOrigin, 500).Index.ToString());
			for (int iLoop = 0; iLoop < 10; iLoop++)
			{
				Quadrant oQuad = ocGrid.RandomDirection(ptOrigin, 1000);
				if (oQuad != null)
					Console.WriteLine("["+iLoop.ToString()+"]:"+oQuad.Coords.ToString());
			}
			PointF ptTmp;
			Quadrant oTmpQuad;
			
			ptTmp = new PointF(-500,-500);
			oTmpQuad = ocGrid.Quad[ocGrid.GetQuadIndex(ptTmp)];
			Console.WriteLine(oTmpQuad.Coords.ToString());

			ptTmp = new PointF(-500,499);
			oTmpQuad = ocGrid.Quad[ocGrid.GetQuadIndex(ptTmp)];
			Console.WriteLine(oTmpQuad.Coords.ToString());
		
			ptTmp = new PointF(499,499);
			oTmpQuad = ocGrid.Quad[ocGrid.GetQuadIndex(ptTmp)];
			Console.WriteLine(oTmpQuad.Coords.ToString());
		
			ptTmp = new PointF(499,-500);
			oTmpQuad = ocGrid.Quad[ocGrid.GetQuadIndex(ptTmp)];
			Console.WriteLine(oTmpQuad.Coords.ToString());
		}
	}


	class TestHive
	{
		public TestHive()
		{
			Hive ocHive = new Hive();
			Grid ocGrid = new Grid(400,15);			
			ocHive.Map = ocGrid;
			ocHive.Population = 1;
			while (ocGrid.GridFood > 0)
			{
				double fFood  = ocHive.HiveFood;
				World.Time += World.TickInc;
				if ((int)(World.Time*10) % 1000 == 0)
				{
					Console.WriteLine("*** Time : {0} ***", World.Time);
					Console.WriteLine("Grid: (Food:={0})", ocGrid.GridFood);
					Console.WriteLine("Hive: (Food:={0}) (Pop:={1}) (Gen:={2})", ocHive.HiveFood, ocHive.Population, ocHive.GenerationCounter);
					Console.WriteLine(ocGrid.ToString());
				}
				ocGrid.TimeTick();
				ocHive.TimeTick();
				//if (fFood != ocHive.HiveFood)
				//	Console.ReadLine();
			}
		}
	}
}
