/* This is my Creature baseclass part of the Ant Hill Simualator the 
 *  Version can be found in the AssemblyInfo.cs
 * 
 * Questions or Comments may be addressed to Spot <NorthSpot@Hotmail.com>, and you can find more
 *  information or get current version of this on my web-site (http://www16.brinkster.com/spotshome/).  
 *  This code is free to use modify and distribute, so long as what your doing with it is also free, 
 *  I'd like to here about any interesting modifications that other programmers come up with.
 */

using System;
using System.Drawing;
using Toolkit;

namespace AI
{
	/// <summary>
	/// Summary description for Creature.
	/// </summary>
	public class Creature
	{
		public string Name = "";

		public double HiveScent = 0;
		public double FoodScent = 0;
		public double Food = 0;
		public PointF Location;
		public double Facing;  //0 to 2PI (PI/2 = Up)

		public double Size;
		public double Birthdate;
		public double Bite;
		public double Age = 0;
		public double Move;
		public double LifeSpan = 2000;
		public double SensorRange;
		public double WanderTime;
		public double MaxWanderTime;
		public int Perception;

		public Hive Colony;

		public Creature(){}
		public Creature(double dSize, Hive ocHive)
		{
			InitCreature(dSize, ocHive);
		}

		private void InitCreature(double dSize, Hive ocHive)
		{
			Birthdate = World.Time;
			Facing = 2 * Math.PI * World.NextRandom;
			Size = dSize;
			Bite = dSize * 0.5;
			Move = dSize * 0.5;
			SensorRange = dSize * 2;
			Perception = 5;
			MaxWanderTime = 10;
			WanderTime = 0;

			Colony = ocHive;
			Location = new PointF(ocHive.Location.X,ocHive.Location.Y);
		}

		public virtual void TimeTick()
		{
			int iQuad = Colony.Map.GetQuadIndex(Location);
			Quadrant oCurQuad = Colony.Map[iQuad];

			if (Food==0)
			{
				//If isn't carrying food
				if (oCurQuad.Food > 0)
				{
					//If "On" Food, then take Bite
					if (oCurQuad.Food > Bite)
					{
						Food = Bite;
						Colony.Map[iQuad].Food -= Bite;
						FoodScent = World.MaxScentTrace;
					}
					else
					{
						Food = oCurQuad.Food;
						Colony.Map[iQuad].Food = 0;
					}
					HiveScent=0;
					//Found food Turn around
					World.DebugMessage(4, "    Got Food: [{0}]  Facing:[{1}]", Food, Facing);
					Facing += Math.PI;
					World.DebugMessage(4, "    Turned around, Facing:[{0}]", Facing);
					//Console.ReadLine();
				}
				else
				{

					//Wander
					WanderTime -= 1;
					if (WanderTime < 0) 
					{
						WanderTime += World.NextRandom * MaxWanderTime;

						int iLook = this.LookAround(enLookFor.HighFood);
						if (iLook > -1)
						{
							// Face the food
							if (iQuad != iLook)
								Facing = World.AngleBetween(Location, Colony.Map[iLook].Center);
						}
						else
						{
							//Wander +/- 60 Degrees
							Facing = Facing + (World.NextRandom-0.5) * Math.PI / 3 * 2;
						}
					}
				}
			}
			else
			{
				if (Colony.Map.GetQuadIndex(Colony.Location) == oCurQuad.Index)
				{
					HiveScent = World.MaxScentTrace;
					FoodScent=0;
					Colony.HiveFood+=Food;
					Food = 0;
					if (Colony.HiveFood > World.CreatureBirthFood)
					{				
						Colony.HiveFood -= World.CreatureBirthFood;
						Colony.MateWithQueen(this);
					}
				}
				else
				{
					int iLook = this.LookAround(enLookFor.HiveHigh);
					if (iLook > -1)
					{
						// Face the Hive
						if (iQuad != iLook)
							Facing = World.AngleBetween(Location, Colony.Map[iLook].Center);
					}
					else
					{
						//Wander
						WanderTime -= 1;
						if (WanderTime < 0) 
						{
							WanderTime += World.NextRandom * MaxWanderTime;
							//Wander +/- 60 Degrees
							Facing = Facing + (World.NextRandom-0.5) * Math.PI / 3 * 2;
						}
					}
				}
			}

			if (World.Time-Birthdate > LifeSpan)
			{
				Colony.HiveMemberDeath(this);
				Colony.Map[iQuad].Food += Size;
				Colony.Map[iQuad].CreatureCount--;
			}
			else
			{
				Movement();
				if (this.HiveScent > 0) this.HiveScent-=2;
				if (this.FoodScent > 0) this.FoodScent-=2;
			}
		}

		public virtual int LookAround(enLookFor eCriteria) 
		{
			double fCurrentRet;
			int iRet = -1;

			if (eCriteria==enLookFor.LowFood || eCriteria==enLookFor.LowHive)
			{
				fCurrentRet = World.MaxScentTrace;
			}
			else
			{
				fCurrentRet = 0;
			}

			for (int iLook = 0; iLook < Perception; iLook++)
			{
				Quadrant LookQuad = Colony.Map.RandomDirection(Location, SensorRange);
	
				if (LookQuad != null )
				{
					switch (eCriteria)
					{
						case enLookFor.HighFood:
							if (LookQuad.Food > 0)
							{
								fCurrentRet = World.MaxScentTrace;
								iRet = LookQuad.Index;
							}
							else
							{
								if (LookQuad.FoodScent > fCurrentRet)
								{
									fCurrentRet = LookQuad.FoodScent;
									iRet = LookQuad.Index;
								}
							}
							break;
						case enLookFor.LowFood:
							if (LookQuad.FoodScent < fCurrentRet)
							{
								fCurrentRet = LookQuad.FoodScent;
								iRet = LookQuad.Index;
							}
							break;
						case enLookFor.HiveHigh:
							if (World.SqrDist(Colony.Location, Location) < SensorRange*SensorRange)
							{
								fCurrentRet = World.MaxScentTrace;
								iRet = LookQuad.Index;
							}
							else
							{
								if (LookQuad.HiveScent > fCurrentRet)
								{
									fCurrentRet = LookQuad.HiveScent;
									iRet = LookQuad.Index;
								}
							}
							break;
						case enLookFor.LowHive:
							if (LookQuad.HiveScent < fCurrentRet)
							{
								fCurrentRet = LookQuad.HiveScent;
								iRet = LookQuad.Index;
							}
							break;
					}
				}
			}

			if (iRet > -1)
			{
				World.DebugMessage(3, "Goal in Sight");
				//Console.ReadLine();
			}

			return iRet;
		}

		public virtual void Movement()
		{
			//Wander +/- 5 Degrees
			Facing = Facing + (World.NextRandom-0.5) * Math.PI / 36;

			PointF PtStep = new PointF( Location.X + (float)(Move * Math.Cos(Facing)), Location.Y + (float)(Move * Math.Sin(Facing)) );
			
			if (Colony.Map.PointOnGrid(PtStep))
			{
				int iQuad;
				iQuad = this.Colony.Map.GetQuadIndex(Location);
				this.Colony.Map.Quad[iQuad].CreatureCount--;
				World.DebugMessage(4, "    Facing:{0}, Move:{1} -> {2}", Facing*180/Math.PI, Location, PtStep);
				Location.X = PtStep.X;
				Location.Y = PtStep.Y;
				iQuad = this.Colony.Map.GetQuadIndex(Location);
				this.Colony.Map.Quad[iQuad].CreatureCount++;
				if (this.HiveScent > this.Colony.Map.Quad[iQuad].HiveScent) this.Colony.Map.Quad[iQuad].HiveScent = this.HiveScent;
				if (this.FoodScent > this.Colony.Map.Quad[iQuad].FoodScent) this.Colony.Map.Quad[iQuad].FoodScent = this.FoodScent;;
			}
			if (Facing < 0)
				Facing += Math.PI * 2;
			if (Facing > Math.PI * 2)
				Facing -= Math.PI * 2;
		}
	}
}
