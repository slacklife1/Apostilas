/* This is my DirectDraw class, part of the Ant Hill Simualator the 
 *  Version can be found in the AssemblyInfo.cs
 * 
 * Questions or Comments may be addressed to Spot <NorthSpot@Hotmail.com>, and you can find more
 *  information or get current version of this on my web-site (http://www16.brinkster.com/spotshome/).  
 *  This code is free to use modify and distribute, so long as what your doing with it is also free, 
 *  I'd like to here about any interesting modifications that other programmers come up with.
 */

using System;
using System.Windows.Forms;
using System.Drawing;
using Microsoft.DirectX;
using Microsoft.DirectX.DirectDraw;

namespace AI
{
	/// <summary>
	/// This class is where the Drawing routines
	/// for non-Direct3D and non-DirectDraw 
	/// applications reside.
	/// </summary>
	public class GraphicsClass
	{
		private Control owner = null;

		private const int ScreenSize = 100; 
		private const int spriteSize = 5;
		private Device localDevice = null;
		private Clipper localClipper = null;
		private Surface surfacePrimary = null;
		private Surface surfaceSecondary = null;

		public GraphicsClass(Control owner)
		{
			this.owner = owner;
		
			localDevice = new Device();
			localDevice.SetCooperativeLevel(owner, CooperativeLevelFlags.Normal);

			CreateSurfaces();
		}

		private void CreateSurfaces()
		{
			SurfaceDescription desc = new SurfaceDescription();
			SurfaceCaps caps = new SurfaceCaps(); 

			localClipper = new Clipper(localDevice);
			localClipper.Window = owner;

			desc.SurfaceCaps.PrimarySurface = true;
			surfacePrimary = new Surface(desc, localDevice);
			surfacePrimary.Clipper = localClipper;
        
			desc.Clear();
			desc.SurfaceCaps.OffScreenPlain = true;
			desc.Width = (int)(surfacePrimary.SurfaceDescription.Width);
			desc.Height = (int)(surfacePrimary.SurfaceDescription.Height);
        
			surfaceSecondary = new Surface(desc, localDevice);            
			surfaceSecondary.FillStyle = 0;
		}

		public void RenderGraphics(Grid oGrid, Hive oHive)
		{
			if (!owner.Created)
				return;

			//Rectangle dest = new Rectangle(owner.PointToScreen(new Point(destination.X, destination.Y)),new Size(spriteSize, spriteSize));
			//Rectangle dest = new Rectangle(owner.PointToScreen(ScalePt(destination.X, destination.Y)),new Size((int)ScaleX(spriteSize), (int)ScaleY(spriteSize)));
		
			if (null == surfacePrimary || null == surfaceSecondary)
				return;

			try
			{
				surfaceSecondary.ColorFill(Color.DarkKhaki);
				oGrid.Draw(this);
				oHive.Draw(this);
				//DrawCircle(new Point((int)(rnd.NextDouble()*ScreenSize*2)-ScreenSize,(int)(rnd.NextDouble()*ScreenSize*2)-ScreenSize), spriteSize/2,Color.Aquamarine,Color.Blue);
				//surfaceSecondary.ForeColor = Color.Blue;
				//surfaceSecondary.FillColor = Color.Aquamarine;
				//surfaceSecondary.DrawEllipse(dest.Left, dest.Y, dest.Right, dest.Bottom);
				surfacePrimary.Draw(surfaceSecondary, DrawFlags.DoNotWait);
			}
				//catch(SurfaceLostException)
			catch(Exception)
			{
				// The surface can be lost if power saving
				// mode kicks in, or any other number of
				// reasons.
				CreateSurfaces();
			}
		}

		public void DrawCircle(Point ptCenter, int iRad, Color cFill, Color cBorder)
		{
			surfaceSecondary.ForeColor = cBorder;
			surfaceSecondary.FillColor = cFill;

			Rectangle dest = new Rectangle(owner.PointToScreen(ScalePt(ptCenter.X-iRad, ptCenter.Y-iRad)),new Size((int)ScaleX(iRad*2), (int)ScaleY(iRad*2)));
			surfaceSecondary.DrawEllipse(dest.Left, dest.Y, dest.Right, dest.Bottom);
		}

		public void DrawSqr(Point ptCenter, int iRad, Color cFill, Color cBorder)
		{
			surfaceSecondary.ForeColor = cBorder;
			surfaceSecondary.FillColor = cFill;

			Rectangle dest = new Rectangle(owner.PointToScreen(ScalePt(ptCenter.X-iRad, ptCenter.Y-iRad)),new Size((int)ScaleX(iRad*2), (int)ScaleY(iRad*2)));
			surfaceSecondary.DrawBox(dest.Left, dest.Y, dest.Right, dest.Bottom);
		}

		private Point ScalePt(int iX, int iY)
		{
			return new Point((int)ScaleX(iX) + owner.Width/2, (int)ScaleY(iY) + owner.Height/2);
		}
	
		private Point ScalePt(Point pt)
		{
			return new Point((int)ScaleX(pt.X) + owner.Width/2, (int)ScaleY(pt.Y) + owner.Height/2);
		}
		private float ScaleX(int iX)
		{
			return (float)iX*owner.Width/(ScreenSize*2);
		}
		private float ScaleY(int iY)
		{
			return (float)iY*owner.Height/(ScreenSize*2);
		}
	}
}