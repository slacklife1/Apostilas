/* This is my Quadrant and Grid classes, part of the Ant Hill Simualator the 
 *  Version can be found in the AssemblyInfo.cs
 * 
 * Questions or Comments may be addressed to Spot <NorthSpot@Hotmail.com>, and you can find more
 *  information or get current version of this on my web-site (http://www16.brinkster.com/spotshome/).  
 *  This code is free to use modify and distribute, so long as what your doing with it is also free, 
 *  I'd like to here about any interesting modifications that other programmers come up with.
 */

using System;
using System.Drawing;

namespace AI
{
	/// <summary>
	/// Summary description for Grid.
	/// </summary>
	public class Quadrant
	{
		public Point Coords;
		public PointF Center;
		public int Index;
		public double Food;
		public int CreatureCount;
		public double HiveScent;
		public double FoodScent;

		public Quadrant()
		{
			BlankInit();
		}
		
		public Quadrant(int iX, int iY, int iIndex)
		{
			BlankInit();
			Coords = new Point(iX, iY);
			Index = iIndex;
		}

		public Quadrant(int iX, int iY, double fSize, int iDim)
		{
			BlankInit();
			Coords = new Point(iX, iY);
			Index = iX + iY*iDim;

			double fGridLen = (double)iDim * fSize / 2;
			double fX = ((double)iX * fSize) - fGridLen + fSize / 2;
			double fY = ((double)iY * fSize) - fGridLen + fSize / 2;
			Center = new PointF((float)fX, (float)fY);
		}

		private void BlankInit()
		{
			Coords = new Point();
			Index = 0;
			Food = 0;
			CreatureCount = 0;
			HiveScent = 0;
			FoodScent = 0;
		}
	}

	/// <summary>
	/// Summary description for Grid.
	/// </summary>
	public class Grid
	{
		public double GridFood;
		private double mf_PlantPct;
		private double mf_Size;
		private int mi_Dimension;
		private double mf_GridLen;
		private bool mb_Wrap = true;

		public Quadrant[] Quad;

		public Grid() 
		{
			mf_PlantPct = World.FoodAbundancyPct;
			InitGrid(10, 10);
		}
		public Grid(double dSize, int iDim)
		{
			mf_PlantPct = World.FoodAbundancyPct;
			InitGrid(dSize, iDim);
		}
		public Grid(double dSize, int iDim, double fPctFood)
		{
			mf_PlantPct = fPctFood;
			InitGrid(dSize, iDim);
		}

		private void InitGrid(double fSize, int iDim)
		{
			mf_GridLen = fSize/2 * (double)iDim;
			mf_Size = fSize;
			mi_Dimension = iDim;
			Quad = new Quadrant[mi_Dimension * mi_Dimension];

			for (int iX = 0; iX <mi_Dimension; iX++)
			{
				for (int iY = 0; iY <mi_Dimension; iY++)
				{
					Quad[iX+iY*mi_Dimension] = new Quadrant(iX, iY, mf_Size, mi_Dimension);
				}
			}
			GridFood = PlantFood(mf_PlantPct);
		}

		public Quadrant this[int iX, int iY]
		{
			get {return this[iX+iY*mi_Dimension];}
			set {Quad[iX+iY*mi_Dimension] = value;}
		}
		public Quadrant this[int iIndex]
		{
			get 
			{
				if (iIndex>=0 && iIndex<Quad.Length)
					return Quad[iIndex];
				else
					return null;
			}
			set {Quad[iIndex] = value;}
		}

		public int GetQuadIndex(PointF ofPt)
		{
			PointF oGridPt = GetGridCoords(ofPt);

			if (PointOnGrid(oGridPt))
			{
				double fIndex = (((double)oGridPt.X+mf_GridLen)/mf_Size) + 
					(double)((int)(((double)oGridPt.Y+mf_GridLen)/mf_Size)) * (double)mi_Dimension;
				return (int)fIndex;
			}
			else
			{
				return -1;
			}
		}

		public PointF GetGridCoords(PointF ofPt)
		{
			PointF oPt = new PointF((float)mf_GridLen+1, (float)mf_GridLen+1);

			if (PointOnGrid(ofPt))
			{
				return ofPt;
			}
			else 
			{
				if (mb_Wrap)
				{
					float fMapX = ((float)mf_GridLen+ofPt.X) / ((float)mf_GridLen*2);
					if (fMapX < 0)
						fMapX = fMapX * ((float)mf_GridLen*2) + (float)mf_GridLen;
					else
						fMapX = (fMapX - (int)fMapX) * ((float)mf_GridLen*2) - (float)mf_GridLen;
					float fMapY = ((float)mf_GridLen+ofPt.Y) / ((float)mf_GridLen*2);
					if (fMapY < 0)
						fMapY = fMapY * ((float)mf_GridLen*2) + (float)mf_GridLen;
					else
						fMapY = (fMapY - (int)fMapY) * ((float)mf_GridLen*2) - (float)mf_GridLen;
					ofPt.X = (float)fMapX;
					ofPt.Y = (float)fMapY;
					return ofPt;
				}
				else
				{
					return oPt;
				}
			}
		}

		public bool PointOnGrid(PointF ofPt)
		{
			//if ((Math.Abs(ofPt.X)<mf_GridLen) && (Math.Abs(ofPt.Y)<mf_GridLen))
			//	return true;
			if (ofPt.X>=-mf_GridLen && ofPt.X<mf_GridLen && ofPt.Y>=-mf_GridLen && ofPt.Y<mf_GridLen)
				return true;
			return false;
		}

		public Quadrant RandomDirection(PointF ofPt, double fRange)
		{
			double fDeltaX = World.NextRandom * fRange * 2-fRange; 
			double fDeltaY = World.NextRandom * fRange * 2-fRange;

			PointF oRndPt = new PointF(ofPt.X + (float)fDeltaX, ofPt.Y + (float)fDeltaY);
			int iQuad = GetQuadIndex(oRndPt);
			if (iQuad == -1)
			{
				return null;
			}
			else
			{
				return this[iQuad];
			}

		}

		public void TimeTick()
		{
			double fGridFood = 0;

			for (int iLoop = 0; iLoop < Quad.Length; iLoop++)
			{
				//Taken care of in Creature;
				//Quad[iLoop].CreatureCount = 0;

				if (Quad[iLoop].Food > 0)
				{
					fGridFood += Quad[iLoop].Food;
					if (Quad[iLoop].Food > World.MaxQuadrantFood)
					{
						Quad[iLoop].Food -= World.FoodSeedSize;
						//added because null Quads can be returned.
						int iRandom = -1;
						while (iRandom < 0)
							iRandom = RandomDirection(Quad[iLoop].Center, mf_Size*2).Index;
						Quad[iRandom].Food += World.FoodSeedSize;
					}
					else
					{
						Quad[iLoop].Food += World.FoodGrowRate;
						Quad[iLoop].FoodScent = World.MaxScentTrace;
					}
				}
				if (Quad[iLoop].HiveScent > 0) Quad[iLoop].HiveScent-=1;
				if (Quad[iLoop].FoodScent > 0) Quad[iLoop].FoodScent-=1;
			}
			GridFood = fGridFood;
		}

		public double PlantFood(double Percent)
		{
			double fGridFood=0;

			for (int iLoop = 0; iLoop < Quad.Length; iLoop++)
			{
				if (World.NextRandom < Percent)
				{
					double fQuadFood = World.MaxQuadrantFood * World.NextRandom + 1;
					fGridFood += fQuadFood;
					Quad[iLoop].Food = fQuadFood;
				}
			}
			return fGridFood;
		}

		public override string ToString()
		{
			string sRet = "";

			for (int iLoop=0; iLoop < Quad.Length; iLoop++)
			{
				if (iLoop % mi_Dimension == 0) sRet += "\n\r";
				sRet += Quad[iLoop].CreatureCount.ToString().PadLeft(2, ' ');
				if (Quad[iLoop].Food > 0)
					if (Quad[iLoop].Food > World.CreatureBirthFood)
						sRet += "*";
					else
						sRet += "+";
				else
					sRet += " ";
				if (Quad[iLoop].HiveScent > World.MaxScentTrace * 0.1)
					if (Quad[iLoop].HiveScent > World.MaxScentTrace * 0.5)
						if (Quad[iLoop].HiveScent == World.MaxScentTrace)
							sRet += "X";
						else
							sRet += "H";
					else
						sRet += "h";
				else
					sRet += " ";
				if (Quad[iLoop].FoodScent > World.MaxScentTrace * 0.1)
					if (Quad[iLoop].FoodScent > World.MaxScentTrace * 0.5)
						sRet += "F";
					else
						sRet += "f";
				else
					sRet += " ";
			}
			return sRet;
		}

		public bool Draw(GraphicsClass g)
		{
			for (int iLoop=0; iLoop < Quad.Length; iLoop++)
			{
				if (Quad[iLoop].HiveScent > World.MaxScentTrace * 0.1)
				{
					int iShade = (int)(Quad[iLoop].HiveScent * 128 / World.MaxScentTrace);
					g.DrawSqr(CoordPoint(Quad[iLoop].Center), CoordLen(mf_Size/2), Color.FromArgb(192-iShade, 0, 192-iShade), Color.Black);
				}
				if (Quad[iLoop].FoodScent > World.MaxScentTrace * 0.1)
				{
					int iShade = (int)(Quad[iLoop].FoodScent * 128 / World.MaxScentTrace);
					g.DrawSqr(CoordPoint(Quad[iLoop].Center), CoordLen(mf_Size/4), Color.FromArgb(0, 192-iShade, 0), Color.Black);
				}
				if (Quad[iLoop].Food > 0)
				{
					g.DrawCircle(CoordPoint(Quad[iLoop].Center), (int)(Quad[iLoop].Food * 10 / World.MaxQuadrantFood), Color.Honeydew, Color.Green);
				}
			}
			return true;
		}

		public Point CoordPoint(PointF GridPt)
		{
			return new Point((int)(GridPt.X * 100 / mf_GridLen), (int)(GridPt.Y * 100 / mf_GridLen));
		}
		public int CoordLen(double fDim)
		{
			return (int)(fDim * 100 / mf_GridLen);
		}
	}
}
