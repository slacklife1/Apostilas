/* This is my World class, part of the Ant Hill Simualator the 
 *  Version can be found in the AssemblyInfo.cs
 * 
 * Questions or Comments may be addressed to Spot <NorthSpot@Hotmail.com>, and you can find more
 *  information or get current version of this on my web-site (http://www16.brinkster.com/spotshome/).  
 *  This code is free to use modify and distribute, so long as what your doing with it is also free, 
 *  I'd like to here about any interesting modifications that other programmers come up with.
 */

using System;
using System.Collections;
using System.Drawing;
using Toolkit;

namespace AI
{
	public enum enLookFor
	{
		Low = 0x01,
		Food = 0x02,
		LowFood = 0x03,
		HighFood = 0x0A,
		Hive = 0x04,
		LowHive = 0x05,
		HiveHigh = 0x0C,
		High = 0x08
	}

	/// <summary>
	/// Summary description for World.
	/// </summary>
	public class World
	{
		public static int iGlobalDebug = 1;
		public static double Time = 0;
		public static double TickInc = 0.1;
		public static double CreatureSize = 10;
		public static double CreatureBirthFood = 20;
		public static double MaxScentTrace = 10000;
		public static double MaxQuadrantFood = 25;
		public static double FoodAbundancyPct = 0.2;
		public static double FoodSeedSize = 5;
		public static double FoodGrowRate = 0.0002;

		private static long ml_Counter_S=0;
		private static Hashtable mo_Entity = new Hashtable();
		private static Grid moc_Map;
		private static Hive moc_Hive;
		private static Random m_Rnd = new Random();

		public World()
		{
			InitWorld(50, 10, 1);
		}
		public World(double dGridSize, int iGridDim, int iPop)
		{
			InitWorld(dGridSize, iGridDim, iPop);
		}

		public Quadrant this[PointF oPt]
		{
			get {return moc_Map.Quad[moc_Map.GetQuadIndex(oPt)];}
			set {moc_Map.Quad[moc_Map.GetQuadIndex(oPt)] = value;}
		}

		public Grid Map
		{
			get {return moc_Map;}
			set {moc_Map = value;}
		}

		private void InitWorld(double dGridSize, int iGridDim, int iPop)
		{
			if (mo_Entity!=null) mo_Entity.Clear();
			mo_Entity = new Hashtable();
			ml_Counter_S = 0;
			moc_Map = new Grid(dGridSize, iGridDim);
			moc_Hive = new Hive();
			moc_Hive.Map = moc_Map;
			moc_Hive.Population = 1;
		}


		public static string NewID(object obj)
		{
			string sID = Tools.TypeName(obj)+"�"+Convert.ToString(ml_Counter_S++);
			mo_Entity.Add( sID, obj);
			return sID;
		}

		public static double NextRandom
		{
			get {return m_Rnd.NextDouble();}
		}

		public static void WorldTick()
		{
			moc_Map.TimeTick();
			moc_Hive.TimeTick();
		}

		public static double SqrDist(PointF PtOne, PointF PtTwo)
		{
			PointF ptSqr = PointDiff(PtOne,PtTwo);
			return (double)(ptSqr.X*ptSqr.X + ptSqr.Y+ptSqr.Y);
		}

		public static PointF PointDiff(PointF PtOne, PointF PtTwo)
		{
			return new PointF(PtOne.X-PtTwo.X,PtOne.Y-PtTwo.Y);
		}

		public static double AngleBetween(PointF PtOne, PointF PtTwo)
		{
			PointF ptAng = PointDiff(PtTwo, PtOne);
			return Math.Atan2(ptAng.Y, ptAng.X);
		}

		public static void DebugMessage(int iLv, string sText, params object[] args)
		{
			for (int iLoop=0; iLoop < args.Length; iLoop++)
			{
				sText = sText.Replace("{"+Convert.ToString(iLoop)+"}", Convert.ToString(args[iLoop]));
			}
			DebugMessage(iLv, sText);
		}

		public static void DebugMessage(int iLv, string sText)
		{
			if (iLv <= iGlobalDebug)
			{
				Console.WriteLine(sText);
			}
		}
	}
}
