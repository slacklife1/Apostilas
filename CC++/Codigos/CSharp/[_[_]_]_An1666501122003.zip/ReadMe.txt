Author: Spot <Northspot@Hotmail.com>
Website: http://www16.brinkster.com/spotshome/

Ant Hill Simulator v1.0
-----------------------

I recently stumbled across Scent Trail AI, and found a fairly
good VB application that demostrated it.  This was:

Ant Farm Simulator, by Roberto Aguirre, 
	available at http://www.geocities.com/chamonate/hormigas/antfarm/

I really thought it had potential, and combining this with my own ideas
and other sources I decided to try a object oriented approach (not that this
version is really that OO), anyway I rewrote it from scatch in C#, 
partly as a turtorial for others and just as an exercise in AI for myself.

The version 1.0 I've applied to this is really Alpha Version 1.0,
as it's the first compile I've got to work with a DirectX frontend.
I just wanted to get this out there for others to play with, and get
feedback on.

I'm essentially using this as a game-engine tool, and the next versions
will hopefully demonstrate this in a more developer friendly assembly,
this was just my Proof of Concept model, now it's time to get down to
the real work...but first I versioned it, and am allowing others to use it.

Current Version
---------------
This application has a long way to go, and currently it's best run in
the IDE, because I didn't add UI to change all the variables in the app.
So, these will require a recompile, but there are a lot of things that
can be tweaked, some of these are:

  Creature Size
     "     MoveSpeed
     "     Lifespan
     "     Reproductive Rate
     "     Perception
     "     Wander Rate
     "     BiteSize
     
  Plant GrowthRate
    "   InitalAbundancy Percent
    "   Reproductive Features
    
  Grid SizeofQuadrants
    "  MaxFood allowed
    "  Dimension of array
 
 In addition to these there are a number of World variables that can
 be changed to allow different behaviors.
 
 Future Ideas
 ------------
 Like I said this is the first one that I slapped the DirectX frontend
 on, and I've got many adjustments to make in the next version, here
 is a list of my current plans to add into the next version:
 
 Multiple Species
    Current only the Hive and the Ant exist, ones that I plan to add are:
        Wandering Eater (think rabbit or rat)
        Wandering Hunter (think cat)
        Wandering Pack (think wolves)
        Wandering Grazer (think deer)
        Wandering Destroyer (think fire)
        Wandering Precipitator (think cloud)
        
    We'll see how many of this I get to, before I version the app again,
      as the capibilities for multple species is going to force me to 
      generalize many of the core objects.
      
 Rewrite Quadrant Class
    I plan on doing this by using a dictionary based storage device for 
    creature counters, scent storage, and food.  This way each Quadrant 
    can contain many types of each and the AI of different creatures will
    only care about certain types.
    
    I also want to add a few things for additional complexity for some
    World dynamics, such as altitude and terrain type.  Some other ideas are
    Water level, slope, etc.  These will allow water to "flow" and gather in
    lower areas of the map.
    
 Detailed Viewer
    If the Terrain will be 3D then maybe I'll have multiple viewers to toggle
    between, one for the 3D aspect, one birdseye, and have filtering boxes to
    show/hide diffent species types.
    
 Combat Calculator
    The end goal is a RPG so, I need a way to determine whos the victor is any
    conflict between two creaures.  This may be real basic at first, but as it
    get more complex than it'll involve adding more attributes to the Creatures
    to allow for a more Dnd-ish conflict resolution.
    
 Chromosomes
    I'd like to get creatures representable as a string a chromosomes, that when
    a reproduction even occurs, these are actually combined so the child is actually
    a combination of the two parentents DNA, with a chance for mutation.
        The affect of the mutation currently only performing slight adjustments on
    the creatures base attributes, but eventually I'd like to get it to the point
    where the mutation could actually result in completely new species, that would be
    a new class that would be dynamically compiled, and inserted into the Game-Engine.
    
 Complex Weather Patterns and World Dynamics
    You see I listed Clouds and Fire as a creature type, well I'd like to expand this
    to creatures that I call Spirits, that would behave like Creatures, but would be
    invisible, except to other certain type of creature.  Some relationships that I see
    existing between different species would be:
    
    Cloud Creatures would be attracted/repelled by Pressure Creatures
    
    Seeders would randomly roam the map and when certain conditions are met they could
      produce any other creature that the engine knows about.  This is largely due to possible
      extinction and deforestation...A seeder would be like mother nature of avatar that
      keeps the world evolving.  Different types of Seeder could adjust altitudes, grow plants,
      create other creatures, or increase a Grids resource.
      
    Pump Creatures would move extremly slow compared to other creatures and would spawn
      water from a Fountain location, at a given rate, this would be largely unnoticed, 
      exept when water content starts to pool in certain areas, and begines to cause rivers 
      to flow.  A fountian creature can be very long, and ends in a Drain, which consumes 
      water at the same rate as its fountain spews it.
   
    Transmuter Creature would simply roam around changing resources it finds from one to 
      another, the change would have to occur only after predefined conditions have been
      met, but would allow the landscape to change over time. 

Conclusion
----------
As you can see there's a lot to be done before it can be implemented in a game scenerio, with
rivers that flow, plants that grow, and creatures that eats, move, and reproduce so their bloodline
will continue to live on.

This doesn't even go into much of the games engine as far as how skills are used and formulas
for creating items, but thats a different article that I can go into at a later date...

Like I said I'd be happy to here ideas, or other such things, especially enhancements you make
the code, so feel free to write me.   

Spot <Northspot@Hotmail.com>
http://www16.brinkster.com/spotshome/
