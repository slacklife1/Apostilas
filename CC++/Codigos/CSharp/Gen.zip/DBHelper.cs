using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Gen2
{
	public class DBHelper
	{
		DataSet _dsProcs;

		private string _server;
		private string _db;
		private string _login;
		private string _pwd;

		private string _cnstring;

		public DBHelper(string server, string db) : this(server, db, null, null)
		{
		}
		public DBHelper(string server, string db, string login, string pwd)
		{
			_server=server;
			_db=db;
			_login=login;
			_pwd=pwd;
		}
		public void Init()
		{
			string cnstring;
			if(_login==null)
			{
				cnstring=string.Format(@"Integrated Security=SSPI;Persist Security Info=False;Initial Catalog={0};Data Source={1}",
					_db, _server);
			}
			else
			{
				cnstring=string.Format(@"Persist Security Info=False;User ID={0};PWD={1};Initial Catalog={2};Data Source={3}",
					_login, _pwd, _db, _server);
			}

			_cnstring=cnstring;
			
			StringBuilder bld=new StringBuilder();
			bld.Append("SELECT SPECIFIC_NAME, ROUTINE_NAME, ROUTINE_SCHEMA, ROUTINE_DEFINITION, CREATED, LAST_ALTERED, ROUTINE_NAME as MethodName ");
			bld.Append("FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_TYPE='PROCEDURE' ORDER BY ROUTINE_NAME;");
			bld.Append("SELECT SPECIFIC_NAME, ORDINAL_POSITION, PARAMETER_MODE,");
			bld.Append("PARAMETER_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, ");
			bld.Append("REPLACE(PARAMETER_NAME, '@', '') as MethodParmName, MethodParmType=");

			bld.Append("CASE DATA_TYPE ");
			bld.Append("WHEN 'varchar' THEN 'String' ");
			bld.Append("WHEN 'nvarchar' THEN 'String' ");
			bld.Append("WHEN 'char' THEN 'String' ");
			bld.Append("WHEN 'nchar' THEN 'String' ");
			bld.Append("WHEN 'text' THEN 'String' ");
			bld.Append("WHEN 'ntext' THEN 'String' ");
			bld.Append("WHEN 'bigint' THEN 'Int64' ");
			bld.Append("WHEN 'binary' THEN 'Byte[]' ");
			bld.Append("WHEN 'bit' THEN 'Boolean' ");
			bld.Append("WHEN 'datetime' THEN 'DateTime' ");
			bld.Append("WHEN 'decimal' THEN 'Decimal' ");
			bld.Append("WHEN 'float' THEN 'Double' ");
			bld.Append("WHEN 'image' THEN 'Byte[]' ");
			bld.Append("WHEN 'int' THEN 'Int32' ");
			bld.Append("WHEN 'money' THEN 'Decimal' ");
			bld.Append("WHEN 'numeric' THEN 'Decimal' ");
			bld.Append("WHEN 'real' THEN 'Single' ");
			bld.Append("WHEN 'smalldatetime' THEN 'DateTime' ");
			bld.Append("WHEN 'smallint' THEN 'Int16' ");
			bld.Append("WHEN 'smallmoney' THEN 'Decimal' ");
			bld.Append("WHEN 'sql_variant' THEN 'Object *' ");
			bld.Append("WHEN 'timestamp' THEN 'Byte[]' ");
			bld.Append("WHEN 'tinyint' THEN 'Byte' ");
			bld.Append("WHEN 'uniqueidentifier' THEN 'Guid' ");
			bld.Append("WHEN 'varbinary' THEN 'Byte[]' ");
			bld.Append("ELSE 'Object' ");
			bld.Append("END ");

			bld.Append(" FROM ");
			bld.Append("INFORMATION_SCHEMA.PARAMETERS WHERE SPECIFIC_NAME IN (");
			bld.Append("SELECT SPECIFIC_NAME ");
			bld.Append("FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_TYPE='PROCEDURE') ORDER BY ORDINAL_POSITION;");
			
			string sql=bld.ToString();
			
			SqlConnection cn=new SqlConnection(cnstring);
			SqlDataAdapter da=new SqlDataAdapter(sql, cn);
			_dsProcs=new DataSet();
			da.Fill(_dsProcs);
			cn.Close();

			_dsProcs.Relations.Add("procs_parms",
				_dsProcs.Tables[0].Columns["SPECIFIC_NAME"],
				_dsProcs.Tables[1].Columns["SPECIFIC_NAME"]);
		}
		public DataSet Procs
		{
			get
			{
				return _dsProcs;
			}
		}
		public string RelName
		{
			get{return "procs_parms";}
		}
		public string ConnectionString
		{
			get{return _cnstring;}
		}
	}
}
