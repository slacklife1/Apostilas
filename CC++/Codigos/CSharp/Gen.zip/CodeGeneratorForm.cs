using System;
using Microsoft.Win32;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Gen2
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem mnuFile;
		private System.Windows.Forms.MenuItem mnuConnect;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.Panel panel1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.ListView lstProcs;
		private System.Windows.Forms.StatusBarPanel statusBarPanel1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtSchema;
		private System.Windows.Forms.TextBox txtDefinition;
		private System.Windows.Forms.TextBox txtCreated;
		private System.Windows.Forms.TextBox txtLastAltered;
		private System.Windows.Forms.TextBox txtMethodName;


		private DBHelper _db;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ComboBox drpRetType;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.ColumnHeader columnHeader4;
		private System.Windows.Forms.ColumnHeader columnHeader5;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox txtParmName;
		private System.Windows.Forms.TextBox txtParmType;
		private System.Windows.Forms.ListView lstParams;
		private NodeTag _currentNode;
		private System.Windows.Forms.MenuItem mnuRefresh;
		private DataRow _currentChildRow;
		private System.Windows.Forms.MenuItem mnuGenerate;

		private CodeWindow _codeWindow;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.mnuFile = new System.Windows.Forms.MenuItem();
			this.mnuConnect = new System.Windows.Forms.MenuItem();
			this.mnuRefresh = new System.Windows.Forms.MenuItem();
			this.mnuGenerate = new System.Windows.Forms.MenuItem();
			this.lstProcs = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.panel1 = new System.Windows.Forms.Panel();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.txtParmName = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.lstParams = new System.Windows.Forms.ListView();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
			this.label8 = new System.Windows.Forms.Label();
			this.txtParmType = new System.Windows.Forms.TextBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.drpRetType = new System.Windows.Forms.ComboBox();
			this.txtCreated = new System.Windows.Forms.TextBox();
			this.txtDefinition = new System.Windows.Forms.TextBox();
			this.txtSchema = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.txtLastAltered = new System.Windows.Forms.TextBox();
			this.txtMethodName = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
			this.panel1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
			this.SuspendLayout();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuFile});
			// 
			// mnuFile
			// 
			this.mnuFile.Index = 0;
			this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuConnect,
																					this.mnuRefresh,
																					this.mnuGenerate});
			this.mnuFile.Text = "File";
			// 
			// mnuConnect
			// 
			this.mnuConnect.Index = 0;
			this.mnuConnect.Text = "Connect...";
			this.mnuConnect.Click += new System.EventHandler(this.mnuConnect_Click);
			// 
			// mnuRefresh
			// 
			this.mnuRefresh.Index = 1;
			this.mnuRefresh.Text = "Refresh List";
			this.mnuRefresh.Click += new System.EventHandler(this.mnuRefresh_Click);
			// 
			// mnuGenerate
			// 
			this.mnuGenerate.Index = 2;
			this.mnuGenerate.Text = "Generate Code...";
			this.mnuGenerate.Click += new System.EventHandler(this.mnuGenerate_Click);
			// 
			// lstProcs
			// 
			this.lstProcs.BackColor = System.Drawing.SystemColors.Info;
			this.lstProcs.CheckBoxes = true;
			this.lstProcs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																					   this.columnHeader1});
			this.lstProcs.Dock = System.Windows.Forms.DockStyle.Left;
			this.lstProcs.FullRowSelect = true;
			this.lstProcs.GridLines = true;
			this.lstProcs.HideSelection = false;
			this.lstProcs.MultiSelect = false;
			this.lstProcs.Name = "lstProcs";
			this.lstProcs.Size = new System.Drawing.Size(208, 561);
			this.lstProcs.Sorting = System.Windows.Forms.SortOrder.Ascending;
			this.lstProcs.TabIndex = 0;
			this.lstProcs.View = System.Windows.Forms.View.Details;
			this.lstProcs.SelectedIndexChanged += new System.EventHandler(this.lstProcs_SelectedIndexChanged);
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Procedure";
			this.columnHeader1.Width = 196;
			// 
			// splitter1
			// 
			this.splitter1.Location = new System.Drawing.Point(208, 0);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(8, 561);
			this.splitter1.TabIndex = 1;
			this.splitter1.TabStop = false;
			// 
			// panel1
			// 
			this.panel1.AutoScroll = true;
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.groupBox2,
																				 this.groupBox1});
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(216, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(472, 561);
			this.panel1.TabIndex = 2;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.txtParmName,
																					this.label7,
																					this.lstParams,
																					this.label8,
																					this.txtParmType});
			this.groupBox2.Location = new System.Drawing.Point(16, 352);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(440, 192);
			this.groupBox2.TabIndex = 1;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Parameters";
			// 
			// txtParmName
			// 
			this.txtParmName.Location = new System.Drawing.Point(184, 130);
			this.txtParmName.Name = "txtParmName";
			this.txtParmName.Size = new System.Drawing.Size(232, 20);
			this.txtParmName.TabIndex = 5;
			this.txtParmName.Text = "";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(24, 132);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(144, 16);
			this.label7.TabIndex = 2;
			this.label7.Text = "Method Parameter Name";
			// 
			// lstParams
			// 
			this.lstParams.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.columnHeader2,
																						this.columnHeader3,
																						this.columnHeader4,
																						this.columnHeader5});
			this.lstParams.FullRowSelect = true;
			this.lstParams.GridLines = true;
			this.lstParams.HideSelection = false;
			this.lstParams.Location = new System.Drawing.Point(12, 24);
			this.lstParams.MultiSelect = false;
			this.lstParams.Name = "lstParams";
			this.lstParams.Size = new System.Drawing.Size(416, 96);
			this.lstParams.TabIndex = 0;
			this.lstParams.View = System.Windows.Forms.View.Details;
			this.lstParams.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Name";
			this.columnHeader2.Width = 114;
			// 
			// columnHeader3
			// 
			this.columnHeader3.Text = "Mode";
			this.columnHeader3.Width = 100;
			// 
			// columnHeader4
			// 
			this.columnHeader4.Text = "Data Type";
			this.columnHeader4.Width = 97;
			// 
			// columnHeader5
			// 
			this.columnHeader5.Text = "Max Length";
			this.columnHeader5.Width = 81;
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(24, 160);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(144, 16);
			this.label8.TabIndex = 2;
			this.label8.Text = "Method Parameter Type";
			// 
			// txtParmType
			// 
			this.txtParmType.Location = new System.Drawing.Point(184, 157);
			this.txtParmType.Name = "txtParmType";
			this.txtParmType.Size = new System.Drawing.Size(232, 20);
			this.txtParmType.TabIndex = 5;
			this.txtParmType.Text = "";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.drpRetType,
																					this.txtCreated,
																					this.txtDefinition,
																					this.txtSchema,
																					this.label3,
																					this.label1,
																					this.label2,
																					this.label4,
																					this.label5,
																					this.txtLastAltered,
																					this.txtMethodName,
																					this.label6});
			this.groupBox1.Location = new System.Drawing.Point(16, 16);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(440, 320);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Properties";
			// 
			// drpRetType
			// 
			this.drpRetType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.drpRetType.Location = new System.Drawing.Point(112, 278);
			this.drpRetType.Name = "drpRetType";
			this.drpRetType.Size = new System.Drawing.Size(312, 21);
			this.drpRetType.TabIndex = 5;
			// 
			// txtCreated
			// 
			this.txtCreated.Location = new System.Drawing.Point(112, 181);
			this.txtCreated.Name = "txtCreated";
			this.txtCreated.ReadOnly = true;
			this.txtCreated.Size = new System.Drawing.Size(312, 20);
			this.txtCreated.TabIndex = 4;
			this.txtCreated.Text = "";
			// 
			// txtDefinition
			// 
			this.txtDefinition.Location = new System.Drawing.Point(112, 64);
			this.txtDefinition.Multiline = true;
			this.txtDefinition.Name = "txtDefinition";
			this.txtDefinition.ReadOnly = true;
			this.txtDefinition.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtDefinition.Size = new System.Drawing.Size(312, 104);
			this.txtDefinition.TabIndex = 3;
			this.txtDefinition.Text = "";
			// 
			// txtSchema
			// 
			this.txtSchema.Location = new System.Drawing.Point(112, 31);
			this.txtSchema.Name = "txtSchema";
			this.txtSchema.ReadOnly = true;
			this.txtSchema.Size = new System.Drawing.Size(312, 20);
			this.txtSchema.TabIndex = 2;
			this.txtSchema.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 184);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(88, 16);
			this.label3.TabIndex = 1;
			this.label3.Text = "Created";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 32);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(88, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Schema";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 64);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(88, 16);
			this.label2.TabIndex = 0;
			this.label2.Text = "Definition";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(16, 216);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(88, 16);
			this.label4.TabIndex = 1;
			this.label4.Text = "Last Altered";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 248);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(88, 16);
			this.label5.TabIndex = 1;
			this.label5.Text = "Method Name";
			// 
			// txtLastAltered
			// 
			this.txtLastAltered.Location = new System.Drawing.Point(112, 214);
			this.txtLastAltered.Name = "txtLastAltered";
			this.txtLastAltered.ReadOnly = true;
			this.txtLastAltered.Size = new System.Drawing.Size(312, 20);
			this.txtLastAltered.TabIndex = 4;
			this.txtLastAltered.Text = "";
			// 
			// txtMethodName
			// 
			this.txtMethodName.Location = new System.Drawing.Point(112, 246);
			this.txtMethodName.Name = "txtMethodName";
			this.txtMethodName.Size = new System.Drawing.Size(312, 20);
			this.txtMethodName.TabIndex = 4;
			this.txtMethodName.Text = "";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(16, 280);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(88, 16);
			this.label6.TabIndex = 1;
			this.label6.Text = "Return Type";
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 561);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.statusBarPanel1});
			this.statusBar1.ShowPanels = true;
			this.statusBar1.Size = new System.Drawing.Size(688, 16);
			this.statusBar1.TabIndex = 3;
			this.statusBar1.Text = "statusBar1";
			// 
			// statusBarPanel1
			// 
			this.statusBarPanel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.statusBarPanel1.Text = "Ready";
			this.statusBarPanel1.Width = 672;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(688, 577);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panel1,
																		  this.splitter1,
																		  this.lstProcs,
																		  this.statusBar1});
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Generator";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.Form1_Load);
			this.panel1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void mnuConnect_Click(object sender, System.EventArgs e)
		{
			Connect();
		}
		private void Connect()
		{
			ConnectDlg dlg=new ConnectDlg();

			RegistryKey rk=Registry.CurrentUser.CreateSubKey(@"Software\Rovshan\Gen2");
			object server=rk.GetValue("LastServer");
			if(server!=null)
			{
				dlg.Server=rk.GetValue("LastServer").ToString();
				dlg.DB=rk.GetValue("LastDB").ToString();
			}

			if(dlg.ShowDialog(this)!=DialogResult.OK)
				return;
			if(dlg.WinAuth)
				_db=new DBHelper(dlg.Server, dlg.DB);
			else
				_db=new DBHelper(dlg.Server, dlg.DB, dlg.Login, dlg.Pwd);

			rk.SetValue("LastServer", dlg.Server);
			rk.SetValue("LastDB", dlg.DB);
			rk.Close();

			dlg.Dispose();

			RetrieveSchema();
		}
		private void RetrieveSchema()
		{
			mnuFile.Enabled=false;
			Status="Connecting...";

			try
			{
				_db.Init();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this, ex.Message);
				Status="";
				mnuFile.Enabled=true;
				return;
			}
			
			Status="";
			mnuFile.Enabled=true;

			ShowProcs();
		}
		private void ShowProcs()
		{
			lstProcs.Items.Clear();

			DataTable dtProcs=_db.Procs.Tables[0];
			foreach(DataRow row in dtProcs.Rows)
			{
				ListViewItem lvi=new ListViewItem(row["SPECIFIC_NAME"].ToString());
				lvi.Tag=new NodeTag(row);
				lstProcs.Items.Add(lvi);
			}
		}

		private void lstProcs_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if(_currentNode!=null)
			{
				SaveChangesToRow();
			}
			if(lstProcs.SelectedItems.Count>0)
			{
				_currentNode=(NodeTag)lstProcs.SelectedItems[0].Tag;
				LoadPropertiesFromRow();
			}
		}
	
		private string Status
		{
			get{return statusBar1.Panels[0].Text;}
			set
			{
				statusBar1.Panels[0].Text=value!="" ? value : "Ready";
			}
		}
		private void LoadPropertiesFromRow()
		{
			DataRow currentRow=_currentNode.Row;

			txtSchema.Text=currentRow["ROUTINE_SCHEMA"].ToString();
			txtDefinition.Text=currentRow["ROUTINE_DEFINITION"].ToString();
			txtCreated.Text=currentRow["CREATED"].ToString();
			txtLastAltered.Text=currentRow["LAST_ALTERED"].ToString();
			txtMethodName.Text=currentRow["MethodName"].ToString();

			drpRetType.SelectedIndex=drpRetType.Items.IndexOf(_currentNode.ReturnType.ToString());

			LoadParamInfo();
		}
		private void SaveChangesToRow()
		{
			DataRow currentRow=_currentNode.Row;

			currentRow["MethodName"]=txtMethodName.Text;
			_currentNode.ReturnType=(MethodRetType)Enum.Parse(typeof(MethodRetType), drpRetType.SelectedIndex.ToString(), true);
		}
		private void FillReturnTypes()
		{
			drpRetType.DataSource=Enum.GetNames(typeof(MethodRetType));
			drpRetType.SelectedIndex=0;
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			FillReturnTypes();
		}

		private void listView1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if(_currentChildRow!=null)
			{
				SaveChangesToChildRow();
			}
			if(lstParams.SelectedItems.Count>0)
			{
				_currentChildRow=(DataRow)lstParams.SelectedItems[0].Tag;
				LoadPropertiesFromChildRow();
			}
		}
		private void LoadPropertiesFromChildRow()
		{
			DataRow currentRow=_currentChildRow;

			txtParmName.Text=currentRow["MethodParmName"].ToString();
			txtParmType.Text=currentRow["MethodParmType"].ToString();
		}
		private void SaveChangesToChildRow()
		{
			DataRow currentRow=_currentChildRow;

			currentRow["MethodParmName"]=txtParmName.Text;
			currentRow["MethodParmType"]=txtParmType.Text;
		}
		private void LoadParamInfo()
		{
			lstParams.Items.Clear();

			DataRow[] parameters=_currentNode.Row.GetChildRows(_db.RelName);
			foreach(DataRow param in parameters)
			{
				string[] items=new string[]
				{
					param["PARAMETER_NAME"].ToString(),
					param["PARAMETER_MODE"].ToString(),
					param["DATA_TYPE"].ToString(),
					param["CHARACTER_MAXIMUM_LENGTH"].ToString()
				};
				ListViewItem lvi=new ListViewItem(items);
				lvi.Tag=param;
				lstParams.Items.Add(lvi);
			}
			if(lstParams.Items.Count>0)
			{
				lstParams.Items[0].Selected=true;
			}
		}

		private void mnuRefresh_Click(object sender, System.EventArgs e)
		{
			if(_db!=null)
			{
				if(MessageBox.Show(this, "All the changes will be lost", "Confirm",
					MessageBoxButtons.OKCancel)==DialogResult.OK)
				{
					RetrieveSchema();
				}
			}
			else
			{
				MessageBox.Show("You must connect first");
			}
		}

		private void mnuGenerate_Click(object sender, System.EventArgs e)
		{
			if(_db==null)
			{
				MessageBox.Show("You must connect first");
				return;
			}
			Generate();
		}
		public void Generate()
		{
			if(_currentNode!=null)
			{
				SaveChangesToRow();
			}
			if(_currentChildRow!=null)
			{
				SaveChangesToChildRow();
			}
			try
			{
				if(_codeWindow==null || _codeWindow.IsDisposed)
				{
					_codeWindow=new CodeWindow();
				}
				ListView.CheckedListViewItemCollection checkedItems=lstProcs.CheckedItems;
				NodeTag[] tags=new NodeTag[checkedItems.Count];
				for(int i=0; i<checkedItems.Count; i++)
				{
					tags[i]=(NodeTag)checkedItems[i].Tag;
				}
				Generator gen=new Generator(tags, _db);
				_codeWindow.txtCode.Text=gen.Generate();

				this.AddOwnedForm(_codeWindow);
				_codeWindow.Show();
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
	}
}
