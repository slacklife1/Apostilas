using System;

namespace Gen2
{
	/// <summary>
	/// Summary description for MethodRetType.
	/// </summary>
	public enum MethodRetType
	{
		Void,
		DataReader,
		DataTable,
		DataSet,
		Object
	}
}
