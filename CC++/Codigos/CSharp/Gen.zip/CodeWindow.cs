using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Gen2
{
	/// <summary>
	/// Summary description for CodeWindow.
	/// </summary>
	public class CodeWindow : System.Windows.Forms.Form
	{
		public System.Windows.Forms.TextBox txtCode;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem mnuCode;
		private System.Windows.Forms.MenuItem mnuRefresh;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CodeWindow()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtCode = new System.Windows.Forms.TextBox();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.mnuCode = new System.Windows.Forms.MenuItem();
			this.mnuRefresh = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// txtCode
			// 
			this.txtCode.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.txtCode.Location = new System.Drawing.Point(8, 8);
			this.txtCode.Multiline = true;
			this.txtCode.Name = "txtCode";
			this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtCode.Size = new System.Drawing.Size(496, 440);
			this.txtCode.TabIndex = 0;
			this.txtCode.Text = "";
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuCode});
			// 
			// mnuCode
			// 
			this.mnuCode.Index = 0;
			this.mnuCode.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					this.mnuRefresh});
			this.mnuCode.Text = "Code";
			// 
			// mnuRefresh
			// 
			this.mnuRefresh.Index = 0;
			this.mnuRefresh.Text = "Refresh";
			this.mnuRefresh.Click += new System.EventHandler(this.mnuRefresh_Click);
			// 
			// CodeWindow
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(512, 453);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.txtCode});
			this.Menu = this.mainMenu1;
			this.Name = "CodeWindow";
			this.Text = "Generated Code";
			this.ResumeLayout(false);

		}
		#endregion

		private void mnuRefresh_Click(object sender, System.EventArgs e)
		{
			Form1 frmGen=(Form1)this.Owner;
			frmGen.Generate();
		}
	}
}
