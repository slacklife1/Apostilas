using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

using System.Windows.Forms;


namespace Gen2
{
	public class ConnectDlg : Gen2.DlgTpl
	{
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.TextBox txtServer;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtDB;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.CheckBox chkWinAuth;
		private System.Windows.Forms.TextBox txtPwd;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtLogin;
		private System.Windows.Forms.Label label3;
		private System.ComponentModel.IContainer components = null;

		public ConnectDlg()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.txtServer = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.txtDB = new System.Windows.Forms.TextBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.chkWinAuth = new System.Windows.Forms.CheckBox();
			this.txtPwd = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtLogin = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(136, 264);
			this.btnOK.Visible = true;
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(240, 264);
			this.btnCancel.Visible = true;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.txtServer,
																					this.label4,
																					this.label1,
																					this.txtDB});
			this.groupBox2.Location = new System.Drawing.Point(6, 8);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(328, 96);
			this.groupBox2.TabIndex = 2;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Server and Database";
			// 
			// txtServer
			// 
			this.txtServer.Location = new System.Drawing.Point(106, 27);
			this.txtServer.Name = "txtServer";
			this.txtServer.Size = new System.Drawing.Size(208, 20);
			this.txtServer.TabIndex = 0;
			this.txtServer.Text = "localhost";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(10, 59);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(88, 16);
			this.label4.TabIndex = 8;
			this.label4.Text = "Database";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(10, 27);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(88, 16);
			this.label1.TabIndex = 2;
			this.label1.Text = "Server";
			// 
			// txtDB
			// 
			this.txtDB.Location = new System.Drawing.Point(106, 59);
			this.txtDB.Name = "txtDB";
			this.txtDB.Size = new System.Drawing.Size(208, 20);
			this.txtDB.TabIndex = 1;
			this.txtDB.Text = "";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.chkWinAuth,
																					this.txtPwd,
																					this.label2,
																					this.txtLogin,
																					this.label3});
			this.groupBox1.Location = new System.Drawing.Point(6, 120);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(328, 120);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Login details";
			// 
			// chkWinAuth
			// 
			this.chkWinAuth.Checked = true;
			this.chkWinAuth.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkWinAuth.Location = new System.Drawing.Point(128, 93);
			this.chkWinAuth.Name = "chkWinAuth";
			this.chkWinAuth.Size = new System.Drawing.Size(168, 16);
			this.chkWinAuth.TabIndex = 2;
			this.chkWinAuth.Text = "Windows Authentication";
			this.chkWinAuth.CheckedChanged += new System.EventHandler(this.chkWinAuth_CheckedChanged);
			// 
			// txtPwd
			// 
			this.txtPwd.Location = new System.Drawing.Point(104, 62);
			this.txtPwd.Name = "txtPwd";
			this.txtPwd.PasswordChar = '*';
			this.txtPwd.ReadOnly = true;
			this.txtPwd.Size = new System.Drawing.Size(208, 20);
			this.txtPwd.TabIndex = 1;
			this.txtPwd.Text = "";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 30);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(88, 16);
			this.label2.TabIndex = 4;
			this.label2.Text = "Login";
			// 
			// txtLogin
			// 
			this.txtLogin.Location = new System.Drawing.Point(104, 30);
			this.txtLogin.Name = "txtLogin";
			this.txtLogin.ReadOnly = true;
			this.txtLogin.Size = new System.Drawing.Size(208, 20);
			this.txtLogin.TabIndex = 0;
			this.txtLogin.Text = "sa";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 62);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(88, 16);
			this.label3.TabIndex = 6;
			this.label3.Text = "Password";
			// 
			// ConnectDlg
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(340, 311);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.groupBox2,
																		  this.groupBox1,
																		  this.btnCancel,
																		  this.btnOK});
			this.Name = "ConnectDlg";
			this.Text = "Connect To Database";
			this.groupBox2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void chkWinAuth_CheckedChanged(object sender, System.EventArgs e)
		{
			txtLogin.ReadOnly=chkWinAuth.Checked;
			txtPwd.ReadOnly=chkWinAuth.Checked;
		}
		public string Server
		{
			get{return txtServer.Text;}
			set{txtServer.Text=value;}
		}
		public string DB
		{
			get{return txtDB.Text;}
			set{txtDB.Text=value;}
		}
		public string Login
		{
			get{return txtLogin.Text;}
		}
		public string Pwd
		{
			get{return txtPwd.Text;}
		}
		public bool WinAuth
		{
			get{return chkWinAuth.Checked;}
		}
	}
}

