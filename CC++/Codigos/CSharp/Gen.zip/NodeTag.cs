using System;
using System.Data;

namespace Gen2
{
	public class NodeTag
	{
		private MethodRetType _methodRetType=MethodRetType.Void;
		private DataRow _row;

		public NodeTag(DataRow row)
		{
			_row=row;
		}
		public DataRow Row
		{
			get{return _row;}
		}
		public MethodRetType ReturnType
		{
			get{return _methodRetType;}
			set{_methodRetType=value;}
		}
	}
}
