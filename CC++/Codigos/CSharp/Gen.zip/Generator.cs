using System;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Gen2
{
	/// <summary>
	/// Summary description for Generator.
	/// </summary>
	public class Generator
	{
		private NodeTag[] _tags;
		private DBHelper _db;

		public Generator(NodeTag[] tags, DBHelper db)
		{
			_tags=tags;
			_db=db;
		}
		public string Generate()
		{
			StringBuilder bld=new StringBuilder();
			GenerateCode(_tags, bld);
			return bld.ToString();
		}
		private void GenerateCode(NodeTag[] tags, StringBuilder bld)
		{
			bld.Append("using System;\r\nusing System.Data;\r\nusing System.Data.SqlClient;\r\n\r\n");
			bld.Append("\r\nnamespace SampleNamespace{"); //start namespace
			bld.Append("\r\npublic class SampleClass ").Append("{"); //start class

			bld.AppendFormat("\r\n//Connection String: {0}\r\n", _db.ConnectionString); //connection string

			foreach(NodeTag tag in tags)
			{
			//	ProcNodeTag tag=n.Tag as ProcNodeTag;
			//	if(tag==null)
			//	{
			//		ClassNodeTag cls=n.Tag as ClassNodeTag;
			//		if(cls!=null)
			//		{
			//			GenerateCode(n, bld);
			//		}
			//		continue;
			//	}

				bld.AppendFormat("\r\n\tpublic {0} {1}", GetRetType(tag), GetFuncName(tag)).Append("\r\n\t{"); //start function

				bld.Append(GetOpenCn(tag));

				bld.Append("\r\n\t}"); //end function
			}

			bld.Append("\r\n}"); //end class
			bld.Append("\r\n}"); //end namespace
		}
		private string GetOpenCn(NodeTag tag)
		{
			StringBuilder bld=new StringBuilder();
			//bld.Append("\t\t\r\n//assume there is a DBHelper class with a static GetConnectionString() method\r\n");
			bld.Append("\r\n\t\tSqlConnection cn=new SqlConnection(DBHelper.GetConnectionString());\r\n");
			if(tag.ReturnType!=MethodRetType.DataReader)
			{
				bld.Append("\t\ttry{\r\n");
			}
			
			bld.Append(GetRes(tag));

			if(tag.ReturnType!=MethodRetType.DataReader)
			{
				bld.Append("\t\t}\r\n");
				bld.Append("\t\tfinally{\r\n");
				bld.Append("\t\t\tcn.Close();\r\n");
				bld.Append("\t\t}\r\n");
			}

			return bld.ToString();
		}
		private string GetRes(NodeTag tag)
		{
			DataRow procrow=tag.Row;
			StringBuilder bld=new StringBuilder();
			StringBuilder outs=new StringBuilder();
			if(tag.ReturnType==MethodRetType.DataSet || tag.ReturnType==MethodRetType.DataTable)
			{
				string rettype=((tag.ReturnType==MethodRetType.DataSet) ? "DataSet" : "DataTable");
				bld.AppendFormat("\t\t\tSqlDataAdapter da=new SqlDataAdapter(\"{0}\", cn);\r\n", procrow["ROUTINE_NAME"]);
				bld.AppendFormat("\t\t\t{0}CommandType=CommandType.StoredProcedure;\r\n", "da.SelectCommand.");

				bld.Append(AddParms(tag, outs));
				
				bld.AppendFormat("\t\t\t{0} d=new {0}(\"{1}\");\r\n", rettype, procrow["ROUTINE_NAME"]);
				bld.Append("\t\t\tda.Fill(d);\r\n");
				bld.Append("\t\t\treturn d;\r\n");

			}
			else
			{
				bld.AppendFormat("\t\t\tSqlCommand cmd=new SqlCommand(\"{0}\", cn);\r\n", procrow["ROUTINE_NAME"]);
				bld.Append("\t\t\tcn.Open();\r\n\r\n");
				bld.AppendFormat("\t\t\t{0}CommandType=CommandType.StoredProcedure;\r\n", "cmd.");
				bld.Append(AddParms(tag, outs));

				if(tag.ReturnType==MethodRetType.Void)
				{
					bld.Append("\t\t\tcmd.ExecuteNonQuery();\r\n");
				}
				else if(tag.ReturnType==MethodRetType.Object)
				{
					bld.Append("\t\t\tobject result=cmd.ExecuteScalar();\r\n");
					bld.Append("\t\t\treturn result;");
				}
				else if(tag.ReturnType==MethodRetType.DataReader)
				{
					bld.Append("\t\t\tSqlDataReader rdr=cmd.ExecuteReader(CommandBehavior.CloseConnection);\r\n");
					bld.Append("\t\t\treturn rdr;\r\n");
				}
				bld.Append("\r\n");
				bld.Append(outs);
			}

			return bld.ToString();
		}
		private string AddParms(NodeTag tag, StringBuilder outs)
		{
			DataRow[] parms=tag.Row.GetChildRows(_db.RelName);
			if(parms.Length<1)
				return "";

			StringBuilder bld=new StringBuilder();
			string prefix=((tag.ReturnType==MethodRetType.DataSet || tag.ReturnType==MethodRetType.DataTable) ? "da.SelectCommand." : "cmd.");
			for(int i=0; i<parms.Length; i++)
			{
				DataRow row=parms[i];
				
				string parmname="parm_"+i;
				ParameterDirection direction=ParameterDirection.Input;
				switch(row["PARAMETER_MODE"].ToString())
				{
					case "IN":
						break;
					case "INOUT":
						direction=ParameterDirection.InputOutput;
						break;
					case "OUT":
						direction=ParameterDirection.Output;
						break;
					case "RETURN":
						direction=ParameterDirection.ReturnValue;
						break;
					default:
						throw new Exception("Unknown parameter direction: "+row["PARAMETER_MODE"].ToString());
				}
				SqlDbType dbtype=(SqlDbType)Enum.Parse(typeof(SqlDbType), row["DATA_TYPE"].ToString(), true);

				bld.AppendFormat("\t\t\tSqlParameter {0}={3}Parameters.Add(\"{1}\", SqlDbType.{2}",
					parmname, row["PARAMETER_NAME"], dbtype, prefix);
				if(row["CHARACTER_MAXIMUM_LENGTH"]!=DBNull.Value)
				{
					bld.AppendFormat(", {0}", row["CHARACTER_MAXIMUM_LENGTH"]);
				}
				bld.Append(");\r\n");
				
				bld.AppendFormat("\t\t\t{0}.Value={1};\r\n", parmname, row["MethodParmName"]);
				bld.AppendFormat("\t\t\t{0}.Direction=ParameterDirection.{1};\r\n\r\n", parmname, direction);

				if(tag.ReturnType!=MethodRetType.DataReader && direction!=ParameterDirection.Input)
				{
					outs.AppendFormat("\t\t\t{0}=({3}){1}Parameters[\"{2}\"].Value;\r\n",
						row["MethodParmName"], prefix, row["PARAMETER_NAME"],
						row["MethodParmType"]);
				}
 			}

			return bld.ToString();
		}
		private string GetFuncName(NodeTag tag)
		{
			string methodname=tag.Row["MethodName"].ToString();
			StringBuilder bld=new StringBuilder();
			bld.Append(methodname).Append("(");
			DataRow[] procdata=tag.Row.GetChildRows(_db.RelName);
			for(int i=0; i<procdata.Length; i++)
			{
				DataRow row=procdata[i];
				if(row["PARAMETER_MODE"].ToString()!="IN")
					bld.Append("ref ");
				bld.Append(row["MethodParmType"]).Append(" ").Append(row["MethodParmName"]);
				if(i!=procdata.Length-1)
					bld.Append(",");
			}
			bld.Append(")");
			return bld.ToString();
		}
		private string GetRetType(NodeTag tag)
		{
			MethodRetType type=tag.ReturnType;
			string rettype="";
			switch(type)
			{
				case MethodRetType.Void:
					rettype="void";
					break;
				case MethodRetType.DataReader:
					rettype="SqlDataReader";
					break;
				case MethodRetType.DataTable:
					rettype="DataTable";
					break;
				case MethodRetType.DataSet:
					rettype="DataSet";
					break;
				case MethodRetType.Object:
					rettype="Object";
					break;
			}
			return rettype;
		}
	}
}


