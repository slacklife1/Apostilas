using System;
using System.IO ;
using System.Text .RegularExpressions ;

namespace FileOperation
{
	
	/// <summary>
	///This class is responsable for event handling
	/// </summary>
	
	public class EventArgsPercent:EventArgs
		
	{
		/// <summary>
		/// parmater percent
		/// </summary>
		private long percent=0;
		
		/// <summary>
		/// parmater percent
		/// </summary>

		public long Percent
		{
			get
			{
				return percent;
			}
			set
			{
				percent=value;
			}
		}

		public EventArgsPercent(long p)
		{
			percent=p;
		}

	}
	public class FileOper
	{
		const char limt =(char)0xbb;
		const byte enf  =0xff;
		private FileInfo finfo=null;
		private FileAttributes fattr;
		private string fname=null;
		private string password=null;
		private string teststr=null;
		private long percentchange=0; //filelenth/100;
		private long counter=0;      //changes from 0 to filelenth/100
		private long percentage=0;  //changes from 0 to 100
		public delegate void OnePercentChange(object o,EventArgsPercent v);
		public event OnePercentChange OnOnePercent;
		
		public FileInfo Finfo
		{
			get
			{
				return finfo;
			}
			set
			{
				if(value.Exists ==false)
				{
					finfo=null;
					throw new Exception ("File Not Exists");
				}
				finfo=value;
				fname=finfo.DirectoryName +"\\"+value.Name ;
				fattr=finfo.Attributes;
			}
		}
		public string Password
		{
			get
			{
				return password;
			}
			set
			{
				password=value;
			}
		}
		public string Fname
		{
			get
			{
				return fname;
			}
			set
			{
				Finfo=new FileInfo (value);
				
			}
		}

		public FileOper()
		{
			finfo=null;
            
		}
		public FileOper(string str,string pass)
		{
		Finfo=new FileInfo (str);
		Password=pass;	
		}
		public FileOper(FileInfo f,string pass)
		{
			Finfo=f;
			
			Password=pass;
			
		}
		~FileOper()
		{
			finfo=null;
			fname=null;
			password=null;
		
		}
		public override string ToString()
		{
			string str="Encryption ,Decryption liberary\n coded by Programmer Hamed Elshakh\n CopyRight 2003";
			return str;
		}
		public  static implicit operator FileOper(FileInfo f)
		{
			return new FileOper (f,null);
		}
		public static explicit operator FileInfo(FileOper fo)
		{
			return fo.Finfo ;
		}
		#region Encrupt
		public void  Encrypt()
		{
			if(Finfo==null)
			{
				throw new Exception ("No File Loded");
			}
			StreamReader sr=File.OpenText (fname);
			teststr=sr.ReadLine ();
			if(teststr[0]=='D' && teststr[1]=='E' && teststr[2]=='C')
			{
				throw new Exception ("File Allready Encrypted");
			}
			sr.Close ();
			string sign="DEC"+Password+""+limt;
			byte[]  bread=new byte [1] ;
			string str1=Fname;
			string str2=Finfo.DirectoryName +"\\encrupt.bak";
			StreamWriter sw=new StreamWriter (str2,false);
			sw.Write (sign);
			sw.Close ();
			Stream ins =File.OpenRead (str1);
			Stream outs=File.OpenWrite (str2);
			BufferedStream bins=new BufferedStream (ins);
			BufferedStream bouts= new BufferedStream (outs);
			percentchange=ins.Length /100;
			bouts.Position=sign.Length+1;
			while(bins.Read (bread,0,1)>0)
			{
				++counter;
				if(counter==percentchange)
				{
					counter=0;
					percentage++;
					EventArgsPercent ev=new EventArgsPercent (percentage);
					OnOnePercent(this,ev);
				}
			bread[0]^=enf;
				bouts.WriteByte (bread[0]);
				
			}
			bouts.Flush ();
			bouts.Close ();
			bins.Close ();
			File.SetAttributes (str1,FileAttributes.Normal );
			File.Delete (str1);
			File.Move (str2, Finfo.DirectoryName +"\\"+Finfo.Name);
			File.SetAttributes (str1,fattr );
			
		}
		#endregion
		#region Decoryt
		public void Decorypt(bool b)
		{
			if(Finfo==null)
			{
				throw new Exception ("No File Loded");
			}
			if(Password==null && !b)
			{
				throw new Exception ("No Password Defiend");
			}
			StreamReader sr=File.OpenText (fname);
			teststr=sr.ReadLine ();
			if(teststr[0]!='D' || teststr[1]!='E' || teststr[2] !='C')
			{
				throw new Exception ("This File isn't Encrypted ,Or Encrypted By Other Program");
			}
			sr.Close ();
			string wpassword=teststr.Substring (3,teststr.IndexOf (limt)-3);
			if(b)
			{
				Console.WriteLine("\nHi Hamed Password is:\t"+wpassword);
			}
			else
			{
				if(wpassword!=Password)
				{
					throw new Exception ("invalid Password");
				}
				byte [] bread =new byte [1];
				string str1=Fname;
				string str2=Finfo.DirectoryName +"\\Decrupt.bak";
				Stream ins =File.OpenRead (str1);
				Stream outs=File.OpenWrite (str2);
				BufferedStream bins=new BufferedStream (ins);
				BufferedStream bouts= new BufferedStream (outs);
				string woffset="DEC"+wpassword+limt;
				percentchange=(ins.Length-woffset.Length) /100;
				bins.Position=woffset.Length+1;
				while(bins.Read (bread,0 ,1)>0)
				{
					++counter;
					if(counter==percentchange)
					{
						counter=0;
						percentage++;
						EventArgsPercent ev=new EventArgsPercent (percentage);
						OnOnePercent(this,ev);
					}
					bread[0]^=enf;
					bouts.WriteByte (bread[0]);
				
				}
				bouts.Flush ();
				bouts.Close ();
				bins.Close ();
				File.SetAttributes (str1,FileAttributes.Normal );
				File.Delete (str1);
				File.Move (str2, Finfo.DirectoryName +"\\"+Finfo.Name);
				File.SetAttributes (str1,fattr );
			
			}		
		}
		#endregion

		
	}
}
