File Encrption, Decrption using password v1.0

Test.exe the main program.

FileOper.dll helper dll

FileOper.cs source code for dll
class1.cs   source code for exe

Note: You must install .Net Platform frist

for morinfo send me Email at

IMAR221@hotmail.com

Thanks.....................
