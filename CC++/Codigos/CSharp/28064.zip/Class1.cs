using System;
using FileOperation;
namespace Test
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Test
	{
		bool AdminLogIn=false;
		DateTime dt;
		string option=null;
		public string Option
		{
			get
			{
				return option;
			}
			set
			{
				switch(value)
				{
					case "/d":
					case"/e":
						option=value;
						break;
					default:
						Console.WriteLine ("\nInvaid Option "+value+" it must be /d or /e \n");
						throw new Exception ();
				}
			}
		}
		
		public override string ToString()
		{
			string str="\t\t\t\t\t\t\t\t\t\t\t\tEncryption ,Decoryption Program\n\t\tWriten by Programmer Hamed Elshakh\n\t\tCopyRight 2003";
				return str;
		}

		[STAThread]
		static void Main(string[] args)
		{	
			
			string fname=null;
			string password=null;
			string useage="\nUseage Test [/d][/e][/p:Password] File name\n\n/d\tDecorypt files allready encrypted by this program\n\n/e\tEncrypt files\n\n/p:\tEnter Password to Encrypt or Decorypt\n\n/?\tShow this help screen\n\n";
			Test t=new Test ();
		Console.WriteLine (t.ToString ())	;
			try
			{
				if(args.Length ==0)
				{
					throw new Exception ();
				}
				else if(args.Length ==2)
				{
					for(int i=0;i<2;++i)
					{
						if(args[i]=="/Admin")
						{
							
							t.AdminLogIn=true;
						}
						else if(args[i][0]!='/')
							fname=args[i];
					}
				}
				else
				{
					for(int i=0; i<args.Length ;++i)
					{
						if(args[i][0]!='/')
							fname=args[i];
						else if(args[i][0]=='/'&& args[i][1]=='p' && args[i][2]==':')
							password=args[i].Substring (3);
						else if(args[i][0]=='/'&&(args[i][1]=='d'||args[i][1]=='e'))
						{
							if(t.Option  !=null)
							{
								Console.WriteLine ("\nYou can choose either encrypt or decorypt\n");
								throw new Exception ();
							}
							t.Option =args[i];
						}
						else
 
							throw new Exception (); 
						
					}
				}
					if(fname==null)
					{
						Console.WriteLine ("\nEnter file name");
						throw new Exception ();
					}
					else if(password ==null && !t.AdminLogIn)
					{
						Console.WriteLine ("\nEnter password");
						throw new Exception ();
					}
					else if(t.Option==null && !t.AdminLogIn)
					{
						Console.WriteLine ("\nEnter Option");
						throw new Exception ();
					}
					else
					t.Run(fname,password);
					
				}
			
			catch
			{
								
				Console.WriteLine (useage);
			}
				
		
		}
		void Run(string fn,string pass)
		{
			try
			{
				
				FileOper fo=new FileOper (fn,pass);
				if(AdminLogIn)
				{
					fo.Decorypt (AdminLogIn);
				}
				else
				{
					fo.OnOnePercent +=new FileOper.OnePercentChange (PercentChange);
					Console.WriteLine ("");
					switch(Option)
					{
						case "/d":
							fo.Decorypt (AdminLogIn);
							break;
						case "/e":
							fo.Encrypt ();
							break;
						default:
							throw new Exception ("unexpected error");
					}


				}
			}
			catch(Exception e)
			{
				Console.WriteLine ("\n"+e.Message+"\n"); 
			}
		}
		void PercentChange(object o,FileOperation.EventArgsPercent  ev)
		{
			int ms,s,m,h;
			Console.Write ("\rProgress:\t"+ev.Percent+"%" );
			if(ev.Percent ==1)
			{
				dt=DateTime.Now ;
			}
			
			else if(ev.Percent ==100)
			{
				DateTime dte=DateTime.Now ;
				FileOper fo=(FileOper)o;
				ms=dte.Millisecond ;
				s=dte.Second ;
				h=dte.Hour ;
				m=dte.Minute ;
				if(dte.Millisecond <dt.Millisecond )
				{
					ms=dte.Millisecond +1000;
					s=dte.Second -1;
				}
				if(dte.Second <dt.Second )
				{
					s+=60;
					m=dte.Minute -1;
				}
				ms-=dt.Millisecond ;
				m-=dt.Minute ;
				s-=dt.Second ;
				h-=dt.Hour ;
				Console.WriteLine ("\n\nTime Elapsed :\t{0:D2}:{1:D2}:{2:D2}:{3:D3}",h,m,s,ms );
                Console.WriteLine ("\nFile name:\t"+fo.Finfo.FullName+"\n\nFile Attribute:\t"+fo.Finfo .Attributes+"\n\nFile size:\t"+fo.Finfo .Length/1024+" KB");
			}
			
		}
	}

}
