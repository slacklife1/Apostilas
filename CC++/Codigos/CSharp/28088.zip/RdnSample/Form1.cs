using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Rdn;
using Rdn.Basis;
using Rdn.Maps;
using RdnShaders;

namespace RdnSample
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.NumericUpDown numericUpDown2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.NumericUpDown numericUpDown1;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.RadioButton radioButton3;
		private System.Windows.Forms.RadioButton radioButton2;
		private System.Windows.Forms.RadioButton radioButton1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private Bitmap bitmap;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Button button6;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.label1 = new System.Windows.Forms.Label();
			this.radioButton3 = new System.Windows.Forms.RadioButton();
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label11 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.button5 = new System.Windows.Forms.Button();
			this.button6 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(320, 240);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
			// 
			// checkBox2
			// 
			this.checkBox2.Location = new System.Drawing.Point(144, 288);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new System.Drawing.Size(72, 24);
			this.checkBox2.TabIndex = 21;
			this.checkBox2.Text = "Shadows";
			// 
			// numericUpDown2
			// 
			this.numericUpDown2.Location = new System.Drawing.Point(96, 312);
			this.numericUpDown2.Maximum = new System.Decimal(new int[] {
																		   5,
																		   0,
																		   0,
																		   0});
			this.numericUpDown2.Minimum = new System.Decimal(new int[] {
																		   1,
																		   0,
																		   0,
																		   0});
			this.numericUpDown2.Name = "numericUpDown2";
			this.numericUpDown2.Size = new System.Drawing.Size(40, 20);
			this.numericUpDown2.TabIndex = 20;
			this.numericUpDown2.Value = new System.Decimal(new int[] {
																		 2,
																		 0,
																		 0,
																		 0});
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 312);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(96, 24);
			this.label3.TabIndex = 19;
			this.label3.Text = "Camera Position:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(0, 288);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(88, 16);
			this.label2.TabIndex = 18;
			this.label2.Text = "ShadingRate:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// numericUpDown1
			// 
			this.numericUpDown1.Location = new System.Drawing.Point(88, 288);
			this.numericUpDown1.Minimum = new System.Decimal(new int[] {
																		   1,
																		   0,
																		   0,
																		   0});
			this.numericUpDown1.Name = "numericUpDown1";
			this.numericUpDown1.Size = new System.Drawing.Size(48, 20);
			this.numericUpDown1.TabIndex = 17;
			this.numericUpDown1.Value = new System.Decimal(new int[] {
																		 5,
																		 0,
																		 0,
																		 0});
			// 
			// checkBox1
			// 
			this.checkBox1.Location = new System.Drawing.Point(144, 312);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(96, 24);
			this.checkBox1.TabIndex = 16;
			this.checkBox1.Text = "DepthOfField";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 256);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(56, 24);
			this.label1.TabIndex = 15;
			this.label1.Text = "Sampling:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// radioButton3
			// 
			this.radioButton3.Location = new System.Drawing.Point(176, 256);
			this.radioButton3.Name = "radioButton3";
			this.radioButton3.Size = new System.Drawing.Size(48, 24);
			this.radioButton3.TabIndex = 14;
			this.radioButton3.Text = "4x4";
			// 
			// radioButton2
			// 
			this.radioButton2.Location = new System.Drawing.Point(128, 256);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.Size = new System.Drawing.Size(48, 24);
			this.radioButton2.TabIndex = 13;
			this.radioButton2.Text = "2x2";
			// 
			// radioButton1
			// 
			this.radioButton1.Checked = true;
			this.radioButton1.Location = new System.Drawing.Point(72, 256);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.Size = new System.Drawing.Size(56, 24);
			this.radioButton1.TabIndex = 12;
			this.radioButton1.TabStop = true;
			this.radioButton1.Text = "None";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(336, 256);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(96, 32);
			this.button1.TabIndex = 22;
			this.button1.Text = "Scene1";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(440, 256);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(96, 32);
			this.button2.TabIndex = 23;
			this.button2.Text = "Scene2";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(336, 296);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(96, 40);
			this.button3.TabIndex = 24;
			this.button3.Text = "Scene3";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(232, 296);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(96, 40);
			this.button4.TabIndex = 25;
			this.button4.Text = "Save";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label4.Location = new System.Drawing.Point(8, 216);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(184, 24);
			this.label4.TabIndex = 26;
			this.label4.Text = "Render Time:";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.label11,
																					this.label10,
																					this.label9,
																					this.label8,
																					this.label7,
																					this.label6,
																					this.label5,
																					this.label4,
																					this.label12});
			this.groupBox1.Location = new System.Drawing.Point(336, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(200, 248);
			this.groupBox1.TabIndex = 27;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Render Status";
			// 
			// label11
			// 
			this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label11.Location = new System.Drawing.Point(8, 192);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(184, 24);
			this.label11.TabIndex = 33;
			this.label11.Text = "Build Time:";
			// 
			// label10
			// 
			this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label10.Location = new System.Drawing.Point(8, 168);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(184, 24);
			this.label10.TabIndex = 32;
			this.label10.Text = "Trace Rays:";
			// 
			// label9
			// 
			this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label9.Location = new System.Drawing.Point(8, 120);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(184, 24);
			this.label9.TabIndex = 31;
			this.label9.Text = "Reyes MP:";
			// 
			// label8
			// 
			this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label8.Location = new System.Drawing.Point(8, 24);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(184, 24);
			this.label8.TabIndex = 30;
			this.label8.Text = "Scene:";
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label7.Location = new System.Drawing.Point(8, 72);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(184, 24);
			this.label7.TabIndex = 29;
			this.label7.Text = "Particles:";
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.Location = new System.Drawing.Point(8, 96);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(184, 24);
			this.label6.TabIndex = 28;
			this.label6.Text = "Primitives:";
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.Location = new System.Drawing.Point(8, 48);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(184, 24);
			this.label5.TabIndex = 27;
			this.label5.Text = "LightSources:";
			// 
			// label12
			// 
			this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label12.Location = new System.Drawing.Point(8, 144);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(184, 24);
			this.label12.TabIndex = 34;
			this.label12.Text = "Trace MP:";
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(232, 256);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(96, 32);
			this.button5.TabIndex = 28;
			this.button5.Text = "About...";
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(440, 296);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(96, 40);
			this.button6.TabIndex = 29;
			this.button6.Text = "Scene4";
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(546, 344);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button6,
																		  this.button5,
																		  this.groupBox1,
																		  this.button4,
																		  this.button3,
																		  this.button2,
																		  this.button1,
																		  this.checkBox2,
																		  this.numericUpDown2,
																		  this.label3,
																		  this.label2,
																		  this.numericUpDown1,
																		  this.checkBox1,
																		  this.label1,
																		  this.radioButton3,
																		  this.radioButton2,
																		  this.radioButton1,
																		  this.pictureBox1});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "RdnSample";
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void pictureBox1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
//			RdnMesh mesh=new RdnMesh("mesh.mff");
//			
//			for(int i=0;i<4;i++)
//				for(int j=0;j<4;j++)
//					e.Graphics.DrawString(mesh.Transform[i,j].ToString(),new Font("Arial",8),Brushes.Black,i*10,j*10);

			if(bitmap!=null)
				e.Graphics.DrawImage(bitmap,0,0);
		}
		
		private void button1_Click(object sender, System.EventArgs e)
		{
			RdnRender rdn=new RdnRender();

			RdnTextureMap texture1=RdnTextureMap.FromBitmap(new Bitmap("img1.jpg"));
			RdnTextureMap texture2=RdnTextureMap.FromBitmap(new Bitmap("img2.jpg"));
			RdnTextureMap texture3=RdnTextureMap.FromBitmap(new Bitmap("img3.jpg"));

			RdnDisplace displace1=new RdnDisplace(0.25f);
			displace1.TextureMap=texture1;
			RdnDisplace displace2=new RdnDisplace(0.5f);
			displace2.TextureMap=texture2;
			RdnDisplace displace3=new RdnDisplace(1f);
			displace3.TextureMap=texture3;
			
			RdnMaterial material1=new RdnMaterial(new RdnColor(0f),new RdnColor(1f),new RdnColor(0f),new RdnColor(1f),0f);
			material1.TextureMap=texture1;
			RdnMaterial material2=new RdnMaterial(new RdnColor(0f),new RdnColor(1f),new RdnColor(1f),new RdnColor(1f),0.01f);
			material2.TextureMap=texture2;
			RdnMaterial material3=new RdnMaterial(new RdnColor(0f),new RdnColor(1f),new RdnColor(0.5f),new RdnColor(1f),0.02f);
			material3.TextureMap=texture3;

			RdnLight light1=new RdnLight(new RdnVector(0f,0f,0f),new RdnColor(1.25f),new RdnColor(0.25f),new RdnVector(0f,0f,0f),(float)Math.PI/5f,(float)Math.PI/3f,1f);
			if(checkBox2.Checked)
				light1.Render=rdn;
			RdnLight light2=new RdnLight(new RdnVector(0f,0f,0f),new RdnColor(1f),new RdnColor(0.25f),new RdnVector(0f,0f,0f),0f,0f,0f);
			if(checkBox2.Checked)
				light2.Render=rdn;

			rdn.FrameBegin(0);
				rdn.Format(320,240,1f);
				if(radioButton1.Checked)
					rdn.Sampling(1,1);
				if(radioButton2.Checked)
					rdn.Sampling(2,2);
				if(radioButton3.Checked)
					rdn.Sampling(4,4);
				rdn.View(new RdnVector(50,75,-150)*((float)numericUpDown2.Value/2),new RdnVector(-10,10,0),new RdnVector(0f,1f,0f),0f);
				rdn.FieldOfView(1f,1f,1f,1000f,true);
				if(checkBox1.Checked)
					rdn.DepthOfField(33f,125f*((float)numericUpDown2.Value/2),145f*((float)numericUpDown2.Value/2),0,8);
				rdn.WorldBegin();
					rdn.Attenuation(new RdnColor(0f),new RdnColor(0.001f),new RdnColor(1f));
					rdn.TransformBegin();
						rdn.Translate(100f,50f,-100f);
						rdn.LightSource(light1);
					rdn.TransformEnd();
					rdn.TransformBegin();
						rdn.Translate(-50f,55f,50f);
						rdn.LightSource(light2);
					rdn.TransformEnd();
					rdn.Options(16,4,3,(float)numericUpDown1.Value);
					rdn.Illuminate(true);
					rdn.Color(new RdnColor(1f,1f,1f));
					rdn.Sides(true);
					rdn.Displacement(displace2);
					rdn.Surface(material2);
					rdn.TransformBegin();
						rdn.RotateX(-(float)Math.PI);
						rdn.TextureCoordinates(0f,0f,0f,4f,4f,4f,4f,0f);
						rdn.Primitive(new RdnPlane(100f,0f,100f,0f));
					rdn.TransformEnd();
					rdn.Displacement(displace1);
					rdn.Surface(material1);
					rdn.TransformBegin();
						rdn.Translate(0,25,50);
						rdn.RotateX(-(float)Math.PI);
						rdn.RotateZ(-(float)Math.PI/2f);
						rdn.TextureCoordinates(0f,0f,0f,2f,1f,2f,1f,0f);
						rdn.Primitive(new RdnPlane(50f,100f,0f,0f));
					rdn.TransformEnd();
					rdn.TransformBegin();
						rdn.Translate(-50,25,0);
						rdn.TextureCoordinates(0f,0f,0f,2f,1f,2f,1f,0f);
						rdn.Primitive(new RdnPlane(0f,50f,100f,0f));
					rdn.TransformEnd();
					rdn.Options(16,64,3,(float)numericUpDown1.Value);
					rdn.Displacement(displace3);
					rdn.Surface(material3);
					rdn.TextureCoordinates(0f,0f,0f,1f,1f,1f,1f,0f);
					rdn.TransformBegin();
						rdn.Translate(0,10,0);
						rdn.TransformBegin();
							rdn.Translate(-20,0,-20);
							rdn.Primitive(new RdnSphere(10f,-10,10,6.28f));
						rdn.TransformEnd();
						rdn.TransformBegin();
							rdn.Translate(-20,-10,20);
							rdn.RotateX(-(float)Math.PI/2f);
							rdn.Primitive(new RdnCone(20,10,6.28f));
						rdn.TransformEnd();
						rdn.TransformBegin();
							rdn.Translate(20,0,20);
							rdn.RotateX(-(float)Math.PI/2f);
							rdn.Primitive(new RdnCylinder(10f,-10,10,6.28f));
						rdn.TransformEnd();
						rdn.TransformBegin();
							rdn.Translate(20,0,-20);
							rdn.RotateX(-(float)Math.PI/2f);
//							rdn.ClippingPlanes(new RdnClippingPlane[2]{new RdnClippingPlane(new RdnVector(-5,0,0),new RdnVector(-1,0,0)),new RdnClippingPlane(new RdnVector(5,0,0),new RdnVector(1,0,0))},true);
							rdn.Primitive(new RdnTorus(10,5,0,6.28f,6.28f));
						rdn.TransformEnd();
					rdn.TransformEnd();
				rdn.WorldEnd();
			rdn.FrameEnd();

			RdnRasterState rasterstate=rdn.Raster();
			label8.Text="Scene: Scene1";
			label5.Text="LightSources: "+rasterstate.LightSources;
			label7.Text="Particles: "+rasterstate.Particles;
			label6.Text="Primitives: "+rasterstate.Primitives;
			label9.Text="Reyes MP: "+rasterstate.ReyesMicroPolygons;
			label12.Text="Trace MP: "+rasterstate.TraceMicroPolygons;
			label10.Text="Trace Rays: "+rasterstate.TraceRays;
			label11.Text="Build Time: "+rasterstate.BuildTime;
			label4.Text="Render Time: "+rasterstate.RenderTime;
			bitmap=rasterstate.Image;

			pictureBox1.Invalidate();
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			RdnRender rdn=new RdnRender();

			RdnTextureMap texture1=RdnTextureMap.FromBitmap(new Bitmap("img3.jpg"));

			RdnDisplace displace1=new RdnDisplace(1f);
			displace1.TextureMap=texture1;
			
			RdnMaterial material1=new RdnMaterial(new RdnColor(0f),new RdnColor(0.1f),new RdnColor(1f),new RdnColor(1f),new RdnColor(0.9f),new RdnColor(0f),new RdnColor(0),0.02f,0f,0);
			material1.Render=rdn;
			RdnMaterial material2=new RdnMaterial(new RdnColor(0f),new RdnColor(1f),new RdnColor(0.75f),new RdnColor(1f),0.01f);
			material2.TextureMap=texture1;

			RdnLight light1=new RdnLight(new RdnVector(0f,0f,0f),new RdnColor(1.25f),new RdnColor(0.5f),new RdnVector(0f,0f,0f),(float)Math.PI/7f,(float)Math.PI/6f,1f);
			if(checkBox2.Checked)
				light1.Render=rdn;

			RdnBackGround imager=new RdnBackGround(new RdnColor(0.2f,0.5f,0.8f),new RdnColor(1f),1f);
//			imager.TextureMap=RdnTextureMap.FromBitmap(new Bitmap("img0.jpg"));

			rdn.FrameBegin(0);
				rdn.Format(320,240,1f);
				if(radioButton1.Checked)
					rdn.Sampling(1,1);
				if(radioButton2.Checked)
					rdn.Sampling(2,2);
				if(radioButton3.Checked)
					rdn.Sampling(4,4);
				rdn.View(new RdnVector(40,80,-120)*((float)numericUpDown2.Value/2),new RdnVector(0,0,0),new RdnVector(0f,1f,0f),0f);
				rdn.FieldOfView(1f,1f,1f,1000f,true);
				if(checkBox1.Checked)
					rdn.DepthOfField(33f,125f*((float)numericUpDown2.Value/2),145f*((float)numericUpDown2.Value/2),0,8);
				rdn.Imager(imager);
				rdn.WorldBegin();
					rdn.Attenuation(new RdnColor(0f),new RdnColor(0.0025f),new RdnColor(0.5f));
//					rdn.Atmosphere(new RdnFog(0f,0.25f,new RdnColor(0.2f,0.5f,0.8f)));
					rdn.TransformBegin();
						rdn.Translate(100f,150f,-100f);
						rdn.LightSource(light1);
					rdn.TransformEnd();
					rdn.Options(16,4,3,(float)numericUpDown1.Value);
					rdn.Illuminate(true);
					rdn.Surface(material1);
					rdn.TransformBegin();
						rdn.RotateX(-(float)Math.PI);
						rdn.Primitive(new RdnPlane(150f,0f,150f,0f));
					rdn.TransformEnd();
					rdn.Displacement(displace1);
					rdn.Surface(material2);
					rdn.Options(16,64,3,(float)numericUpDown1.Value);
					rdn.TransformBegin();
						rdn.Translate(0f,16f,0f);
						rdn.Scale(1.5f);
						rdn.Primitive(new RdnSphere(10f,-10,10,6.28f));
//						float sx=10f,sy=10f,sz=10f;
//						rdn.Primitive(new RdnPolygon(new RdnVector(-sx,-sy,-sz),new RdnVector(sx,-sy,-sz),new RdnVector(sx,sy,-sz),new RdnVector(-sx,sy,-sz)));
//						rdn.Primitive(new RdnPolygon(new RdnVector(-sx,-sy,sz),new RdnVector(-sx,sy,sz),new RdnVector(sx,sy,sz),new RdnVector(sx,-sy,sz)));
//						rdn.Primitive(new RdnPolygon(new RdnVector(-sx,-sy,-sz),new RdnVector(-sx,sy,-sz),new RdnVector(-sx,sy,sz),new RdnVector(-sx,-sy,sz)));
//						rdn.Primitive(new RdnPolygon(new RdnVector(sx,-sy,-sz),new RdnVector(sx,-sy,sz),new RdnVector(sx,sy,sz),new RdnVector(sx,sy,-sz)));
//						rdn.Primitive(new RdnPolygon(new RdnVector(-sx,-sy,-sz),new RdnVector(-sx,-sy,sz),new RdnVector(sx,-sy,sz),new RdnVector(sx,-sy,-sz)));
//						rdn.Primitive(new RdnPolygon(new RdnVector(-sx,sy,-sz),new RdnVector(sx,sy,-sz),new RdnVector(sx,sy,sz),new RdnVector(-sx,sy,sz)));
					rdn.TransformEnd();
				rdn.WorldEnd();
			rdn.FrameEnd();

			RdnRasterState rasterstate=rdn.Raster();

			label8.Text="Scene: Scene2";
			label5.Text="LightSources: "+rasterstate.LightSources;
			label7.Text="Particles: "+rasterstate.Particles;
			label6.Text="Primitives: "+rasterstate.Primitives;
			label9.Text="Reyes MP: "+rasterstate.ReyesMicroPolygons;
			label12.Text="Trace MP: "+rasterstate.TraceMicroPolygons;
			label10.Text="Trace Rays: "+rasterstate.TraceRays;
			label11.Text="Build Time: "+rasterstate.BuildTime;
			label4.Text="Render Time: "+rasterstate.RenderTime;
			bitmap=rasterstate.Image;

//			bitmap=new Bitmap(320,240);
//			for(int x=0;x<320;x++)
//			{
//				for(int y=0;y<240;y++)
//				{
//					RdnRay r=RdnRay.FromProjection(x,y,320,240,new RdnVector(40,80,-120)*1f,new RdnVector(0,0,0),new RdnVector(0,1,0),45f);
//					RdnTraceState tracestate=rdn.Trace(r,5);
//					bitmap.SetPixel(x,y,tracestate.Color.Clamped.ToColor());
//				}
//			}

			pictureBox1.Invalidate();
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			RdnRender rdn=new RdnRender();

			RdnMaterial material1=new RdnMaterial(new RdnColor(0f),new RdnColor(1f),new RdnColor(0f),new RdnColor(1f),0f);//,new RdnColor(0f),new RdnColor(0f),new RdnColor(0.25f),0f,0f,4);
			RdnMaterial material2=new RdnMaterial(new RdnColor(0f),new RdnColor(1f,0.7f,0.7f),new RdnColor(0f),new RdnColor(1f),0f);//,new RdnColor(0f),new RdnColor(0f),new RdnColor(0.25f),0f,0f,4);
			RdnMaterial material3=new RdnMaterial(new RdnColor(0f),new RdnColor(0.7f,0.7f,1f),new RdnColor(0f),new RdnColor(1f),0f);//,new RdnColor(0f),new RdnColor(0f),new RdnColor(0.25f),0f,0f,4);
			RdnMaterial material4=new RdnMaterial(new RdnColor(0f),new RdnColor(0f),new RdnColor(1f),new RdnColor(1f),new RdnColor(1f),new RdnColor(0f),new RdnColor(0),0.02f,0f,0);
			RdnMaterial material5=new RdnMaterial(new RdnColor(0f),new RdnColor(0f),new RdnColor(1f),new RdnColor(1f),new RdnColor(0f),new RdnColor(1f),new RdnColor(0),0.01f,1.5f,0);

			material1.Render=material2.Render=material3.Render=rdn;
			material4.Render=material5.Render=rdn;

			RdnLight light1=new RdnLight(new RdnVector(0f,0f,0f),new RdnColor(1f,1f,1f),new RdnColor(0.25f),new RdnVector(0f,0f,0f),0f,0f,0f);
			if(checkBox2.Checked)
				light1.Render=rdn;

			rdn.FrameBegin(0);
				rdn.Format(320,240,1f);
				if(radioButton1.Checked)
					rdn.Sampling(1,1);
				if(radioButton2.Checked)
					rdn.Sampling(2,2);
				if(radioButton3.Checked)
					rdn.Sampling(4,4);
				rdn.View(new RdnVector(0f,25f,-100f*((float)numericUpDown2.Value/2)),new RdnVector(0,25,2000),new RdnVector(0f,1f,0f),0f);
				rdn.FieldOfView(1f,1f,1f,1000f,true);
				if(checkBox1.Checked)
					rdn.DepthOfField(33f,125f*((float)numericUpDown2.Value/2),145f*((float)numericUpDown2.Value/2),0,8);
				rdn.WorldBegin();
					rdn.Attenuation(new RdnColor(0.0001f),new RdnColor(0.01f),new RdnColor(1f));
					rdn.TransformBegin();
						rdn.Translate(0f,45f,0f);
						rdn.LightSource(light1);
					rdn.TransformEnd();
					rdn.Options(16,4,5,(float)numericUpDown1.Value);
					rdn.Illuminate(true);
					rdn.Sides(true);
					rdn.Surface(material1);
					rdn.TransformBegin();
						rdn.RotateX(-(float)Math.PI);
						rdn.Primitive(new RdnPlane(80f,0f,100f,0f));
					rdn.TransformEnd();
					rdn.TransformBegin();
						rdn.Translate(0f,25f,50f);
						rdn.RotateY(-(float)Math.PI);
						rdn.Primitive(new RdnPlane(80f,50f,0f,0f));
					rdn.TransformEnd();
					rdn.TransformBegin();
						rdn.Translate(0f,50f,0f);
						rdn.Primitive(new RdnPlane(80f,0f,100f,0f));
					rdn.TransformEnd();
					rdn.Surface(material2);
					rdn.TransformBegin();
						rdn.Translate(-40f,25f,0f);
						rdn.Primitive(new RdnPlane(0f,50f,100f,0f));
					rdn.TransformEnd();
					rdn.Surface(material3);
					rdn.TransformBegin();
						rdn.Translate(40f,25f,0f);
						rdn.RotateY(-(float)Math.PI);
						rdn.Primitive(new RdnPlane(0f,50f,100f,0f));
					rdn.TransformEnd();
					rdn.Options(16,64,5,(float)numericUpDown1.Value);
					rdn.Surface(material4);
					rdn.TransformBegin();
						rdn.Translate(-15f,10f,10f);
						rdn.Primitive(new RdnSphere(10f,-10,10,6.28f));
					rdn.TransformEnd();
					rdn.Surface(material5);
					rdn.TransformBegin();
						rdn.Translate(15f,10f,-10f);
						rdn.Primitive(new RdnSphere(10f,-10,10,6.28f));
					rdn.TransformEnd();
				rdn.WorldEnd();
			rdn.FrameEnd();

			RdnRasterState rasterstate=rdn.Raster();
			label8.Text="Scene: Scene3";
			label5.Text="LightSources: "+rasterstate.LightSources;
			label7.Text="Particles: "+rasterstate.Particles;
			label6.Text="Primitives: "+rasterstate.Primitives;
			label9.Text="Reyes MP: "+rasterstate.ReyesMicroPolygons;
			label12.Text="Trace MP: "+rasterstate.TraceMicroPolygons;
			label10.Text="Trace Rays: "+rasterstate.TraceRays;
			label11.Text="Build Time: "+rasterstate.BuildTime+"s";
			label4.Text="Render Time: "+rasterstate.RenderTime+"s";
			bitmap=rasterstate.Image;

			pictureBox1.Invalidate();
		}

		private void button6_Click(object sender, System.EventArgs e)
		{
			RdnRender rdn=new RdnRender();

			RdnTextureMap texture1=RdnTextureMap.FromBitmap(new Bitmap("img1.jpg"));
			RdnTextureMap texture2=RdnTextureMap.FromBitmap(new Bitmap("img3.jpg"));

			RdnDisplace displace1=new RdnDisplace(1f);
			displace1.TextureMap=texture1;
			
			RdnDisplace displace2=new RdnDisplace(1f);
			displace2.TextureMap=texture2;
			
			RdnMaterial material1=new RdnMaterial(new RdnColor(0f),new RdnColor(1f),new RdnColor(0f),new RdnColor(1f),0f);
			material1.TextureMap=texture1;
			RdnMaterial material2=new RdnMaterial(new RdnColor(0f),new RdnColor(1f),new RdnColor(0.75f),new RdnColor(1f),0.01f);
			material2.TextureMap=texture2;
			RdnMaterial material3=new RdnMaterial(new RdnColor(0f),new RdnColor(0.1f),new RdnColor(1f),new RdnColor(1f),new RdnColor(0.9f),new RdnColor(0f),new RdnColor(0),0.02f,0f,0);
			material3.Render=rdn;

			RdnLight light1=new RdnLight(new RdnVector(-250f,-250f,250f),new RdnColor(1.25f),new RdnColor(0.5f),new RdnVector(0f,0f,0f),0,0,0f);
			if(checkBox2.Checked)
				light1.Render=rdn;

			rdn.FrameBegin(0);
				rdn.Format(320,240,1f);
				if(radioButton1.Checked)
					rdn.Sampling(1,1);
				if(radioButton2.Checked)
					rdn.Sampling(2,2);
				if(radioButton3.Checked)
					rdn.Sampling(4,4);
				rdn.View(new RdnVector(40,80,-120)*((float)numericUpDown2.Value/2),new RdnVector(0,0,0),new RdnVector(0f,1f,0f),0f);
				rdn.FieldOfView(1f,1f,1f,1000f,true);
				if(checkBox1.Checked)
					rdn.DepthOfField(33f,125f*((float)numericUpDown2.Value/2),145f*((float)numericUpDown2.Value/2),0,8);
				rdn.Imager(new RdnBackGround(new RdnColor(0.2f,0.5f,0.8f),new RdnColor(1f),1f));
				rdn.WorldBegin();
//					rdn.Atmosphere(new RdnFog(0f,0.25f,new RdnColor(0.2f,0.5f,0.8f)));
					rdn.TransformBegin();
						rdn.Translate(250f,250f,-250f);
						rdn.LightSource(light1);
					rdn.TransformEnd();
					rdn.Options(16,4,3,(float)numericUpDown1.Value);
					rdn.Illuminate(true);
					rdn.Displacement(displace1);
					rdn.Surface(material1);
					rdn.TransformBegin();
						rdn.RotateX(-(float)Math.PI);
						rdn.TextureCoordinates(0f,0f,0f,2f,2f,2f,2f,0f);
						rdn.Primitive(new RdnPlane(250f,0f,250f,0f));
					rdn.TransformEnd();
					rdn.Options(16,64,3,(float)numericUpDown1.Value);
					rdn.TextureCoordinates(0f,0f,0f,1f,1f,1f,1f,0f);
					rdn.Displacement(null);
					rdn.Surface(material3);
					rdn.TransformBegin();
						rdn.Translate(-25f,21f,25f);
						rdn.Scale(2f);
						rdn.Primitive(new RdnSphere(10f,-10,10,6.28f));
					rdn.TransformEnd();
					rdn.TransformBegin();
						rdn.Translate(25f,21f,25f);
						rdn.Scale(2f);
						rdn.Primitive(new RdnSphere(10f,-10,10,6.28f));
					rdn.TransformEnd();
					rdn.Displacement(displace2);
					rdn.Surface(material2);
//					rdn.ClippingPlanes(new RdnClippingPlane[1]{new RdnClippingPlane(new RdnVector(0,0,0),new RdnVector(1,0,0))},false);
					rdn.TransformBegin();
						rdn.Translate(0f,1f,-25f);
						rdn.RotateZ((float)Math.PI/2f);
						rdn.Scale(1.5f);
						rdn.SurfaceCoordinates(0f,0f,0.5f,1f);
						rdn.Primitive(new RdnTorus(10,5,0,6.28f,6.28f));
					rdn.TransformEnd();
//					rdn.Options(4,4,3,(float)numericUpDown1.Value);
//					rdn.TransformBegin();
//						rdn.Translate(0f,0f,0f);
//						rdn.Scale(2f);
//						RdnMesh mesh=new RdnMesh();
//						mesh.Vertices=new RdnVertex[8];
//						mesh.Vertices[0].Point=new RdnVector(-10,-10,-10);
//						mesh.Vertices[0].Normal=new RdnVector(-1,-1,-1).Normalized;
//						mesh.Vertices[0].TexCoord=new PointF(0,0);
//						mesh.Vertices[1].Point=new RdnVector(-10,10,-10);
//						mesh.Vertices[1].Normal=new RdnVector(-1,1,-1).Normalized;
//						mesh.Vertices[1].TexCoord=new PointF(0,1);
//						mesh.Vertices[2].Point=new RdnVector(10,10,-10);
//						mesh.Vertices[2].Normal=new RdnVector(1,1,-1).Normalized;
//						mesh.Vertices[2].TexCoord=new PointF(1,1);
//						mesh.Vertices[3].Point=new RdnVector(10,-10,-10);
//						mesh.Vertices[3].Normal=new RdnVector(1,-1,-1).Normalized;
//						mesh.Vertices[3].TexCoord=new PointF(1,0);
//						mesh.Vertices[4].Point=new RdnVector(-10,-10,10);
//						mesh.Vertices[4].Normal=new RdnVector(-1,-1,1).Normalized;
//						mesh.Vertices[4].TexCoord=new PointF(1,0);
//						mesh.Vertices[5].Point=new RdnVector(-10,10,10);
//						mesh.Vertices[5].Normal=new RdnVector(-1,1,1).Normalized;
//						mesh.Vertices[5].TexCoord=new PointF(1,1);
//						mesh.Vertices[6].Point=new RdnVector(10,10,10);
//						mesh.Vertices[6].Normal=new RdnVector(1,1,1).Normalized;
//						mesh.Vertices[6].TexCoord=new PointF(0,1);
//						mesh.Vertices[7].Point=new RdnVector(10,-10,10);
//						mesh.Vertices[7].Normal=new RdnVector(1,-1,1).Normalized;
//						mesh.Vertices[7].TexCoord=new PointF(0,0);
//						mesh.Faces=new RdnFace[3];
//						mesh.Faces[0]=new RdnFace(2,6,5,1);
//						mesh.Faces[1]=new RdnFace(3,2,1,0);
//						mesh.Faces[2]=new RdnFace(3,7,6,2);
//						rdn.Mesh(mesh);
//					rdn.TransformEnd();
				rdn.WorldEnd();
			rdn.FrameEnd();

			RdnRasterState rasterstate=rdn.Raster();

			label8.Text="Scene: Scene4";
			label5.Text="LightSources: "+rasterstate.LightSources;
			label7.Text="Particles: "+rasterstate.Particles;
			label6.Text="Primitives: "+rasterstate.Primitives;
			label9.Text="Reyes MP: "+rasterstate.ReyesMicroPolygons;
			label12.Text="Trace MP: "+rasterstate.TraceMicroPolygons;
			label10.Text="Trace Rays: "+rasterstate.TraceRays;
			label11.Text="Build Time: "+rasterstate.BuildTime;
			label4.Text="Render Time: "+rasterstate.RenderTime;
			bitmap=rasterstate.Image;

			pictureBox1.Invalidate();
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
//			RdnMesh mesh=new RdnMesh();
//			mesh.Vertices=new RdnVertex[4];
//			mesh.Faces=new RdnFace[12];
//			mesh.Save("mesh.mff");
			
			if(bitmap!=null)
				bitmap.Save("Output.bmp");
		}

		private void button5_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("Developed (c) by Gustavo Arranhado","About...");
		}
	}
}
