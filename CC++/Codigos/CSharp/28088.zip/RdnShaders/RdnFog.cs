using System;
using Rdn;
using Rdn.Basis;

namespace RdnShaders
{
	/// <summary>
	/// Summary description for RdnFog.
	/// </summary>
	public class RdnFog : RdnShader
	{
		private float mindist,maxdist;
		private RdnColor color;

		public RdnFog(float mindist,float maxdist,RdnColor color)
		{
			this.mindist=mindist;
			this.maxdist=maxdist;
			this.color=color;
		}

		public override void VolumeProcess(ref RdnColor color,ref RdnColor opacity,float depth,RdnVector point,RdnRay eye,int frame)
		{
			float d=RdnMath.ClampWrap((depth-mindist)/(maxdist-mindist),0f,1f);
			color=RdnColor.FromBlend(color,this.color,d);
		}
	}
}
