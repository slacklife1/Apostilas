using System;
using Rdn;
using Rdn.Basis;

namespace RdnShaders
{
	/// <summary>
	/// Summary description for RdnPolygon.
	/// </summary>
	public class RdnPolygon : RdnShader
	{
		private RdnVector point00,point01,point11,point10;

		public RdnPolygon(RdnVector point00,RdnVector point01,RdnVector point11,RdnVector point10)
		{
			this.point00=point00;
			this.point01=point01;
			this.point11=point11;
			this.point10=point10;
		}
		
		public override void PrimitiveProcess(out RdnVector point,float u,float v)
		{
			point=point00*((1f-u)*(1f-v))+point01*((1f-u)*v)+point11*(u*v)+point10*(u*(1f-v));
		}
	}
}