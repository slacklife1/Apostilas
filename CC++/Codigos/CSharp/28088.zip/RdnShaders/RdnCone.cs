using System;
using Rdn;
using Rdn.Basis;

namespace RdnShaders
{
	/// <summary>
	/// Summary description for RdnCone.
	/// </summary>
	public class RdnCone : RdnShader
	{
		private float height,radius,thetamax;

		public RdnCone(float height,float radius,float thetamax)
		{
			this.height=height;
			this.radius=radius;
			this.thetamax=thetamax;
		}

		public override void PrimitiveProcess(out RdnVector point,float u,float v)
		{
			float t=u*thetamax;
			float tt=radius*(1f-v);
			point=new RdnVector(tt*(float)Math.Cos(t),tt*(float)Math.Sin(t),v*height);
		}
	}
}
