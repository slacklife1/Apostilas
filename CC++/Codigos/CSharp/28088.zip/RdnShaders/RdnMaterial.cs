using System;
using System.Collections;
using Rdn;
using Rdn.Basis;

namespace RdnShaders
{
	/// <summary>
	/// Summary description for RdnMaterial.
	/// </summary>
	public class RdnMaterial : RdnShader
	{
		private RdnColor ambient,diffuse,specular,opacity,reflection,refraction,gathering;
		private float shininess,refractionindex;
		private int gatheringsamples;
		private Random random=new Random();

		public RdnMaterial(RdnColor ambient,RdnColor diffuse,RdnColor specular,RdnColor opacity,RdnColor reflection,RdnColor refraction,RdnColor gathering,float shininess,float refractionindex,int gatheringsamples)
		{
			this.ambient=ambient;
			this.diffuse=diffuse;
			this.specular=specular;
			this.opacity=opacity;
			this.reflection=reflection;
			this.refraction=refraction;
			this.gathering=gathering;
			this.shininess=shininess;
			this.refractionindex=refractionindex;
			this.gatheringsamples=gatheringsamples;
		}
		public RdnMaterial(RdnColor ambient,RdnColor diffuse,RdnColor specular,RdnColor opacity,float shininess)
		{
			this.ambient=ambient;
			this.diffuse=diffuse;
			this.specular=specular;
			this.opacity=opacity;
			this.shininess=shininess;
		}

		public override void SurfaceProcess(ref RdnColor color,ref RdnColor opacity,RdnVector point,RdnVector dPdu,RdnVector dPdv,RdnVector normal,float u,float v,float du,float dv,float s,float t,RdnPhoton[] photons,RdnRay eye,int levels,int frame)
		{
			opacity=this.opacity;
			RdnColor dif=diffuse;
			if(TextureMap!=null)
				dif=diffuse*Texture(s,t,0,0f,true);
			RdnColor direct=new RdnColor(0f);
			RdnColor indirect=new RdnColor(0f);

			if(photons!=null)
				for(int i=0;i<photons.Length;i++)
					direct=direct+(photons[i].Energy*(dif*Diffuse(photons[i].Ray.Direction,normal)+specular*Specular(photons[i].Ray.Direction,eye.Direction,normal,shininess))).Clamped;
			
			RdnPhoton[] pho;
			LocateNearestGlobalPhotons(out pho,point,10f);
			if(pho!=null)
			{
				for(int i=0;i<pho.Length;i++)
					indirect=indirect+((pho[i].Energy)*(dif*Diffuse(pho[i].Ray.Direction,normal)+specular*Specular(pho[i].Ray.Direction,eye.Direction,normal,shininess))).Clamped;
				if(pho.Length>0)
					indirect=indirect/pho.Length;
			}
			LocateNearestCausticPhotons(out pho,point,2f);
			if(pho!=null)
			{
				for(int i=0;i<pho.Length;i++)
					indirect=indirect+((pho[i].Energy)*(dif*Diffuse(pho[i].Ray.Direction,normal)+specular*Specular(pho[i].Ray.Direction,eye.Direction,normal,shininess))).Clamped;
				if(pho.Length>0)
					indirect=indirect/pho.Length;
			}
			color=(ambient+direct+indirect.Clamped)*opacity;

			if(eye.Type!=RdnRayType.Gathering)
			{
				if(reflection!=new RdnColor(0f))
					color=color+reflection*Trace(new RdnRay(RdnRayType.Secondary,point,RdnVector.FromReflect(eye.Direction,normal)),levels).Color;
				if(refraction!=new RdnColor(0f))
				{
					if(eye.Direction*normal>0)
						color=color+refraction*Trace(new RdnRay(RdnRayType.Secondary,point,RdnVector.FromRefract(eye.Direction,normal.Inverted,refractionindex)),levels).Color;
					else
						color=color+refraction*Trace(new RdnRay(RdnRayType.Secondary,point,RdnVector.FromRefract(eye.Direction,normal,1f/refractionindex)),levels).Color;
				}
			}
			if(gathering!=new RdnColor(0f))
				color=color+gathering*Trace(new RdnRay(RdnRayType.Gathering,point,normal),levels,gatheringsamples,(float)(Math.PI/2.0),random).Color;
		}
		public override void SurfaceEmitterProcess(out RdnPhoton[] photons,RdnVector point,RdnVector dPdu,RdnVector dPdv,RdnVector normal,float u,float v,float du,float dv,float s,float t,RdnPhoton photon,int frame)
		{
			ArrayList photonlist=new ArrayList();
			RdnColor tex=new RdnColor(1f);
			if(TextureMap!=null)
				tex=Texture(s,t,0,0f,true);
			if(reflection!=new RdnColor(0f))
			{
				RdnPhoton pho=new RdnPhoton();
				pho.Ray=new RdnRay(RdnRayType.Caustic,point,RdnVector.FromReflect(photon.Ray.Direction,normal));
				pho.Energy=reflection*tex*photon.Energy;
				photonlist.Add(pho);
			}
			if(refraction!=new RdnColor(0f))
			{
				RdnPhoton pho=new RdnPhoton();
				if(photon.Ray.Direction*normal>0)
					pho.Ray=new RdnRay(RdnRayType.Caustic,point,RdnVector.FromRefract(photon.Ray.Direction,normal.Inverted,refractionindex));
				else
					pho.Ray=new RdnRay(RdnRayType.Caustic,point,RdnVector.FromRefract(photon.Ray.Direction,normal,1f/refractionindex));
				pho.Energy=refraction*tex*photon.Energy;
				photonlist.Add(pho);
			}
			if(reflection==new RdnColor(0f)&&refraction==new RdnColor(0f))
			{
				RdnPhoton pho=new RdnPhoton();
				pho.Ray=new RdnRay(RdnRayType.Global,point,RdnVector.FromSphere(normal,((float)Math.PI/2),random));
				float d=(normal*photon.Ray.Direction.Inverted);
				if(d<0f)
					d=0f;
				pho.Energy=diffuse*tex*photon.Energy*d;
				photonlist.Add(pho);
			}
			if(photonlist.Count>0)
			{
				photons=new RdnPhoton[photonlist.Count];
				for(int i=0;i<photonlist.Count;i++)
					photons[i]=((RdnPhoton)photonlist[i]);
			}
			else
				photons=null;
		}
	}
}