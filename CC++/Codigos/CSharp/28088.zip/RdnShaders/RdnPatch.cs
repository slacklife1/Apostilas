using System;
using Rdn;
using Rdn.Basis;

namespace RdnShaders
{
	/// <summary>
	/// Summary description for RdnPatch.
	/// </summary>
	public class RdnPatch : RdnShader
	{
		private RdnVector[,] cpts;

		public RdnPatch(RdnVector[,] cpoints)
		{
			cpts=cpoints;
		}

		public override void PrimitiveProcess(out RdnVector point,float u,float v)
		{
			point=new RdnVector(
					RdnMath.BezierInterpolation(
					RdnMath.BezierInterpolation(cpts[0,0].X,cpts[1,0].X,cpts[2,0].X,cpts[3,0].X,u),
					RdnMath.BezierInterpolation(cpts[0,1].X,cpts[1,1].X,cpts[2,1].X,cpts[3,1].X,u),
					RdnMath.BezierInterpolation(cpts[0,2].X,cpts[1,2].X,cpts[2,2].X,cpts[3,2].X,u),
					RdnMath.BezierInterpolation(cpts[0,3].X,cpts[1,3].X,cpts[2,3].X,cpts[3,3].X,u),v),
					RdnMath.BezierInterpolation(
					RdnMath.BezierInterpolation(cpts[0,0].Y,cpts[1,0].Y,cpts[2,0].Y,cpts[3,0].Y,u),
					RdnMath.BezierInterpolation(cpts[0,1].Y,cpts[1,1].Y,cpts[2,1].Y,cpts[3,1].Y,u),
					RdnMath.BezierInterpolation(cpts[0,2].Y,cpts[1,2].Y,cpts[2,2].Y,cpts[3,2].Y,u),
					RdnMath.BezierInterpolation(cpts[0,3].Y,cpts[1,3].Y,cpts[2,3].Y,cpts[3,3].Y,u),v),
					RdnMath.BezierInterpolation(	
					RdnMath.BezierInterpolation(cpts[0,0].Z,cpts[1,0].Z,cpts[2,0].Z,cpts[3,0].Z,u),
					RdnMath.BezierInterpolation(cpts[0,1].Z,cpts[1,1].Z,cpts[2,1].Z,cpts[3,1].Z,u),
					RdnMath.BezierInterpolation(cpts[0,2].Z,cpts[1,2].Z,cpts[2,2].Z,cpts[3,2].Z,u),
					RdnMath.BezierInterpolation(cpts[0,3].Z,cpts[1,3].Z,cpts[2,3].Z,cpts[3,3].Z,u),v));
		}
	}
}
