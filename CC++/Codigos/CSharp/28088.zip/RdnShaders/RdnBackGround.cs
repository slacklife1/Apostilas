using System;
using Rdn;
using Rdn.Basis;

namespace RdnShaders
{
	/// <summary>
	/// Summary description for RdnBackGround.
	/// </summary>
	public class RdnBackGround : RdnShader
	{
		private RdnColor backcolor1,backcolor2;
		private float scale;

		public RdnBackGround()
		{
		}
		public RdnBackGround(RdnColor color)
		{
			backcolor1=color;
		}
		public RdnBackGround(RdnColor color1,RdnColor color2,float scale)
		{
			backcolor1=color1;backcolor2=color2;
			this.scale=scale;
		}

		public override void ImagerProcess(ref RdnColor color,int width,int height,int x,int y,float depth,int id,int frame)
		{
			if(id==-1)
			{
				if(TextureMap!=null)
					color=Texture((float)x/(float)(width-1),(float)y/(float)(height-1),0,0f,true);
				else
				{
					if(scale>0f)
						color=RdnColor.FromBlend(backcolor1,backcolor2,RdnMath.GenerateCloud(x*scale*(256f/(float)width),y*scale*(256f/(float)height),2,0));
					else
						color=backcolor1;
				}
			}
		}
	}
}
