using System;
using Rdn;
using Rdn.Basis;

namespace RdnShaders
{
	/// <summary>
	/// Summary description for RdnPlane.
	/// </summary>
	public class RdnPlane : RdnShader
	{
		private float sx,sy,sz,height;

		public RdnPlane(float sx,float sy,float sz,float height)
		{
			this.sx=sx;
			this.sy=sy;
			this.sz=sz;
			this.height=height;
		}

		public override void PrimitiveProcess(out RdnVector point,float u,float v)
		{
			point=new RdnVector(0,0,0);
			if(sx==0f)
				point=new RdnVector(height,u*sy-sy/2f,v*sz-sz/2f);
			if(sy==0f)
				point=new RdnVector(u*sx-sx/2f,height,v*sz-sz/2f);
			if(sz==0f)
				point=new RdnVector(u*sx-sx/2f,v*sy-sy/2f,height);
		}
	}
}
