using System;
using Rdn;
using Rdn.Basis;

namespace RdnShaders
{
	/// <summary>
	/// Summary description for RdnCylinder.
	/// </summary>
	public class RdnCylinder : RdnShader
	{
		private float zmin,zmax,radius,thetamax;

		public RdnCylinder(float radius,float zmin,float zmax,float thetamax)
		{
			this.radius=radius;
			this.zmin=zmin;
			this.zmax=zmax;
			this.thetamax=thetamax;
		}
		
		public override void PrimitiveProcess(out RdnVector point,float u,float v)
		{
			float t=u*(float)thetamax;
			point=new RdnVector(radius*(float)Math.Cos(t),radius*(float)Math.Sin(t),zmin+v*(zmax-zmin));
		}
	}
}
