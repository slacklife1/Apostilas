using System;
using Rdn;
using Rdn.Basis;

namespace RdnShaders
{
	/// <summary>
	/// Summary description for RdnDisplace.
	/// </summary>
	public class RdnDisplace : RdnShader
	{
		private float scale,width,height;

		public RdnDisplace(float scale,float width,float height)
		{
			this.scale=scale;
			this.width=width;
			this.height=height;
		}
		public RdnDisplace(float scale)
		{
			this.scale=scale;
		}

		public override void DisplacementProcess(ref RdnVector point,RdnVector dPdu,RdnVector dPdv,RdnVector normal,float u,float v,float du,float dv,float s,float t,RdnRay eye,int frame)
		{
			if(TextureMap!=null)
				point=point+normal*(scale*Texture(s,t,0,0f,true).Intensity);
			else
				point=point+normal*(scale*RdnMath.GenerateCloud(s*height,t*width,2f,0));
		}
	}
}
