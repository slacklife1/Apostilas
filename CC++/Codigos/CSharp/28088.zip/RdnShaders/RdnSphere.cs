using System;
using Rdn;
using Rdn.Basis;

namespace RdnShaders
{
	/// <summary>
	/// Summary description for RdnSphere.
	/// </summary>
	public class RdnSphere : RdnShader
	{
		private float zmin,zmax,radius,thetamax;

		public RdnSphere(float radius,float zmin,float zmax,float thetamax)
		{
			this.radius=radius;
			this.zmin=zmin;
			this.zmax=zmax;
			this.thetamax=thetamax;
		}

		public override void PrimitiveProcess(out RdnVector point,float u,float v)
		{
			float vangmin=(float)Math.Asin(zmin/radius);
			float vangmax=(float)Math.Asin(zmax/radius);
			float uang=u*thetamax;
			float vang=vangmin+v*(vangmax-vangmin);
			point=new RdnVector(radius*(float)(Math.Cos(uang)*Math.Cos(vang)),
				radius*(float)(Math.Sin(uang)*Math.Cos(vang)),
				radius*(float)Math.Sin(vang));
		}
	}
}
