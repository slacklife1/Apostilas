using System;
using Rdn;
using Rdn.Basis;

namespace RdnShaders
{
	/// <summary>
	/// Summary description for RdnCone.
	/// </summary>
	public class RdnLight : RdnShader
	{
		private int numphotons;
		private RdnVector direction,spottarget;
		private RdnColor color,shadow;
		private float spottheta,spotphi,spotfalloff;
		private Random random=new Random();

		public RdnLight(RdnVector direction,RdnColor color,RdnColor shadow,RdnVector spottarget,float spottheta,float spotphi,float spotfalloff,int numphotons)
		{
			this.direction=direction;
			this.color=color;
			this.shadow=shadow;
			this.spottarget=spottarget;
			this.spottheta=(float)Math.Cos(spottheta/2.0f);
			this.spotphi=(float)Math.Cos(spotphi/2.0f);
			this.spotfalloff=spotfalloff;
			this.numphotons=numphotons;
		}
		public RdnLight(RdnVector direction,RdnColor color,RdnColor shadow,RdnVector spottarget,float spottheta,float spotphi,float spotfalloff)
		{
			this.direction=direction;
			this.color=color;
			this.shadow=shadow;
			this.spottarget=spottarget;
			this.spottheta=(float)Math.Cos(spottheta/2.0f);
			this.spotphi=(float)Math.Cos(spotphi/2.0f);
			this.spotfalloff=spotfalloff;
		}
		public RdnLight(RdnVector direction,RdnColor color,RdnColor shadow)
		{
			this.direction=direction;
			this.color=color;
			this.shadow=shadow;
		}

		public override void LightSourceProcess(out RdnPhoton[] photons,RdnVector position,RdnVector point,RdnRay eye,int frame)
		{
			photons=new RdnPhoton[1];
			float dist=(point-position).Length;
			if(direction!=new RdnVector(0f,0f,0f))
				photons[0].Ray=new RdnRay(RdnRayType.Direct,position,direction);
			else
				photons[0].Ray=new RdnRay(RdnRayType.Direct,position,point-position);
			photons[0].Energy=color;
			if(spotfalloff!=0f&&direction==new RdnVector(0f,0f,0f))
				photons[0].Energy=photons[0].Energy*RdnMath.ClampWrap((float)Math.Pow(Math.Max(0f,((photons[0].Ray.Direction*(spottarget-photons[0].Ray.Origin).Normalized)-spotphi)/(spottheta-spotphi)),spotfalloff),0f,1f);
			if(shadow!=new RdnColor(1f))
			{
				RdnPhoton[] pho;
				LocateNearestDirectPhotons(out pho,point,1f);
				RdnColor phoc=new RdnColor(0f);
				if(pho!=null)
				{
					for(int i=0;i<pho.Length;i++)
						phoc=phoc+pho[i].Energy;
					if(pho.Length>0)
						phoc=phoc/pho.Length;
				}
				if(phoc==new RdnColor(0f))
				{
					RdnCastState cs=Cast(new RdnRay(RdnRayType.Shadow,point,photons[0].Ray.Direction.Inverted));
					if(cs.MicroPolygon!=null)
					{
						if(cs.Dist<dist)
							photons[0].Energy=photons[0].Energy*shadow;
					}
				}
			}
		}
		public override void LightSourceEmitterProcess(out RdnPhoton[] photons,RdnVector position,int frame)
		{
			photons=null;
			if(numphotons>0)
			{
				photons=new RdnPhoton[numphotons];
				for(int i=0;i<photons.Length;i++)
				{
					photons[i].Ray=new RdnRay(RdnRayType.Direct,position,RdnVector.FromSphere(new RdnVector(0f,-1,0f),((float)Math.PI),random));
					photons[i].Energy=color;
				}
			}
		}
	}
}