using System;
using Rdn;
using Rdn.Basis;

namespace RdnShaders
{
	/// <summary>
	/// Summary description for RdnTorus.
	/// </summary>
	public class RdnTorus : RdnShader
	{
		private float majorradius,minorradius,phimin,phimax,thetamax;

		public RdnTorus(float majorradius,float minorradius,float phimin,float phimax,float thetamax)
		{
			this.majorradius=majorradius;
			this.minorradius=minorradius;
			this.phimin=phimin;
			this.phimax=phimax;
			this.thetamax=thetamax;
		}
		
		public override void PrimitiveProcess(out RdnVector point,float u,float v)
		{
			float t=u*thetamax;
			float tt=phimin+v*(phimax-phimin);
			float r=minorradius*(float)Math.Cos(tt);
			point=new RdnVector((majorradius-r)*(float)Math.Sin(t),
								(majorradius-r)*(float)Math.Cos(t),
								minorradius*(float)Math.Sin(tt));
		}
	}
}