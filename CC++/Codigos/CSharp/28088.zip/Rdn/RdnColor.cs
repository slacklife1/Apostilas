using System;
using System.Drawing;

namespace Rdn.Basis
{
	/// <summary>
	/// Summary description for RdnColor.
	/// </summary>
	public struct RdnColor
	{
		private float red,green,blue;
			
		public RdnColor(float red,float green,float blue)
		{
			this.red=red;this.green=green;this.blue=blue;
		}
		public RdnColor(float intensity)
		{
			this.red=intensity;this.green=intensity;this.blue=intensity;
		}
			
		public Color ToColor()
		{
			return Color.FromArgb((int)(red*255.0f),(int)(green*255.0f),(int)(blue*255.0f));
		}
		public void Clamp()
		{
			if(red<0)
				red=0;
			else if(red>1)
				red=1;
			if(green<0)
				green=0;
			else if(green>1)
				green=1;
			if(blue<0)
				blue=0;
			else if(blue>1)
				blue=1;
		}
			
		public override bool Equals(object obj)
		{
			if((object)this==obj)
				return true;
			return false;
		}
		public override int GetHashCode()
		{
			return 0;
		}
		
		public static RdnColor FromColor(Color color)
		{
			return new RdnColor((float)color.R/255.0f,(float)color.G/255.0f,(float)color.B/255.0f);
		}
		public static RdnColor FromBlend(RdnColor a,RdnColor b,float opacity)
		{
			return new RdnColor(RdnMath.LinearInterpolation(a.Red,b.Red,opacity),RdnMath.LinearInterpolation(a.Green,b.Green,opacity),RdnMath.LinearInterpolation(a.Blue,b.Blue,opacity));
		}
		public static RdnColor FromBlend(RdnColor a,RdnColor b,RdnColor opacity)
		{
			return new RdnColor(RdnMath.LinearInterpolation(a.Red,b.Red,opacity.Red),RdnMath.LinearInterpolation(a.Green,b.Green,opacity.Green),RdnMath.LinearInterpolation(a.Blue,b.Blue,opacity.Blue));
		}
		unsafe public static RdnColor FromBitmap(int* pixels,int width,int height,float u,float v)
		{
			return RdnColor.FromColor(Color.FromArgb(pixels[((int)(v*(height-1)))*width+((int)(u*(width-1)))]));
		}
		public static RdnColor FromBitmap(Bitmap bitmap,float u,float v)
		{
			return RdnColor.FromColor(bitmap.GetPixel((int)(u*(bitmap.Width-1)),
				(int)(v*(bitmap.Height-1))));
		}
		public static RdnColor FromFilter(RdnColor c00,RdnColor c10,RdnColor c01,RdnColor c11,float fu,float fv)
		{
			return ((1.0f-fu)*(1.0f-fv)*c00+fu*(1.0f-fv)*c10+(1.0f-fu)*fv*c01+fu*fv*c11);
		}
		unsafe public static RdnColor FromFilter(int* pixels,int width,int height,float u,float v)
		{
			float fx=u*(width-1);
			float fy=v*(height-1);
			int x0=(int)Math.Floor(fx);
			int x1=(int)Math.Ceiling(fx);
			int y0=(int)Math.Floor(fy);
			int y1=(int)Math.Ceiling(fy);
			float fu=fx-x0;
			float fv=fy-y0;
			return RdnColor.FromFilter(RdnColor.FromColor(Color.FromArgb(pixels[y0*width+x0])),
									  RdnColor.FromColor(Color.FromArgb(pixels[y0*width+x1])),
									  RdnColor.FromColor(Color.FromArgb(pixels[y1*width+x0])),
									  RdnColor.FromColor(Color.FromArgb(pixels[y1*width+x1])),
									  fu,fv);
		}
		public static RdnColor FromFilter(Bitmap bitmap,float u,float v)
		{
			float fx=u*(bitmap.Width-1);
			float fy=v*(bitmap.Height-1);
			int x0=(int)Math.Floor(fx);
			int x1=(int)Math.Ceiling(fx);
			int y0=(int)Math.Floor(fy);
			int y1=(int)Math.Ceiling(fy);
			float fu=fx-x0;
			float fv=fy-y0;
			return RdnColor.FromFilter(RdnColor.FromColor(bitmap.GetPixel(x0,y0)),
									  RdnColor.FromColor(bitmap.GetPixel(x1,y0)),
									  RdnColor.FromColor(bitmap.GetPixel(x0,y1)),
									  RdnColor.FromColor(bitmap.GetPixel(x1,y1)),
									  fu,fv);
		}
		public static bool operator==(RdnColor a,RdnColor b)
		{
			if((a.Red==b.Red)&&(a.Green==b.Green)&&(a.Blue==b.Blue))
				return true;
			return false;
		}
		public static bool operator!=(RdnColor a,RdnColor b)
		{
			if((a.Red!=b.Red)||(a.Green!=b.Green)||(a.Blue!=b.Blue))
				return true;
			return false;
		}
		public static RdnColor operator+(RdnColor a,RdnColor b)
		{
			return new RdnColor(a.Red+b.Red,a.Green+b.Green,a.Blue+b.Blue);
		}
		public static RdnColor operator-(RdnColor a,RdnColor b)
		{
			return new RdnColor(a.Red-b.Red,a.Green-b.Green,a.Blue-b.Blue);
		}
		public static RdnColor operator*(RdnColor color,float scalar)
		{
			return new RdnColor(color.Red*scalar,color.Green*scalar,color.Blue*scalar);
		}
		public static RdnColor operator*(float scalar,RdnColor color)
		{
			return new RdnColor(color.Red*scalar,color.Green*scalar,color.Blue*scalar);
		}
		public static RdnColor operator/(RdnColor color,float scalar)
		{
			return new RdnColor(color.Red/scalar,color.Green/scalar,color.Blue/scalar);
		}
		public static RdnColor operator/(float scalar,RdnColor color)
		{
			return new RdnColor(scalar/color.Red,scalar/color.Green,scalar/color.Blue);
		}
		public static RdnColor operator*(RdnColor a,RdnColor b)
		{
			return new RdnColor(a.Red*b.Red,a.Green*b.Green,a.Blue*b.Blue);
		}
			
		public float Red
		{
			get
			{
				return red;
			}
			set
			{
				red=value;
			}
		}
		public float Green
		{
			get
			{
				return green;
			}
			set
			{
				green=value;
			}
		}
		public float Blue
		{
			get
			{
				return blue;
			}
			set
			{
				blue=value;
			}
		}
		public float Intensity
		{
			get
			{
				return (red+green+blue)/3.0f;
			}
		}
		public float Length
		{
			get
			{
				return (float)Math.Sqrt(red*red+green*green+blue*blue);
			}
		}
		public RdnColor Clamped
		{
			get
			{
				RdnColor c=this;
				c.Clamp();
				return c;
			}
		}
	}
}