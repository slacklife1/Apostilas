using System;
using System.Drawing;
using Rdn.Basis;

namespace Rdn.Maps
{
	/// <summary>
	/// Summary description for RdnShadowMap.
	/// </summary>
	public class RdnShadowMap
	{
		private string name;
		private int width,height;
		private RdnMatrix view;
		private float near,far;
		private float[,] depths;
		
		public RdnShadowMap(int width,int height)
		{
			this.width=width;
			this.height=height;
			depths=new float[width,height];
		}

		public void Clear()
		{
			this.width=width;
			this.height=height;
			depths=new float[width,height];
		}
		public void Clear(float depth)
		{
			for(int x=0;x<width;x++)
				for(int y=0;y<height;y++)
					depths[x,y]=depth;
		}
		
		public static RdnShadowMap FromTextureMap(RdnTextureMap texturemap)
		{
			RdnShadowMap shadow=new RdnShadowMap(texturemap.Width,texturemap.Height);
			for(int x=0;x<shadow.Width;x++)
				for(int y=0;y<shadow.Height;y++)
					shadow[x,y]=texturemap[x,y].Color.Intensity;
			return shadow;
		}

		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				name=value;
			}
		}
		public int Width
		{
			get
			{
				return width;
			}
		}
		public int Height
		{
			get
			{
				return height;
			}
		}
		public RdnMatrix View
		{
			get
			{
				return view;
			}
			set
			{
				view=value;
			}
		}
		public float Near
		{
			get
			{
				return near;
			}
			set
			{
				near=value;
			}
		}
		public float Far
		{
			get
			{
				return far;
			}
			set
			{
				far=value;
			}
		}
		public float this[int x, int y]
		{ 
			get
			{
				return depths[x,y];
			}
			set
			{
				depths[x,y]=value;
			}
		}
	}
}
