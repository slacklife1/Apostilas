using System;

namespace Rdn.Basis
{
	/// <summary>
	/// Summary description for RdnMath.
	/// </summary>
	public sealed class RdnMath
	{
		public static float BaryCentric(float p0,float p1,float p2,float a,float b)
		{
			return p0+a*(p1-p0)+b*(p2-p0);
		}
		public static float BezierInterpolation(float p0,float p1,float p2,float t)
		{
			float tm1,tm12,t2;
			t2=t*t;tm1=1-t;tm12=tm1*tm1;
			return p0*tm12+2*p1*tm1*t+p2*t2;
		}
		public static float BezierInterpolation(float p0,float p1,float p2,float p3,float t)
		{
			float tm1,tm13,t3;
			tm1=1-t;tm13=tm1*tm1*tm1;t3=t*t*t;
			return tm13*p0+3*t*tm1*tm1*p1+3*t*t*tm1*p2+t3*p3;
		}
		public static float BezierInterpolation(float[] points,float t)
		{
			int k,kn,nn,nkn,numpoints=points.Length;
			float blend,tk,tnk;
			float b=0.0f;tk=1.0f;
			tnk=(float)Math.Pow(1.0f-t,(float)numpoints);
			for (k=0;k<=numpoints;k++) 
			{
				nn=numpoints;
				kn=k;
				nkn=numpoints-k;
				blend=tk*tnk;
				tk*=t;
				tnk/=(1.0f-t);
				while(nn>=1)
				{
					blend*=nn;
					nn--;
					if (kn>1.0f)
					{
						blend/=(float)kn;
						kn--;
					}
					if(nkn>1.0f)
					{
						blend/=(float)nkn;
						nkn--;
					}
				}
				b+=points[k]*blend;
			}
			return b;
		}
		public static float BiLinearInterpolation(float start0,float end0,float t0,float start1,float end1,float t1)
		{
			return LinearInterpolation(LinearInterpolation(start0,end0,t0),LinearInterpolation(start1,end1,t0),t1);
		}
		public static float BoxFilter(float x,float y,float xwidth,float ywidth)
		{
			if((Math.Abs(x)<=xwidth)&&(Math.Abs(y)<=ywidth))
				return 1.0f;
			return 0.0f;
		}
		public static float CatmullRomFilter(float x,float y)
		{
			float r2=x*x+y*y;
			float r=(float)Math.Sqrt(r2);
			return (r>=2f)?0f:(r<1f)?(3f*r*r2-5f*r2+2f):(-r*r2+5f*r2-8f*r+4f);
		}
		public static float ClampWrap(float val,float min,float max)
		{
			return (min>val)?min:(max>val)?val:max;
		}
		public static float CosineInterpolation(float start,float end,float t)
		{
			float tt=(float)(1.0f-Math.Cos(t*Math.PI))/2.0f;
			return LinearInterpolation(start,end,tt);
		}
		public static float CubicInterpolation(float first,float start,float end,float last,float t)
		{
			float a0,a1,a2,a3;
			a0=last-end-first+start;a1=first-start-a0;
			a2=end-first;a3=start;
			return a0*t*t*t+a1*t*t+a2*t+a3;
		}
		public static float CubicBezierInterpolation(float p0,float p1,float p2,float p3,float t)
		{
			float c=3.0f*(p1-p0);
			float b=3.0f*(p2-p1)-c;
			float a=p3-p0-c-b;
			return a*t*t*t+b*t*t+c*t+p0;
		}
		public static void CylinderToRect(out float x,out float y,out float z,float r,float e,float t)
		{
			x=(float)(r*Math.Cos((float)t));
			y=(float)(r*Math.Sin((float)t));
			z=e;
		}
		public static void CylinderToRect(out float u,out float v,float e,float t,float h)
		{
			u=(float)(t/(2.0f*Math.PI));
			v=e/h;
		}
		public static void CylinderToRect(out float u,out float v,float t0,float t1,float a,float e0,float e1,float b,float h)
		{
			u=(float)((a*(t1-t0))/(2.0f*Math.PI));
			v=(float)((b*(e1-e0))/h);
		}
		public static float GaussianFilter(float x,float y,float xwidth,float ywidth)
		{
			return (float)(Math.Exp(-(x*x)/(2*xwidth*xwidth))*Math.Exp(-(y*y)/(2*ywidth*ywidth)));
		}
		public static float LinearInterpolation(float start,float end,float t)
		{
			return start+t*(end-start);
		}
		public static int LineSide(float a,float b,float c,float x,float y)
		{
			float s=a*x+b*y+c;
			if(s<0)
				return -1;
			if(s>0)
				return 1;
			return 0;
		}
		public static int LineSide(float x0,float y0,float x1,float y1,float x,float y)
		{
			float dist=(y-y0)*(x1-x0)-(y1-y0)*(x-x0);
			if(dist>0)
				return -1;
			if(dist<0)
				return 1;
			return 0;
		}
		public static float MirrorWrap(float val,float min,float max)
		{
			float d=(max-min)-1.0f;
			float r=RepeatWrap(val,min,max*2.0f);
			if(r>d)
				return d-RepeatWrap(val,min,max);
			return RepeatWrap(val,min,max);
		}
		public static int PlaneSide(float a,float b,float c,float d,float x,float y,float z)
		{
			float s=a*x+b*y+c*z+d;
			if(s<0)
				return -1;
			if(s>0)
				return 1;
			return 0;
		}
		public static bool PointInLine(float x0,float y0,float x1,float y1,float x,float y)
		{
			float div=Math.Max(x1-x0,y1-y0);
			if(div==0)
				return false;
			if(Math.Floor((float)((y-y0)*(x1-x0)-(y1-y0)*(x-x0))/div)==0)
				return true;
			return false;
		}
		public static bool PointInPolygon(float [,]vertices,float x,float y)
		{
			int numvertices=vertices.Length;
			bool c=false;
			for(int i=0,j=numvertices-1;i<numvertices;j=i++)
				if((((vertices[i,1]<=y)&&(y<vertices[j,1]))||((vertices[j,1]<=y)&&(y<vertices[i,1])))&&(x<(vertices[j,0]-vertices[i,0])*(y-vertices[i,1])/(vertices[j,1]-vertices[i,1])+vertices[i,0]))
					c=!c;
			return c;
		}
		public static bool PointInRect(int x0,int y0,int x1,int y1,int x,int y)
		{
			if(((x>=x0)&&(x<=x1))&&((y>=y0)&&(y<=y1)))
				return true;
			return false;
		}
		public static bool PointInTriangle(float x0,float y0,float x1,float y1,float x2,float y2,float x,float y)
		{
			int side0,side1,side2;
			side0=LineSide(x0,y0,x1,y1,x,y);
			side1=LineSide(x1,y1,x2,y2,x,y);
			side2=LineSide(x2,y2,x0-1,y0-1,x,y);
			if(side0==0&&side1==0)
				return true;
			if(side1==0&&side2==0)
				return true;
			if(side0==0&&(side1==side2))
				return true;
			if(side1==0&&(side0==side2))
				return true;
			if(side2==0&&(side0==side1))
				return true;
			if((side0==side1)&&(side1==side2))
				return true;
			return false;
		}
		public static float Poly(float a,float b,float x)
		{
			return a*x+b;
		}
		public static float Poly(float a,float b,float c,float x)
		{
			return a*x*x+b*x+c;
		}
		public static float Poly(float a,float b,float c,float d,float x)
		{
			return a*x*x*x+b*x*x+c*x+d;
		}
		public static float PolynomialInterpolation(float p0,float p1,float p2,float t)
		{
			float a=p0-2*p1+p2;
			float b=-2*p0+2*p1;
			float c=p0;
			return a*t*t+b*t+c;
		}
		public static void PolarToRect(out float x,out float y,float r,float a)
		{
			x=(float)(r*Math.Cos(a));
			y=(float)(r*Math.Sin(a));
		}
		public static float RepeatWrap(float x,float min,float max)
		{
			float d=max-min;
			if(x<0.0f)
				return min+(x-x*d%d);
			return min+(x%d);
		}
		public static int Scale(int val,float scale)
		{
			return (int)Math.Floor((float)val/scale);
		}
		public static float SincFilter(float x,float y)
		{
			float d=(float)Math.Sqrt(x*x+y*y);
			if(d!=0.0f)
				return (float)Math.Sin(d)/d;
			return 1.0f;
		}
		public static float SinWave(float a,float b,float amp,float freq,float x)
		{
			return (float)(b+amp*Math.Sin(a+freq*x));
		}
		public static void SphereToRect(out float x,out float y,out float z,float r,float t,float s)
		{
			x=(float)(r*Math.Cos(t)*Math.Sin(s));
			y=(float)(r*Math.Sin(t)*Math.Sin(s));
			z=(float)(r*Math.Cos(s));
		}
		public static void SphereToRect(out float u,out float v,float t,float s)
		{
			u=(float)(t/(2.0f*Math.PI));
			v=(float)(s/Math.PI);
		}
		public static void SphereToRect(out float u,out float v,float t0,float t1,float a,float s0,float s1,float b)
		{
			u=(float)((a*(t1-t0))/(2.0f*Math.PI));
			v=(float)((b*(s1-s0))/Math.PI);
		}
		public static float StepWrap(float val,float min,float max)
		{
			if(val<=min)
				return 0.0f;
			if(val>=max)
				return 1.0f;
			return LinearInterpolation(min,max,val);
		}
		public static void Swap(ref float a,ref float b)
		{
			float aux=a;
			a=b;b=aux;
		}
		public static float TriangleFilter(float x,float y,float xwidth,float ywidth)
		{
			float  hxw=xwidth/2.0f;
			float  hyw=ywidth/2.0f;
			float  absx=Math.Abs(x);
			float  absy=Math.Abs(y);
			return (float)Math.Min((absx<=hxw?(hxw-absx)/hxw:0.0),(absy<=hyw?(hyw-absy)/hyw:0.0));
		}
		public static float GenerateRandom(int x,int y)
		{
			int n=x+y*57;
			n=(n<<13)^n;
			return (1.0f-(float)((n*(n*n*15731+789221)+1376312589)&2147483647)/1073741824);
		}
		public static float NoiseInterpolation(float x,float y)
		{
			float v1,v2,v3,v4;
			float integer_X,integer_Y;
			float fractional_X,fractional_Y;
			float i1,i2;
			integer_X=(int)x;
			fractional_X=x-integer_X;
			integer_Y=(int)y;
			fractional_Y=y-integer_Y;
			v1=GenerateRandom((int)integer_X,(int)integer_Y);
			v2=GenerateRandom((int)integer_X+1,(int)integer_Y);
			v3=GenerateRandom((int)integer_X,(int)integer_Y+1);
			v4=GenerateRandom((int)integer_X+1,(int)integer_Y+1);
			i1=LinearInterpolation(v1,v2,fractional_X);
			i2=LinearInterpolation(v3,v4,fractional_X);
			return LinearInterpolation(i1,i2,fractional_Y);
		}
		public static float PerlinNoise(float x,float y,float pers,int oct)
		{
			float frequency=(float)Math.Pow(2,oct);
			float amplitude=(float)Math.Pow(pers,oct);
			return NoiseInterpolation(x*frequency,y*frequency)*amplitude;
		}
		public static float Turbulence(float x,float y,float scale,float pers,int oct)
		{
			float t=0.0f;
			while(scale>=1.0f)
			{
				t+=PerlinNoise(x/scale,y/scale,pers,oct)*scale;
				scale/=2.0f;
			}
			return t;
		}
		public static float GenerateCloud(float x,float y,float pers,int oct)
		{
			float val=0.01f*Turbulence(x,y,256.0f,pers,oct);
			return (float)Math.Abs(Math.Sin(val*Math.PI));
		}
		public static float GenerateFloor(float x,float y,float pers,int oct)
		{
			float val=0.1f*Turbulence(x/12.0f,y,256.0f,pers,oct);
			return (float)Math.Abs(Math.Sin(val*Math.PI));
		}
		public static float GenerateGas(float x,float y,float pers,int oct,float density,float exp)
		{
			return (float)Math.Pow(density*Turbulence(x,y,256.0f,pers,oct),exp);
		}
		public static float GenerateStrange(float x,float y,float pers,int oct)
		{
			float val=0.0003f*Turbulence(y,x,512.0f,pers,oct);
			return (float)Math.Abs(Math.Sin((x*y/2)+val));
		}
		public static float Attenuation(float a,float b,float c,float dist)
		{
			if(c==0.0f)
				return 1.0f;
			float att=Math.Min(1.0f/(a*dist*dist+b*dist+c),1.0f);
			if(att<0.0f)
				att=0.0f;
			return att;
		}
		public static void ProjectCoords(out float x1,out float y1,float x0,float y0,float z0,float nx,float ny,float nz)
		{
			x1=y1=0;
			float absnx=Math.Abs(nx);
			float absny=Math.Abs(ny);
			float absnz=Math.Abs(nz);
			float max=Math.Max(absnx,Math.Max(absny,absnz));
			if(max==absnx)
			{
				x1=y0;
				y1=z0;
			}
			else if(max==absny)
			{
				x1=x0;
				y1=z0;
			}
			else if(max==absnz)
			{
				x1=x0;
				y1=y0;
			}
		}
		public static void BaryCoords(out float a,out float b,float x0,float y0,float x1,float y1,float x2,float y2,float x,float y)
		{
			a=b=0;
			float u0=x-x0;
			float u1=y-y0;
			float v0=x1-x0;
			float v1=y1-y0;
			float w0=x2-x0;
			float w1=y2-y0;
			float det=v0*w1-v1*w0;
			if(det==0.0f)
				return;
			a=(u0*w1-u1*w0)/det;
			b=(v0*u1-v1*u0)/det;
		}		
		public static int TriangleArea(int x0,int y0,int x1,int y1,int x2,int y2)
		{
			int u0=x1-x0;
			int u1=y1-y0;
			int v0=x2-x0;
			int v1=y2-y0;
			return Math.Abs((x0*(u1-v1)-y0*(u0-v0)+(u0*v1-u1*v0))/2);
		}
		public static void SpherePoint(out float x,out float y,out float z,float theta,float phi)
		{
			x=(float)(Math.Cos(phi)*Math.Sin(theta));
			y=(float)(Math.Sin(phi)*Math.Sin(theta));
			z=(float)(Math.Cos(theta));
		}
		public static bool PointInBox(float minx,float miny,float minz,float maxx,float maxy,float maxz,float x,float y,float z)
		{
			if((x>=minx&&x<=maxx)&&(y>=miny&&y<=maxy)&&(z>=minz&&z<=maxz))
				return true;
			return false;
		}
		public static float SmoothStep(float val,float min,float max)
		{
			if(val<=min)
				return 0f;
			if(val>=max)
				return 1f;
			return -2f*(float)Math.Pow((val-min)/(max-min),3)+3f*(float)Math.Pow((val-min)/(max-min),2);
		}
	}
}