using System;
using System.Drawing;

namespace Rdn.Basis
{
	/// <summary>
	/// Summary description for RdnFilter.
	/// </summary>
	public class RdnFilter
	{
		public Point[] Points;
		public float[] Mults;
		public float Div;

		public static RdnFilter FromBlur(int width,int height)
		{
			RdnFilter filter=new RdnFilter();
			filter.Points=new Point[width*height];
			filter.Mults=new float[width*height];
			for(int x=0;x<width;x++)
			{
				for(int y=0;y<height;y++)
				{
					int offset=y*width+x;
					filter.Points[offset]=new Point(x-(width/2-1),y-(height/2-1));
					filter.Mults[offset]=1f;
				}
			}
			filter.Div=width*height;
			return filter;
		}
	}
}
