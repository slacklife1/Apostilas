using System;
using System.Collections;
using System.Reflection;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using Rdn.Basis;
using Rdn.Maps;

namespace Rdn
{
	/// <summary>
	/// Summary description for RdnRender.
	/// </summary>
	public class RdnRender
	{
		private RdnMicroPolygonMap micropolygonmap;
		private RdnPhotonMap directphotonmap,globalphotonmap,causticphotonmap;
		private struct rdnframe
		{
			public RdnMatrix transform;
			public bool fovperspective,open;
			public int frame,formatwidth,formatheight,xsamples,ysamples;
			public int width,height,dofminradius,dofmaxradius;
			public float formataspect,fovwidth,fovheight,fovnear,fovfar;
			public float roll,doffstop,doffocallength,doffocaldistance;
			public RdnColor gain,gamma;
			public RdnVector position,target,up;
			public RdnShader imager;
			public RdnFilter filter;
			public rdnworld world;
		}
		private struct rdnworld
		{
			public RdnMatrix transform;
			public RdnShader atmosphere;
			public int id,reyessamples,tracesamples,tracelevels;
			public float shadingrate;
			public float u0,v0,u1,v1;
			public PointF[] texcoords;
			public RdnColor color,opacity,att2,att1,att0;
			public RdnShader displacement,surface;
			public bool illuminate,hider,matte,twosides,invori,union;
			public RdnClippingPlane[] planes;
			public ArrayList transforms,lightsources,particles,primitives,meshs;
		}
		private struct rdnparticle
		{
			public RdnVector point;
			public int id;
			public float size;
			public RdnColor color,opacity;
			public bool illuminate,hider,matte;
			public void raster(ref RdnFrame frame,rdnframe frm)
			{
				RdnVector p=frm.transform*point;
				RdnVector pt00=RdnVector.FromRaster(p,frm.formatwidth,frm.formatheight,frm.formataspect,frame.Width,frame.Height,frm.fovwidth,frm.fovheight,frm.fovnear,frm.fovfar,frm.fovperspective);
				RdnVector pt01=RdnVector.FromRaster(p+new RdnVector(0f,size,p.Z),frm.formatwidth,frm.formatheight,frm.formataspect,frame.Width,frame.Height,frm.fovwidth,frm.fovheight,frm.fovnear,frm.fovfar,frm.fovperspective);
				RdnVector pt11=RdnVector.FromRaster(p+new RdnVector(size,size,p.Z),frm.formatwidth,frm.formatheight,frm.formataspect,frame.Width,frame.Height,frm.fovwidth,frm.fovheight,frm.fovnear,frm.fovfar,frm.fovperspective);
				RdnVector pt10=RdnVector.FromRaster(p+new RdnVector(size,0f,p.Z),frm.formatwidth,frm.formatheight,frm.formataspect,frame.Width,frame.Height,frm.fovwidth,frm.fovheight,frm.fovnear,frm.fovfar,frm.fovperspective);
				if(RdnMath.PointInBox(0f,0f,0f,(float)frame.Width,(float)frame.Height,1f,pt00.X,pt00.Y,pt00.Z))
				{
					RdnColor col=color,opa=opacity;
					RdnRay incidentray=new RdnRay(frm.position,point-frm.position);
					if(illuminate)
					{
						ArrayList photonlist=new ArrayList();
						for(int i=0;i<frm.world.lightsources.Count;i++)
						{
							RdnPhoton[] ps;
							((rdnlightsource)frm.world.lightsources[i]).lightsource.LightSourceProcess(out ps,((rdnlightsource)frm.world.lightsources[i]).position,point,incidentray,frm.frame);
							if(ps!=null)
								for(int j=0;j<ps.Length;j++)
									photonlist.Add(ps[j]);
						}
						if(photonlist.Count>0)
						{
							RdnColor lig=new RdnColor(0f);
							for(int i=0;i<photonlist.Count;i++)
								lig=lig+((RdnPhoton)photonlist[i]).Energy;
							col=col*lig;
						}
					}
					if(frm.world.atmosphere!=null)
						frm.world.atmosphere.VolumeProcess(ref col,ref opa,pt00.Z,point,incidentray,frm.frame);
					if(frm.imager!=null)
						frm.imager.ImagerProcess(ref col,frame.Width,frame.Height,(int)pt00.X,(int)pt00.Y,pt00.Z,id,frm.frame);
					RdnVector[] mp=new RdnVector[4]{pt00,pt01,pt11,pt10};
					int xmin=(int)mp[0].X,ymin=(int)mp[0].Y;
					int xmax=(int)(mp[0].X+1),ymax=(int)(mp[0].Y+1);
					for(int i=1;i<4;i++)
					{
						if((int)mp[i].X<xmin)
							xmin=(int)mp[i].X;
						if((int)(mp[i].X+1)>xmax)
							xmax=(int)(mp[i].X+1);
						if((int)mp[i].Y<ymin)
							ymin=(int)mp[i].Y;
						if((int)(mp[i].Y+1)>ymax)
							ymax=(int)(mp[i].Y+1);
					}
					for(int x=xmin;x<=xmax;x++)
					{	
						for(int y=ymin;y<=ymax;y++)
						{
							if(!hider||matte)
								frame[x,y]=null;
							frame.SetColor(x,y,pt00.Z,col,opa,id);
							if(matte)
								frame.SetMask(x,y,true);
						}
					}
				}
			}
		}
		private struct rdnlightsource
		{
			public RdnVector position;
			public RdnShader lightsource;
			public void Trace(RdnRender render,rdnframe frm,RdnPhoton photon,int levels)
			{
				if(levels>0)
				{
					RdnCastState caststate=new RdnCastState();
					caststate=render.Cast(photon.Ray);
					if(caststate.MicroPolygon!=null)
					{
						RdnVector point=caststate.Ray.GetPoint(caststate.Dist);
						photon.Point=point;
						float dist=(point-photon.Ray.Origin).Length;
						photon.Energy=photon.Energy*(1f/(frm.world.att2*(dist*dist)+frm.world.att1*dist+frm.world.att0));
						if(photon.Ray.Type==RdnRayType.Direct)
							render.DirectPhotonMap.StorePhoton(photon);
						if(photon.Ray.Type==RdnRayType.Global)
							render.GlobalPhotonMap.StorePhoton(photon);
						if(photon.Ray.Type==RdnRayType.Caustic)
							render.CausticPhotonMap.StorePhoton(photon);
						if(((rdnmicropolygon)caststate.MicroPolygon).surface!=null)
						{
							RdnPhoton[] photons;
							RdnVector dPdu=caststate.MicroPolygon.dPdu;
							RdnVector dPdv=caststate.MicroPolygon.dPdv;
							((rdnmicropolygon)caststate.MicroPolygon).surface.SurfaceEmitterProcess(out photons,point,dPdu,dPdv,dPdu^dPdv,caststate.U,caststate.V,((rdnmicropolygon)caststate.MicroPolygon).du,((rdnmicropolygon)caststate.MicroPolygon).dv,caststate.S,caststate.T,photon,frm.frame);
							if(photons!=null)
								for(int i=0;i<photons.Length;i++)
									Trace(render,frm,photons[i],levels-1);
						}
					}
				}
			}
		}
		private struct rdnprimitive
		{
			public RdnMatrix transform;
			public int id,reyessamples,tracesamples,tracelevels;
			public float shadingrate;
			public float u0,v0,u1,v1;
			public PointF[] texcoords;
			public RdnColor color,opacity;
			public RdnClippingPlane[] planes;
			public RdnShader displacement,surface,primitive;
			public bool illuminate,hider,matte,twosides,invori,mesh,union;
			public void raster(ref RdnFrame frame,ref int nummp,rdnframe frm,float u0,float v0,float u1,float v1)
			{
				int u,v,us,vs;
				us=vs=reyessamples;
				float du,dv;
				du=dv=1f/(float)reyessamples;
				RdnVector[,] points=new RdnVector[us+2,vs+2];
				RdnVector[,] pts=new RdnVector[us+2,vs+2];
				RdnBox bd=new RdnBox(float.MaxValue,float.MaxValue,float.MaxValue,float.MinValue,float.MinValue,float.MinValue);;
				for(u=0;u<=us+1;u++)
				{
					for(v=0;v<=vs+1;v++)
					{
						float ui=RdnMath.LinearInterpolation(u0,u1,(float)u/(float)us);
						float vi=RdnMath.LinearInterpolation(v0,v1,(float)v/(float)vs);
						primitive.PrimitiveProcess(out points[u,v],ui,vi);
						if(displacement==null)
						{
							points[u,v]=transform*points[u,v];
							pts[u,v]=RdnVector.FromRaster(frm.transform*points[u,v],frm.formatwidth,frm.formatheight,frm.formataspect,frame.Width,frame.Height,frm.fovwidth,frm.fovheight,frm.fovnear,frm.fovfar,frm.fovperspective);
							bd.MinX=Math.Min(bd.MinX,pts[u,v].X);
							bd.MinY=Math.Min(bd.MinY,pts[u,v].Y);
							bd.MinZ=Math.Min(bd.MinZ,pts[u,v].Z);
							bd.MaxX=Math.Max(bd.MaxX,pts[u,v].X);
							bd.MaxY=Math.Max(bd.MaxY,pts[u,v].Y);
							bd.MaxZ=Math.Max(bd.MaxZ,pts[u,v].Z);
						}
					}
				}
				if(displacement!=null)
				{
					for(u=0;u<=us;u++)
					{
						for(v=0;v<=vs;v++)
						{
							RdnVector a=points[u,v+1]-points[u,v];
							RdnVector b=points[u+1,v]-points[u,v];
							RdnVector c=points[u+1,v+1]-points[u+1,v];
							RdnVector d=points[u+1,v+1]-points[u,v+1];
							if(c.Length>a.Length)a=c;
							if(d.Length>b.Length)b=d;
							float ui=RdnMath.LinearInterpolation(u0,u1,(float)u/(float)us);
							float vi=RdnMath.LinearInterpolation(v0,v1,(float)v/(float)vs);
							float s=texcoords[0].X*((1f-ui)*(1f-vi))+texcoords[1].X*((1f-ui)*vi)+texcoords[2].X*(ui*vi)+texcoords[3].X*(ui*(1f-vi));
							float t=texcoords[0].Y*((1f-ui)*(1f-vi))+texcoords[1].Y*((1f-ui)*vi)+texcoords[2].Y*(ui*vi)+texcoords[3].Y*(ui*(1f-vi));
							displacement.DisplacementProcess(ref points[u,v],b.Normalized,a.Normalized,(b^a).Normalized,ui,vi,du,dv,s,t,new RdnRay(frm.position,points[u,v]-frm.position),frm.frame);
							points[u,v]=transform*points[u,v];
							pts[u,v]=RdnVector.FromRaster(frm.transform*points[u,v],frm.formatwidth,frm.formatheight,frm.formataspect,frame.Width,frame.Height,frm.fovwidth,frm.fovheight,frm.fovnear,frm.fovfar,frm.fovperspective);
							bd.MinX=Math.Min(bd.MinX,pts[u,v].X);
							bd.MinY=Math.Min(bd.MinY,pts[u,v].Y);
							bd.MinZ=Math.Min(bd.MinZ,pts[u,v].Z);
							bd.MaxX=Math.Max(bd.MaxX,pts[u,v].X);
							bd.MaxY=Math.Max(bd.MaxY,pts[u,v].Y);
							bd.MaxZ=Math.Max(bd.MaxZ,pts[u,v].Z);
						}
					}
				}
				if(bd.IntersectWith(new RdnBox(0f,0f,0f,frame.Width,frame.Height,1f)))
				{
					if(Math.Max(bd.Distances.X,bd.Distances.Y)<Math.Max(frame.Width,frame.Height))
					{
						float maxusize=0;
						float maxvsize=0;
						for(u=0;u<us;u++)
						{
							for(v=0;v<vs;v++)
							{
								float udist=(pts[u+1,v].X-pts[u,v].X)*(pts[u+1,v].X-pts[u,v].X)+
									(pts[u+1,v].Y-pts[u,v].Y)*(pts[u+1,v].Y-pts[u,v].Y);
								float vdist=(pts[u,v+1].X-pts[u,v].X)*(pts[u,v+1].X-pts[u,v].X)+
									(pts[u,v+1].Y-pts[u,v].Y)*(pts[u,v+1].Y-pts[u,v].Y);
								maxusize=Math.Max(maxusize,udist);
								maxvsize=Math.Max(maxvsize,vdist);
							}
						}
						us=vs=1<<(int)Math.Log(RdnMath.ClampWrap((reyessamples*(float)Math.Sqrt(Math.Max(maxusize,maxvsize)))/(shadingrate*Math.Max(frm.xsamples,frm.ysamples)),4,Math.Max(frame.Width,frame.Height)),2);
						points=new RdnVector[us+2,vs+2];
						pts=new RdnVector[us+2,vs+2];
						for(u=0;u<=us+1;u++)
						{
							for(v=0;v<=vs+1;v++)
							{
								float ui=RdnMath.LinearInterpolation(u0,u1,(float)u/(float)us);
								float vi=RdnMath.LinearInterpolation(v0,v1,(float)v/(float)vs);
								primitive.PrimitiveProcess(out points[u,v],ui,vi);
								if(displacement==null)
								{
									points[u,v]=transform*points[u,v];
									pts[u,v]=RdnVector.FromRaster(frm.transform*points[u,v],frm.formatwidth,frm.formatheight,frm.formataspect,frame.Width,frame.Height,frm.fovwidth,frm.fovheight,frm.fovnear,frm.fovfar,frm.fovperspective);
								}
							}
						}
						du=1f/(float)us;
						dv=1f/(float)vs;
						if(displacement!=null)
						{						
							for(u=0;u<=us;u++)
							{
								for(v=0;v<=vs;v++)
								{
									RdnVector a=points[u,v+1]-points[u,v];
									RdnVector b=points[u+1,v]-points[u,v];
									RdnVector c=points[u+1,v+1]-points[u+1,v];
									RdnVector d=points[u+1,v+1]-points[u,v+1];
									if(c.Length>a.Length)a=c;
									if(d.Length>b.Length)b=d;
									float ui=RdnMath.LinearInterpolation(u0,u1,(float)u/(float)us);
									float vi=RdnMath.LinearInterpolation(v0,v1,(float)v/(float)vs);
									float s=texcoords[0].X*((1f-ui)*(1f-vi))+texcoords[1].X*((1f-ui)*vi)+texcoords[2].X*(ui*vi)+texcoords[3].X*(ui*(1f-vi));
									float t=texcoords[0].Y*((1f-ui)*(1f-vi))+texcoords[1].Y*((1f-ui)*vi)+texcoords[2].Y*(ui*vi)+texcoords[3].Y*(ui*(1f-vi));
									displacement.DisplacementProcess(ref points[u,v],b.Normalized,a.Normalized,(b^a).Normalized,ui,vi,du,dv,s,t,new RdnRay(frm.position,points[u,v]-frm.position),frm.frame);
									points[u,v]=transform*points[u,v];
									pts[u,v]=RdnVector.FromRaster(frm.transform*points[u,v],frm.formatwidth,frm.formatheight,frm.formataspect,frame.Width,frame.Height,frm.fovwidth,frm.fovheight,frm.fovnear,frm.fovfar,frm.fovperspective);
								}
							}
						}
						float xf=shadingrate*frm.xsamples;
						float yf=shadingrate*frm.ysamples;
						RdnVector ai,bi,ci,di,normali=new RdnVector();
						if(mesh)
						{
							ai=((rdnpolygon)primitive).point01-((rdnpolygon)primitive).point00;
							bi=((rdnpolygon)primitive).point10-((rdnpolygon)primitive).point00;
							ci=((rdnpolygon)primitive).point11-((rdnpolygon)primitive).point10;
							di=((rdnpolygon)primitive).point11-((rdnpolygon)primitive).point01;
							if(ci.Length>ai.Length)ai=ci;
							if(di.Length>bi.Length)bi=di;
							normali=(bi^ai).Normalized;
						}
						for(u=0;u<us;u++)
						{
							for(v=0;v<vs;v++)
							{
								if(RdnMath.PointInBox(-xf,-yf,0f,(float)frame.Width+xf,(float)frame.Height+yf,1f,pts[u,v].X,pts[u,v].Y,pts[u,v].Z))
								{
									bool shading=true;
									if(planes!=null)
									{
										if(union)
										{
											for(int i=0;i<planes.Length;i++)
											{
												if((points[u,v]-planes[i].Point)*planes[i].Normal>0f)
												{
													shading=false;
													break;
												}
											}
										}
										else
										{
											int numcp=0;
											for(int i=0;i<planes.Length;i++)
												if((points[u,v]-planes[i].Point)*planes[i].Normal>0f)
													numcp++;
											if(numcp==planes.Length)
												shading=false;
										}
									}
//									int xi=(int)pts[u,v].X;
//									int yi=(int)pts[u,v].Y;
//									if(((xi>=0)&&(xi<frm.width))&&((yi>=0)&&(yi<frm.height)))
//										if(frame[xi,yi]!=null)
//											if((pts[u,v].Z>frame[xi,yi].Depth+0.01f)&&(frame[xi,yi].Opacity==new RdnColor(1f)))
//												shading=false;
									if(shading)
									{
										RdnColor col=color,opa=opacity;
										RdnVector a=points[u,v+1]-points[u,v];
										RdnVector b=points[u+1,v]-points[u,v];
										RdnVector c=points[u+1,v+1]-points[u+1,v];
										RdnVector d=points[u+1,v+1]-points[u,v+1];
										if(c.Length>a.Length)a=c;
										if(d.Length>b.Length)b=d;
										RdnVector normal=(b^a).Normalized;
										RdnRay incidentray=new RdnRay(RdnRayType.Primary,frm.position,points[u,v]-frm.position);
										int i;
										RdnVector[] mp=null;
										if(invori)
										{
											if(normal*incidentray.Direction<0f)
												mp=new RdnVector[4]{pts[u,v],pts[u,v+1],pts[u+1,v+1],pts[u+1,v]};
											else if(twosides)
												mp=new RdnVector[4]{pts[u,v],pts[u+1,v],pts[u+1,v+1],pts[u,v+1]};
										}
										else
										{
											if(normal*incidentray.Direction<0f)
												mp=new RdnVector[4]{pts[u,v],pts[u+1,v],pts[u+1,v+1],pts[u,v+1]};
											else if(twosides)
												mp=new RdnVector[4]{pts[u,v],pts[u,v+1],pts[u+1,v+1],pts[u+1,v]};
										}
										if(mp!=null)
										{
											nummp++;
											if(illuminate&&surface!=null)
											{
												float ui=RdnMath.LinearInterpolation(u0,u1,(float)u/(float)us);
												float vi=RdnMath.LinearInterpolation(v0,v1,(float)v/(float)vs);
												float s=texcoords[0].X*((1f-ui)*(1f-vi))+texcoords[1].X*((1f-ui)*vi)+texcoords[2].X*(ui*vi)+texcoords[3].X*(ui*(1f-vi));
												float t=texcoords[0].Y*((1f-ui)*(1f-vi))+texcoords[1].Y*((1f-ui)*vi)+texcoords[2].Y*(ui*vi)+texcoords[3].Y*(ui*(1f-vi));
												ArrayList photonlist=new ArrayList();
												for(i=0;i<frm.world.lightsources.Count;i++)
												{
													RdnPhoton[] ps;
													((rdnlightsource)frm.world.lightsources[i]).lightsource.LightSourceProcess(out ps,((rdnlightsource)frm.world.lightsources[i]).position,points[u,v],incidentray,frm.frame);
													if(ps!=null)
														for(int j=0;j<ps.Length;j++)
															photonlist.Add(ps[j]);
												}
												RdnPhoton[] photons=null;
												if(photonlist.Count>0)
												{
													photons=new RdnPhoton[photonlist.Count];
													for(i=0;i<photons.Length;i++)
													{
														photons[i]=((RdnPhoton)photonlist[i]);
														float dist=(points[u,v]-photons[i].Ray.Origin).Length;
														photons[i].Energy=photons[i].Energy*(1f/(frm.world.att2*(dist*dist)+frm.world.att1*dist+frm.world.att0));
													}
												}
												if(mesh)
													surface.SurfaceProcess(ref col,ref opa,points[u,v],b.Normalized,a.Normalized,((normal-normali)+((rdnpolygon)primitive).normal00*((1f-ui)*(1f-vi))+((rdnpolygon)primitive).normal01*((1f-ui)*vi)+((rdnpolygon)primitive).normal11*(ui*vi)+((rdnpolygon)primitive).normal10*(ui*(1f-vi))).Normalized,ui,vi,du,dv,s,t,photons,incidentray,tracelevels,frm.frame);
												else
													surface.SurfaceProcess(ref col,ref opa,points[u,v],b.Normalized,a.Normalized,normal,ui,vi,du,dv,s,t,photons,incidentray,tracelevels,frm.frame);
											}
											if(frm.world.atmosphere!=null)
												frm.world.atmosphere.VolumeProcess(ref col,ref opa,pts[u,v].Z,points[u,v],incidentray,frm.frame);
											if(frm.imager!=null)
												frm.imager.ImagerProcess(ref col,frame.Width,frame.Height,(int)pts[u,v].X,(int)pts[u,v].Y,pts[u,v].Z,id,frm.frame);
											int xmin=(int)mp[0].X,ymin=(int)mp[0].Y;
											int xmax=(int)(mp[0].X+1),ymax=(int)(mp[0].Y+1);
											for(i=1;i<4;i++)
											{
												if((int)mp[i].X<xmin)
													xmin=(int)mp[i].X;
												if((int)(mp[i].X+1)>xmax)
													xmax=(int)(mp[i].X+1);
												if((int)mp[i].Y<ymin)
													ymin=(int)mp[i].Y;
												if((int)(mp[i].Y+1)>ymax)
													ymax=(int)(mp[i].Y+1);
											}
											for(int x=xmin;x<=xmax;x++)
											{	
												for(int y=ymin;y<=ymax;y++)
												{
													int inside=0;
													for(i=0;i<4;i++)
													{
														float ax=mp[(i+1)%4].X-mp[i].X;
														float ay=mp[(i+1)%4].Y-mp[i].Y;
														float bx=(float)x-mp[i].X;
														float by=(float)y-mp[i].Y;
														inside+=((ax*by-ay*bx)>=0f)?1:0;
													}
													if(inside==4)
													{
														if(!hider||matte)
															frame[x,y]=null;
														frame.SetColor(x,y,pts[u,v].Z,col,opa,id);
														if(matte)
															frame.SetMask(x,y,true);
													}
												}
											}
										}
									}
								}
							}
						}
					}
					else
					{
						float udiv=u0+(u1-u0)/2f;
						float vdiv=v0+(v1-v0)/2f;
						raster(ref frame,ref nummp,frm,u0,v0,udiv,vdiv);
						raster(ref frame,ref nummp,frm,udiv,v0,u1,vdiv);
						raster(ref frame,ref nummp,frm,udiv,vdiv,u1,v1);
						raster(ref frame,ref nummp,frm,u0,vdiv,udiv,v1);
					}
				}
			}
		}
		private class rdnmicropolygon : RdnMicroPolygon
		{
			public bool illuminate;
			public float u,v,du,dv;
			public PointF[] texcoords;
			public RdnVector normal;
			public RdnColor color,opacity;
			public RdnShader surface;
		}
		public class rdnpolygon : RdnShader
		{
			public RdnVector point00,point01,point11,point10;
			public RdnVector normal00,normal01,normal11,normal10;

			public override void PrimitiveProcess(out RdnVector point,float u,float v)
			{
				point=point00*((1f-u)*(1f-v))+point01*((1f-u)*v)+point11*(u*v)+point10*(u*(1f-v));
			}
		}
		private rdnframe frm;
		private int mode,ntr,tmp;
		private float bst;
		private Bitmap bitmap;

		public RdnRender()
		{
		}
		public RdnRender(string filename)
		{
		}
		public void FrameBegin(int frame)
		{
			if(mode==0)
			{
				frm=new rdnframe();
				frm.frame=frame;
				frm.formatwidth=640;
				frm.formatheight=480;
				frm.formataspect=1f;
				frm.fovperspective=true;
				frm.fovwidth=1f;
				frm.fovheight=1f;
				frm.fovnear=1f;
				frm.fovfar=1000f;
				frm.position=new RdnVector(0f,0f,-10f);
				frm.target=new RdnVector(0f,0f,0f);
				frm.up=new RdnVector(0f,1f,0f);
				frm.xsamples=frm.ysamples=1;
				DateTime dt=DateTime.Now;
				bst=((float)dt.Hour)*3600f+((float)dt.Minute)*60f+((float)dt.Second)+((float)dt.Millisecond)/1000f;
				mode=1;
			}
		}
		public void Format(int width,int height,float aspect)
		{
			if(mode==1)
			{
				frm.formatwidth=width;
				frm.formatheight=height;
				frm.formataspect=aspect;
			}
		}
		public void Sampling(int xsamples,int ysamples,RdnFilter filter)
		{
			if(mode==1)
			{
				frm.xsamples=xsamples;
				frm.ysamples=ysamples;
				frm.filter=filter;
			}
		}
		public void Sampling(int xsamples,int ysamples)
		{
			Sampling(xsamples,ysamples,null);
		}
		public void View(RdnVector position,RdnVector target,RdnVector up,float roll)
		{
			if(mode==1)
			{
				frm.position=position;
				frm.target=target;
				frm.up=up;
				frm.roll=roll;
				frm.transform=new RdnMatrix();
				frm.transform.LookAt(position,target,up);
				RdnMatrix rol=new RdnMatrix();
				rol.RotateZ(roll);
				frm.transform=rol*frm.transform;
			}
		}
		public void FieldOfView(float width,float height,float near,float far,bool perspective)
		{
			if(mode==1)
			{
				frm.fovwidth=width;
				frm.fovheight=height;
				frm.fovnear=near;
				frm.fovfar=far;
				frm.fovperspective=perspective;
			}
		}
		public void DepthOfField(float fstop,float focallength,float focaldistance,int minradius,int maxradius)
		{
			if(mode==1)
			{
				frm.doffstop=fstop;
				frm.doffocallength=focallength;
				frm.doffocaldistance=focaldistance;
				frm.dofminradius=minradius;
				frm.dofmaxradius=maxradius;
			}
		}
		public void Exposure(RdnColor gain,RdnColor gamma)
		{
			if(mode==1)
			{
				frm.gain=gain;
				frm.gamma=gamma;
			}
		}
		public void Imager(RdnShader shader)
		{
			if(mode==1)
				frm.imager=shader;
		}
		public void Shutter(bool open)
		{
			if(mode==1)
				frm.open=open;
		}
		public void WorldBegin()
		{
			if(mode==1)
			{
				frm.world=new rdnworld();
				frm.world.transforms=new ArrayList();
				frm.world.lightsources=new ArrayList();
				frm.world.particles=new ArrayList();
				frm.world.primitives=new ArrayList();
				frm.world.meshs=new ArrayList();
				frm.world.transform=new RdnMatrix();
				frm.world.transform.Identity();
				frm.world.color=frm.world.opacity=new RdnColor(1f);
				frm.world.reyessamples=16;
				frm.world.tracesamples=64;
				frm.world.tracelevels=3;
				frm.world.shadingrate=1f;
				frm.world.hider=true;
				frm.world.matte=false;
				frm.world.u0=0f;
				frm.world.v0=0f;
				frm.world.u1=1f;
				frm.world.v1=1f;
				frm.world.texcoords=new PointF[4]{new PointF(0f,0f),new PointF(0f,1f),new PointF(1f,1f),new PointF(1f,0f)};
				frm.world.att0=new RdnColor(1f);
				frm.world.planes=null;
				mode=2;
			}
		}
		public void Attenuation(RdnColor att2,RdnColor att1,RdnColor att0)
		{
			if(mode==2)
			{
				frm.world.att2=att2;
				frm.world.att1=att1;
				frm.world.att0=att0;
			}
		}
		public void Atmosphere(RdnShader shader)
		{
			if(mode==2)
				frm.world.atmosphere=shader;
		}
		public void TransformBegin()
		{
			if(mode==2)
			{
				RdnMatrix mat=new RdnMatrix();
				mat.Identity();
				frm.world.transforms.Add(mat);
			}
		}
		public void Transform(RdnMatrix matrix)
		{
			if(mode==2)
			{
				if(frm.world.transforms.Count>0)
					frm.world.transforms[frm.world.transforms.Count-1]=matrix;
				else
					frm.world.transform=matrix;
			}
		}		
		public void Identity()
		{
			if(mode==2)
			{
				if(frm.world.transforms.Count>0)
					((RdnMatrix)frm.world.transforms[frm.world.transforms.Count-1]).Identity();
				else
					frm.world.transform.Identity();
			}
		}
		public void Translate(float x,float y,float z)
		{
			if(mode==2)
			{
				RdnMatrix mat=new RdnMatrix();
				mat.Translate(x,y,z);
				if(frm.world.transforms.Count>0)
					frm.world.transforms[frm.world.transforms.Count-1]=((RdnMatrix)frm.world.transforms[frm.world.transforms.Count-1])*mat;
				else
					frm.world.transform=frm.world.transform*mat;
			}
		}
		public void RotateX(float angle)
		{
			if(mode==2)
			{
				RdnMatrix mat=new RdnMatrix();
				mat.RotateX(angle);
				if(frm.world.transforms.Count>0)
					frm.world.transforms[frm.world.transforms.Count-1]=((RdnMatrix)frm.world.transforms[frm.world.transforms.Count-1])*mat;
				else
					frm.world.transform=frm.world.transform*mat;
			}
		}
		public void RotateY(float angle)
		{
			if(mode==2)
			{
				RdnMatrix mat=new RdnMatrix();
				mat.RotateY(angle);
				if(frm.world.transforms.Count>0)
					frm.world.transforms[frm.world.transforms.Count-1]=((RdnMatrix)frm.world.transforms[frm.world.transforms.Count-1])*mat;
				else
					frm.world.transform=frm.world.transform*mat;
			}
		}
		public void RotateZ(float angle)
		{
			if(mode==2)
			{
				RdnMatrix mat=new RdnMatrix();
				mat.RotateZ(angle);
				if(frm.world.transforms.Count>0)
					frm.world.transforms[frm.world.transforms.Count-1]=((RdnMatrix)frm.world.transforms[frm.world.transforms.Count-1])*mat;
				else
					frm.world.transform=frm.world.transform*mat;
			}
		}
		public void ShearXY(float x,float y)
		{
			if(mode==2)
			{
				RdnMatrix mat=new RdnMatrix();
				mat.ShearXY(x,y);
				if(frm.world.transforms.Count>0)
					frm.world.transforms[frm.world.transforms.Count-1]=((RdnMatrix)frm.world.transforms[frm.world.transforms.Count-1])*mat;
				else
					frm.world.transform=frm.world.transform*mat;
			}
		}
		public void ShearXZ(float x,float z)
		{
			if(mode==2)
			{
				RdnMatrix mat=new RdnMatrix();
				mat.ShearXZ(x,z);
				if(frm.world.transforms.Count>0)
					frm.world.transforms[frm.world.transforms.Count-1]=((RdnMatrix)frm.world.transforms[frm.world.transforms.Count-1])*mat;
				else
					frm.world.transform=frm.world.transform*mat;
			}
		}
		public void ShearYZ(float y,float z)
		{
			if(mode==2)
			{
				RdnMatrix mat=new RdnMatrix();
				mat.ShearYZ(y,z);
				if(frm.world.transforms.Count>0)
					frm.world.transforms[frm.world.transforms.Count-1]=((RdnMatrix)frm.world.transforms[frm.world.transforms.Count-1])*mat;
				else
					frm.world.transform=frm.world.transform*mat;
			}
		}
		public void Scale(float x,float y,float z)
		{
			if(mode==2)
			{
				RdnMatrix mat=new RdnMatrix();
				mat.Scale(x,y,z);
				if(frm.world.transforms.Count>0)
					frm.world.transforms[frm.world.transforms.Count-1]=((RdnMatrix)frm.world.transforms[frm.world.transforms.Count-1])*mat;
				else
					frm.world.transform=frm.world.transform*mat;
			}
		}
		public void Scale(float val)
		{
			Scale(val,val,val);
		}
		public void LightSource(RdnShader shader)
		{
			if(mode==2)
			{
				rdnlightsource light=new rdnlightsource();
				RdnMatrix transform=new RdnMatrix();
				transform.Identity();
				for(int t=frm.world.transforms.Count-1;t>=0;t--)
					transform=((RdnMatrix)frm.world.transforms[t])*transform;
				light.position=(frm.world.transform*transform)*(new RdnVector(0f,0f,0f));
				light.lightsource=shader;
				frm.world.lightsources.Add(light);
			}
		}
		public void Color(RdnColor color)
		{
			if(mode==2)
				frm.world.color=color;
		}
		public void Opacity(RdnColor opacity)
		{
			if(mode==2)
				frm.world.opacity=opacity;
		}
		public void Displacement(RdnShader shader)
		{
			if(mode==2)
				frm.world.displacement=shader;
		}
		public void Surface(RdnShader shader)
		{
			if(mode==2)
				frm.world.surface=shader;
		}
		public void Illuminate(bool on)
		{
			if(mode==2)
				frm.world.illuminate=on;
		}
		public void Id(int val)
		{
			if(mode==2)
				frm.world.id=val;
		}
		public void Hider(bool on)
		{
			if(mode==2)
				frm.world.hider=on;
		}
		public void Matte(bool on)
		{
			if(mode==2)
				frm.world.matte=on;
		}
		public void Sides(bool two)
		{
			if(mode==2)
				frm.world.twosides=two;
		}
		public void Orientation(bool inverse)
		{
			if(mode==2)
				frm.world.invori=inverse;
		}
		public void Options(int reyessamples,int tracesamples,int tracelevels,float shadingrate)
		{
			if(mode==2)
			{
				frm.world.reyessamples=reyessamples;
				frm.world.tracesamples=tracesamples;
				frm.world.tracelevels=tracelevels;
				frm.world.shadingrate=shadingrate;
			}
		}
		public void ClippingPlanes(RdnClippingPlane[] planes,bool union)
		{
			if(mode==2)
			{
				if(planes!=null)
				{
					RdnMatrix transform=new RdnMatrix();
					transform.Identity();
					for(int t=frm.world.transforms.Count-1;t>=0;t--)
						transform=((RdnMatrix)frm.world.transforms[t])*transform;
					transform=frm.world.transform*transform;
					frm.world.planes=new RdnClippingPlane[planes.Length];
					for(int i=0;i<frm.world.planes.Length;i++)
					{
						RdnClippingPlane plane=new RdnClippingPlane();
						plane.Point=transform*planes[i].Point;
						plane.Normal=transform.VectorTransform(planes[i].Normal,0f);
						frm.world.planes[i]=plane;
					}
					frm.world.union=union;
				}
				else
					frm.world.planes=null;
			}
		}
		public void SurfaceCoordinates(float u0,float v0,float u1,float v1)
		{
			if(mode==2)
			{
				frm.world.u0=u0;
				frm.world.v0=v0;
				frm.world.u1=u1;
				frm.world.v1=v1;
			}
		}
		public void TextureCoordinates(float s0,float t0,float s1,float t1,float s2,float t2,float s3,float t3)
		{
			if(mode==2)
				frm.world.texcoords=new PointF[4]{new PointF(s0,t0),new PointF(s1,t1),new PointF(s2,t2),new PointF(s3,t3)};
		}
		public void Particle(RdnVector point,float size)
		{
			if(mode==2)
			{
				rdnparticle particle=new rdnparticle();
				RdnMatrix transform=new RdnMatrix();
				transform.Identity();
				for(int t=frm.world.transforms.Count-1;t>=0;t--)
					transform=((RdnMatrix)frm.world.transforms[t])*transform;
				particle.point=(frm.world.transform*transform)*point;
				particle.size=size;
				particle.id=frm.world.id;
				particle.illuminate=frm.world.illuminate;
				particle.matte=frm.world.matte;
				particle.hider=frm.world.hider;
				particle.color=frm.world.color;
				particle.opacity=frm.world.opacity;
				frm.world.particles.Add(particle);
			}
		}
		public void Primitive(RdnShader shader)
		{
			if(mode==2)
			{
				if(shader!=null)
				{
					rdnprimitive primitive=new rdnprimitive();
					primitive.transform=new RdnMatrix();
					primitive.transform.Identity();
					for(int t=frm.world.transforms.Count-1;t>=0;t--)
						primitive.transform=((RdnMatrix)frm.world.transforms[t])*primitive.transform;
					primitive.transform=frm.world.transform*primitive.transform;
					primitive.matte=frm.world.matte;
					primitive.hider=frm.world.hider;
					primitive.invori=frm.world.invori;
					primitive.twosides=frm.world.twosides;
					primitive.reyessamples=frm.world.reyessamples;
					primitive.tracesamples=frm.world.tracesamples;
					primitive.tracelevels=frm.world.tracelevels;
					primitive.shadingrate=frm.world.shadingrate;
					primitive.u0=frm.world.u0;
					primitive.v0=frm.world.v0;
					primitive.u1=frm.world.u1;
					primitive.v1=frm.world.v1;
					primitive.id=frm.world.id;
					primitive.texcoords=frm.world.texcoords;
					primitive.displacement=frm.world.displacement;
					primitive.surface=frm.world.surface;
					primitive.primitive=shader;
					primitive.illuminate=frm.world.illuminate;
					primitive.color=frm.world.color;
					primitive.opacity=frm.world.opacity;
					primitive.planes=frm.world.planes;
					primitive.union=frm.world.union;
					frm.world.primitives.Add(primitive);
				}
			}
		}
		public void Mesh(RdnMesh mesh)
		{
			if(mode==2)
			{
				if(mesh!=null)
				{
					for(int i=0;i<mesh.Faces.Length;i++)
					{
						RdnVertex a=mesh.Vertices[mesh.Faces[i].A];
						RdnVertex b=mesh.Vertices[mesh.Faces[i].B];
						RdnVertex c=mesh.Vertices[mesh.Faces[i].C];
						RdnVertex d=mesh.Vertices[mesh.Faces[i].D];
						TextureCoordinates(a.TexCoord.X,a.TexCoord.Y,b.TexCoord.X,b.TexCoord.Y,c.TexCoord.X,c.TexCoord.Y,d.TexCoord.X,d.TexCoord.Y);
						rdnpolygon poly=new rdnpolygon();
						poly.point00=a.Point;
						poly.point01=b.Point;
						poly.point11=c.Point;
						poly.point10=d.Point;
						rdnprimitive primitive=new rdnprimitive();
						primitive.transform=new RdnMatrix();
						primitive.transform.Identity();
						primitive.transform=primitive.transform*mesh.Transform;
						for(int t=frm.world.transforms.Count-1;t>=0;t--)
							primitive.transform=((RdnMatrix)frm.world.transforms[t])*primitive.transform;
						primitive.transform=frm.world.transform*primitive.transform;
						poly.normal00=primitive.transform.VectorTransform(a.Normal,0f).Normalized;
						poly.normal01=primitive.transform.VectorTransform(b.Normal,0f).Normalized;
						poly.normal11=primitive.transform.VectorTransform(c.Normal,0f).Normalized;
						poly.normal10=primitive.transform.VectorTransform(d.Normal,0f).Normalized;
						primitive.matte=frm.world.matte;
						primitive.hider=frm.world.hider;
						primitive.invori=frm.world.invori;
						primitive.twosides=frm.world.twosides;
						primitive.reyessamples=frm.world.reyessamples;
						primitive.tracesamples=frm.world.tracesamples;
						primitive.tracelevels=frm.world.tracelevels;
						primitive.shadingrate=frm.world.shadingrate;
						primitive.u0=frm.world.u0;
						primitive.v0=frm.world.v0;
						primitive.u1=frm.world.u1;
						primitive.v1=frm.world.v1;
						primitive.id=frm.world.id;
						primitive.texcoords=frm.world.texcoords;
						primitive.displacement=frm.world.displacement;
						primitive.surface=frm.world.surface;
						primitive.primitive=poly;
						primitive.illuminate=frm.world.illuminate;
						primitive.color=frm.world.color;
						primitive.opacity=frm.world.opacity;
						primitive.mesh=true;
						primitive.planes=frm.world.planes;
						primitive.union=frm.world.union;
						frm.world.primitives.Add(primitive);
					}
				}
			}
		}
		public void TransformEnd()
		{
			if(mode==2)
			{
				if(frm.world.transforms.Count>0)
					frm.world.transforms.RemoveAt(frm.world.transforms.Count-1);
			}
		}
		public void WorldEnd()
		{
			if(mode==2)
				mode=1;
		}
		public void FrameEnd()
		{
			if(mode==1)
			{
				tmp=0;
				frm.width=frm.formatwidth*frm.xsamples;
				frm.height=frm.formatheight*frm.ysamples;
				int dim=(int)(frm.fovfar-frm.fovnear);
				RdnBox otb=new RdnBox(dim,dim,dim);
				otb.Offset(frm.position.X,frm.position.Y,frm.position.Z);
				micropolygonmap=new RdnMicroPolygonMap(otb,null);
				for(int i=0;i<frm.world.primitives.Count;i++)
				{
					if(((rdnprimitive)frm.world.primitives[i]).tracesamples>0&&((rdnprimitive)frm.world.primitives[i]).tracelevels>0)
					{
						RdnMicroGrid mg=new RdnMicroGrid(((rdnprimitive)frm.world.primitives[i]).tracesamples+1,((rdnprimitive)frm.world.primitives[i]).tracesamples+1);
						float du=1f/(float)(mg.USize-1);
						float dv=1f/(float)(mg.VSize-1);
						for(int u=0;u<=mg.USize;u++)
						{
							for(int v=0;v<=mg.VSize;v++)
							{
								RdnVector p;
								float ui=RdnMath.LinearInterpolation(((rdnprimitive)frm.world.primitives[i]).u0,((rdnprimitive)frm.world.primitives[i]).u1,((float)u)*du);
								float vi=RdnMath.LinearInterpolation(((rdnprimitive)frm.world.primitives[i]).v0,((rdnprimitive)frm.world.primitives[i]).v1,((float)v)*dv);
								((rdnprimitive)frm.world.primitives[i]).primitive.PrimitiveProcess(out p,ui,vi);
								if(((rdnprimitive)frm.world.primitives[i]).displacement!=null)
									mg[u,v]=p;
								else
									mg[u,v]=((rdnprimitive)frm.world.primitives[i]).transform*p;
							}
						}
						if(((rdnprimitive)frm.world.primitives[i]).displacement!=null)
						{	
							for(int u=0;u<mg.USize;u++)
							{
								for(int v=0;v<mg.VSize;v++)
								{
									RdnVector p=mg[u,v];
									RdnVector dPdu=mg.GetMicroPolygon(u,v).dPdu;
									RdnVector dPdv=mg.GetMicroPolygon(u,v).dPdv;
									float ui=RdnMath.LinearInterpolation(((rdnprimitive)frm.world.primitives[i]).u0,((rdnprimitive)frm.world.primitives[i]).u1,((float)u)*du);
									float vi=RdnMath.LinearInterpolation(((rdnprimitive)frm.world.primitives[i]).v0,((rdnprimitive)frm.world.primitives[i]).v1,((float)v)*dv);
									float s=((rdnprimitive)frm.world.primitives[i]).texcoords[0].X*((1f-ui)*(1f-vi))+((rdnprimitive)frm.world.primitives[i]).texcoords[1].X*((1f-ui)*vi)+((rdnprimitive)frm.world.primitives[i]).texcoords[2].X*(ui*vi)+((rdnprimitive)frm.world.primitives[i]).texcoords[3].X*(ui*(1f-vi));
									float t=((rdnprimitive)frm.world.primitives[i]).texcoords[0].Y*((1f-ui)*(1f-vi))+((rdnprimitive)frm.world.primitives[i]).texcoords[1].Y*((1f-ui)*vi)+((rdnprimitive)frm.world.primitives[i]).texcoords[2].Y*(ui*vi)+((rdnprimitive)frm.world.primitives[i]).texcoords[3].Y*(ui*(1f-vi));
									((rdnprimitive)frm.world.primitives[i]).displacement.DisplacementProcess(ref p,dPdu,dPdv,dPdu^dPdv,u,v,du,dv,s,t,new RdnRay(frm.position,p-frm.position),frm.frame);
									mg[u,v]=((rdnprimitive)frm.world.primitives[i]).transform*p;
								}
							}
						}
						RdnVector ai,bi,ci,di,normali=new RdnVector();
						if(((rdnprimitive)frm.world.primitives[i]).mesh)
						{
							rdnpolygon rmp=(rdnpolygon)((rdnprimitive)frm.world.primitives[i]).primitive;
							ai=rmp.point01-rmp.point00;
							bi=rmp.point10-rmp.point00;
							ci=rmp.point11-rmp.point10;
							di=rmp.point11-rmp.point01;
							if(ci.Length>ai.Length)ai=ci;
							if(di.Length>bi.Length)bi=di;
							normali=(bi^ai).Normalized;
						}
						for(int u=0;u<mg.USize-1;u++)
						{
							for(int v=0;v<mg.VSize-1;v++)
							{
								RdnMicroPolygon mp=mg.GetMicroPolygon(u,v);
								rdnmicropolygon mpi=new rdnmicropolygon();
								mpi.Point00=mp.Point00;
								mpi.Point01=mp.Point01;
								mpi.Point11=mp.Point11;
								mpi.Point10=mp.Point10;
								mpi.illuminate=((rdnprimitive)frm.world.primitives[i]).illuminate;
								mpi.u=RdnMath.LinearInterpolation(((rdnprimitive)frm.world.primitives[i]).u0,((rdnprimitive)frm.world.primitives[i]).u1,((float)u)*du);
								mpi.v=RdnMath.LinearInterpolation(((rdnprimitive)frm.world.primitives[i]).v0,((rdnprimitive)frm.world.primitives[i]).v1,((float)v)*dv);
								mpi.du=du;mpi.dv=dv;
								mpi.texcoords=((rdnprimitive)frm.world.primitives[i]).texcoords;
								mpi.color=((rdnprimitive)frm.world.primitives[i]).color;
								mpi.opacity=((rdnprimitive)frm.world.primitives[i]).opacity;
								mpi.surface=((rdnprimitive)frm.world.primitives[i]).surface;
								if(micropolygonmap.Box.PointIn(mpi))
								{
									if(((rdnprimitive)frm.world.primitives[i]).mesh)
									{
										rdnpolygon rmp=(rdnpolygon)((rdnprimitive)frm.world.primitives[i]).primitive;
										float ui=(float)u/(float)mg.USize;
										float vi=(float)v/(float)mg.VSize;
										mpi.normal=((mpi.Normal-normali)+(rmp.normal00*((1f-ui)*(1f-vi))+rmp.normal01*((1f-ui)*vi)+rmp.normal11*(ui*vi)+rmp.normal10*(ui*(1f-vi)))).Normalized;
									}
									else
										mpi.normal=mpi.Normal;
									micropolygonmap.AddMicroPolygon(mpi);
									tmp++;
								}
							}
						}
					}
				}
				micropolygonmap.Optimize();
				micropolygonmap.SubDivide(4,(int)Math.Log(Math.Max(micropolygonmap.Box.Distances.X,Math.Max(micropolygonmap.Box.Distances.Y,micropolygonmap.Box.Distances.Z)),2));
				mode=0;
				directphotonmap=new RdnPhotonMap();
				globalphotonmap=new RdnPhotonMap();
				causticphotonmap=new RdnPhotonMap();
				for(int i=0;i<frm.world.lightsources.Count;i++)
				{
					RdnPhoton[] ps;
					((rdnlightsource)frm.world.lightsources[i]).lightsource.LightSourceEmitterProcess(out ps,((rdnlightsource)frm.world.lightsources[i]).position,frm.frame);
					if(ps!=null)
						for(int j=0;j<ps.Length;j++)
							((rdnlightsource)frm.world.lightsources[i]).Trace(this,frm,ps[j],frm.world.tracelevels);
				}	
				directphotonmap.Balance(10);
				globalphotonmap.Balance(10);
				causticphotonmap.Balance(10);
				DateTime dt=DateTime.Now;
				bst=(((float)dt.Hour)*3600f+((float)dt.Minute)*60f+((float)dt.Second)+((float)dt.Millisecond)/1000f)-bst;
			}
		}
		public void Save(string filename)
		{
			if(mode==0)
			{
			}
		}
		public RdnRasterState Raster()
		{
			RdnRasterState rasterstate=new RdnRasterState();
			if(mode==0)
			{
				ntr=0;
				DateTime dt=DateTime.Now;
				float rtime=((float)dt.Hour)*3600f+((float)dt.Minute)*60f+((float)dt.Second)+((float)dt.Millisecond)/1000f;
				RdnFrame frame=new RdnFrame(frm.formatwidth*frm.xsamples,frm.formatheight*frm.ysamples);
				if(frm.imager!=null)
				{
					for(int x=0;x<frame.Width;x++)
					{
						for(int y=0;y<frame.Height;y++)
						{
							RdnColor col=new RdnColor(0f);
							frm.imager.ImagerProcess(ref col,frame.Width,frame.Height,x,y,1f,-1,frm.frame);
							frame.SetBack(x,y,col);
						}
					}
				}
				for(int i=0;i<frm.world.particles.Count;i++)
					((rdnparticle)frm.world.particles[i]).raster(ref frame,frm);
				for(int i=0;i<frm.world.primitives.Count;i++)
					((rdnprimitive)frm.world.primitives[i]).raster(ref frame,ref rasterstate.ReyesMicroPolygons,frm,((rdnprimitive)frm.world.primitives[i]).u0,((rdnprimitive)frm.world.primitives[i]).v0,((rdnprimitive)frm.world.primitives[i]).u1,((rdnprimitive)frm.world.primitives[i]).v1);
				if(!frm.open)
					bitmap=new Bitmap(frm.formatwidth,frm.formatheight);
				BitmapData bd=bitmap.LockBits(new Rectangle(0,0,frm.formatwidth,frm.formatheight),ImageLockMode.WriteOnly,PixelFormat.Format32bppArgb);
				unsafe
				{
					int* pixels=(int*)bd.Scan0;
					int sd=bd.Stride/4;
					for(int x=0;x<frm.formatwidth;x++)
					{
						for(int y=0;y<frm.formatheight;y++)
						{
							RdnColor col=new RdnColor(0f);
							if(frm.doffstop>0f)
							{
								float depth=1f;
								if(frame[x*frm.xsamples,y*frm.ysamples]!=null)
									depth=frame[x*frm.xsamples,y*frm.ysamples].Depth;
								float C=(frm.doffocallength/frm.doffstop)*((frm.doffocaldistance*frm.doffocallength)/(frm.doffocaldistance-frm.doffocallength))*Math.Abs((1f/(depth*(frm.fovfar-frm.fovnear)+frm.fovnear))-(1f/frm.doffocaldistance));
								int level=(int)RdnMath.ClampWrap(C,frm.dofminradius,frm.dofmaxradius);
								float ddiv=level*level;
								if(level>1)
								{
									RdnColor dcol=new RdnColor(0f);
									for(int dx=0;dx<level;dx++)
										for(int dy=0;dy<level;dy++)
											dcol=dcol+frame.GetColor((x+(int)(dx-(level/2-1)))*frm.xsamples,(y+(int)(dy-(level/2-1)))*frm.ysamples);
									col=dcol/ddiv;
								}
								else
									col=frame.GetColor(x,y,frm.xsamples,frm.ysamples,frm.filter);
							}
							else
								col=frame.GetColor(x,y,frm.xsamples,frm.ysamples,frm.filter);
							if(frm.gamma!=new RdnColor(0f))
							{
								col.Red=(float)Math.Pow(col.Red*frm.gain.Red,frm.gamma.Red);
								col.Green=(float)Math.Pow(col.Green*frm.gain.Green,frm.gamma.Green);
								col.Blue=(float)Math.Pow(col.Blue*frm.gain.Blue,frm.gamma.Blue);
							}
							if(frm.open)
								col=(col+RdnColor.FromColor(System.Drawing.Color.FromArgb(pixels[y*sd+x])))/2f;
							pixels[y*sd+x]=col.Clamped.ToColor().ToArgb();
						}
					}
				}
				bitmap.UnlockBits(bd);
				dt=DateTime.Now;
				rtime=(((float)dt.Hour)*3600f+((float)dt.Minute)*60f+((float)dt.Second)+((float)dt.Millisecond)/1000f)-rtime;
				rasterstate.LightSources=frm.world.lightsources.Count;
				rasterstate.Particles=frm.world.particles.Count;
				rasterstate.Primitives=frm.world.primitives.Count;
				rasterstate.ReyesMicroPolygons=rasterstate.ReyesMicroPolygons+rasterstate.Particles;
				rasterstate.TraceMicroPolygons=tmp;
				rasterstate.TraceRays=ntr;
				rasterstate.BuildTime=Math.Max(0f,bst);
				rasterstate.RenderTime=Math.Max(0f,rtime);
				rasterstate.Frame=frame;
				rasterstate.Image=bitmap;
			}
			return rasterstate;
		}
		public RdnCastState Cast(RdnRay ray)
		{
			RdnCastState caststate=new RdnCastState();
			if(mode==0)
			{
				ntr++;
				caststate.Ray=ray;
				caststate.MicroPolygon=ray.CastMicroPolygons(out caststate.Dist,out caststate.U,out caststate.V,frm.fovnear,frm.fovfar,micropolygonmap);
				if(caststate.MicroPolygon!=null)
				{
					caststate.U=((rdnmicropolygon)caststate.MicroPolygon).v+(caststate.U)*((rdnmicropolygon)caststate.MicroPolygon).du;
					caststate.V=((rdnmicropolygon)caststate.MicroPolygon).u+(caststate.V)*((rdnmicropolygon)caststate.MicroPolygon).dv;
					caststate.U=1f-caststate.U;
					PointF[] sc=new PointF[1];
					sc[0]=new PointF(caststate.U-0.5f,caststate.V-0.5f);
					Matrix rot=new Matrix();
					rot.Rotate(-90f);
					rot.TransformPoints(sc);
					caststate.U=sc[0].X+0.5f;
					caststate.V=sc[0].Y+0.5f;
					caststate.S=((rdnmicropolygon)caststate.MicroPolygon).texcoords[0].X*((1f-caststate.U)*(1f-caststate.V))+((rdnmicropolygon)caststate.MicroPolygon).texcoords[1].X*((1f-caststate.U)*caststate.V)+((rdnmicropolygon)caststate.MicroPolygon).texcoords[2].X*(caststate.U*caststate.V)+((rdnmicropolygon)caststate.MicroPolygon).texcoords[3].X*(caststate.U*(1f-caststate.V));
					caststate.T=((rdnmicropolygon)caststate.MicroPolygon).texcoords[0].Y*((1f-caststate.U)*(1f-caststate.V))+((rdnmicropolygon)caststate.MicroPolygon).texcoords[1].Y*((1f-caststate.U)*caststate.V)+((rdnmicropolygon)caststate.MicroPolygon).texcoords[2].Y*(caststate.U*caststate.V)+((rdnmicropolygon)caststate.MicroPolygon).texcoords[3].Y*(caststate.U*(1f-caststate.V));
					caststate.Point=ray.GetPoint(caststate.Dist);
					caststate.Normal=((rdnmicropolygon)caststate.MicroPolygon).normal;
				}
			}
			return caststate;
		}
		public RdnTraceState Trace(RdnRay ray,int levels)
		{
			RdnTraceState tracestate=new RdnTraceState();
			if(mode==0)
			{
				if(levels>0)
				{
					tracestate.CastState=Cast(ray);
					if(tracestate.CastState.MicroPolygon!=null)
					{
						tracestate.Color=((rdnmicropolygon)tracestate.CastState.MicroPolygon).color;
						tracestate.Opacity=((rdnmicropolygon)tracestate.CastState.MicroPolygon).opacity;
						if(((rdnmicropolygon)tracestate.CastState.MicroPolygon).illuminate&&((rdnmicropolygon)tracestate.CastState.MicroPolygon).surface!=null)
						{
							ArrayList photonlist=new ArrayList();
							for(int i=0;i<frm.world.lightsources.Count;i++)
							{
								RdnPhoton[] ps;
								((rdnlightsource)frm.world.lightsources[i]).lightsource.LightSourceProcess(out ps,((rdnlightsource)frm.world.lightsources[i]).position,tracestate.CastState.Point,tracestate.CastState.Ray,frm.frame);
								if(ps!=null)
									for(int j=0;j<ps.Length;j++)
										photonlist.Add(ps[j]);
							}
							RdnPhoton[] photons=null;
							if(photonlist.Count>0)
							{
								photons=new RdnPhoton[photonlist.Count];
								for(int i=0;i<photons.Length;i++)
								{
									photons[i]=((RdnPhoton)photonlist[i]);
									float dist=(tracestate.CastState.Point-photons[i].Ray.Origin).Length;
									photons[i].Energy=photons[i].Energy*(1f/(frm.world.att2*(dist*dist)+frm.world.att1*dist+frm.world.att0));
								}
							}
							((rdnmicropolygon)tracestate.CastState.MicroPolygon).surface.SurfaceProcess(ref tracestate.Color,ref tracestate.Opacity,tracestate.CastState.Point,tracestate.CastState.MicroPolygon.dPdu,tracestate.CastState.MicroPolygon.dPdv,tracestate.CastState.Normal,tracestate.CastState.U,tracestate.CastState.V,((rdnmicropolygon)tracestate.CastState.MicroPolygon).du,((rdnmicropolygon)tracestate.CastState.MicroPolygon).dv,tracestate.CastState.S,tracestate.CastState.T,photons,tracestate.CastState.Ray,levels-1,frm.frame);
						}
						if(frm.world.atmosphere!=null)
							frm.world.atmosphere.VolumeProcess(ref tracestate.Color,ref tracestate.Opacity,1f-((frm.fovfar-tracestate.CastState.Dist)/(frm.fovfar-frm.fovnear)),tracestate.CastState.Ray.GetPoint(tracestate.CastState.Dist),tracestate.CastState.Ray,frm.frame);
					}
					else
					{
						tracestate.Opacity=new RdnColor(1f);
						if(frm.imager!=null)
						{
							float m=2f*(ray.Direction+(frm.target-frm.position).Normalized).Length;
							float s=ray.Direction.X/m+0.5f;
							float t=ray.Direction.Y/m+0.5f;
							frm.imager.ImagerProcess(ref tracestate.Color,frm.width,frm.height,(int)(RdnMath.ClampWrap(s,0f,1f)*(frm.width-1)),(int)(RdnMath.ClampWrap(t,0f,1f)*(frm.height-1)),1f,-1,frm.frame);
						}
					}
				}
			}
			return tracestate;
		}

		public RdnMicroPolygonMap MicroPolygonMap
		{ 
			get
			{
				return micropolygonmap;
			}
		}
		public RdnPhotonMap DirectPhotonMap
		{ 
			get
			{
				return directphotonmap;
			}
		}
		public RdnPhotonMap GlobalPhotonMap
		{ 
			get
			{
				return globalphotonmap;
			}
		}
		public RdnPhotonMap CausticPhotonMap
		{ 
			get
			{
				return causticphotonmap;
			}
		}
	}

	public struct RdnClippingPlane
	{
		public RdnClippingPlane(RdnVector point,RdnVector normal)
		{
			Point=point;Normal=normal;
		}

		public RdnVector Point,Normal;
	}
	public struct RdnRasterState
	{
		public int LightSources,Particles,Primitives,TraceRays;
		public int ReyesMicroPolygons,TraceMicroPolygons;
		public float BuildTime,RenderTime;
		public RdnFrame Frame;
		public Bitmap Image;
	}
	public struct RdnCastState
	{
		public RdnRay Ray;
		public float Dist,U,V,S,T;
		public RdnVector Point,Normal;
		public RdnMicroPolygon MicroPolygon;
	}
	public struct RdnTraceState
	{
		public RdnCastState CastState;
		public RdnColor Color,Opacity;
	}
}