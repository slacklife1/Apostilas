using System;
using Rdn.Basis;

namespace Rdn
{
	/// <summary>
	/// Summary description for RdnFrame.
	/// </summary>
	public class RdnFragment
	{
		public float Depth;
		public RdnColor Color,Opacity;
		public int Id;
		public RdnFragment Next;
	
		public RdnFragment(){}
		public RdnFragment(float depth,RdnColor color,RdnColor opacity,int id,RdnFragment next)
		{
			this.Depth=depth;
			this.Color=color;
			this.Opacity=opacity;
			this.Id=id;
			this.Next=next;
		}
	}

	public class RdnFrame
	{
		private RdnColor[,] back;
		private RdnFragment[,] fragments;
		private bool[,] mask;
		private int width,height;

		public RdnFrame(int width,int height)
		{
			this.width=width;
			this.height=height;
			back=new RdnColor[width,height];
			fragments=new RdnFragment[width,height];
			mask=new bool[width,height];
		}

		public void ClearBack()
		{
			back=new RdnColor[width,height];
		}
		public void SetBack(int x,int y,RdnColor color)	
		{
			back[x,y]=color;
		}
		public RdnColor GetBack(int x,int y)	
		{
			return back[x,y];
		}
		public void ClearMask()
		{
			mask=new bool[width,height];
		}
		public void SetMask(int x,int y,bool on)	
		{
			mask[x,y]=on;
		}
		public bool GetMask(int x,int y)	
		{
			return mask[x,y];
		}
		public void ClearFragments()
		{
			fragments=new RdnFragment[width,height];
		}		
		public void SetColor(ref RdnFragment fragment,float depth,RdnColor color,RdnColor opacity,int id)
		{
			if(depth<=fragment.Depth)
			{
				if(opacity.Intensity<1f)
					fragment=new RdnFragment(depth,color,opacity,id,fragment);
				else
					fragment=new RdnFragment(depth,color,opacity,id,null);
			}
			else
			{
				if(fragment.Opacity.Intensity<1f)
				{
					if(fragment.Next!=null)
						SetColor(ref fragment.Next,depth,color,opacity,id);
					else
						fragment.Next=new RdnFragment(depth,color,opacity,id,null);
				}
			}
		}
		public void SetColor(int x,int y,float depth,RdnColor color,RdnColor opacity,int id)
		{
			if(((x>=0)&&(x<width))&&((y>=0)&&(y<height)))
			{
				if(!mask[x,y])
				{
					if(fragments[x,y]!=null)
						SetColor(ref fragments[x,y],depth,color,opacity,id);
					else
						fragments[x,y]=new RdnFragment(depth,color,opacity,id,null);
				}
			}
		}
		public RdnColor GetColor(int x,int y,RdnFragment fragment)
		{
			if(fragment!=null)
			{
				RdnColor col;
				if(fragment.Next!=null)
					col=RdnColor.FromBlend(GetColor(x,y,fragment.Next),fragment.Color,fragment.Opacity);
				else
				{
					if(fragment.Opacity.Intensity<1f)
						col=RdnColor.FromBlend(back[x,y],fragment.Color,fragment.Opacity);
					else
						col=fragment.Color;
				}
				return col;
			}
			return back[x,y];
		}
		public RdnColor GetColor(int x,int y)
		{
			return GetColor(x,y,0,0);
		}
		public RdnColor GetColor(int x,int y,int xsamples,int ysamples)
		{
			int xi=(int)RdnMath.ClampWrap(x,0,width-1);
			int yi=(int)RdnMath.ClampWrap(y,0,height-1);
			if(xsamples>1||ysamples>1)
			{
				RdnColor col=new RdnColor(0f);
				for(int i=0;i<xsamples;i++)
				{
					for(int j=0;j<ysamples;j++)
					{
						int sx=xi*xsamples+i;
						int sy=yi*ysamples+j;
						col=col+GetColor(sx,sy,fragments[sx,sy]);
					}
				}
				return col/(float)(xsamples*ysamples);
			}
			return GetColor(xi,yi,fragments[xi,yi]);
		}
		public RdnColor GetColor(int x,int y,int xsamples,int ysamples,RdnFilter filter)
		{
			int xi=(int)RdnMath.ClampWrap(x,0,width-1);
			int yi=(int)RdnMath.ClampWrap(y,0,height-1);
			if(filter!=null)
			{
				RdnColor col=new RdnColor(0f);
				if(xsamples>1||ysamples>1)
				{
					for(int i=0;i<xsamples;i++)
					{
						for(int j=0;j<ysamples;j++)
						{
							int sx=xi*xsamples+i;
							int sy=yi*ysamples+j;
							RdnColor fcol=new RdnColor(0f);
							for(int f=0;f<filter.Points.Length;f++)
							{
								if(filter.Mults[f]!=0f)
								{
									int sxi=(int)RdnMath.ClampWrap(sx+filter.Points[f].X,0,width-1);
									int syi=(int)RdnMath.ClampWrap(sy+filter.Points[f].Y,0,height-1);
									fcol=fcol+filter.Mults[f]*GetColor(sxi,syi,fragments[sxi,syi]);
								}
							}
							col=col+fcol/filter.Div;
						}
					}
					col=col/(float)(xsamples*ysamples);
				}
				else
				{
					RdnColor fcol=new RdnColor(0f);
					for(int f=0;f<filter.Points.Length;f++)
					{
						if(filter.Mults[f]!=0f)
						{
							int sx=(int)RdnMath.ClampWrap(xi+filter.Points[f].X,0,width-1);
							int sy=(int)RdnMath.ClampWrap(yi+filter.Points[f].Y,0,height-1);
							fcol=fcol+filter.Mults[f]*GetColor(sx,sy,fragments[sx,sy]);
						}
					}
					col=fcol/filter.Div;
				}
				return col;
			}
			return GetColor(x,y,xsamples,ysamples);
		}
		public void RasterMicroPolygon(RdnMicroPolygon micropolygon,float depth,RdnColor color,RdnColor opacity,int id,bool inverse,bool hider,bool matte)
		{
			if(micropolygon!=null)
			{
				int i;
				RdnVector[] mp=null;
				if(inverse)
					mp=new RdnVector[4]{micropolygon.Point00,micropolygon.Point10,micropolygon.Point11,micropolygon.Point01};
				else
					mp=new RdnVector[4]{micropolygon.Point00,micropolygon.Point01,micropolygon.Point11,micropolygon.Point10};
				int xmin=(int)mp[0].X,ymin=(int)mp[0].Y;
				int xmax=(int)(mp[0].X+1),ymax=(int)(mp[0].Y+1);
				for(i=1;i<4;i++)
				{
					if((int)mp[i].X<xmin)
						xmin=(int)mp[i].X;
					if((int)(mp[i].X+1)>xmax)
						xmax=(int)(mp[i].X+1);
					if((int)mp[i].Y<ymin)
						ymin=(int)mp[i].Y;
					if((int)(mp[i].Y+1)>ymax)
						ymax=(int)(mp[i].Y+1);
				}
				for(int x=xmin;x<=xmax;x++)
				{	
					for(int y=ymin;y<=ymax;y++)
					{
						int inside=0;
						for(i=0;i<4;i++)
						{
							float ax=mp[(i+1)%4].X-mp[i].X;
							float ay=mp[(i+1)%4].Y-mp[i].Y;
							float bx=(float)x-mp[i].X;
							float by=(float)y-mp[i].Y;
							inside+=((ax*by-ay*bx)>=0f)?1:0;
						}
						if(inside==4)
						{
							if(!hider||matte)
								fragments[x,y]=null;
							SetColor(x,y,depth,color,opacity,id);
							if(matte)
								SetMask(x,y,true);
						}
					}
				}
			}
		}

		public int Width
		{
			get
			{
				return width;
			}
		}
		public int Height
		{
			get
			{
				return height;
			}
		}
		public RdnFragment this[int x, int y]
		{ 
			get
			{
				return fragments[x,y];
			}
			set
			{
				fragments[x,y]=value;
			}
		}
	}
}
