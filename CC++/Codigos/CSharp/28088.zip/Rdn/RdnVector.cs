using System;

namespace Rdn.Basis
{
	/// <summary>
	/// Summary description for RdnVector.
	/// </summary>
	public struct RdnVector
	{
		private float x,y,z;
				
		public RdnVector(float x,float y,float z)
		{
			this.x=x;this.y=y;this.z=z;
		}

		public override bool Equals(object obj)
		{
			if((object)this==obj)
				return true;
			return false;
		}
		public override int GetHashCode()
		{
			return 0;
		}
				
		public void Normalize()
		{
			float len=Length;
			if(len==0.0f)
				x=y=z=0.0f;
			else
			{
				x/=len;y/=len;z/=len;
			}
		}
		public void Inverse()
		{
			x=-x;y=-y;z=-z;
		}
				
		public static RdnVector FromVectorW(RdnVector vector,float w)
		{
			return new RdnVector(vector.X/w,vector.Y/w,vector.Z/w);
		}
		public static RdnVector FromLine(RdnVector a,RdnVector b)
		{
			return new RdnVector(b.X-a.X,b.Y-a.Y,b.Z-a.Z);
		}
		public static RdnVector FromSphere(float theta,float phi)
		{
			return new RdnVector((float)(Math.Sin(theta)*Math.Cos(phi)),(float)(Math.Sin(theta)*Math.Sin(phi)),(float)(Math.Cos(theta)));
		}
		public static RdnVector FromSphere(RdnVector direction,float angle,Random random)
		{
			RdnVector newvec;
			do
			{
				newvec=RdnVector.FromSphere((float)(random.NextDouble()*Math.PI),(float)(random.NextDouble()*Math.PI*2.0));
			}
			while((direction*newvec)<(float)Math.Cos(angle));
			return newvec;
		}
		public static RdnVector FromReflect(RdnVector incident,RdnVector normal)
		{
			return incident-2.0f*(incident*normal)*normal;
		}
		public static RdnVector FromRefract(RdnVector incident,RdnVector normal,float eta)
		{
			float idotn=incident*normal;
			float k=1.0f-eta*eta*(1.0f-idotn*idotn);
			return k<0 ? new RdnVector(0,0,0) : incident*eta-normal*(eta*idotn+(float)Math.Sqrt(k));
		}
		public static RdnVector FromProjection(RdnVector direction,float x,float y,float width,float height,float dist)
		{
			RdnVector uoffset=new RdnVector(direction.Z-direction.Y,
				direction.X-direction.Z,
				direction.Y-direction.X);
			uoffset=uoffset*dist;
			RdnVector voffset=direction^uoffset;
			return (direction+((x+0.5f)/width-0.5f)*uoffset+((y+0.5f)/height-0.5f)*voffset);
		}
		public static RdnVector FromView(RdnVector point,RdnVector position,RdnVector target,RdnVector up,float roll)
		{
			RdnMatrix view=new RdnMatrix();
			view.LookAt(position,target,up);
			RdnMatrix rol=new RdnMatrix();
			rol.RotateZ(roll);
			return (rol*view)*point;
		}
		public static RdnVector FromRaster(RdnVector point,float formatwidth,float formatheight,float formataspect,float width,float height,float fovwidth,float fovheight,float near,float far,bool perspective)
		{
			if(perspective)
				return new RdnVector(width/2f+((near*point.X*fovwidth)/point.Z)*width,height/2f+(-(near*point.Y*fovheight)/point.Z)*height*(((float)formatwidth/(float)formatheight)*formataspect),RdnMath.ClampWrap((point.Z-near)/(far-near),0f,1f));
			else
				return new RdnVector(width/2f+point.X*fovwidth,height/2f+(-point.Y)*fovheight,RdnMath.ClampWrap((point.Z-near)/(far-near),0f,1f));
		}
		public static bool operator==(RdnVector a,RdnVector b)
		{
			if((a.X==b.X)&&(a.Y==b.Y)&&(a.Z==b.Z))
				return true;
			return false;
		}
		public static bool operator!=(RdnVector a,RdnVector b)
		{
			if((a.X!=b.X)||(a.Y!=b.Y)||(a.Z!=b.Z))
				return true;
			return false;
		}
		public static RdnVector operator+(RdnVector a,RdnVector b)
		{
			return new RdnVector(a.X+b.X,a.Y+b.Y,a.Z+b.Z);
		}
		public static RdnVector operator-(RdnVector a,RdnVector b)
		{
			return new RdnVector(a.X-b.X,a.Y-b.Y,a.Z-b.Z);
		}
		public static RdnVector operator*(RdnVector vector,float scalar)
		{
			return new RdnVector(vector.X*scalar,vector.Y*scalar,vector.Z*scalar);
		}
		public static RdnVector operator*(float scalar,RdnVector vector)
		{
			return new RdnVector(vector.X*scalar,vector.Y*scalar,vector.Z*scalar);
		}
		public static RdnVector operator/(RdnVector vector,float scalar)
		{
			return new RdnVector(vector.X/scalar,vector.Y/scalar,vector.Z/scalar);
		}
		public static RdnVector operator/(float scalar,RdnVector vector)
		{
			return new RdnVector(scalar/vector.X,scalar/vector.Y,scalar/vector.Z);
		}
		public static float operator*(RdnVector a,RdnVector b)
		{
			return (a.X*b.X+a.Y*b.Y+a.Z*b.Z);
		}
		public static RdnVector operator*(RdnVector vector,RdnMatrix matrix)
		{
			return new RdnVector(vector.X*matrix.GetElement(0,0)+vector.Y*matrix.GetElement(0,1)+vector.Z*matrix.GetElement(0,2)+matrix.GetElement(0,3),
				vector.X*matrix.GetElement(1,0)+vector.Y*matrix.GetElement(1,1)+vector.Z*matrix.GetElement(1,2)+matrix.GetElement(1,3),
				vector.X*matrix.GetElement(2,0)+vector.Y*matrix.GetElement(2,1)+vector.Z*matrix.GetElement(2,2)+matrix.GetElement(2,3));
		}
		public static RdnVector operator^(RdnVector a,RdnVector b)
		{
			return new RdnVector(a.Y*b.Z-a.Z*b.Y,a.Z*b.X-a.X*b.Z,a.X*b.Y-a.Y*b.X);
		}
		public static float operator|(RdnVector a,RdnVector b)
		{
			if(a==b)
				return 0.0f;
			float A=a.Length*b.Length;
			if(A==0.0f)
				return 0.0f;
			float B=(a*b)/A;
			if(B<=-1.0f)
				return (float)Math.PI;
			if(B>=1.0f)
				return 0.0f;
			return (float)Math.Acos(B);
		}
				
		public float X
		{
			get
			{
				return x;
			}
			set
			{
				x=value;
			}
		}
		public float Y
		{
			get
			{
				return y;
			}
			set
			{
				y=value;
			}
		}
		public float Z
		{
			get
			{
				return z;
			}
			set
			{
				z=value;
			}
		}
		public float Length
		{
			get
			{
				return (float)Math.Sqrt(x*x+y*y+z*z);
			}
		}
		public float Length2
		{
			get
			{
				return (float)(x*x+y*y+z*z);
			}
		}
		public RdnVector Normalized
		{
			get
			{
				RdnVector v=this;
				v.Normalize();
				return v;
			}
		}
		public RdnVector Inverted
		{
			get
			{
				return new RdnVector(0,0,0)-this;
			}
		}
	}
}
