using System;
using System.Collections;
using Rdn.Basis;

namespace Rdn.Maps
{
	/// <summary>
	/// Summary description for RdnPhotonMap.
	/// </summary>
	public class RdnPhotonMap
	{
		private RdnBox box;
		private ArrayList photons;
		private RdnPhotonMap left,right;

		public RdnPhotonMap()
		{
			photons=new ArrayList();
		}

		public void StorePhoton(RdnPhoton photon)
		{
			photons.Add(photon);
		}
		private void Balance(int limit,int depth)
		{
			if(photons.Count>limit)
			{
				box=new RdnBox(float.MaxValue,float.MaxValue,float.MaxValue,float.MinValue,float.MinValue,float.MinValue);
				for(int i=0;i<photons.Count;i++)
				{
					box.MinX=Math.Min(box.MinX,((RdnPhoton)photons[i]).Point.X);
					box.MinY=Math.Min(box.MinY,((RdnPhoton)photons[i]).Point.Y);
					box.MinZ=Math.Min(box.MinZ,((RdnPhoton)photons[i]).Point.Z);
					box.MaxX=Math.Max(box.MaxX,((RdnPhoton)photons[i]).Point.X);
					box.MaxY=Math.Max(box.MaxY,((RdnPhoton)photons[i]).Point.Y);
					box.MaxZ=Math.Max(box.MaxZ,((RdnPhoton)photons[i]).Point.Z);
				}
				int dim=depth%3;
				RdnVector center=box.Center;
				left=new RdnPhotonMap();
				right=new RdnPhotonMap();
				for(int i=0;i<photons.Count;i++)
				{
					if(dim==0)
					{
						if(((RdnPhoton)photons[i]).Point.X<center.X)
							left.StorePhoton(((RdnPhoton)photons[i]));
						else
							right.StorePhoton(((RdnPhoton)photons[i]));
					}
					else if(dim==1)
					{
						if(((RdnPhoton)photons[i]).Point.Y<center.Y)
							left.StorePhoton(((RdnPhoton)photons[i]));
						else
							right.StorePhoton(((RdnPhoton)photons[i]));
					}
					else
					{
						if(((RdnPhoton)photons[i]).Point.Z<center.Z)
							left.StorePhoton(((RdnPhoton)photons[i]));
						else
							right.StorePhoton(((RdnPhoton)photons[i]));
					}
				}
				photons.Clear();
				left.Balance(limit,depth+1);
				right.Balance(limit,depth+1);
			}
		}
		public void Balance(int limit)
		{
			Balance(limit,0);
		}
		private void LocateNearestPhotons(ArrayList photonlist,RdnVector point,float maxdist,int depth)
		{
			if(photons.Count>0)
			{
				for(int i=0;i<photons.Count;i++)
				{
					if((((RdnPhoton)photons[i]).Point-point).Length2<maxdist)
						photonlist.Add(((RdnPhoton)photons[i]));
				}
			}
			else
			{
				int dim=depth%3;
				RdnVector center=box.Center;
				if(dim==0)
				{
					if(point.X-maxdist<center.X)
					{
						if(left!=null)
							left.LocateNearestPhotons(photonlist,point,maxdist,depth+1);
					}
					if(point.X+maxdist>=center.X)
					{
						if(right!=null)
							right.LocateNearestPhotons(photonlist,point,maxdist,depth+1);
					}
				}
				else if(dim==1)
				{
					if(point.Y-maxdist<center.Y)
					{
						if(left!=null)
							left.LocateNearestPhotons(photonlist,point,maxdist,depth+1);
					}
					if(point.Y+maxdist>=center.Y)
					{
						if(right!=null)
							right.LocateNearestPhotons(photonlist,point,maxdist,depth+1);
					}			
				}
				else
				{
					if(point.Z-maxdist<center.Z)
					{
						if(left!=null)
							left.LocateNearestPhotons(photonlist,point,maxdist,depth+1);
					}
					if(point.Z+maxdist>=center.Z)
					{
						if(right!=null)
							right.LocateNearestPhotons(photonlist,point,maxdist,depth+1);
					}			
				}
			}
		}
		public void LocateNearestPhotons(ArrayList photonlist,RdnVector point,float maxdist)
		{
			LocateNearestPhotons(photonlist,point,maxdist,0);
		}

		public RdnBox Box
		{ 
			get
			{
				return box;
			}
			set
			{
				box=value;
			}
		}
		public int NumPhotons
		{ 
			get
			{
				return photons.Count;
			}
		}
	}
}
