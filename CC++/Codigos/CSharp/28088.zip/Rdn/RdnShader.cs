using System;
using System.Collections;
using System.Reflection;
using Rdn.Basis;
using Rdn.Maps;

namespace Rdn
{
	/// <summary>
	/// Summary description for RdnShader.
	/// </summary>
	public abstract class RdnShader
	{
		private string shadername,shaderassembly;
		private RdnShaderType shadertype;
		private RdnShaderParam[] shaderparams;
		private RdnTextureMap texturemap;
		private RdnShadowMap shadowmap;
		private RdnSphericalMap sphericalmap;
		private RdnCubicMap cubicmap;
		private RdnRender render;

		public RdnShader()
		{
			shadertype=RdnShaderType.None;
		}

		protected void SetNumParams(int num)
		{
			shaderparams=new RdnShaderParam[num];
		}
		protected void DefineParam(int index,string name,object val)
		{
			shaderparams[index]=new RdnShaderParam();
			shaderparams[index].Name=name;
			shaderparams[index].Value=val;
		}
		public void SetParam(int index,object val)
		{
			shaderparams[index].Value=val;
		}
		public int GetNumParams()
		{
			return shaderparams.Length;
		}
		public RdnShaderParam GetParam(int index)
		{
			return shaderparams[index];
		}
		protected RdnColor Texture(float s,float t,int samples,float blur,bool filter)
		{
			if(texturemap!=null)
			{
				if(samples>1)
				{
					RdnColor col=new RdnColor(0f);
					for(int i=0;i<samples;i++)
					{
						for(int j=0;j<samples;j++)
						{
							float ss=s+(float)(i-(samples/2-1))*blur;
							float st=t+(float)(j-(samples/2-1))*blur;
							col=col+texturemap.GetTexel(ss,st,filter).Color;
						}
					}
					return col/(float)(samples*samples);
				}
				else
					return texturemap.GetTexel(s,t,filter).Color;
			}
			return new RdnColor(1f);
		}
		protected float Shadow(RdnVector point,int samples,float blur,float bias)
		{
			if(shadowmap!=null)
			{
				point=shadowmap.View*point;
				point=RdnVector.FromRaster(point,shadowmap.Width,shadowmap.Height,1,shadowmap.Width,shadowmap.Height,1,1,shadowmap.Near,shadowmap.Far,true);
				if(samples>1)
				{
					int sum=0;
					for(int i=0;i<samples;i++)
					{
						for(int j=0;j<samples;j++)
						{
							int sx=(int)(point.X+(float)(i-(samples/2-1))*blur);
							int sy=(int)(point.Y+(float)(j-(samples/2-1))*blur);
							if((sx>=0&&sx<shadowmap.Width)&&(sy>=0&&sy<shadowmap.Height))
								if((shadowmap[sx,sy]+bias)<point.Z)
									sum++;
						}
					}
					return RdnMath.ClampWrap(1f-(float)sum/(samples*samples),0f,1f);
				}
				else
				{
					if((point.X>=0&&point.X<shadowmap.Width)&&(point.Y>=0&&point.Y<shadowmap.Height))
						if(shadowmap[(int)point.X,(int)point.Y]+bias<point.Z)
							return 0f;
				}
			}
			return 1f;
		}
		protected RdnColor Environment(RdnVector direction,int samples,float blur,bool filter,bool cubic)
		{
			if(cubic)
			{
				if(cubicmap!=null)
				{
					RdnTextureMap face=null;
					float s=0f,t=0f,m=1f;
					if((direction.X>=direction.Y)&&(direction.X>=direction.Z)) 
					{ 
						m=Math.Abs(direction.X); 
						s=((-direction.Z/m)+1f)/2f; 
						t=((-direction.Y/m)+1f)/2f; 
						face=cubicmap.MapPx;
					} 
					if((direction.X<=direction.Y)&&(direction.X<=direction.Z)) 
					{ 
						m=Math.Abs(direction.X); 
						s=((direction.Z/m)+1f)/2f; 
						t=((-direction.Y/m)+1f)/2f; 
						face=cubicmap.MapNx;
					} 
					if((direction.Y>=direction.Z)&&(direction.Y>=direction.X)) 
					{ 
						m=Math.Abs(direction.Y); 
						s=((direction.X/m)+1f)/2f; 
						t=((direction.Z/m)+1f)/2f; 
						face=cubicmap.MapPy;
					} 
					if((direction.Y<=direction.Z)&&(direction.Y<=direction.X)) 
					{ 
						m=Math.Abs(direction.Y); 
						s=((direction.X/m)+1f)/2f; 
						t=((-direction.Z/m)+1f)/2f; 
						face=cubicmap.MapNy;
					} 
					if((direction.Z>=direction.Y)&&(direction.Z>=direction.X)) 
					{ 
						m=Math.Abs(direction.Z); 
						s=((direction.X/m)+1f)/2f; 
						t=((-direction.Y/m)+1f)/2f; 
						face=cubicmap.MapPz;
					} 
					if((direction.Z<=direction.Y)&&(direction.Z<=direction.X)) 
					{ 
						m=Math.Abs(direction.Z); 
						s=((-direction.X/m)+1f)/2f; 
						t=((-direction.Y/m)+1f)/2f; 
						face=cubicmap.MapNz;
					}
					if(face!=null)
					{
						if(samples>1)
						{
							RdnColor col=new RdnColor(0f);
							for(int i=0;i<samples;i++)
							{
								for(int j=0;j<samples;j++)
								{
									float ss=s+(float)(i-(samples/2-1))*blur;
									float st=t+(float)(j-(samples/2-1))*blur;
									col=col+face.GetTexel(RdnMath.ClampWrap(ss,0f,1f),RdnMath.ClampWrap(st,0f,1f),filter).Color;
								}
							}
							return col/(float)(samples*samples);
						}
						else
							return face.GetTexel(RdnMath.ClampWrap(s,0f,1f),RdnMath.ClampWrap(t,0f,1f),filter).Color;
					}
				}
			}
			else
			{
				if(sphericalmap!=null)
				{
					float m=2f*(direction+sphericalmap.Axis).Length;
					float s=direction.X/m+0.5f;
					float t=direction.Y/m+0.5f;
					if(samples>1)
					{
						RdnColor col=new RdnColor(0f);
						for(int i=0;i<samples;i++)
						{
							for(int j=0;j<samples;j++)
							{
								float ss=s+(float)(i-(samples/2-1))*blur;
								float st=t+(float)(j-(samples/2-1))*blur;
								col=col+sphericalmap.Map.GetTexel(RdnMath.ClampWrap(ss,0f,1f),RdnMath.ClampWrap(st,0f,1f),filter).Color;
							}
						}
						return col/(float)(samples*samples);
					}
					else
						return sphericalmap.Map.GetTexel(RdnMath.ClampWrap(s,0f,1f),RdnMath.ClampWrap(t,0f,1f),filter).Color;
				}
			}
			return new RdnColor(0f);
		}
		protected RdnColor Environment(RdnRay RdnRay,RdnVector envcenter,float envrad,int samples,float blur,bool filter,bool cubic)
		{
			float d0,d1;
			if(RdnRay.CastSphere(out d0,out d1,envcenter,envrad))
				return Environment(RdnRay.GetPoint(d1).Normalized,samples,blur,filter,cubic);
			return new RdnColor(0f);
		}
		protected RdnCastState Cast(RdnRay ray)
		{
			if(render!=null)
				return render.Cast(ray);
			return new RdnCastState();
		}
		protected RdnTraceState Trace(RdnRay ray,int levels)
		{
			if(render!=null)
				return render.Trace(ray,levels);
			return new RdnTraceState();
		}
		protected RdnTraceState Trace(RdnRay ray,int level,int sampleswidth,int samplesheight,float samplesdist)
		{
			RdnTraceState state=new RdnTraceState();
			if(sampleswidth>0||samplesheight>0)
			{
				RdnRay r=new RdnRay(ray.Origin,ray.Direction);
				RdnColor col=new RdnColor(0f);
				for(int j=0;j<samplesheight;j++)
				{
					for(int i=0;i<sampleswidth;i++)
					{
						r.Direction=RdnVector.FromProjection(ray.Direction,(float)i,(float)j,(float)sampleswidth,(float)samplesheight,samplesdist);
						state=Trace(r,level);
						col=col+state.Color;
					}
				}
				state.Color=col/(sampleswidth*samplesheight);
				state.Color.Clamp();
			}
			return state;
		}
		protected RdnTraceState Trace(RdnRay ray,int level,int sampleswidth,int samplesheight,float samplesdist,float[,] mults,float div)
		{
			RdnTraceState state=new RdnTraceState();
			if(sampleswidth>0||samplesheight>0)
			{
				RdnRay r=new RdnRay(ray.Origin,ray.Direction);
				RdnColor col=new RdnColor(0f);
				for(int j=0;j<samplesheight;j++)
				{
					for(int i=0;i<sampleswidth;i++)
					{
						r.Direction=RdnVector.FromProjection(ray.Direction,(float)i,(float)j,(float)sampleswidth,(float)samplesheight,samplesdist);
						state=Trace(r,level);
						col=col+mults[i,j]*state.Color;
					}
				}
				state.Color=col/div;
				state.Color.Clamp();
			}
			return state;
		}
		protected RdnTraceState Trace(RdnRay ray,int level,int sampleswidth,int samplesheight,float samplesdist,float samplesnoise,Random random)
		{
			RdnTraceState state=new RdnTraceState();
			if(sampleswidth>0||samplesheight>0)
			{
				RdnRay r=new RdnRay(ray.Origin,ray.Direction);
				RdnColor col=new RdnColor(0f);
				for(int j=0;j<samplesheight;j++)
				{
					for(int i=0;i<sampleswidth;i++)
					{		
						r.Direction=RdnVector.FromProjection(ray.Direction,(samplesnoise*(float)(-1.0+2.0*random.NextDouble()))+(float)i,(samplesnoise*(float)(-1.0+2.0*random.NextDouble()))+(float)j,(float)sampleswidth,(float)samplesheight,samplesdist);
						state=Trace(r,level);
						col=col+state.Color;
					}
				}
				state.Color=col/(sampleswidth*samplesheight);
				state.Color.Clamp();
			}
			return state;
		}
		protected RdnTraceState Trace(RdnRay ray,int level,int samples,float samplesangle,Random random)
		{
			RdnTraceState state=new RdnTraceState();
			if(samples>0)
			{
				RdnRay r=new RdnRay(ray.Origin,ray.Direction);
				RdnColor col=new RdnColor(0,0,0);
				for(int i=0;i<samples;i++)
				{
					r.Direction=RdnVector.FromSphere(ray.Direction,samplesangle,random);
					state=Trace(r,level);
					col=col+state.Color;
				}
				state.Color=col/(float)samples;
				state.Color.Clamp();
			}
			return state;
		}
		protected float Diffuse(RdnVector incoming,RdnVector normal)
		{
			float d=incoming.Inverted*normal;
			if(d<0f)
				return 0f;
			if(d>1f)
				return 1f;
			return d;
		}
		protected float Specular(RdnVector incoming,RdnVector incident,RdnVector normal,float roughness)
		{
			float s=(float)Math.Pow(Math.Max(0f,normal*((incoming.Inverted+incident.Inverted).Normalized)),1f/roughness);
			if(s<0f)
				return 0f;
			if(s>1f)
				return 1f;
			return s;
		}
		protected float Phong(RdnVector incoming,RdnVector incident,RdnVector normal,float size)
		{
			float p=(float)Math.Pow(Math.Max(0f,(RdnVector.FromReflect(incident,normal))*incoming.Inverted),size);
			if(p<0f)
				return 0f;
			if(p>1f)
				return 1f;
			return p;
		}
		protected float Glossy(RdnVector incoming,RdnVector incident,RdnVector normal,float roughness,float sharpness)
		{
			float w=0.18f*(1f-sharpness);
			float g=RdnMath.SmoothStep(Specular(incoming,incident,normal,roughness),0.72f-w,0.72f+w);
			if(g<0f)
				return 0f;
			if(g>1f)
				return 1f;
			return g;
		}
		protected float AbsorptionProbability(RdnColor diffuse,RdnColor glossy,RdnColor specular)
		{
			RdnColor c=new RdnColor(diffuse.Red+glossy.Red+specular.Red,diffuse.Green+glossy.Green+specular.Green,diffuse.Blue+glossy.Blue+specular.Blue);
			c.Clamp();
			return 1.0f-Math.Max(c.Red,Math.Max(c.Green,c.Blue));
		}
		protected float DiffuseReflectionProbability(RdnColor diffuse,RdnColor glossy,RdnColor specular,RdnColor opacity)
		{
			RdnColor c=new RdnColor(diffuse.Red+glossy.Red+specular.Red,diffuse.Green+glossy.Green+specular.Green,diffuse.Blue+glossy.Blue+specular.Blue);
			c.Clamp();
			return Math.Max(c.Red,Math.Max(c.Green,c.Blue))*opacity.Intensity*((diffuse.Red+diffuse.Green+diffuse.Blue)/(diffuse.Red+diffuse.Green+diffuse.Blue+glossy.Red+glossy.Green+glossy.Blue+specular.Red+specular.Green+specular.Blue));
		}
		protected float DiffuseTransmissionProbability(RdnColor diffuse,RdnColor glossy,RdnColor specular,RdnColor opacity)
		{
			RdnColor c=new RdnColor(diffuse.Red+glossy.Red+specular.Red,diffuse.Green+glossy.Green+specular.Green,diffuse.Blue+glossy.Blue+specular.Blue);
			c.Clamp();
			return Math.Max(c.Red,Math.Max(c.Green,c.Blue))*(1.0f-opacity.Intensity)*((diffuse.Red+diffuse.Green+diffuse.Blue)/(diffuse.Red+diffuse.Green+diffuse.Blue+glossy.Red+glossy.Green+glossy.Blue+specular.Red+specular.Green+specular.Blue));
		}
		protected float GlossyReflectionProbability(RdnColor diffuse,RdnColor glossy,RdnColor specular,RdnColor opacity)
		{
			RdnColor c=new RdnColor(diffuse.Red+glossy.Red+specular.Red,diffuse.Green+glossy.Green+specular.Green,diffuse.Blue+glossy.Blue+specular.Blue);
			c.Clamp();
			return Math.Max(c.Red,Math.Max(c.Green,c.Blue))*opacity.Intensity*((glossy.Red+glossy.Green+glossy.Blue)/(diffuse.Red+diffuse.Green+diffuse.Blue+glossy.Red+glossy.Green+glossy.Blue+specular.Red+specular.Green+specular.Blue));
		}
		protected float GlossyTransmissionProbability(RdnColor diffuse,RdnColor glossy,RdnColor specular,RdnColor opacity)
		{
			RdnColor c=new RdnColor(diffuse.Red+glossy.Red+specular.Red,diffuse.Green+glossy.Green+specular.Green,diffuse.Blue+glossy.Blue+specular.Blue);
			c.Clamp();
			return Math.Max(c.Red,Math.Max(c.Green,c.Blue))*(1.0f-opacity.Intensity)*((glossy.Red+glossy.Green+glossy.Blue)/(diffuse.Red+diffuse.Green+diffuse.Blue+glossy.Red+glossy.Green+glossy.Blue+specular.Red+specular.Green+specular.Blue));
		}
		protected float SpecularReflectionProbability(RdnColor diffuse,RdnColor glossy,RdnColor specular,RdnColor opacity)
		{
			RdnColor c=new RdnColor(diffuse.Red+glossy.Red+specular.Red,diffuse.Green+glossy.Green+specular.Green,diffuse.Blue+glossy.Blue+specular.Blue);
			c.Clamp();
			return Math.Max(c.Red,Math.Max(c.Green,c.Blue))*opacity.Intensity*((specular.Red+specular.Green+specular.Blue)/(diffuse.Red+diffuse.Green+diffuse.Blue+glossy.Red+glossy.Green+glossy.Blue+specular.Red+specular.Green+specular.Blue));
		}
		protected float SpecularTransmissionProbability(RdnColor diffuse,RdnColor glossy,RdnColor specular,RdnColor opacity)
		{
			RdnColor c=new RdnColor(diffuse.Red+glossy.Red+specular.Red,diffuse.Green+glossy.Green+specular.Green,diffuse.Blue+glossy.Blue+specular.Blue);
			c.Clamp();
			return Math.Max(c.Red,Math.Max(c.Green,c.Blue))*(1.0f-opacity.Intensity)*((specular.Red+specular.Green+specular.Blue)/(diffuse.Red+diffuse.Green+diffuse.Blue+glossy.Red+glossy.Green+glossy.Blue+specular.Red+specular.Green+specular.Blue));
		}
		protected void LocateNearestDirectPhotons(out RdnPhoton[] photons,RdnVector point,float maxdist)
		{
			photons=null;
			if(render!=null)
			{
				if(render.DirectPhotonMap!=null)
				{
					ArrayList photonlist=new ArrayList();
					render.DirectPhotonMap.LocateNearestPhotons(photonlist,point,maxdist);
					if(photonlist.Count>0)
					{
						photons=new RdnPhoton[photonlist.Count];
						for(int i=0;i<photons.Length;i++)
							photons[i]=((RdnPhoton)photonlist[i]);
					}
				}
			}
		}
		protected void LocateNearestDirectPhotons(out RdnPhoton[] photons,RdnVector point,float maxdist,float filter)
		{
			photons=null;
			if(render!=null)
			{
				if(render.DirectPhotonMap!=null)
				{
					ArrayList photonlist=new ArrayList();
					render.DirectPhotonMap.LocateNearestPhotons(photonlist,point,maxdist);
					if(photonlist.Count>0)
					{
						photons=new RdnPhoton[photonlist.Count];
						for(int i=0;i<photons.Length;i++)
						{
							photons[i]=((RdnPhoton)photonlist[i]);
							photons[i].Energy=photons[i].Energy*Math.Max(0f,1f-((photons[i].Point-point).Length2)/(maxdist*filter));
						}
					}
				}
			}
		}
		protected void LocateNearestGlobalPhotons(out RdnPhoton[] photons,RdnVector point,float maxdist)
		{
			photons=null;
			if(render!=null)
			{
				if(render.GlobalPhotonMap!=null)
				{
					ArrayList photonlist=new ArrayList();
					render.GlobalPhotonMap.LocateNearestPhotons(photonlist,point,maxdist);
					if(photonlist.Count>0)
					{
						photons=new RdnPhoton[photonlist.Count];
						for(int i=0;i<photons.Length;i++)
							photons[i]=((RdnPhoton)photonlist[i]);
					}
				}
			}
		}
		protected void LocateNearestGlobalPhotons(out RdnPhoton[] photons,RdnVector point,float maxdist,float filter)
		{
			photons=null;
			if(render!=null)
			{
				if(render.GlobalPhotonMap!=null)
				{
					ArrayList photonlist=new ArrayList();
					render.GlobalPhotonMap.LocateNearestPhotons(photonlist,point,maxdist);
					if(photonlist.Count>0)
					{
						photons=new RdnPhoton[photonlist.Count];
						for(int i=0;i<photons.Length;i++)
						{
							photons[i]=((RdnPhoton)photonlist[i]);
							photons[i].Energy=photons[i].Energy*Math.Max(0f,1f-((photons[i].Point-point).Length2)/(maxdist*filter));
						}
					}
				}
			}
		}
		protected void LocateNearestCausticPhotons(out RdnPhoton[] photons,RdnVector point,float maxdist)
		{
			photons=null;
			if(render!=null)
			{
				if(render.CausticPhotonMap!=null)
				{
					ArrayList photonlist=new ArrayList();
					render.CausticPhotonMap.LocateNearestPhotons(photonlist,point,maxdist);
					if(photonlist.Count>0)
					{
						photons=new RdnPhoton[photonlist.Count];
						for(int i=0;i<photons.Length;i++)
							photons[i]=((RdnPhoton)photonlist[i]);
					}
				}
			}
		}
		protected void LocateNearestCausticPhotons(out RdnPhoton[] photons,RdnVector point,float maxdist,float filter)
		{
			photons=null;
			if(render!=null)
			{
				if(render.CausticPhotonMap!=null)
				{
					ArrayList photonlist=new ArrayList();
					render.CausticPhotonMap.LocateNearestPhotons(photonlist,point,maxdist);
					if(photonlist.Count>0)
					{
						photons=new RdnPhoton[photonlist.Count];
						for(int i=0;i<photons.Length;i++)
						{
							photons[i]=((RdnPhoton)photonlist[i]);
							photons[i].Energy=photons[i].Energy*Math.Max(0f,1f-((photons[i].Point-point).Length2)/(maxdist*filter));
						}
					}
				}
			}
		}

		public virtual void OpenData(string filename){}
		public virtual void SaveData(string filename){}
		public virtual void PrimitiveProcess(out RdnVector point,float u,float v){point=new RdnVector(0f,0f,0f);}
		public virtual void DisplacementProcess(ref RdnVector point,RdnVector dPdu,RdnVector dPdv,RdnVector normal,float u,float v,float du,float dv,float s,float t,RdnRay eye,int frame){}
		public virtual void SurfaceProcess(ref RdnColor color,ref RdnColor opacity,RdnVector point,RdnVector dPdu,RdnVector dPdv,RdnVector normal,float u,float v,float du,float dv,float s,float t,RdnPhoton[] photons,RdnRay eye,int levels,int frame){}
		public virtual void SurfaceEmitterProcess(out RdnPhoton[] photons,RdnVector point,RdnVector dPdu,RdnVector dPdv,RdnVector normal,float u,float v,float du,float dv,float s,float t,RdnPhoton photon,int frame){photons=null;}
		public virtual void LightSourceProcess(out RdnPhoton[] photons,RdnVector position,RdnVector point,RdnRay eye,int frame){photons=null;}
		public virtual void LightSourceEmitterProcess(out RdnPhoton[] photons,RdnVector position,int frame){photons=null;}
		public virtual void VolumeProcess(ref RdnColor color,ref RdnColor opacity,float depth,RdnVector point,RdnRay eye,int frame){}
		public virtual void ImagerProcess(ref RdnColor color,int width,int height,int x,int y,float depth,int id,int frame){}

		public static RdnShader FromAssembly(string name,string assembly)
		{
			System.Reflection.Assembly ass=System.Reflection.Assembly.LoadFrom(assembly);
			if(ass.GetType(name)!=null)
			{
				RdnShader shader=(RdnShader)ass.CreateInstance(name);
				shader.Name=name;
				shader.Assembly=assembly;
				return shader;
			}
			return null;
		}
		public static RdnShader FromAssembly(string name,string assembly,params object[] list)
		{
			System.Reflection.Assembly ass=System.Reflection.Assembly.LoadFrom(assembly);
			if(ass.GetType(name)!=null)
			{
				RdnShader shader=(RdnShader)ass.CreateInstance(name);
				shader.Name=name;
				shader.Assembly=assembly;
				shader.SetParam(list.Length,list);
				return shader;
			}
			return null;
		}

		public string Name
		{
			get
			{
				return shadername;
			}
			set
			{
				shadername=value;
			}
		}
		public string Assembly
		{
			get
			{
				return shaderassembly;
			}
			set
			{
				shaderassembly=value;
			}
		}
		public RdnShaderType Type
		{
			get
			{
				return shadertype;
			}
			set
			{
				shadertype=value;
			}
		}
		public RdnTextureMap TextureMap
		{
			get
			{
				return texturemap;
			}
			set
			{
				texturemap=value;
			}
		}
		public RdnShadowMap ShadowMap
		{
			get
			{
				return shadowmap;
			}
			set
			{
				shadowmap=value;
			}
		}
		public RdnSphericalMap SphericalMap
		{
			get
			{
				return sphericalmap;
			}
			set
			{
				sphericalmap=value;
			}
		}
		public RdnCubicMap CubicMap
		{
			get
			{
				return cubicmap;
			}
			set
			{
				cubicmap=value;
			}
		}
		public RdnRender Render
		{
			get
			{
				return render;
			}
			set
			{
				render=value;
			}
		}
	}

	public struct RdnShaderParam
	{
		public string Name;
		public object Value;
	}

	public enum RdnShaderType{None,Primitive,Displacement,Surface,LightSource,Volume,Imager,Mix};
}
