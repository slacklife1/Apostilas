using System;

namespace Rdn.Basis
{
	/// <summary>
	/// Summary description for RdnMatrix.
	/// </summary>
	public sealed class RdnMatrix
	{
		private float[,] elements=new float[4,4];
	
		public RdnMatrix()
		{
		}
		public RdnMatrix(float a00,float a01,float a02,float a03,float a10,float a11,float a12,float a13,float a20,float a21,float a22,float a23,float a30,float a31,float a32,float a33)
		{
			elements[0,0]=a00;
			elements[0,1]=a01;
			elements[0,2]=a02;
			elements[0,3]=a03;
			elements[1,0]=a10;
			elements[1,1]=a11;
			elements[1,2]=a12;
			elements[1,3]=a13;
			elements[2,0]=a20;
			elements[2,1]=a21;
			elements[2,2]=a22;
			elements[2,3]=a23;
			elements[3,0]=a30;
			elements[3,1]=a31;
			elements[3,2]=a32;
			elements[3,3]=a33;
		}
	
		public float GetElement(int i,int j)
		{
			return elements[i,j];
		}
		public void SetElement(int i,int j,float val)
		{
			elements[i,j]=val;
		}
		public void Clear(float val)
		{
			for(int i=0;i<4;i++)
				for(int j=0;j<4;j++)
					SetElement(i,j,val);
		}
		public void Zero()
		{
			Clear(0.0f);
		}
		public void Identity()
		{
			for(int i=0;i<4;i++)
				for(int j=0;j<4;j++)
					if(i==j)
						SetElement(i,j,1);
					else
						SetElement(i,j,0);
		}
		public void Viewport(float x,float y,float width,float height)
		{
			Identity();
			SetElement(0,3,x+width/2f);
			SetElement(1,3,(height+y)-height/2f);
			SetElement(0,0,width);
			SetElement(1,1,-height);
		}
		public void Projection(float a,float b,float c,float d,float e,float f)
		{
			Zero();
			SetElement(0,0,a);
			SetElement(1,1,b);
			SetElement(2,2,c);
			SetElement(2,3,d);
			SetElement(3,2,e);
			SetElement(3,3,f);
		}
		public void Projection(float width,float height,float near,float far,bool perspective)
		{
			float dd=far-near;
			if(perspective==true)
				Projection((2*near)/width,(2*near)/height,far/dd,-(near*far)/dd,1,0);
			else
				Projection(2/width,2/height,1/dd,-near/dd,0,1);
		}
		public void Ortho(float left,float right,float bottom,float top,float near,float far)
		{
			Zero();
			float dw=right-left;
			float dh=top-bottom;
			float dd=far-near;
			SetElement(0,0,2f/dw);
			SetElement(1,1,2f/dh);
			SetElement(2,2,-2f/dd);
			SetElement(0,3,-((right+left)/dw));
			SetElement(1,3,-((top+bottom)/dh));
			SetElement(2,3,-((far+near)/dd));
			SetElement(3,3,-1);
		}
		public void Frustum(float left,float right,float bottom,float top,float near,float far)
		{
			Zero();
			float dw=right-left;
			float dh=top-bottom;
			float dd=far-near;
			SetElement(0,0,(2f*near)/dw);
			SetElement(1,1,(2f*near)/dh);
			SetElement(2,2,-((far+near)/dd));
			SetElement(0,2,(right+left)/dw);
			SetElement(1,2,(top+bottom)/dh);
			SetElement(2,3,-((2f*far*near)/dd));
			SetElement(3,2,-1);
		}
		public void Perspective(float fovy,float aspect,float near,float far)
		{
			float f=(float)Math.Tan(fovy/2);
			float dd=near-far;
			Projection(f/aspect,f,(near+far)/dd,-1,(2*near*far)/dd,0);
		}
		public void View(RdnVector u,RdnVector v,RdnVector n)
		{
			SetElement(0,0,u.X);
			SetElement(0,1,u.Y);
			SetElement(0,2,u.Z);
			SetElement(0,3,0);
			SetElement(1,0,v.X);
			SetElement(1,1,v.Y);
			SetElement(1,2,v.Z);
			SetElement(1,3,0);
			SetElement(2,0,n.X);
			SetElement(2,1,n.Y);
			SetElement(2,2,n.Z);
			SetElement(2,3,0);
			SetElement(3,0,0);
			SetElement(3,1,0);
			SetElement(3,2,0);
			SetElement(3,3,1);
		}
		public void View(RdnVector u,RdnVector v,RdnVector n,RdnVector c)
		{
			SetElement(0,0,u.X);
			SetElement(0,1,u.Y);
			SetElement(0,2,u.Z);
			SetElement(0,3,-(u*c));
			SetElement(1,0,v.X);
			SetElement(1,1,v.Y);
			SetElement(1,2,v.Z);
			SetElement(1,3,-(v*c));
			SetElement(2,0,n.X);
			SetElement(2,1,n.Y);
			SetElement(2,2,n.Z);
			SetElement(2,3,-(n*c));
			SetElement(3,0,0);
			SetElement(3,1,0);
			SetElement(3,2,0);
			SetElement(3,3,1);
		}
		public void LookAt(RdnVector eye,RdnVector at,RdnVector up)
		{
			RdnVector a,b,c;
			c=at-eye;
			c.Normalize();
			a=up^c;
			a.Normalize();
			b=c^a;
			View(a,b,c,eye);
		}
		public void Translate(float x,float y,float z)
		{
			Identity();
			SetElement(0,3,x);
			SetElement(1,3,y);
			SetElement(2,3,z);
		}
		public void Rotate(RdnVector axis,float angle)
		{
			axis.Normalize();
			float c=(float)Math.Cos(angle);
			float s=(float)Math.Sin(angle);
			float ic=1.0f-(float)Math.Cos(angle);
			elements[0,0]=(axis.X*axis.X)*ic+c;
			elements[0,1]=(axis.Y*axis.X)*ic+(axis.Z*s);
			elements[0,2]=(axis.Z*axis.X)*ic-(axis.Y*s);
			elements[0,3]=0.0f;
			elements[1,0]=(axis.X*axis.Y)*ic-(axis.Z*s);
			elements[1,1]=(axis.Y*axis.Y)*ic+c;
			elements[1,2]=(axis.Z*axis.Y)*ic+(axis.X*s);
			elements[1,3]=0.0f;
			elements[2,0]=(axis.X*axis.Z)*ic+(axis.Y*s);
			elements[2,1]=(axis.Y*axis.Z)*ic-(axis.X*s);
			elements[2,2]=(axis.Z*axis.Z)*ic+c;
			elements[2,3]=0.0f;
			elements[3,0]=0.0f;
			elements[3,1]=0.0f;
			elements[3,2]=0.0f;
			elements[3,3]=1.0f;
		}
		public void RotateX(float angle)
		{
			Identity();
			float c=(float)Math.Cos(angle);
			float s=(float)Math.Sin(angle);
			SetElement(1,1,c);
			SetElement(1,2,-s);
			SetElement(2,1,s);
			SetElement(2,2,c);
		}
		public void RotateY(float angle)
		{
			Identity();
			float c=(float)Math.Cos(angle);
			float s=(float)Math.Sin(angle);
			SetElement(0,0,c);
			SetElement(0,2,s);
			SetElement(2,0,-s);
			SetElement(2,2,c);
		}
		public void RotateZ(float angle)
		{
			Identity();
			float c=(float)Math.Cos(angle);
			float s=(float)Math.Sin(angle);
			SetElement(0,0,c);
			SetElement(0,1,-s);
			SetElement(1,0,s);
			SetElement(1,1,c);
		}
		public void ShearXY(float x,float y)
		{
			Identity();
			SetElement(0,2,x);
			SetElement(1,2,y);
		}
		public void ShearXZ(float x,float z)
		{
			Identity();
			SetElement(0,1,x);
			SetElement(2,1,z);
		}
		public void ShearYZ(float y,float z)
		{
			Identity();
			SetElement(1,0,y);
			SetElement(2,0,z);
		}
		public void Scale(float x,float y,float z)
		{
			Identity();
			SetElement(0,0,x);
			SetElement(1,1,y);
			SetElement(2,2,z);
		}
		public RdnVector VectorTransform(RdnVector vector,float w)
		{
			return new RdnVector(vector.X*GetElement(0,0)+vector.Y*GetElement(0,1)+vector.Z*GetElement(0,2)+w*GetElement(0,3),
				vector.X*GetElement(1,0)+vector.Y*GetElement(1,1)+vector.Z*GetElement(1,2)+w*GetElement(1,3),
				vector.X*GetElement(2,0)+vector.Y*GetElement(2,1)+vector.Z*GetElement(2,2)+w*GetElement(2,3));
		}
		public RdnVector VectorTransform(ref float w,RdnVector vector)
		{
			float ww=w;w=(vector.X*GetElement(3,0)+vector.Y*GetElement(3,1)+vector.Z*GetElement(3,2)+ww*GetElement(3,3));
			return new RdnVector(vector.X*GetElement(0,0)+vector.Y*GetElement(0,1)+vector.Z*GetElement(0,2)+ww*GetElement(0,3),
				vector.X*GetElement(1,0)+vector.Y*GetElement(1,1)+vector.Z*GetElement(1,2)+ww*GetElement(1,3),
				vector.X*GetElement(2,0)+vector.Y*GetElement(2,1)+vector.Z*GetElement(2,2)+ww*GetElement(2,3));
		}
				
		public static RdnMatrix operator+(RdnMatrix a,RdnMatrix b)
		{
			RdnMatrix mat=new RdnMatrix();
			for(int i=0;i<4;i++)
				for(int j=0;j<4;j++)
					mat.SetElement(i,j,a.GetElement(i,j)+b.GetElement(i,j));
			return mat;
		}
		public static RdnMatrix operator-(RdnMatrix a,RdnMatrix b)
		{
			RdnMatrix mat=new RdnMatrix();
			for(int i=0;i<4;i++)
				for(int j=0;j<4;j++)
					mat.SetElement(i,j,a.GetElement(i,j)-b.GetElement(i,j));
			return mat;
		}
		public static RdnMatrix operator*(RdnMatrix matrix,float val)
		{
			RdnMatrix mat=new RdnMatrix();
			for(int i=0;i<4;i++)
				for(int j=0;j<4;j++)
					mat.SetElement(i,j,val*matrix.GetElement(i,j));
			return mat;
		}
		public static RdnMatrix operator/(RdnMatrix matrix,float val)
		{
			RdnMatrix mat=new RdnMatrix();
			for(int i=0;i<4;i++)
				for(int j=0;j<4;j++)
					mat.SetElement(i,j,matrix.GetElement(i,j)/val);
			return mat;
		}
		public static RdnVector operator*(RdnMatrix matrix,RdnVector vector)
		{
			return new RdnVector(vector.X*matrix.GetElement(0,0)+vector.Y*matrix.GetElement(0,1)+vector.Z*matrix.GetElement(0,2)+matrix.GetElement(0,3),
				vector.X*matrix.GetElement(1,0)+vector.Y*matrix.GetElement(1,1)+vector.Z*matrix.GetElement(1,2)+matrix.GetElement(1,3),
				vector.X*matrix.GetElement(2,0)+vector.Y*matrix.GetElement(2,1)+vector.Z*matrix.GetElement(2,2)+matrix.GetElement(2,3));
		}
		public static RdnMatrix operator*(RdnMatrix a,RdnMatrix b)
		{
			RdnMatrix mat=new RdnMatrix();
			for(int i=0;i<4;i++)
			{
				for(int j=0;j<4;j++)
				{
					float sum=0.0f;
					for(int k=0;k<4;k++)
					{
						sum+=a.GetElement(i,k)*b.GetElement(k,j);
					}
					mat.SetElement(i,j,sum);
				}
			}
			return mat;
		}
		public static RdnBox operator*(RdnMatrix matrix,RdnBox box)
		{
  			RdnBox b=new RdnBox();
  			RdnVector[] p=new RdnVector[8];
  			p[0]=new RdnVector(box.MinX,box.MinY,box.MinZ);
  			p[1]=new RdnVector(box.MinX,box.MinY,box.MaxZ);
  			p[2]=new RdnVector(box.MinX,box.MaxY,box.MinZ);
  			p[3]=new RdnVector(box.MinX,box.MaxY,box.MaxZ);
  			p[4]=new RdnVector(box.MaxX,box.MinY,box.MinZ);
  			p[5]=new RdnVector(box.MaxX,box.MinY,box.MaxZ);
  			p[6]=new RdnVector(box.MaxX,box.MaxY,box.MinZ);
  			p[7]=new RdnVector(box.MaxX,box.MaxY,box.MaxZ);
  			for(int i=0;i<8;i++)
   				p[i]=matrix*p[i];
  			b.MinX=Math.Min(Math.Min(Math.Min(p[0].X,p[1].X),Math.Min(p[2].X,p[3].X)),Math.Min(Math.Min(p[4].X,p[5].X),Math.Min(p[6].X,p[7].X)));
  			b.MinY=Math.Min(Math.Min(Math.Min(p[0].Y,p[1].Y),Math.Min(p[2].Y,p[3].Y)),Math.Min(Math.Min(p[4].Y,p[5].Y),Math.Min(p[6].Y,p[7].Y)));
  			b.MinZ=Math.Min(Math.Min(Math.Min(p[0].Z,p[1].Z),Math.Min(p[2].Z,p[3].Z)),Math.Min(Math.Min(p[4].Z,p[5].Z),Math.Min(p[6].Z,p[7].Z)));
  			b.MaxX=Math.Max(Math.Max(Math.Max(p[0].X,p[1].X),Math.Max(p[2].X,p[3].X)),Math.Max(Math.Max(p[4].X,p[5].X),Math.Max(p[6].X,p[7].X)));
  			b.MaxY=Math.Max(Math.Max(Math.Max(p[0].Y,p[1].Y),Math.Max(p[2].Y,p[3].Y)),Math.Max(Math.Max(p[4].Y,p[5].Y),Math.Max(p[6].Y,p[7].Y)));
  			b.MaxZ=Math.Max(Math.Max(Math.Max(p[0].Z,p[1].Z),Math.Max(p[2].Z,p[3].Z)),Math.Max(Math.Max(p[4].Z,p[5].Z),Math.Max(p[6].Z,p[7].Z)));
  			return b;
		}
				
		public float this[int i, int j]
		{ 
			get
			{
				return elements[i,j];
			}
			set
			{
				elements[i,j]=value;
			}
		}
	}
}
