using System;
using System.Drawing;
using Rdn.Basis;

namespace Rdn.Maps
{
	/// <summary>
	/// Summary description for RdnTextureMap.
	/// </summary>
	public class RdnTextureMap
	{
		private string name;
		private int width,height;
		private RdnTexel[,] texels;
		
		public RdnTextureMap(int width,int height)
		{
			this.width=width;
			this.height=height;
			texels=new RdnTexel[width,height];
		}

		public void Clear()
		{
			this.width=width;
			this.height=height;
			texels=new RdnTexel[width,height];
		}
		public void Clear(RdnTexel texel)
		{
			for(int x=0;x<width;x++)
				for(int y=0;y<height;y++)
					texels[x,y]=texel;
		}
		public RdnTexel GetTexel(float s,float t,bool filter)
		{
			if(s<0f)
				s=1f-s;
			if(t<0f)
				t=1f-t;
			if(filter)
			{
				float fx=(s*(float)(width-1))%width;
				float fy=(t*(float)(height-1))%height;
				int x0=(int)Math.Floor(fx);
				int x1=(int)Math.Ceiling(fx);
				int y0=(int)Math.Floor(fy);
				int y1=(int)Math.Ceiling(fy);
				float fu=fx-x0;
				float fv=fy-y0;
				RdnTexel texel=new RdnTexel();
				texel.Color=RdnColor.FromFilter(texels[x0%width,y0%height].Color,
					texels[x1%width,y0%height].Color,
					texels[x0%width,y1%height].Color,
					texels[x1%width,y1%height].Color,
					fu,fv);
				texel.Opacity=RdnColor.FromFilter(texels[x0%width,y0%height].Opacity,
					texels[x1%width,y0%height].Opacity,
					texels[x0%width,y1%height].Opacity,
					texels[x1%width,y1%height].Opacity,
					fu,fv);
				return texel;
			}
			else
				return texels[(int)(s*(float)(width-1))%width,(int)(t*(float)(height-1))%height];
		}

		public static RdnTextureMap FromBitmap(Bitmap bitmap)
		{
			RdnTextureMap texture=new RdnTextureMap(bitmap.Width,bitmap.Height);
			for(int x=0;x<texture.Width;x++)
			{
				for(int y=0;y<texture.Height;y++)
				{
					RdnTexel texel=new RdnTexel();
					texel.Color=RdnColor.FromColor(bitmap.GetPixel(x,y));
					texel.Opacity=new RdnColor(1f,1f,1f);
					texture[x,y]=texel;
				}
			}
			return texture;
		}
		public static RdnTextureMap FromShadowMap(RdnShadowMap shadowmap)
		{
			RdnTextureMap texture=new RdnTextureMap(shadowmap.Width,shadowmap.Height);
			for(int x=0;x<texture.Width;x++)
			{
				for(int y=0;y<texture.Height;y++)
				{
					RdnTexel texel=new RdnTexel();
					texel.Color=new RdnColor(shadowmap[x,y]);
					texel.Opacity=new RdnColor(1f,1f,1f);
					texture[x,y]=texel;
				}
			}
			return texture;
		}

		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				name=value;
			}
		}
		public int Width
		{
			get
			{
				return width;
			}
		}
		public int Height
		{
			get
			{
				return height;
			}
		}
		public RdnTexel this[int x, int y]
		{ 
			get
			{
				return texels[x,y];
			}
			set
			{
				texels[x,y]=value;
			}
		}
	}
	public class RdnSphericalMap
	{
		public RdnTextureMap Map;
		public RdnVector Axis;
	}
	public class RdnCubicMap
	{
		public RdnTextureMap MapPx,MapPy,MapPz,MapNx,MapNy,MapNz;
	}

	public struct RdnTexel
	{
		public RdnColor Color,Opacity;
	}
}
