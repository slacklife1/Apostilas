using System;

namespace Rdn.Basis
{
	/// <summary>
	/// Summary description for RdnTriangle.
	/// </summary>
	public sealed class RdnTriangle
	{
		private RdnVector vertex0,vertex1,vertex2;
		private RdnVector texcoord0,texcoord1,texcoord2;
				
		public RdnTriangle(RdnVector vertex0,RdnVector vertex1,RdnVector vertex2)
		{
			this.vertex0=vertex0;this.vertex1=vertex1;this.vertex2=vertex2;
			texcoord0=texcoord1=texcoord2=new RdnVector(0,0,0);
		}
		public RdnTriangle(RdnVector vertex0,RdnVector vertex1,RdnVector vertex2,RdnVector texcoord0,RdnVector texcoord1,RdnVector texcoord2)
		{
			this.vertex0=vertex0;this.vertex1=vertex1;this.vertex2=vertex2;
			this.texcoord0=texcoord0;this.texcoord1=texcoord1;this.texcoord2=texcoord2;
		}

		public void TransformVertices(RdnMatrix matrix)
		{
			vertex0=matrix*vertex0;
			vertex1=matrix*vertex1;
			vertex2=matrix*vertex2;
		}
		public void TransformTexCoords(RdnMatrix matrix)
		{
			texcoord0=matrix*texcoord0;
			texcoord1=matrix*texcoord1;
			texcoord2=matrix*texcoord2;
		}
		public RdnVector GetVertexPoint(float a,float b)
		{
			return new RdnVector(RdnMath.BaryCentric(vertex0.X,vertex1.X,vertex2.X,a,b),
				RdnMath.BaryCentric(vertex0.Y,vertex1.Y,vertex2.Y,a,b),
				RdnMath.BaryCentric(vertex0.Z,vertex1.Z,vertex2.Z,a,b));
		}
		public RdnVector GetTexCoordPoint(float a,float b)
		{
			return new RdnVector(RdnMath.BaryCentric(texcoord0.X,texcoord1.X,texcoord2.X,a,b),
				RdnMath.BaryCentric(texcoord0.Y,texcoord1.Y,texcoord2.Y,a,b),
				RdnMath.BaryCentric(texcoord0.Z,texcoord1.Z,texcoord2.Z,a,b));
		}
		public RdnTriangle FromTransform(RdnMatrix vertexmatrix,RdnMatrix texcoordmatrix)
		{
			return new RdnTriangle(vertexmatrix*vertex0,vertexmatrix*vertex1,vertexmatrix*vertex2,texcoordmatrix*texcoord0,texcoordmatrix*texcoord1,texcoordmatrix*texcoord2);
		}

		public RdnVector Vertex0
		{
			get
			{
				return vertex0;
			}
			set
			{
				vertex0=value;
			}
		}
		public RdnVector Vertex1
		{
			get
			{
				return vertex1;
			}
			set
			{
				vertex1=value;
			}
		}
		public RdnVector Vertex2
		{
			get
			{
				return vertex2;
			}
			set
			{
				vertex2=value;
			}
		}
		public RdnVector TexCoord0
		{
			get
			{
				return texcoord0;
			}
			set
			{
				texcoord0=value;
			}
		}
		public RdnVector TexCoord1
		{
			get
			{
				return texcoord1;
			}
			set
			{
				texcoord1=value;
			}
		}
		public RdnVector TexCoord2
		{
			get
			{
				return texcoord2;
			}
			set
			{
				texcoord2=value;
			}
		}
		public RdnVector Vector0
		{
			get
			{
				return vertex1-vertex0;
			}
		}
		public RdnVector Vector1
		{
			get
			{
				return vertex2-vertex0;
			}
		}
		public RdnVector Center
		{
			get
			{
				return new RdnVector(RdnMath.BaryCentric(vertex0.X,vertex1.X,vertex2.X,0.5f,0.5f)/2,
					RdnMath.BaryCentric(vertex0.Y,vertex1.Y,vertex2.Y,0.5f,0.5f)/2,
					RdnMath.BaryCentric(vertex0.Z,vertex1.Z,vertex2.Z,0.5f,0.5f)/2);
			}
		}
		public RdnVector Normal
		{
			get
			{
				RdnVector norm=Vector0^Vector1;
				norm.Normalize();
				return norm;
			}
		}
		public float Area
		{
			get
			{
				return (Vector0^Vector1).Length/2.0f;
			}
		}
	}
}
