using System;
using System.Drawing;

namespace Rdn.Basis
{
	/// <summary>
	/// Summary description for RdnMicroPolygon.
	/// </summary>
	public class RdnMicroPolygon
	{
		private RdnVector point00,point01,point11,point10;

		public RdnMicroPolygon()
		{
		}
		public RdnMicroPolygon(RdnVector point00,RdnVector point01,RdnVector point11,RdnVector point10)
		{
			this.point00=point00;
			this.point01=point01;
			this.point11=point11;
			this.point10=point10;
		}

		public void Transform(RdnMatrix matrix)
		{
			point00=matrix*point00;
			point01=matrix*point01;
			point11=matrix*point11;
			point10=matrix*point10;
		}

		public RdnMicroPolygon FromTransform(RdnMatrix matrix)
		{
			RdnMicroPolygon mp=new RdnMicroPolygon();
			mp.Point00=matrix*point00;
			mp.Point01=matrix*point01;
			mp.Point11=matrix*point11;
			mp.Point10=matrix*point10;
			return mp;
		}

		public RdnVector Point00
		{
			get
			{
				return point00;
			}
			set
			{
				point00=value;
			}
		}
		public RdnVector Point01
		{
			get
			{
				return point01;
			}
			set
			{
				point01=value;
			}
		}
		public RdnVector Point11
		{
			get
			{
				return point11;
			}
			set
			{
				point11=value;
			}
		}
		public RdnVector Point10
		{
			get
			{
				return point10;
			}
			set
			{
				point10=value;
			}
		}
		public RdnVector dPdu
		{
			get
			{
				RdnVector a=point10-point00;
				RdnVector b=point11-point01;
				if(b.Length>a.Length)
					a=b;
				return a.Normalized;
			}
		}
		public RdnVector dPdv
		{
			get
			{
				RdnVector a=point01-point00;
				RdnVector b=point11-point10;
				if(b.Length>a.Length)
					a=b;
				return a.Normalized;
			}
		}
		public RdnVector Normal
		{
			get
			{
				return (dPdu^dPdv).Normalized;
			}
		}
	}

	public class RdnMicroGrid
	{
		private RdnVector[,] points;
		private int usize,vsize;

		public RdnMicroGrid(int usize,int vsize)
		{
			this.usize=usize;this.vsize=vsize;
			points=new RdnVector[usize+1,vsize+1];
		}

		public void Transform(RdnMatrix matrix)
		{
			for(int u=0;u<=usize;u++)
				for(int v=0;v<=usize;v++)
					points[u,v]=matrix*points[u,v];
		}
		public RdnMicroPolygon GetMicroPolygon(int u,int v)
		{
			return new RdnMicroPolygon(points[u,v],points[u,v+1],points[u+1,v+1],points[u+1,v]);
		}
		public RdnMicroPolygon[] GetMicroPolygons()
		{
			RdnMicroPolygon[] mps=new RdnMicroPolygon[usize*vsize];
			for(int u=0;u<usize;u++)
				for(int v=0;v<usize;v++)
					mps[v*usize+u]=GetMicroPolygon(u,v);
			return mps;
		}
		public int EstimateGridSize(int mingridsize,int maxgridsize,float rate)
		{
			float maxusize=0;
			float maxvsize=0;
			for(int u=0;u<usize;u++)
			{
				for(int v=0;v<vsize;v++)
				{
					float udist=(points[u+1,v].X-points[u,v].X)*(points[u+1,v].X-points[u,v].X)+
						(points[u+1,v].Y-points[u,v].Y)*(points[u+1,v].Y-points[u,v].Y);
					float vdist=(points[u,v+1].X-points[u,v].X)*(points[u,v+1].X-points[u,v].X)+
						(points[u,v+1].Y-points[u,v].Y)*(points[u,v+1].Y-points[u,v].Y);
					maxusize=Math.Max(maxusize,udist);
					maxvsize=Math.Max(maxvsize,vdist);
				}
			}
			return 1<<(int)Math.Log(RdnMath.ClampWrap(((usize*vsize)*(float)Math.Sqrt(Math.Max(maxusize,maxvsize)))/rate,mingridsize,maxgridsize),2);
		}

		public RdnMicroGrid FromTransform(RdnMatrix matrix)
		{
			RdnMicroGrid mg=new RdnMicroGrid(usize,vsize);
			for(int u=0;u<=usize;u++)
				for(int v=0;v<=usize;v++)
					mg[u,v]=matrix*points[u,v];
			return mg;
		}

		public RdnVector this[int u,int v]
		{
			get
			{
				return points[u,v];
			}
			set
			{
				points[u,v]=value;
			}
		}
		public int USize
		{
			get
			{
				return usize;
			}
		}
		public int VSize
		{
			get
			{
				return vsize;
			}
		}
	}
}
