using System;

namespace Rdn.Basis
{
	/// <summary>
	/// Summary description for RdnBox.
	/// </summary>
	public struct RdnBox
	{
		private float minx,miny,minz,maxx,maxy,maxz;
				
		public RdnBox(float minx,float miny,float minz,float maxx,float maxy,float maxz)
		{
			this.minx=minx;
			this.miny=miny;
			this.minz=minz;
			this.maxx=maxx;
			this.maxy=maxy;
			this.maxz=maxz;
		}
		public RdnBox(RdnVector min,RdnVector max)
		{
			this.minx=min.X;
			this.miny=min.Y;
			this.minz=min.Z;
			this.maxx=max.X;
			this.maxy=max.Y;
			this.maxz=max.Z;
		}
		public RdnBox(float sx,float sy,float sz)
		{
			this.minx=-sx/2f;
			this.miny=-sy/2f;
			this.minz=-sz/2f;
			this.maxx=sx/2f;
			this.maxy=sy/2f;
			this.maxz=sz/2f;
		}
				
		public void Offset(float x,float y,float z)
		{
			this.minx+=x;
			this.miny+=y;
			this.minz+=z;
			this.maxx+=x;
			this.maxy+=y;
			this.maxz+=z;
		}
		public void Scale(float x,float y,float z)
		{
			this.minx=this.minx*x;
			this.miny=this.miny*y;
			this.minz=this.minz*z;
			this.maxx=this.maxx*x;
			this.maxy=this.maxy*y;
			this.maxz=this.maxz*z;
		}
		public bool IntersectWith(RdnBox box)
		{
			if(((minx<box.MaxX)&&(maxx>box.MinX))&&
				((miny<box.MaxY)&&(maxy>box.MinY))&&
				((minz<box.MaxZ)&&(maxz>box.MinZ)))
				return true;
			return false;
		}
//		public bool Intersect(out RdnBox t,RdnBox RdnBox)
//		{
//			return false;
//		}

		public bool PointIn(RdnVector point)
		{
			if(RdnMath.PointInBox(minx,miny,minz,maxx,maxy,maxz,point.X,point.Y,point.Z))
				return true;
			return false;
		}
		public bool PointIn(RdnMicroPolygon micropolygon)
		{
			if(PointIn(micropolygon.Point00)||PointIn(micropolygon.Point01)||PointIn(micropolygon.Point11)||PointIn(micropolygon.Point10))
				return true;
			return false;
		}
		public static RdnBox FromMicroPolygon(RdnMicroPolygon micropolygon)
		{
			RdnBox boundingbox=new RdnBox(float.MaxValue,float.MaxValue,float.MaxValue,float.MinValue,float.MinValue,float.MinValue);
			if(micropolygon.Point00.X<boundingbox.MinX)
				boundingbox.MinX=micropolygon.Point00.X;
			if(micropolygon.Point00.X>boundingbox.MaxX)
				boundingbox.MaxX=micropolygon.Point00.X;
			if(micropolygon.Point00.Y<boundingbox.MinY)
				boundingbox.MinY=micropolygon.Point00.Y;
			if(micropolygon.Point00.Y>boundingbox.MaxY)
				boundingbox.MaxY=micropolygon.Point00.Y;
			if(micropolygon.Point00.Z<boundingbox.MinZ)
				boundingbox.MinZ=micropolygon.Point00.Z;
			if(micropolygon.Point00.Z>boundingbox.MaxZ)
				boundingbox.MaxZ=micropolygon.Point00.Z;						
			if(micropolygon.Point01.X<boundingbox.MinX)
				boundingbox.MinX=micropolygon.Point01.X;
			if(micropolygon.Point01.X>boundingbox.MaxX)
				boundingbox.MaxX=micropolygon.Point01.X;
			if(micropolygon.Point01.Y<boundingbox.MinY)
				boundingbox.MinY=micropolygon.Point01.Y;
			if(micropolygon.Point01.Y>boundingbox.MaxY)
				boundingbox.MaxY=micropolygon.Point01.Y;
			if(micropolygon.Point01.Z<boundingbox.MinZ)
				boundingbox.MinZ=micropolygon.Point01.Z;
			if(micropolygon.Point01.Z>boundingbox.MaxZ)
				boundingbox.MaxZ=micropolygon.Point01.Z;						
			if(micropolygon.Point11.X<boundingbox.MinX)
				boundingbox.MinX=micropolygon.Point11.X;
			if(micropolygon.Point11.X>boundingbox.MaxX)
				boundingbox.MaxX=micropolygon.Point11.X;
			if(micropolygon.Point11.Y<boundingbox.MinY)
				boundingbox.MinY=micropolygon.Point11.Y;
			if(micropolygon.Point11.Y>boundingbox.MaxY)
				boundingbox.MaxY=micropolygon.Point11.Y;
			if(micropolygon.Point11.Z<boundingbox.MinZ)
				boundingbox.MinZ=micropolygon.Point11.Z;
			if(micropolygon.Point11.Z>boundingbox.MaxZ)
				boundingbox.MaxZ=micropolygon.Point11.Z;
			if(micropolygon.Point10.X<boundingbox.MinX)
				boundingbox.MinX=micropolygon.Point10.X;
			if(micropolygon.Point10.X>boundingbox.MaxX)
				boundingbox.MaxX=micropolygon.Point10.X;
			if(micropolygon.Point10.Y<boundingbox.MinY)
				boundingbox.MinY=micropolygon.Point10.Y;
			if(micropolygon.Point10.Y>boundingbox.MaxY)
				boundingbox.MaxY=micropolygon.Point10.Y;
			if(micropolygon.Point10.Z<boundingbox.MinZ)
				boundingbox.MinZ=micropolygon.Point10.Z;
			if(micropolygon.Point10.Z>boundingbox.MaxZ)
				boundingbox.MaxZ=micropolygon.Point10.Z;
			return boundingbox;
		}
		public static RdnBox FromMicroGrid(RdnMicroGrid microgrid)
		{
			RdnBox boundingbox=new RdnBox(float.MaxValue,float.MaxValue,float.MaxValue,float.MinValue,float.MinValue,float.MinValue);
			for(int u=0;u<=microgrid.USize;u++)
			{
				for(int v=0;v<=microgrid.VSize;v++)
				{
					boundingbox.MinX=Math.Min(boundingbox.MinX,microgrid[u,v].X);
					boundingbox.MinY=Math.Min(boundingbox.MinY,microgrid[u,v].Y);
					boundingbox.MinZ=Math.Min(boundingbox.MinZ,microgrid[u,v].Z);
					boundingbox.MaxX=Math.Max(boundingbox.MaxX,microgrid[u,v].X);
					boundingbox.MaxY=Math.Max(boundingbox.MaxY,microgrid[u,v].Y);
					boundingbox.MaxZ=Math.Max(boundingbox.MaxZ,microgrid[u,v].Z);
				}
			}
			return boundingbox;
		}
		public static RdnBox FromTriangle(RdnTriangle triangle)
		{
			RdnBox boundingbox=new RdnBox(float.MaxValue,float.MaxValue,float.MaxValue,float.MinValue,float.MinValue,float.MinValue);
			if(triangle.Vertex0.X<boundingbox.MinX)
				boundingbox.MinX=triangle.Vertex0.X;
			if(triangle.Vertex0.X>boundingbox.MaxX)
				boundingbox.MaxX=triangle.Vertex0.X;
			if(triangle.Vertex0.Y<boundingbox.MinY)
				boundingbox.MinY=triangle.Vertex0.Y;
			if(triangle.Vertex0.Y>boundingbox.MaxY)
				boundingbox.MaxY=triangle.Vertex0.Y;
			if(triangle.Vertex0.Z<boundingbox.MinZ)
				boundingbox.MinZ=triangle.Vertex0.Z;
			if(triangle.Vertex0.Z>boundingbox.MaxZ)
				boundingbox.MaxZ=triangle.Vertex0.Z;						
			if(triangle.Vertex1.X<boundingbox.MinX)
				boundingbox.MinX=triangle.Vertex1.X;
			if(triangle.Vertex1.X>boundingbox.MaxX)
				boundingbox.MaxX=triangle.Vertex1.X;
			if(triangle.Vertex1.Y<boundingbox.MinY)
				boundingbox.MinY=triangle.Vertex1.Y;
			if(triangle.Vertex1.Y>boundingbox.MaxY)
				boundingbox.MaxY=triangle.Vertex1.Y;
			if(triangle.Vertex1.Z<boundingbox.MinZ)
				boundingbox.MinZ=triangle.Vertex1.Z;
			if(triangle.Vertex1.Z>boundingbox.MaxZ)
				boundingbox.MaxZ=triangle.Vertex1.Z;						
			if(triangle.Vertex2.X<boundingbox.MinX)
				boundingbox.MinX=triangle.Vertex2.X;
			if(triangle.Vertex2.X>boundingbox.MaxX)
				boundingbox.MaxX=triangle.Vertex2.X;
			if(triangle.Vertex2.Y<boundingbox.MinY)
				boundingbox.MinY=triangle.Vertex2.Y;
			if(triangle.Vertex2.Y>boundingbox.MaxY)
				boundingbox.MaxY=triangle.Vertex2.Y;
			if(triangle.Vertex2.Z<boundingbox.MinZ)
				boundingbox.MinZ=triangle.Vertex2.Z;
			if(triangle.Vertex2.Z>boundingbox.MaxZ)
				boundingbox.MaxZ=triangle.Vertex2.Z;
			return boundingbox;
		}
		public static RdnBox FromTriangles(RdnTriangle[] triangles)
		{
			RdnBox boundingbox=new RdnBox(float.MaxValue,float.MaxValue,float.MaxValue,float.MinValue,float.MinValue,float.MinValue);
			for(int i=0;i<triangles.Length;i++)
			{
				if(triangles[i].Vertex0.X<boundingbox.MinX)
					boundingbox.MinX=triangles[i].Vertex0.X;
				if(triangles[i].Vertex0.X>boundingbox.MaxX)
					boundingbox.MaxX=triangles[i].Vertex0.X;
				if(triangles[i].Vertex0.Y<boundingbox.MinY)
					boundingbox.MinY=triangles[i].Vertex0.Y;
				if(triangles[i].Vertex0.Y>boundingbox.MaxY)
					boundingbox.MaxY=triangles[i].Vertex0.Y;
				if(triangles[i].Vertex0.Z<boundingbox.MinZ)
					boundingbox.MinZ=triangles[i].Vertex0.Z;
				if(triangles[i].Vertex0.Z>boundingbox.MaxZ)
					boundingbox.MaxZ=triangles[i].Vertex0.Z;						
				if(triangles[i].Vertex1.X<boundingbox.MinX)
					boundingbox.MinX=triangles[i].Vertex1.X;
				if(triangles[i].Vertex1.X>boundingbox.MaxX)
					boundingbox.MaxX=triangles[i].Vertex1.X;
				if(triangles[i].Vertex1.Y<boundingbox.MinY)
					boundingbox.MinY=triangles[i].Vertex1.Y;
				if(triangles[i].Vertex1.Y>boundingbox.MaxY)
					boundingbox.MaxY=triangles[i].Vertex1.Y;
				if(triangles[i].Vertex1.Z<boundingbox.MinZ)
					boundingbox.MinZ=triangles[i].Vertex1.Z;
				if(triangles[i].Vertex1.Z>boundingbox.MaxZ)
					boundingbox.MaxZ=triangles[i].Vertex1.Z;						
				if(triangles[i].Vertex2.X<boundingbox.MinX)
					boundingbox.MinX=triangles[i].Vertex2.X;
				if(triangles[i].Vertex2.X>boundingbox.MaxX)
					boundingbox.MaxX=triangles[i].Vertex2.X;
				if(triangles[i].Vertex2.Y<boundingbox.MinY)
					boundingbox.MinY=triangles[i].Vertex2.Y;
				if(triangles[i].Vertex2.Y>boundingbox.MaxY)
					boundingbox.MaxY=triangles[i].Vertex2.Y;
				if(triangles[i].Vertex2.Z<boundingbox.MinZ)
					boundingbox.MinZ=triangles[i].Vertex2.Z;
				if(triangles[i].Vertex2.Z>boundingbox.MaxZ)
					boundingbox.MaxZ=triangles[i].Vertex2.Z;
			}
			return boundingbox;
		}

		public float MinX
		{
			get
			{
				return minx;
			}
			set
			{
				minx=value;
			}
		}
		public float MinY
		{
			get
			{
				return miny;
			}
			set
			{
				miny=value;
			}
		}
		public float MinZ
		{
			get
			{
				return minz;
			}
			set
			{
				minz=value;
			}
		}
		public float MaxX
		{
			get
			{
				return maxx;
			}
			set
			{
				maxx=value;
			}
		}
		public float MaxY
		{
			get
			{
				return maxy;
			}
			set
			{
				maxy=value;
			}
		}
		public float MaxZ
		{
			get
			{
				return maxz;
			}
			set
			{
				maxz=value;
			}
		}
		public RdnVector Min
		{
			get
			{
				return new RdnVector(minx,miny,minz);
			}
		}
		public RdnVector Max
		{
			get
			{
				return new RdnVector(maxx,maxy,maxz);
			}
		}
		public RdnVector Center
		{
			get
			{
				return new RdnVector((maxx+minx)/2.0f,(maxy+miny)/2.0f,(maxz+minz)/2.0f);
			}
		}
		public RdnVector Distances
		{
			get
			{
				return new RdnVector(Math.Abs(maxx-minx),Math.Abs(maxy-miny),Math.Abs(maxz-minz));
			}
		}
	}
}