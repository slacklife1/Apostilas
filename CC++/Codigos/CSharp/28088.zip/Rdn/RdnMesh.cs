using System;
using System.IO;
using System.Drawing;

namespace Rdn.Basis
{
	/// <summary>
	/// Summary description for RdnMesh.
	/// </summary>
	public class RdnMesh
	{
		private RdnMatrix transform;
		private RdnVertex[] vertices;
		private RdnFace[] faces;

		public RdnMesh()
		{
			transform=new RdnMatrix();
			transform.Identity();
		}
		public RdnMesh(string filename)
		{
			transform=new RdnMatrix();
			BinaryReader rb=new BinaryReader(new FileStream(filename,FileMode.Open));
			for(int i=0;i<4;i++)
				for(int j=0;j<4;j++)
					transform[i,j]=rb.ReadSingle();
			int numvert=rb.ReadInt32();
			if(numvert!=-1)
			{
				vertices=new RdnVertex[numvert];
				for(int i=0;i<vertices.Length;i++)
				{
					vertices[i].Point.X=rb.ReadSingle();
					vertices[i].Point.Y=rb.ReadSingle();
					vertices[i].Point.Z=rb.ReadSingle();
					vertices[i].Normal.X=rb.ReadSingle();
					vertices[i].Normal.Y=rb.ReadSingle();
					vertices[i].Normal.Z=rb.ReadSingle();
					vertices[i].TexCoord.X=rb.ReadSingle();
					vertices[i].TexCoord.Y=rb.ReadSingle();
				}
			}
			int numfac=rb.ReadInt32();
			if(numfac!=-1)
			{
				faces=new RdnFace[numfac];
				for(int i=0;i<faces.Length;i++)
				{
					faces[i].A=rb.ReadInt32();
					faces[i].B=rb.ReadInt32();
					faces[i].C=rb.ReadInt32();
					faces[i].D=rb.ReadInt32();
				}
			}
			rb.Close();
		}

		public void Save(string filename)
		{
			BinaryWriter wb=new BinaryWriter(new FileStream(filename,FileMode.Create));
			for(int i=0;i<4;i++)
				for(int j=0;j<4;j++)
					wb.Write((float)transform[i,j]);
			if(vertices!=null)
			{
				wb.Write((int)vertices.Length);
				for(int i=0;i<vertices.Length;i++)
				{
					wb.Write((float)vertices[i].Point.X);
					wb.Write((float)vertices[i].Point.Y);
					wb.Write((float)vertices[i].Point.Z);
					wb.Write((float)vertices[i].Normal.X);
					wb.Write((float)vertices[i].Normal.Y);
					wb.Write((float)vertices[i].Normal.Z);
					wb.Write((float)vertices[i].TexCoord.X);
					wb.Write((float)vertices[i].TexCoord.Y);
				}
			}
			else
				wb.Write((int)-1);
			if(faces!=null)
			{
				wb.Write((int)faces.Length);
				for(int i=0;i<faces.Length;i++)
				{
					wb.Write((int)faces[i].A);
					wb.Write((int)faces[i].B);
					wb.Write((int)faces[i].C);
					wb.Write((int)faces[i].D);
				}
			}
			else
				wb.Write((int)-1);
			wb.Close();
		}

		public RdnMatrix Transform
		{
			get
			{
				return transform;
			}
			set
			{
				transform=value;
			}
		}
		public RdnVertex[] Vertices
		{
			get
			{
				return vertices;
			}
			set
			{
				vertices=value;
			}
		}
		public RdnFace[] Faces
		{
			get
			{
				return faces;
			}
			set
			{
				faces=value;
			}
		}
		public RdnBox BoundingBox
		{
			get
			{
				RdnBox box=new RdnBox(float.MaxValue,float.MaxValue,float.MaxValue,float.MinValue,float.MinValue,float.MinValue);
				for(int i=0;i<vertices.Length;i++)
				{
					box.MinX=Math.Min(box.MinX,vertices[i].Point.X);
					box.MinY=Math.Min(box.MinY,vertices[i].Point.Y);
					box.MinZ=Math.Min(box.MinZ,vertices[i].Point.Z);
					box.MaxX=Math.Max(box.MaxX,vertices[i].Point.X);
					box.MaxY=Math.Max(box.MaxY,vertices[i].Point.Y);
					box.MaxZ=Math.Max(box.MaxZ,vertices[i].Point.Z);
				}
				return box;
			}
		}
	}

	public struct RdnVertex
	{
		public RdnVector Point,Normal;
		public PointF TexCoord;
	}
	public struct RdnFace
	{
		public int A,B,C,D;

		public RdnFace(int a,int b,int c,int d)
		{
			A=a;B=b;C=c;D=d;
		}
	}
}
