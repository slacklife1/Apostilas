using System;
using System.Collections;
using Rdn.Basis;

namespace Rdn.Maps
{
	/// <summary>
	/// Summary description for RdnOcTree.
	/// </summary>
	public sealed class RdnMicroPolygonMap
	{
		private RdnBox box;
		private ArrayList micropolygons;
		private RdnMicroPolygonMap parent;
		private RdnMicroPolygonMap[] childs;

		public RdnMicroPolygonMap(RdnBox box,RdnMicroPolygonMap parent)
		{
			this.box=box;
			micropolygons=new ArrayList();
			this.parent=parent;
			this.childs=new RdnMicroPolygonMap[8];
		}

		public void AddMicroPolygon(RdnMicroPolygon micropolygon)
		{
			micropolygons.Add(micropolygon);
		}
		public void AddMicroGrid(RdnMicroGrid microgrid)
		{
			for(int u=0;u<microgrid.USize;u++)
				for(int v=0;v<microgrid.VSize;v++)
					AddMicroPolygon(microgrid.GetMicroPolygon(u,v));
		}
		public void Optimize()
		{
			box=new RdnBox(float.MaxValue,float.MaxValue,float.MaxValue,float.MinValue,float.MinValue,float.MinValue);
			for(int i=0;i<micropolygons.Count;i++)
			{
				RdnBox bb=RdnBox.FromMicroPolygon(((RdnMicroPolygon)micropolygons[i]));
				box.MinX=Math.Min(box.MinX,bb.MinX);
				box.MinY=Math.Min(box.MinY,bb.MinY);
				box.MinZ=Math.Min(box.MinZ,bb.MinZ);
				box.MaxX=Math.Max(box.MaxX,bb.MaxX);
				box.MaxY=Math.Max(box.MaxY,bb.MaxY);
				box.MaxZ=Math.Max(box.MaxZ,bb.MaxZ);
			}
		}
		public void SubDivide(int limit,int levels)
		{
//			float minx=box.MinX;
//			float miny=box.MinY;
//			float minz=box.MinZ;
//			float maxx=box.MaxX;
//			float maxy=box.MaxY;
//			float maxz=box.MaxZ;
//			float midx=(maxx+minx)/2f;
//			float midy=(maxy+miny)/2f;
//			float midz=(maxz+minz)/2f;
//			childs[0]=new RdnMicroPolygonMap(new RdnBox(minx,miny,minz,midx,midy,midz),this);
//			childs[1]=new RdnMicroPolygonMap(new RdnBox(minx,midy,minz,midx,maxy,midz),this);
//			childs[2]=new RdnMicroPolygonMap(new RdnBox(midx,midy,minz,maxx,maxy,midz),this);
//			childs[3]=new RdnMicroPolygonMap(new RdnBox(midx,miny,minz,maxx,midy,midz),this);
//			childs[4]=new RdnMicroPolygonMap(new RdnBox(minx,miny,midz,midx,midy,maxz),this);
//			childs[5]=new RdnMicroPolygonMap(new RdnBox(minx,midy,midz,midx,maxy,maxz),this);
//			childs[6]=new RdnMicroPolygonMap(new RdnBox(midx,midy,midz,maxx,maxy,maxz),this);
//			childs[7]=new RdnMicroPolygonMap(new RdnBox(midx,miny,midz,maxx,midy,maxz),this);
//			if(Math.Min(box.Distances.X,Math.Min(box.Distances.Y,box.Distances.Z))>area)
			RdnVector center=box.Center;
			RdnVector topCenter=center;topCenter.Y=box.MaxY;
			RdnVector v1,v2;
			float halfy =(box.MaxY-box.MinY)/2.0f; 
			v1=center;v1.X=box.MinX;
			v2=topCenter;v2.Z=box.MaxZ;
			childs[0]=new RdnMicroPolygonMap(new RdnBox(v1,v2),this); 
			v1=center; 
			v2=box.Max;
			childs[1]=new RdnMicroPolygonMap(new RdnBox(v1,v2),this); 
			v1=center;v1.X=box.MinX;v1.Z=box.MinZ; 
			v2=topCenter;
			childs[2]=new RdnMicroPolygonMap(new RdnBox(v1,v2),this); 
			v1=center;v1.Z=box.MinZ; 
			v2=topCenter;v2.X=box.MaxX;
			childs[3]=new RdnMicroPolygonMap(new RdnBox(v1,v2),this); 
			v1=center;v1.X=box.MinX;    
			v2=topCenter;v2.Z=box.MaxZ; 
			v1.Y-=halfy;
			v2.Y-=halfy;
			childs[4]=new RdnMicroPolygonMap(new RdnBox(v1,v2),this); 
			v1=center; 
			v2=box.Max;
			v1.Y-=halfy;
			v2.Y-=halfy;
			childs[5]=new RdnMicroPolygonMap(new RdnBox(v1,v2),this); 
			v1=center;v1.X=box.MinX;v1.Z=box.MinZ; 
			v2=topCenter;
			v1.Y-=halfy;
			v2.Y-=halfy;
			childs[6]=new RdnMicroPolygonMap(new RdnBox(v1,v2),this); 
			v1=center;v1.Z=box.MinZ; 
			v2=topCenter;v2.X=box.MaxX;
			v1.Y-=halfy;
			v2.Y-=halfy;
			childs[7]=new RdnMicroPolygonMap(new RdnBox(v1,v2),this);
			for(int i=0;i<micropolygons.Count;i++)
			{
				for(int j=0;j<8;j++)
				{
					if(childs[j].Box.PointIn(((RdnMicroPolygon)micropolygons[i])))
					{
						childs[j].AddMicroPolygon(((RdnMicroPolygon)micropolygons[i]));
						break;
					}
				}
			}
			micropolygons.Clear();
			for(int k=0;k<8;k++)
			{
				if(childs[k].NumMicroPolygons>0)
				{
					if(childs[k].NumMicroPolygons!=micropolygons.Count)
					{
						childs[k].Optimize();
						if(childs[k].NumMicroPolygons>limit&&levels>0)
							childs[k].SubDivide(limit,levels-1);
					}
				}
				else
					childs[k]=null;
			}
		}
		public void Trace(ArrayList micropolygonlist,RdnRay ray)
		{
			float d0,d1;
			if(ray.CastBox(out d0,out d1,box))
			{
				if(micropolygons.Count>0)
				{
					for(int i=0;i<micropolygons.Count;i++)
						micropolygonlist.Add((RdnMicroPolygon)micropolygons[i]);
				}
				else
				{
					for(int i=0;i<8;i++)
						if(childs[i]!=null)
							childs[i].Trace(micropolygonlist,ray);
				}
			}
		}		
		public void Trace(ArrayList micropolygonlist,RdnRay ray,float near,float far)
		{
			float d0,d1;
			if(ray.CastBox(out d0,out d1,box))
			{
				if((d0>near||d1>near)&&(d0<far||d1<far))
				{
					if(micropolygons.Count>0)
					{
						for(int i=0;i<micropolygons.Count;i++)
							micropolygonlist.Add((RdnMicroPolygon)micropolygons[i]);
					}
					else
					{
						for(int i=0;i<8;i++)
							if(childs[i]!=null)
								childs[i].Trace(micropolygonlist,ray,near,far);
					}
				}
			}
		}

		public RdnBox Box
		{ 
			get
			{
				return box;
			}
			set
			{
				box=value;
			}
		}
		public int NumMicroPolygons
		{ 
			get
			{
				return micropolygons.Count;
			}
		}
		public RdnMicroPolygonMap Parent
		{ 
			get
			{
				return parent;
			}
			set
			{
				parent=value;
			}
		}
		public RdnMicroPolygonMap[] Childs
		{ 
			get
			{
				return childs;
			}
		}
	}
}
