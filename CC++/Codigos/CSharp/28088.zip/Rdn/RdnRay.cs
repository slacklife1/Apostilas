using System;
using System.Collections;
using Rdn.Maps;

namespace Rdn.Basis
{
	/// <summary>
	/// Summary description for RdnRay.
	/// </summary>
	public class RdnRay
	{
		private RdnRayType type;
		private RdnVector origin,direction;

		public RdnRay()
		{
		}
		public RdnRay(RdnVector origin,RdnVector direction)
		{
			this.origin=origin;this.direction=direction.Normalized;
		}
		public RdnRay(RdnRayType type,RdnVector origin,RdnVector direction)
		{
			this.type=type;
			this.origin=origin;
			this.direction=direction.Normalized;
		}
				
		public RdnVector GetPoint(float dist)
		{
			return origin+direction*dist;
		}
		public bool CastPlane(out float dist,RdnVector position,RdnVector normal)
		{
			dist=0;
			normal.Normalize();
			float D=normal*direction;
			if(D==0)
				return false;
			dist=(normal*(position-origin))/D;
			if(dist<=0.0f)
				return false;
			return true;
		}
		public bool CastSphere(out float dist0,out float dist1,RdnVector center,float radius)
		{
			dist0=dist1=0;
			RdnVector oc=center-origin;
			float B=direction*oc;
			if(B<0)
				return false;
			float C=oc*oc-radius*radius;
			float D=B*B-C;
			if(D<0)
				return false;
			dist0=(B-(float)Math.Sqrt(D));
			dist1=(B+(float)Math.Sqrt(D));
			if((dist0<=0.0f)&&(dist1<=0.0f))
				return false;
			return true;
		}
		public bool CastBox(out float dist0,out float dist1,RdnBox box) 
		{
			dist0=dist1=0;
			float q0=float.MinValue;
			float q1=float.MaxValue;
			if(direction.X==0.0f)
			{
				if(origin.X<box.MinX||origin.X>box.MaxX)
					return false;
			}
			else
			{
				float r0=(box.MinX-origin.X)/direction.X;
				float r1=(box.MaxX-origin.X)/direction.X;
				if(r0>r1)
				{
					float temp=r0;
					r0=r1;
					r1=temp;
				}
				if(r0>q0)
					q0=r0;					
				if(r1<q1)
					q1=r1;					
				if(q0>q1) 
					return false;
				if(q1<0.0f) 
					return false;
			}
			if(direction.Y==0.0f)
			{
				if(origin.Y<box.MinY||origin.Y>box.MaxY)
					return false;
			}
			else 
			{
				float r0=(box.MinY-origin.Y)/direction.Y;
				float r1=(box.MaxY-origin.Y)/direction.Y;
				if(r0>r1)
				{
					float temp=r0;
					r0=r1;
					r1=temp;
				}
				if(r0>q0)
					q0=r0;					
				if(r1<q1)
					q1=r1;					
				if(q0>q1) 
					return false;
				if(q1<0.0f) 
					return false;
			}
			if(direction.Z==0.0f)
			{
				if(origin.Z<box.MinZ||origin.Z>box.MaxZ)
					return false;
			}
			else 
			{
				float r0=(box.MinZ-origin.Z)/direction.Z;
				float r1=(box.MaxZ-origin.Z)/direction.Z;
				if(r0>r1)
				{
					float temp=r0;
					r0=r1;
					r1=temp;
				}
				if(r0>q0)
					q0=r0;					
				if(r1<q1)
					q1=r1;					
				if(q0>q1) 
					return false;
				if(q1<0.0f) 
					return false;
			}
			dist0=q0;
			dist1=q1;
			if((dist0<=0.0f)&&(dist1<=0.0f))
				return false;
			return true;
		}
		public bool CastTriangle(out float dist,out float u,out float v,RdnTriangle triangle)
		{
			dist=u=v=0;
			RdnVector edge1,edge2,tvec,pvec,qvec;
			float det,inv_det;
			edge1=triangle.Vector0;
			edge2=triangle.Vector1;
			pvec=direction^edge2;				 
			det=edge1*pvec;				
			if((det>-float.Epsilon)&&(det<float.Epsilon))
				return false;
			inv_det=1.0f/det;
			tvec=origin-triangle.Vertex0;				 
			u=(tvec*pvec)*inv_det;
			if((u<0.0f)||(u>1.0f))
				return false;
			qvec=tvec^edge1;				
			v=(direction*qvec)*inv_det;
			if((v<0.0f)||(u+v>1.0f))
				return false;				
			dist=(edge2*qvec)*inv_det;
			if(dist<=0.0f)
				return false;					
			return true;
		}
		public RdnTriangle CastTriangles(out float dist,out float u,out float v,float near,float far,RdnTriangle[] triangles)
		{
			RdnTriangle hit=null;
			dist=far;u=v=0;
			float disti,ui,vi;
			for(int i=0;i<triangles.Length;i++)
			{
				if(CastTriangle(out disti,out ui,out vi,triangles[i]))
				{	
					if((disti<dist)&&(disti>near)&&(disti<far))
					{
						dist=disti;u=ui;v=vi;
						hit=triangles[i];
					}
				}
			}
			return hit;
		}
		public bool CastMicroPolygon(out float dist,out float u,out float v,RdnMicroPolygon micropolygon)
		{
			if(CastTriangle(out dist,out u,out v,new RdnTriangle(micropolygon.Point00,micropolygon.Point01,micropolygon.Point10)))
				return true;
			else if(CastTriangle(out dist,out u,out v,new RdnTriangle(micropolygon.Point11,micropolygon.Point10,micropolygon.Point01)))
			{
				u=1f-u;
				v=1f-v;
				return true;
			}
			return false;
		}
		public RdnMicroPolygon CastMicroPolygons(out float dist,out float u,out float v,float near,float far,RdnMicroPolygon[] micropolygons)
		{
			RdnMicroPolygon hit=null;
			dist=far;u=v=0;
			float disti,ui,vi;
			for(int i=0;i<micropolygons.Length;i++)
			{
				if(CastMicroPolygon(out disti,out ui,out vi,micropolygons[i]))
				{	
					if((disti<dist)&&(disti>near)&&(disti<far))
					{
						dist=disti;u=ui;v=vi;
						hit=micropolygons[i];
					}
				}
			}
			return hit;
		}
		public RdnMicroPolygon CastMicroPolygons(out float dist,out float u,out float v,float near,float far,RdnMicroPolygonMap micropolygonmap)
		{
			RdnMicroPolygon hit=null;
			dist=far;u=v=0;
			if(micropolygonmap!=null)
			{
				float disti,ui,vi;
				ArrayList micropolygonlist=new ArrayList();
				micropolygonmap.Trace(micropolygonlist,this,near,far);
				for(int i=0;i<micropolygonlist.Count;i++)
				{
					if(CastMicroPolygon(out disti,out ui,out vi,(RdnMicroPolygon)micropolygonlist[i]))
					{	
						if((disti<dist)&&(disti>near)&&(disti<far))
						{
							dist=disti;u=ui;v=vi;
							hit=(RdnMicroPolygon)micropolygonlist[i];
						}
					}
				}
			}
			return hit;
		}

		public static RdnRay FromProjection(float x,float y,float width,float height,RdnVector eye,RdnVector at,RdnVector up,float fov)
		{
			RdnVector look=at-eye;
			look.Normalize();
			RdnVector du=up^look;
			RdnVector dv=du^look;
			float fl=(float)(width/(2.0f*Math.Tan((0.5f*fov)*Math.PI/180.0f)));
			RdnVector vp=new RdnVector(look.X*fl-0.5f*(width*du.X+height*dv.X),look.Y*fl-0.5f*(width*du.Y+height*dv.Y),look.Z*fl-0.5f*(width*du.Z+height*dv.Z));
			return new RdnRay(eye,new RdnVector(x*du.X+y*dv.X+vp.X,x*du.Y+y*dv.Y+vp.Y,x*du.Z+y*dv.Z+vp.Z));
		}

		public RdnRayType Type
		{
			get
			{
				return type;
			}
			set
			{
				type=value;
			}
		}
		public RdnVector Origin
		{
			get
			{
				return origin;
			}
			set
			{
				origin=value;
			}
		}
		public RdnVector Direction
		{
			get
			{
				return direction;
			}
			set
			{
				direction=value.Normalized;
			}
		}
	}

	public struct RdnPhoton
	{
		public RdnRay Ray;
		public RdnColor Energy;
		public RdnVector Point;
	}

	public enum RdnRayType{None,Primary,Secondary,Shadow,Direct,Global,Caustic,Gathering};
}