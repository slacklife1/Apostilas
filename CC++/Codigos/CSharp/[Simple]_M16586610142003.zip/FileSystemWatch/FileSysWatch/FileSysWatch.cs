using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;

using System.Runtime.InteropServices;


namespace FileSysWatch
{
	public class FileSysWatch : System.ServiceProcess.ServiceBase
	{

		[DllImport("User32.dll")]
		public static extern int MessageBox(int hParent, string Message, string Caption, int Type);


		private System.IO.FileSystemWatcher fileSystemWatcher1;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FileSysWatch()
		{
			// This call is required by the Windows.Forms Component Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitComponent call
		}

		// The main entry point for the process
		static void Main()
		{
			System.ServiceProcess.ServiceBase[] ServicesToRun;
	
			// More than one user Service may run within the same process. To add
			// another service to this process, change the following line to
			// create a second service object. For example,
			//
			//   ServicesToRun = New System.ServiceProcess.ServiceBase[] {new Service1(), new MySecondUserService()};
			//
			ServicesToRun = new System.ServiceProcess.ServiceBase[] { new FileSysWatch() };

			System.ServiceProcess.ServiceBase.Run(ServicesToRun);
		}

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
			((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
			// 
			// fileSystemWatcher1
			// 
			this.fileSystemWatcher1.EnableRaisingEvents = true;
			this.fileSystemWatcher1.IncludeSubdirectories = true;
			this.fileSystemWatcher1.Path = "C:\\";
			this.fileSystemWatcher1.Deleted += new System.IO.FileSystemEventHandler(this.fileSystemWatcher1_deleted);
			this.fileSystemWatcher1.Renamed += new System.IO.RenamedEventHandler(this.fileSystemWatcher1_renamed);
			this.fileSystemWatcher1.Changed += new System.IO.FileSystemEventHandler(this.fileSystemWatcher1_Changed);
			this.fileSystemWatcher1.Created += new System.IO.FileSystemEventHandler(this.fileSystemWatcher1_created);
			// 
			// FileSysWatch
			// 
			this.CanHandlePowerEvent = true;
			this.CanPauseAndContinue = true;
			this.CanShutdown = true;
			this.ServiceName = "FileSysWatch";
			((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// Set things in motion so your service can do its work.
		/// </summary>
		protected override void OnStart(string[] args)
		{
			// TODO: Add code here to start your service.
		}
 
		/// <summary>
		/// Stop this service.
		/// </summary>
		protected override void OnStop()
		{
			// TODO: Add code here to perform any tear-down necessary to stop your service.
		}

		private void fileSystemWatcher1_Changed(object sender, System.IO.FileSystemEventArgs e)
		{
			if((e.Name.IndexOf("_fso_lg") == -1) && (e.Name.IndexOf("ntuser.dat") == -1) && (e.Name.IndexOf("mmc104.tmp") == -1) && (e.Name.IndexOf("winnt\\system32\\config\\software") == -1) && (e.Name.IndexOf("recycler") == -1) && (e.Name.IndexOf("\\recent") == -1) && (e.Name.IndexOf("log\\nmapserv.log") == -1))
			{
				Scripting.FileSystemObject fso = new Scripting.FileSystemObject();
				Scripting.TextStream fstream = fso.OpenTextFile("C:\\SimpleSolutions\\_fso_lg\\_fso_lg.txt", Scripting.IOMode.ForAppending, true, Scripting.Tristate.TristateUseDefault);
				fstream.WriteLine("Changed," + e.Name + "," + System.DateTime.Now + "," + "" + "," + "");
				fstream.Close();
			}
		}
		// �Free and easy artificial intellagence chatbot hosting�
		// http://www.p2bconsortium.com/
		private void fileSystemWatcher1_created(object sender, System.IO.FileSystemEventArgs e)
		{
			if((e.Name.IndexOf("_fso_lg") == -1) && (e.Name.IndexOf("ntuser.dat") == -1) && (e.Name.IndexOf("mmc104.tmp") == -1) && (e.Name.IndexOf("winnt\\system32\\config\\software") == -1) && (e.Name.IndexOf("recycler") == -1) && (e.Name.IndexOf("\\recent") == -1) && (e.Name.IndexOf("log\\nmapserv.log") == -1) && (e.Name.IndexOf("scs12e.tmp") == -1))
			{
				Scripting.FileSystemObject fso = new Scripting.FileSystemObject();
				Scripting.TextStream fstream = fso.OpenTextFile("C:\\SimpleSolutions\\_fso_lg\\_fso_lg.txt", Scripting.IOMode.ForAppending, true, Scripting.Tristate.TristateUseDefault);
				fstream.WriteLine("Created," + e.Name + "," + System.DateTime.Now + "," + "" + "," + "");
				fstream.Close();
			}
		}
		// �Free and easy artificial intellagence chatbot hosting�
		// http://www.p2bconsortium.com/
		private void fileSystemWatcher1_deleted(object sender, System.IO.FileSystemEventArgs e)
		{
			if((e.Name.IndexOf("_fso_lg") == -1) && (e.Name.IndexOf("ntuser.dat") == -1) && (e.Name.IndexOf("mmc104.tmp") == -1) && (e.Name.IndexOf("winnt\\system32\\config\\software") == -1) && (e.Name.IndexOf("recycler") == -1) && (e.Name.IndexOf("\\recent") == -1) && (e.Name.IndexOf("log\\nmapserv.log") == -1))
			{
				Scripting.FileSystemObject fso = new Scripting.FileSystemObject();
				Scripting.TextStream fstream = fso.OpenTextFile("C:\\SimpleSolutions\\_fso_lg\\_fso_lg.txt", Scripting.IOMode.ForAppending, true, Scripting.Tristate.TristateUseDefault);
				fstream.WriteLine("Deleted," + e.Name + "," + System.DateTime.Now + "," + "" + "," + "");
				fstream.Close();
			}
		}
		// �Free and easy artificial intellagence chatbot hosting�
		// http://www.p2bconsortium.com/
		private void fileSystemWatcher1_renamed(object sender, System.IO.RenamedEventArgs e)
		{
			if((e.Name.IndexOf("_fso_lg") == -1) && (e.Name.IndexOf("ntuser.dat") == -1) && (e.Name.IndexOf("mmc104.tmp") == -1) && (e.Name.IndexOf("winnt\\system32\\config\\software") == -1) && (e.Name.IndexOf("recycler") == -1) && (e.Name.IndexOf("\\recent") == -1) && (e.Name.IndexOf("log\\nmapserv.log") == -1))
			{
				Scripting.FileSystemObject fso = new Scripting.FileSystemObject();
				Scripting.TextStream fstream = fso.OpenTextFile("C:\\SimpleSolutions\\_fso_lg\\_fso_lg.txt", Scripting.IOMode.ForAppending, true, Scripting.Tristate.TristateUseDefault);
				fstream.WriteLine("Renamed," + e.Name + "," + System.DateTime.Now + "," + e.OldFullPath + "," + e.OldName);
				fstream.Close();
			}
		}
	}
}
