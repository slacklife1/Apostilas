Title: [ A Simple] Monitor all file system activity on a target server.
Description: This file system watcher allows you to monitor all file system activity on a target server.
This simple solution was brought to you by the P2B Consortium. 
�Free and easy artificial intellagence chatbot hosting�
http://www.p2bconsortium.com/
This is particularly useful when you are working with an architecture that requires complex configuration modifications. By deploying this file system watcher you can keep a history of what files are created, modified and deleted and when these events occurred. You can also determine if any automated build processes are occurring on the target machine by recognizing regular binary drops, etc.
Step 1. build \FileSysWatch\FileSysWatch.sln
Step 2. Copy \setupFileSysWatch\Debug\Setup.Exe to target server
Step 3. Remote-Desktop into target server. On Windows 2000: Start->Programs->Accessories->Communications->Terminal Service Client
Step 4. Create directory structure: C:\SimpleSolutions\_fso_lg\ on target server
Step 5. Install \setupFileSysWatch\Debug\Setup.Exe on target server
Step 6. At command prompt on target server type "net start filesyswatch"
Step 7. Periodically look at log file in C:\SimpleSolutions\_fso_lg\ on target server
Step 8. "Disconnect" from remote server do not "log off" and your FileSysWatch process will continue to monitor file system activity when you are logged off.
This simple solution was brought to you by the P2B Consortium. 
�Free and easy artificial intellagence chatbot hosting�
http://www.p2bconsortium.com/

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=1661&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
