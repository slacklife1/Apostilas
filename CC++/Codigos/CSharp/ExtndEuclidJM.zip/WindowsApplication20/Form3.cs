namespace WindowsApplication20
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.WinForms;

    /// <summary>
    ///    Summary description for Form3.
    /// </summary>
    public class Form3 : System.WinForms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.WinForms.Label label2;
		private System.WinForms.Label label1;
		private System.WinForms.LinkLabel linkLabel1;

        public Form3()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			this.linkLabel1 = new System.WinForms.LinkLabel ();
			this.label1 = new System.WinForms.Label ();
			this.label2 = new System.WinForms.Label ();
			//@this.TrayHeight = 0;
			//@this.TrayLargeIcon = false;
			//@this.TrayAutoArrange = true;
			linkLabel1.Text = "Junaid Majeed";
			linkLabel1.Size = new System.Drawing.Size (100, 23);
			linkLabel1.TabIndex = 0;
			linkLabel1.TabStop = true;
			linkLabel1.Location = new System.Drawing.Point (88, 112);
			linkLabel1.LinkClick += new System.EventHandler (this.linkLabel1_LinkClick);
			label1.Location = new System.Drawing.Point (8, 16);
			label1.Text = "This Program is developed By Junaid Majeed";
			label1.Size = new System.Drawing.Size (248, 32);
			label1.Font = new System.Drawing.Font ("Tahoma", 10);
			label1.TabIndex = 1;
			label1.Click += new System.EventHandler (this.label1_Click);
			label2.Location = new System.Drawing.Point (16, 72);
			label2.Text = "Any Query About this Program Mail Me @";
			label2.Size = new System.Drawing.Size (264, 40);
			label2.TabIndex = 2;
			this.Text = "About";
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.BorderStyle = System.WinForms.FormBorderStyle.FixedToolWindow;
			this.ClientSize = new System.Drawing.Size (294, 278);
			this.Controls.Add (this.label2);
			this.Controls.Add (this.label1);
			this.Controls.Add (this.linkLabel1);
		}

		protected void linkLabel1_LinkClick (object sender, System.EventArgs e)
		{
 System.Diagnostics.Process.Start("Mailto:junaidmajeed161@hotmail.com");

		}

		protected void label1_Click (object sender, System.EventArgs e)
		{

		}
    }
}
