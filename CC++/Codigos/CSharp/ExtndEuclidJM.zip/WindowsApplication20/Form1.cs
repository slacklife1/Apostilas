namespace WindowsApplication20
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.WinForms;
    using System.Data;

    /// <summary>
    ///    Summary description for Form1.
    /// </summary>
    public class Form1 : System.WinForms.Form
	
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.WinForms.Button button2;
		private System.WinForms.Label label9;
		private System.WinForms.Label label8;
		private System.WinForms.Label label7;
		private System.WinForms.Label label6;
		private System.WinForms.Label label5;
		private System.WinForms.Label label4;
		private System.WinForms.Label label3;
		private System.WinForms.Label label2;
		private System.WinForms.Label label1;
		private System.WinForms.TextBox textBox2;
		private System.WinForms.TextBox textBox1;
		private System.WinForms.MenuItem menuItem5;
		private System.WinForms.MenuItem menuItem4;
		private System.WinForms.MenuItem menuItem3;
		private System.WinForms.MenuItem menuItem2;
		private System.WinForms.MenuItem menuItem1;
		private System.WinForms.LinkLabel linkLabel1;
		private System.WinForms.ToolTip toolTip1;
		private System.WinForms.ContextMenu contextMenu2;
		private System.WinForms.TrayIcon trayIcon1;
		private System.WinForms.ContextMenu contextMenu1;
		private System.WinForms.Button button1;
		private System.WinForms.TextBox[] x1t= new TextBox[100] ;
		private System.WinForms.TextBox[] x2t= new TextBox[100] ;
		private System.WinForms.TextBox[] x3t= new TextBox[100] ;
		private System.WinForms.TextBox[] y1t= new TextBox[100] ;
		private System.WinForms.TextBox[] y2t= new TextBox[100] ;
		private System.WinForms.TextBox[] y3t= new TextBox[100] ;
		private System.WinForms.TextBox[] qt= new TextBox[100] ;
		private System.WinForms.Label[] lb = new Label[10];

		public int k;

        public Form1()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager (typeof(Form1));
			this.components = new System.ComponentModel.Container ();
			this.menuItem1 = new System.WinForms.MenuItem ();
			this.menuItem2 = new System.WinForms.MenuItem ();
			this.menuItem4 = new System.WinForms.MenuItem ();
			this.menuItem5 = new System.WinForms.MenuItem ();
			this.textBox2 = new System.WinForms.TextBox ();
			this.button2 = new System.WinForms.Button ();
			this.linkLabel1 = new System.WinForms.LinkLabel ();
			this.toolTip1 = new System.WinForms.ToolTip (this.components);
			this.menuItem3 = new System.WinForms.MenuItem ();
			this.trayIcon1 = new System.WinForms.TrayIcon ();
			this.button1 = new System.WinForms.Button ();
			this.label4 = new System.WinForms.Label ();
			this.label5 = new System.WinForms.Label ();
			this.label6 = new System.WinForms.Label ();
			this.label8 = new System.WinForms.Label ();
			this.label9 = new System.WinForms.Label ();
			this.textBox1 = new System.WinForms.TextBox ();
			this.label3 = new System.WinForms.Label ();
			this.contextMenu2 = new System.WinForms.ContextMenu ();
			this.contextMenu1 = new System.WinForms.ContextMenu ();
			this.label7 = new System.WinForms.Label ();
			this.label1 = new System.WinForms.Label ();
			this.label2 = new System.WinForms.Label ();
			//@this.TrayHeight = 90;
			//@this.TrayLargeIcon = false;
			//@this.TrayAutoArrange = true;
			menuItem1.Text = "Addition";
			menuItem1.Index = 0;
			menuItem1.Click += new System.EventHandler (this.menuItem1_Click);
			menuItem2.Text = "Subtraction";
			menuItem2.Index = 1;
			menuItem2.Click += new System.EventHandler (this.menuItem2_Click);
			menuItem4.Text = "About";
			menuItem4.Index = 0;
			menuItem4.Click += new System.EventHandler (this.menuItem4_Click);
			menuItem5.Text = "Scientific";
			menuItem5.Index = 1;
			menuItem5.Click += new System.EventHandler (this.menuItem5_Click);
			textBox2.Location = new System.Drawing.Point (152, 8);
			textBox2.TabIndex = 9;
			textBox2.Size = new System.Drawing.Size (100, 20);
			button2.Location = new System.Drawing.Point (440, 32);
			button2.Size = new System.Drawing.Size (80, 24);
			button2.TabIndex = 19;
			button2.Text = "Refresh";
			button2.Click += new System.EventHandler (this.button2_Click_1);
			linkLabel1.Text = "JunaidMajeed";
			linkLabel1.Size = new System.Drawing.Size (100, 23);
			toolTip1.SetToolTip (linkLabel1, "Mail Me");
			linkLabel1.TabIndex = 4;
			linkLabel1.TabStop = true;
			linkLabel1.Location = new System.Drawing.Point (448, 264);
			linkLabel1.LinkClick += new System.EventHandler (this.linkLabel1_LinkClick);
			//@toolTip1.SetLocation (new System.Drawing.Point (310, 7));
			toolTip1.Active = true;
			menuItem3.Text = "Multiplication";
			menuItem3.Index = 2;
			menuItem3.Click += new System.EventHandler (this.menuItem3_Click);
			//@trayIcon1.SetLocation (new System.Drawing.Point (116, 7));
			trayIcon1.Text = "Visual Matrix";
			trayIcon1.Visible = true;
			trayIcon1.Icon = (System.Drawing.Icon) resources.GetObject ("trayIcon1.Icon");
			trayIcon1.ContextMenu = this.contextMenu2;
			button1.Location = new System.Drawing.Point (440, 8);
			button1.Size = new System.Drawing.Size (80, 24);
			button1.TabIndex = 1;
			button1.Text = "Draw";
			button1.Click += new System.EventHandler (this.button1_Click);
			label4.Location = new System.Drawing.Point (184, 32);
			label4.Text = "Y1";
			label4.Size = new System.Drawing.Size (32, 23);
			label4.TabIndex = 13;
			label5.Location = new System.Drawing.Point (88, 32);
			label5.Text = "X2";
			label5.Size = new System.Drawing.Size (24, 23);
			label5.TabIndex = 14;
			label6.Location = new System.Drawing.Point (48, 32);
			label6.Text = "X1";
			label6.Size = new System.Drawing.Size (32, 16);
			label6.TabIndex = 15;
			label8.Location = new System.Drawing.Point (256, 32);
			label8.Text = "Y2";
			label8.Size = new System.Drawing.Size (40, 23);
			label8.TabIndex = 17;
			label9.Location = new System.Drawing.Point (304, 32);
			label9.Text = "Y3";
			label9.Size = new System.Drawing.Size (100, 23);
			label9.TabIndex = 18;
			textBox1.Location = new System.Drawing.Point (0, 8);
			textBox1.TabIndex = 8;
			textBox1.Size = new System.Drawing.Size (100, 20);
			label3.Location = new System.Drawing.Point (136, 32);
			label3.Text = "X3";
			label3.Size = new System.Drawing.Size (32, 23);
			label3.TabIndex = 12;
			//@contextMenu2.SetLocation (new System.Drawing.Point (201, 7));
			contextMenu2.Popup += new System.EventHandler (this.contextMenu2_Popup);
			contextMenu2.MenuItems.All = new System.WinForms.MenuItem[2] {this.menuItem4, this.menuItem5};
			//@contextMenu1.SetLocation (new System.Drawing.Point (7, 7));
			contextMenu1.Popup += new System.EventHandler (this.contextMenu1_Popup);
			contextMenu1.MenuItems.All = new System.WinForms.MenuItem[3] {this.menuItem1, this.menuItem2, this.menuItem3};
			label7.Location = new System.Drawing.Point (296, 48);
			label7.Text = "label7";
			label7.Size = new System.Drawing.Size (0, 0);
			label7.TabIndex = 16;
			label1.Location = new System.Drawing.Point (112, 8);
			label1.Text = "Mod";
			label1.Size = new System.Drawing.Size (32, 23);
			label1.TabIndex = 10;
			label2.Location = new System.Drawing.Point (0, 32);
			label2.Text = "Q";
			label2.Size = new System.Drawing.Size (32, 23);
			label2.TabIndex = 11;
			this.Text = "Extended Eucilden  Algo";
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.BorderStyle = System.WinForms.FormBorderStyle.FixedToolWindow;
			this.ClientSize = new System.Drawing.Size (522, 278);
			this.Click += new System.EventHandler (this.Form1_Click);
			this.Controls.Add (this.button2);
			this.Controls.Add (this.label9);
			this.Controls.Add (this.label8);
			this.Controls.Add (this.label7);
			this.Controls.Add (this.label6);
			this.Controls.Add (this.label5);
			this.Controls.Add (this.label4);
			this.Controls.Add (this.label3);
			this.Controls.Add (this.label2);
			this.Controls.Add (this.label1);
			this.Controls.Add (this.textBox2);
			this.Controls.Add (this.textBox1);
			this.Controls.Add (this.linkLabel1);
			this.Controls.Add (this.button1);
		}

		protected void button2_Click_1 (object sender, System.EventArgs e)
		{
 for(int i=0;i<=12;i++)
			{
					x1t[i].Clear();
     				x1t[i].Hide();
				 x2t[i].Clear();
     				x2t[i].Hide();
				x3t[i].Clear();
     				x3t[i].Hide();
					y1t[i].Clear();
     				y1t[i].Hide();
					y2t[i].Clear();
     				y2t[i].Hide();
					 y3t[i].Clear();
     				y3t[i].Hide();
					qt[i].Clear();
     				qt[i].Hide();



			}

		}

		protected void label4_Click (object sender, System.EventArgs e)
		{
 		}

		protected void menuItem5_Click (object sender, System.EventArgs e)
		{
 Form2 sci = new Form2();
			sci.Show();
		}

		protected void contextMenu2_Popup (object sender, System.EventArgs e)
		{
 

		}

		protected void menuItem3_Click (object sender, System.EventArgs e)
		{
			double[,] t1 = new double[100,100];

		}

		protected void button4_Click (object sender, System.EventArgs e)
		{


		}

		protected void menuItem2_Click (object sender, System.EventArgs e)
		{
		}

		protected void menuItem1_Click (object sender, System.EventArgs e)
		{

/*			double[,] temp = new double[100,100];
			if((textBox1.Text).ToInt32() == (textBox3.Text).ToInt32() && (textBox2.Text).ToInt32() == (textBox4.Text).ToInt32())
			{

 for(int i=1;i<=(textBox2.Text).ToInt32();i++)
			{
				for(int j=1;j<=(textBox1.Text).ToInt32();j++)
				{
						
 this.j3[i,j] = new System.WinForms.TextBox ();
			
					j3[i,j].Location = new System.Drawing.Point (180+i*20, 120+j*23);
			j3[i,j].TabIndex = 0;
			j3[i,j].Size = new System.Drawing.Size (20, 23);
			this.Controls.Add (this.j3[i,j]);
					temp[i,j] = (j2[i,j].Text).ToDouble() + (j1[i,j].Text).ToDouble();
					j3[i,j].Text = temp[i,j].ToString();

				}
			}
			}
			else
			{
				MessageBox.Show("this addition is not possible:");


			}
*/

		}

		protected void menuItem4_Click (object sender, System.EventArgs e)
		{
 Form3 abt = new Form3();
			abt.Show();

		}

		protected void contextMenu1_Popup (object sender, System.EventArgs e)
		{

		}

		protected void linkLabel1_LinkClick (object sender, System.EventArgs e)
		{
 System.Diagnostics.Process.Start("mailto:junaidmajeed161@hotmail.com");

		}

		protected void button3_Click (object sender, System.EventArgs e)
		{
			MessageBox.Show("Under Developement");

 		}

		protected void button2_Click (object sender, System.EventArgs e)
		{
			MessageBox.Show("press Right Mouse Button:");

 		}

		protected void Form1_Click (object sender, System.EventArgs e)
		{

		}

		protected void button1_Click (object sender, System.EventArgs e)
		{
			int i,j,m,n;
		

			int[] x1 = new int[100];
			int[] x2 = new int[100];
			int[] x3 = new int[100];
			int[] y1 = new int[100];
			int[] y2 = new int[100];
			int[] y3 = new int[100];
			int[] q = new int[100];
			
x1[0] = 1;
x2[0] = 0;
y1[0] = 0;
y2[0] = 1;
q[0] = 0;

y3[0] = (textBox1.Text).ToInt32();
x3[0] = (textBox2.Text).ToInt32();

for(i=1;i<13;i++)
{

q[i] = x3[i-1]/y3[i-1];
y1[i] = x1[i-1] - q[i]*y1[i-1];
y2[i] = x2[i-1] - q[i]*y2[i-1];
y3[i] = x3[i-1]%y3[i-1];
x1[i] = y1[i-1];
x2[i] = y2[i-1];
x3[i] = y3[i-1];
if(y3[i]== 1)
{
k =i;
m=y2[i];
	MessageBox.Show("Value of d is"+m);

break;
}

else if(y3[i] ==0)
{
MessageBox.Show("Sorry no multiplicative inverse:");

}

}


		
			int [] itno = new int [100];//iteration number
			for(int i1=0;i1<=12;i1++)
			{
			 this.x1t[i1] = new System.WinForms.TextBox ();
			x1t[i1].Location = new System.Drawing.Point (8, 56+1+i1*23);
			x1t[i1].TabIndex = 0;
			x1t[i1].Size = new System.Drawing.Size (30, 23);
			this.Controls.Add (this.x1t[i1]);
						x1t[i1].Text = (q[i1]).ToString();
							}


			for(int i1=0;i1<=12;i1++)
			{
			 this.x2t[i1] = new System.WinForms.TextBox ();
			x2t[i1].Location = new System.Drawing.Point (48, 56+1+i1*23);
			x2t[i1].TabIndex = 0;
			x2t[i1].Size = new System.Drawing.Size (30, 23);
			this.Controls.Add (this.x2t[i1]);
						x2t[i1].Text = (x1[i1]).ToString();
							}

			for(int i1=0;i1<=12;i1++)
			{
			 this.x3t[i1] = new System.WinForms.TextBox ();
			x3t[i1].Location = new System.Drawing.Point (88, 56+1+i1*23);
			x3t[i1].TabIndex = 0;
			x3t[i1].Size = new System.Drawing.Size (30, 23);
			this.Controls.Add (this.x3t[i1]);
						x3t[i1].Text = (x2[i1]).ToString();
							}

						for(int i1=0;i1<=12;i1++)
			{
			 this.y1t[i1] = new System.WinForms.TextBox ();
			y1t[i1].Location = new System.Drawing.Point (128, 56+1+i1*23);
			y1t[i1].TabIndex = 0;
			y1t[i1].Size = new System.Drawing.Size (30, 23);
			this.Controls.Add (this.y1t[i1]);
						y1t[i1].Text = (x3[i1]).ToString();
							}

			for(int i1=0;i1<=12;i1++)
			{
			 this.y2t[i1] = new System.WinForms.TextBox ();
			y2t[i1].Location = new System.Drawing.Point (178, 56+1+i1*23);
			y2t[i1].TabIndex = 0;
			y2t[i1].Size = new System.Drawing.Size (30, 23);
			this.Controls.Add (this.y2t[i1]);
						y2t[i1].Text = (y1[i1]).ToString();
							}

						for(int i1=0;i1<=12;i1++)
			{
			 this.y3t[i1] = new System.WinForms.TextBox ();
			y3t[i1].Location = new System.Drawing.Point (248, 56+1+i1*23);
			y3t[i1].TabIndex = 0;
			y3t[i1].Size = new System.Drawing.Size (30, 23);
			this.Controls.Add (this.y3t[i1]);
						y3t[i1].Text = (y2[i1]).ToString();
							}

									for(int i1=0;i1<=12;i1++)
			{
			 this.qt[i1] = new System.WinForms.TextBox ();
			qt[i1].Location = new System.Drawing.Point (288, 56+1+i1*23);
			qt[i1].TabIndex = 0;
			qt[i1].Size = new System.Drawing.Size (30, 23);
			this.Controls.Add (this.qt[i1]);
						qt[i1].Text = (y3[i1]).ToString();
							}







}



        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Main(string[] args) 
        {
            Application.Run(new Form1());
        }
    }
}
