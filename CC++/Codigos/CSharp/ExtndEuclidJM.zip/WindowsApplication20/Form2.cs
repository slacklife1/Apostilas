namespace WindowsApplication20
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.WinForms;

    /// <summary>
    ///    Summary description for Form2.
    /// </summary>
    public class Form2 : System.WinForms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.WinForms.Button button6;
		private System.WinForms.Button button5;
		private System.WinForms.Button button4;
		private System.WinForms.Button button3;
		private System.WinForms.Button button2;
		private System.WinForms.Button button1;
		private System.WinForms.Label label2;
		private System.WinForms.TextBox textBox2;
		private System.WinForms.Label label1;
		private System.WinForms.TextBox textBox1;

        public Form2()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			this.button6 = new System.WinForms.Button ();
			this.button5 = new System.WinForms.Button ();
			this.button3 = new System.WinForms.Button ();
			this.label2 = new System.WinForms.Label ();
			this.button4 = new System.WinForms.Button ();
			this.textBox2 = new System.WinForms.TextBox ();
			this.button1 = new System.WinForms.Button ();
			this.textBox1 = new System.WinForms.TextBox ();
			this.label1 = new System.WinForms.Label ();
			this.button2 = new System.WinForms.Button ();
			//@this.TrayHeight = 0;
			//@this.TrayLargeIcon = false;
			//@this.TrayAutoArrange = true;
			button6.Location = new System.Drawing.Point (56, 136);
			button6.Size = new System.Drawing.Size (40, 23);
			button6.TabIndex = 10;
			button6.Text = "ACos";
			button6.Click += new System.EventHandler (this.button6_Click);
			button5.Location = new System.Drawing.Point (112, 136);
			button5.Size = new System.Drawing.Size (48, 23);
			button5.TabIndex = 9;
			button5.Text = "ATan";
			button5.Click += new System.EventHandler (this.button5_Click);
			button3.Location = new System.Drawing.Point (112, 104);
			button3.Size = new System.Drawing.Size (40, 23);
			button3.TabIndex = 7;
			button3.Text = "Tan";
			button3.Click += new System.EventHandler (this.button3_Click);
			label2.Location = new System.Drawing.Point (64, 48);
			label2.Text = "Answer";
			label2.Size = new System.Drawing.Size (56, 23);
			label2.TabIndex = 4;
			button4.Location = new System.Drawing.Point (8, 136);
			button4.Size = new System.Drawing.Size (40, 23);
			button4.TabIndex = 8;
			button4.Text = "ASin";
			button4.Click += new System.EventHandler (this.button4_Click);
			textBox2.Location = new System.Drawing.Point (128, 48);
			textBox2.TabIndex = 3;
			textBox2.Size = new System.Drawing.Size (144, 20);
			button1.Location = new System.Drawing.Point (8, 104);
			button1.Size = new System.Drawing.Size (40, 23);
			button1.TabIndex = 5;
			button1.Text = "Sin";
			button1.Click += new System.EventHandler (this.button1_Click_1);
			textBox1.Location = new System.Drawing.Point (128, 16);
			textBox1.TabIndex = 1;
			textBox1.Size = new System.Drawing.Size (144, 20);
			label1.Location = new System.Drawing.Point (64, 16);
			label1.Text = "Value";
			label1.Size = new System.Drawing.Size (56, 23);
			label1.TabIndex = 2;
			button2.Location = new System.Drawing.Point (56, 104);
			button2.Size = new System.Drawing.Size (40, 23);
			button2.TabIndex = 6;
			button2.Text = "Cos";
			button2.Click += new System.EventHandler (this.button2_Click);
			this.Text = "Scientific";
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.BorderStyle = System.WinForms.FormBorderStyle.FixedToolWindow;
			this.ClientSize = new System.Drawing.Size (294, 278);
			this.Click += new System.EventHandler (this.Form2_Click);
			this.Controls.Add (this.button6);
			this.Controls.Add (this.button5);
			this.Controls.Add (this.button4);
			this.Controls.Add (this.button3);
			this.Controls.Add (this.button2);
			this.Controls.Add (this.button1);
			this.Controls.Add (this.label2);
			this.Controls.Add (this.textBox2);
			this.Controls.Add (this.label1);
			this.Controls.Add (this.textBox1);
		}

		protected void button5_Click (object sender, System.EventArgs e)
		{
 textBox2.Text=(Math.Atan((textBox1.Text).ToDouble())*180/Math.PI).ToString();
		}

		protected void button6_Click (object sender, System.EventArgs e)
		{
 textBox2.Text=(Math.Acos((textBox1.Text).ToDouble())*180/Math.PI).ToString();
		}

		protected void button4_Click (object sender, System.EventArgs e)
		{
 textBox2.Text=(Math.Asin((textBox1.Text).ToDouble())*180/Math.PI).ToString();
		}

		protected void button3_Click (object sender, System.EventArgs e)
		{
 textBox2.Text=Math.Tan((textBox1.Text).ToDouble()*Math.PI/180).ToString();
		}

		protected void button2_Click (object sender, System.EventArgs e)
		{
			textBox2.Text=Math.Cos((textBox1.Text).ToDouble()*Math.PI/180).ToString();

		}

		protected void button1_Click_1 (object sender, System.EventArgs e)
		{
 textBox2.Text=Math.Sin((textBox1.Text).ToDouble()*Math.PI/180).ToString();

		}

		protected void Form2_Click (object sender, System.EventArgs e)
		{

		}

		protected void button1_Click (object sender, System.EventArgs e)
		{
 
		}
    }
}
