using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace TestProg
{
	/// <summary>
	/// Zusammendfassende Beschreibung f�r Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button cmdStartTest;
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Erforderlich f�r die Windows Form-Designerunterst�tzung
			//
			InitializeComponent();

			//
			// TODO: F�gen Sie den Konstruktorcode nach dem Aufruf von InitializeComponent hinzu
			//
		}

		/// <summary>
		/// Die verwendeten Ressourcen bereinigen.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung. 
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdStartTest = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// cmdStartTest
			// 
			this.cmdStartTest.Location = new System.Drawing.Point(8, 16);
			this.cmdStartTest.Name = "cmdStartTest";
			this.cmdStartTest.Size = new System.Drawing.Size(248, 48);
			this.cmdStartTest.TabIndex = 0;
			this.cmdStartTest.Text = "&Start Registry Test";
			this.cmdStartTest.Click += new System.EventHandler(this.cmdStartTest_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(264, 102);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.cmdStartTest});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Der Haupteinstiegspunkt f�r die Anwendung.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void cmdStartTest_Click(object sender, System.EventArgs e)
		{
			CSRegistryTest.Test();
		}
	}
}
