using System.Diagnostics;
using System.Windows.Forms;

public class CSRegistryTest 
{
	public static void Test()
	{
		try 
		{
			int i;
			byte[] arrByte;
			CSRegistry.clsCSRegistry objCSRegistry = new CSRegistry.clsCSRegistry();

			// Pr�fen, ob Schl�ssel existiert
			if (! objCSRegistry.DoesKeyExist(CSRegistry.ERegistryPossibleRoots.HKEY_LOCALE_MACHINE, "Software\\NGS\\key1\\key2\\key3"))
			{
				// Schl�ssel anlegen
				Debug.WriteLine(objCSRegistry.CreateKey(CSRegistry.ERegistryPossibleRoots.HKEY_LOCALE_MACHINE, "Software\\NGS\\key1\\key2\\key3"));
			}

			// Wert StrVal erzeugen
			Debug.WriteLine(objCSRegistry.CreateValue( CSRegistry.ERegistryPossibleRoots.HKEY_LOCALE_MACHINE, "Software\\NGS\\key1\\key2\\key3", "StrVal", "Jochen"));

			// Wert BinVal erzeugen
			arrByte=new byte[4];
			arrByte[0] = 1;
			arrByte[1] = 2;
			arrByte[2] = 3;
			arrByte[3] = 4;

			Debug.WriteLine(objCSRegistry.CreateValue( CSRegistry.ERegistryPossibleRoots.HKEY_LOCALE_MACHINE, "Software\\NGS\\key1\\key2\\key3", "BinVal", arrByte));

			// Wert DWordVal erzeugen
			Debug.WriteLine(objCSRegistry.CreateValue(CSRegistry.ERegistryPossibleRoots.HKEY_LOCALE_MACHINE, "Software\\NGS\\key1\\key2\\key3", "DWordVal", (int)1234));

			// Wert StrVal abfragen
			Debug.WriteLine(objCSRegistry.QueryValue(CSRegistry.ERegistryPossibleRoots.HKEY_LOCALE_MACHINE, "Software\\NGS\\key1\\key2\\key3", "StrVal", ""));

			// Wert BinVal abfragen
			arrByte=new byte[4];
			arrByte[0] = 1;
			arrByte[1] = 1;
			arrByte[2] = 1;
			arrByte[3] = 1;

			arrByte = objCSRegistry.QueryValue(CSRegistry.ERegistryPossibleRoots.HKEY_LOCALE_MACHINE, "Software\\NGS\\key1\\key2\\key3", "BinVal", arrByte);

			for(i=arrByte.GetLowerBound(0);i<=arrByte.GetUpperBound(0);i++)
				Debug.WriteLine(string.Concat("arrByte[", i, "]: ", arrByte[i]));
			
			// Wert DWord-Val abfragen
			Debug.WriteLine(objCSRegistry.QueryValue(CSRegistry.ERegistryPossibleRoots.HKEY_LOCALE_MACHINE, "Software\\NGS\\key1\\key2\\key3", "DWordVal", (int)0));

			// Schl�ssel key3 l�schen (NICHT rekursiv)
			Debug.WriteLine(objCSRegistry.DeleteKey(CSRegistry.ERegistryPossibleRoots.HKEY_LOCALE_MACHINE, "Software\\NGS\\key1\\key2\\key3"));

			// Schl�ssel key1 l�schen (rekursiv)
			Debug.WriteLine(objCSRegistry.DeleteKey(CSRegistry.ERegistryPossibleRoots.HKEY_LOCALE_MACHINE, "Software\\NGS\\key1", true));

			objCSRegistry=null;

			MessageBox.Show("Test abgeschlossen!", "TestCSRegistry", MessageBoxButtons.OK, MessageBoxIcon.Information);
			
		}
		catch (System.Exception ex) 
		{
			MessageBox.Show(ex.ToString());
		}
	}
}