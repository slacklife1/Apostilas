/*
 * Column.cs
 *
 * Copyright (c) 2001, The HSQL Development Group
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Neither the name of the HSQL Development Group nor the names of its
 * contributors may be used to endorse or promote products derived from this
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * This package is based on HypersonicSQL, originally developed by Thomas Mueller.
 *
 * C# port by Mark Tutt
 * C# .NET Final Release port update by Pramod Kumar Singh
 *
 */
namespace SharpHSQL
{
	using System;
	using System.Collections;
	using System.IO;
	using System.Text;


	/**
	 * Class declaration
	 *
	 *
	 * @version 1.0.0.1
	 */
	class Column 
	{
		private static Hashtable hTypes;
		public const int	     BIT = -7;
		public const int	     TINYINT = -6;
		public const int	     BIGINT = -5;
		public const int	     LONGVARBINARY = -4;
		public const int	     VARBINARY = -3;
		public const int	     BINARY = -2;
		public const int	     LONGVARCHAR = -1;
		public const int	     CHAR = 1;
		public const int	     NUMERIC = 2;
		public const int	     DECIMAL = 3;
		public const int	     INTEGER = 4;
		public const int	     SMALLINT = 5;
		public const int	     FLOAT = 6;
		public const int	     REAL = 7;
		public const int	     DOUBLE = 8;
		public const int	     VARCHAR = 12;
		public const int	     DATE = 91;
		public const int	     TIME = 92;
		public const int	     TIMESTAMP = 93;
		public const int	     OTHER = 1111;
		public const int	     NULL = 0;
		public const int	     VARCHAR_IGNORECASE = 100;	    // this is the only non-standard type

		// NULL and VARCHAR_IGNORECASE is not part of TYPES
		public static int[]	     TYPES = 
		{
			BIT, TINYINT, BIGINT, LONGVARBINARY, VARBINARY, BINARY, LONGVARCHAR,
			CHAR, NUMERIC, DECIMAL, INTEGER, SMALLINT, FLOAT, REAL, DOUBLE,
			VARCHAR, DATE, TIME, TIMESTAMP, OTHER
		};
		public string		     sName;
		public int			     iType;
		private bool			 bNullable;
		private bool			 bIdentity;
    
		/**
		 * Method declaration
		 *
		 *
		 * @param type
		 * @param name
		 * @param n2
		 * @param n3
		 */
		private static void addTypes(int type, string name, string n2, string n3) 
		{
			addType(type, name);
			addType(type, n2);
			addType(type, n3);
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param type
		 * @param name
		 */
		private static void addType(int type, string name) 
		{
			if (name != null) 
			{
				hTypes.Add(name, type);
			}
		}

		/**
		 * Constructor declaration
		 *
		 *
		 * @param name
		 * @param nullable
		 * @param type
		 * @param identity
		 */
		public Column(string name, bool nullable, int type, bool identity) 
		{
	
			sName = name;
			bNullable = nullable;
			iType = type;
			bIdentity = identity;
		}

		/**
		 * Method declaration
		 *
		 *
		 * @return
		 */
		public bool isIdentity() 
		{
			return bIdentity;
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static int getTypeNr(string type) 
		{
			if (hTypes == null)
			{
				hTypes = new Hashtable();

				addTypes(INTEGER, "INTEGER", "int", "java.lang.int");
				addType(INTEGER, "INT");
				addTypes(DOUBLE, "DOUBLE", "double", "java.lang.Double");
				addType(FLOAT, "FLOAT");		       // this is a Double
				addTypes(VARCHAR, "VARCHAR", "java.lang.string", null);
				addTypes(CHAR, "CHAR", "CHARACTER", null);
				addType(LONGVARCHAR, "LONGVARCHAR");

				// for ignorecase data types, the 'original' type name is lost
				addType(VARCHAR_IGNORECASE, "VARCHAR_IGNORECASE");
				addTypes(DATE, "DATE", "java.sql.Date", null);
				addTypes(TIME, "TIME", "java.sql.Time", null);

				// DATETIME is for compatibility with MS SQL 7
				addTypes(TIMESTAMP, "TIMESTAMP", "java.sql.Timestamp", "DATETIME");
				addTypes(DECIMAL, "DECIMAL", "java.math.BigDecimal", null);
				addType(NUMERIC, "NUMERIC");
				addTypes(BIT, "BIT", "java.lang.Boolean", "bool");
				addTypes(TINYINT, "TINYINT", "java.lang.Short", "short");
				addType(SMALLINT, "SMALLINT");
				addTypes(BIGINT, "BIGINT", "java.lang.Long", "long");
				addTypes(REAL, "REAL", "java.lang.Float", "float");
				addTypes(BINARY, "BINARY", "byte[]", null);    // maybe better "[B"
				addType(VARBINARY, "VARBINARY");
				addType(LONGVARBINARY, "LONGVARBINARY");
				addTypes(OTHER, "OTHER", "java.lang.object", "OBJECT");
			}

			if (hTypes.ContainsKey(type))
			{
				int i = (int)hTypes[type];
				return i;
			}
			else
				throw Trace.error(Trace.WRONG_DATA_TYPE, type);
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static string getType(int type) 
		{
			switch (type) 
			{

				case NULL:
					return "NULL";

				case INTEGER:
					return "INTEGER";

				case DOUBLE:
					return "DOUBLE";

				case VARCHAR_IGNORECASE:
					return "VARCHAR_IGNORECASE";

				case VARCHAR:
					return "VARCHAR";

				case CHAR:
					return "CHAR";

				case LONGVARCHAR:
					return "LONGVARCHAR";

				case DATE:
					return "DATE";

				case TIME:
					return "TIME";

				case DECIMAL:
					return "DECIMAL";

				case BIT:
					return "BIT";

				case TINYINT:
					return "TINYINT";

				case SMALLINT:
					return "SMALLINT";

				case BIGINT:
					return "BIGINT";

				case REAL:
					return "REAL";

				case FLOAT:
					return "FLOAT";

				case NUMERIC:
					return "NUMERIC";

				case TIMESTAMP:
					return "TIMESTAMP";

				case BINARY:
					return "BINARY";

				case VARBINARY:
					return "VARBINARY";

				case LONGVARBINARY:
					return "LONGVARBINARY";

				case OTHER:
					return "OBJECT";

				default:
					throw Trace.error(Trace.WRONG_DATA_TYPE, type);
			}
		}

		/**
		 * Method declaration
		 *
		 *
		 * @return
		 */
		public bool isNullable() 
		{
			return bNullable;
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param a
		 * @param b
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static object add(object a, object b, int type) 
		{
			if (a == null || b == null) 
			{
				return null;
			}

			switch (type) 
			{

				case NULL:
					return null;

				case INTEGER:
					int ai = (int)a;
					int bi = (int)b;

					return (ai + bi);

				case FLOAT:

				case DOUBLE:
					double ad = (double) a;
					double bd = (double) b;

					return (ad + bd);

				case VARCHAR:

				case CHAR:

				case LONGVARCHAR:

				case VARCHAR_IGNORECASE:
					return (string) a + (string) b;

				case NUMERIC:

				case DECIMAL:
					decimal abd = (decimal) a;
					decimal bbd = (decimal) b;

					return (abd + bbd);

				case TINYINT:

				case SMALLINT:
					short shorta = (short) a;
					short shortb = (short) b;

					return (shorta + shortb);

				case BIGINT:
					long longa = (long) a;
					long longb = (long) b;

					return (longa + longb);

				case REAL:
					float floata = (float) a;
					float floatb = (float) b;

					return (floata + floatb);

				default:
					throw Trace.error(Trace.FUNCTION_NOT_SUPPORTED, type);
			}
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param a
		 * @param b
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static object concat(object a, object b) 
		{
			if (a == null) 
			{
				return b;
			} 
			else if (b == null) 
			{
				return a;
			}

			return convertobject(a) + convertobject(b);
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param a
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static object negate(object a, int type) 
		{
			if (a == null) 
			{
				return null;
			}

			switch (type) 
			{

				case NULL:
					return null;

				case INTEGER:
					return (-(int) a);

				case FLOAT:

				case DOUBLE:
					return (-(double) a);

				case NUMERIC:

				case DECIMAL:
					return (-(decimal)a);

				case TINYINT:

				case SMALLINT:
					return (-(short)a);

				case BIGINT:
					return (-(long) a);

				case REAL:
					return (-(float) a);

				default:
					throw Trace.error(Trace.FUNCTION_NOT_SUPPORTED, type);
			}
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param a
		 * @param b
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static object multiply(object a, object b, int type) 
		{
			if (a == null || b == null) 
			{
				return null;
			}

			switch (type) 
			{

				case NULL:
					return null;

				case INTEGER:
					int ai = (int) a;
					int bi = (int) b;

					return (ai * bi);

				case FLOAT:

				case DOUBLE:
					double ad = (double) a;
					double bd = (double) b;

					return (ad * bd);

				case NUMERIC:

				case DECIMAL:
					decimal abd = (decimal) a;
					decimal bbd = (decimal) b;

					return (abd * bbd);

				case TINYINT:

				case SMALLINT:
					short shorta = (short) a;
					short shortb = (short) b;

					return (shorta * shortb);

				case BIGINT:
					long longa = (long) a;
					long longb = (long) b;

					return (longa * longb);

				case REAL:
					float floata = (float) a;
					float floatb = (float) b;

					return (floata * floatb);

				default:
					throw Trace.error(Trace.FUNCTION_NOT_SUPPORTED, type);
			}
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param a
		 * @param b
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static object divide(object a, object b, int type) 
		{
			if (a == null || b == null) 
			{
				return null;
			}

			switch (type) 
			{

				case NULL:
					return null;

				case INTEGER:
					if ((int)b == 0)
						return null;
					return ((int)a / (int)b);

				case FLOAT:

				case DOUBLE:
					if ((double) b == 0)
						return null;
					return ((double)a / (double)b);

				case NUMERIC:

				case DECIMAL:
					if ((decimal) b == 0)
						return null;
					return ((decimal)a / (decimal)b);

				case TINYINT:

				case SMALLINT:
					if ((short) b == 0)
						return null;
					return ((short)a / (short)b);

				case BIGINT:
					if ((long) b == 0)
						return null;
					return ((long)a / (long)b);

				case REAL:
					if ((float) b == 0)
						return null;
					return ((float)a / (float)b);

				default:
					throw Trace.error(Trace.FUNCTION_NOT_SUPPORTED, type);
			}
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param a
		 * @param b
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static object subtract(object a, object b, int type) 
		{
			if (a == null || b == null) 
			{
				return null;
			}

			switch (type) 
			{

				case NULL:
					return null;

				case INTEGER:
					return ((int)a - (int)b);

				case FLOAT:

				case DOUBLE:
					return ((double)a - (double)b);

				case NUMERIC:

				case DECIMAL:
					return ((decimal)a - (decimal)b);

				case TINYINT:

				case SMALLINT:
					return ((short)a - (short)b);

				case BIGINT:
					return ((long)a - (long)b);

				case REAL:
					return ((float)a - (float)b);

				default:
					throw Trace.error(Trace.FUNCTION_NOT_SUPPORTED, type);
			}
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param a
		 * @param b
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static object sum(object a, object b, int type) 
		{
			object result;
			if (a == null) 
			{
				return b;
			}

			if (b == null) 
			{
				return a;
			}

			switch (type) 
			{

				case NULL:
					result= null;
					break;
				case INTEGER:
					result= (((int) a) + ((int) b));
					break;
				case FLOAT:

				case DOUBLE:
					result= (((double) a) + ((double) b));
					break;
				case NUMERIC:

				case DECIMAL:
					result= (((decimal) a) + ((decimal) b));
					break;
				case TINYINT:

				case SMALLINT:
					result=  (((short) a) + ((short) b));
					break;
				case BIGINT:
					result= (((long) a) + ((long) b));
					break;
				case REAL:
					result= (((float) a)	+ ((float) b));
					break;
				default:
					Trace.error(Trace.SUM_OF_NON_NUMERIC);
					break;
			}

			return null;
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param a
		 * @param type
		 * @param count
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static object avg(object a, int type, int count) 
		{
			object result;
			if (a == null || count == 0) 
			{
				return null;
			}

			switch (type) 
			{

				case NULL:
					result= null;
					break;
				case INTEGER:
					result= ((int)a / count);
					break;
				case FLOAT:

				case DOUBLE:
					result= ((double) a / count);
					break;
				case NUMERIC:

				case DECIMAL:
					result= ((decimal) a / (decimal)count);
					break;
				case TINYINT:

				case SMALLINT:
					result= ((short) a / count);
					break;
				case BIGINT:
					result= ((long) a / count);
					break;
				case REAL:
					result= ((float) a / count);
					break;
				default:
					Trace.error(Trace.SUM_OF_NON_NUMERIC);
					break;
			}

			return null;
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param a
		 * @param b
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static object min(object a, object b, int type) 
		{
			if (a == null) 
			{
				return b;
			}

			if (b == null) 
			{
				return a;
			}

			if (compare(a, b, type) < 0) 
			{
				return a;
			}

			return b;
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param a
		 * @param b
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static object max(object a, object b, int type) 
		{
			if (a == null) 
			{
				return b;
			}

			if (b == null) 
			{
				return a;
			}

			if (compare(a, b, type) > 0) 
			{
				return a;
			}

			return b;
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param a
		 * @param b
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static int compare(object a, object b, int type) 
		{
			int i = 0;

			// null handling: null==null and smaller any value
			// todo: implement standard SQL null handling
			// it is also used for grouping ('null' is one group)
			if (a == null) 
			{
				if (b == null) 
				{
					return 0;
				}

				return -1;
			}

			if (b == null) 
			{
				return 1;
			}

			switch (type) 
			{

				case NULL:
					return 0;

				case INTEGER:
					return ((int)a > (int)b) ? 1 : ((int)b > (int)a ? -1 : 0);

				case FLOAT:
					return ((float)a > (float)b) ? 1 : ((float)b > (float)a ? -1 : 0);

				case DOUBLE:
					return ((double)a > (double)b) ? 1 : ((double)b > (double)a ? -1 : 0);

				case VARCHAR:

				case CHAR:

				case LONGVARCHAR:
					i = ((string) a).CompareTo((string) b);
					break;

				case VARCHAR_IGNORECASE:
					i = ((string) a).ToUpper().CompareTo(((string) b).ToUpper());

					break;

				case DATE:
				case TIME:
				case TIMESTAMP:
					if ((DateTime)a > (DateTime) b)
					{
						return 1;
					} 
					if ((DateTime)a >(DateTime) b)
					{
						return -1;
					} 
					else 
					{
						return 0;
					}

				case NUMERIC:
				case DECIMAL:
					return ((decimal)a > (decimal)b) ? 1 : ((decimal)b > (decimal)a ? -1 : 0);

				case BIT:
					return (((bool)a == (bool)b) ? 0 : 1);

				case TINYINT:

				case SMALLINT:
					return ((short)a > (short)b) ? 1 : ((short)b > (short)a ? -1 : 0);

				case BIGINT:
					return ((long)a > (long)b) ? 1 : ((long)b > (long)a ? -1 : 0);

				case REAL:
					return ((float)a > (float)b) ? 1 : ((float)b > (float)a ? -1 : 0);

				case BINARY:

				case VARBINARY:

				case LONGVARBINARY:

				case OTHER:
					ByteArray tmp=(ByteArray) a;
					i = tmp.compareTo((ByteArray) b);
					break;

				default:
					throw Trace.error(Trace.FUNCTION_NOT_SUPPORTED, type);
			}

			return (i > 0) ? 1 : (i < 0 ? -1 : 0);
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param s
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static object convertstring(string s, int type) 
		{
			object result;
			if (s == null) 
			{
				return null;
			}

			switch (type) 
			{

				case NULL:
					result= null;
					break;
				case INTEGER:
					result=System.Int32.Parse( s);
					break;
				case FLOAT:

				case DOUBLE:
					result=System.Double.Parse( s);
					break;

				case VARCHAR_IGNORECASE:

				case VARCHAR:

				case CHAR:

				case LONGVARCHAR:
					result=s;
					break;
				case DATE:
				case TIME:
				case TIMESTAMP:
					result= System.TimeSpan.Parse(s);
					break;

				case NUMERIC:

				case DECIMAL:
					result= System.Decimal.Parse(s);
					break;
				case BIT:
					result= System.Boolean.Parse(s);
					break;

				case TINYINT:
					result= System.Byte.Parse(s);
					break;

				case SMALLINT:
					result= System.Int16.Parse(s);
					break;
				case BIGINT:
					result= System.Int64.Parse(s);
					break;
				case REAL:
					result= System.Single.Parse(s);
					break;
				case BINARY:

				case VARBINARY:

				case LONGVARBINARY:

				case OTHER:
					result= new ByteArray(s);
					break;
				default:
					throw Trace.error(Trace.FUNCTION_NOT_SUPPORTED, type);
			}
			return result;
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param o
		 *
		 * @return
		 */
		public static string convertobject(object o) 
		{
			if (o == null) 
			{
				return null;
			}

			return o.ToString();
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param o
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static object convertobject(object o, int type) 
		{
			if (o == null) 
			{
				return null;
			}
			return convertstring(o.ToString(), type);
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param o
		 * @param type
		 *
		 * @return
		 *
		 * @throws Exception
		 */
		public static string createstring(object o, int type) 
		{
			if (o == null) 
			{
				return "NULL";
			}

			switch (type) 
			{

				case NULL:
					return "NULL";

				case BINARY:

				case VARBINARY:

				case LONGVARBINARY:

				case DATE:

				case TIME:

				case TIMESTAMP:

				case OTHER:
					return "'" + o.ToString() + "'";

				case VARCHAR_IGNORECASE:

				case VARCHAR:

				case CHAR:

				case LONGVARCHAR:
					return createstring((string) o);

				default:
					return o.ToString();
			}
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param s
		 *
		 * @return
		 */
		public static string createstring(string s) 
		{
			StringBuilder b = new StringBuilder();
			b.Append("\'");

			if (s != null) 
			{
				for (int i = 0, len = s.Length; i < len; i++) 
				{
					char c = System.Char.Parse( s.Substring(i,1));

					if (c == '\'') 
					{
						b.Append(c.ToString());
					}

					b.Append(c.ToString());
				}
			}

			return b.Append('\'').ToString();
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param in
		 * @param l
		 *
		 * @return
		 *
		 * @throws IOException
		 * @throws Exception
		 */
		public static object[] readData(BinaryReader din, int l) 
		{
			object[] data = new object[l];

			for (int i = 0; i < l; i++) 
			{
				int    type = din.ReadByte();
				object o = null;
				switch (type) 
				{

					case NULL:
						o = null;

						break;

					case FLOAT:
					case REAL:
						o = din.ReadSingle();

						break;

					case DOUBLE:
						o = din.ReadDouble();

						break;

					case VARCHAR_IGNORECASE:

					case VARCHAR:

					case CHAR:

					case LONGVARCHAR:
						o = din.ReadString();

						break;

					case DATE:
					case TIME:
					case TIMESTAMP:
						o = DateTime.Parse(din.ReadString());

						break;

					case NUMERIC:

					case DECIMAL:
						o = Decimal.Parse(din.ReadString());

						break;

					case BIT:
						o = din.ReadBoolean();

						break;

					case TINYINT:
						o = din.ReadByte();

						break;

					case SMALLINT:
						o = din.ReadInt16();

						break;

					case INTEGER:
						o = din.ReadInt32();

						break;

					case BIGINT:
						o = din.ReadInt64();

						break;

					case BINARY:

					case VARBINARY:

					case LONGVARBINARY:

					case OTHER:
						int len = din.ReadInt32();
						byte[] b = new byte[len];
						din.ReadBytes(len);
						o = new ByteArray(b);

						break;

					default:
						throw Trace.error(Trace.FUNCTION_NOT_SUPPORTED, type);
				}

				data[i] = o;
			}

			return data;
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param out
		 * @param data
		 * @param t
		 *
		 * @throws IOException
		 */
		public static void writeData(BinaryWriter dout, object[] data, Table t) 
		{
			int len = t.getInternalColumnCount();
			int[] type = new int[len];

			for (int i = 0; i < len; i++) 
			{
				type[i] = t.getType(i);
			}

			writeData(dout, len, type, data);
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param out
		 * @param l
		 * @param type
		 * @param data
		 *
		 * @throws IOException
		 */
		public static void writeData(BinaryWriter dout, int l, int[] type, object[] data) 
		{
			for (int i = 0; i < l; i++) 
			{
				object o = data[i];

				if (o == null) 
				{
					dout.Write(NULL);
				} 
				else 
				{
					int t = type[i];

					dout.Write(t);

					switch (t) 
					{

						case INTEGER:
							dout.Write((int)o);

							break;

						case FLOAT:

						case DOUBLE:
							dout.Write((double)o);

							// some JDKs have a problem with this:
							// out.writeDouble(((Double)o).doubleValue());
							break;

						case BINARY:
						case VARBINARY:
						case LONGVARBINARY:
						case OTHER:
							byte[] b = ((ByteArray)o).byteValue();
							dout.Write(b.Length);
							dout.Write(b);
							break;

						default:
							dout.Write(o.ToString());
							break;
					}
				}
			}
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param data
		 * @param t
		 *
		 * @return
		 */
		public static int getSize(object[] data, Table t) 
		{
			int l = data.Length;
			int[] type = new int[l];

			for (int i = 0; i < l; i++) 
			{
				type[i] = t.getType(i);
			}

			return getSize(data, l, type);
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param data
		 * @param l
		 * @param type
		 *
		 * @return
		 */
		private static int getSize(object[] data, int l, int[] type) 
		{
			int s = 0;

			for (int i = 0; i < l; i++) 
			{
				object o = data[i];

				s += 4;    // type

				if (o != null) 
				{
					switch (type[i]) 
					{

						case INTEGER:
							s += 4;

							break;

						case FLOAT:

						case DOUBLE:
							s += 8;

							break;

						case BINARY:
						case VARBINARY:
						case LONGVARBINARY:
						case OTHER:
							s += getUTFsize("**"); //new format flag
							s += 4;
							s += ((ByteArray)o).byteValue().Length;

							break;

						default:
							s += getUTFsize(o.ToString());
							break;
					}
				}
			}

			return s;
		}

		/**
		 * Method declaration
		 *
		 *
		 * @param s
		 *
		 * @return
		 */
		private static int getUTFsize(string s) 
		{

			// a bit bigger is not really a problem, but never smaller!
			if (s == null) 
			{
				s = "";
			}

			int len = s.Length;
			int l = 2;

			for (int i = 0; i < len; i++) 
			{
				int c = System.Int32.Parse(s.Substring(i,1));

				if ((c >= 0x0001) && (c <= 0x007F)) 
				{
					l++;
				} 
				else if (c > 0x07FF) 
				{
					l += 3;
				} 
				else 
				{
					l += 2;
				}
			}

			return l;
		}

	}
}
