/*HUFFMAN CODING.

  GNU GENERAL PUBLIC LICENSE

  Huffman Algorithm
  Copyright (C) 2003 <Pradeep P Chandiramani>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
  Feel free to send us any question, remark, bug report, feedback!
  Pradeep P Chandiramani (pradeepchandiramani@yahoo.co.in)
  Visit www.chandiramani.info for more programs and tutorials.

  Huffman Algorithm in 'C'  Ver 1.0 																																										  by Pradeep P Chandiramani -PCD- 06/02/03
*/

/*
  My program follows the following algorithm for creating the huffman tree
  and for allocating the codes to the symbols.
*/

/* Huffman Algorithm -PCD-

NODE
 _______________
|  Symbol       |
|  Frequency    |
|  Node * Right |
|  Node * Left  |
|_______________|


1)INPUT all Symbols along with their respective frequencies/pobabilities.
2)CREATE leaf (Right and Left links will be NULL)nodes representing
   the symbols scanned.
3)Let S be set containing the nodes created.
4)[Create the Huffman Tree]
  While there is only one node in S
   a)SORT the nodes (symbols) in S with respct to their frequencies.
   b)Combine the 2 symbols (nodes) with least frequencies to CREATE a
      combined symbol(node).
     Frequency of this new combined symbol(node) will be equal to sum
      of frequencies of symbols(nodes) which are combined.
     This combined symbol(node) will be parent of 2 symbols those
      were combined.
   c)Replace, in S, the 2 symbols(nodes) which were combined with the
      new combined symbol(node).

  [After 4th step you will be left with only one node,which inturn
   is the root,having frequency equal to sum of all frequences of all
   symbols. And a tree is generated with leaf nodes equal to basic
   symbols whose code is to be found.]

5)[Assigning the code]
   Start from root of tree generated in step 4 and go on assigining
    1 to every left branch and 0 to every right branch.
6)[Reading code Assigned for a symbol]
  To get the code for any symbol, start from the node of that symbol,
   this in turn will be a leaf node, and move towards root. As soon
   as any link is encountered output code assighned for that link(0/1).
   NOTE: This way you get code from LSB to MSB.


   Illustrative Example:

		Enter the no. of letter to be coded:6
		Enter the letter & frequency:a 40
		Enter the letter & frequency:b 30
		Enter the letter & frequency:c 10
		Enter the letter & frequency:d 10
		Enter the letter & frequency:e 6
		Enter the letter & frequency:f 4

		a code:1
		d code:011
		f code:01011
		e code:01010
		c code:0100
		b code:00


				  ___________
				 |adfecb 100 |
				 |___________|
				      / \
				  1 /     \ 0
			 _________/         \  _________
			| a 40    |           | dfecb 60|
			|_________|           |_________|
						 / \
					     1 /     \ 0
				   _________ /         \ _________
				  | dfec 30|            | b 30    |
				  |_________|           |_________|
				     / \
				 1 /     \ 0
			 ________/         \  _________
			|  d 10   |          |  fec 20 |
			|_________|          |_________|
						/ \
					    1  /    \  0
				     ________/        \  _________
				    |  fe 10  |         |   c 10  |
				    |_________|         |_________|
					 / \
				     1 /     \  0
			     ________/         \  _________
			    |   f 4   |          |  e 6    |
			    |_________|          |_________|


    */




/*
  Known Bugs: While displaying the Huffman Tree, sometimes nodes may overlap
	      making tree look weird. You are encouraged to remove that
	      problem
*/

/*
  Compiled in Turbo C++ ver 3.0
  Make sure you have EGAVGA.bgi file in the same directory as program, this
  file is required for displaying the Huffman Tree created.
*/


#include<stdio.h>
#include<string.h>
#include<graphics.h>
#include<iostream.h>
#include<conio.h>
#include<stdlib.h>
#define MAX 10

struct link
{
	int freq;
	char ch[MAX];
	struct link* right;
	struct link* left;
};
typedef struct link node;


void sort(node *[], int);
node* create(char[], int);
void sright(node *[], int);
void Assign_Code(node*, int [], int);
void Delete_Tree(node *);


void initialize_graphics(int& , int& );
void Draw_Tree(node *, int, int);

main()
{
	node* ptr, * head;
	int i, n, total = 0, u, c[15];
	char str[MAX];
	node* a[12];
	int freq;

	clrscr();
	printf(  "Huffman Algorithm\n");
	printf(  "Copyright (C) 2003 Pradeep P Chandiramani -PCD-\n" );
	printf(  "Huffman Algorithm comes with ABSOLUTELY NO WARRANTY;\n");
	printf(  "This is free software, and you are welcome\n" );
	printf(  "to redistribute it under GNU GENERAL PUBLIC LICENSE\n" );
	printf(  "For details read gpl.txt included with installation.\n\n" );

	printf( "Press any Key to continue..." );
	getch();

	printf("\nEnter the no. of letter to be coded:");/*input the no. of letters*/
	scanf("%d", &n);

	for (i = 0; i < n; i++)
	{
		printf("Enter the letter & frequency:");/*input the letter & frequency*/
		scanf("%s %d", str, &freq);

		a[i] = create(str, freq);
	}



	while (n > 1)
	{
		sort(a, n);
		u = a[0]->freq + a[1]->freq;
		strcpy(str,a[0]->ch);
		strcat(str,a[1]->ch);
		ptr = create(str, u);
		ptr->right = a[1];
		ptr->left = a[0];
		a[0] = ptr;
		sright(a, n);
		n--;

	}
	Assign_Code(a[0], c, 0);
	getch();

	int max_x,max_y;
	initialize_graphics(max_x, max_y);

	setfillstyle(1,LIGHTBLUE);
	settextjustify(CENTER_TEXT,CENTER_TEXT);


	bar(0,0,max_x,max_y);
	Draw_Tree(a[0],max_x/2,30);
	getch();

	Delete_Tree(a[0]);
}

/* START of NON Graphical Routines*/
node* create(char a[], int x)
{
	node* ptr;
	ptr = (node *) malloc(sizeof(node));
	ptr->freq = x;
	strcpy( ptr->ch , a);
	ptr->right = ptr->left = NULL;
	return(ptr);
}


void sort(node* a[], int n)
{
	int i, j;
	node* temp;

	for (i = 0; i < n - 1; i++)
		for (j = i; j < n; j++)
			if (a[i]->freq > a[j]->freq)
			{
				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
}



void sright(node* a[], int n)
{
	int i;
	for (i = 1; i < n - 1; i++)
		a[i] = a[i + 1];
}


void Assign_Code(node* tree, int c[], int n)
{
	int i;
	if ((tree->left == NULL) && (tree->right == NULL))
	{
		printf("%s code:", tree->ch);

		for (i = 0; i < n; i++)
		 {
		  printf("%d", c[i]);
		 }
		printf("\n");
	}
	else
	{
		c[n] = 1;
		n++;
		Assign_Code(tree->left, c, n);
		c[n - 1] = 0;
		Assign_Code(tree->right, c, n);
	}
}


void Delete_Tree(node * root)
{
    if(root!=NULL)
    {
	Delete_Tree(root->left);
	Delete_Tree(root->right);
	free(root);
    }
}
/* END of NON Graphical Routines*/


/* Start of Graphical Routines*/
void initialize_graphics(int& max_x, int& max_y)
{
	/*
	  initialize_graphics() function initializes the graphic enviroment.
	*/
	int gdriver = DETECT, gmode, errorcode;

	//registerfarbgidriver(EGAVGA_driver_far);
	initgraph(&gdriver, &gmode, NULL);



	/* read result of initialization */
	errorcode = graphresult();
	if (errorcode != grOk)  /* an error occurred */
	{
		cout << "Graphics error:" << grapherrormsg(errorcode) << endl;
		cout << "Press any key to halt:";
		getch();
		exit(1); /* terminate with an error code */
	}
	max_x = getmaxx();
	max_y = getmaxy();
}

#define RADIUS 20
#define OFFSETX 2*RADIUS
#define OFFSETY 2*RADIUS+10

void Draw_Tree(node *root,int x,int y)
{
   if(root!=NULL)
    {
	 setcolor(RED);
	 circle(x,y,RADIUS);

	 setcolor(WHITE);
	 outtextxy(x,y,root->ch);



	 if(root->left!=NULL)
	  {
	   setcolor(BLUE);
	   line(x,y+RADIUS,x-OFFSETX,y+OFFSETY);
	   setcolor(WHITE);
	   outtextxy(x-OFFSETX-10,y+OFFSETY-10,"1");
	  }

	 if(root->right!=NULL)
	  {
	   setcolor(BLUE);
	   line(x,y+RADIUS,x+OFFSETX,y+OFFSETY);
	   setcolor(WHITE);
	   outtextxy(x+OFFSETX+10,y+OFFSETY-10,"0");

	  }

	 x-=OFFSETX,y+=OFFSETY+RADIUS;
	 Draw_Tree(root->left,x,y);

	 x+=2*OFFSETX;
	 Draw_Tree(root->right,x,y);


    }
}
