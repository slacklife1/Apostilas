Last updated: 7/15/03

Huffman Tree Encoder(For data compression)
Copyright (C) <2003> <Pradeep P Chandiramani>

Description
---
Huffman Tree Encoder is an implementation of the HUffman algorithm.I wrote a simplified version of the Algorithm for this program. The Algorithm is also available with the program.The program can generate codes for the symbols entered as well as display the tree for them. An included illustrative example explains this process.View the included HTML file for Algorithm,Program and the Example.



Developer(s): 
---
Pradeep P Chandiramani (pradeepchandiramani@yahoo.co.in)
www.chandiramani.info

Compiler: 
---
Turbo C++ 3.0

Make sure you have EGAVGA.bgi file in the same directory as program, this file is required for displaying the Huffman Tree created.



Testing:
---
The program was tested on Intel P-3 machine with Windows98 SE.

Disclaimer:
---
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


Installation:
---
Just Unzip the .ZiP file and u are ready to go!

Usage:
---
There is an illustarative example with the program to help you understand it.

Known Bugs:
---
While displaying the Huffman Tree, sometimes nodes may overlap making tree look weird. You are encouraged to remove that problem

Contact us:
---
Feel free to send us any question, remark, bug report, feedback! 
Pradeep P Chandiramani (pradeepchandiramani@yahoo.co.in)



Files included:
---
readme.txt/*read first*/
gpl.txt /*GNU General Public Licence*/
Huffman.CPP /*Source code file*/
Huffman.exe /*Executable file*/
Huffman.htm /*Source code file(HTML)*/
PCD.jpg  /*logo file*/

/*PCD*/