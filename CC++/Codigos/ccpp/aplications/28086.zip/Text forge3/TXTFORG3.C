#include"stdio.h"
#include"conio.h"
#include"dos.h"
#include"dir.h"
#include"string.h"
#include"ctype.h"
char far *Vid_base=0xb8000000; /*VDU base memory address*/
int i,j;
char *menulist[]={"^File","^Edit","^Search","^Case","^Help"};
int xpos=1,ypos=1,ins=1,Exit_Forge=1,choice,save=1,tx,ty;
char ch,filename[15]="NAMELESS.TXT",*dbuff,cpline[78],cplen,fstring[40],ttime[15];
union REGS in; /*for interrupt functions*/
	struct data /*the struct definition for the linked list*/
	{
	char text[78];
	struct data *prev,*next;
	int length;
	};

typedef struct data LINE;
LINE *Cur_line,*start;
char *filemenu[]={"^New","^Open...","^Save","Save ^As...","^Change Dir","^Dos Shell","^Exit"},
*editmenu[]={"Cu^t Line","^Copy Line","^Paste Line","Insert ^Date"},*srchmenu[]={"^Find...","Find ^Next"},
*casemenu[]={"To ^Upper","To ^Lower","^Toggle Case"};
*helpmenu[]={"^Contents","^About"};
struct  time t;

void main(int argc,char *argv[])
{
clrscr();
window(2,3,79,24); /*set the window area*/
Cur_line=(LINE*)malloc(sizeof(LINE));
start=Cur_line;
Cur_line->next=NULL; /*initialization of the first node*/
Cur_line->prev=NULL; Cur_line->length=0;
if(argc>2)
	{
	printf("\nInvalid Number of arguments\n");
	exit(0);
	}
else
if(argc==2)  /*if filename is given as the second argument, copy filename and open*/
      {
      if(strlen(argv[1])>12)
       {printf("File name Too long"); free(Cur_line);  exit(0); }
      else
	{
	strcpy(filename,argv[1]);
	openfile();
	}
      }
Display_screen();   /*display list of menus*/
Display_status();
gotoxy(1,1);
setkeyboard();
while(Exit_Forge) /* the master loop*/
  {
   Displaytime();

   ch=getch();

   if(ch==0)
   Special_key();  /* do the special key function like up arrow/downarrow/left arrow delete etc*/
   else
   Normal_key(); /* set the position with the entered key or bspace ,enter key*/

   Display_status();
  }
Free_memory();
}

Display_screen()
{
int k;
char *shortcuts=" ^F^1 Help  ^F^2 Save  ^F^3 Open  ^A^L^T^-^X Exit  ^F^5 Find Next";
for(i=1;i<160;i+=2) /*set the status bar background to green and menu bar background  to green*/
 {
 *(Vid_base+(24*160)+i)=15;/*status bar*/
 *(Vid_base+i)=2;/*menu bar*/
 if(*shortcuts)
 {
 if(*shortcuts=='^')
 {
 *(Vid_base+(24*160)+i)=12;
 shortcuts++;
 }
 *(Vid_base+(24*160)+i-1)=*(shortcuts++);
 }

 }
for(i=161;i<3840;i+=2)/*set the editing screen attribute*/
*(Vid_base+i)=31;

for(i=160;i<3840;i+=160)/*draw vertial borders*/
  {
  *(Vid_base+i)='�';
  *(Vid_base+158+i)='�';
  }

for(i=2;i<80;i++)/*draw Horizontal border*/
 {
 *(Vid_base+(i*2)+(158))='�';
 }
*(Vid_base+(160))='�';/*the top left corner;*/
*(Vid_base+160+158)='�';/*the top right corner;*/
/*here ends the bordering*/

for(i=6,j=0;j<5;i+=10,j++) /*Displaying the list of menus . i is for col 1 is for first row 12 is the spacing*/
 {
 k=0;
 while(*menulist[j])
  {
  if(*menulist[j]=='^')
   { *(Vid_base+((i+k)*2)+1)=12;/*red with black background*/
   menulist[j]++;}
   else
   *(Vid_base+((i+k)*2)+1)=15;/*white with black background*/
   *(Vid_base+((i+k)*2))=*menulist[j];
   menulist[j]++;
   k++;
   }
 }

}

/* the main function which makes the manipulation of data in the Linked List*/

Normal_key()
{
LINE *tmp,*tmp1;
save=0;/* make the save flag zero since the linked list is going to be altered*/
if(ch==8)   /*Backspace key is pressed*/
{
	if(xpos>1)/*checking weather the charecter exists to backspace*/
	{
	if(xpos<Cur_line->length+2)
	  {
	    for(i=xpos-2;i<Cur_line->length;i++)/*move all the characters back one position*/
	    Cur_line->text[i]=Cur_line->text[i+1];
	  Cur_line->length--;
	  }
	xpos--;
	Display_line();
	gotoxy(wherex()-1,wherey());
	}
	else /* free the current line and move to previous line(since there is no characters to backspace)*/
	{
	tmp=Cur_line->prev;
	if(Cur_line->prev!=NULL&&(Cur_line->length+tmp->length)<78)/*if there is a line before the current line*/
		{
			tmp=Cur_line;
			Cur_line=Cur_line->prev;
			Cur_line->next=tmp->next;
			tmp1=tmp->next;
			tmp1->prev=Cur_line;
			i=0;
			while(i<tmp->length)
			{
			Cur_line->text[Cur_line->length]=tmp->text[i];
			Cur_line->length++;
			i++;
			}
			free(tmp);
			xpos=Cur_line->length-i+1; /*setting the xpos value*/
			ypos--;

			if(wherey()>1)
			gotoxy(Cur_line->length-i+1,wherey()-1);
			else
			gotoxy(Cur_line->length-i+1,wherey());
			Display_afterline();

		}
	}

}
else
if(ch==13)	/*Enter key is pressed*/
{
       if(  (tmp=(LINE*)malloc(sizeof(LINE))  )==NULL)
	{ printf("Insufficient memory space");Free_memory(); exit(0);}
	tmp->next=Cur_line->next;
	tmp->prev=Cur_line;
	tmp1=Cur_line->next;
	tmp1->prev=tmp;
	Cur_line->next=tmp;
		i=0;
		tmp->length=0;
		while(Cur_line->length>(xpos-1+i))/* copying current line remaining from current position contents to next line*/
		{
		tmp->text[i]=Cur_line->text[(xpos-1)+i];
		tmp->length++;
		*(Vid_base+((wherey()+1)*160)+((Cur_line->length-i)*2))=' ';/*erase character on screen*/
		i++;
		}
		Cur_line->length=Cur_line->length-i;
	       if(wherey()==22) /*checking if scrolling is needed*/
		{
		scrolldown();
		gotoxy(1,wherey());
		}
		else
		gotoxy(1,wherey()+1);

	Cur_line=Cur_line->next;
	ypos++;
	Display_afterline();
	xpos=1;

}
else
if(ch==9&&Cur_line->length<70) 	/*Tab is pressed*/
{
j=0;
while(j<8)/*move the caracters by 8 position*/
       {
       for(i=Cur_line->length;i>=(xpos-1);i--) /*the movement of array by one positon forward*/
       Cur_line->text[i+1]=Cur_line->text[i];
       Cur_line->text[xpos-1]=' ';
       xpos++;
       Cur_line->length++;
       j++;
       }
Display_line();
gotoxy(wherex()+8,wherey());
}

else          /*inserting the entered character into the current line if its not reached 78 characters*/
  if(Cur_line->length<77&&xpos<78)
  {
     if(ins==0&&Cur_line->length>(xpos-1)) /*if insert key is OFF and character is entered in between the line*/
     {
	*(Vid_base+(wherex()*2)+((wherey()+1)*160))=ch; /*display character on screen*/
	Cur_line->text[xpos-1]=ch;
	if((xpos-1)==Cur_line->length)/*if the cursor is at the end of the line*/
	Cur_line->length++;
	xpos++;
     }
    else
    if(Cur_line->length>(xpos-1))      /*insert key is ON and character is entered in between the line*/
      {
       for(i=Cur_line->length;i>=(xpos-1);i--) /*the movement of array contents to make space for new character*/
       Cur_line->text[i+1]=Cur_line->text[i];
       Cur_line->text[xpos-1]=ch;
       Cur_line->length++;
       xpos++;
       Display_line();
       }
		else   /*character is entered after the end of the line*/
		{
		   while((xpos-1)>Cur_line->length)/*fill spaces until the cursor positon xpos*/
		    {
		     *(Vid_base+(Cur_line->length+1)*2+((wherey()+1)*160))=' ';/*fill spaces*/
		     Cur_line->text[Cur_line->length]=' ';
		     Cur_line->length++;
		    }
		    *(Vid_base+(wherex()*2)+((wherey()+1)*160))=ch; /*make the pressed character appear on screen*/
		    Cur_line->text[Cur_line->length]=ch;
		xpos++;
		Cur_line->length++;
		}

	gotoxy(wherex()+1,wherey());/*move cursor by one position after insertion of a character*/

   }

}


Special_key()           /*the moving part of the cursor,delete and other special keys*/
{
LINE *fnode=Cur_line->next,*ffnode=Cur_line->next;/*ffnode=front to front node*/
ffnode=ffnode->next; /*point to the next to next line. ie the second line from current line*/
ch=getch();
switch(ch)
{
case 72:  /*Up arrow*/
	if(Cur_line->prev!=NULL)/*checking for current line is not the first line*/
	{
	Cur_line=Cur_line->prev;
		ypos--;
		if(wherey()>1)
		gotoxy(wherex(),wherey()-1);
		else/*scrolling needed*/
		{
		scrollup();
		Display_line();
		}

	}
break;

case 80:  /* Down arrow*/
	if(Cur_line->next!=NULL)/*checking weather the current line is not the last line*/
	{
	Cur_line=Cur_line->next;
	       if(wherey()<22)
		{
		gotoxy(wherex(),wherey()+1);
		}
		else/*scrolling needed*/
		{
		scrolldown();
		Display_line();
		}
		ypos++;
	}

break;

case 75:  /*Left arrow*/
  if(xpos>1)
  {
  xpos--;
  gotoxy(wherex()-1,wherey());
  }
break;

case 77:  /* Right Arrow*/
 if(xpos<78)
 {
 xpos++;
 gotoxy(wherex()+1,wherey());
 }
break;

case 83:  /*Delete key*/
  if(Cur_line->length>xpos-1)/*if cursor is not at the end of the line*/
	{
	for(i=xpos-1;i<Cur_line->length;i++)
	Cur_line->text[i]=Cur_line->text[i+1];
	Cur_line->length--;
	Display_line();
	save=0;
	}
	else
	if(fnode!=NULL&&(xpos+fnode->length)<78)/*if the cursor is at the end of the line and there is a next line*/
	{
		     while((xpos-1)>Cur_line->length) /*filling extra length with spaces*/
		    {
		     Cur_line->text[Cur_line->length]=' ';
		     Cur_line->length++;
		    }
		Cur_line->next=ffnode;
		ffnode->prev=Cur_line;
		i=0;
		while( i < (fnode->length))/*copy the next line to current line*/
		{
		Cur_line->text[xpos-1+i]=fnode->text[i];
		i++;
		Cur_line->length++;
		}
	save=0;
	free(fnode);
	Display_afterline();
	}
break;

case 71:     /* Home key*/
gotoxy(1,wherey());
xpos=1;
break;

case 79:     /* End Key*/
gotoxy(Cur_line->length+1,wherey());
xpos=Cur_line->length+1;
break;

case 73:    /* Page UP*/
 if(Cur_line->prev!=NULL)
    {
    i=0;
    j=wherey();
    while( i<(19+j) && Cur_line->prev!=NULL) /*seek the previous page page*/
      {
      Cur_line=Cur_line->prev;
      i++;   ypos--;
      }
    gotoxy(wherex(),1);  /*go to the starting of the page*/
    Display_afterline(); /*print the previous page*/
    i=1;
       while(i<j&&Cur_line->next!=NULL)  /*move cursor to respective previous page*/
	{
	Cur_line=Cur_line->next;
	i++;
	ypos++;
	}
      gotoxy(wherex(),j); /*seek the previous cursor place*/
    }
break;

case 81: /*Page down*/
	i=wherey();
	j=0;
	while(j< 20+i)   /*display next line until next page is reached*/
	{
	if(Cur_line->next!=NULL)
	{
	Cur_line=Cur_line->next;
	       if(wherey()<22)
		{
		gotoxy(wherex(),wherey()+1);
		}
		else/*scrolling needed*/
		{
		scrolldown();
		Display_line();
		}
		ypos++;
	}
	j++;
	}
break;

case 82:             /*Insert key is pressed*/
  if(ins==0)
  {
  _setcursortype(_NORMALCURSOR); /*set cursor to normal cursor & turn off the insert flag*/
  ins=1;
  }
 else
  {
  _setcursortype(_SOLIDCURSOR);/*set cursor to solid cursor & turn on the insert flag*/
  ins=0;
  }
break;

case 33:		/*File Menu   /*Alt+f*/
FILE:
choice=Get_Menuchoice(filemenu,7,4);
dofile(choice);
if(choice==75)    goto HELP;     /*if left arrow or right arrow is pressed*/
if(choice==77)    goto EDIT;     /*change the menu to left or right*/
break;

case 18:		/*Edit Menu   Alt+e*/
EDIT:
choice=Get_Menuchoice(editmenu,4,14);
doedit(choice);
if(choice==75)    goto FILE;
if(choice==77)    goto SEARCH;
break;

case 31: 		/*Search Menu Alt+s*/
SEARCH:
choice=Get_Menuchoice(srchmenu,2,24);
dosearch(choice);
if(choice==75)    goto EDIT;
if(choice==77)    goto CHCASE;
break;


case 46:		/*Format Menu   Alt+o*/
CHCASE:
choice=Get_Menuchoice(casemenu,3,34);
doformat(choice);
if(choice==75)    goto SEARCH;
if(choice==77)    goto HELP;
break;


case 35:		/*Help Menu   Alt+h*/
HELP:
choice=Get_Menuchoice(helpmenu,2,44);
dohelp(choice);
if(choice==75)    goto CHCASE;
if(choice==77)    goto FILE;
break;

case 59:
Help_window();
break;

case 60:              /* F2 Save File*/
	    if(strcmp("NAMELESS.TXT",filename)==0)
	    saveas();
	    else
	    savefile();
break;

case 61:             /*F3 Open file*/
	   checksave();
	   if(getfilename())
	   openfile();
break;

case 63:            /*F5 Find string*/
 findstring();
break;

case 32:           /*Alt+X cut line*/
cutline();
break;

case -94:          /* ALT+INS copy line*/
copyline();
break;

case 47:          /*Alt+v Paste line*/
pasteline();
break;

case 45:     /*Alt +X exit*/
	    checksave();
	    Exit_Forge=0;
	    break;

 }
}

Display_line() /*displays the current line (line of the current node)*/
{
int row=wherey()+1,col=2;
 for(i=0;i<Cur_line->length;i++,col+=2)
 {
 *(Vid_base+col+(row*160))=Cur_line->text[i];
 }
 *(Vid_base+((Cur_line->length+1)*2)+(row*160))=' ';/*erase the last character*/

}

Display_afterline()  /*display all LINE after the current line(includes the current line)*/
{
int row=wherey()+1,col=1;
LINE *tmp=Cur_line;
       while(tmp&&row<24) /*display lines until it is not the last line of the screen*/
	{
	col=1;
	 for(i=0;i<tmp->length;i++,col++)
	 {
	 *(Vid_base+(col*2)+(row*160))=tmp->text[i];
	 }
  while(col<78)/*cover the remaining line space with blank(ie' ')*/
  {
  *(Vid_base+(col*2)+(row*160))=' ';
  col++;
  }
tmp=tmp->next;
row++;
}
col=1;
while(row<24&&col<78)/* Erasing the last line*/
 {
 *(Vid_base+(col*2)+(row*160))=' ';
 col++;
 }

}

scrolldown()
{
in.h.ah=0x06;
in.h.al=1;  /*lines to scroll*/
in.h.bh=31; /* Filler attribute*/
in.h.ch=2;  /*up row*/
in.h.cl=1;  /*left column*/
in.h.dh=23; /*down row*/
in.h.dl=78; /*right column*/
int86(0x10,&in,&in);
}

scrollup()
{
in.h.ah=0x07;
in.h.al=1;  /*lines to scroll*/
in.h.bh=31; /* Filler attribute*/
in.h.ch=2;  /*up row*/
in.h.cl=1;  /*left column*/
in.h.dh=23; /*down row*/
in.h.dl=78; /*right column*/
int86(0x10,&in,&in);
}

Display_status()
{
int row=24,col=0,x=0;
char status[25];
if(ins==0)
sprintf(status,"REPLACE  Row:%3d Col:%2d",ypos,xpos);
else
sprintf(status,"INSERT   Row:%3d Col:%2d",ypos,xpos);
 col=110;
 while(status[x])
 {
 *(Vid_base+(row*160)+col)=status[x++];
 col+=2;
 }

col=24;
 while(col<36)
 *(Vid_base+180+(col++*2))=' ';/*make 12 char space to display filename(24-36)*/
x=0;
col=30-(strlen(filename)/2);
 while(filename[x])     /*Display filename*/
 {
 *(Vid_base+180+(col*2))=filename[x];
 x++;  col++;
 }

}


int Get_Menuchoice(char **menu,int titem,int col)
{
int area,row=2,tcol=col,cur=2,prev,trow=row; /*row is assigned 2 bcoz the menu is printed from the second line*/
int i;
char ch=0,*buffer,*tmp,hotkeys[7],hl[10];
_setcursortype(_NOCURSOR);/*remove the cursor display*/
area=(titem+2)*14*2; /* +2 for borders*/
buffer=(char*)malloc(area);/*allocating space for buffer*/

j=0;
for(i=tcol+1;i<tcol+10;i++)/* set the attribute of the menu title*/
{
hl[j++]=*(Vid_base+(i*2)-1);/*copy attribute*/
*(Vid_base+(i*2)-1)=14;     /*set attribute */
}
drawboxnsave(buffer,row,titem,col,14);  /*draw the box in menu area and save it into buffer*/

for(i=0;i<titem;i++) /*Displaying the list of menu items*/
 {
 col=tcol;
 col=col+1;/*make space for border*/
 tmp=menu[i]; /*getting the starting address of the menu item into temp ;*/
 while(*menu[i])
  {
   col++;
   if(*menu[i]=='^')
    {
    menu[i]++;
    *(Vid_base+((col*2)+(row*160))+1)=RED; /*Setting the attribute for the Hotkey char as RED*/
    hotkeys[i]=*menu[i];
    }
   else
    *(Vid_base+((col*2)+(row*160))+1)=WHITE;
   *(Vid_base+((col*2)+(row*160)))=*menu[i];
   menu[i]++;
   }
  menu[i]=tmp;/*setting back the starting address of the menu item;*/
  row++;
 }

while(ch!=13)/*display menu until a choice is made and Enter key is pressed*/
{

 for(col=tcol+2;col<tcol+14;col++)/* set the background of the selected menu item to GREEN which has ascii value of 32*/
  *(Vid_base+((cur)*160)+(col*2)-1)+=32;
 prev=cur;
 ch=getch(); /*get a keyboard hit to make a choice from menu*/
 if(ch==27)/*Check if escape key is pressed*/
 {ch=13; cur=0;}

 for(i=0;i<titem;i++)/*check if hot key pressed*/
 if(ch==tolower(hotkeys[i])||ch==toupper(hotkeys[i]))
 {cur=i+2; ch=13;}

 if(ch==0)/*if special key is pressed*/
 ch=getch();
 if(ch==72)/* (Up arrow) Move the Selection Up*/
 cur--;
 if(ch==80)/* (Down arrow) Move the Selection Down*/
 cur++;
 if(cur==1)/*check if the menu is over scrolled up*/
 cur=titem+1;
 if(cur==titem+2)/*check if the menu is over scrolled down*/
 cur=2;
 for(col=tcol+2;col<tcol+14;col++)/*set back the background of the previously selected menu item from green to black*/
   *(Vid_base+((prev)*160)+(col*2)-1)-=32;
 if(ch==75||ch==77) /*left and right arrow is pressed*/
 {
 cur=ch+1;
 ch=13;
 }
 }
row=trow;/*get the row value to previus value*/
restorebox(buffer,row,titem,tcol,14);/* restore the area covered by menu*/
free(buffer);

if(ins==1)                   /*restore the cursor*/
_setcursortype(_NORMALCURSOR);
else
_setcursortype(_SOLIDCURSOR);

j=0;
for(i=tcol+1;i<tcol+10;i++)/* set the attribute of the menu title back to previous attribute*/
{
*(Vid_base+(i*2)-1)=hl[j++];     /*set attribute*/
}

return(cur-1);
}

drawboxnsave(char *buffer,int row,int trow,int scol,int ecol) /*draw box and save[ syntax: buffer, row, total row, starting column, total columns]*/
{
int i,col;
 for(i=row-1;i<row+trow+1;i++)/*saving previous menu area into buffer +1  and -1 for the extra border*/
 for(col=(scol*2);col<(scol*2)+(ecol*2);col++)  /*11 is the width(columns) of the area covered by menu +4 for border*/
 {
 *buffer=*(Vid_base+(i*160)+col);/*saving to buffer*/
 buffer++;
	if(col%2!=0)   /*make the odd numbers (ie the attribute of char) to black background*/
	*(Vid_base+(i*160)+col)=1;/*set attribute value to blue color*/
	else
	if(i==row-1||i==trow+row)/*draw horizontal border if it is the first row or last row*/
	*(Vid_base+(i*160)+col)='�';
	else
	if(col==(scol*2)||col==((scol+ecol-1)*2))/*draw the vertical borders*/
	*(Vid_base+(i*160)+col)='�';
	 else
	 *(Vid_base+(i*160)+col)=' ';/*clearing the box area*/
 }
 /*draw the corners of the box*/
 *(Vid_base+((row-1)*160)+scol*2)='�';
 *(Vid_base+((row-1)*160)+(scol+ecol-1)*2)='�';
 *(Vid_base+((row+trow)*160)+scol*2)='�';
 *(Vid_base+((row+trow)*160)+(scol+ecol-1)*2)='�';
}


restorebox(char *buff,int row,int trow,int scol,int ecol) /*restore box area*/
{
int i,col;
 for(i=row-1;i<row+trow+1;i++)/*Restore the area covered by the menu from the buffer store*/
  for(col=(scol*2);col<(scol*2)+(ecol*2);col++)
  {
  *(Vid_base+((i*160)+col))=*buff;
  buff++;
  }
}

dofile(int choice)  /*do the file service*/
{
     switch(choice)
     {
	case 1:             /*create new file*/
	  createnew();
	break;

	case 2:           /*open a file*/
	   checksave();
	   if(getfilename())
	   openfile();
	break;

	case 3:       /*save the current file*/
	    if(strcmp("NAMELESS.TXT",filename)==0)
	    saveas();
	    else
	    savefile();
	break;

	case 4:   /* Save As*/
	    saveas();
	break;

	case 5:       /*change directory*/
	   Change_Directory();
	break;

	case 6:       /*this option works only when you run the exe file alone*/
	tx=wherex(); /*save the cursor positons*/
	ty=wherey(); /*temporaryly*/
	j=80*25*2; /*calculate no of bytes required to save the screen*/
	dbuff=(char*)malloc(j);       /*make area for saving box area*/
	drawboxnsave(dbuff,1,23,0,80);
	textattr(7);
	window(1,1,80,25);
	clrscr();
	system("c:\\windows\\command.com");
	restorebox(dbuff,1,23,0,80);
	window(2,3,79,24); /*set the window area*/
	gotoxy(tx,ty);
	free(dbuff);
	break;

	case 7:/*exit*/
	    checksave();
	    Exit_Forge=0;
	    break;

  }
}

Free_memory() /*free the memory allocated to linked list*/
{
  while(start)
  {
  Cur_line=start;
  start=start->next;
  free(Cur_line);
  }
}

checksave()
{
char ch;
	if(save==0)
	{
	   Draw_Dialog();
	   gotoxy(12,11);
	   cprintf("Do you wanna save changes to %s?(Y/N):",filename);
	   ch=getch();
	   Clear_Dialog();
	   if(ch=='y'||ch=='Y')
	     {
	      if(strcmp("NAMELESS.TXT",filename)==0)
	       saveas();
	       else
	       savefile();
	     }
	}
}

createnew()
{	  checksave();
	  Free_memory();
	  Cur_line=(LINE*)malloc(sizeof(LINE));
	  Cur_line->prev=NULL;
	  Cur_line->length=0;
	  Cur_line->next=NULL;
	  start=Cur_line;
	  xpos=1;
	  ypos=1;
	  save=1;
	  strcpy(filename,"NAMELESS.TXT");
	  textattr(31);/*set color to clear screen for new file*/
	  clrscr();
}

savefile()
{
FILE *fp;
LINE *tmp=start;
int x;
char chr;
fp=fopen(filename,"w");
	while(tmp)
	{
	x=0;
	 while(x<tmp->length)
	  {
	  chr=tmp->text[x];
	  fputc(chr,fp); /*write the character into the file*/
	  x++;
	  }
	  if(tmp->next!=NULL)
	  fputc('\n',fp);/*write newline character*/
	 tmp=tmp->next;/*move to next line*/
	 }
fclose(fp);
save=1;
}

openfile()
{
int area;
char chr;
int x=0,t;
FILE *fp;
LINE *tmp;
	     Free_memory();
	     Cur_line=(LINE*)malloc(sizeof(LINE));//initialize first node for new file
	     Cur_line->prev=NULL;
	     Cur_line->next=NULL;
	     Cur_line->length=0;
	     start=Cur_line;
	     fp=fopen(filename,"r");
	      while((chr=fgetc(fp))!=EOF)
	      {
	      if(chr=='\n'||Cur_line->length==77)
	       {
		tmp=Cur_line;
		i=Cur_line->length;
		Cur_line->next=(LINE*)malloc(sizeof(LINE));
		Cur_line=Cur_line->next; x=0;
		Cur_line->next=NULL;
		Cur_line->prev=tmp;
		Cur_line->length=0;
		  if(i==77)/*77th character is reached*/
		  {
		  Cur_line->text[x]=chr;
		  Cur_line->length=1;
		  x++;
		  }
	       }
	       else
	       if(chr==9&&(Cur_line->length+8)<78)/*Tab character*/
	       {
	       t=0; while(t++<8)
		    {
		    Cur_line->text[x]=' ';
		    x++;
		    Cur_line->length++;
		    }
	       }
	       else
	       {
	       Cur_line->text[x]=chr;
	       x++;
	       Cur_line->length++;
	       }
	     }
	    textattr(31);
	    clrscr();    /*clear the previous file contents on screen*/
	    Cur_line=start;
	    Display_afterline();

	    xpos=1;
	    ypos=1;
	    gotoxy(xpos,ypos);

	    fclose(fp);
}

saveas()
{
  FILE *tmp;
  char fname[15],fchoice;
  int gotit;
  Draw_Dialog();
  gotoxy(12,11);
  cprintf("Enter the file name to Save As:");
  if(getstring(&fname))
  {
    if(strlen(fname)>12||strlen(fname)==0)/*check for length of the filename given to be less than 9 characters*/
    {
    gotoxy(12,12); printf("File name should be < 12 characters and > 0");
    getch();
    }
    else
    if(tmp=fopen(fname,"r")!=NULL)//check if the file already exists. and prompt the user to replace
      {
      fclose(tmp);
      gotoxy(12,12);
      cprintf("File already exists. Replace?(y/n):");
      fchoice=getche();
	if(fchoice=='y'||fchoice=='Y')
	{
	strcpy(filename,fname);
	savefile();
	}
      }
  else //save as a new file
    {
    strcpy(filename,fname);
    savefile();
    }
  }
  Clear_Dialog();
}

Draw_Dialog()      /*draws a dialog on the screen saving the previous screen contents*/
{
   int area;
   tx=wherex(); /*save the cursor positons*/
   ty=wherey(); /*temporaryly*/
	area=(8)*50*2; /* +2 for borders*/
	dbuff=(char*)malloc(area);       /*make area for saving box area*/
	   drawboxnsave(dbuff,10,5,10,55);
	   textattr(4);
}

    Clear_Dialog() /*restores the dialog drawn by drawdialog function*/
	{
	restorebox(dbuff,10,5,10,55);
	free(dbuff);
	gotoxy(tx,ty);/*restore cursor to previous position*/
	}

Change_Directory()
{
 char curdir[MAXPATH],newdir[MAXPATH];
   current_directory(curdir);
   Draw_Dialog();
   gotoxy(12,11);
   cprintf("The Current Directory is %s", curdir);
   gotoxy(12,12);
   cprintf("Enter the Directory Path to change:");
   if(getstring(newdir))
		if (chdir(newdir)) /*check if directory exists*/
		     {
		     gotoxy(12,13);
		     printf("Invalid directory specification!");
		     getch();
		     }
   Clear_Dialog();
}

current_directory(char *path)
{
   strcpy(path, "X:\\");      /* fill string with form of response: X:\ */
   path[0] = 'A' + getdisk();    /* replace X with current drive letter */
   getcurdir(0, path+3);  /* fill rest of string with current directory */
}

doedit(int choice)          /*edit menu operations*/
{
 switch(choice)
 {
 case 1:    /*cut line*/
 cutline();
 break;

 case 2:   /*copy Line*/
 copyline();
 break;

 case 3: /*paste line*/
 pasteline();
 break;

 case 4:
  Insert_date();
 break;

 }
}

cutline()   /*cut line function*/
{
LINE *tmp,*tmp2;
 cplen=0;
   while(cplen<Cur_line->length)
   cpline[cplen]=Cur_line->text[cplen++];
 if(Cur_line->prev==NULL&&Cur_line->next==NULL)/*if cursor is at first line and there is no line after current line*/
 Cur_line->length=0;
 else
 if(Cur_line->prev!=NULL)
	{
	tmp2=Cur_line;
	tmp=Cur_line->prev;
	tmp->next=Cur_line->next;
	Cur_line=Cur_line->next;
	Cur_line->prev=tmp;
	free(tmp2);
	if(Cur_line==NULL){ Cur_line=Cur_line->prev;gotoxy(wherex(),wherey()-1); ypos--;}/*if the current line is the last line move to previous line*/
	}
 else
   {
   tmp=Cur_line;
   Cur_line=Cur_line->next;
   Cur_line->prev=NULL;
   free(tmp);
   }
 Display_afterline();
}

copyline()         /*copy line function*/
{
 cplen=0;
  while(cplen<Cur_line->length)
  cpline[cplen]=Cur_line->text[cplen++];
}

pasteline()       /*paste line function*/
{
   int i=0;
   LINE *tmp,*tmp2;
   tmp=(LINE*)malloc(sizeof(LINE));/*allocate space for new line to be pasted*/
   tmp2=Cur_line->prev;
   tmp2->next=tmp;
   tmp->next=Cur_line;
   tmp->prev=Cur_line->prev;
   Cur_line->prev=tmp;
   Cur_line=tmp;
   Cur_line->length=cplen;
     i=cplen;
     while(i>=0)/*copy the contents of buffer to the new line*/
     Cur_line->text[i]=cpline[i--];
   Display_afterline();
}

setkeyboard()  /*set keyboard status*/
{
char far *kb;
kb=0x417;
*kb=160;/*set the numlock and insert ON and all other locks off*/
}

dosearch(int choice)  /*search menu operations*/
{
int x,y;
 switch(choice)
 {
  case 1:   /*find string*/
  if(getfstring())
  findstring();
  break;

  case 2:
  findstring();
  break;
 }

}

getfstring() /*get the string to find*/
       {
       char find[40];
       int gotit;
       i=0;
       Draw_Dialog();
       gotoxy(12,11);
       cprintf("Enter the String To Find:");
	   textattr(2);
	   gotit=getstring(&find);
	   if(gotit==1)
	   strcpy(fstring,find);
       Clear_Dialog();
       return(gotit);
       }

findstring()
    {
    int found=0;
    int i,j,lcount=0;
    char tmpstring[40]; /*tmpstring is used to store a string temporarily and compare with the search string*/
    LINE *tmp=Cur_line;
    i=xpos;
    while(tmp&&found==0)
     {
	while(i<tmp->length&&found==0)
	{
	j=0;
		while(tmp->text[i]!=' '&&tmp->text[i]!=','&&tmp->text[i]!='.'&&i<tmp->length)/*checking for terminating string chracters*/
		{
		tmpstring[j++]=tmp->text[i++];
		}
		tmpstring[j]='\0';
		     if(strcmp(tmpstring,fstring)==0)
			  {
			  Cur_line=tmp;
			  xpos=i+1;/*set cursor position*/
			  ypos=ypos+lcount;
			  found=1;
			  j=0;
			  while(j++<10&&Cur_line->prev)/*seek the line 10 positons back to bring the searched string to the center of the screen*/
			  Cur_line=Cur_line->prev;
			  textattr(31);/*attribute to fill screen*/
			  clrscr();
			  Display_afterline();
			  Cur_line=tmp;             /*make the line in which string is fount to be current line*/
			  gotoxy(xpos,j);
			  }
	 i++;
	 }
       tmp=tmp->next;
       i=0;
       lcount++;
      }
   if(found==0)  /*if the given string is not found*/
      {
       Draw_Dialog();
       gotoxy(26,11);
       cprintf("String Not Found!");
       getch();
       Clear_Dialog();
       }
   }

doformat(int choice)
{
switch(choice)
{
case 1:
for(i=0;i<Cur_line->length;i++)
Cur_line->text[i]=toupper(Cur_line->text[i]);
Display_line();
break;

case 2:
for(i=0;i<Cur_line->length;i++)
Cur_line->text[i]=tolower(Cur_line->text[i]);
Display_line();
break;

case 3:

for(i=0;i<Cur_line->length;i++)
{
if(islower(Cur_line->text[i]))
Cur_line->text[i]=toupper(Cur_line->text[i]);
else
Cur_line->text[i]=tolower(Cur_line->text[i]);
}
Display_line();

break;
}
}

dohelp(int choice) /*help menu operations*/
{
	_setcursortype(_NOCURSOR);
	switch (choice)
	{
	case 1:    /*Help Contents window*/
	Help_window();
	break;

	case 2:    /*About window*/
	Draw_Dialog();
	gotoxy(30,9);
	textattr(12);   cprintf("Text Forge 1.3");
	gotoxy(24,10); 	printf("Team Members:  Sharath A.V");
	gotoxy(20,11); 	printf("Srikanth K.S And Santosh kumar J.J");
	gotoxy(13,12); 	printf("National College Basavangudi, Bangalore University");
	gotoxy(13,13); 	printf("Designed As part of IV sem BCA Text Editor Project");
	getch();
	Clear_Dialog();
	break;
       }
	if(ins==1)
	_setcursortype(_NORMALCURSOR);
	else
	_setcursortype(_SOLIDCURSOR);
}

getfilename() /*gets the file name to be opened*/
 {
  char fname[40],gotit=0;
	   Draw_Dialog();
	   gotoxy(12,11);
	   cprintf("Enter the file name to Open:");
	   gotit=getstring(&fname);
	   if(gotit==1)
	   {
		if(strlen(fname)>12||strlen(fname)==0)/*check for file name length to be less than or equal to 12 characters*/
		{
		gotoxy(12,12);
		printf("File name should be < 12 characters and > 0");
		getch();
		gotit=0;/*make the gotit flag 0*/
		}
	       else
		  strcpy(filename,fname);

	   }
	   Clear_Dialog();
	   return(gotit);
 }

	Help_window() /*draws the help window*/
	{
	int area;
	i=wherex();
	j=wherey();
	_setcursortype(_NOCURSOR);
	area=(10+2)*(65+2)*2; /* +2 for borders*/
	dbuff=(char*)malloc(area);       /*allocate memory for saving box area*/
	drawboxnsave(dbuff,5,15,5,70);
	gotoxy(35,3);
	textattr(12);
	cprintf("Help Window"); /* print the window title*/
	textattr(4);
	gotoxy(20,5); cprintf("Short cut Key      Operation");
	gotoxy(20,7);  printf("F1                 Help Window");
	gotoxy(20,8);  printf("F2                 Save File");
	gotoxy(20,9);  printf("F3                 Open file");
	gotoxy(20,10); printf("F5                 Find Again or Find Next");
	gotoxy(20,11); printf("Alt+F              File Menu");
	gotoxy(20,12); printf("Alt+E              Edit Menu");
	gotoxy(20,13); printf("Alt+S              Search Menu");
	gotoxy(20,14); printf("Alt+X              Exit");
	gotoxy(20,15); printf("Alt+D              Cut Line");
	gotoxy(20,16); printf("Alt+INS            Copy Line");
	gotoxy(20,17); printf("Alt+V              Paste Line");
	getch();
	restorebox(dbuff,5,15,5,70);
	free(dbuff);
	gotoxy(i,j);
	if(ins==1)
	_setcursortype(_NORMALCURSOR);
	else
	_setcursortype(_SOLIDCURSOR);
	}

	getstring(char *str)/*gets a string from the user and returns 1 if successfull*/
	{
	   i=wherex();
	   textattr(9);
	   while((*str=getche())!=27&&*str++!=13)/*scan filename until enter key or escape key is pressed*/
	   {
	     if(*(str-1)==8)                 /*backspace*/
	      {
		   if(wherex()>=i)
		   {
		   str-=2; /*remove one character back and the backspace value stored in pointer*/
		   *(Vid_base+((wherex())*2)+((wherey()+1)*160))=' ';
		   }
		   else
		  { gotoxy(wherex()+1,wherey());
		   str--;
		  }
	      }
	   }
	   if(*(str-1)==13)/*if enter key is pressed, terminate string with null char/*13 is value of enter key*/
	   {
	   *(str-1)='\0';
	   return 1;
	   }
	   else
	   return 0;
	}

Displaytime()
{
	while(!kbhit())
     {
     gettime(&t);
     sprintf(ttime,"%2d:%02d:%02d",t.ti_hour, t.ti_min, t.ti_sec);
     i=134;
     j=0;
	while(ttime[j])
	     {
	     *(Vid_base+i)=ttime[j++];
	     i+=2;
	     }
     }

}


Insert_date()
{
char tdate[11];
struct date d;

if(Cur_line->length<69&&xpos<69)
    {
    getdate(&d);
    sprintf(tdate,"%2d:%2d:%4d",d.da_day,d.da_mon,d.da_year);

	for(i=Cur_line->length;i>xpos-2;i--)//make space to insert date
	{
	Cur_line->text[i+10]=Cur_line->text[i];
	}

       j=0;
       for(i=xpos-1;i<xpos+9;i++) //insert the date in the space
       {
       Cur_line->text[i]=tdate[j++];
       }
     Cur_line->length+=10;
     Display_line();
    }

}