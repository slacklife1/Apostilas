hi
these is a universal installer creator
with this softwae u can create proffesional packages
just read documentation file after installation
follow the steps to proceed

extract all files in same folder/directory
execute/click setup.exe

1)click next

2)u will be prompted for project name just enter-----> setup
 
after this step

3)click on exit



it will create a following things on your machine

/*************************************************/
c:\uni
main directory contains following things
src------>directory
exe------>directory
readme.txt----->documentation file


/*************************************************/
c:\uni\src
source code directory contains following files
setup.c
install.c
window.h

/*************************************************/
c:\uni\exe
executables directory contains following files
setup.exe
install.exe
egavga.bgi


contact info:
vaibhavk_@hotmail.com