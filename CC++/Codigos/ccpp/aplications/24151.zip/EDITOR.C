#include<stdlib.h>
#include<alloc.h>
#include<stdio.h>
#include<conio.h>

write2vdu(char, char, int, int);
void border(void);
int search(char);
void insert( char);
void backspace(void);
void save(void);
void open(char*);
void delete(void);
void position(void);
char readvdu(int,int);

char attr = 11;
char far *vidmem = (char far *)(0xB8000000);
FILE *filep;


main()
{
	int xi,yi,xf,yf;
	int j,h,l;
	char c=0,spkey,s,i,end;
	char se[80],sea[]="Search :";
	char filename[20];
	int x=2,y=5,x1,y1;
	int a;
	FILE *filep;
	border();
	window( 3,5,77,24);


	while(c!=27)
	{

	 c=getch();

	 if(c==8){	     backspace();    		        }         /* backspace */

	 if(c==0)
	 {
	  spkey = getch();
	  switch(spkey)
	  {

	   case 71:      y=wherey();                              /* home */
					 gotoxy(1,y);
					 break;

	   case 79:      y=wherey();                              /* end */
					 gotoxy(75,y);
					 x=wherex();
					 while(1)
					 {
					  end=readvdu(y+3,x);
					  if((end!=' ')||(x==1))   break;
					  x--;
					 }
					 gotoxy(x,y);
					 break;

	   case 72:      y=wherey(); x=wherex();
					 y--;                     /* up */
					 gotoxy(x,y);
					 break;

	   case 77:      x=wherex(); y=wherey();                  /* right */
					 x++;
					 gotoxy(x,y);
					 break;

	   case 75:      x=wherex(); y=wherey();
					 x--;                     /* left */
					 gotoxy(x,y);
					 break;

	   case 80:      x=wherex(); y=wherey();
					 y++;                     /* down */
					 gotoxy(x,y);
					 break;

	   case 83:      delete();                                /* delete */
					 break;

	   case 82:      i=0;                                     /* insert */
					 while(i!=27)
					 {
					  i=getch();
					  insert(i);
					  position();
					 }
					  break;

	   case 59:      window(1,1,77,4);                        /* F1 search */
					 gotoxy(52,3);
					 for(i=0; sea[i]!=NULL; i++)
					 write2vdu(sea[i],attr,2,i+42);
					 s=getche();
					 a=search(s);
					 window(1,1,77,4);
					 gotoxy(66,3);
					 printf("%d Occurences",a);
					 getch();
					 gotoxy(41,3);
					 printf("                                      ");
					 window( 3,5,77,21);
					 break;

	   case 60:      window(1,1,77,4);                        /* F2 save */
					 gotoxy(45,3);
					 printf("Save as: ");
					 gets(filename);
					 getch();
                     gotoxy(45,3);
					 printf("                        ");

					 filep=fopen("filen","w+");
					 fclose(filep);
					 save();
					 fclose(filep);
					 window( 3,5,77,21);
					 break;

	   case 61:      window(1,1,77,4);                        /* F3 open */
					 gotoxy(45,3);
					 printf("Open file: ");
					 gets(filename);
					 open(filename);
					 window(1,1,77,4);
					 getch();
                     gotoxy(45,3);
					 printf("                        ");
					 window( 3,5,77,21);
					 break;

	   case 62:                                               /* F4 start select */
					  xi=wherex();   yi=wherey();
					  break;

	   case 63:       i=0;                                    /* F5 end select */
					  xf=wherex();
					  for(h=xi; h<=xf; h++)
					   {
						 se[i]=readvdu(yi+3,h);
						 write2vdu(se[i],25,yi+3,h);
						 i++;
					   }
					   l=i;
					  break;

	   case 64:       i=0;                                    /* F6 paste */
					  x=wherex(); y=wherey();
					  for(h=0; h<l; h++)
					   {
						 write2vdu(se[i],attr,y+3,x+h);
						 i++;
					   }
					  break;

	  }
	 }
	 else
	 {
		 if((c!=13)&&(c!=8)&&(c!=27))
		 {
			x=wherex();
			y=wherey();
			if(x>74)
			 { x=1; y++; gotoxy(x,y);  }
/*			printf("%c",c);*/
		  write2vdu(c,attr,y+3,x+1);
		  gotoxy(x+1,y);
		 }
	 }

	if(c==13){	     y=wherey(); y++; x=1;                    /* enter */
					 gotoxy(x,y);                   }


	 position();

	}
}


void border(void)
{
 int i;
 int f,g;
 char line[] = "Line";
 char col[] = "Col";
 clrscr();

 for(i=1; i<=23; i++)
 {
  write2vdu(179,attr,i,0);
  write2vdu(179,attr,i,79);
 }
 for(i=1; i<=78; i++)
 {
  write2vdu(205,attr,0,i);
  write2vdu(205,attr,24,i);
 }
  write2vdu(213,attr,0,0);                           /* four ends */
  write2vdu(184,attr,0,79);
  write2vdu(212,attr,24,0);
  write2vdu(190,attr,24,79);
													 /* line */
   for(i=1; i<=78; i++)
  write2vdu(196,attr,3,i);

   for(i=0; line[i]!=NULL; i++)
  write2vdu(line[i],attr,2,i+4);

   for(i=0;col[i]!=NULL; i++)
  write2vdu(col[i],attr,2,i+16);

}


write2vdu(char ch, char attr, int row, int col)
{
  char far *v;
  v = vidmem + row*160 + col*2 ;
  *v = ch;
  v++;
  *v = attr;
}

char readvdu( int row, int col)
{
  char far *v;
  v = vidmem + row*160 + col*2 ;
  return(*v);
}

int search(char s)
{
	int x, y, l=0;
	char far *p;

	for(y=1; y<20; y++)
	{
	  for(x=1; x<70; x++)
	  {
	   p=(vidmem + (3+y)*160 + x*2  );
	   if(*p==s)
	   {
		 write2vdu(s,59,y+3,x);
		 l++;
		 getch();
		 write2vdu(s,attr,y+3,x);
	   }
	  }
	}
	return(l);
}

void insert(char i)
{
   char far *k;
   char far *u;
   int b,x,y;
   if(i==27) return;
   x=wherex(); y=wherey();
   k = vidmem + (y+3)*160 + x*2 ;
   u = vidmem + (y+3)*160 + 77*2 ;

   for( b=(77-x); b>0; b--)
   {
	 *u=*(u-2);
	 u=u-2;
   }
   *(k+2)=i;
   x++; gotoxy(x,y);
   return;
}


void backspace(void)
{
 char far *k;
 int b,x,y;
 x=wherex();   y=wherey();
 if(x<=1)
 return;
 k = vidmem + (y+3)*160 + x*2 ;
 for(b=0; b<=77-x; b++)
 {
  *k=*(k+2);
  k=k+2;
 }
 gotoxy(x-1,y);
 return;
}



void save(void)
{
 int x,y;
 char t;

 for(y=3; y<24; y++)
 {
  for(x=2; x<75; x++)
  {
   t=readvdu(y,x);
   fputc(t,filep);
  }
 }

}

void open(char* f)
{
 char vdu[4096];
 char far *u=vidmem;
 FILE *fp;
 int b;
 fp = fopen(f,"r");
 fgets(vdu,4096,fp);
 for(b=0; b<4096; b++)
 {
  *u=vdu[b];
  u++;
 }
 fclose(fp);
}

void delete(void)
{
 char far *k;
 int b,x,y;
 x=wherex();   y=wherey();
 if(x<=1)
 return;
 k = vidmem + (y+3)*160 + x*2 + 2 ;
 for(b=0; b<=76-x; b++)
 {
  *(k)=*(k+2);
  k=k+2;
 }
 return;
}

void position(void)
{
	int x1,y1;
	x1=wherex();   y1=wherey();
	window(1,1,77,4);
	gotoxy(11,3);   printf("  ");
	gotoxy(11,3);   printf("%d",y1);
	gotoxy(22,3);   printf("  ");
	gotoxy(22,3);   printf("%d",x1);
	window( 3,5,77,24);
	gotoxy(x1,y1);
}


