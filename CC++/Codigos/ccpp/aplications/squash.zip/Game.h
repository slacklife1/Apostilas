#include<graphics.h>
#include<stdlib.h>
#include<dos.h>
m()
{
	union REGS i,o;
	i.x.ax=0;
	int86(51,&i,&o);
	return 0;
}
changemp(int i1,int j1)
{
	union REGS i,o;
	i.x.ax=4;
	i.x.cx=i1;
	i.x.dx=j1;
	int86(51,&i,&o);
	return 0;
}
hidemp()
{
	union REGS i,o;
	i.x.ax=2; int86(51,&i,&o);
	return 0;
}
showmp()
{
	union REGS i,o;
	i.x.ax=1;
	int86(51,&i,&o);
	return 0;
}
getmstat(int *b,int *x,int *y)
{
	union REGS i,o;
	i.x.ax=3;
	int86(51,&i,&o);
	*b=o.x.bx;
	*x=o.x.cx;
	*y=o.x.dx;
	return 0;
}
/* graphics function*/
win(int x1,int y1,int x2,int y2)
{
	setlinestyle(0,1,1);
	setfillstyle(1,7);
	bar(x1,y1,x2,y2);
	setcolor(WHITE);
	line(x1,y1,x2,y1);
	line(x1,y1,x1,y2);
	setcolor(0);
	line(x1,y2,x2,y2);
	line(x2,y1,x2,y2);
	setfillstyle(1,1);
	bar(x1+1,y1+1,x2-1,y1+20);
	return 0;
}
button(int x1,int y1,int x2,int y2,char s[30])
{
	int t1,t2,k=0,i;
	setlinestyle(0,1,1);
	for(i=0;i<strlen(s);i++)
		k=k+4;
	t1=(x2-x1)/2+x1-k;
	t2=(y2-y1)/2+y1;
	unpress(x1,y1,x2,y2);
	settextstyle(0,0,0);
	outtextxy(t1,t2,s);
	return 0;
}
unpress(int x1,int y1,int x2,int y2)
{
	setlinestyle(0,1,1);
	setfillstyle(1,7);
	bar(x1,y1,x2,y2);
	setcolor(WHITE);
	line(x1,y1,x2,y1);
	line(x1,y1,x1,y2);
	setcolor(0);
	line(x1,y2,x2,y2);
	line(x2,y1,x2,y2);
	return 0;
}
press(int x1,int y1,int x2,int y2)
{
	setlinestyle(0,1,1);
	setfillstyle(1,7);
	bar(x1,y1,x2,y2);
	setcolor(0);
	line(x1,y1,x2,y1);
	line(x1,y1,x1,y2);
	setcolor(WHITE);
	line(x1,y2,x2,y2);
	line(x2,y1,x2,y2);
	return 0;
}
/*objects and events*/
click(int x1,int y1,int x2,int y2,char s[30])
{
	int b,x,y;
	int t1,t2,k=0,i,j;
	setlinestyle(0,1,1);
	for(i=0;i<strlen(s);i++)
		k=k+4;
	t1=(x2-x1)/2+x1-k;
	t2=(y2-y1)/2+y1;
	getmstat(&b,&x,&y);
	if( (x>x1 && x<x2) && (y>y1 && y<y2) && b==1)
	{
		hidemp();
		press(x1,y1,x2,y2);
		setcolor(0);
		settextstyle(0,0,0);
		outtextxy(t1+2,t2+2,s);
		showmp();
		while((b==1))
			getmstat(&b,&x,&y);
		hidemp();
		unpress(x1,y1,x2,y2);
		settextstyle(0,0,0);
		outtextxy(t1,t2,s);
		for(i=50;i<500;i=i+50)
		{
			delay(10);
			sound(i+200);
		}
		showmp();
		nosound();
		return 0;
	}
	else return 1;
}
help()
{
	win(120,100,500,400);
	tbox(130,145,490,360);
	setcolor(0);
	settextstyle(0,0,0);

	outtextxy(140,180,"      Welcome to online help");
	outtextxy(140,210,"This is my biggest time pass beleive");
	outtextxy(140,230,"me i am not that bad programmer");
	outtextxy(140,250,"I hope u dont need any help to play");
	outtextxy(140,270,"the game .About virus it is really not");
	outtextxy(140,290,"harming any hardware part but in its next");
	outtextxy(140,310,"version it will defintely.You will be able");
	outtextxy(140,330,"to program the game in this package");
	outtextxy(140,350,"JUST WAIT FOR NEXT VERSION....");

	button(280,370,330,390,"Close");
	return 0;
}
tbox(int x1,int y1,int x2,int y2)
{
	setlinestyle(0,1,1);
	setfillstyle(1,WHITE);
	bar(x1,y1,x2,y2);
	setcolor(0);
	line(x1,y1,x2,y1);
	line(x1,y1,x1,y2);
	setcolor(WHITE);
	line(x1,y2,x2,y2);
	line(x2,y1,x2,y2);
	return 0;
}

