#include "game.h"
int x1=10,y1=200,x2,y2;
int x11=610,y11,x22=623,y22;
int c=0,d=20,cnt=10,ct=0,snd=300;
main()
{
	int gd=0,gm;initgraph(&gd,&gm,"c:\\tc\\bgi");
	m();showmp();
	initial();
}
initial()
{
	a1:hidemp();
	setbkcolor(0);
	win(120,100,500,400);
	outtextxy(200,200,"WELCOME TO THIS SMALL PROGRAM");
	outtextxy(200,230," YOU HAVE TO OPTIONS IS THIS ");
	outtextxy(200,260,"        VIRUS OR GAME        ");
	outtextxy(200,290,"     SELECT YOUR CHOICE      ");
	button(200,350,280,390,"VIRUS");
	button(300,350,380,390,"GAME");
	button(480,103,495,118,"X");
	button(460,103,475,118,"?");
	showmp();
	while(1)
	{
//			button(200,350,280,390,"VIRUS");
		if(click(300,350,380,390,"GAME")==0)
		{
			hidemp();
			game();
			clearviewport();
			goto a1;
		}
		if(click(480,103,495,118,"X")==0)
		{
			closegraph();
			nosound();
			exit(0);
		}
		if(click(200,350,280,390,"VIRUS")==0)
		{
			virus();
		}
		if(click(460,103,475,118,"?")==0)
		{
			help1();
			goto a1;
		}
	}
}
game()
{
	clearviewport();
	hidemp();
	while(1)
	{
		if(ball()==0) return 0;
		racket();
		if(ct>1)
		{
			ct=0;
			d=d-2;
			if(d<1)
			{
				nosound();
				clearviewport();
				outtextxy(200,200,"CONGRATULATION YOH WON THE GAME");
				exit(0);
			}
		}

	}
}
ball()
{
	int tp;
	if(c==0)
	{
		newimg(x1,y1);
		delay(d);
		snd=snd+5;
//		sound(snd);
		rem(x1,y1);
		if(x1<=590)
		{
			x1=x1+cnt;
		}
		else
		{
			if(check()==0)
				c=1;
			else
				return 0;
		}
	}
	if(c==1)
	{
		newimg(x1,y1);
		delay(d);
		snd=snd-5;
//		sound(snd);
		rem(x1,y1);
		if(x1>10)
			x1=x1-cnt;
		else
		{
			c=0;x1=10;
			while(1)
			{
				tp=random(600);
				if(tp>10)
					if(tp<470)
						if(tp!=y1)
							break;
			}
			y1=tp;
		}
	}
}
newimg(int x1,int y1)
{
	setcolor(WHITE);
	setfillstyle(1,2);
	fillellipse(x1,y1,10,10);
}
rem(int x1,int y1)
{
	setfillstyle(1,0);
	bar(x1-10,y1-10,x1+10,y1+10);
}

racket()
{
	int b,x,y;
	getmstat(&b,&x,&y);
	if(y11!=y)
	{
		normal(x11,y11);
		y11=y;
		setfillstyle(1,WHITE);
		bar(x11,y11,x22,y11+40);
	}
}
normal(int x11,int y11)
{
	x22=x11+12;y22=y11+40;
	setfillstyle(1,0);
	bar(x11,y11,x22,y22);
	return 0;
}
check()
{
	if(y1>y11 && y1< y22)
	{

		sound(500);
		delay(7);
		nosound();
		ct=ct+1;
		return 0;
	}
	 else
	 {
		clearviewport();
		nosound();
		win(200,200,350,300);
		outtextxy(220,230,"SORRY U LOST");
		button(220,260,270,290,"QUIT");
		button(280,260,330,290,"AGAIN");
		m();
		showmp();
		while(1)
		{
			showmp();
			if(click(220,260,270,290,"QUIT")==0)
			{
				clearviewport();
				return 1;
			}
			if(click(280,260,330,290,"AGAIN")==0)
			{
				hidemp();
				clearviewport();
//				d=20;
				return 0;
			}
		}
	 }
}
virus()
{
	int i;
	setcolor(WHITE);
	outtextxy(50,50,"SORRY YOUR MOUSE IS BURNT BY THIS SOFTWARE BUY ANOTHER ONE");
	for(i=0;i<480;i++)
	{
		delay(3);
		changemp(320,i);
	}
	for(i=640;i>0;i--)
	{
		delay(3);
		changemp(i,240);
	}
	for(i=640;i>0;i--)
	{
		delay(3);
		changemp(i,i);
	}
	for(i=0;i<640;i++)
	{
		delay(3);
		changemp(i,i);
	}
	outtextxy(50,70,"JUST A BAD JOKE");
}
help1()
{
	hidemp();
	clearviewport();
	help();
	showmp();
	while(1)
	{
		if(click(280,370,330,390,"Close")==0)
		{
			clearviewport();
			return 0;
		}
	}
}