/*	UTIL.C:	Utility functions for MicroSPELL 2.0
		Spell Checker and Corrector

		(C)opyright May 1991 by Daniel Lawrence
		All Rights Reserved
*/

#include	<stdio.h>
#include	"dopt.h"
#include	"dstruct.h"
#include	"ddef.h"

init_lcase()

{
	register int index;

	/* init the lower case table */
	for (index = 0; index < 128; index ++)
		if ('A' <= index && index <= 'Z')
			lcase[index] = index - 'A' + 'a';
		else
			lcase[index] = index;
}

/* compare 2 strings, ignore the case of the first character */

int lowcmp(s1, s2)

char *s1;
char *s2;

{
#ifdef OLD_VERSION
	register int result;

	result = 0;
	while ((result == 0) && (*s1 || *s2))
		result = lcase[*s1++] - lcase[*s2++];

	return(result);
#else
#if	0
	while ((lcase[*s1] == lcase[*s2]) && (*s1 != 0)) {
		s1++;
		s2++;
	}
	return (lcase[*s1] - lcase[*s2]);
#else
	while (((*s1 == *s2) || (lcase[*s1] == lcase[*s2])) && (*s1 != 0)) {
		s1++;
		s2++;
	}
	return (lcase[*s1] - lcase[*s2]);
#endif
#endif
}
