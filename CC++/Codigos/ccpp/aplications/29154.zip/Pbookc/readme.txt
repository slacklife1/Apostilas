Pbookc Readme V1.0
========================================================================================================
Pbookc (A Phone Book created using C, containing Full Name, Home, Work & Mobile Numbers as data fields)
Copyright � 2003 <Sumit J Vele>


Program Utility:-
=================
Pbookc is a program created in C,to create & manage a Phone Book.
It is accompanied with data fields such as Full Name, Home, Work & Mobile Number.
Entries can be easily modified, searched & can be viewed line-by-line.
Other data fields can be conviently added, by some minor adjustments in the source-Code.
Source-Code is not provided with installation; but it is encoded in HTML format in "Pbookc.htm"(Provided with Installation)


Author:- 
========
Sumit J Vele <sumit0110@hotmail.com>


Compiler:- 
==========
Turbo C Version 2.01


Testing:-
=========
The program was tested successfully on Intel Celeron machine with Windows98 SE.


Disclaimer:-
============
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


Installation:-
==============
Just Unzip the .ZiP file and just click on Executable file.


Uninstallation:-
================
Just delete the unzipped folder.


Response:-
==========
Your response is highly appreciated.
Your comments, suggestions & questions are most awaited;
      Contact :- Sumit J Vele <sumit0110@hotmail.com>



Files included:-
================
readme.txt/*read first*/
gpl.txt /*GNU General Public Licence*/
Pbookc.exe /*Executable file*/
Pbookc.htm /*Source code file(HTML)*/
NBT.jpg  /*logo file*/

===========================================================================================================