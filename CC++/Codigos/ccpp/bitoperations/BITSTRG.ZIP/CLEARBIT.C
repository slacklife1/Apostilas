/*
	librairie : bitstrg

	clearbit --	mise a 0l d'un bit

*/

#include "bitstrg.h"

/*
	Clear specified bit

	if bit > map size, 0 is returned, else 1 is returned
*/

unsigned clearbit(ptr,bit)
	struct SPARRAY * ptr;		/* pointer on structure */
	unsigned	bit;			/* bit number */
{

	if(ptr->numlbit < bit) {
		return(0);
	}

		/* AND original with 0 */

	(ptr->pntarray)[bit / SIZE] &= ~(1 << (bit & (SIZE - 1)));	
	return(1);
}
