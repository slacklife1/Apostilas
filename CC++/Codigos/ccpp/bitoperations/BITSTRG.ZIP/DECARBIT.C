/*
	librairie : bitstrg

	decarbit -- declaration d'un champ memoire comme etant un champ de bits
*/

/*
#define debug
*/

/* standard include */

#include <stdio.h>

#include "bitstrg.h"

/*
	 declaration of a memory field as an array of bit

	return a pointer on the array parameters structure or NULL if problem
*/

struct SPARRAY* decarbit(ptr,nombr)
	ELEBAR*		ptr;		/* pointer on the memory field */
	unsigned	nombr;		/* number of elements in the field */
{

	struct SPARRAY* pnt;
 
	if(nombr == 0) {
		return(NULL);
	}
	if((pnt = (struct SPARRAY *) calloc (1,sizeof(struct SPARRAY))) != NULL) {
		pnt->pntarray = ptr;
		pnt->numlbit = (nombr * SIZE) - 1;
	}
	return(pnt);
}
