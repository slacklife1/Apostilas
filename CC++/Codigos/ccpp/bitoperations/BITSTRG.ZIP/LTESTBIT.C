/*
	librairie : bitstrg

	ltestbit --	test l'etat d'un bit


				Le parametre nombre de bits est de type unsigned long

	Attention : en Small Memory Model le champ Data est limite a 64Koctets
*/

#include "bitstrg.h"

/*
	Test specified bit

	return non zero if set, else return zero
*/

unsigned ltestbit(ptr,bit)
	struct LSPARRAY * ptr;		/* pointer on structure */
	unsigned long	bit;		/* bit number */
{

	if(ptr->numlbit < bit) {
		return(0);
	}
	
	return((ptr->pntarray)[bit / SIZE] & (1 << (bit & (SIZE - 1))));	
}
