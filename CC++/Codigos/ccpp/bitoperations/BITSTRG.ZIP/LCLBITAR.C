/*
	librairie : bitstrg

	lclrbitarray --	initialisation a 0 d'un champ de bits


				Le parametre nombre de bits est de type unsigned long

	Attention : en Small Memory Model le champ Data est limite a 64Koctets
*/


#include "bitstrg.h"

/*
	Clear bit array to all 0s
*/

void lclrbitarray(ptr)
	struct LSPARRAY * ptr;		/* pointer on structure */
{

	unsigned	ind;

	ELEBAR*		ptrbit;

	ind = (((long)ptr->numlbit + 1) / SIZE)
			 + ((((long)ptr->numlbit + 1) & (SIZE - 1)) ? 1 : 0);
 	for (ptrbit = ptr -> pntarray ;ind > 0;--ind,++ptrbit) {
		*ptrbit ^= *ptrbit;		/* exclusive-OR */
	}
}
