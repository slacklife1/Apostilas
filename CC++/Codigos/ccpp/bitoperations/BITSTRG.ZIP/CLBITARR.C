/*
	librairie : bitstrg

	clrbitarray --	initialisation a 0 d'un champ de bits

*/

#include "bitstrg.h"

/*
	Clear bit array to all 0s
*/

void clrbitarray(ptr)
	struct SPARRAY * ptr;		/* pointer on structure */
{

	unsigned	ind;

	ELEBAR*		ptrbit;

	ind = (((long)ptr->numlbit + 1) / SIZE)
			 + ((((long)ptr->numlbit + 1) & (SIZE - 1)) ? 1 : 0);
 	for (ptrbit = ptr -> pntarray ;ind > 0;--ind,++ptrbit) {
		*ptrbit ^= *ptrbit;		/* exclusive-OR */
	}
}
