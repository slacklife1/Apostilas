/*
	librairie : bitstrg

	freebitarray --	restitution memoire d'un champ de bits

*/

#include "bitstrg.h"

/*
	Restitution of the memory space of an array of bit
*/

void freebitarray(ptr)
	struct SPARRAY * ptr;		/* pointer on structure */
{

	free(ptr->pntarray);
	free(ptr);
}
