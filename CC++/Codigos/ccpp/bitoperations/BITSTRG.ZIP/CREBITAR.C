/*
	librairie : bitstrg

	crebitarray -- allocation memoire pour champ de bits
*/

#include <stdio.h>
#include "bitstrg.h"

/*
	Creation of an array of bit

	The array is initialized to all 0s
	return a pointer on the array parameters structure or NULL if problem
*/

struct SPARRAY* crebitarray(nbbit)
	unsigned nbbit;			/* number of the last bit in the array */
{
	unsigned value;			/* number of element in array */

	struct SPARRAY* pnt;
 
	value = (((long)nbbit+1) / SIZE )
		 + ((((long)nbbit+1) & (SIZE - 1)) ? 1 : 0);

	if((pnt = (struct SPARRAY *) calloc (1,sizeof(struct SPARRAY))) != NULL) {
		if((pnt->pntarray = (ELEBAR*) calloc(value,sizeof(ELEBAR))) == NULL) {
			free(pnt);
			return(NULL);
		}
		pnt->numlbit = nbbit;
	}
	return(pnt);
}
