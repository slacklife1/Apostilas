/*
	librairie : bitstrg

	testbit --	test l'etat d'un bit

*/

#include "bitstrg.h"

/*
	Test specified bit

	return non zero if set, else return zero
*/

unsigned testbit(ptr,bit)
	struct SPARRAY * ptr;		/* pointer on structure */
	unsigned	bit;			/* bit number */
{

	if(ptr->numlbit < bit) {
		return(0);
	}
	
	return((ptr->pntarray)[bit / SIZE] & (1 << (bit & (SIZE - 1))));	
}
