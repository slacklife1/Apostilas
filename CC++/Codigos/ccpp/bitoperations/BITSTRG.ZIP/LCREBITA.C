/*
	librairie : bitstrg

	lcrebitarray -- allocation memoire pour champ de bits

					Le parametre nombre de bits est de type unsigned long

	Attention : en Small Memory Model le champ Data est limite a 64Koctets
*/

#include <stdio.h>
#include "bitstrg.h"

/*
	Creation of an array of bit

	The array is initialized to all 0s
	return a pointer on the array parameters structure or NULL if problem
*/

struct LSPARRAY* lcrebitarray(nbbit)
	unsigned long	 nbbit;		/* number of the last bit in the array */
{
	unsigned value;			/* number of element in array */

	struct LSPARRAY* pnt;
 
	value = (((long)nbbit+1) / SIZE )
		 + ((((long)nbbit+1) & (SIZE - 1)) ? 1 : 0);

	if((pnt = (struct LSPARRAY *) calloc (1,sizeof(struct LSPARRAY))) != NULL) {
		if((pnt->pntarray = (ELEBAR*) calloc(value,sizeof(ELEBAR))) == NULL) {
			free(pnt);
			return(NULL);
		}
		pnt->numlbit = nbbit;
	}
	return(pnt);
}
