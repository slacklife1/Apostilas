/*
	librairie : bitstrg

	lfreebitarray --	restitution memoire d'un champ de bits


					Le parametre nombre de bits est de type unsigned long

	Attention : en Small Memory Model le champ Data est limite a 64Koctets
*/

#include <local\bitstrg.h>

/*
	Restitution of the memory space of an array of bit
*/

void lfreebitarray(ptr)
	struct LSPARRAY * ptr;		/* pointer on structure */
{

	free(ptr->pntarray);
	free(ptr);
}
