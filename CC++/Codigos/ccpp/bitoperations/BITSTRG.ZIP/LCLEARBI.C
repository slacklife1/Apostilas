/*
	librairie : bitstrg

	lclearbit --	mise a 0l d'un bit

					Le parametre nombre de bits est de type unsigned long

	Attention : en Small Memory Model le champ Data est limite a 64Koctets

*/

#include "bitstrg.h"

/*
	Clear specified bit

	if bit > map size, 0 is returned, else 1 is returned
*/

unsigned lclearbit(ptr,bit)
	struct LSPARRAY * ptr;		/* pointer on structure */
	unsigned long	bit;		/* bit number */
{

	if(ptr->numlbit < bit) {
		return(0);
	}

		/* AND original with 0 */

	(ptr->pntarray)[bit / SIZE] &= ~(1 << (bit & (SIZE - 1)));	
	return(1);
}
