/*
	librairie : bitstrg

	invertbit --	inversion de l'etat d'un bit

*/

#include "bitstrg.h"

/*
	invert state of specified bit

	if bit > map size, 0 is returned, else 1 is returned
*/

unsigned invertbit(ptr,bit)
	struct SPARRAY * ptr;		/* pointer on structure */
	unsigned	bit;			/* bit number */
{

	if(ptr->numlbit < bit) {
		return(0);
	}

		/* XOR original with 1 */

	(ptr->pntarray)[bit / SIZE] ^= (1 << (bit & (SIZE - 1)));	
	return(1);
}
