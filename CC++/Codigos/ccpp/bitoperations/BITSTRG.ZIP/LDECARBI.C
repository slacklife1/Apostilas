/*
	librairie : bitstrg

	ldecarbit -- declaration d'un champ memoire comme etant un champ de bits

					Le parametre nombre de bits est de type unsigned long

	Attention : en Small Memory Model le champ Data est limite a 64Koctets
*/

/*
#define debug
*/

/* standard include */

#include <stdio.h>

#include "bitstrg.h"

/*
	 declaration of a memory field as an array of bit

	return a pointer on the array parameters structure or NULL if problem
*/

struct LSPARRAY* ldecarbit(ptr,nombr)
	ELEBAR*		ptr;		/* pointer on the memory field */
	unsigned	nombr;		/* number of elements in the field */
{

	struct LSPARRAY* pnt;
 
	if(nombr == 0) {
		return(NULL);
	}
	if((pnt = (struct LSPARRAY *) calloc (1,sizeof(struct LSPARRAY))) != NULL) {
		pnt->pntarray = ptr;
		pnt->numlbit = (nombr * SIZE) - 1;
	}
	return(pnt);
}
