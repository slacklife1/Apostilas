/*INVERT.C  v1.0
This program replaces n bits from the position p of the bit
representation of an inputted character x with the one's complement
Reference:The C Programming Language K&REx:2-7
Deepak  deepak-p@eth.net
Computer Engg: Student,Kerala,India*/

# include "showbits.h"
/*# include <stdio.h>   Include if necessary*/
unsigned char invert(unsigned char x,int p,int n)
{
	unsigned char a,b;
	a=((~0)<<(9-p-n))&(~((~0)<<(9-p)));
	a=~a;
	b=x&(~a);
	b=~b;
	b=b&(~a);
	x=x&a;
	x=x|b;
	return x;
}
main()
{
	unsigned char x;
	unsigned int p,n;
	clrscr();
	printf("\nThis program takes a character x and two integers n & p");
	printf("\nboth less than 8.It then replaces n bits from position");
	printf("\np in x with their one's complement.i.e.,1 to 0 and vice");
	printf("\nversa.This replaces character is output as new x.");
	printf("\nRef:Ex:2-7 The C Programming Language K&R 2e/d Page 49");
	printf("\nDeepak  deepak-p@eth.net    Kerala,India\n");
	printf("\nEnter x:");scanf("%c",&x);//fflush(sdtin);
	printf("\nEnter p:");scanf("%d",&p);
	printf("\nEnter n:");scanf("%d",&n);
	if((p+n)>9)
	{
		clrscr();
		printf("\nImpossible operation.Aborting");
		return 1;
	}
	clrscr();
	printf("\nBit representations\n");
	printf("\nx:");showbits(x);
	printf("\np:%d",p);
	printf("\nn:%d",n);
	printf("\nNew x:");showbits(invert(x,p,n));
	printf("\n\nCharacter representations");
	printf("\nx:%c",x);
	printf("\nnew x:%c",invert(x,p,n));
	printf("\n\nPress a key...");
	getch();
	return 0;
}