/*
	MikDLL - Done by MikMak / HaRDCoDE '95
*/
#include <stdio.h>
#include <stdlib.h>
#include <alloc.h>
#include <string.h>
#include "mdllload.h"

void (*Child)(void);


void huge xputs(char *s)
/*
	This function will be used by the child MDLL
	to print the hello world message.
*/
{
	puts(s);
}



int main(void)
{
	MDLL ovl;

	// export the xputs() function:

	MDLL_Export("xputs()",xputs);

	// load & bind the child MDLL

	if(!MDLL_Bind(&ovl,"CHILD.EXE")){
		printf("Error loading MDLL: %s\n",MDLL_Error());
		return 0;
	}

	// import the function 'Child()' from child.exe

	Child=MDLL_Import("Child()");

	// print parent message

	xputs("Hello world from PARENT.EXE");

	// print child message using the imported function

	Child();

	MDLL_Unbind(&ovl);
	return 1;
}
