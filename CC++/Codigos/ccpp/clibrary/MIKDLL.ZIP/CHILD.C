/*
	MikDLL - Done by MikMak / HaRDCoDE '95
*/
#include <stdio.h>
#include "mdllload.h"

void (*xputs)(char *s);


void huge Child(void)
/*
	This function will be called from the parent program.
*/
{
	xputs("Hello world from CHILD.EXE");
}


void huge entry(void *(*MDLL_Import)(char *name) ,
				void (*MDLL_Export)(char *name,void *obj))
/*
	This is the entry function where the MDLL has to import & export the
	external objects. This function will be called from the MDLL loader.
*/
{
	xputs=MDLL_Import("xputs()");
	MDLL_Export("Child()",Child);
}


// The tag used by the MDLL loader to access the 'entry' function:

TAG t={
	"MDLLTAG0",
	entry
};


void main(void)
/*
	This is a dummy main that just prints a stoopid message when
	a stoopid user tries to execute the MDLL
*/
{
	puts("This is a MDLL and cannot be executed.");
}
