#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

struct list{
     char item;
     struct list *link;
     };
typedef struct list x;
x *stack,*temp=NULL;


push(char data)     /* pushes characters to stack */
{
 stack=(x *)malloc(sizeof(x));
 stack->item=data;
 stack->link=temp;
 temp=stack;
}

pop()          /* pops characters from stack */
{
 x *t;
 while(temp!=NULL)
  {
   printf("%c",temp->item);
   t=temp;
   temp=temp->link;
   free(t);              /* deallocate allocated memory */
  }
 printf(" ");
 temp=NULL;
}



main()
{
 int i;
 char string[30];
 clrscr();
 printf("\nReverser 1.0");
 printf("\nThis reverses a sentence word by word making use of stacks\n\n");
 printf("Enter the sentence :");
 gets(string);
 i=0;
 printf("The reverse is :");
 while(string[i]!='\0')
 {
  if(isspace(string[i])!=0)   /* if space is encountered */
   pop();
  else
   push(string[i]);
  i++;
 }
 pop();
}