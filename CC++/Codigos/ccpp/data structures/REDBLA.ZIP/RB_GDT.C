/*: RB_GDT.C	 Threaded RedBlack Tree Library   Version 1.51	8-feb-93
 *
 *: Prototype: void *rb_getdata(RB_treeptr, RB_nodeptr, void *buffer)
 *: Purpose:   Copy data from existing node to buffer. Returns pointer to buffer
 *
 *  RELEASED TO THE PUBLIC DOMAIN
 *
 *		 author:    Bert C. Hughes
 *			    200 N.Saratoga
 *			    St.Paul, MN 55104
 *			    Compuserve 71211,577
 */

#include "redblack.h"

void *rb_getdata(RB_treeptr tree, RB_nodeptr p, void *buffer)
{
    return (*tree->copy_item)(buffer, p->dataptr);
}
