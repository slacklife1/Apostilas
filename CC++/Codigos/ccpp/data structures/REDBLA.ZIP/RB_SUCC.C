/*: RB_SUCC.C	 Threaded RedBlack Tree Library   Version 1.51	8-feb-93
 *
 *: Prototype: RB_nodeptr rb_succ(RB_nodeptr p)
 *: Purpose:   Return in-order successor of "p"
 *
 *  RELEASED TO THE PUBLIC DOMAIN
 *
 *	       author:	    Bert C. Hughes
 *			    200 N.Saratoga
 *			    St.Paul, MN 55104
 *			    Compuserve 71211,577
 */

#include "redblack.h"
#include "rb_priv.h"

RB_nodeptr rb_succ(RB_nodeptr p)
{
    register RB_nodeptr q;

    if (!p)
	return NULL;

    q = p->Rptr;

    if (RLINK(p))
	while (LLINK(q))
	    q = q->Lptr;

    return (Is_Head(q) ? NULL : q);
}
