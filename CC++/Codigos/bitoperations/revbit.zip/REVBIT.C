/* program to reverse the bits in a byte */
/* programmed by Sandeep.P */

#include <stdio.h>

power(int x)    /* gets value of(2^x) */
{
 int y=1,i;
 for(i=0;i<x;i++)
   y=y*2;
 return y;
}

unsigned char reverse(char x)       /* reverse bits in a byte */
{
 unsigned char t=0;
 unsigned char a=0;
 int i;
 for(i=0;i<8;i++)
 {
  t=x & (char)power(i);
  if(t!=0)
   a|=(char)power(7-i);
 }
 return a;
}

main()
{
 unsigned char c;
 clrscr();
 printf("\nRevBit 1.0 \nReverses the bit sequence of an inputted character\nBy Sandeep <sandeep_potty@yahoo.com>");
 printf("\n\n\nEnter the character whose bits are to be reversed :");
 scanf("%u",&c);
 printf("\nResult after reversing bits : %u",reverse(c));
}
