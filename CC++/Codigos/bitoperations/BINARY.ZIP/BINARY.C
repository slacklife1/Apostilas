#include <stdio.h>
#include <stdlib.h>

void main( int argc, char *argv[] )
{
	int arg1, x;

	if( argc == 1 )
		{
		puts( "BINARY num = displays num in binary form." );
		exit( 1 );
		}

	arg1 = atoi( argv[1] );
	printf( "INTEGER: %i\n", arg1 );
	printf( "    HEX: %x\n", arg1 );
	printf( " BINARY:" );
	for( x = 15; x > 7; x-- )
		printf( " %i ", (arg1 & 1 << x ) > 0 ? 1 : 0 );

	printf( "  " );

	for( x = 7; x > -1; x-- )
		printf( " %i ", (arg1 & 1 << x ) > 0 ? 1 : 0 );

	puts( "" );
	puts( " 16 bit:15 14 13 12 11 10  9  8    7  6  5  4  3  2  1  0" );
	puts( "  8 bit: 7  6  5  4  3  2  1  0    7  6  5  4  3  2  1  0" );
	puts( "    Hex: |----4---|  |----3---|    |----2---|  |----1---|" );
	puts( "    Sum: 3  1                                            " );
	puts( "         2  6  8  4  2  1                                " );
	puts( "         7  3  1  0  0  0  5  2    1                     " );
	puts( "         6  8  9  9  4  2  1  5    2  6  3  1            " );
	puts( "         8  4  2  6  8  4  2  6    8  4  2  6  8  4  2  1" );
	exit( 0 );
}
