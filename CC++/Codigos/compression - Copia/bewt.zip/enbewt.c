/*
BeWT Encoder
Sandeep <sandeep_potty@yahoo.com>
Deepak <deepak-p@eth.net>
http://www.geocities.com/acmesofties/
07-May-2002
*/

# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include "mtf.c"

# define MAX 20480 //Edit this value for changing block size of BWT
# define TEMP "temp.dat"

int a[2*MAX],n;
int b[MAX];
int eof;

//calling the memcmp() function for comparison
int compare(int i,int j)
{
	return memcmp((void*)(a+i),(void*)(a+j),n);
}

//The comparing function to be supplied as parameter
//to qsort call
int qsort_compare(void *a,void *b)
{
	int *c,*d;
	c=a;d=b;
	return compare(*c,*d);
}

//custom bubble sort:very very slow
void bubble_sort()
{
	int j,temp,i;
	for(i=0;i<n;i++)
	{
		for(j=(i+1);j<(n);j++)
		{
			if(compare(b[i],b[j])>0)
			{
				temp=b[i];
				b[i]=b[j];
				b[j]=temp;
			}
		}
	}
	return;
}

//getting primary index
int get_primary_index()
{
	int i;
	for(i=0;i<n;i++)
	{
		if(compare(b[i],1)==0)
			return i;
	}
	return 0;
}

//reading chunks of data from file
void readchunk(FILE *in)
{
	int i=0,ch;
	printf("*");
	while(i<MAX)
	{
		ch=fgetc(in);
		if(ch==EOF)
		{
			eof=1;
			break;
		}
		a[i]=ch;
		i++;
	}
	n=i;
	for(i=0;i<n;i++)
	{
		a[i+n]=a[i];
	}
	for(i=0;i<n;i++)b[i]=i;//initializing the b array
	return;
}

//writing chunks of data from b to output file
void writechunk(FILE *out)
{
	int i;
	for(i=0;i<n;i++)
	{
		fputc(a[b[i]+(n-1)],out);
	}
	return;
}

//the encoding function encodes in to out.
//both file pointers are to be supplied rewound
void bwtencode(FILE *in,FILE *out)
{
	int i=0;
	int primary_index;
	while(eof!=1)
	{
		readchunk(in);
		if(n==0)break;
		//bubble_sort();
		qsort((void *)b,(size_t)n,(size_t)sizeof(int),qsort_compare);
		primary_index=get_primary_index();
		writechunk(out);
		fwrite(&primary_index,sizeof(int),1,out);
	}
	return;
}

//The one that cannot be left out the main() atlast!!!
void main()
{
	char infile[100],outfile[100];
	FILE *in,*out;
	printf("\n\nBeWT BWT and MTF Encoder 1.0");
	printf("\n\nBy \nDeepak <deepak-p@eth.net> &");
	printf("\nSandeep <sandeep_potty@yahoo.com>");
	printf("\nhttp://www.geocities.com/acmesofties/");
	printf("\nRelease date:7-May-2002\n");
	printf("\nEnter input file:");scanf("%s",infile);
	printf("\nEnter output file:");scanf("%s",outfile);
	printf("\n\nBWT encoding starts...");
	in=fopen(infile,"rb");
	out=fopen(TEMP,"wb");
	if(in==NULL || out==NULL)
	{
		printf("\nFile I/O error");
		fcloseall();
	}
	bwtencode(in,out);
	fclose(in);
	fclose(out);
	printf("   done");
	printf("\nMTF Encoding starts...");
	mtfencode(TEMP,outfile);
	printf("done");
	remove(TEMP);
	printf("\nSuccessfully completed operation");
	return;
}