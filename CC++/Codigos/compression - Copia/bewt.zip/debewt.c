/*
BeWT Decoder
for decoding files encoded with
BeWT encoder.
Sandeep <sandeep_potty@yahoo.com>
Deepak <deepak-p@eth.net>
http://www.geocities.com/acmesofties/
07-May-2002
*/

# include <stdlib.h>
# include <stdio.h>
# include "unmtf.c"

# define TEMP "temp.dat"

# define MAX 20480  //Edit this value for changing blocksize of BWT

int a[MAX],n;
int b[MAX],af[MAX];
int vector[MAX];
int primary_index;

int eof=0;

void readchunk(FILE *in)
{
	int i=0,ch;
	printf(".");
	while(i<MAX)
	{
		ch=fgetc(in);
		if(ch==EOF)
		{
			eof=1;
			break;
		}
		a[i]=ch;
		i++;
	}
	n=i;
	for(i=0;i<n;i++)b[i]=a[i];//initializing the b array
	return;
}

int qsort_compare(void *a,void *b)
{
	int *c,*d;
	c=(int *)a;d=(int *)b;
	return (*c)-(*d);
}

void sortb()
{
	int i;
	qsort(b,(size_t)n,(size_t)sizeof(int),qsort_compare);
	for(i=0;i<n;i++)af[i]=0;
}

void makevector()
{
	int i,j;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			if(a[j]==b[i] && af[j]==0)
			{
				vector[i]=j;
				af[j]=1;
				break;
			}
		}
	}
	return;
}

void decode_from_vector(FILE *out)
{
	int i;
	int index=primary_index;
	for(i=0;i<n;i++)
	{
		fputc(a[index],out);
		index=vector[index];
	}
	return;
}

void bwtdecode(FILE *in,FILE *out)
{
	while(eof!=1)
	{
		readchunk(in);
		if(eof==1)
		{
			fseek(in,(-1)*sizeof(int),SEEK_END);
			n-=sizeof(int);
		}
		fread(&primary_index,sizeof(int),1,in);
		sortb();
		makevector();
		decode_from_vector(out);
	}
	return;
}

void main()
{
	char infile[100],outfile[100];
	FILE *in,*out;
	printf("\n\nBeWT BWT and MTF Decoder 1.0");
	printf("\n\nBy \nDeepak <deepak-p@eth.net> &");
	printf("\nSandeep <sandeep_potty@yahoo.com>");
	printf("\nhttp://www.geocities.com/acmesofties/");
	printf("\nRelease date:7-May-2002\n");
	printf("\nEnter input file:");scanf("%s",infile);
	printf("\nEnter output file:");scanf("%s",outfile);
	printf("\n\nMTF Decoding starts...");
	mtfdecode(infile,TEMP);
	printf("done");
	printf("\nBWT decoding starts");
	in=fopen(TEMP,"rb");
	out=fopen(outfile,"wb");
	if(in==NULL || out==NULL)
	{
		printf("\nFile I/O error");
		fcloseall();
	}
	bwtdecode(in,out);
	fclose(in);
	fclose(out);
	printf("done");
	remove(TEMP);
	printf("\nSuccessfully completed operation");
	return;
}


		

