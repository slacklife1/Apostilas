BeWT 1.0
========
Deepak <deepak-p@eth.net>
Sandeep <sandeep_potty@yahoo.com>
http://www.geocities.com/acmesofties/
07-May-2002

BeWT is a BWT and MTF encoder and
decoder package. BWT or the Burrows
Wheeler transform is applied on data
to make it more suitable for compression
using an entropy encoder like 
Huffman algorithm. The BeWT encoder
encodes the input file using BWT and 
further using MTF (move to front encoding)
to the output file.

Applying MTF makes BWT encoded data
more suitable for compression using an
entropy encoder.

The outputfile given by BeWT encoder
when compressed by the entropy encoder
should give far better results compared to
compressing the raw file using the same
entropy encoder.

The output file encoded using BeWT encoder
can be decoded using the BeWT decoder
provided with the package. The block size
for BWT encoding used is 20Kb but it can easily
be changed as it is # defined in the
files enbwt and debwt as MAX.

Sequence of operations for seeing
results of BWT and MTF encoding:
=================================

input file:in.dat

1.Encode in.dat to in.enc by BeWT encoder (enbewt.exe)
2.Compress in.enc to in.out using entropy encoder.
3.Compress in.dat to in.ent by entropy encoder.
 Compare sizes of in.out and in.ent

The file in.enc can be decoded to the same in.dat
by BeWT decoder (debewt.exe)

enbewt.exe and debewt.exe are executables generated
by compiling enbewt.c and debewt.c in VC++ compiler.

Note:
=====
A huffman encoder can be used as the entropy encoder.
HuffPack, a huffman encoder by the authors of BeWT
is available for download at
http://www.geocities.com/acmesofties/