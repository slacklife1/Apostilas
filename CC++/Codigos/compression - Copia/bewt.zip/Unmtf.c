/****MTF Decoder 1.0
Deepak <deepak-p@eth.net>
*/

# include <stdio.h>
# include <time.h>

/*Globals*/
int array[256];

void initarray()
{
	int i;
	for(i=0;i<256;i++)
	{
		array[i]=i;
	}
	return;
}

void move2front(int i)
{
	int j,temp=array[i];
	for(j=i;j>0;j--)
	{
		array[j]=array[j-1];
	}
	array[0]=temp;
	return;
}

int mtfdecode(char *infile,char *outfile)
{
	int ch;
	FILE *out,*in;
	initarray();
	in=fopen(infile,"rb");
	out=fopen(outfile,"wb");
	if(in==NULL || out==NULL){fclose(in);fclose(out);return 1;}
	while(ch=fgetc(in),ch!=EOF)
	{
		fputc(array[ch],out);
		move2front(ch);
	}
	fclose(in);
	fclose(out);
	return 0;
}
