/*FRECOUNT.C v1.0
This program lists the frequency table of the input file which is supplied as
a command line argument.The output is done to a file frecount.txt in the
working directory.This table is useful in preparation of Huffman trees for
file compression programs.This is distributed as open source and anybody
can make changes.Pleae do send me the changed versions.
Deepak   deepak-p@eth.net   Kerala,India
Computer Engg: Student*/
# include <stdio.h>
main(int argc,char *argv[])
{
	FILE *p1;
	char in[100];
	long int freq[257];
	int i;
	clrscr();
        printf("\nFrecount v1.0 - File frequency table generator\n\n");
	if(argc<2)
	{
		printf("\nInput file:");scanf("%s",in);
	}
	else strcpy(in,argv[1]);
	p1=fopen(in,"rb");
	if(p1==NULL)
	{
		printf("\nCould not open input file.Aborting");
		return 1;
	}
	for(i=0;i<257;i++)
		freq[i]=0;
	while(i=fgetc(p1),i!=EOF)
	{
		freq[i]++;
	}
	fcloseall();
	p1=fopen("frecount.txt","w");
	fprintf(p1,"\nCharacter frequency table of %s\n",in);
	fprintf(p1,"\nCharacter ASCII frequency\n\n");
	for(i=0;i<256;i++)
	{
		if(i==26)
		{
			fprintf(p1,"\t    26\t  %ld\n",freq[26]);
		}
		else if(i==9)
		{
			fprintf(p1,"\t    9\t  %ld",freq[9]);
		}
		else if(i<10)
		{
			fprintf(p1,"%c\t    %d\t  %ld\n",i,i,freq[i]);
		}
		else if(i<100)
		{
			fprintf(p1,"%c\t    %d\t  %ld\n",i,i,freq[i]);
		}
		else
		{
			fprintf(p1,"%c\t    %d\t  %ld\n",i,i,freq[i]);
		}
	}
	fprintf(p1,"\nEnd of table");
	fcloseall();
        printf("\nFrequency table copied to frecount.txt");
}



