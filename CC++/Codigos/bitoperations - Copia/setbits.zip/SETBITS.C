/*SETBITS.C v1.0
This program gets characters x & y from the user and prints out a character c
which is a copy of x with n bits from the pth position of x replaced with the
rightmost n bits of y.
Reference: The C Programming Language 2e/d Ex:2-6
Deepak    deepak-p@eth.net      Kerala,India
Computer Engg: Student     */

# include <stdio.h>
# include "showbits.h"
unsigned char setbits(unsigned char x,int p,int n,unsigned char y)
{
	unsigned char a,b;
	y=y<<(9-p-n);
	a=((~0)<<(9-p-n))&(~((~0)<<(9-p)));
	a=~a;
	b=x&a;
	a=~a;
	y=y&a;
	b=b|y;
	return b;
}
main()
{
	unsigned char x,y,c;
	int n,p;
	clrscr();
	printf("\nEnter two characters x and y and two integers p and n.");
	printf("\nThe function setbits in the program returns c which is a");
	printf("\ncopy of x with the n bits from pth position of x");
	printf("\nreplaced with the rightmost n bits of y leaving the");
	printf("\nother bits unchanged.");
	printf("\nRef:Ex:2-6 The C Programming Language K&R 2e/d Page 49");
	printf("\nDeepak    deepak-p@eth.net   Kerala,India\n");
	printf("\n\nInput x:");scanf("%c",&x);fflush(stdin);
	printf("\nInput y:");scanf("%c",&y);fflush(stdin);
	printf("\nInput p(<=8):");scanf("%d",&p);
	printf("\nInput n(>0 & <=8):");scanf("%d",&n);
	if((p+n)>9)
	{
		clrscr();
		printf("\nImpossible operation.Aborting");
		return 1;
	}
	clrscr();
	printf("\nBit representations\n");
	printf("\nx:");showbits(x);
	printf("\ny:");showbits(y);
	printf("\np:%d",p);
	printf("\nn:%d",n);
	c=setbits(x,p,n,y);
	printf("\nc:");showbits(c);
	printf("\n\nCharacter representations\n");
	printf("x:%c",x);
	printf("\nc:%c",c);
	printf("\n\nPress a key...");
	getch();
	return 0;
}
