/******************************************************************************
 *  Library to manage collections of nodes (lists, stack, queque...)
 *
 *  Written by Civera Estefan [19-04-2003]
 *
 *  Mail To: estefan.civera@email.it
 *
 * Copyright � 2003 Estefan Civera. All Rights Reserved.
 *
 * This code may be used in compiled form in any way you wish. This
 * file may be redistributed unmodified by any means PROVIDING it is
 * not sold for profit without the authors written consent, and
 * providing that this notice and the authors name is included. If the
 * source code is used in any commercial application then an email letting
 * me know that you are using it would be nice. However, this code may
 * not be sold as a part of any commercial library in compiled or source
 * form. In any other cases the code is free to whoever wants it anyway.

 * This software is provided "as is" without express or implied warranty.
 * Use it at you own risk! The author accepts no liability for any damages
 * to your computer or data this product may cause.
******************************************************************************/


#ifndef COLLECTION
#define COLLECTION

/******************************************************************************
 * Read from file  modality:
 * 		RdFHEAD     Add nodes on the head of the list
 *      RdFTAIL		Add nodes at the tail of the list
 *****************************************************************************/
typedef enum RDF{
                	RdFHEAD,
			        RdFTAIL
		        }RdF;

/******************************************************************************
 * Write on file  modality:
 * 		LdFWRAPPEND     Append data to the selected file
 *      LdFWRBEGIN      Overwrite the existing file
 *****************************************************************************/
typedef enum LDF{
			        LdFWRAPPEND,
    			    LdFWRBEGIN
	    	    }LdF;


/******************************************************************************
 * Node structure:
 * 		pNext       Pointer to the next node
 *      pValue      Pointer to the data
 *****************************************************************************/

typedef struct NODE
{
    struct  NODE*   pNext;
    void*   pValue;
};

/******************************************************************************
 * If C++ is not defined program define new boolean type called bool
 *****************************************************************************/
#ifndef _cplusplus
typedef enum BOOL{false, true}
             bool;
#endif

typedef struct NODE*   pNODE;
typedef struct NODE**  dpNODE;

#define EOL 0    /* stands for End Of List */

/******************************************************************************
/******************************************************************************
 *                              GENERAL FUNCTION                              *
 *            Common use for all type of collection (list, stack,tail)        *
 ******************************************************************************
 *****************************************************************************/


/******************************************************************************
 * 	This function sets to EOL the pointer given.
 *****************************************************************************/
void Init(dpNODE dpNode);


/******************************************************************************
 *  This function check if pNode is the last of the list.
 *  In case of success the function return 'true' else return 'false'
 *****************************************************************************/
bool IsEol(pNODE pNode);


/******************************************************************************
 *  Return the number of node starting from the node pointed by pNode
 *****************************************************************************/
unsigned long GetSize(pNODE pNode);


/******************************************************************************
 *  It store data onto the node
 *  pNode   is the pointer to the node where you want store data
 *  pBuffer is the buffer where is store the data to write on the node
 *  sSize   represent the size of the buffer (use sizeof to know the size of it)
 *  Return  The number of the bytes wrote
 *****************************************************************************/
size_t SetValue(pNODE pNode, void* pBuffer, size_t sSize);


/******************************************************************************
 *  GetValue get data from the node
 *  pNode   is the pointer to the node where you want get data
 *  pBuffer is the buffer where store the data of the node
 *  sSize   represent the size of the buffer (use sizeof to know the size of it)
 *  Return  The number of the bytes wrote
 *****************************************************************************/
size_t GetValue(pNODE pNode, void* pBuffer, size_t sSize);


/******************************************************************************
 *  Delete all nodes starting from pHead pointer
 *  pHead   is the pointer to the first node you want delete
 *  Return  The number of nodes deleted
 *****************************************************************************/
unsigned long DeleteAll(dpNODE dpNode);


/******************************************************************************
 *  Save collection starting from pPointer pointer.
 *  Filename    Pointer to the string that contens the path of the file
 *  Mode        Two possibility
 * 		        LdFWRAPPEND     Append data to the selected file
 *              LdFWRBEGIN      Overwrite the existing file
 *  pPointer    is the pointer to the first node you want save
 *  sSize       represent the size of the buffer (use sizeof to know the size
 *              of the buffer)
 *  Return      The number of nodes saved on the file
 *****************************************************************************/
unsigned long SaveCltnOnFile(char* Filename, LdF Mode, pNODE pPointer,
							 size_t sSize);


/******************************************************************************
 *  Read collection starting from pPointer pointer.
 *  Filename    Pointer to the string that contens the path of the file
 *  Mode        Two possibility
 *      		RdFHEAD     Add nodes at the head of the collection
 *              RdFTAIL		Add nodes at the tail of the collection
 *  dpHead      is the pointer to the first node of the collection
 *  dpTail      is the pointer to the last  node of the collection
 *  sSize       represent the size of the buffer (use sizeof to know the size
 *              of the buffer)
 *  Return      The number of nodes red from the file
 *****************************************************************************/
unsigned long LoadCltnFromFile(char* Filename, RdF Mode, dpNODE dpHead,
							   dpNODE pTail, size_t sSize);


/******************************************************************************
/******************************************************************************
 *                                  LIST FUNCTION                             *
 ******************************************************************************
 *****************************************************************************/

/******************************************************************************
 *  This function allows to add a new node on the head of the list.
 *  dpHead  is the pointer to the first node of the list
 *  pBuffer is the buffer where is store the data to save on the node
 *  sSize   represent the size of the buffer (use sizeof to know the size
 *          of the buffer)
 *  Return  'true' in case of success. In case of unsucces the function call
 *          assert macro. See assert() for more information
 *****************************************************************************/
bool AddHead(dpNODE dpHead, void* pBuffer, size_t sSize);


/******************************************************************************
 *  This function allows to add a new node on the tail of the list.
 *  dpHead  is the pointer to the first node of the list
 *  dpTail  is the pointer to the last node of the list
 *  pBuffer is the buffer where is store the data to save on the node
 *  sSize   represent the size of the buffer (use sizeof to know the size
 *          of the buffer)
 *  Return  'false' if the list was empty, in other case return 'true'.
 *          In case of unsucces the function calls assert macro. See assert()
 *          for more information
 *****************************************************************************/
bool AddTail(dpNODE dpHead, dpNODE dpTail, void* pBuffer, size_t sSize);


/******************************************************************************
 *  This function move the pointer give as paramter to the next nodes.
 *  If it is the last MoveNext return 'false', else return 'true'
 *****************************************************************************/
bool MoveNext(dpNODE dpNode);


/******************************************************************************
 *  Delete a node from the list
 *  dpHead  is the pointer to the head-node of the list
 *  dpDel   is the pointer to the node you want delete
 *  Return  'true' if the node deleted was the head of the list, 'false'
 *          in other case
 *****************************************************************************/
bool DeleteNode(dpNODE dpHead, dpNODE dpToDel);



/******************************************************************************
/******************************************************************************
 *                                 STACK FUNCTION                             *
 ******************************************************************************
 *****************************************************************************/


/******************************************************************************
 *  Insert a new item into the stack.
 *  dpHead  Pointer to the head of the stack
 *  pBuffer is the buffer where is store the data to save on the stack
 *  sSize   represent the size of the buffer (use sizeof to know the size
 *          of the buffer)
 *  Return  'true' in case of success. In case of unsucces the function call
 *          assert macro. See assert() for more information
 *  See AddHead() function
 *****************************************************************************/
bool Push(dpNODE dpHead, void* pBuffer, size_t sSize);


/******************************************************************************
 *  Extract the last item insert into the stack.
 *  dpHead  Pointer to the head of the stack
 *  pBuffer is the buffer where will store the data from the stack
 *  sSize   represent the size of the buffer (use sizeof to know the size
 *          of the buffer)
 *  Return  'true' in case of success. In case of unsucces the function call
 *          assert macro. See assert() for more information
 *****************************************************************************/
size_t Pop (dpNODE dpHead, void* pBuffer, size_t sSize);


/******************************************************************************
 *  Read the last item insert into the stack.
 *  pHead   Pointer to the head of the stack
 *  pBuffer is the buffer where will store the data from the stack
 *  sSize   represent the size of the buffer (use sizeof to know the size
 *          of the buffer)
 *  Return  'true' in case of success. In case of unsucces the function calls
 *          assert macro. See assert() for more information
 *****************************************************************************/
size_t Top (pNODE  pHead, void* pBuffer, size_t sSize);


/******************************************************************************
/******************************************************************************
 *                                 TAIL FUNCTION                              *
 ******************************************************************************
 *****************************************************************************/

/******************************************************************************
 *  Insert a new item into the tail.
 *  dpHead  Pointer to the first node of the tail
 *  dpTail  Pointer to the last node  of the tail
 *  pBuffer is the buffer where is stored data to save on the tail
 *  sSize   represent the size of the buffer (use sizeof to know the size of it)
 *  Return  'true' in case of success. In case of unsucces the function call
 *          assert macro. See assert() for more information
 *  See AddTail() function
 *****************************************************************************/
bool    Insert(dpNODE dpHead, dpNODE dpTail, void* pBuffer, size_t sSize);

/******************************************************************************
 *  Extract the first item insert into the Tail.
 *  dpHead  Pointer to the head of the tail
 *  pBuffer is the buffer where will store the data from the stack
 *  sSize   represent the size of the buffer (use sizeof to know the size of it)
 *  Return  'true' in case of success. In case of unsucces the function call
 *          assert macro. See assert() for more information
 *****************************************************************************/
size_t  Extract(dpNODE dpHead, void* pBuffer, size_t sSize);


/******************************************************************************
 *  Read the first item insert into the tail.
 *  pHead   Pointer to the head of the tail
 *  pBuffer is the buffer where will store the data from the stack
 *  sSize   represent the size of the buffer (use sizeof to know the size of it)
 *  Return  'true' in case of success. In case of unsucces the function calls
 *          assert macro. See assert() for more information
 *****************************************************************************/
size_t  First(pNODE pHead, void* pBuffer, size_t sSize);

/*****************************************************************************/
#endif
/*****************************************************************************/



