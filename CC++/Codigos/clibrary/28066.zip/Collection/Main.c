/******************************************************************************
 *  Example program to manage collections
 *
 *  Written by Civera Estefan 19-04-2003
 *
 *  Mail To: estefan.civera@studenti.unibg.it
 *
 *  Mail To: estefan.civera@email.it
 *
 * Copyright � 2003 Estefan Civera. All Rights Reserved.
 *
 * This code may be used in compiled form in any way you wish. This
 * file may be redistributed unmodified by any means PROVIDING it is
 * not sold for profit without the authors written consent, and
 * providing that this notice and the authors name is included. If the
 * source code is used in any commercial application then an email letting
 * me know that you are using it would be nice. However, this code may
 * not be sold as a part of any commercial library in compiled or source
 * form. In any other cases the code is free to whoever wants it anyway.

 * This software is provided "as is" without express or implied warranty.
 * Use it at you own risk! The author accepts no liability for any damages
 * to your computer or data this product may cause.
******************************************************************************/


#include <stdio.h>
#include <conio.h>
#include "dyn.h"

int main(int argc, char* argv[])
{
    int a,i=0;

    /* Nodes declaretions...*/
    /* I use three nodes
        Head -> It's the head of tle list
        Tail -> It's the tail of the list
        Current -> It's a temporaney pointer thats point to the current node.
    */
    pNODE   Head, Tail, Current;

    /* Nodes inizialization */
    Init(&Head);
    Init(&Tail);
    Init(&Current);

    /* Program loads from file other nodes. */
    LoadCltnFromFile("file.txt", RdFHEAD, &Head, &Tail, sizeof(int));

    /* Now program adds ten nodes */
    for(a=100; a< 110; a++)
        AddTail(&Head, &Tail,&a, sizeof(a));
         /*You can also use...*/
         /*AddHead(&Head, &a, sizeof(a));*/



    Current = Head;
    /* Current now points to the first node of the list*/

    /* I'm scrolling the list until I find the end.*/
    while(!IsEol(Current))
    {       i++;
        /* I extract the field DATA from the node */
       GetValue(Current, &a, sizeof(a));
        if(a==0)
            /* Delete node Current*/
            DeleteNode(&Head, &Current);
        if(a==5)
            DeleteNode(&Head, &Current);

        if(a==9)
            DeleteNode(&Head, &Current);

        printf("%d --> %d\n",i,a);

        /* I go to the next Node */
        MoveNext(&Current);
     }

    /* Save the list on the file */
    /* The old list is overwrite by the new list */
    SaveCltnOnFile("file.txt", RdFTAIL, Head, sizeof(int));
    getch();
    return 0;
}
//---------------------------------------------------------------------------

