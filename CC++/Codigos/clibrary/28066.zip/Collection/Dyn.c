/******************************************************************************
 *  Library to manage collections of nodes (lists, stack, queque...)
 *
 *  Written by Civera Estefan [19-04-2003]
 *
 *  Mail To: estefan.civera@email.it
 *
 * Copyright � 2003 Estefan Civera. All Rights Reserved.
 *
 * This code may be used in compiled form in any way you wish. This
 * file may be redistributed unmodified by any means PROVIDING it is
 * not sold for profit without the authors written consent, and
 * providing that this notice and the authors name is included. If the
 * source code is used in any commercial application then an email letting
 * me know that you are using it would be nice. However, this code may
 * not be sold as a part of any commercial library in compiled or source
 * form. In any other cases the code is free to whoever wants it anyway.

 * This software is provided "as is" without express or implied warranty.
 * Use it at you own risk! The author accepts no liability for any damages
 * to your computer or data this product may cause.
******************************************************************************/

#include <assert.h>
#include <mem.h>
#include <alloc.h>
#include <stdio.h>

#ifndef COLLECTION
#include "dyn.h"

/*****************************************************************************/
void Init(dpNODE dpNode)
{
    *dpNode = EOL;
    assert(*dpNode == NULL);
}

/*****************************************************************************/
bool IsEol	(pNODE pNode)
{
	return	(pNode == EOL) ? true : false;
}

/*****************************************************************************/
bool MoveNext (dpNODE dpNode)
{
	if( IsEol(*(dpNode)) )
		return false;

  	*dpNode = (*dpNode)->pNext;

	return true;
}

/*****************************************************************************/
unsigned long GetSize(pNODE pNode)
{
	unsigned long counter = 0;

	while( !IsEol (pNode) )
	{
		counter++;
		MoveNext (&pNode);
	}

	return (unsigned long) counter;
}
/*****************************************************************************/

bool AddHead(dpNODE dpHead, void* pBuffer, size_t sSize)
{
    pNODE pNode;

	pNode =	malloc(sizeof (struct NODE));
	pNode->pValue = malloc(sSize);

    assert(pNode != NULL);

	pNode->pNext = *dpHead;

	SetValue (pNode, pBuffer, sSize);

	*dpHead =	pNode;

	return true;
}

/*****************************************************************************/
bool AddTail(dpNODE dpHead, dpNODE dpTail , void* pBuffer,  size_t sSize)
{
    pNODE pNode;
    pNODE pTemp;

    pTemp = *dpHead;

	pNode =	malloc(sizeof (struct NODE));
	pNode->pValue = malloc(sSize);

    assert(pNode != NULL);

    SetValue (pNode, pBuffer, sSize);
    pNode->pNext = EOL;

    if(!IsEol(*dpTail))
    {
        (*dpTail)->pNext = pNode;
         *dpTail = pNode;
         return true;
    }

    if(IsEol(*dpHead))
    {
        *dpHead = pNode;
        *dpTail = *dpHead;
        return false;
    }

    while (!IsEol(pTemp->pNext))
	    MoveNext (&pTemp);

    pTemp->pNext = pNode;
    *dpTail = pNode;
    return true;
}

/*****************************************************************************/
size_t SetValue (pNODE pNode, void* pBuffer, size_t sSize)
{
	if( IsEol(pNode) )
		return 0;

	memcpy (pNode->pValue, pBuffer, sSize);

	return (size_t) sizeof (pNode->pValue);
}

/*****************************************************************************/
size_t GetValue (pNODE pNode, void* pBuffer, size_t sSize)
{
	if(IsEol(pNode))
		return (size_t) 0;

	memcpy (pBuffer, pNode->pValue, sSize);

	return (size_t) sizeof(pBuffer);
}

/*****************************************************************************/
bool DeleteNode (dpNODE dpHead, dpNODE dpDel)
{
	pNODE	pNode;
	pNode = *dpHead;

	if (pNode == *dpDel)
	{
		MoveNext (dpHead);
		*dpDel = *dpHead;

		free(pNode->pValue);
		free(pNode);

		return true;
	}

	while ( pNode->pNext != *dpDel)
		MoveNext (&pNode);

	pNode->pNext = (*dpDel)->pNext;

	free((*dpDel)->pValue);
	free(*dpDel);

	*dpDel = pNode->pNext;

	return false;
}

/*****************************************************************************/
unsigned long DeleteAll (dpNODE dpHead)
{
	pNODE	pNode;
	int		counter	= 0;

	while (!IsEol(*dpHead))
	{
		pNode	= *dpHead;
		MoveNext (dpHead);

		free(pNode->pValue);
		free(pNode);

		counter++;
	}
	return counter;
}

/*****************************************************************************/
unsigned long SaveCltnOnFile(char* Filename, LdF Mode, pNODE pPointer,
							 size_t sSize)
{
	void*	pBuffer = EOL;
	char*	OpenMode;
	FILE*	file;
	int		counter = 0;

	pBuffer = malloc(sSize);

	switch	(Mode)
	{
		case	LdFWRAPPEND	:	OpenMode = "ab";	break;
		case	LdFWRBEGIN	:	OpenMode = "wb";	break;
	}

	if((file = fopen(Filename, OpenMode)) == NULL)
		return 0;

	GetValue (pPointer, pBuffer, sSize);

	while(!IsEol(pPointer))
	{
		fwrite (pBuffer, sSize,1,file);
 		counter++;
		MoveNext (&pPointer);
		GetValue (pPointer, pBuffer, sSize);
	}

	free(pBuffer);

	fclose(file);

	return counter;
}

/*****************************************************************************/
unsigned long LoadCltnFromFile(char* Filename, RdF Mode, dpNODE dpHead,
							   dpNODE pTail, size_t sSize)
{
	FILE*	file	=	NULL;
	void*	pBuffer	=	EOL;
	int		counter	=	0;

	pBuffer = malloc(sSize);

	if((file = fopen(Filename,"rb")) == NULL)
		return 0;

	fread(pBuffer, sSize,1,file);
	while(!feof(file))
	{
		switch (Mode)
		{
			case RdFHEAD :	AddHead(dpHead, pBuffer, sSize);	break;

			case RdFTAIL :	AddTail(dpHead, pTail, pBuffer, sSize);
							break;
		}

		fread(pBuffer, sSize, 1, file);
		counter++;
	}

	free(pBuffer);

	fclose(file);

	return counter;
}



/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/
bool Push(dpNODE dpHead, void* pBuffer, size_t sSize)
{
    return AddHead(dpHead, pBuffer, sSize);
}

/*****************************************************************************/
size_t Top (pNODE  pHead, void* pBuffer, size_t sSize)
{
    return GetValue(pHead, pBuffer, sSize);

}

/*****************************************************************************/
size_t Pop (dpNODE dpHead, void* pBuffer, size_t sSize)
{
    size_t bytes = GetValue(*dpHead, pBuffer, sSize);

    DeleteNode(dpHead, dpHead);

    return bytes;
}

/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/
bool    Insert(dpNODE dpHead, dpNODE dpTail, void* pBuffer, size_t sSize)
{
    return AddTail(dpHead, dpTail, pBuffer, sSize);
}

/*****************************************************************************/
size_t Extract(dpNODE dpHead, void* pBuffer, size_t sSize)
{
    size_t bytes = GetValue(*dpHead, pBuffer, sSize);

    DeleteNode(dpHead, dpHead);

    return bytes;
}

/*****************************************************************************/
size_t First(pNODE pHead, void* pBuffer, size_t sSize)
{
    return (size_t) GetValue(pHead, pBuffer, sSize);
}


/*****************************************************************************/
#endif
/*****************************************************************************/



