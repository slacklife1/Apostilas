Use examples files
==================

Rename file from *Main.c to Main.c

Copy this file into the parent directory

Open project and run the application
 