/******************************************************************************
 *  Example program to manage tails
 *
 *  Written by Civera Estefan [19-04-2003]
 *
 *  Mail To: estefan.civera@studenti.unibg.it
 *
 *  Compiled with Borland C++ Builder 5
 *
 *****************************************************************************/

#include <stdio.h>
#include <conio.h>
#include "dyn.h"

int main(int argc, char* argv[])
{
    int n;
    pNODE pHead;
    pNODE pTail;

    Init(&pHead);
    Init(&pTail);

    for(n=0; n<10;n++)
        Insert(&pHead,&pTail, &n, sizeof(n));


    printf("There are %d nodes on the list\n", GetSize(pHead));
    First(pHead, &n, sizeof(n));
    printf("The first is %d\n", n);

    while(!IsEol(pHead))
    {
     Extract(&pHead, &n, sizeof(n));
     printf("%d\n", n);
    }
    DeleteAll(&pHead);
    getch();
    return 0;
}
//---------------------------------------------------------------------------

