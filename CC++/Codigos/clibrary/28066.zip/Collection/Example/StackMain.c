/******************************************************************************
 *  Example program to manage collections
 *
 *  Written by Civera Estefan 19-04-2003
 *
 *  Mail To: estefan.civera@studenti.unibg.it
 *
 *  Compiled with Borland C++ Builder 5
 *
 *****************************************************************************/

#include <stdio.h>
#include <conio.h>
#include "dyn.h"

int main(int argc, char* argv[])
{
    int n;
    pNODE pStack;
    Init(&pStack);

    for(n=0; n<10;n++)
        Push(&pStack, &n, sizeof(n));


    Top(pStack, &n, sizeof(n));
    printf("%d\n", n);

    while(!IsEol(pStack))
    {
     Pop(&pStack, &n, sizeof(n));
     printf("%d\n", n);
    }
    getch();
    return 0;
}
//---------------------------------------------------------------------------

