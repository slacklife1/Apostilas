This is smallest steganography program
with this u can hide your data in a image file
u can use any image file
but its type must be .bmp /.jpg
and data can be any thing
that data will be hidden in image 
and no one will be able to view the data
but image will open normally in any image viewer
Try it
Source code for actually operation is less than 0.2k LOC

BUT ONLY 1 FILE CAN BE KEPT IN 1 IMAGE FILE FOR MORE FILES TO BE COPIED DROP ME A LINE FOR ADVANCE PROGRAM 
AND IN THIS PROGRAM TRY MOSTLY DATA FILES ONLY AND NOT BINARY EVEN THOUGH THEY WORK SOME TIME BINARY FILES MIGHT FAIL TO BE RECOVERED PROPERLY


How to Use It
1) extract all files in folder possible on root
2) click on stagno
3)it will give u following options
a) hide-------->	specify image name c:\a.bmp
		Data name c:\readme.txt
it will hide data file readme.txt in that image
Then open image in paint brush
u will see a nice and beautiful face
with no signs of any data in that face
go to stagno program
click on retrieve
b) Retrieve-----> specify image name c:\a.bmp
		Specify data file name "as your wish"	
and then enter
Then the read me file's data will be available in file u specified
isn�t it magical
ya it is
u can hide any data in any image
and no one will ever no 
and no can even search thousand of images on your hard drive
which image contains which data
its a really use full tool for all
but this is beta version of the program so much functionality is not provided with it

but additional functionality  ready with me is
1) Password protection for that data
2) Strong encryption of data
3) Relocatable storing of data
4) More image file formats and mp3, and wav support also


**One more thing i have not added much comments in programs but its simple and easy to understand
**this is actually not a good technique for stganography
if u r interested in such things do mail me for advance version of the program and knowing more such stuff
As I cant write every thing in 1 readme.txt file


Algorithm for hiding the data in image
1) Ask for image file name
2) Ask for data file name
3) Open image file
if success full goto 4
else goto 1
4) open data file
if success full goto 5
else goto 2
5) Move file handle of image file to end position of file
(Increment a counter for each byte)
6) Start copying data of data file to image file
till end of data file

7) Copy size of image file that is counter value to end of resulting image file
(this will be used in retrieving process)
close the file's


Algorithm for retrieving the data in image
1) Ask for image file name
2) Ask for data file name
3) Open image file
if success full goto 4
else goto 1
4) open data file
if success full goto 5
else goto 2
5) Move file handle of image file to end position of file
(incrment a counter for each byte)
6) Retrieve counter value
7) Start copying data from that counter point into new file specified by user
till end of data file
close the file's



Loop holes created in program
1) not a safe way to store data as any one can view data by opening image file in notepad or some editor
2) Not password protected
3) Not a correct way of hiding data by just appending data to image file
(Lots of good techniques i can tell u
And that to different for different image and audio files which make even difficult to crack)
4) Image might corrupt some time
5) Data might corrupt some time
6) only 1 file can be copied into image file in this version
and lots more.............

But important point here is concept and simple implementation of it


Sorry for spelling mistakes that might be and bad way of writing the document

Any bugs comments always welcome
vaibhavk_@hotmail.com
vaibhav2410@yahoo.com
