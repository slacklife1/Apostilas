#include<stgano.h>
#include<graphics.h>
#include<stdio.h>
#include<dos.h>
#include<stdlib.h>
int ani=0;
main()
{
	a:g();m();
	win(10,100,400,250);
	outtextxy(20,150,"Smallets Stgnaograph Program");
	button(30,200,80,220,"Hide");
	button(130,200,200,220,"Retrive");
	button(230,200,280,220,"Exit");
	button(330,200,380,220,"Test");
	while(1)
	{
		if(click(30,200,80,220,"Hide")==0)
		{
			hide();
			goto a;
		}
		if(click(130,200,200,220,"Retrive")==0)
		{
			retrive();
			goto a;
		}
		if(click(230,200,280,220,"Exit")==0)
		{
			closegraph();
			exit(0);
		}
		if(click(330,200,380,220,"Test")==0)
		{
			system("c:\\winnt\\system32\\mspaint.exe ");
			goto a;
		}
	}
}
hide()
{
	StagnoHide();
	return 0;
}
retrive()
{
	StagnoRetrive();
	return 0;
//	exit(0);
}
StagnoHide()
{
	FILE *fp1,*fp2;
	char ImgFile[100],DataFile[100];
	long int i=0;
	char *tmp;
	cleardevice();
	win(10,100,300,250);
	outtextxy(20,130,"Enter Image File Name");
	tbox(20,150,280,170);
	tenter(20,160,280,170,ImgFile);

	cleardevice();
	win(10,100,300,250);
	outtextxy(20,130,"Enter Data File Name");
	tbox(20,150,280,170);
//	button(230,200,280,220,"NEXT");
	tenter(20,160,280,170,DataFile);
	fp1=fopen(ImgFile,"a+b");
	if(fp1==NULL)
	{
		closegraph();
		clrscr();
		printf("Invalid File Name1");
		getch();
		exit(0);
	}
	while(1)
	{
		if(feof(fp1)) break;
		i++;
		fgetc(fp1);
	}
	sprintf(tmp,"DATA=%ld",i);
	fp2=fopen(DataFile,"rt");
	if(fp2==NULL)
	{
		closegraph();
		printf("Invalid File Name2");
		getch();
		exit(0);
	}
	i=0;
	while(!feof(fp2))
	{
		i++;
		fputc(fgetc(fp2),fp1);
	}
	win(10,100,300,250);
	outtextxy(20,130,"Wait Till Hiding Data..");
	tbox(20,150,280,170);
//	printf("\nafter File Contains %ld Bytes",i);
	for(i=0;i<500;i++)
	{
		delay(10);
		anim(20,150,280,170);
	}
	ani=0;
	fputs(tmp,fp1);
	fclose(fp1);
	fclose(fp2);
	win(10,100,300,250);
	outtextxy(20,130,"Completed Now U can test Image");
	outtextxy(20,170,"Press Any Key To Continue");
	getch();
	return 0;
}
StagnoRetrive()
{
	FILE *fp1,*fp2;
	char ImgFile[100],DataFile[100];
	int Flag=0;
	long i=0,j=0,total=0;
	long x;
	int l=0,var=0;
	char *tmp,ch;
	ImgFile[0]='\0';
	DataFile[0]='\0';
	cleardevice();
	win(10,100,300,250);
	outtextxy(20,130,"Enter Image File Name");
	tbox(20,150,280,170);
	tenter(20,160,280,170,ImgFile);

	cleardevice();
	win(10,100,300,250);
	outtextxy(20,130,"Enter Data File Name");
	tbox(20,150,280,170);
	button(230,200,280,220,"NEXT");
	tenter(20,160,280,170,DataFile);
	fp1=fopen(ImgFile,"a+b");
	if(fp1==NULL)
	{
		closegraph();
		printf("Invalid File Name");
		getch();
		exit(0);
	}
	while(!feof(fp1))
	{
		fgetc(fp1);
		total++;
	}
	fclose(fp1);
	fp1=fopen(ImgFile,"a+b");
	if(fp1==NULL)
	{
		closegraph();
		printf("Invalid File Name");
		getch();
		exit(0);
	}
	while(!feof(fp1))
	{
		ch=fgetc(fp1);
		if(ch=='D')
		{
			ch=fgetc(fp1);
			if(ch=='A')
			{
				ch=fgetc(fp1);
				if(ch=='T')
				{
					ch=fgetc(fp1);
					if(ch=='A')
					{
						ch=fgetc(fp1);
						if(ch=='=')
						{
							Flag=1;
							break;
						}
					}
				}
			}
		}
	}
	if(Flag==0)
	{
		closegraph();
		clrscr();
		printf("Image Contains No Hidden Data\nSo Exiting\nPress Any Key ...");
		getch();
		exit(0);
	}
/*
		for(l=0;l<5;l++) tmp[l]=fgetc(fp1);
		tmp[l]='\0';
		if(strcmp(tmp,"DATA=")==0)
		{
			printf("Ok");    			break;
		}
	}*/
	l=0;
	while(1)
	{
		if(feof(fp1))  break ;
		tmp[l]=fgetc(fp1);
		l++;
	}
	tmp[l]='\0';
//	puts(tmp);
	var=strlen(tmp);
	x=atol(tmp);
//	printf("\nFile Contains %ld Bytes",x);
	fclose(fp1);

	fp1=fopen(ImgFile,"a+b");
	x--;
	for(j=0;j<x;j++)	fgetc(fp1);
	fp2=fopen(DataFile,"wt");
	if(fp2==NULL){closegraph();printf("Invalid File Name2");getch();exit(0);}
	total=total-(long)var-(long)1-(long)5;
	/*copy data to specifed data*/
	for(j=x;j<total;j++)
//	while(!feof(fp1))
	{
		ch=fgetc(fp1);
//		if(ch==255) break;
		fputc(ch,fp2);
	}
	win(10,100,300,250);
	outtextxy(20,130,"Wait Till Extracting Data..");
	tbox(20,150,280,170);
//	printf("\nafter File Contains %ld Bytes",i);
	for(i=0;i<500;i++)
	{
		delay(10);
		anim(20,150,280,170);
	}
	ani=0;
	fclose(fp1);
	fclose(fp2);
	win(10,100,300,250);
	outtextxy(20,130,"Completed Now U can test Image");
	outtextxy(20,170,"Press Any Key To Continue");
	getch();
	return 0;
}
anim(int x1,int y1,int x2,int y2)
{
	setfillstyle(1,1);
	if((x1+ani++)<x2)
		bar(x1+0,y1+1,x1+ani,y1+19);
	else
	{
		tbox(x1,y1,x2,y2);
		ani=0;
	}
	return 0;
}
