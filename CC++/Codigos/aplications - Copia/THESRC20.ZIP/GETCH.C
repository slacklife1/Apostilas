/*
 * This software is Copyright (c) 1989, 1990, 1991 by Patrick J. Wolfe.
 *
 * Permission is hereby granted to copy, distribute or otherwise
 * use any part of this package as long as you do not try to make
 * money from it or pretend that you wrote it.  This copyright
 * notice must be maintained in any copy made.
 *
 * Use of this software constitutes acceptance for use in an AS IS
 * condition. There are NO warranties with regard to this software.
 * In no event shall the author be liable for any damages whatsoever
 * arising out of or in connection with the use or performance of this
 * software.  Any use of this software is at the user's own risk.
 *
 * If you make modifications to this software that you feel
 * increases it usefulness for the rest of the community, please
 * email the changes, enhancements, bug fixes as well as any and
 * all ideas to me. This software is going to be maintained and
 * enhanced as deemed necessary by the community.
 *
 *              Patrick J. Wolfe
 *              uunet!uiucuxc!kailand!pwolfe
 *              pwolfe@kailand.kai.com
 *
 * Additions of Xenix,Sun,DOS,VMS,AIX and OS2 key handling
 * made by Mark Hessling (M.Hessling@gu.edu.au)
 *
 */


/*
$Id: getch.c 2.0 1995/01/26 16:31:10 MH Release MH $
*/

#if defined(USE_NCURSES)
#   include <ncurses.h>
#else
#   if defined(USE_EXTCURSES)
#      include <cur00.h>
#   else
#      include <curses.h>
#   endif
#endif

#if !defined(DOS) && !defined(OS2)
#include "getch.h"

#define NORMAL 100
#define ESCAPE 200
#define FKEY   300
#define BRACK  400

/***********************************************************************/
#ifdef PROTO
#  ifdef MSWIN
int my_getch (WINDOW far *winptr)
#  else
int my_getch (WINDOW *winptr)
#  endif
#else
int my_getch (winptr)
#  ifdef MSWIN
WINDOW far *winptr;
#  else
WINDOW *winptr;
#  endif
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
int c=0;
short state = NORMAL;
short fkeycount = 0;
/*--------------------------- processing ------------------------------*/
while (1) {
#ifndef VMS
       c = wgetch(winptr);
#else
       c = keypress();
#endif
       switch (state) {

       case BRACK:
               switch (c) {
               /* Linux f1 thru f5 are <esc>[[A <esc>[[B ... <esc>[[E */
               case 'A': case 'B': case 'C': case 'D': case 'E':
                       return KEY_F1 + (c - 'A');
               default:
                       state = NORMAL;
                       break;
                       }
               break;

       case FKEY:
               switch (c) {

               /* numeric function keys */
               case '0': case '1': case '2': case '3': case '4':
               case '5': case '6': case '7': case '8': case '9':
                       fkeycount = (fkeycount * 10) + (c - '0');
                       break;

               case '~':
                       switch (fkeycount) {

                       /* Find, Insert Here, Remove, Select, Prev Screen, Next Screen */
                       case 1: return KEY_Find;
                       case 2: return KEY_InsertHere;
                       case 3: return KEY_Remove;
                       case 4: return KEY_Select;
                       case 5: return KEY_PrevScreen;
                       case 6: return KEY_NextScreen;

                       /* unshifted xterm (Linux only ?) function keys */
                       case 11: case 12: case 13: case 14: case 15:
                               return KEY_F1 + (fkeycount - 11);

                       /* unshifted vt220 function keys */
                       case 17: case 18: case 19: case 20: case 21:
                               return KEY_F6 + (fkeycount - 17);
                       case 23: case 24: case 25: case 26:
                               return KEY_F11 + (fkeycount - 23);
                       case 28: case 29:
                               return KEY_F15 + (fkeycount - 28);
                       case 31: case 32: case 33: case 34:
                               return KEY_F17 + (fkeycount - 31);

                       /* vt220 function keys - control */
                       case 37: case 38: case 39: case 40: case 41:
                               return KEY_SF6 + (fkeycount - 37);
                       case 43: case 44: case 45: case 46:
                               return KEY_SF11 + (fkeycount - 43);
                       case 48: case 49:
                               return KEY_SF15 + (fkeycount - 48);
                       case 51: case 52: case 53: case 54:
                               return KEY_SF17 + (fkeycount - 51);

                       /* shifted tvs922 function keys */
        /*             case 37: case 38: case 39: case 40: case 41:
                       case 42: case 43: case 44: case 45: case 46:
                       case 47: case 48: case 49: case 50: case 51:
                               return KEY_SF6 + (fkeycount - 37); */

                       default:
                               state = NORMAL;
                               }
                       break;

               case 'A':       return KEY_UP;
               case 'B':       return KEY_DOWN;
               case 'C':       return KEY_RIGHT;
               case 'D':       return KEY_LEFT;
               case 'M':       return KEY_PadEnter;
               case 'Z':       return KEY_BackTab;

               /* Xenix default key mappings */
               case 'H':       return KEY_HOME;
               case 'F':       return KEY_END;
               case 'L':       return KEY_InsertHere;
               case 'G':       return KEY_NextScrn;
               case 'I':       return KEY_PrevScrn;

               case 'N':       return KEY_F2;
               case 'O':       return KEY_F3;
               case 'T':       return KEY_F8;
               case 'U':       return KEY_F9;
               case 'V':       return KEY_F10;
               case 'W':       return KEY_F11;
               case 'X':       return KEY_F12;

               /* VT[12]00 PF keys */
               case 'P': case 'Q': case 'R': case 'S':
                       return KEY_PF1 + (c - 'P');

               /* VT[12]00 keypad */
               case 'l': case 'm': case 'n': case 'o': case 'p': case 'r':
               case 's': case 't': case 'u': case 'v': case 'w': case 'x': case 'y':
                       return KEY_PadComma + (c - 'l');

               /* Sun Keyboard Function Keys */
               case 'z':
                       switch (fkeycount) {
                       /* SUN F1-F10 */
                       case 224: case 225: case 226: case 227: case 228:
                       case 229: case 230: case 231: case 232: case 233:
                               return KEY_F1 + (fkeycount - 224);
                       /* SUN S-F1-S-F10 */
                       case 324: case 325: case 326: case 327: case 328:
                       case 329: case 330: case 331: case 332: case 333:
                               return KEY_SF1 + (fkeycount - 324);
                       case 192: return KEY_F11;
                       case 193: return KEY_F12;
                       case 195: return KEY_UNDO;
                       case 292: return KEY_SF11;
                       case 293: return KEY_SF12;
                       case 214: return KEY_HOME;
                       case 414: return KEY_CHOME;
                       case 215: return KEY_UP;
                       case 415: return KEY_CUP;
                       case 216: return KEY_PrevScrn;
                       case 416: return KEY_CPGUP;
                       case 217: return KEY_LEFT;
                       case 417: return KEY_CLEFT;
                       case 219: return KEY_RIGHT;
                       case 419: return KEY_CRIGHT;
                       case 220: return KEY_END;
                       case 420: return KEY_CEND;
                       case 221: return KEY_DOWN;
                       case 421: return KEY_CDOWN;
                       case 222: return KEY_NextScrn;
                       case 422: return KEY_CPGDN;
                       case 1:   return KEY_BTAB;
                       case 2:   return KEY_InsertHere;
                       case 3:   return KEY_HOME;
                       case 4:   return KEY_END;
                       case 5:   return KEY_PrevScrn;
                       case 6:   return KEY_NextScrn;
                       case 423: return KEY_PadComma;
                       default:
                               state = NORMAL;
                               }
                       break;

               /* IBM AIX ???????? */
               case 'q':
                       switch (fkeycount) {
                       case 0:  /* VT100/200 keypad */
                               return KEY_PadComma + (c - 'l');
                       /* AIX F1-F12 */
                       case 1: case 2: case 3: case 4: case 5: case 6:
                       case 7: case 8: case 9: case 10: case 11: case 12:
                               return KEY_F1 + (fkeycount - 1);
                       /* AIX SF1-F12 */
                       case 13: case 14: case 15: case 16: case 17: case 18:
                       case 19: case 20: case 21: case 22: case 23: case 24:
                               return KEY_SF1 + (fkeycount - 13);
                       /* AIX CF1-F12 */
                       case 25: case 26: case 27: case 28: case 29: case 30:
                       case 31: case 32: case 33: case 34: case 35: case 36:
                               return KEY_CF1 + (fkeycount - 25);
                       case 150: return KEY_PrevScrn;
                       case 146: return KEY_END;
                       case 154: return KEY_NextScrn;
                       case 139: return KEY_InsertHere;
                       default:
                               state = NORMAL;
                               }
                       break;
               case '[':
                       state = BRACK;
                       break;

               default:
                       state = NORMAL;
                       }
               break;

       case ESCAPE:
               switch (c) {
               case 'O':     /* vt100 numeric keypad application codes */
               case '?':     /* vt52  numeric keypad application codes */
               case '[':
                       state = FKEY;
                       fkeycount = 0;
                       break;
               /* VT52 PF keys */
               case 'P': case 'Q': case 'R': case 'S':
                       return KEY_PF1 + (c - 'P');

               default:
                       state = NORMAL;
                       }
               break;

       default:
               switch (c) {
               case Escape:
                       state = ESCAPE;
                       break;

               case CSI:
                       state = FKEY;
                       fkeycount = 0;
                       break;

               default:
                       return (c);
                       }
               }
       }
}
#endif
#if defined(DOS) || defined(OS2)
int my_getch (winptr)
WINDOW *winptr;
{
 return(wgetch(winptr));
}
#endif
#ifdef VMS
#include iodef
#include descrip
/***********************************************************************/
short keypress()
/***********************************************************************/
{
/*--------------------------- local data ------------------------------*/
struct { long length; char *address; } logical_name;
struct { short status; short length; short remainder; } iosb;

static char kb[] = { "sys$input" };
static short chan;

static char key = 0;
short new_key;
static short first = 1;
short status;
/*--------------------------- processing ------------------------------*/

 key = 0;
 logical_name.length = strlen (kb);
 logical_name.address = kb;
 status = sys$assign (&logical_name, &chan, 0, 0);
 if (status != 1)
   return(-1);
 status = SYS$QIOW(0, chan, IO$_READVBLK | IO$M_NOFILTR | IO$M_NOECHO
        | IO$M_TIMED, &iosb, 0, 0, &key, 1,600, 0,0, 0, 0);
 if (!key)
    return (0);
 new_key = (short)(key);
 status = sys$dassgn (chan);
 return (new_key);
}
#endif
