/***********************************************************************/
/* RXIFACE - Personal REXX interface                                   */
/***********************************************************************/
/*
 * THE - The Hessling Editor. A text editor similar to VM/CMS xedit.
 * Copyright (C) 1991-1995 Mark Hessling
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to:
 *
 *    The Free Software Foundation, Inc.
 *    675 Mass Ave,
 *    Cambridge, MA 02139 USA.
 *
 *
 * If you make modifications to this software that you feel increases
 * it usefulness for the rest of the community, please email the
 * changes, enhancements, bug fixes as well as any and all ideas to me.
 * This software is going to be maintained and enhanced as deemed
 * necessary by the community.
 *
 * Mark Hessling                     email: M.Hessling@gu.edu.au
 * 36 David Road                     Phone: +61 7 849 7731
 * Holland Park                      Fax:   +61 7 875 5314
 * QLD 4121
 * Australia
 */

/*
$Id: QUERCUS.C 2.0 1995/01/26 16:34:37 MH Release MH $
*/

#if defined(USE_QUERCUS)

#define INCL_RXSHV
#define INCL_RXSUBCOM
#define INCL_RXFUNC
#define INCL_RXSYSEXIT 

#include "the.h"
#include "rexx.h"

/*--------------------------- global data -----------------------------*/
/*-------------------------- external data ----------------------------*/
extern bool rexx_output;
/***********************************************************************/
LONG RexxStart(
   LONG		ArgCount,
   PRXSTRING 	ArgList,
   PSZ		ProgramName,
   PRXSTRING	Instore,
   PSZ		EnvName,
   LONG		CallType,
   PRXSYSEXIT	Exits,
   PLONG	ReturnCode,
   PRXSTRING	Result )
{
/***********************************************************************/
/*--------------------------- local data ------------------------------*/
/*--------------------------- processing ------------------------------*/
 return(0L);
}
/***********************************************************************/
ULONG RexxRegisterSubcomExe( 
   PSZ EnvName,
   PFN EntryPoint,
   PUCHAR UserArea )
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
/*--------------------------- processing ------------------------------*/
 return(0L);
}
/***********************************************************************/
ULONG RexxDeregisterSubcom( 
   PSZ EnvName,
   PSZ ModuleName )
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
/*--------------------------- processing ------------------------------*/
 return(-1L);
}
/***********************************************************************/
ULONG RexxVariablePool( 
   PSHVBLOCK RequestBlockList )
/***********************************************************************/
{
/*--------------------------- local data ------------------------------*/
/*--------------------------- processing ------------------------------*/
 return(0L);
}
/***********************************************************************/
ULONG RexxRegisterExitExe( 
   PSZ EnvName,
   PFN EntryPoint, 
   PUCHAR UserArea )
/***********************************************************************/
{
/*--------------------------- local data ------------------------------*/
/*--------------------------- processing ------------------------------*/
 return(-1L);
}
/***********************************************************************/
int RexxDeregisterExit( 
   PSZ EnvName,
   PSZ ModuleName )
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
/*--------------------------- processing ------------------------------*/
 return(0L);
}
/***********************************************************************/
ULONG RexxRegisterFunctionExe( PSZ Name, PFN EntryPoint )
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
/*--------------------------- processing ------------------------------*/
 return(-1L);
}
/***********************************************************************/
ULONG RexxDeregisterFunction( PSZ Name ) 
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
/*--------------------------- processing ------------------------------*/
 return(0L);
}
#endif
