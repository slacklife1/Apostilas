/***********************************************************************/
/* PREFIX.C - Prefix commands.                                         */
/***********************************************************************/
/*
 * THE - The Hessling Editor. A text editor similar to VM/CMS xedit.
 * Copyright (C) 1991-1995 Mark Hessling
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to:
 *
 *    The Free Software Foundation, Inc.
 *    675 Mass Ave,
 *    Cambridge, MA 02139 USA.
 *
 *
 * If you make modifications to this software that you feel increases
 * it usefulness for the rest of the community, please email the
 * changes, enhancements, bug fixes as well as any and all ideas to me.
 * This software is going to be maintained and enhanced as deemed
 * necessary by the community.
 *
 * Mark Hessling                     email: M.Hessling@gu.edu.au
 * 36 David Road                     Phone: +61 7 849 7731
 * Holland Park                      Fax:   +61 7 875 5314
 * QLD 4121
 * Australia
 */

/*
$Id: prefix.c 2.0 1995/01/26 16:31:36 MH Release MH $
*/

#include <stdio.h>

#include "the.h"
#include "proto.h"
/*-------------------------- declarations -----------------------------*/
#ifdef PROTO
static short parse_prefix_command(PPC *,CHARTYPE *,CHARTYPE *);
static short invalidate_prefix(PPC *);
static short prefix_makecurr(PPC *,short,LINETYPE);
static short prefix_add(PPC *,short,LINETYPE);
static short prefix_duplicate(PPC *,short,LINETYPE);
static short prefix_copy(PPC *,short,LINETYPE);
static short prefix_move(PPC *,short,LINETYPE);
static short prefix_delete(PPC *,short,LINETYPE);
static short prefix_shift_left(PPC *,short,LINETYPE);
static short prefix_shift_right(PPC *,short,LINETYPE);
static short prefix_tabline(PPC *,short,LINETYPE);
static short prefix_scale(PPC *,short,LINETYPE);
static short prefix_show(PPC *,short,LINETYPE);
static short prefix_exclude(PPC *,short,LINETYPE);
static short prefix_block_duplicate(PPC *,short,LINETYPE);
static short prefix_block_copy(PPC *,short,LINETYPE);
static short prefix_block_move(PPC *,short,LINETYPE);
static short prefix_block_delete(PPC *,short,LINETYPE);
static short prefix_block_shift_left(PPC *,short,LINETYPE);
static short prefix_block_shift_right(PPC *,short,LINETYPE);
static short prefix_block_exclude(PPC *,short,LINETYPE);
static PPC *find_bottom_ppc(PPC *,short);
static PPC *find_target_ppc(void);
static PPC *calculate_target_line(void);
static short try_rexx_prefix_macro(PPC *);
static CHARTYPE *substr(CHARTYPE *, CHARTYPE *, short, short);
#else
static short parse_prefix_command();
static short invalidate_prefix();
static short prefix_makecurr();
static short prefix_add();
static short prefix_duplicate();
static short prefix_copy();
static short prefix_move();
static short prefix_delete();
static short prefix_shift_left();
static short prefix_shift_right();
static short prefix_tabline();
static short prefix_scale();
static short prefix_show();
static short prefix_exclude();
static short prefix_block_duplicate();
static short prefix_block_copy();
static short prefix_block_move();
static short prefix_block_delete();
static short prefix_block_shift_left();
static short prefix_block_shift_right();
static short prefix_block_exclude();
static PPC *find_bottom_ppc();
static PPC *find_target_ppc();
static PPC *calculate_target_line();
static short try_rexx_prefix_macro();
static CHARTYPE *substr();
#endif
/*---------------------------------------------------------------------*/
/* The following two are to specify the first and last items in the    */
/* linked list for prefix synonyms.                                    */
/*---------------------------------------------------------------------*/
LINE *first_prefix_synonym=NULL;
LINE *last_prefix_synonym=NULL;
/*---------------------------------------------------------------------*/

#define PPC_NO_TARGET        (-1)
#define PPC_NO_COMMAND       (-2)
#define PPC_TARGET_PREVIOUS  0
#define PPC_TARGET_FOLLOWING 1
/* the above two defines correspond to the position in the pc[] array  */
/* and should be changed if the position in pc[] array changes.        */

#define NUMBER_PREFIX_COMMANDS 22
 static PREFIX_COMMAND pc[NUMBER_PREFIX_COMMANDS] =
  {
   {(CHARTYPE *)"p",1,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,TRUE,FALSE,NULL,1L,FALSE,FALSE},
   {(CHARTYPE *)"f",1,FALSE,FALSE,FALSE,FALSE,FALSE,TRUE,FALSE,FALSE,NULL,1L,FALSE,FALSE},
   {(CHARTYPE *)"tabl",4,TRUE,FALSE,FALSE,FALSE,FALSE,TRUE,TRUE,TRUE,prefix_tabline,1L,FALSE,FALSE},
   {(CHARTYPE *)"scale",5,TRUE,FALSE,FALSE,FALSE,FALSE,TRUE,TRUE,TRUE,prefix_scale,1L,FALSE,FALSE},
   {(CHARTYPE *)"\"\"",2,TRUE,TRUE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,prefix_block_duplicate,1L,FALSE,FALSE},
   {(CHARTYPE *)"cc",2,TRUE,TRUE,FALSE,TRUE,TRUE,FALSE,FALSE,FALSE,prefix_block_copy,1L,FALSE,FALSE},
   {(CHARTYPE *)"mm",2,TRUE,TRUE,FALSE,TRUE,TRUE,FALSE,FALSE,FALSE,prefix_block_move,1L,FALSE,FALSE},
   {(CHARTYPE *)"dd",2,TRUE,TRUE,FALSE,TRUE,FALSE,FALSE,FALSE,FALSE,prefix_block_delete,1L,FALSE,FALSE},
   {(CHARTYPE *)"xx",2,TRUE,TRUE,FALSE,TRUE,FALSE,FALSE,FALSE,FALSE,prefix_block_exclude,1L,FALSE,FALSE},
   {(CHARTYPE *)"<<",2,TRUE,TRUE,FALSE,TRUE,FALSE,FALSE,FALSE,FALSE,prefix_block_shift_left,1L,FALSE,FALSE},
   {(CHARTYPE *)">>",2,TRUE,TRUE,FALSE,TRUE,FALSE,FALSE,FALSE,FALSE,prefix_block_shift_right,1L,FALSE,FALSE},
   {(CHARTYPE *)"\"",1,TRUE,TRUE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,prefix_duplicate,1L,FALSE,FALSE},
   {(CHARTYPE *)"c",1,TRUE,TRUE,TRUE,FALSE,TRUE,FALSE,FALSE,FALSE,prefix_copy,1L,FALSE,FALSE},
   {(CHARTYPE *)"m",1,TRUE,TRUE,TRUE,FALSE,TRUE,FALSE,FALSE,FALSE,prefix_move,1L,FALSE,FALSE},
   {(CHARTYPE *)"d",1,TRUE,TRUE,TRUE,FALSE,FALSE,FALSE,FALSE,FALSE,prefix_delete,1L,FALSE,FALSE},
   {(CHARTYPE *)"s",1,TRUE,TRUE,TRUE,FALSE,FALSE,FALSE,FALSE,FALSE,prefix_show,MAX_LONG,TRUE,TRUE},
   {(CHARTYPE *)"x",1,TRUE,TRUE,TRUE,FALSE,FALSE,FALSE,FALSE,FALSE,prefix_exclude,1L,FALSE,FALSE},
   {(CHARTYPE *)"<",1,TRUE,TRUE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,prefix_shift_left,1L,FALSE,FALSE},
   {(CHARTYPE *)">",1,TRUE,TRUE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,prefix_shift_right,1L,FALSE,FALSE},
   {(CHARTYPE *)"i",1,TRUE,TRUE,FALSE,FALSE,FALSE,TRUE,FALSE,FALSE,prefix_add,1L,FALSE,FALSE},
   {(CHARTYPE *)"a",1,TRUE,TRUE,FALSE,FALSE,FALSE,TRUE,FALSE,FALSE,prefix_add,1L,FALSE,FALSE},
   {(CHARTYPE *)"/",1,TRUE,FALSE,FALSE,FALSE,FALSE,TRUE,TRUE,TRUE,prefix_makecurr,1L,FALSE,FALSE},
  };

LINETYPE prefix_current_line;
bool in_prefix_macro=FALSE;     /* indicate if processing prefix macro */
/***********************************************************************/
#ifdef PROTO
short execute_prefix_commands(void)
#else
short execute_prefix_commands()
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
 extern bool readonly;
 extern bool rexx_support;
 extern CHARTYPE number_of_files;
 extern bool curses_started;
/*--------------------------- local data ------------------------------*/
 short cmd_idx=0,rc=RC_OK;
 CHARTYPE cmd[PREFIX_WIDTH+1];
 CHARTYPE mult[PREFIX_WIDTH+1];
 LINETYPE long_mult=0L;
 short top_ppc=0,bot_ppc=0,target_ppc=0;
 PPC *curr_ppc=NULL;
 TARGET target;
 short target_type=TARGET_NORMAL;
 unsigned short y=0,x=0;
/*--------------------------- processing ------------------------------*/
#ifdef TRACE
 trace_function("prefix.c:  execute_prefix_commands");
#endif
 post_process_line(CURRENT_VIEW,CURRENT_VIEW->focus_line);
 curr_ppc = CURRENT_FILE->first_ppc;
 while(1)
   {
    if (curr_ppc == NULL)
       break;
/*---------------------------------------------------------------------*/
/* If a set point command, validate the name.                          */
/*---------------------------------------------------------------------*/
    if (*(curr_ppc->ppc_command) == '.')
      {
       if (isalpha(curr_ppc->ppc_command[1]))
         {
          if (execute_set_point(curr_ppc->ppc_command,curr_ppc->ppc_line_number,TRUE) != RC_OK)
            {
             invalidate_prefix(curr_ppc);
             curr_ppc = curr_ppc->next;
             continue;
            }
          clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
          curr_ppc = curr_ppc->next;
          continue;
         }
       else
         {
          invalidate_prefix(curr_ppc);
          curr_ppc = curr_ppc->next;
          continue;
         }
      }
/*---------------------------------------------------------------------*/
/* If an invalid prefix command from last time, clear it.              */
/*---------------------------------------------------------------------*/
    if (*(curr_ppc->ppc_command) == '?')
      {
       clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
       curr_ppc = curr_ppc->next;
       continue;
      }
/*---------------------------------------------------------------------*/
/* To get here we have 'normal' prefix command.                        */
/*---------------------------------------------------------------------*/
    if (rexx_support)              /* if REXX support is in effect ... */
      {
/*---------------------------------------------------------------------*/
/* first determine if the command is a prefix macro BEFORE looking for */
/* standard prefix commands.                                           */
/*---------------------------------------------------------------------*/
       rc = try_rexx_prefix_macro(curr_ppc);
/*---------------------------------------------------------------------*/
/* If at this point there are no more files in the ring; we assume that*/
/* this was caused by exitting the last file in the ring from a prefix */
/* macro, exit and ignore any more prefix commands. This is messy !!!  */
/*---------------------------------------------------------------------*/
       if (number_of_files == 0)
         {
#ifdef TRACE
          trace_return();
#endif
          return(RC_COMMAND_NO_FILES);
         }
       if (rc != RC_NOT_COMMAND)
         {
          curr_ppc = curr_ppc->next;
          continue;
         }
      }
/*---------------------------------------------------------------------*/
/* if no prefix macro found for the prefix command, check to see if it */
/* is a standard prefix command.                                       */
/*---------------------------------------------------------------------*/
    if ((cmd_idx = parse_prefix_command(curr_ppc,cmd,mult)) == PPC_NO_TARGET)
      {
       invalidate_prefix(curr_ppc);
       curr_ppc = curr_ppc->next;
       continue;
      }
    if (cmd_idx == PPC_NO_COMMAND)
      {
       curr_ppc = curr_ppc->next;
       continue;
      }
/*---------------------------------------------------------------------*/
/* If running in read-only mode and the function selected is not valid */
/* display an error.                                                   */
/*---------------------------------------------------------------------*/
    if (readonly && !pc[cmd_idx].valid_in_readonly)
      {
       display_error(56,"",FALSE);
       invalidate_prefix(curr_ppc);
       continue;
      }
/*---------------------------------------------------------------------*/
/* We now have a recognised command. We have to validate its parameters*/
/* and find any associated pending commands.                           */
/*---------------------------------------------------------------------*/
/*---------------------------------------------------------------------*/
/* Set the block_command flag for the current prefix command to the    */
/* appropriate value for the prefix command.                           */
/*---------------------------------------------------------------------*/
    curr_ppc->ppc_block_command = pc[cmd_idx].block_prefix_command;
/*---------------------------------------------------------------------*/
/* If the command does not allow parameters and there are parameters,  */
/* error.                                                              */
/*---------------------------------------------------------------------*/
    if (!pc[cmd_idx].multiples_allowed
    && strcmp(mult,"") != 0)
      {
       invalidate_prefix(curr_ppc);
       curr_ppc = curr_ppc->next;
       continue;
      }
/*---------------------------------------------------------------------*/
/* If the command does allow parameters and there are no parameters,   */
/* set to default...                                                   */
/*---------------------------------------------------------------------*/
    rc = RC_OK;
    if (strcmp(mult,"") == 0)
       long_mult = pc[cmd_idx].default_target;
    else
/*---------------------------------------------------------------------*/
/* ...otherwise validate the target supplied...                        */
/*---------------------------------------------------------------------*/
      {
       if (pc[cmd_idx].multiples_allowed)
         {
          if (pc[cmd_idx].full_target_allowed)
            {
             initialise_target(&target);
             target.ignore_scope = pc[cmd_idx].ignore_scope;
             if (pc[cmd_idx].use_last_not_in_scope        /* S command */
             && mult[0] == '-')
                rc = validate_target(mult,&target,target_type,find_last_not_in_scope(NULL,curr_ppc->ppc_line_number,DIRECTION_FORWARD),TRUE,TRUE);
             else
                rc = validate_target(mult,&target,target_type,curr_ppc->ppc_line_number,TRUE,TRUE);
             if (target.num_lines == 0L)
                rc = RC_INVALID_OPERAND;
             long_mult = target.num_lines;
             free_target(&target);
            }
          else
             if (!valid_positive_integer(mult))
                rc = RC_INVALID_OPERAND;
             else
                long_mult = atol(mult);
         }
      }
/*---------------------------------------------------------------------*/
/* If the target is invalid or not found, invalidate the command.      */
/*---------------------------------------------------------------------*/
    if (rc != RC_OK)
      {
       invalidate_prefix(curr_ppc);
       curr_ppc = curr_ppc->next;
       continue;
      }
    curr_ppc->ppc_cmd_param = long_mult;
    curr_ppc = curr_ppc->next;
   }
/*---------------------------------------------------------------------*/
/* For each valid pending  command for the current view, execute  the  */
/* command.                                                            */
/*---------------------------------------------------------------------*/
 curr_ppc = CURRENT_FILE->first_ppc;
 while(curr_ppc != NULL)
   {
    top_ppc = bot_ppc = target_ppc = (-1);
/*---------------------------------------------------------------------*/
/* Execute the function associated with the prefix command...          */
/*---------------------------------------------------------------------*/
    cmd_idx = curr_ppc->ppc_cmd_idx;
    long_mult = curr_ppc->ppc_cmd_param;
    if (cmd_idx != (-1)
    &&  cmd_idx != (-2)
    &&  pc[cmd_idx].function != NULL)
       rc = (*pc[cmd_idx].function)(curr_ppc,cmd_idx,long_mult);
    curr_ppc = curr_ppc->next;
   }
/*---------------------------------------------------------------------*/
/* The "cleared" pending prefix commands now need to be deleted from   */
/* the linked list...                                                  */
/*---------------------------------------------------------------------*/
 curr_ppc = CURRENT_FILE->first_ppc;
 while(curr_ppc != NULL)
   {
    if (curr_ppc->ppc_cmd_idx == (-1))
#if 0
       curr_ppc = pll_del(&(CURRENT_FILE->first_ppc),&(CURRENT_FILE->last_ppc),curr_ppc,DIRECTION_FORWARD);
#endif
       curr_ppc = delete_pending_prefix_command(curr_ppc,CURRENT_FILE,NULL);
    else
       curr_ppc = curr_ppc->next;
   }
/*---------------------------------------------------------------------*/
/* Now that we are here, display the new version of the screen.        */
/*---------------------------------------------------------------------*/
 pre_process_line(CURRENT_VIEW,CURRENT_VIEW->focus_line);
 build_current_screen(); 
 display_current_screen();
 if (CURRENT_VIEW->current_window != WINDOW_COMMAND)
   {
    if (curses_started)
       getyx(CURRENT_WINDOW,y,x);
    CURRENT_VIEW->focus_line = get_focus_line_in_view(CURRENT_VIEW->focus_line,y);
    y = get_row_for_focus_line(CURRENT_VIEW->focus_line,CURRENT_VIEW->current_row);
    if (curses_started)
       wmove(CURRENT_WINDOW,y,x);
    pre_process_line(CURRENT_VIEW,CURRENT_VIEW->focus_line);
   }
#ifdef TRACE
 trace_return();
#endif
 return(RC_OK);
}
/***********************************************************************/
#ifdef PROTO
static short parse_prefix_command(PPC *curr_ppc,CHARTYPE *cmd,CHARTYPE *mult)
#else
static short parse_prefix_command(curr_ppc,cmd,mult)
PPC *curr_ppc;
CHARTYPE *cmd,*mult;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 register short i=0,j=0;
 short len_pcmd=0;
 CHARTYPE pcmd[PREFIX_WIDTH+1];
 short pos=0,rc=RC_OK;
 LINE *curr=NULL;
/*--------------------------- processing ------------------------------*/
#ifdef TRACE
 trace_function("prefix.c:  parse_prefix_command");
#endif
/*---------------------------------------------------------------------*/
/* For each pending prefix command for the current view, execute the   */
/* appropriate command.                                                */
/*---------------------------------------------------------------------*/
 rc = PPC_NO_TARGET;
 strcpy(pcmd,curr_ppc->ppc_command); /* get our own copy to pull apart */
 if (blank_field(pcmd))          /* if prefix command is blank, return */
   {
#ifdef TRACE
    trace_return();
#endif
    return(PPC_NO_COMMAND);
   }
 len_pcmd = strlen(pcmd);
/*---------------------------------------------------------------------*/
/* For each prefix synonym, determine if it exists somewhere in the    */
/* entered prefix command.                                             */
/*---------------------------------------------------------------------*/
 curr = first_prefix_synonym;
 while(1)
   {
    if (curr == NULL)
       break;
    pos = memfind(pcmd,curr->name,len_pcmd,strlen(curr->name),TRUE,FALSE,' ',' ');
    if (pos == (-1))
      {
       curr = curr->next;
       continue;
      }
/*---------------------------------------------------------------------*/
/* Now that a match on synonym is made, determine the original prefix  */
/* command associated with that synonym...                             */
/*---------------------------------------------------------------------*/
    for (i=0;i<NUMBER_PREFIX_COMMANDS;i++)
      {
       if (strcmp(pc[i].cmd,(CHARTYPE *)curr->line) == 0)
         {
          strcpy(cmd,pc[i].cmd);
          for (j=0;j<strlen(curr->name);j++)
             *(pcmd+pos+j) = ' ';
          strtrunc(pcmd);
          strcpy(mult,pcmd);
          curr_ppc->ppc_cmd_idx = i;
#ifdef TRACE
          trace_return();
#endif
          return(i);
         }
      }
/*---------------------------------------------------------------------*/
/* To get here we found a prefix synonym, but no matching original     */
/* command, so return an error.                                        */
/*---------------------------------------------------------------------*/
    curr_ppc->ppc_cmd_idx = (-1);
#ifdef TRACE
    trace_return();
#endif
    return(rc);
   }
/*---------------------------------------------------------------------*/
/* For each valid prefix command,  check to see if a valid command     */
/* exists somewhere in the entered prefix command.                     */
/*---------------------------------------------------------------------*/
 for (i=0;i<NUMBER_PREFIX_COMMANDS;i++)
   {
    pos = memfind(pcmd,pc[i].cmd,len_pcmd,pc[i].cmd_len,TRUE,FALSE,' ',' ');
    if (pos == (-1))
       continue;
    strcpy(cmd,pc[i].cmd);
    for (j=0;j<pc[i].cmd_len;j++)
       *(pcmd+pos+j) = ' ';
    strtrunc(pcmd);
    strcpy(mult,pcmd);
    rc = i;
/*---------------------------------------------------------------------*/
/* Set a flag in ppc[] array to indicate which command is present.     */
/*---------------------------------------------------------------------*/
    curr_ppc->ppc_cmd_idx = i;
    break;
   }
/*---------------------------------------------------------------------*/
/* If command not found, set a flag in ppc[] array to indicate command */
/* is invalid.                                                         */
/*---------------------------------------------------------------------*/
 if (rc == PPC_NO_TARGET)
    curr_ppc->ppc_cmd_idx = (-1);
#ifdef TRACE
 trace_return();
#endif
 return(rc);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_makecurr(PPC *curr_ppc,short cmd_idx,LINETYPE number_lines)
#else
static short prefix_makecurr(curr_ppc,cmd_idx,number_lines)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_lines;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 LINETYPE top_line = curr_ppc->ppc_line_number;
/*--------------------------- processing ------------------------------*/
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 execute_makecurr(top_line);
 return(0);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_tabline(PPC *curr_ppc,short cmd_idx,LINETYPE number_lines)
#else
static short prefix_tabline(curr_ppc,cmd_idx,number_lines)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_lines;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 LINETYPE top_line = curr_ppc->ppc_line_number;
 short tab_row = 0;
/*--------------------------- processing ------------------------------*/
 if ((tab_row = get_row_for_focus_line(top_line,(-1))) != (-1))
   {
    CURRENT_VIEW->tab_base = POSITION_TOP;
    CURRENT_VIEW->tab_off = tab_row+1;
    CURRENT_VIEW->tab_on = TRUE;
   }
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 return(0);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_scale(PPC *curr_ppc,short cmd_idx,LINETYPE number_lines)
#else
static short prefix_scale(curr_ppc,cmd_idx,number_lines)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_lines;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 LINETYPE top_line = curr_ppc->ppc_line_number;
 short scale_row = 0;
/*--------------------------- processing ------------------------------*/
 if ((scale_row = get_row_for_focus_line(top_line,(-1))) != (-1))
   {
    CURRENT_VIEW->scale_base = POSITION_TOP;
    CURRENT_VIEW->scale_off = scale_row+1;
    CURRENT_VIEW->scale_on = TRUE;
   }
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 return(0);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_show(PPC *curr_ppc,short cmd_idx,LINETYPE number_lines)
#else
static short prefix_show(curr_ppc,cmd_idx,number_lines)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_lines;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 register int i;
 short rc=RC_OK;
 LINETYPE top_line = curr_ppc->ppc_line_number;
 LINETYPE target_line=0L;
 LINE *curr=NULL;
 short direction=DIRECTION_FORWARD;
/*--------------------------- processing ------------------------------*/
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 if (TOF(top_line)
 ||  BOF(top_line))
    return(-1);
/*---------------------------------------------------------------------*/
/* Find the current line from where we start showing...                */
/*---------------------------------------------------------------------*/
 curr = lll_find(CURRENT_FILE->first_line,top_line);
/*---------------------------------------------------------------------*/
/* If the line that the show command was entered is in scope, then     */
/* return with an error.                                               */
/*---------------------------------------------------------------------*/
 if (in_scope(curr))
   {
    invalidate_prefix(curr_ppc);
    return(-1);
   }
/*---------------------------------------------------------------------*/
/* For a negative target, show the lines from the end of the excluded  */
/* block.                                                              */
/*---------------------------------------------------------------------*/
 if (number_lines < 0)
   {
    target_line = find_last_not_in_scope(curr,top_line,DIRECTION_FORWARD);
    curr = lll_find(CURRENT_FILE->first_line,target_line);
    for(i=0;i>number_lines;i--)
      {
       curr->select = CURRENT_VIEW->display_high;
       curr = curr->prev;
       if (curr->prev == NULL
       ||  in_scope(curr))
          break;
      }
   }
 else
/*---------------------------------------------------------------------*/
/* For a positive target, show the lines from the start of the excluded*/
/* block.                                                              */
/*---------------------------------------------------------------------*/
   {
    for(i=0;i<number_lines;i++)
      {
       curr->select = CURRENT_VIEW->display_high;
       curr = curr->next;
       if (curr->next == NULL
       ||  in_scope(curr))
          break;
      }
   }
 return(rc);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_exclude(PPC *curr_ppc,short cmd_idx,LINETYPE number_lines)
#else
static short prefix_exclude(curr_ppc,cmd_idx,number_lines)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_lines;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 short rc=RC_OK;
 LINETYPE top_line = curr_ppc->ppc_line_number;
 LINE *curr=NULL;
 short direction=DIRECTION_FORWARD;
/*--------------------------- processing ------------------------------*/
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 if (TOF(top_line)
 ||  BOF(top_line))
    return(-1);
/*---------------------------------------------------------------------*/
/* If the high value of SET DISPLAY is 255, we can't exclude any lines */
/* so exit.                                                            */
/*---------------------------------------------------------------------*/
 if (CURRENT_VIEW->display_high == 255)
    return(rc);
 if (number_lines < 0)
    direction = DIRECTION_BACKWARD;
 else
    direction = DIRECTION_FORWARD;
/*---------------------------------------------------------------------*/
/* Find the current line from where we start excluding...              */
/*---------------------------------------------------------------------*/
 curr = lll_find(CURRENT_FILE->first_line,top_line);
/*---------------------------------------------------------------------*/
/* For the number of lines affected, change the select level if the    */
/* line is in scope.                                                   */
/*---------------------------------------------------------------------*/
 while(number_lines != 0)
   {
    if (in_scope(curr))
       curr->select = (short)CURRENT_VIEW->display_high + 1;
    if (direction == DIRECTION_FORWARD)
       curr = curr->next;
    else
       curr = curr->prev;
    number_lines -= direction;
   }
 return(rc);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_add(PPC *curr_ppc,short cmd_idx,LINETYPE number_lines)
#else
static short prefix_add(curr_ppc,cmd_idx,number_lines)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_lines;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 short rc=(-1);
 LINETYPE top_line = curr_ppc->ppc_line_number;
/*--------------------------- processing ------------------------------*/
 if (top_line == CURRENT_FILE->number_lines+1)
    top_line--;
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 rc = insert_new_line((CHARTYPE *)"",0,number_lines,
                     top_line,FALSE,FALSE,CURRENT_VIEW->display_low);
 return(rc);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_duplicate(PPC *curr_ppc,short cmd_idx,LINETYPE number_occ)
#else
static short prefix_duplicate(curr_ppc,cmd_idx,number_occ)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_occ;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 short rc=(-1);
 LINETYPE top_line = curr_ppc->ppc_line_number;
/*--------------------------- processing ------------------------------*/
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 if (top_line != 0L
 &&  top_line != CURRENT_FILE->number_lines+1)
    rc = rearrange_line_blocks(COMMAND_DUPLICATE,SOURCE_PREFIX,top_line,top_line,top_line,(short)number_occ,CURRENT_VIEW,CURRENT_VIEW,TRUE);
 return(rc);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_copy(PPC *curr_ppc,short cmd_idx,LINETYPE number_lines)
#else
static short prefix_copy(curr_ppc,cmd_idx,number_lines)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_lines;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 LINETYPE bottom_line=0L,target_line=0L;
 LINETYPE top_line = curr_ppc->ppc_line_number;
 PPC *target_ppc=NULL;
 short rc=(-1);
/*--------------------------- processing ------------------------------*/
 if ((target_ppc = calculate_target_line()) == NULL)
    return(rc);
 target_line = target_ppc->ppc_line_number+target_ppc->ppc_cmd_param;
 bottom_line = top_line + number_lines - ((number_lines < 0L) ? (-1L) : 1L);
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 if (top_line != 0L
 &&  top_line != CURRENT_FILE->number_lines+1)
    rc = rearrange_line_blocks(COMMAND_COPY,SOURCE_PREFIX,top_line,bottom_line,target_line,1,CURRENT_VIEW,CURRENT_VIEW,TRUE);
 return(rc);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_move(PPC *curr_ppc,short cmd_idx,LINETYPE number_lines)
#else
static short prefix_move(curr_ppc,cmd_idx,number_lines)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_lines;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 LINETYPE bottom_line=0L,target_line=0L;
 LINETYPE top_line = curr_ppc->ppc_line_number;
 PPC *target_ppc=NULL;
 short rc=(-1);
/*--------------------------- processing ------------------------------*/
 if ((target_ppc = calculate_target_line()) == NULL)
    return(rc);
 target_line = target_ppc->ppc_line_number+target_ppc->ppc_cmd_param;
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 bottom_line = top_line + number_lines - ((number_lines < 0L) ? (-1L) : 1L);

 if (top_line != 0L
 &&  top_line != CURRENT_FILE->number_lines+1)
   {
    if ((rc = rearrange_line_blocks(COMMAND_MOVE_COPY_SAME,SOURCE_PREFIX,
         top_line,bottom_line,target_line,1,CURRENT_VIEW,CURRENT_VIEW,TRUE)) != RC_OK)
       return(rc);
    if (target_line < top_line)
      {
       top_line += number_lines;
       target_line += number_lines;
       bottom_line += number_lines;
      }
    rc = rearrange_line_blocks(COMMAND_MOVE_DELETE_SAME,SOURCE_PREFIX,
         top_line,bottom_line,target_line,1,CURRENT_VIEW,CURRENT_VIEW,TRUE);
   }
 return(rc);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_delete(PPC *curr_ppc,short cmd_idx,LINETYPE number_lines)
#else
static short prefix_delete(curr_ppc,cmd_idx,number_lines)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_lines;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 short rc=(-1);
 LINETYPE top_line = curr_ppc->ppc_line_number;
 LINETYPE bottom_line=0L,target_line=0L;
/*--------------------------- processing ------------------------------*/

 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 if (!TOF(top_line)
 &&  !BOF(top_line))
   {
    bottom_line = top_line + number_lines - ((number_lines < 0L) ? (-1L) : 1L);
    target_line = (number_lines < 0L) ? (bottom_line) : (top_line);
    rc = rearrange_line_blocks(COMMAND_DELETE,SOURCE_PREFIX,top_line,bottom_line,target_line,1,CURRENT_VIEW,CURRENT_VIEW,TRUE);
   }
 return(rc);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_shift_left(PPC *curr_ppc,short cmd_idx,LINETYPE number_cols)
#else
static short prefix_shift_left(curr_ppc,cmd_idx,number_cols)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_cols;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 LINETYPE top_line = curr_ppc->ppc_line_number;
/*--------------------------- processing ------------------------------*/
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 if (top_line != 0L
 &&  top_line != CURRENT_FILE->number_lines+1)
   {
    execute_shift_command(TRUE,(short)number_cols,top_line,1L,TRUE);
   }
 return(0);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_shift_right(PPC *curr_ppc,short cmd_idx,LINETYPE number_cols)
#else
static short prefix_shift_right(curr_ppc,cmd_idx,number_cols)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_cols;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 LINETYPE start_line = curr_ppc->ppc_line_number;
/*--------------------------- processing ------------------------------*/
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 if (start_line != 0L
 &&  start_line != CURRENT_FILE->number_lines+1)
   {
    execute_shift_command(FALSE,(short)number_cols,start_line,1L,TRUE);
   }
 return(0);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_block_duplicate(PPC *curr_ppc,short cmd_idx,LINETYPE number_occ)
#else
static short prefix_block_duplicate(curr_ppc,cmd_idx,number_occ)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_occ;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 short rc=(-1);
 LINETYPE top_line=0L,bottom_line=0L;
 PPC *bottom_ppc=NULL;
/*--------------------------- processing ------------------------------*/
 if ((bottom_ppc = find_bottom_ppc(curr_ppc,cmd_idx)) == NULL)
    return(rc);
 top_line = min(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);
 bottom_line = max(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);
 top_line = (top_line == 0L) ? 1L : top_line;
 bottom_line = (bottom_line == CURRENT_FILE->number_lines+1L) ? bottom_line-1L : bottom_line;
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 clear_pending_prefix_command(bottom_ppc,(LINE *)NULL);
 rc = rearrange_line_blocks(COMMAND_DUPLICATE,SOURCE_PREFIX,top_line,bottom_line,bottom_line,(short)number_occ,CURRENT_VIEW,CURRENT_VIEW,FALSE);
 return(rc);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_block_copy(PPC *curr_ppc,short cmd_idx,LINETYPE number_lines)
#else
static short prefix_block_copy(curr_ppc,cmd_idx,number_lines)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_lines;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 short rc=(-1);
 LINETYPE top_line=0L,bottom_line=0L,target_line=0L;
 PPC *bottom_ppc=NULL;
 PPC *target_ppc=NULL;
/*--------------------------- processing ------------------------------*/
 if ((bottom_ppc = find_bottom_ppc(curr_ppc,cmd_idx)) == NULL)
    return(rc);
 if ((target_ppc = calculate_target_line()) == NULL)
    return(rc);
 target_line = target_ppc->ppc_line_number+target_ppc->ppc_cmd_param;
 top_line = min(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);
 bottom_line = max(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);
 top_line = (top_line == 0L) ? 1L : top_line;
 bottom_line = (bottom_line == CURRENT_FILE->number_lines+1L) ? bottom_line-1L : bottom_line;
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 clear_pending_prefix_command(bottom_ppc,(LINE *)NULL);
 rc = rearrange_line_blocks(COMMAND_COPY,SOURCE_PREFIX,top_line,bottom_line,target_line,1,CURRENT_VIEW,CURRENT_VIEW,FALSE);
 return(rc);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_block_move(PPC *curr_ppc,short cmd_idx,LINETYPE number_lines)
#else
static short prefix_block_move(curr_ppc,cmd_idx,number_lines)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_lines;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 short rc=(-1);
 LINETYPE top_line=0L,bottom_line=0L,target_line=0L,num_lines=0L;
 PPC *bottom_ppc=NULL;
 PPC *target_ppc=NULL;
/*--------------------------- processing ------------------------------*/
 if ((bottom_ppc = find_bottom_ppc(curr_ppc,cmd_idx)) == NULL)
    return(rc);
 if ((target_ppc = calculate_target_line()) == NULL)
    return(rc);
 target_line = target_ppc->ppc_line_number+target_ppc->ppc_cmd_param;
 top_line = min(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);
 bottom_line = max(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);
 top_line = (top_line == 0L) ? 1L : top_line;
 bottom_line = (bottom_line == CURRENT_FILE->number_lines+1L) ? bottom_line-1L : bottom_line;
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 clear_pending_prefix_command(bottom_ppc,(LINE *)NULL);
 if ((rc = rearrange_line_blocks(COMMAND_MOVE_COPY_SAME,SOURCE_PREFIX,
           top_line,bottom_line,target_line,1,CURRENT_VIEW,CURRENT_VIEW,FALSE)) != RC_OK)
    return(rc);
 if (target_line < top_line)
   {
    num_lines = bottom_line - top_line + 1L;
    top_line += num_lines;
    bottom_line += num_lines;
    target_line += num_lines;
   }
 rc = rearrange_line_blocks(COMMAND_MOVE_DELETE_SAME,SOURCE_PREFIX,
      top_line,bottom_line,target_line,1,CURRENT_VIEW,CURRENT_VIEW,FALSE);
 return(rc);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_block_delete(PPC *curr_ppc,short cmd_idx,LINETYPE number_lines)
#else
static short prefix_block_delete(curr_ppc,cmd_idx,number_lines)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_lines;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 short rc=(-1);
 LINETYPE top_line=0L,bottom_line=0L;
 PPC *bottom_ppc=NULL;
/*--------------------------- processing ------------------------------*/
 if ((bottom_ppc = find_bottom_ppc(curr_ppc,cmd_idx)) == NULL)
    return(rc);
 top_line = min(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);
 bottom_line = max(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);
 top_line = (top_line == 0L) ? 1L : top_line;
 bottom_line = (bottom_line == CURRENT_FILE->number_lines+1L) ? bottom_line-1L : bottom_line;
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 clear_pending_prefix_command(bottom_ppc,(LINE *)NULL);
 rc = rearrange_line_blocks(COMMAND_DELETE,SOURCE_PREFIX,top_line,bottom_line,bottom_line,1,CURRENT_VIEW,CURRENT_VIEW,FALSE);
 return(rc);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_block_shift_left(PPC *curr_ppc,short cmd_idx,LINETYPE number_cols)
#else
static short prefix_block_shift_left(curr_ppc,cmd_idx,number_cols)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_cols;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 LINETYPE top_line=0L,bottom_line=0L;
 PPC *bottom_ppc;
/*--------------------------- processing ------------------------------*/
 if ((bottom_ppc = find_bottom_ppc(curr_ppc,cmd_idx)) == NULL)
    return(-1);
 top_line = min(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);
 bottom_line = max(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);

 top_line = (top_line == 0L) ? 1L : top_line;
 bottom_line = (bottom_line == CURRENT_FILE->number_lines+1L) ? bottom_line-1L : bottom_line;
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 clear_pending_prefix_command(bottom_ppc,(LINE *)NULL);

 execute_shift_command(TRUE,(short)number_cols,top_line,bottom_line-top_line+1L,FALSE);

 return(0);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_block_shift_right(PPC *curr_ppc,short cmd_idx,LINETYPE number_cols)
#else
static short prefix_block_shift_right(curr_ppc,cmd_idx,number_cols)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_cols;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 LINETYPE top_line=0L,bottom_line=0L;
 PPC *bottom_ppc=NULL;
/*--------------------------- processing ------------------------------*/
 if ((bottom_ppc = find_bottom_ppc(curr_ppc,cmd_idx)) == NULL)
    return(-1);
 top_line = min(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);
 bottom_line = max(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);

 top_line = (top_line == 0L) ? 1L : top_line;
 bottom_line = (bottom_line == CURRENT_FILE->number_lines+1L) ? bottom_line-1L : bottom_line;
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 clear_pending_prefix_command(bottom_ppc,(LINE *)NULL);

 execute_shift_command(FALSE,(short)number_cols,top_line,bottom_line-top_line+1L,FALSE);

 return(0);
}
/***********************************************************************/
#ifdef PROTO
static short prefix_block_exclude(PPC *curr_ppc,short cmd_idx,LINETYPE number_lines)
#else
static short prefix_block_exclude(curr_ppc,cmd_idx,number_lines)
PPC *curr_ppc;
short cmd_idx;
LINETYPE number_lines;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 short rc=RC_OK;
 LINETYPE top_line=0L,bottom_line=0L,num_lines=0L,i=0L;
 LINE *curr=NULL;
 PPC *bottom_ppc=NULL;
/*--------------------------- processing ------------------------------*/
 if ((bottom_ppc = find_bottom_ppc(curr_ppc,cmd_idx)) == NULL)
    return(-1);
 top_line = min(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);
 bottom_line = max(curr_ppc->ppc_line_number,bottom_ppc->ppc_line_number);
 top_line = (top_line == 0L) ? 1L : top_line;
 bottom_line = (bottom_line == CURRENT_FILE->number_lines+1L) ? bottom_line-1L : bottom_line;
 num_lines = bottom_line-top_line+1L;
 clear_pending_prefix_command(curr_ppc,(LINE *)NULL);
 clear_pending_prefix_command(bottom_ppc,(LINE *)NULL);
/*---------------------------------------------------------------------*/
/* If the high value of SET DISPLAY is 255, we can't exclude any lines */
/* so exit.                                                            */
/*---------------------------------------------------------------------*/
 if (CURRENT_VIEW->display_high == 255)
    return(rc);
/*---------------------------------------------------------------------*/
/* Find the current line from where we start excluding...              */
/*---------------------------------------------------------------------*/
 curr = lll_find(CURRENT_FILE->first_line,top_line);
/*---------------------------------------------------------------------*/
/* For the number of lines affected, change the select level if the    */
/* line is in scope.                                                   */
/*---------------------------------------------------------------------*/
 for (i=0;i<num_lines;i++)
   {
    if (in_scope(curr))
       curr->select = (short)CURRENT_VIEW->display_high + 1;
    curr = curr->next;
   }
 return(rc);
}
/***********************************************************************/
#ifdef PROTO
static short invalidate_prefix(PPC *curr_ppc)
#else
static short invalidate_prefix(curr_ppc)
PPC *curr_ppc;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
 extern short prefix_width;
/*--------------------------- local data ------------------------------*/
 short len=0;
/*--------------------------- processing ------------------------------*/
 if (*(curr_ppc->ppc_command) != '?')
   {
    len = strlen(curr_ppc->ppc_command);
    meminschr(curr_ppc->ppc_command,'?',0,prefix_width,len);
    *(curr_ppc->ppc_command+len+1) = '\0';
   }
/*---------------------------------------------------------------------*/
/* ensure that there is no chance that a 'real' prefix command can be  */
/* executed.                                                           */
/*---------------------------------------------------------------------*/
 curr_ppc->ppc_cmd_idx = (-2);
 return(RC_OK);
}
/***********************************************************************/
#ifdef PROTO
void clear_pending_prefix_command(PPC *curr_ppc,LINE *curr_line)
#else
void clear_pending_prefix_command(curr_ppc,curr_line)
PPC *curr_ppc;
LINE *curr_line;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 LINE *curr=curr_line;
/*--------------------------- processing ------------------------------*/
/*---------------------------------------------------------------------*/
/* If curr_ppc == NULL, then do nothing.                               */
/*---------------------------------------------------------------------*/
 if (curr_ppc == NULL)
    return;
 if (curr == (LINE *)NULL)
    curr = lll_find(CURRENT_FILE->first_line,curr_ppc->ppc_line_number);
 curr->pre = NULL;
 curr_ppc->ppc_cmd_idx = (-1);
 curr_ppc->ppc_block_command = FALSE;
 return;
}
/***********************************************************************/
#ifdef PROTO
PPC *delete_pending_prefix_command(PPC *curr_ppc,FILE_DETAILS *curr_file,LINE *curr_line)
#else
PPC *delete_pending_prefix_command(curr_ppc,curr_file,curr_line)
PPC *curr_ppc;
FILE_DETAILS *curr_file;
LINE *curr_line;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 LINE *curr=curr_line;
 PPC *return_ppc=NULL;
/*--------------------------- processing ------------------------------*/
/*---------------------------------------------------------------------*/
/* If curr_ppc == NULL, then do nothing.                               */
/*---------------------------------------------------------------------*/
 if (curr_ppc == NULL)
    return(NULL);
 if (curr == (LINE *)NULL)
    curr = lll_find(curr_file->first_line,curr_ppc->ppc_line_number);
 curr->pre = NULL;
 return_ppc = pll_del(&(curr_file->first_ppc),&(curr_file->last_ppc),curr_ppc,DIRECTION_FORWARD);
 return(return_ppc);
}
/***********************************************************************/
#ifdef PROTO
static PPC *find_bottom_ppc(PPC *curr_ppc,short top_cmd_idx)
#else
static PPC *find_bottom_ppc(curr_ppc,top_cmd_idx)
PPC *curr_ppc;
short top_cmd_idx;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 PPC *bottom_ppc=curr_ppc;
/*--------------------------- processing ------------------------------*/
 while(bottom_ppc != NULL)
   {
    if (bottom_ppc != curr_ppc)
      {
       if (top_cmd_idx == curr_ppc->ppc_cmd_idx)
          return(bottom_ppc);
      }
    bottom_ppc = bottom_ppc->next;
   }
 return(NULL);
}
/***********************************************************************/
#ifdef PROTO
static PPC *find_target_ppc(void)
#else
static PPC *find_target_ppc()
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 PPC *target_ppc=NULL;
/*--------------------------- processing ------------------------------*/
 target_ppc = CURRENT_FILE->first_ppc;
 while(target_ppc != NULL)
   {
    if (target_ppc->ppc_cmd_idx == PPC_TARGET_PREVIOUS
    ||  target_ppc->ppc_cmd_idx == PPC_TARGET_FOLLOWING)
       return(target_ppc);
    target_ppc = target_ppc->next;
   }
 return(NULL);
}
/***********************************************************************/
#ifdef PROTO
static PPC *calculate_target_line(void)
#else
static PPC *calculate_target_line()
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 PPC *target_ppc=NULL;
/*--------------------------- processing ------------------------------*/
 if ((target_ppc = find_target_ppc()) == NULL)
    return(NULL);
 target_ppc->ppc_cmd_param = 0L;
/*---------------------------------------------------------------------*/
/* If the target line is NOT top of file line and the target type is   */
/* PREVIOUS, subtract 1 from the target line.                          */
/*---------------------------------------------------------------------*/
 if (target_ppc->ppc_cmd_idx == PPC_TARGET_PREVIOUS
 && !TOF(target_ppc->ppc_line_number))
    target_ppc->ppc_cmd_param = (-1);
/*---------------------------------------------------------------------*/
/* If the target line is the bottom of file and the target type is     */
/* FOLLOWING, sutract 1 from the target line.                          */
/*---------------------------------------------------------------------*/
 if (target_ppc->ppc_cmd_idx == PPC_TARGET_FOLLOWING
 && BOF(target_ppc->ppc_line_number))
    target_ppc->ppc_cmd_param = (-1);
 clear_pending_prefix_command(target_ppc,(LINE *)NULL);
 return(target_ppc);
}
/***********************************************************************/
#ifdef PROTO
static short try_rexx_prefix_macro(PPC *curr_ppc)
#else
static short try_rexx_prefix_macro(curr_ppc)
PPC *curr_ppc;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
 extern CHARTYPE *temp_cmd;
/*--------------------------- local data ------------------------------*/
 short ctr=0, parm_length=0, pmacro_rc=0, errnum = 0 ;
 bool found_left=FALSE, found_right=FALSE;
 LINETYPE line_number=0L;
 CHARTYPE pm_parms[(PREFIX_WIDTH*4)+1], t_area[PREFIX_WIDTH+1],
      parms[PREFIX_WIDTH+1], tmpstr[PREFIX_WIDTH+1], 
      orig_cmd[PREFIX_WIDTH+1];
/*--------------------------- processing ------------------------------*/
 strcpy(orig_cmd, curr_ppc->ppc_command);

 found_right = FALSE;
 found_left = FALSE;
/*---------------------------------------------------------------------*/
/* Scan 'orig_cmd' from right to left looking for an embedded macro    */
/* file name.                                                          */
/*---------------------------------------------------------------------*/
 for (ctr = strlen(orig_cmd); ctr >= 0 && !found_right; ctr--)
   {
    substr(&tmpstr[0], orig_cmd, 1, ctr);
    strcpy(t_area, tmpstr);
/*---------------------------------------------------------------------*/
/* First check if the prefix command is a synonym.                     */
/*---------------------------------------------------------------------*/
/* check for prefix synonym, if so use the macro name not the synonym */
    get_valid_macro_file_name(find_prefix_synonym(t_area),temp_cmd,&errnum);

    if (errnum == 0)
       found_right = TRUE;
   }

/*---------------------------------------------------------------------*/
/* No valid macro file name found ?                                    */
/*                                                                     */
/* Scan 'temp_cmd' from left to right looking for an embedded macro    */
/* file name.                                                          */
/*---------------------------------------------------------------------*/
 if (!found_right)
   for ( ctr = 0; ctr <= strlen(orig_cmd) && !found_left; ctr++)
     {
      substr(&tmpstr[0], orig_cmd, ctr + 1, strlen(temp_cmd) - ctr);
      strcpy(t_area, tmpstr);
/*---------------------------------------------------------------------*/
/* First check if the prefix command is a synonym.                     */
/*---------------------------------------------------------------------*/
/* check for prefix synonym, if so use the macro name not the synonym */
      get_valid_macro_file_name(find_prefix_synonym(t_area),temp_cmd,&errnum);

      if (errnum == 0)
         found_left = TRUE;
     }

 if (found_right || found_left)
   {
    parm_length = strlen(orig_cmd) - strlen(t_area);

    if (found_right)
       substr(&tmpstr[0],orig_cmd,strlen(t_area) + 1,parm_length);
    else
       substr(&tmpstr[0],orig_cmd,1,parm_length);

    strcpy(parms, tmpstr);
    line_number = curr_ppc->ppc_line_number;
    sprintf(pm_parms," PREFIX %ld %s",line_number,parms);
    strcat(temp_cmd, pm_parms);     /* add on the parameter list */
    prefix_current_line = line_number;
    in_prefix_macro = TRUE;
    pmacro_rc = execute_macro(temp_cmd,TRUE);
    in_prefix_macro = FALSE;
   }
 else
    pmacro_rc = RC_NOT_COMMAND;

 return(pmacro_rc);
}
/***********************************************************************/
#ifdef PROTO
static CHARTYPE *substr(CHARTYPE *temp_string,CHARTYPE *string,short start,short length)
#else
static CHARTYPE *substr(temp_string, string, start, length)
CHARTYPE *temp_string, *string;
short start, length;
#endif
/***********************************************************************/
/* This function is like the REXX SUBSTR function, it returns a        */
/* pointer to a string containing the result.                          */
/* Note: The address of the beginning of a blank string is passed to be*/
/* modified by address: substr(&tmpstr[0],<string>,<start>,<length>);  */
/* ( In this case, the result is contained in 'tmpstr'  :-)            */
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 register i=0, target_idx = 0;
/*--------------------------- processing ------------------------------*/
 for (i = start - 1; target_idx <= length - 1; i++)
    temp_string[target_idx++] = string[i];
 temp_string[target_idx] = '\0';   /*MH*/
 return(temp_string);
}
/***********************************************************************/
#ifdef PROTO
void add_prefix_command(LINE *curr,LINETYPE line_number,bool block_command)
#else
void add_prefix_command(curr,line_number,block_command)
LINE *curr;
LINETYPE line_number;
bool block_command;
#endif
/***********************************************************************/
{
/*------------------------- external data -----------------------------*/
 extern bool prefix_changed;
 extern CHARTYPE *pre_rec;
 extern unsigned short pre_rec_len;
/*--------------------------- local data ------------------------------*/
 register short i=0;
 short prefix_index=0;
 CHARTYPE temp_prefix_array[PREFIX_WIDTH+1];
 PPC *curr_ppc=NULL;
 bool redisplay_screen=FALSE;
/*--------------------------- processing ------------------------------*/
#ifdef TRACE
 trace_function("prefix.c:  add_prefix_command");
#endif
 prefix_changed = FALSE;
/*---------------------------------------------------------------------*/
/* Copy the contexts of the prefix record area into a temporary area.  */
/*---------------------------------------------------------------------*/
 for (i=0;i<pre_rec_len;i++)
     temp_prefix_array[i] = pre_rec[i];
 temp_prefix_array[pre_rec_len] = '\0';
 strtrunc(temp_prefix_array);
/*---------------------------------------------------------------------*/
/* If the prefix record area is blank, clear the pending prefix area.  */
/*---------------------------------------------------------------------*/
 if (blank_field(temp_prefix_array))
   {
    (void)delete_pending_prefix_command(curr->pre,CURRENT_FILE,curr);
    redisplay_screen = TRUE;
   }
 else
   {
/*---------------------------------------------------------------------*/
/* If the input line already points to an entry in the array, use the  */
/* existing entry in the array, otherwise add to the next entry.       */
/*---------------------------------------------------------------------*/
    curr_ppc = pll_find(CURRENT_FILE->first_ppc,line_number);
    if (curr_ppc == NULL)  /* not found */
      {
       CURRENT_FILE->last_ppc = pll_add(CURRENT_FILE->first_ppc,CURRENT_FILE->last_ppc,sizeof(PPC));
       if (CURRENT_FILE->last_ppc == NULL)
         {
          display_error(30,"",FALSE);
#ifdef TRACE
          trace_return();
#endif
          return;
         }
       if (CURRENT_FILE->first_ppc == NULL)
          CURRENT_FILE->first_ppc = CURRENT_FILE->last_ppc;
       curr_ppc = CURRENT_FILE->last_ppc;
      }
    curr->pre = curr_ppc;
    strcpy(curr_ppc->ppc_command,temp_prefix_array);
    curr_ppc->ppc_line_number = line_number;
    curr_ppc->ppc_block_command = block_command;
    curr_ppc->ppc_cmd_idx = (-1);
   }
/*---------------------------------------------------------------------*/
/* Clear the pending prefix command line.                              */
/*---------------------------------------------------------------------*/
 memset(pre_rec,' ',PREFIX_WIDTH);
 pre_rec_len = 0;
 pre_rec[PREFIX_WIDTH] = '\0';
 if (redisplay_screen)
   {
    build_current_screen();
    display_current_screen();
   }
#ifdef TRACE
 trace_return();
#endif
 return;
}
/***********************************************************************/
#ifdef PROTO
short add_prefix_synonym(CHARTYPE *synonym,CHARTYPE *macroname)
#else
short add_prefix_synonym(synonym,macroname)
CHARTYPE *synonym,*macroname;
#endif
/***********************************************************************/
/* Parameters:                                                         */
/*    synonym: synonym for prefix macro                                */
/*  macroname: name of REXX macro file                                 */
/***********************************************************************/
{
/*--------------------------- local data ------------------------------*/
 LINE *curr=NULL;
/*--------------------------- processing ------------------------------*/
#ifdef TRACE
 trace_function("prefix.c:  add_prefix_synonym");
#endif
/*---------------------------------------------------------------------*/
/* First thing is to delete any definitions that may exist for the     */
/* supplied synonym.                                                   */
/*---------------------------------------------------------------------*/
 curr = first_prefix_synonym;
 while(curr != NULL)
   {
    if (strcmp(curr->name,synonym) == 0)
      {
       if (curr->name != NULL)
          (*the_free)(curr->name);
       if (curr->line != NULL)
          (*the_free)(curr->line);
       curr = lll_del(&first_prefix_synonym,&last_prefix_synonym,curr,DIRECTION_FORWARD);
      }
    else
       curr = curr->next;
   }
/*---------------------------------------------------------------------*/
/* Lastly append the synonym at the end of the linked list.            */
/*---------------------------------------------------------------------*/
 curr = lll_add(first_prefix_synonym,last_prefix_synonym,sizeof(LINE));
 if (curr == NULL)
   {
    display_error(30,(CHARTYPE *)"",FALSE);
#ifdef TRACE
    trace_return();
#endif
    return(RC_OUT_OF_MEMORY);
   }
 curr->line = (CHARTYPE *)(*the_malloc)((strlen(macroname)+1)*sizeof(CHARTYPE));
 if (curr->line == NULL)
   {
    display_error(30,(CHARTYPE *)"",FALSE);
#ifdef TRACE
    trace_return();
#endif
    return(RC_OUT_OF_MEMORY);
   }
 strcpy(curr->line,macroname);
 curr->name = (CHARTYPE *)(*the_malloc)((strlen(synonym)+1)*sizeof(CHARTYPE));
 if (curr->name == NULL)
   {
    display_error(30,(CHARTYPE *)"",FALSE);
#ifdef TRACE
    trace_return();
#endif
    return(RC_OUT_OF_MEMORY);
   }
 strcpy(curr->name,synonym);
 last_prefix_synonym = curr;
 if (first_prefix_synonym == NULL)
    first_prefix_synonym = last_prefix_synonym;
#ifdef TRACE
 trace_return();
#endif
 return(RC_OK);
}
/*man***************************************************************************
NAME
     find_prefix_synonym

SYNOPSIS
     CHARTYPE *find_prefix_synonym(synonym)
     CHARTYPE *synonym;

DESCRIPTION
     The find_prefix_synonym function finds a synonym for 'synonym'
     and returns that value. If no synonym exists, the 'synonym' is
     returned unchanged.

     This function is only available if REXX support is available.
     
RETURN VALUE
     Either the macroname associated with 'synonym' or 'synonym'.
*******************************************************************************/
#ifdef PROTO
CHARTYPE *find_prefix_synonym(CHARTYPE *synonym)
#else
CHARTYPE *find_prefix_synonym(synonym)
CHARTYPE *synonym;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 LINE *curr=NULL;
/*--------------------------- processing ------------------------------*/
#ifdef TRACE
 trace_function("prefix.c:  find_prefix_synonym");
#endif
 curr = first_prefix_synonym;
 while(curr != NULL)
   {
    if (strcmp(synonym,(CHARTYPE *)curr->name) == 0)
      {
#ifdef TRACE
       trace_return();
#endif
       return((CHARTYPE *)curr->line);
      }
    curr = curr->next;
   }
#ifdef TRACE
 trace_return();
#endif
 return(synonym);
}
/*man***************************************************************************
NAME
     find_prefix_oldname

SYNOPSIS
     CHARTYPE *find_prefix_oldname(oldname)
     CHARTYPE *oldname;

DESCRIPTION
     The find_prefix_oldname function finds the synonym for
     'oldname' and returns that value. If no synonym exists, the 
     'oldname' is returned unchanged.

     This function is only available if REXX support is available.
     
RETURN VALUE
     Either the synonym associated with 'oldname' or 'oldname'.
*******************************************************************************/
#ifdef PROTO
CHARTYPE *find_prefix_oldname(CHARTYPE *oldname)
#else
CHARTYPE *find_prefix_oldname(oldname)
CHARTYPE *oldname;
#endif
/***********************************************************************/
{
/*-------------------------- external data ----------------------------*/
/*--------------------------- local data ------------------------------*/
 LINE *curr=NULL;
/*--------------------------- processing ------------------------------*/
#ifdef TRACE
 trace_function("prefix.c:  find_prefix_oldname");
#endif
 curr = first_prefix_synonym;
 while(curr != NULL)
   {
    if (strcmp(oldname,(CHARTYPE *)curr->line) == 0)
      {
#ifdef TRACE
       trace_return();
#endif
       return(curr->name);
      }
    curr = curr->next;
   }
#ifdef TRACE
 trace_return();
#endif
 return(oldname);
}
/***********************************************************************/
#ifdef PROTO
CHARTYPE *get_prefix_command(LINETYPE prefix_index)
#else
CHARTYPE *get_prefix_command(prefix_index)
LINETYPE prefix_index;
#endif
/***********************************************************************/
{
/*--------------------------- local data ------------------------------*/
/*--------------------------- processing ------------------------------*/
#ifdef TRACE
 trace_function("prefix.c:  get_prefix_command");
#endif
/*---------------------------------------------------------------------*/
/* Just return a pointer to the prefix command associated with the     */
/* supplied index.                                                     */
/*---------------------------------------------------------------------*/
#ifdef TRACE
 trace_return();
#endif
 return(pc[prefix_index].cmd);
}
