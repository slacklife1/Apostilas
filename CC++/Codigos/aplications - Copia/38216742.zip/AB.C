/*
	Author: Ga�per Raj�ek, November 2001
	eMail: gape.korn@volja.net
	Translated: 11/8/2002
	Memory Model: SMALL
*/

# include <stdio.h>
# include <conio.h>
# include <alloc.h>
# include <string.h>
# include <stdlib.h>
# include <dir.h>
# include <io.h>
# include <fcntl.h>
# include <ctype.h> // for function "tolower"

// address book main functions
void Add (struct AddressBook **start);
void RemovePerson (struct AddressBook **start);
void FindPeople (struct AddressBook **start);
int STRCMPI (char string1[], char string2[]); // checking two strings which are type SIGNED CHAR, if they are equal, without CASE SENSITIVE
void PrintPersonOnScreen (struct AddressBook **start);
void PrintPersonOnPrinter (struct AddressBook **start);
void PrintPersonIntoFile (struct AddressBook **start);
void PrintAllDataOnScreen (struct AddressBook **start);
void PrintAllDataOnPrinter (struct AddressBook **start);
void PrintAllDataIntoFile (struct AddressBook **start);
void WriteOutPeople (struct AddressBook **start);
void PrintOnScreen (char temp[]);
void PrintOnPrinter (char temp[]);
void PrintIntoFile (char temp[], FILE *fout);
void Write (struct AddressBook **start, char file[]);
void Read (struct AddressBook **start, char file[]);
void Write1 (char temp[], FILE *fout);
// functions for selecting language, ...
void SelectLanguage (void);
char *ReadLanguage (char file[], int line);
char *File (void);
char *PathToADRfile (char file1[], char password[]);
int CheckLNGfile (char file[]);
// functions for login user, ...
int LoginUser (char file[], char password[]);
void AddUser (void);
void RemoveUser (void);
void USRfiles (void);
// function for coding and decoding password
char *EncodeDecodePassword (char password[]);
// functions for database statistics
void DatabaseStatistic (struct AddressBook **start);
long int SIZEOF (char temp[]);
long int NumberOfPeople (struct AddressBook **start);
// function for the logo
void Logo (void);

struct AddressBook
{
	char Name[80];
	char Surname[80];
	char Address[80];
	char Http[80];
	char eMail[80];
	char Telephone[80];
	char MobilePhone[80];
	struct AddressBook *next;
};

const char NEW_LINE_CHAR       = '\n';
const char PROG_VERSION[]      = "ADDRESS BOOK v2.1";
const char SEARCH_LNG_FILES[]  = "./DATA/LANGUAGE/*.lng";  // search for "*.lng" files in directory "/DATA/LANGUAGE/"
const char SEARCH_USR_FILES[]  = "./DATA/USERS/*.usr";     // search for "*.usr" files in directory "/DATA/USERS/"
const char LANGUAGE_DAT_FILE[] = "./DATA/language.dat";
const char LOGO_DAT_FILE[]     = "./DATA/logo.dat";
const char LANGUAGE_DIR[]      = "./DATA/LANGUAGE/";
const char USERS_DIR[]         = "./DATA/USERS/";
const int  PASSWORD            = 1; // password is in the second line of the "*.usr" file
const int  PATH_TO_ADR_FILE    = 2; // path to "*.adr" file is in the third line of the "*.usr" file

int main()
{
	struct AddressBook **start;
	int i=0, ch=0, selection1=0, selection2=0, selection3=0, counter1=0, counter2=0;
	char file[13], password[100];

	// checking language file
	if (CheckLNGfile (File ()) != -1)
	{
		Logo (); // print logo
		// login, adding and removing user
		do
		{
			counter1 = 0; // always reset counter to 0
			clrscr ();
			printf ("%s\n%s Ga�per Raj�ek, (c) ", PROG_VERSION, ReadLanguage (File (), 1));
			printf ("%s 2001", ReadLanguage (File (), 2));
			printf ("\n\n%s", ReadLanguage (File (), 3));
			printf ("\n%s", ReadLanguage (File (), 4));
			printf ("\n%s", ReadLanguage (File (), 5));
			printf ("\n%s", ReadLanguage (File (), 6));
			printf ("\n\n%s ", ReadLanguage (File (), 7));
			scanf ("%d", &selection1);
			switch (selection1)
			{
				case 1:
					clrscr ();
					printf ("%s", ReadLanguage (File (), 8));
					USRfiles ();
					gets (0);
					printf ("\n\n%s", ReadLanguage (File (), 9));
					printf ("\n\n%s ", ReadLanguage (File (), 10));
					gets (file);
					if (STRCMPI (file, "0") == 0) counter1 = 1;
					if (counter1 != 1)
					{
						printf ("%s ", ReadLanguage (File (), 11));
						for (i=0; i<80; i++)
						{
							ch = getch ();
							if (ch == '\r' || ch == '\n') break;
							if ((ch == '\b') && (i > 0))
							{
								printf ("\b%c\b", ' ');
								i -= 2;
							}
							else
							{
								putc ('*', stdout);
								password[i] = (char) ch;
							}
						}
						password[i] = '\0';
						printf ("\n");
						if (STRCMPI (password, "0") == 0) counter1 = 2;
						if (counter1 != 2)
						{
							counter2 = LoginUser (file, password);
							// reading user personal files
							if (counter2 == 1) // if the entered password was correct
							{
								clrscr ();
								Read (start, PathToADRfile (file, password)); // read from file and fill the memory
								do
								{
									// reading language file
									clrscr ();
									printf ("%s\n%s Ga�per Raj�ek, (c) ", PROG_VERSION, ReadLanguage (File (), 1));
									printf ("%s 2001", ReadLanguage (File (), 2));
									printf ("\n\n%s", ReadLanguage (File (), 12));
									printf ("\n%s", ReadLanguage (File (), 13));
									printf ("\n%s", ReadLanguage (File (), 14));
									printf ("\n%s", ReadLanguage (File (), 15));
									printf ("\n%s", ReadLanguage (File (), 16));
									printf ("\n%s", ReadLanguage (File (), 17));
									printf ("\n\n%s ", ReadLanguage (File (), 18));
									scanf ("%d", &selection2);
									switch (selection2)
									{
										case 1:
											Add (start);
											break;
										case 2:
											do
											{
												clrscr ();
												printf ("%s\n%s Ga�per Raj�ek, (c) ", PROG_VERSION, ReadLanguage (File (), 1));
												printf ("%s 2001", ReadLanguage (File (), 2));
												printf ("\n\n%s", ReadLanguage (File (), 19));
												printf ("\n%s", ReadLanguage (File (), 20));
												printf ("\n%s", ReadLanguage (File (), 21));
												printf ("\n%s", ReadLanguage (File (), 22));
												printf ("\n\n%s ", ReadLanguage (File (), 18));
												scanf ("%d", &selection3);
												switch (selection3)
												{
													case 1:
														do
														{
															clrscr ();
															printf ("%s\n%s Ga�per Raj�ek, (c) ", PROG_VERSION, ReadLanguage (File (), 1));
															printf ("%s 2001", ReadLanguage (File (), 2));
															printf ("\n\n%s", ReadLanguage (File (), 23));
															printf ("\n%s", ReadLanguage (File (), 24));
															printf ("\n%s", ReadLanguage (File (), 25));
															printf ("\n\n%s ", ReadLanguage (File (), 18));
															scanf ("%d", &selection2);
															switch (selection2)
															{
																case 1:
																	PrintAllDataOnScreen (start);
																	break;
																case 2:
																	PrintPersonOnScreen (start);
																	break;
																case 3:
																	break;
																default:
																	printf ("\n%s", ReadLanguage (File (), 26));
																	getch ();
															}
														} while (selection2 != 3);
														break;
													case 2:
														do
														{
															clrscr ();
															printf ("%s\n%s Ga�per Raj�ek, (c) ", PROG_VERSION, ReadLanguage (File (), 1));
															printf ("%s 2001", ReadLanguage (File (), 2));
															printf ("\n\n%s", ReadLanguage (File (), 27));
															printf ("\n%s", ReadLanguage (File (), 28));
															printf ("\n%s", ReadLanguage (File (), 25));
															printf ("\n\n%s ", ReadLanguage (File (), 18));
															scanf ("%d", &selection2);
															switch (selection2)
															{
																case 1:
																	PrintAllDataOnPrinter (start);
																	break;
																case 2:
																	PrintPersonOnPrinter (start);
																	break;
																case 3:
																	break;
																default:
																	printf ("\n%s", ReadLanguage (File (), 26));
																	getch ();
															}
														} while (selection2 != 3);
														break;
													case 3:
														do
														{
															clrscr ();
															printf ("%s\n%s Ga�per Raj�ek, (c) ", PROG_VERSION, ReadLanguage (File (), 1));
															printf ("%s 2001", ReadLanguage (File (), 2));
															printf ("\n\n%s", ReadLanguage (File (), 29));
															printf ("\n%s", ReadLanguage (File (), 30));
															printf ("\n%s", ReadLanguage (File (), 25));
															printf ("\n\n%s ", ReadLanguage (File (), 18));
															scanf ("%d", &selection2);
															switch (selection2)
															{
																case 1:
																	PrintAllDataIntoFile (start);
																	break;
																case 2:
																	PrintPersonIntoFile  (start);
																	break;
																case 3:
																	break;
																default:
																	printf ("\n%s", ReadLanguage (File (), 26));
																	getch ();
															}
														} while (selection2 != 3);
														break;
													case 4:
														break;
													default:
														printf ("\n%s", ReadLanguage (File (), 26));
														getch ();
												}
											} while (selection3 != 4);
											break;
										case 3:
											RemovePerson (start);
											break;
										case 4:
											FindPeople (start);
											break;
										case 5:
											do
											{
												clrscr ();
												printf ("%s\n%s Ga�per Raj�ek, (c) ", PROG_VERSION, ReadLanguage (File (), 1));
												printf ("%s 2001", ReadLanguage (File (), 2));
												printf ("\n\n%s", ReadLanguage (File (), 31));
												printf ("\n%s", ReadLanguage (File (), 32));
												printf ("\n%s", ReadLanguage (File (), 25));
												printf ("\n\n%s ", ReadLanguage (File (), 18));
												scanf ("%d", &selection2);
												switch (selection2)
												{
													case 1:
														DatabaseStatistic (start);
														break;
													case 2:
														SelectLanguage ();
														break;
													case 3:
														break;
													default:
														printf ("\n%s", ReadLanguage (File (), 26));
														getch ();
												}
											} while (selection2 != 3);
											break;
										case 6:
											Write (start, PathToADRfile (file, password)); // reads from memory and writes into a file
											clrscr ();
											break;
										default:
											printf ("\n%s", ReadLanguage (File (), 26));
											getch ();
									}
								} while (selection2 != 6);
							}
						}
					}
					break;
				case 2:
					AddUser ();
					break;
				case 3:
					RemoveUser ();
					break;
				case 4:
					clrscr ();
					break;
				default:
					printf ("\n%s", ReadLanguage (File (), 26));
					getch ();
			}
		} while (selection1 != 4);
	}
	else
	{
		clrscr ();
		printf ("ERROR: File \"%s\" is missing or it is damaged.", LANGUAGE_DAT_FILE);
		printf ("\n\nPress any key to exit to system ...");
		getch ();
		exit (1);
	}
	return 0;
}

// logo function

void Logo ()
{
	FILE *fin;
	unsigned char c=0;
	int i=0;

	fin = fopen (LOGO_DAT_FILE, "rt");

	clrscr ();
	if (fin != NULL)
	{
		while (fscanf (fin, "%c", &c) != EOF)
		{
			for (i=0; i<=26; i++)
			{
				if (c == 97 + i)       c = 32 + i;
				else if (c == 32 + i)  c = 97 + i;
				else if (c == 65 + i)  c = 130 + i;
				else if (c == 130 + i) c = 65 + i;
			}
			printf ("%c", c);
		}
	}
	else
	{
		clrscr ();
		printf ("%s \"%s\" ", ReadLanguage (File (), 33), LOGO_DAT_FILE);
		printf ("%s", ReadLanguage (File (), 34));
		printf ("\n\n%s", ReadLanguage (File (), 35));
		getch ();
		exit (0);
	}
	fclose (fin);
	printf ("\n\n%s", ReadLanguage (File (), 36));
	getch ();
}

// functions for login user, ...

int LoginUser (char file[], char password[])
{
	if (strlen (password) < 5) // password length must not be less then 5 characters
	{
		printf ("\n%s", ReadLanguage (File (), 37));
		printf ("\n%s\n", ReadLanguage (File (), 38));
	}
	if (PathToADRfile (file, password) != NULL)
	{
		printf ("\n%s", ReadLanguage (File (), 39));
		printf ("\n\n%s", ReadLanguage (File (), 36));
		getch ();
		return 1;
	}
	else
	{
		printf ("\n%s", ReadLanguage (File (), 40));
		printf ("\n\n%s", ReadLanguage (File (), 41));
		getch ();
		return 0;
	}
}

char *PathToADRfile (char file1[], char password[]) // it prints path to the "*.adr" file
{
	char file2[30], temp1[100], *temp1ptr=0, temp2[100], *temp2ptr=0, temp3[100], *temp3ptr=0;
	int i=0, j=0, k=0;
	FILE *fin;

	strcpy (file2, USERS_DIR); // copy path to file2
	strcat (file2, file1); // add filename to file2
	fin = fopen (file2, "rt");
	temp1ptr = temp1;
	temp2ptr = temp2;
	temp3ptr = temp3;
	while (fscanf(fin, "%c", temp1ptr) != EOF)
	{
		if (*temp1ptr == '\n') i++;
		if (i == PASSWORD) // correct line
		{
			if (*temp1ptr != '\n') // read to the end of the line
			{
				j++;
			}
			if (j >= 11) // in temp2 write only from the 11 character ahead so I can avoid from the "Password: " text
			{
				*temp2ptr = *temp1ptr;
				temp2ptr++;
			}
			*temp2ptr = '\0'; // add \0 - end of the string
		}
		if (i == PATH_TO_ADR_FILE) // temp3 fills with the correct line
		{
			if (*temp1ptr != '\n') // read to the end of the line
			{
				k++;
			}
			if (k >= 7) // in temp2 write only from the 7 character ahead so I can avoid from the "Path: " text
			{
				*temp3ptr = *temp1ptr;
				temp3ptr++;
			}
			*temp3ptr = '\0'; // add \0 - end of the string
		}
	}
	fclose (fin);
	if (STRCMPI (password, EncodeDecodePassword (temp2)) == 0) // decode password and compare it with the entered password
	{
		return temp3; // return path to the "*.adr" file
	}
	else
	{
		return NULL;
	}
}

void USRfiles () // show *.usr files in "./DATA/USERS/" directory
{
	struct ffblk file1;
	int Search=0, i=0;

	printf ("\n\n%s\n", ReadLanguage (File (), 42));
	Search = findfirst (SEARCH_USR_FILES, &file1, 0);
	while (!Search)
	{
		i++;
		printf ("\n%s", file1.ff_name);
		Search = findnext (&file1);
	}
	if (i == 0) printf ("\n%s", ReadLanguage (File (), 43));
}

void AddUser ()
{
	char name[100], password[100], file1[13], file2[30], file3[13], file4[30];
	FILE *fout;
	int counter1=0, i=0, ch=0;

	clrscr ();
	printf ("%s", ReadLanguage (File (), 44));
	gets (0);
	printf ("\n\n%s", ReadLanguage (File (), 9));
	printf ("\n\n%s ", ReadLanguage (File (), 45));
	gets (name);
	if (STRCMPI (name, "0") == 0) counter1 = 1;
	if (counter1 != 1)
	{
		do
		{
			printf ("%s ", ReadLanguage (File (), 11));
			for (i=0; i<80; i++)
			{
				ch = getch ();
				if (ch == '\r' || ch == '\n') break;
				if ((ch == '\b') && (i > 0))
				{
					printf ("\b%c\b", ' ');
					i-=2;
				}
				else
				{
					putc ('*', stdout);
					password[i] = (char) ch;
				}
			}
			password[i] = '\0';
			printf ("\n");
			if (STRCMPI (password, "0") == 0) counter1 = 2;
			if (counter1 != 2)
			{
				if (strlen (password) < 5)
				{
					printf ("\n%s", ReadLanguage (File (), 37));
					printf ("\n%s\n\n", ReadLanguage (File (), 38));
				}
			}
			else break;
		}
		while (strlen (password) < 5);
		if (counter1 != 2)
		{
			printf ("%s ", ReadLanguage (File (), 10));
			scanf ("%s", file1);
			if (STRCMPI (file1, "0") == 0) counter1 = 3;
			if (counter1 != 3)
			{
				strcpy (file2, USERS_DIR);
				strcat (file2, file1);
				printf ("%s ", ReadLanguage (File (), 46));
				scanf ("%s", file3);
				if (STRCMPI (file3, "0") == 0) counter1 = 4;
				if (counter1 != 4)
				{
					fout = fopen(file2, "wt+");
					strcpy (file4, USERS_DIR);
					strcat (file4, file3);
					fprintf (fout, "User: %s", name);
					fprintf (fout, "\nPassword: %s", EncodeDecodePassword (password)); // zakodira password
					fprintf (fout, "\nPath: %s", file4);
					fprintf (fout, "\n\n%s", ReadLanguage (File (), 47));
					fclose (fout);
				}
			}
		}
	}
}

void RemoveUser ()
{
	int i=0, j=0, k=0, ch=0, counter1=0;
	char password[100], file1[13], file2[30], file3[13], file4[30], temp1[100], *temp1ptr=0, temp2[100], *temp2ptr=0;
	FILE *fin;

	clrscr ();
	printf ("%s", ReadLanguage (File (), 48));
	USRfiles ();
	printf ("\n\n%s", ReadLanguage (File (), 9));
	printf ("\n\n%s ", ReadLanguage (File (), 10));
	scanf ("%s", file1);
	if (STRCMPI (file1, "0") == 0) counter1 = 1;
	if (counter1 != 1)
	{
		strcpy (file2, USERS_DIR);
		strcat (file2, file1);
		printf ("%s ", ReadLanguage (File (), 46));
		scanf ("%s", file3);
		if (STRCMPI (file3, "0") == 0) counter1 = 2;
		if (counter1 != 2)
		{
			strcpy (file4, USERS_DIR);
			strcat (file4, file3);
			gets (0);
			do
			{
				printf ("%s ", ReadLanguage (File (), 11));
				for (k=0; k<80; k++)
				{
					ch = getch ();
					if (ch == '\r' || ch == '\n') break;
					if ((ch == '\b') && (k > 0))
					{
						printf ("\b%c\b", ' ');
						k -= 2;
					}
					else
					{
						putc ('*', stdout);
						password[k] = (char) ch;
					}
				}
				password[k] = '\0';
				printf ("\n");
				if (STRCMPI (password, "0") == 0) counter1 = 3;
				if (counter1 != 3)
				{
					if (strlen (password) < 5)
					{
						printf ("\n%s", ReadLanguage (File (), 37));
						printf ("\n%s\n\n", ReadLanguage (File (), 38));
					}
				}
				else break;
			}
			while (strlen (password) < 5);
			if (counter1 != 3)
			{
				fin = fopen (file2, "rt");
				temp1ptr = temp1;
				temp2ptr = temp2;
				while (fscanf (fin, "%c", temp1ptr) != EOF)
				{
					if (*temp1ptr == '\n') i++;
					if (i == PASSWORD) // correct line
					{
						if (*temp1ptr != '\n')
						{
							j++;
						}
						if (j >= 11) // in temp2 write only from 11 character ahead so I can avoid from the "Password: " text
						{
							*temp2ptr = *temp1ptr;
							temp2ptr++;
						}
						*temp2ptr = '\0';
					}
				}
				fclose (fin);
				if (STRCMPI (password, EncodeDecodePassword (temp2)) == 0)
				{
					printf ("\n%s\n", ReadLanguage (File (), 39));
					if (remove (file2) == 0)
					{
						printf ("\n%s \"%s\" ", ReadLanguage (File (), 33), file2);
						printf ("%s", ReadLanguage (File (), 49));
					}
					else
					{
						printf ("\n%s \"%s\" ", ReadLanguage (File (), 50), file2);
						printf ("%s", ReadLanguage (File (), 51));
					}
					if (remove (file4) == 0)
					{
						printf ("\n%s \"%s\" ", ReadLanguage (File (), 33), file4);
						printf ("%s", ReadLanguage (File (), 49));
					}
					else
					{
						printf ("\n%s \"%s\" ", ReadLanguage (File (), 50), file4);
						printf ("%s", ReadLanguage (File (), 51));
					}
					printf ("\n\n%s", ReadLanguage (File (), 41));
					getch ();
				}
				else
				{
					printf ("\n%s", ReadLanguage (File (), 40));
					printf ("\n\n%s", ReadLanguage (File (), 41));
					getch ();
				}
			}
		}
	}
}

// functions for the database statistics

long int SIZEOF (char temp[])
{
	long int size=0, chars=0, lines=0;
	char *tempptr=0;

	tempptr = temp;
	while (*tempptr != 0)
	{
		if (*tempptr == '\n') lines = lines + 2; // size of the New line character is 2 bytes
		if (*tempptr != '\n') chars++;
		tempptr++;
	}
	size = chars + lines;
	return size;
}

long int NumberOfPeople (struct AddressBook **start)
{
	struct AddressBook *Tmp=*start;
	long int NoOfPeople=0;

	while (Tmp != NULL)
	{
		NoOfPeople++;
		Tmp = Tmp->next;
	}
	return NoOfPeople;
}

void DatabaseStatistic (struct AddressBook **start)
{
	long int size=0;
	struct AddressBook *Tmp=*start;

	clrscr ();
	while (Tmp != NULL)
	{
		size += (SIZEOF (Tmp->Name) + SIZEOF (Tmp->Surname) + SIZEOF (Tmp->Address) + SIZEOF (Tmp->Http) + SIZEOF (Tmp->eMail) + SIZEOF (Tmp->Telephone) + SIZEOF (Tmp->MobilePhone)) + 2; // +2 is beacuse New line character is not counted in the first line
		Tmp = Tmp->next;
	}
	printf ("%s", ReadLanguage (File (), 52));
	printf ("\n\n%s %ld ", ReadLanguage (File (), 53), NumberOfPeople (start));
	printf ("%s", ReadLanguage (File (), 54));
	printf ("\n%s %ld ", ReadLanguage (File (), 55), size);
	printf ("%s", ReadLanguage (File (), 56));
	printf ("\n\n%s", ReadLanguage (File (), 41));
	getch ();
}

// functions for selecting, reading language, ...

char *ReadLanguage (char file[], int line)
{
	FILE *fin=0;
	int i=0, j=0;
	char temp1[100], temp2[100], temp3[100], *temp1ptr=0, *temp2ptr=0, *temp3ptr=0;

	fin = fopen (file, "rt");
	temp1ptr = temp1;
	temp2ptr = temp2;
	temp3ptr = temp3;
	while (fscanf (fin, "%c", temp1ptr) != EOF)
	{
		if (*temp1ptr == '\n') i++; // count lines
		if (i == line+10) // temp2 fills with the right line, line+10 is beacuse in the first nine lines are just comments
		{
			if (*temp1ptr != '\n')
			{
				*temp2ptr = *temp1ptr;
				temp2ptr++;
				j++;
			}
			*temp2ptr = '\0';
			if (j >= 6) // in temp3 write only from the 6 character ahead so I can avoid from the "001: " text
			{
				*temp3ptr = *temp1ptr;
				temp3ptr++;
			}
			*temp3ptr = '\0';
		}
	}
	fclose (fin);
	return temp3;
}

char *File () // this function is good for translating subfunctions and not just the main function
{
	FILE *fin;
	int i=0;
	char temp1[50], file[33], file1[33], *fileptr=0, *file1ptr=0, *temp1ptr=0;

	fin = fopen (LANGUAGE_DAT_FILE, "rt");
	temp1ptr = temp1;
	while (fscanf (fin, "%c", temp1ptr) != EOF)
	{
		i++;
	}
	fclose (fin);
	fin = fopen (LANGUAGE_DAT_FILE, "rt");
	if ( (fin != NULL) && (i != 0) )
	{
		fileptr = file;
		file1ptr = file1;
		while (fscanf (fin, "%c", fileptr) != EOF)
		{
			if (*fileptr != '\n')
			{
				*file1ptr = *fileptr;
				file1ptr++;
			}
			*file1ptr = '\0';
		}
	}
	if (fin == NULL)
	{
		clrscr ();
		printf ("ERROR: File \"%s\" is damaged.", LANGUAGE_DAT_FILE);
		printf ("\n\nPress any key to exit to system ...");
		getch ();
		exit (1);
	}
	fclose (fin);
	if (i == 0)
	{
		clrscr ();
		printf ("In file \"%s\" is missing a path to language files.", LANGUAGE_DAT_FILE);
		printf ("\n\nPress any key to exit to system ...");
		getch ();
		exit (1);
	}
	return file1;
}

int CheckLNGfile (char file[])
{
	FILE *fin;

	fin = fopen (file, "rt");

	if (fgetc (fin) != 'L' || fgetc (fin) != 'A' || fgetc (fin) != 'N' ||
		 fgetc (fin) != 'G' || fgetc (fin) != 'U' || fgetc (fin) != 'A' ||
		 fgetc (fin) != 'G' || fgetc (fin) != 'E' || fgetc (fin) != ' ' ||
		 fgetc (fin) != 'F' || fgetc (fin) != 'I' || fgetc (fin) != 'L' ||
		 fgetc (fin) != 'E' || fgetc (fin) != ',' || fgetc (fin) != ' ' ||
		 fgetc (fin) != 169 || fgetc (fin) != ' ' || fgetc (fin) != '2' ||
		 fgetc (fin) != '0' || fgetc (fin) != '0' || fgetc (fin) != '1')
	{
		fclose (fin);
		return -1;
	}
	else
	{
		fclose (fin);
		return 1;
	}
}

void SelectLanguage ()
{
	FILE *fout;
	struct ffblk Files;
	int Search=0, counter1=0, counter2=0;
	char file[13], file1[30];

	clrscr ();
	printf ("%s", ReadLanguage (File (), 57));
	printf ("\n\n%s\n", ReadLanguage (File (), 58));
	Search = findfirst (SEARCH_LNG_FILES, &Files, 0);
	while (!Search)
	{
		printf ("\n%s", Files.ff_name);
		Search = findnext (&Files);
	}
	printf ("\n\n%s", ReadLanguage (File (), 9));
	printf ("\n\n%s ", ReadLanguage (File (), 59));
	scanf("%s", file);
	if (STRCMPI (file, "0") == 0) counter2 = 1;
	if (counter2 != 1)
	{
		strcpy (file1, LANGUAGE_DIR);
		strcat (file1, file);
		counter1 = CheckLNGfile (file1);
		if (counter1 != -1)
		{
			fout = fopen (LANGUAGE_DAT_FILE, "wt+");
			fprintf (fout, "%s", file1);
			fclose (fout);
			printf ("\n%s", ReadLanguage (File (), 41));
			getch ();
		}
		else
		{
			printf ("\n%s \"%s\" ", ReadLanguage (File (), 33), file1);
			printf ("%s", ReadLanguage (File (), 60));
			printf ("\n\n%s", ReadLanguage (File (), 41));
			getch ();
		}
	}
}

// dunction for encoding and decoding a password

char *EncodeDecodePassword (char password[])
{
	int i=0;
	char password1[100], *password1ptr=0, *passwordptr=0;

	passwordptr = password;
	password1ptr = password1;
	while (*passwordptr != 0)
	{
		for (i=0; i<25; i++)
		{
			if (*passwordptr == 97 + i)        *password1ptr = 32 + i;
			else if (*passwordptr == 32 + i)   *password1ptr = 97 + i;
			else if (*passwordptr == 65 + i)   *password1ptr = -126 + i;
			else if (*passwordptr == -126 + i) *password1ptr = 65 + i;
		}
		passwordptr++;
		password1ptr++;
	}
	*password1ptr = '\0';
	return password1;
}

// address book main functions

void Read (struct AddressBook **start, char file[]) // read from file
{
	FILE *fin;
	char temp[100];
	struct AddressBook *New;

	*start = NULL;
	fin = fopen (file, "rt+");
	while (fgets  (temp, 100, fin) != NULL)
	{
		New = (struct AddressBook*) malloc (sizeof (struct AddressBook));
		sscanf (temp, "%s", New->Name);
		fgets  (New->Surname,     sizeof (New->Surname),     fin);
		fgets  (New->Address,     sizeof (New->Address),     fin);
		fgets  (New->Http,        sizeof (New->Http),        fin);
		fgets  (New->eMail,       sizeof (New->eMail),       fin);
		fgets  (New->Telephone,   sizeof (New->Telephone),   fin);
		fgets  (New->MobilePhone, sizeof (New->MobilePhone), fin);
		New->next = *start;
		*start = New;
	}
	fclose(fin);
}

void Add (struct AddressBook **start) // add person into database
{
	struct AddressBook *New, *Tmp;
	long int NoOfPeople=0, i=0, j=0;
	int counter1=0;
	char TempName[80], TempSurname[80], *name1ptr=0, *name2ptr=0, *surname1ptr=0, *surname2ptr=0;

	clrscr ();
	printf ("%s", ReadLanguage (File (), 61));
	printf ("\n\n%s ", ReadLanguage (File (), 62));
	scanf("%ld", &NoOfPeople);
	gets (0);
	for (i=1; i<=NoOfPeople; i++)
	{
		j=1;
		New = (struct AddressBook*) malloc (sizeof (struct AddressBook));
		printf ("\n%s %5ld ", ReadLanguage (File (), 63), NumberOfPeople (start) + j);
		printf ("%s", ReadLanguage (File (), 64));
		printf ("%s ", ReadLanguage (File (), 65));
		gets (New->Name);
		name1ptr = New->Name;
		name2ptr = TempName;
		while (*name1ptr != 0)
		{
			*name2ptr = *name1ptr;
			name1ptr++;
			name2ptr++;
		}
		*name2ptr = '\n'; name2ptr++;
		*name2ptr = 0;
		printf ("%s ", ReadLanguage (File (), 66));
		gets (New->Surname);
		surname1ptr = New->Surname;
		surname2ptr = TempSurname;
		while (*surname1ptr != 0)
		{
			*surname2ptr = *surname1ptr;
			surname1ptr++;
			surname2ptr++;
		}
		*surname2ptr = '\n'; surname2ptr++;
		*surname2ptr = 0;
		Tmp = *start;
		while (Tmp != NULL)
		{
			if ( ((STRCMPI (New->Name, Tmp->Name) == 0) || (STRCMPI (TempName, Tmp->Name) == 0)) && ((STRCMPI (New->Surname, Tmp->Surname) == 0) || (STRCMPI (TempSurname, Tmp->Surname) == 0)) )
			{
				counter1 = 1;
			}
			Tmp = Tmp->next;
		}
		if (counter1 != 1)
		{
			printf ("%s ", ReadLanguage (File (), 67));
			gets (New->Address);
			printf ("%s ", ReadLanguage (File (), 68));
			gets (New->Http);
			printf ("%s ", ReadLanguage (File (), 69));
			gets (New->eMail);
			printf ("%s ", ReadLanguage (File (), 70));
			gets (New->Telephone);
			printf ("%s ", ReadLanguage (File (), 71));
			gets (New->MobilePhone);
			printf ("********************************************************************************");
			New->next = *start;
			*start = New;
			if (i != NoOfPeople)
			{
				printf ("\n%s\n", ReadLanguage (File (), 36));
			}
			else
			{
				printf ("\n%s", ReadLanguage (File (), 41));
			}
			getch ();
		}
		else
		{
			counter1 = 0;
			i = i - 1;
			printf ("\n%s \"%s %s\" ", ReadLanguage (File (), 72), New->Name, New->Surname);
			printf ("%s", ReadLanguage (File (), 73));
			printf ("\n\n%s\n", ReadLanguage (File (), 36));
			getch ();
		}
	}
}

void RemovePerson (struct AddressBook **start)
{
	struct AddressBook *Tmp, *previous;
	char Name[80], TempName[80], *name1ptr=0, *name2ptr=0, Surname[80], TempSurname[80], *surname1ptr=0, *surname2ptr=0;
	int counter1=0, counter2=0;

	gets (0);
	do
	{
		counter1 = counter2 = 0;
		clrscr ();
		printf ("%s", ReadLanguage (File (), 74));
		WriteOutPeople (start);
		if (*start != NULL)
		{
			printf ("\n%s", ReadLanguage (File (), 9));
			printf ("\n\n%s ", ReadLanguage (File (), 65));
			gets (Name);
			if (STRCMPI (Name, "0") == 0) counter1 = 1;
			if (counter1 != 1)
			{
				name1ptr = Name;
				name2ptr = TempName;
				while (*name1ptr != 0)
				{
					*name2ptr = *name1ptr;
					name1ptr++;
					name2ptr++;
				}
				*name2ptr = '\n'; name2ptr++;
				*name2ptr = 0;
				printf ("%s ", ReadLanguage (File (), 66));
				gets (Surname);
				if (STRCMPI (Surname, "0") == 0) counter1 = 2;
				if (counter1 != 2)
				{
					surname1ptr = Surname;
					surname2ptr = TempSurname;
					while (*surname1ptr != 0)
					{
						*surname2ptr = *surname1ptr;
						surname1ptr++;
						surname2ptr++;
					}
					*surname2ptr = '\n'; surname2ptr++;
					*surname2ptr = 0;
					Tmp = *start;
					while (Tmp != NULL)
					{
						if ( ((STRCMPI (Name, Tmp->Name) == 0) || (STRCMPI (TempName, Tmp->Name) == 0)) && ((STRCMPI (TempSurname, Tmp->Surname) == 0) || (STRCMPI (Surname, Tmp->Surname) == 0)) )
						{
							counter2 = 1;
							if (Tmp == *start)
							{
								*start = Tmp->next;
							}
							else
							{
								break;
							}
						}
						else
						{
							Tmp=Tmp->next;
						}
					}
					previous = *start;
					Tmp = previous->next;
					while (Tmp != NULL)
					{
						if ( ((STRCMPI (Name, Tmp->Name) == 0) || (STRCMPI (TempName, Tmp->Name) == 0)) && ((STRCMPI (TempSurname, Tmp->Surname) == 0) || (STRCMPI (Surname, Tmp->Surname) == 0)) )
						{
							counter2 = 1;
							Tmp=Tmp->next;
							previous->next=Tmp;
						}
						else
						{
							previous=Tmp;
							Tmp=Tmp->next;
						}
					}
					if (counter2 == 1)
					{
						printf ("\n%s \"%s %s\" ", ReadLanguage (File (), 72), Name, Surname);
						printf ("%s", ReadLanguage (File (), 75));
						printf ("\n\n%s\n", ReadLanguage (File (), 36));
						getch ();
					}
					else
					{
						printf ("\n%s \"%s %s\" ", ReadLanguage (File (), 76), Name, Surname);
						printf ("%s", ReadLanguage (File (), 77));
						printf ("\n\n%s\n", ReadLanguage (File (), 36));
						getch ();
					}
				}
			}
		}
		else
		{
			clrscr ();
			printf ("%s", ReadLanguage (File (), 78));
			printf ("\n\n%s", ReadLanguage (File (), 41));
			getch ();
			break;
		}
	} while ( (STRCMPI (Name, "0") != 0) && (STRCMPI (Surname, "0") != 0) );
}

void FindPeople (struct AddressBook **start)
{
	struct AddressBook *Tmp;
	int counter1=0, selection1=0, i=0;
	char Name[80], TempName[80], *name1ptr=0, *name2ptr=0, Surname[80], TempSurname[80]={0}, *surname2ptr=0, *surname1ptr=0;
	char Address[80], TempAddress[80], *address1ptr=0, *address2ptr=0, Http[80], TempHttp[80], *eaddress1ptr=0, *eaddress2ptr=0;
	char eMail[80], TempeMail[80], *email1ptr=0, *email2ptr=0, Telephone[80], TempTelephone[80], *telefon1ptr=0, *telefon2ptr=0, MobilePhone[80], TempMobilePhone[80], *mtelefon1ptr=0, *mtelefon2ptr=0;

	do
	{
		i = counter1 = selection1 = 0;
		clrscr ();
		printf ("%s", ReadLanguage (File (), 79));
		printf ("\n\n%s", ReadLanguage (File (), 9));
		printf ("\n\n%s", ReadLanguage (File (), 80));
		printf ("\n%s", ReadLanguage (File (), 81));
		printf ("\n%s", ReadLanguage (File (), 82));
		printf ("\n%s", ReadLanguage (File (), 83));
		printf ("\n%s", ReadLanguage (File (), 84));
		printf ("\n%s", ReadLanguage (File (), 85));
		printf ("\n%s", ReadLanguage (File (), 86));
		printf ("\n%s", ReadLanguage (File (), 87));
		printf ("\n\n%s ", ReadLanguage (File (), 7));
		scanf ("%d", &selection1);
		gets (0);
		switch (selection1)
		{
			case 0:
				break;
			case 1:
				printf ("\n%s", ReadLanguage (File (), 88));
				printf ("\n\n%s ", ReadLanguage (File (), 65));
				gets (Name);
				if (STRCMPI (Name, "0") == 0) counter1 = 1;
				if (counter1 != 1)
				{
					name1ptr = Name;
					name2ptr = TempName;
					while (*name1ptr != 0)
					{
						*name2ptr = *name1ptr;
						name1ptr++;
						name2ptr++;
					}
					*name2ptr = '\n'; name2ptr++;
					*name2ptr = 0;
					printf ("\n%s\n", ReadLanguage (File (), 89));
					Tmp = *start;
					while (Tmp != NULL)
					{
						if ( (STRCMPI (Name, Tmp->Name) == 0) || (STRCMPI (TempName, Tmp->Name) == 0) )
						{
							i++;
							printf ("\n%s ", ReadLanguage (File (), 90));
							PrintOnScreen (Tmp->Name);
							printf (" ");
							PrintOnScreen (Tmp->Surname);
						}
						Tmp = Tmp->next;
					}
					if (i == 0)
					{
						printf ("\n%s \"%s\" ", ReadLanguage (File (), 91), Name);
						printf ("%s", ReadLanguage (File (), 77));
					}
					printf ("\n\n%s", ReadLanguage (File (), 36));
					getch ();
				}
				break;
			case 2:
				printf ("\n%s", ReadLanguage (File (), 92));
				printf ("\n\n%s ", ReadLanguage (File (), 66));
				gets (Surname);
				if (STRCMPI (Surname, "0") == 0) counter1 = 1;
				if (counter1 != 1)
				{
					surname1ptr = Surname;
					surname2ptr = TempSurname;
					while (*surname1ptr != 0)
					{
						*surname2ptr = *surname1ptr;
						surname1ptr++;
						surname2ptr++;
					}
					*surname2ptr = '\n'; surname2ptr++;
					*surname2ptr = 0;
					printf ("\n%s\n", ReadLanguage (File (), 89));
					Tmp = *start;
					while (Tmp != NULL)
					{
						if ( (STRCMPI (Surname, Tmp->Surname) == 0) || (STRCMPI (TempSurname, Tmp->Surname) == 0) )
						{
							i++;
							printf ("\n%s ", ReadLanguage (File (), 90));
							PrintOnScreen (Tmp->Name);
							printf (" ");
							PrintOnScreen (Tmp->Surname);
						}
						Tmp = Tmp->next;
					}
					if (i == 0)
					{
						printf ("\n%s \"%s\" ", ReadLanguage (File (), 93), Surname);
						printf ("%s", ReadLanguage (File (), 77));
					}
					printf ("\n\n%s", ReadLanguage (File (), 36));
					getch ();
				}
				break;
			case 3:
				printf ("\n%s", ReadLanguage (File (), 94));
				printf ("\n\n%s ", ReadLanguage (File (), 67));
				gets (Address);
				if (STRCMPI (Address, "0") == 0) counter1 = 1;
				if (counter1 != 1)
				{
					address1ptr = Address;
					address2ptr = TempAddress;
					while (*address1ptr != 0)
					{
						*address2ptr = *address1ptr;
						address1ptr++;
						address2ptr++;
					}
					*address2ptr = '\n'; address2ptr++;
					*address2ptr = 0;
					printf ("\n%s\n", ReadLanguage (File (), 89));
					Tmp = *start;
					while (Tmp != NULL)
					{
						if ( (STRCMPI (Address, Tmp->Address) == 0) || (STRCMPI (TempAddress, Tmp->Address) == 0) )
						{
							i++;
							printf ("\n%s ", ReadLanguage (File (), 90));
							PrintOnScreen (Tmp->Name);
							printf (" ");
							PrintOnScreen (Tmp->Surname);
						}
						Tmp = Tmp->next;
					}
					if (i == 0)
					{
						printf ("\n%s \"%s\", ", ReadLanguage (File (), 95), Address);
						printf ("%s", ReadLanguage (File (), 77));
					}
					printf ("\n\n%s", ReadLanguage (File (), 36));
					getch ();
				}
				break;
			case 4:
				printf ("\n%s", ReadLanguage (File (), 96));
				printf ("\n\n%s ", ReadLanguage (File (), 68));
				gets (Http);
				if (STRCMPI (Http, "0") == 0) counter1 = 1;
				if (counter1 != 1)
				{
					eaddress1ptr = Http;
					eaddress2ptr = TempHttp;
					while (*eaddress1ptr != 0)
					{
						*eaddress2ptr = *eaddress1ptr;
						eaddress1ptr++;
						eaddress2ptr++;
					}
					*eaddress2ptr = '\n'; eaddress2ptr++;
					*eaddress2ptr = 0;
					printf ("\n%s\n", ReadLanguage (File (), 89));
					Tmp = *start;
					while (Tmp != NULL)
					{
						if ( (STRCMPI (Http, Tmp->Http) == 0) || (STRCMPI (TempHttp, Tmp->Http) == 0) )
						{
							i++;
							printf ("\n%s ", ReadLanguage (File (), 90));
							PrintOnScreen (Tmp->Name);
							printf (" ");
							PrintOnScreen (Tmp->Surname);
						}
						Tmp = Tmp->next;
					}
					if (i == 0)
					{
						printf ("\n%s \"%s\", ", ReadLanguage (File (), 97), Http);
						printf ("%s", ReadLanguage (File (), 77));
					}
					printf ("\n\n%s", ReadLanguage (File (), 36));
					getch ();
				}
				break;
			case 5:
				printf ("\n%s", ReadLanguage (File (), 98));
				printf ("\n\n%s ", ReadLanguage (File (), 69));
				gets (eMail);
				if (STRCMPI (eMail, "0") == 0) counter1 = 1;
				if (counter1 != 1)
				{
					email1ptr = eMail;
					email2ptr = TempeMail;
					while (*email1ptr != 0)
					{
						*email2ptr = *email1ptr;
						email1ptr++;
						email2ptr++;
					}
					*email2ptr = '\n'; email2ptr++;
					*email2ptr = 0;
					printf ("\n%s\n", ReadLanguage (File (), 89));
					Tmp = *start;
					while (Tmp != NULL)
					{
						if ( (STRCMPI (eMail, Tmp->eMail) == 0) || (STRCMPI (TempeMail, Tmp->eMail) == 0) )
						{
							i++;
							printf ("\n%s ", ReadLanguage (File (), 90));
							PrintOnScreen (Tmp->Name);
							printf (" ");
							PrintOnScreen (Tmp->Surname);
						}
						Tmp = Tmp->next;
					}
					if (i == 0)
					{
						printf ("\n%s \"%s\", ", ReadLanguage (File (), 99), eMail);
						printf ("%s", ReadLanguage (File (), 77));
					}
					printf ("\n\n%s", ReadLanguage (File (), 36));
					getch ();
				}
				break;
			case 6:
				printf ("\n%s", ReadLanguage (File (), 100));
				printf ("\n\n%s ", ReadLanguage (File (), 70));
				gets (Telephone);
				if (STRCMPI (Telephone, "0") == 0) counter1 = 1;
				if (counter1 != 1)
				{
					telefon1ptr = Telephone;
					telefon2ptr = TempTelephone;
					while (*telefon1ptr != 0)
					{
						*telefon2ptr = *telefon1ptr;
						telefon1ptr++;
						telefon2ptr++;
					}
					*telefon2ptr = '\n'; telefon2ptr++;
					*telefon2ptr = 0;
					printf ("\n%s\n", ReadLanguage (File (), 89));
					Tmp = *start;
					while (Tmp != NULL)
					{
						if ( (STRCMPI (Telephone, Tmp->Telephone) == 0) || (STRCMPI (TempTelephone, Tmp->Telephone) == 0) )
						{
							i++;
							printf ("\n%s ", ReadLanguage (File (), 90));
							PrintOnScreen (Tmp->Name);
							printf (" ");
							PrintOnScreen (Tmp->Surname);
						}
						Tmp = Tmp->next;
					}
					if (i == 0)
					{
						printf ("\n%s \"%s\", ", ReadLanguage (File (), 101), Telephone);
						printf ("%s", ReadLanguage (File (), 77));
					}
					printf ("\n\n%s", ReadLanguage (File (), 36));
					getch ();
				}
				break;
			case 7:
				printf ("\n%s", ReadLanguage (File (), 102));
				printf ("\n\n%s ", ReadLanguage (File (), 71));
				gets (MobilePhone);
				if (STRCMPI (MobilePhone, "0") == 0) counter1 = 1;
				if (counter1 != 1)
				{
					mtelefon1ptr = MobilePhone;
					mtelefon2ptr = TempMobilePhone;
					while (*mtelefon1ptr != 0)
					{
						*mtelefon2ptr = *mtelefon1ptr;
						mtelefon1ptr++;
						mtelefon2ptr++;
					}
					*mtelefon2ptr = '\n'; mtelefon2ptr++;
					*mtelefon2ptr = 0;
					printf ("\n%s\n", ReadLanguage (File (), 89));
					Tmp = *start;
					while (Tmp != NULL)
					{
						if ( (STRCMPI (MobilePhone, Tmp->MobilePhone) == 0) || (STRCMPI (TempMobilePhone, Tmp->MobilePhone) == 0) )
						{
							i++;
							printf ("\n%s ", ReadLanguage (File (), 90));
							PrintOnScreen (Tmp->Name);
							printf (" ");
							PrintOnScreen (Tmp->Surname);
						}
						Tmp = Tmp->next;
					}
					if (i == 0)
					{
						printf ("\n%s \"%s\", ", ReadLanguage (File (), 103), MobilePhone);
						printf ("%s", ReadLanguage (File (), 77));
					}
					printf ("\n\n%s", ReadLanguage (File (), 36));
					getch ();
				}
				break;
			default:
				printf ("\n%s", ReadLanguage (File (), 26));
				getch ();
		}
	} while (selection1 != 0);
}

int STRCMPI (char string1[], char string2[])
{
	int counter=0;
	char *string1ptr=0, *string2ptr=0;

	string1ptr = string1;
	string2ptr = string2;
	if (strlen(string1) == strlen(string2))
	{
		while ( (*string1ptr != 0) && (*string2ptr != 0) )
		{
			if (tolower (*string1ptr) == tolower (*string2ptr))
			{
				counter++;
			}
			string1ptr++;
			string2ptr++;
		}
	}
	if (counter == strlen (string1)) return 0; else return -1;
}

void WriteOutPeople (struct AddressBook **start)
{
	struct AddressBook *Tmp;

	printf ("\n\n%s\n\n", ReadLanguage (File (), 104));
	Tmp = *start;
	while (Tmp != NULL)
	{
		PrintOnScreen (Tmp->Name);
		printf (" ");
		PrintOnScreen (Tmp->Surname);
		printf ("\n");
		Tmp = Tmp->next;
	}
}

void PrintPersonOnScreen (struct AddressBook **start)
{
	struct AddressBook *Tmp;
	char Name[80], TempName[80], *name1ptr=0, *name2ptr=0, Surname[80], TempSurname[80], *surname1ptr=0, *surname2ptr=0;
	long int i=0, j=0;
	int counter1=0;

	gets (0);
	do
	{
		i = 1;
		counter1 = j = 0;
		clrscr ();
		printf ("%s", ReadLanguage (File (), 105));
		WriteOutPeople (start);
		if (*start != NULL)
		{
			printf ("\n%s", ReadLanguage (File (), 9));
			printf ("\n\n%s ", ReadLanguage (File (), 65));
			gets (Name);
			if (STRCMPI (Name, "0") == 0) counter1 = 1;
			if (counter1 != 1)
			{
				name1ptr = Name;
				name2ptr = TempName;
				while (*name1ptr != 0)
				{
					*name2ptr = *name1ptr;
					name1ptr++;
					name2ptr++;
				}
				*name2ptr = '\n'; name2ptr++;
				*name2ptr = 0;
				printf ("%s ", ReadLanguage (File (), 66));
				gets (Surname);
				if (STRCMPI (Surname, "0") == 0) counter1 = 2;
				if (counter1 != 2)
				{
					surname1ptr = Surname;
					surname2ptr = TempSurname;
					while (*surname1ptr != 0)
					{
						*surname2ptr = *surname1ptr;
						surname1ptr++;
						surname2ptr++;
					}
					*surname2ptr = '\n'; surname2ptr++;
					*surname2ptr = 0;
					Tmp = *start;
					while (Tmp != NULL)
					{
						if ( ((STRCMPI (Name, Tmp->Name) == 0) || (STRCMPI (TempName, Tmp->Name) == 0)) && ((STRCMPI (TempSurname, Tmp->Surname) == 0) || (STRCMPI (Surname, Tmp->Surname) == 0)) )
						{
							printf ("\n%s %5ld ", ReadLanguage (File (), 63), i);
							printf ("%s", ReadLanguage (File (), 64));
							printf ("%s ", ReadLanguage (File (), 90));
							PrintOnScreen (Tmp->Name);
							printf (" ");
							PrintOnScreen (Tmp->Surname);
							printf ("\n%s ", ReadLanguage (File (), 106));
							PrintOnScreen (Tmp->Address);
							printf ("\n%s ", ReadLanguage (File (), 107));
							PrintOnScreen (Tmp->Http);
							printf ("\n%s ", ReadLanguage (File (), 108));
							PrintOnScreen (Tmp->eMail);
							printf ("\n%s ", ReadLanguage (File (), 109));
							PrintOnScreen (Tmp->Telephone);
							printf ("\n%s ", ReadLanguage (File (), 110));
							PrintOnScreen (Tmp->MobilePhone);
							printf ("\n********************************************************************************");
							j++;
						}
						Tmp = Tmp->next;
						i++;
					}
					if (j == 0)
					{
						printf ("\n%s \"%s %s\" \n", ReadLanguage (File (), 72), Name, Surname);
						printf ("%s", ReadLanguage (File (), 111));
					}
					printf ("\n%s", ReadLanguage (File (), 36));
					getch ();
				}
			}
		}
		else
		{
			clrscr ();
			printf ("%s", ReadLanguage (File (), 78));
			printf ("\n\n%s", ReadLanguage (File (), 41));
			getch ();
			break;
		}
	} while ( (STRCMPI (Name, "0") != 0) && (STRCMPI (Surname, "0") != 0) );
}

void PrintPersonOnPrinter (struct AddressBook **start)
{
	struct AddressBook *Tmp;
	char Name[80], TempName[80], *name1ptr=0, *name2ptr=0, Surname[80], TempSurname[80], *surname1ptr=0, *surname2ptr=0;
	long int i=0, j=0;
	float odst=0;
	int counter1=0;

	gets (0);
	do
	{
		i = 1;
		j = odst = counter1 = 0;
		clrscr ();
		printf ("%s", ReadLanguage (File (), 112));
		WriteOutPeople (start);
		if (*start != NULL)
		{
			printf ("\n%s", ReadLanguage (File (), 9));
			printf ("\n\n%s ", ReadLanguage (File (), 65));
			gets (Name);
			if (STRCMPI (Name, "0") == 0) counter1 = 1;
			if (counter1 != 1)
			{
				name1ptr = Name;
				name2ptr = TempName;
				while (*name1ptr != 0)
				{
					*name2ptr = *name1ptr;
					name1ptr++;
					name2ptr++;
				}
				*name2ptr = '\n'; name2ptr++;
				*name2ptr = 0;
				printf ("%s ", ReadLanguage (File (), 66));
				gets (Surname);
				if (STRCMPI (Surname, "0") == 0) counter1 = 2;
				if (counter1 != 2)
				{
					surname1ptr = Surname;
					surname2ptr = TempSurname;
					while (*surname1ptr != 0)
					{
						*surname2ptr = *surname1ptr;
						surname1ptr++;
						surname2ptr++;
					}
					*surname2ptr = '\n'; surname2ptr++;
					*surname2ptr = 0;
					Tmp = *start;
					while (Tmp != NULL)
					{
						if ( ((STRCMPI (Name, Tmp->Name) == 0) || (STRCMPI (TempName, Tmp->Name) == 0)) && ((STRCMPI (TempSurname, Tmp->Surname) == 0) || (STRCMPI (Surname, Tmp->Surname) == 0)) )
						{
							odst = 0; j = 0;
							fprintf (stdprn, "\n\r\n\r%s %5ld ", ReadLanguage (File (), 63), i);
							fprintf (stdprn, "%s", ReadLanguage (File (), 64));
							fprintf (stdprn, "\n\r%s ", ReadLanguage (File (), 90));
							PrintOnPrinter (Tmp->Name);
							fprintf (stdprn, " ");
							PrintOnPrinter (Tmp->Surname);
							fprintf (stdprn, "\n\r%s ", ReadLanguage (File (), 106));
							PrintOnPrinter (Tmp->Address);
							fprintf (stdprn, "\n\r%s ", ReadLanguage (File (), 107));
							PrintOnPrinter (Tmp->Http);
							fprintf (stdprn, "\n\r%s ", ReadLanguage (File (), 108));
							PrintOnPrinter (Tmp->eMail);
							fprintf (stdprn, "\n\r%s ", ReadLanguage (File (), 109));
							PrintOnPrinter (Tmp->Telephone);
							fprintf (stdprn, "\n\r%s ", ReadLanguage (File (), 110));
							PrintOnPrinter (Tmp->MobilePhone);
							fprintf (stdprn, "\n\r********************************************************************************\n\r");
							j++;
							printf ("\n");
							odst = ((float) j / 1) * 100;
							printf ("%s ", ReadLanguage (File (), 113)); printf ("%1.2f%\r", odst);
						}
						Tmp = Tmp->next;
						i++;
					}
					if (j == 0)
					{
						printf ("\n%s \"%s %s\" ", ReadLanguage (File (), 72), Name, Surname);
						printf ("%s", ReadLanguage (File (), 111));
					}
					printf ("\n\n%s", ReadLanguage (File (), 41));
					getch ();
				}
			}
		}
		else
		{
			clrscr ();
			printf ("%s", ReadLanguage (File (), 78));
			printf ("\n\n%s", ReadLanguage (File (), 41));
			getch ();
			break;
		}
	} while ( (STRCMPI (Name, "0") != 0) && (STRCMPI (Surname, "0") != 0) );
}

void PrintPersonIntoFile (struct AddressBook **start)
{
	struct AddressBook *Tmp;
	char Name[80], TempName[80], *name1ptr=0, *name2ptr=0, Surname[80], TempSurname[80], *surname1ptr=0, *surname2ptr=0, file[13];
	long int i=0, j=0;
	float odst=0;
	int counter1=0;
	FILE *fout=0;

	gets (0);
	do
	{
		i = 1;
		j = odst = counter1 = 0;
		clrscr ();
		printf ("%s", ReadLanguage (File (), 114));
		WriteOutPeople (start);
		if (*start != NULL)
		{
			printf ("\n%s", ReadLanguage (File (), 9));
			printf ("\n\n%s ", ReadLanguage (File (), 65));
			gets (Name);
			if (STRCMPI(Name, "0") == 0) counter1 = 1;
			if (counter1 != 1)
			{
				name1ptr = Name;
				name2ptr = TempName;
				while (*name1ptr != 0)
				{
					*name2ptr = *name1ptr;
					name1ptr++;
					name2ptr++;
				}
				*name2ptr = '\n'; name2ptr++;
				*name2ptr = 0;
				printf ("%s ", ReadLanguage (File (), 66));
				gets (Surname);
				if (STRCMPI(Surname, "0") == 0) counter1 = 2;
				if (counter1 != 2)
				{
					printf ("%s ", ReadLanguage (File (), 115));
					gets (file);
					if (STRCMPI (file, "0") == 0) counter1 = 3;
					if (counter1 != 3)
					{
						fout = fopen (file, "wt+");
						surname1ptr = Surname;
						surname2ptr = TempSurname;
						while (*surname1ptr != 0)
						{
							*surname2ptr = *surname1ptr;
							surname1ptr++;
							surname2ptr++;
						}
						*surname2ptr = '\n'; surname2ptr++;
						*surname2ptr = 0;
						Tmp = *start;
						while (Tmp != NULL)
						{
							if ( ((STRCMPI (Name, Tmp->Name) == 0) || (STRCMPI (TempName, Tmp->Name) == 0)) && ((STRCMPI (TempSurname, Tmp->Surname) == 0) || (STRCMPI (Surname, Tmp->Surname) == 0)) )
							{
								odst = 0; j = 0;
								fprintf (fout, "%s %5ld ", ReadLanguage (File (), 63), i);
								fprintf (fout, "%s", ReadLanguage (File (), 64));
								fprintf (fout, "\n%s ", ReadLanguage (File (), 90));
								PrintIntoFile (Tmp->Name, fout);
								fprintf (fout, " ");
								PrintIntoFile (Tmp->Surname, fout);
								fprintf (fout, "\n%s ", ReadLanguage (File (), 106));
								PrintIntoFile (Tmp->Address, fout);
								fprintf (fout, "\n%s ", ReadLanguage (File (), 107));
								PrintIntoFile (Tmp->Http, fout);
								fprintf (fout, "\n%s ", ReadLanguage (File (), 108));
								PrintIntoFile (Tmp->eMail, fout);
								fprintf (fout, "\n%s ", ReadLanguage (File (), 109));
								PrintIntoFile (Tmp->Telephone, fout);
								fprintf (fout, "\n%s ", ReadLanguage (File (), 110));
								PrintIntoFile (Tmp->MobilePhone, fout);
								fprintf (fout, "\n********************************************************************************\n");
								j++;
								printf ("\n");
								odst = ((float)j / 1)*100;
								printf ("%s ", ReadLanguage (File (), 113)); printf ("%1.2f%\r", odst);
							}
							Tmp = Tmp->next;
							i++;
						}
						fclose (fout);
						if (j == 0)
						{
							printf ("\n%s \"%s %s\" ", ReadLanguage (File (), 72), Name, Surname);
							printf ("%s", ReadLanguage (File (), 111));
						}
						printf ("\n\n%s", ReadLanguage (File (), 36));
						getch ();
					}
				}
			}
		}
		else
		{
			clrscr ();
			printf ("%s", ReadLanguage (File (), 78));
			printf ("\n\n%s", ReadLanguage (File (), 41));
			getch ();
			break;
		}
	} while ( (STRCMPI (Name, "0") != 0) && (STRCMPI (Surname, "0") != 0) );
}

void PrintAllDataOnScreen (struct AddressBook **start) // write all data on the screen
{
	struct AddressBook *Tmp;
	long int i=1;

	clrscr ();
	printf ("%s", ReadLanguage (File (), 116));
	if (*start != NULL)
	{
		Tmp = *start;
		while (Tmp != NULL)
		{
			printf ("\n\n%s %5ld ", ReadLanguage (File (), 63), i);
			printf ("%s", ReadLanguage (File (), 64));
			printf ("%s ", ReadLanguage (File (), 90));
			PrintOnScreen (Tmp->Name);
			printf (" ");
			PrintOnScreen (Tmp->Surname);
			printf ("\n%s ", ReadLanguage (File (), 106));
			PrintOnScreen (Tmp->Address);
			printf ("\n%s ", ReadLanguage (File (), 107));
			PrintOnScreen (Tmp->Http);
			printf ("\n%s ", ReadLanguage (File (), 108));
			PrintOnScreen (Tmp->eMail);
			printf ("\n%s ", ReadLanguage (File (), 109));
			PrintOnScreen (Tmp->Telephone);
			printf ("\n%s ", ReadLanguage (File (), 110));
			PrintOnScreen (Tmp->MobilePhone);
			printf ("\n********************************************************************************");
			Tmp = Tmp->next;
			if (i != NumberOfPeople (start))
			{
				printf ("\n%s", ReadLanguage (File (), 36));
				getch ();
			}
			i++;
		}
		printf ("\n%s", ReadLanguage (File (), 41));
		getch ();
	}
	else
	{
		clrscr ();
		printf ("%s", ReadLanguage (File (), 78));
		printf ("\n\n%s", ReadLanguage (File (), 41));
		getch ();
	}
}

void PrintAllDataOnPrinter (struct AddressBook **start)
{
	struct AddressBook *Tmp;
	long int i=1, j=0;
	float odst=0;

	clrscr ();
	printf ("%s", ReadLanguage (File (), 117));
	printf ("\n");
	if (*start != NULL)
	{
		Tmp = *start;
		while (Tmp != NULL)
		{
			fprintf (stdprn, "\n\r\n\r%s %5ld ", ReadLanguage (File (), 63), i);
			fprintf (stdprn, "%s", ReadLanguage (File (), 64));
			fprintf (stdprn, "\n\r%s ", ReadLanguage (File (), 90));
			PrintOnPrinter (Tmp->Name);
			fprintf (stdprn, " ");
			PrintOnPrinter (Tmp->Surname);
			fprintf (stdprn, "\n\r%s ", ReadLanguage (File (), 106));
			PrintOnPrinter (Tmp->Address);
			fprintf (stdprn, "\n\r%s ", ReadLanguage (File (), 107));
			PrintOnPrinter (Tmp->Http);
			fprintf (stdprn, "\n\r%s ", ReadLanguage (File (), 108));
			PrintOnPrinter (Tmp->eMail);
			fprintf (stdprn, "\n\r%s ", ReadLanguage (File (), 109));
			PrintOnPrinter (Tmp->Telephone);
			fprintf (stdprn, "\n\r%s ", ReadLanguage (File (), 110));
			PrintOnPrinter (Tmp->MobilePhone);
			fprintf (stdprn, "\n\r********************************************************************************\n\r");
			Tmp = Tmp->next;
			i++; j++;
			odst = ( (float) j / (float) NumberOfPeople (start) ) * 100;
			printf ("%s ", ReadLanguage (File (), 113)); printf ("%1.2f%\r", odst);
		}
		printf ("\n\n%s", ReadLanguage (File (), 41));
		getch ();
	}
	else
	{
		clrscr ();
		printf ("%s", ReadLanguage (File (), 78));
		printf ("\n\n%s", ReadLanguage (File (), 41));
		getch ();
	}
}

void PrintAllDataIntoFile (struct AddressBook **start)
{
	struct AddressBook *Tmp;
	long int i=1, j=0;
	FILE *fout=0;
	char File1[13];
	float odst=0;
	int counter1=0;

	clrscr ();
	printf ("%s", ReadLanguage (File (), 118));
	if (*start != NULL)
	{
		printf ("\n\n%s", ReadLanguage (File (), 9));
		printf ("\n\n%s ", ReadLanguage (File (), 115));
		scanf("%s", File1);
		if (STRCMPI (File1, "0") == 0) counter1 = 1;
		if (counter1 != 1)
		{
			fout = fopen (File1, "wt+");
			printf ("\n");
			Tmp = *start;
			while (Tmp != NULL)
			{
				fprintf (fout, "%s %5ld ", ReadLanguage (File (), 63), i);
				fprintf (fout, "%s", ReadLanguage (File (), 64));
				fprintf (fout, "\n%s ", ReadLanguage (File (), 90));
				PrintIntoFile (Tmp->Name, fout);
				fprintf (fout, " ");
				PrintIntoFile (Tmp->Surname, fout);
				fprintf (fout, "\n%s ", ReadLanguage (File (), 106));
				PrintIntoFile (Tmp->Address, fout);
				fprintf (fout, "\n%s ", ReadLanguage (File (), 107));
				PrintIntoFile (Tmp->Http, fout);
				fprintf (fout, "\n%s ", ReadLanguage (File (), 108));
				PrintIntoFile (Tmp->eMail, fout);
				fprintf (fout, "\n%s ", ReadLanguage (File (), 109));
				PrintIntoFile (Tmp->Telephone, fout);
				fprintf (fout, "\n%s ", ReadLanguage (File (), 110));
				PrintIntoFile (Tmp->MobilePhone, fout);
				fprintf (fout, "\n********************************************************************************\n");
				Tmp = Tmp->next;
				i++; j++;
				odst = ( (float) j / (float) NumberOfPeople (start) ) * 100;
				printf ("%s ", ReadLanguage (File (), 113)); printf ("%1.2f%\r", odst);
			}
			fclose (fout);
			printf ("\n\n%s", ReadLanguage (File (), 41));
			getch ();
		}
	}
	else
	{
		clrscr ();
		printf ("%s", ReadLanguage (File (), 78));
		printf ("\n\n%s", ReadLanguage (File (), 41));
		getch ();
	}
}

void PrintOnScreen (char temp[])
{
	int i=0, j=0;

	j = strlen (temp);
	for (i=0; i<j; i++)
	{
		if (temp[i] != '\n') printf ("%c", temp[i]);
	}
}

void PrintOnPrinter (char temp[])
{
	int i=0, j=0;

	j = strlen (temp);
	for (i=0; i<j; i++)
	{
		if (temp[i] != '\n') fprintf (stdprn, "%c", temp[i]);
	}
}

void PrintIntoFile (char temp[], FILE *fout)
{
	int i=0, j=0;

	j = strlen (temp);
	for (i=0; i<j; i++)
	{
		if (temp[i] != '\n') fprintf (fout, "%c", temp[i]);
	}
}

void Write1 (char temp[], FILE *fout) // write single character into a file
{
	int i=0, j=0;

	j = strlen (temp);
	for (i=0; i<j; i++)
	{
		if (temp[i] != '\n') fprintf (fout, "%c", temp[i]);
	}
}

void Write (struct AddressBook **start, char file[]) // write all data into a file
{
	FILE *fout;
	struct AddressBook *Tmp;

	fout = fopen (file, "wt+");
	Tmp = *start;
	while (Tmp != NULL)
	{
		Write1 (Tmp->Name, fout);
		fprintf (fout, "%c", NEW_LINE_CHAR);
		Write1 (Tmp->Surname, fout);
		fprintf (fout, "%c", NEW_LINE_CHAR);
		Write1 (Tmp->Address, fout);
		fprintf (fout, "%c", NEW_LINE_CHAR);
		Write1 (Tmp->Http, fout);
		fprintf (fout, "%c", NEW_LINE_CHAR);
		Write1 (Tmp->eMail, fout);
		fprintf (fout, "%c", NEW_LINE_CHAR);
		Write1 (Tmp->Telephone, fout);
		fprintf (fout, "%c", NEW_LINE_CHAR);
		Write1 (Tmp->MobilePhone, fout);
		fprintf (fout, "%c", NEW_LINE_CHAR);
		free (Tmp);
		Tmp = Tmp->next;
	}
	fclose (fout);
}