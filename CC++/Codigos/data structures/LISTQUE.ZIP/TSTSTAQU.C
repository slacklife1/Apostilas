/*
   TSTSTAQU.C

   Stack and Que test program.

   Copyright (c) 1990, 1997, Scott Beasley.
   Released into the Public Domain

   Scott Beasley.
   704 Otis RD. Walterboro, SC 29488.
   scottb@lowcountry.com
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "listque.h"

void main ( void );

void main ( void )
{
   PSHND shnd;
   PQHND qhnd;
   char strentry[81];

   puts ( "STACK TEST." );

   /* Create a stack 50 entrys long and 81 bytes wid. */
   shnd = Screate ( 81, 50 );

   strcpy ( strentry, "1st in 4th out" );
   Spush ( shnd, ( SELEMENT ) strentry );

   strcpy ( strentry, "2nd in 3rd out" );
   Spush ( shnd, ( SELEMENT ) strentry );

   strcpy ( strentry, "3rd in 2nd out" );
   Spush ( shnd, ( SELEMENT ) strentry );

   strcpy ( strentry, "4th in 1st out" );
   Spush ( shnd, ( SELEMENT ) strentry );

   while ( 1 ) {
      if ( Spop ( shnd, ( SELEMENT ) strentry ) == SUNDERFLOW )
         break;

      printf ( "%s\n", strentry );
   }

   Sdestroy ( shnd );

   puts ( "\n\nQUE TEST." );

   /* Create a Que 50 entrys long and 81 bytes wid. */
   qhnd = Qcreate ( 81, 50 );

   strcpy ( strentry, "1st in 1st out" );
   Qwrite ( qhnd, ( QELEMENT ) strentry );

   strcpy ( strentry, "2nd in 2nd out" );
   Qwrite ( qhnd, ( QELEMENT ) strentry );

   strcpy ( strentry, "3rd in 3rd out" );
   Qwrite ( qhnd, ( QELEMENT ) strentry );

   strcpy ( strentry, "4th in 4th out" );
   Qwrite ( qhnd, ( QELEMENT ) strentry );

   while ( 1 ) {
      if ( Qread ( qhnd, ( QELEMENT ) strentry ) == QEMPTY )
         break;

      printf ( "%s\n", strentry );
   }

   Qdestroy ( qhnd );
}
