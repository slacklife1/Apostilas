/*
   TSTREE.C

   04/09/97

   I-Tree, test program.

   Copyright (c) 1990, 1997, Scott Beasley.
   Released into the Public Domain

   Scott Beasley.
   704 Otis RD. Walterboro, SC 29488.
   scottb@lowcountry.com
*/

#include <stdlib.h>
#include "listque.h"

int main ( void );

int main ( void )
{
   PTHND thnd;
   char strbuf[256];
   int iret;

   thnd = Tcreate ( 0, 1, 1, ( COMPFUNC ) NULL );

   Twrite ( thnd, ( TELEMENT ) "Nine" );
   Twrite ( thnd, ( TELEMENT ) "Two" );
   Twrite ( thnd, ( TELEMENT ) "Five" );
   Twrite ( thnd, ( TELEMENT ) "Seven" );
   Twrite ( thnd, ( TELEMENT ) "Three" );
   Twrite ( thnd, ( TELEMENT ) "Eight" );
   Twrite ( thnd, ( TELEMENT ) "Four" );
   Twrite ( thnd, ( TELEMENT ) "One" );

   if ( Tsearch ( thnd, ( TELEMENT ) "Four", ( TELEMENT ) strbuf ) )
      printf ( "1 - %s\n", strbuf );

   if ( Tsearch ( thnd, ( TELEMENT ) "One", ( TELEMENT ) strbuf ) )
      printf ( "2 - %s\n", strbuf );

   if ( Tsearch ( thnd, ( TELEMENT ) "Seven", ( TELEMENT ) strbuf ) )
      printf ( "3 - %s\n", strbuf );

   if ( Tsearch ( thnd, ( TELEMENT ) "Six", ( TELEMENT ) strbuf ) )
      printf ( "4 - %s\n", strbuf );
}
