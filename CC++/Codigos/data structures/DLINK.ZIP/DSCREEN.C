#include <ctype.h>
#include <conio.h>
#include <dos.h>
#include <stdio.h>

int menu_select();
void main_menu(), put_char(char a);
extern unsigned TallCursor, NoCursor;
void charbox()
{
    int test;

    /* draw top of box */
    char nw[]          = "�";
    char par[]       = "���������������������������������������";
    char ne[]        = "�";
    char vert[]      = "�";
    char sw[]        = "�";

    int loop;
    int x = 1;

    clrscr();
    gotoxy(1, 1);

    cputs(nw);
    cputs(par);
    cputs(par);
    cputs(ne);

    /* draw parallel lines down the sides */
    for (x = 2; x < 25; x++)
    {
        gotoxy(1, x);
        cputs(vert);
	gotoxy(80, x);
        cputs(vert);
    }

    /* draw bottom of box */
    cputs(sw);
    cputs(par);
    cputs(par);
    put_char('�');
}

void display_screen()
{
    gotoxy(18, 6);
    cputs("enter first name:  ");
    gotoxy(18, 8);
    cputs(" enter last name:  ");
    gotoxy(18, 10);
    cputs("    enter street:  ");
    gotoxy(18, 12);
    cputs("      enter city:  ");
    gotoxy(18, 14);
    cputs("     enter state:  ");
    gotoxy(18, 16);
    cputs("       enter zip:  ");
    gotoxy(18, 18);
    cputs("     enter phone:  ");
}

void inputs(char *s, int count)
{
  int looper;
  char p[50];
  p[0] = count;
  p[1] = 0;

  textbackground(LIGHTGRAY);
  for (looper = 0; looper < count; looper++)
      cputs(" ");
  for (looper = 0; looper < count; looper++)
      printf("\b");
  cgets(p);
  strcpy(s, p+2);
  textbackground(BLACK);
  if (*s == '\0')
  {
    textbackground(BLACK);
    window(1, 1, 80, 25);
    clrscr();
    charbox();
    window(2, 2, 79, 24);
    main_menu();
  }
}

void Beep(void)
{
  sound(750);
  delay(25);
  nosound();
}

void put_char(char a)
{
    union REGS r;
    r.h.ah = 9;
    r.h.al = a;
    r.h.bl = 14;
    r.h.bh = 0;
    r.x.cx = 1;
    int86(0x10, &r, &r);
}

int getkey(void)
/* Uses the BIOS to read the next keyboard character */
{
 int key, lo, hi;

 key = bioskey(0);
 lo = key & 0X00FF;
 hi = (key & 0XFF00) >> 8;
 return((lo == 0) ? hi + 256 : lo);
} /* getkey */

void field(char *field, int max)
{
    int loop;

    for (loop = 0; loop < max; loop++)
    {
	cputs(" ");
    }

    for (loop = 0; loop < max; loop++)
    {
        cprintf("\b");
    }

    cprintf("%s", field);

    for (loop = 0; loop < strlen(field); loop++)
    {
        cprintf("\b");
    }
} /* field */

int menu_select()
{
    int x, y, c, selection;
    char sel[4];
    
    strcpy(sel, "");

    main_menu();

    SetCursor(TallCursor);

    do
    {
	edit_field(51, 22, sel, 2, LIGHTGRAY, YELLOW);
	selection = atoi(sel);
        gotoxy(51, 22);
    } while ((selection < 1) || (selection > 10));

    SetCursor(NoCursor);
    return (selection);
}

void main_menu()
{
    clrscr();

    gotoxy(25, 2);
    textcolor(WHITE); cputs("1"); textcolor(YELLOW); cputs(".  Add A Record");
    gotoxy(25, 4);
    textcolor(WHITE); cputs("2"); textcolor(YELLOW); cputs(".  Remove A Record");
    gotoxy(25, 6);
    textcolor(WHITE); cputs("3"); textcolor(YELLOW); cputs(".  Write Labels To Disk");
    gotoxy(25, 8);
    textcolor(WHITE); cputs("4"); textcolor(YELLOW); cputs(".  Display A Record");
    gotoxy(25, 10);
    textcolor(WHITE); cputs("5"); textcolor(YELLOW); cputs(".  Edit A Record");
    gotoxy(25, 12);
    textcolor(WHITE); cputs("6"); textcolor(YELLOW); cputs(".  Save The File");
    gotoxy(25, 14);
    textcolor(WHITE); cputs("7"); textcolor(YELLOW); cputs(".  Retrieve The File");
    gotoxy(25, 16);
    textcolor(WHITE); cputs("8"); textcolor(YELLOW); cputs(".  Browse Through List");
    gotoxy(25, 18);
    textcolor(WHITE); cputs("9"); textcolor(YELLOW); cputs(".  DOS Shell");
    gotoxy(25, 20);
    textcolor(WHITE); cputs("10"); textcolor(YELLOW); cputs(".  Exit Program");
    gotoxy(25, 22);
    
    cputs("Select Number of Choice:  ");
}

