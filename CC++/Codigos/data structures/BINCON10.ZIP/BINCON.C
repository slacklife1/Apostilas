/*   ��������������������������������������������������������������ͻ
     �        All of the files included in this BINCON package      �
     �  are (C)opyright 1993 Tim Triemstra, All Rights are Reserved �
     �                                                              �
     �  The author can be contacted at:                             �
     �  Internet: empath@ais.org                                    �
     �  UUCP:     umcc!roofus!empath                                �
     �  Fido:     Tim Triemstra @ 1:2410/339.1                      �
     ��������������������������������������������������������������ͼ */

/*
    This file is probably pretty ugly to alot of you "professional
    programmers" (or anybody else actuall.)  However, since I am
    just a guy who learned myself all mines knowledge on mines own =)
    - don't expect too much.

    I included the source because there is probably a situation
    that someone out there mich like some more functionality.  I can't
    really think of anything off the top of my head (after all, I
    wrote this program for myself anyhow.)

    Please, if this code influences you to write an application along
    this line, release it as shareware/freeware.  The world needs
    good programs and if we all have to spend our precious minutes
    writing small tools like this then the real programs will take
    alot longer.

    I'm constantly writing small programs like this myself and I try
    to release them all into the public domain with source code.  The
    only thing I ask is that if you use it constantly - distribute it!
    After all, you're not the only wierd one out there that may like
    this program.

    Finally, I doubt I'll do too much more with this program, but in
    the interest of keeping the good stuff rolling, I do accept
    donations.  I'll be sure to send you back some mail with some little
    tidbit of code or info that you may find interesting.  Sometimes
    it'll be an update, other times I'll send you other code that I may
    be working on that you may be interested in.  If you have a specific
    application you may want some help with, or are looking for little
    tidbits, let me know.  I may have some code lying around...  And,
    ESPECIALLY, if you have an internet mail site (or Fido I guess)
    let me know it and I can get you alot more stuff sent to you.

    I'd ask for something like $7 for a general, all purpose donation.
    If you'd like some graphics coding information (my real speciality)
    I'll gladly send you a disk full of stuff for a little more money.
    I prefer to handle most of this stuff via regular mail or, especially,
    internet mail.  So, here's the info:

    Send any donations (along with your personal info so I can keep in
    touch and send you some stuff you might like, and keep track of
    my fellow programmers) to:

    Tim Triemstra
    Empath Software
    6238 College Drive
    Dearborn Heights, MI 48127

    * Make any checks/money orders payable to Tim Triemstra, my bank is
      still trying to charge me for depositing company checks so I don't
      deal with them like that yet.

    I can be contacted at:
    Internet:  empath@ais.org
    Fidomail:  Tim Triemstra @ 1:2410/339.1 (I'm a point so I see it all)
    UUCPmail:  umcc!roofus!empath

    This info is also included in the readme.txt, but I know I love to
    delete those darn files so I put it here as well.  There IS some
    other good info in the readme though too...
*/

#include <stdio.h>
#include <stdlib.h>
#include <dos.h>

void main(int argc, char *argv[])
{
    FILE *f;
    unsigned char   *raw;
    unsigned int    length;
    unsigned int    count;
    short           count2;
    int             start, end;

    if(argc < 3)
    {
#ifdef DOS386
    puts("32bit usage: BIN2DEC <infile> <type D:H> <start> <end>");
    puts("The <start> defaults to 0, the <end> defaults to the eof\n");
#else
    puts("16bit usage: BIN2DEC <infile> <type D:H> <start> <end>");
    puts("The <start> defaults to 0, the <end> defaults to the eof\n");
#endif
    exit(1);
    }

    f = fopen(argv[1],"rb");
    if(!f)
    {
    printf("Could not open the requested file \"%s\"\n",argv[1]);
    goto EXIT;
    }
    length = (int)filelength(fileno(f));

#ifdef DOS386
    raw = (unsigned char*)malloc(length*sizeof(char));
#else
    raw = farmalloc(length*sizeof(char));
#endif
    fread(raw,1,length,f);
    fclose(f);

    start = 0; end = length;
    if(argc > 3)
        start = atoi(argv[3]);
    if(argc > 4)
        end = atoi(argv[4]);

    count2 = -1;
    printf("\n{\n    ");
    /* This will simply output to the screen, good for >filename work */
    for(count = start; count < end; count++)
    {
        if(count != start)
            printf(",");

        ++count2;
        if(count2 > 11)
        {
            count2 = 0;
            printf("\n    ");
        }
        switch(argv[2][0])
        {
            case 'd' :   printf(" %3d",raw[count]); break;
            case 'D' :   printf(" %3d",raw[count]); break;
            case 'h' :   printf("%#4x",raw[count]); break;
            case 'H' :   printf("%#4x",raw[count]); break;
            default  : exit(0);
        }
    }
    printf("\n};\n");

EXIT:
    printf("\n");
    exit(0);
}
