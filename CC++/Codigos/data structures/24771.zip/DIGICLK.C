#include <stdio.h>
#include <conio.h>
#include <dos.h>

vline(int x,int y,int FL)
{
 int i;
    char digit1[3]=
	   {
	      {'�'},{'�'},{'�'}
	   };
    for(i=0;i<3;i++)
	{
	    gotoxy(x,y+i);
	    cprintf("%c\n",digit1[i]);
	 }
    if(FL==1)
     {
      for(i=0;i<3;i++)
	{
	    gotoxy(x,y+i+4);
	    cprintf("%c\n",digit1[i]);
	 }
     }

}

hline(int x,int y,int FL)
{
 int i;
  char  digit2[6]= {
		     {'�'},{'�'},{'�'},{'�'},{'�'},{'�'}
		   };
     for(i=0;i<6;i++)
	{
	    gotoxy(x+i,y);
	    cprintf("%c\n",digit2[i]);
	 }
   if(FL==1)
   {
    for(i=0;i<6;i++)
	{
	    gotoxy(x+i,y+4);
	    cprintf("%c\n",digit2[i]);
	 }
   }
  else
  if(FL==2)
   {
    for(i=0;i<6;i++)
	{
	    gotoxy(x+i,y+8);
	    cprintf("%c\n",digit2[i]);
	 }
   for(i=0;i<6;i++)
	{
	    gotoxy(x+i,y+4);
	    cprintf("%c\n",digit2[i]);
	 }

   }

}


main()
 {
   struct time t;
   int sec1,sec2,hr1,min1,hr2,min2;
   clrscr();
   while(!kbhit())
    {
     textcolor(12);
     gettime(&t);
     delay(500);
     clrscr();
     sec1=t.ti_sec%10;
     sec2=t.ti_sec/10;

     min1=t.ti_min%10;
     min2=t.ti_min/10;

     hr1=t.ti_hour%10;
     hr2=t.ti_hour/10;

     switch(sec1)
	{
	     case 0:
		{
		  vline(77,2,1);
		  vline(70,2,1);
		  hline(71,1,0);
		  hline(71,9,0);
		  break;
	       }
	    case 1:
		{
		  vline(70,2,1);
		  break;
		}
	    case 2:
	       {
		 vline(70,6,0);
		 vline(77,2,0);
		 hline(71,1,2);
		 break;
	       }
	   case 3:
	       {
		 vline(77,2,1);
		 hline(71,1,2);
		 break;
	       }
	    case 4:
	       {
		 vline(70,2,0);
		 vline(77,2,1);
		 hline(71,5,0);
		 break;
	       }
	    case 5:
	       {
		 vline(70,2,0);
		 vline(77,6,0);
		 hline(71,1,2);
		 break;
	       }
	    case 6:
	       {
		 vline(70,2,1);
		 vline(77,6,0);
		 hline(71,1,2);
		 break;
	       }
	    case 7:
	       {
		 vline(77,2,1);
		 hline(71,1,0);
		 break;
	       }
	    case 8:
	       {
		 vline(70,2,1);
		 vline(77,2,1);
		 hline(71,1,2);
		 break;
	       }
	    case 9:
	       {
		 vline(70,2,0);
		 vline(77,2,1);
		 hline(71,1,2);
		 break;
	       }
	    default:printf("Invalid");break;
     }

     switch(sec2)
	{
	     case 0:
		{
		  vline(67,2,1);
		  vline(60,2,1);
		  hline(61,1,0);
		  hline(61,9,0);
		  break;
	       }
	    case 1:
		{
		  vline(60,2,1);
		  break;
		}
	    case 2:
	       {
		 vline(60,6,0);
		 vline(67,2,0);
		 hline(61,1,2);
		 break;
	       }
	   case 3:
	       {
		 vline(67,2,1);
		 hline(61,1,2);
		 break;
	       }
	    case 4:
	       {
		 vline(60,2,0);
		 vline(67,2,1);
		 hline(61,5,0);
		 break;
	       }
	    case 5:
	       {
		 vline(60,2,0);
		 vline(67,6,0);
		 hline(61,1,2);
		 break;
	       }
	    default:printf("Invalid");break;
     }

  switch(min1)
	{
	     case 0:
		{
		  vline(47,2,1);
		  vline(40,2,1);
		  hline(41,1,0);
		  hline(41,9,0);
		  break;
	       }
	    case 1:
		{
		  vline(40,2,1);
		  break;
		}
	    case 2:
	       {
		 vline(40,6,0);
		 vline(47,2,0);
		 hline(41,1,2);
		 break;
	       }
	   case 3:
	       {
		 vline(47,2,1);
		 hline(41,1,2);
		 break;
	       }
	    case 4:
	       {
		 vline(40,2,0);
		 vline(47,2,1);
		 hline(41,5,0);
		 break;
	       }
	    case 5:
	       {
		 vline(40,2,0);
		 vline(47,6,0);
		 hline(41,1,2);
		 break;
	       }
	    case 6:
	       {
		 vline(40,2,1);
		 vline(47,6,0);
		 hline(41,1,2);
		 break;
	       }
	    case 7:
	       {
		 vline(47,2,1);
		 hline(41,1,0);
		 break;
	       }
	    case 8:
	       {
		 vline(40,2,1);
		 vline(47,2,1);
		 hline(41,1,2);
		 break;
	       }
	    case 9:
	       {
		 vline(40,2,0);
		 vline(47,2,1);
		 hline(41,1,2);
		 break;
	       }
	    case 27:break;

	    default:printf("Invalid");break;
     }
    switch(min2)
	{
	     case 0:
		{
		  vline(37,2,1);
		  vline(30,2,1);
		  hline(31,1,0);
		  hline(31,9,0);
		  break;
	       }
	    case 1:
		{
		  vline(30,2,1);
		  break;
		}
	    case 2:
	       {
		 vline(30,6,0);
		 vline(37,2,0);
		 hline(31,1,2);
		 break;
	       }
	   case 3:
	       {
		 vline(37,2,1);
		 hline(31,1,2);
		 break;
	       }
	    case 4:
	       {
		 vline(30,2,0);
		 vline(37,2,1);
		 hline(31,5,0);
		 break;
	       }
	    case 5:
	       {
		 vline(30,2,0);
		 vline(37,6,0);
		 hline(31,1,2);
		 break;
	       }
	    default:printf("Invalid");break;
     }
    switch(hr1)
	{
	     case 0:
		{
		  vline(17,2,1);
		  vline(10,2,1);
		  hline(11,1,0);
		  hline(11,9,0);
		  break;
	       }
	    case 1:
		{
		  vline(10,2,1);
		  break;
		}
	    case 2:
	       {
		 vline(10,6,0);
		 vline(17,2,0);
		 hline(11,1,2);
		 break;
	       }
	   case 3:
	       {
		 vline(17,2,1);
		 hline(11,1,2);
		 break;
	       }
	    case 4:
	       {
		 vline(10,2,0);
		 vline(17,2,1);
		 hline(11,5,0);
		 break;
	       }
	    case 5:
	       {
		 vline(10,2,0);
		 vline(17,6,0);
		 hline(11,1,2);
		 break;
	       }
	    case 6:
	       {
		 vline(10,2,1);
		 vline(17,6,0);
		 hline(11,1,2);
		 break;
	       }
	    case 7:
	       {
		 vline(17,2,1);
		 hline(11,1,0);
		 break;
	       }
	    case 8:
	       {
		 vline(10,2,1);
		 vline(17,2,1);
		 hline(11,1,2);
		 break;
	       }
	    case 9:
	       {
		 vline(10,2,0);
		 vline(17,2,1);
		 hline(11,1,2);
		 break;
	       }
	    default:printf("Invalid");break;
     }
    switch(hr2)
	{
	     case 0:
		{
		  vline(07,2,1);
		  vline(00,2,1);
		  hline(01,1,0);
		  hline(01,9,0);
		  break;
	       }
	    case 1:
		{
		  vline(1,2,1);
		  break;
		}
	    case 2:
	       {
		 vline(1,6,0);
		 vline(8,2,0);
		 hline(2,1,2);
		 break;
	       }
	   case 3:
	       {
		 vline(8,2,1);
		 hline(2,1,2);
		 break;
	       }
	    case 4:
	       {
		 vline(1,2,0);
		 vline(8,2,1);
		 hline(2,5,0);
		 break;
	       }
	    case 5:
	       {
		 vline(1,2,0);
		 vline(8,6,0);
		 hline(2,1,2);
		 break;
	       }
	    default:printf("Invalid");break;
     }
      gotoxy(22,5);
      cprintf("�� ��");

      gotoxy(52,5);
      cprintf("�� ��");
      gotoxy(15,20);
      textcolor(2);
      cprintf("D I G I T A L  CLOCK BY S U M I T--K U M A R");

      gotoxy(1,24);
      cprintf("Press any key to E X I T");

    }
 }