using System;

namespace FTPCom
{
	/// <summary>
	/// 
	/// </summary>
	public class FTPEventArgs : System.EventArgs
	{
		private bool m_bResult;
		private string m_sResult;
		private string m_sError;
		private int m_timeelapsed;
		private int m_totalbytes;
		private string m_function;

		public FTPEventArgs()
		{
			// 
			// TODO: Add constructor logic here
			//
			m_bResult = false;
			m_sResult = "";
			m_sError = "";
		}
		public FTPEventArgs(bool bResult, string sResult, string sError)
		{
			m_bResult = bResult;
			m_sResult = sResult;
			m_sError = sError;
		}

		public bool Result
		{
			get
			{
				return m_bResult;
			}
			set
			{
				m_bResult = value;
			}
		}

		public string ResultCode
		{
			get
			{
				return m_sResult;
			}
			set
			{
				m_sResult = value;
			}
		}

		public string Error
		{
			get
			{
				return m_sError;
			}
			set
			{
				m_sError = value;
			}
		}

		public int TimeElapsed
		{
			get
			{
				return m_timeelapsed;
			}
			set
			{
				m_timeelapsed = value;
			}
		}

		public int TotalBytes
		{
			get
			{
				return m_totalbytes;
			}
			set
			{
				m_totalbytes = value;
			}
		}

		public string FunctionName
		{
			get
			{
				return m_function;
			}
			set
			{
				m_function = value;
			}
		}
	}
}
