using System.Collections;
using Calc.Interpreter.Var;

using StringBuffer = System.Text.StringBuilder;

namespace Calc.Interpreter 
{

	/// <summary>
	/// represents stack frame on the execution stack
	/// of the interpreter.
	/// Hold the name of the function that is being called
	/// and all passed arguments and local variables
	/// IsActive if set to true, terminates the execution
	/// (return statement does that)
	/// </summary>
	public class Frame 
	{

		string name;
		Hashtable vars;
		bool active;

		public Frame(string name)
		{
			this.name = name;			
			this.vars = new Hashtable();
		
			this.active = true;
		}
	
		public bool IsActive { get {return this.active; }
			set { this.active = value; }
		}
		
	
		public string Name { get { return this.name; }}

		public void addVariable(string name, Variable val)
		{
			vars[name] = val;	
		}
	
		public bool hasVariable(string name) 
		{
			return vars.ContainsKey(name);
		}
	
		public Variable getValue(string name)
		{
			return (Variable)vars[name];
		}
	
		public ICollection Variables
		{
			get 
			{
				return this.vars.Keys;
			}
		}
	
		public override string ToString()
		{
			StringBuffer buf = new StringBuffer();
			buf.Append("Variables in function '" + Name + "':\n");
			
			foreach (string varName in vars)
			{
				buf.Append("\t" + varName + ": " + getValue(varName).toString());
			}
			return buf.ToString();
		}
	}
}