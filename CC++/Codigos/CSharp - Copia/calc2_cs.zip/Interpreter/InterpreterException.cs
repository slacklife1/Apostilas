using System;

namespace Calc.Interpreter 
{

	/// <summary>
	/// exception thrown when interpreter encounters errors
	/// </summary>
	public class InterpreterException : ApplicationException 
	{

		public InterpreterException(string msg)
			:base(msg)
		{

		}

	}
}