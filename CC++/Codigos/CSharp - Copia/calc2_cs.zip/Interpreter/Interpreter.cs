using System.IO;
using System.Collections;
using Calc.Interpreter.Var;
using Calc.AST;
using System;

using StringBuffer = System.Text.StringBuilder;

namespace Calc.Interpreter 
{

	/// <summary>
	/// interpreter uses the AST visitor to execute the program
	/// </summary>
	public class Interpreter : Visitor 
	{

		Program program;	// program to execute
		Hashtable functions;// functions availble to call

		Stack frames;		// execution stack 
		Frame currentFrame;	// current frame of execution
		Frame mainFrame;	// frame for the main execution, variable access could come from currentFrame or mainFrame

		TextWriter writer;	// all output is sent to the writer
	
		Variable returnValue; // all expressions evaluate to a variable and set the returnValue to result of evaluation

		Random rand;		// for using random native functions
	
		public Interpreter(Program program) 
		{
			this.program = program;
		
			functions = new Hashtable();

			frames = new Stack();		
		
			returnValue = new VarDouble(0);

			rand = new Random();
		}
	
		/// <summary>
		/// start interpreting and send output to writer
		/// </summary>
		/// <param name="writer"></param>
		public void process(TextWriter writer)
		{
		
			this.writer = writer;
			program.acceptVisitor(this);	
		}

		public void visitProgram(Program p) 
		{
			// get all the functions
			for (int i=0; i<p.FunctionsCount; i++) 
			{
				Function f = p.FunctionAt(i);
				functions[f.Name] = f;
			}		
		
			// add native functions
			addNativeFunctions();
		
			mainFrame = new Frame("main");
			frames.Push(mainFrame);
			currentFrame = mainFrame;
		
			p.Body.acceptVisitor(this);		
		}

		public void visitFunction(Function func) 
		{
			// we should never visit function construct
		}

		public void visitBlock(Block block) 
		{
			for (int i=0; i<block.NumStatements && currentFrame.IsActive; i++)
				block.StatementAt(i).acceptVisitor(this);
			
		}

		public void visitStatExp(StatExp stat) 
		{
			// evaluation expression
			stat.Exp.acceptVisitor(this);
		
		}
	
		public void visitStatBlock(StatBlock stat)
		{
			stat.Block.acceptVisitor(this);	
		}

		public void visitStatIf(StatIf stat)
		{
			stat.Exp.acceptVisitor(this);
			bool result = returnValue.toBoolean();
			if (result)
				stat.TrueBlock.acceptVisitor(this);
			else if (stat.FalseBlock != null)
				stat.FalseBlock.acceptVisitor(this);
			
		}

		public void visitStatWhile(StatWhile stat)
		{
			Exp exp = stat.Exp;
			Statement body = stat.Block;
		
		
			while (true)
			{
				exp.acceptVisitor(this);
				if (!returnValue.toBoolean())
					break;
				
				body.acceptVisitor(this);	
			}		
			
		}
	
		public void visitStatFor(StatFor stat)
		{
			Exp initExp = stat.InitExp;
			Exp condExp = stat.CondExp;
			Exp updateExp = stat.UpdateExp;
			Statement body = stat.Body;
		
			if (initExp != null)
				initExp.acceptVisitor(this);
			
			while(true)
			{
				// check condition
				if (condExp != null) 
				{
					condExp.acceptVisitor(this);

					if (!returnValue.toBoolean())
						break;	
				}
			
				// run body
				body.acceptVisitor(this);
			
				// update condition
				if (updateExp != null) 
					updateExp.acceptVisitor(this);	

			}
		
		}


		public void visitStatReturn(StatReturn stat)
		{
			stat.Exp.acceptVisitor(this);
		
			currentFrame.IsActive = false;
		}

		public void visitExpAssign(ExpAssign exp) 
		{
			Exp var = exp.VariableExp;
		
			if (var.Type == ExpType.VAR) 
			{
				ExpVar expVar = (ExpVar)var;

				// evaluation expression
				exp.ValueExp.acceptVisitor(this);
		
				this.storeVariable(expVar.Name, returnValue);
			}
			else if (var.Type == ExpType.ARRAY)
			{
				exp.ValueExp.acceptVisitor(this);
				Variable storeVar = returnValue;
			
				// expression must evaluate to variable
				ExpArray expArray = (ExpArray)var;
				expArray.VariableExp.acceptVisitor(this);
				if (returnValue.Type != VarType.ARRAY)
					throw new InterpreterException("Cannot apply array index to variable of type: " + returnValue.Type);
				
				VarArray array = (VarArray)returnValue;
			
				// evaluate index
				expArray.IndexExp.acceptVisitor(this);
				int index = (int)returnValue.toInt();
			
				array.setAt(index, storeVar);
				returnValue = storeVar;

			}
			else if (var.Type == ExpType.STRUCT)
			{
				// evaluate right side
				exp.ValueExp.acceptVisitor(this);
			
				ExpStruct expStr = (ExpStruct)var;
				VarStruct varStr = lookupStruct(expStr.Exp);
				varStr.addVariable(expStr.Name, returnValue);			
						
			}
			else
				throw new InterpreterException("LHS of assignment is not valid expression.");
		}
	
		VarStruct lookupStruct(Exp exp)
		{
			if (exp.Type == ExpType.VAR) 
			{
				string varName = ((ExpVar)exp).Name;
				Variable var = lookupVariable(varName);
				if (var == null || var.Type != VarType.STRUCT)
					var = new VarStruct();
				
				VarStruct varStruct = (VarStruct)var;
				this.addVariable(varName, varStruct);
			
				return varStruct;
			} 
			else 
			{ // assume inner is ExpStruct if it's not ExpVar
				ExpStruct expStruct = (ExpStruct)exp;			
				VarStruct varStruct = lookupStruct(expStruct.Exp);

				string member = expStruct.Name;

				if (varStruct.hasVariable(member) && varStruct.getVariable(member).Type == VarType.STRUCT)
					return (VarStruct)varStruct.getVariable(member);
		
				// struct didn't have the member, so create it
				VarStruct newStruct = new VarStruct();
				varStruct.addVariable(member, newStruct);
		
				return newStruct;			
			}
		}

		public void visitExpBinary(ExpBinary exp) 
		{
			exp.LeftExp.acceptVisitor(this);
			Variable left = returnValue;
			exp.RightExp.acceptVisitor(this);
			Variable right = returnValue;
		
			returnValue = left.binaryOperation(exp.Operator, right);
		
		}
	
		public void visitExpUnary(ExpUnary exp)
		{
			Exp innerExp = exp.Exp;
			innerExp.acceptVisitor(this);
		
			returnValue = returnValue.unaryOperation(exp.Operator);		
		}
	

		public void visitExpVar(ExpVar exp) 
		{
			returnValue = this.getVariable(exp.Name);
		}

		public void visitExpFunc(ExpFunc exp) 
		{
			string funName = exp.Name;
			// lookup function
			Function fun = functions[funName] as Function;
			if (fun == null)
				throw new InterpreterException("Function '" + funName + "' is not defined.");
			
			// figure out parameters
			if (fun.ArgCount != exp.ParamCount)
				throw new InterpreterException("Function '" + funName + "' is expecting " + fun.ArgCount + " parameters.");

			Frame f = new Frame(fun.Name);
			
			// evaluate and add parameters as variables
			for (int i=0; i<fun.ArgCount; i++) 
			{
				exp.ParamAt(i).acceptVisitor(this);

				f.addVariable(fun.ArgAt(i), returnValue);
			}
		
			// call the function, by visiting it's body
			frames.Push(f);		
			currentFrame = f;

			if (fun.IsNative)
				this.executeNativeFunction(fun);
			else
				fun.Body.acceptVisitor(this);
			
			frames.Pop();
			if (currentFrame != mainFrame)
				currentFrame = (Frame)frames.Peek();
			
		
		}

		public void visitExpStruct(ExpStruct exp)
		{
			Exp inner = exp.Exp;
		
			if (inner.Type == ExpType.STRUCT)
				inner.acceptVisitor(this);
			else if (exp.Exp.Type == ExpType.VAR)
				inner.acceptVisitor(this);
			else
				throw new InterpreterException("Cannot apply struct construct to exp of type: " + exp.Type);
			
			if (returnValue.Type == VarType.STRUCT)
			{
				VarStruct str = (VarStruct)returnValue;
				string name = exp.Name;
				if (!str.hasVariable(name))
					throw new InterpreterException("Cannot find member '" + name + "' in structure.");
				
				returnValue = str.getVariable(name);
				
			}
			else
				throw new InterpreterException("Cannot apply struct construct to variable of type: " + returnValue.Type);		
		}
	
		public void visitExpArray(ExpArray exp)
		{
			// evaluate exp
			exp.VariableExp.acceptVisitor(this);
			if (returnValue.Type != VarType.ARRAY)
				throw new InterpreterException("Cannot apply array index to variable of type: " + returnValue.Type);
			
			VarArray array = (VarArray)returnValue;
		
			// evaluate index
			exp.IndexExp.acceptVisitor(this);
			int index = (int)returnValue.toInt();
		
			returnValue = array.getAt(index);
		}
	

		public void visitExpLiteralDouble(ExpLiteralDouble exp) 
		{
			returnValue = new VarDouble(exp.Value);
		}

	
		public void visitExpLiteralBool(ExpLiteralBool exp)
		{
			returnValue = new VarBool(exp.Value);
		}
	
		public void visitExpLiteralString(ExpLiteralString exp)
		{
			returnValue = new VarString(exp.Value);			
		}

		public void visitExpLiteralInt(ExpLiteralInt exp)
		{
			returnValue = new VarInt(exp.Value);			
		}


		public Variable getVariable(string name)
		{
			// check in current frame
			if (currentFrame.hasVariable(name))
				return currentFrame.getValue(name);
			
			if (currentFrame != mainFrame && mainFrame.hasVariable(name))
				return mainFrame.getValue(name);
			
			StringBuffer buf = new StringBuffer();
			buf.Append("Variable '" + name + "' is not defined.\n");
		
			// show all variables for this frame
			buf.Append(currentFrame.ToString());

			if (currentFrame != mainFrame) 
			{
				buf.Append(mainFrame.ToString());			
			}	
		
			throw new InterpreterException(buf.ToString());
		}
	
		/**
		 * looks up variable in current and main scope.
		 * If it doesn't exist returnsnull
		 */
		public Variable lookupVariable(string name)
		{
			// check in current frame
			if (currentFrame.hasVariable(name))
				return currentFrame.getValue(name);
			
			if (currentFrame != mainFrame && mainFrame.hasVariable(name))
				return mainFrame.getValue(name);

			return null;			
		}	
	
		/**
		 * adds the variable to current scope
		 */
		public void addVariable(string name, Variable val)
		{		
			currentFrame.addVariable(name, val);
		}
	
		/**
		 * adds variable to current scope it's defined there
		 * or main scope (global) if its there
		 */
		public void storeVariable(string name, Variable val)
		{
			if (currentFrame.hasVariable(name))
				currentFrame.addVariable(name, val);
			else
				mainFrame.addVariable(name, val);
		}
		
		void addNativeFunctions()
		{
			addNativeFunction("sin", 1, 1);
			addNativeFunction("cos", 1, 2);
			addNativeFunction("pow", 2, 3);	
			addNativeFunction("random", 0, 4);
			addNativeFunction("round", 1, 5);
			addNativeFunction("log", 1, 6);		
			addNativeFunction("sqrt", 1, 7);		
			addNativeFunction("exp", 1, 8);		
			addNativeFunction("print", 1, 9);
			addNativeFunction("println", 1, 10);		
			addNativeFunction("getTickCount", 0, 11);
			addNativeFunction("randRange", 2, 12);
			addNativeFunction("toDouble", 1, 13);
			addNativeFunction("toInt", 1, 14);
			addNativeFunction("toString", 1, 15);
			addNativeFunction("toBool", 1, 16);
			addNativeFunction("structNew", 0, 17);
			addNativeFunction("arrayNew", 0, 18);
			addNativeFunction("arrayLen", 1, 19);
			addNativeFunction("structKeyExists", 2, 20);
		}
	
		void addNativeFunction(string name, int numParams, int index)
		{
			ArrayList args = new ArrayList();
			for (int i=0; i<numParams; i++)
				args.Add("$" + i);
			
			Function fun = new Function(name, args, index);
			functions[name] = fun;
		}
	
		void executeNativeFunction(Function fun)
		{
			// the frame contains the parameters	
			switch (fun.NativeIndex)
			{
					// sin
				case 1: returnValue = new VarDouble(Math.Sin(currentFrame.getValue("$0").toDouble())); 
					break;
			
					// cos
				case 2: returnValue = new VarDouble(Math.Cos(currentFrame.getValue("$0").toDouble())); 
					break;
			
					// pow
				case 3: returnValue = new VarDouble(Math.Pow(currentFrame.getValue("$0").toDouble(), currentFrame.getValue("$1").toDouble())); 
					break;			
			
					// random
				case 4: returnValue = new VarDouble(rand.NextDouble()); 
					break;
			
					// round
				case 5: returnValue = new VarDouble(Math.Round(currentFrame.getValue("$0").toDouble())); 
					break;
			
					// log
				case 6: returnValue = new VarDouble(Math.Log(currentFrame.getValue("$0").toDouble())); 
					break;
			
					// sqrt
				case 7: returnValue = new VarDouble(Math.Sqrt(currentFrame.getValue("$0").toDouble())); 
					break;
			
					// exp
				case 8: returnValue = new VarDouble(Math.Exp(currentFrame.getValue("$0").toDouble())); 
					break;
			
					// print
				case 9: returnValue = currentFrame.getValue("$0"); writer.Write(returnValue.toString()); writer.Flush(); 
					break;
			
					// println
				case 10: returnValue = currentFrame.getValue("$0"); writer.WriteLine(returnValue.toString()); writer.Flush(); 
					break;
			
					// getTickCount
				case 11: returnValue = new VarInt(System.Environment.TickCount); 
					break;
			
					// randRange
				case 12: 
					long numOne = currentFrame.getValue("$0").toInt(); 
					long numTwo = currentFrame.getValue("$1").toInt();
					long temp = rand.Next((int)numOne, (int)numTwo+1);
					returnValue = new VarInt(temp);
					break;
				
					// toDouble
				case 13: returnValue = new VarDouble(currentFrame.getValue("$0").toDouble()); 
					break;
			
					// toInt
				case 14: returnValue = new VarInt(currentFrame.getValue("$0").toInt()); 
					break;
			
					// toString
				case 15: returnValue = new VarString(currentFrame.getValue("$0").toString()); 
					break;
			
					// toBool
				case 16: returnValue = new VarBool(currentFrame.getValue("$0").toBoolean()); 
					break;
			
					// structNew
				case 17: returnValue = new VarStruct();
					break;
			
					// arrayNew
				case 18: returnValue = new VarArray();
					break;
			
					// arrayLen
				case 19:
					Variable var = currentFrame.getValue("$0");
					if (var.Type != VarType.ARRAY)
						throw new InterpreterException("Cannot get size of array from non-array variable.");
					VarArray arr = (VarArray)var;
					returnValue = new VarInt(arr.Size);
					break;

					// structKeyExists
				case 20:
					Variable varStruct = currentFrame.getValue("$0");
					if (varStruct.Type != VarType.STRUCT)
						throw new InterpreterException("First parameter to structKeyExists must be a structure.");
					VarStruct str = (VarStruct)varStruct;
				
					// get key name
					String key = currentFrame.getValue("$1").toString();
				
					returnValue = new VarBool(str.hasVariable(key));												
					break;

			}	
		
		
		}
	
	}
}