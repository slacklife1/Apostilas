using System;
using Calc.AST;
using Calc.Interpreter;

namespace Calc.Interpreter.Var 
{

	public class VarString : Variable 
	{

		string val;
	
		public VarString(string val) 
		{
			this.val = val;
		}

		public VarType Type 
		{
			get 
			{
				return VarType.STRING;
			}
		}

		public Variable unaryOperation(ExpUnaryOperator oper) 
		{
			switch (oper)
			{
				case ExpUnaryOperator.NOT: return new VarInt(val.Length);
				default:	
					throw new InterpreterException("Unary operator '" + oper + "' cannot be applied to string.");		
			}
		}

		public Variable binaryOperation(ExpBinaryOperator oper, Variable rhs) 
		{
			string rhsValue = rhs.toString();
			switch (oper)
			{
				case ExpBinaryOperator.PLUS: return new VarString(val + rhsValue);	
				case ExpBinaryOperator.EQUAL: return new VarBool(val == rhsValue);
				case ExpBinaryOperator.NOTEQUAL: return new VarBool(val != rhsValue);
				default:	
					throw new InterpreterException("Operator '" + oper + "' cannot be applied to string.");		
			
			}
		}

		public double toDouble() 
		{
			try 
			{
				double dVal = Double.Parse(val);
				return dVal;
			}
			catch (FormatException)
			{
				throw new InterpreterException("string '" + this.val + "' cannot be converted to double.");
			}
			
		}

		public long toInt()
		{
			try 
			{
				long dVal = Int64.Parse(val);
				return dVal;
			}
			catch (FormatException)
			{
				throw new InterpreterException("string '" + this.val + "' cannot be converted to integer.");
			}

		}

		public bool toBoolean() 
		{
			if (val.Length == 0)
				return false;
			else return true;
		}
	
		public string toString()
		{
			return this.val;	
		}
	
	

	}
}