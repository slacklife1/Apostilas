using Calc.Interpreter;
using Calc.AST;
using System.Collections;

namespace Calc.Interpreter.Var 
{

	/// <summary>
	/// represents array in a program
	/// the array is actually stored as hashtable, so 
	/// it does not automatically resize itself, because there is no need to.
	/// Also, while the array might be of size 10, element at position 5 might
	/// be not availble.
	/// </summary>
	public class VarArray : Variable 
	{

		Hashtable array;
		int curSize;

		public VarArray() 
		{
			array = new Hashtable();
			curSize = 0;
		}

		/// <summary>
		/// gets the maximum element size of this array
		/// </summary>
		public int Size { 
			get { return curSize; }
		}
	
		/// <summary>
		/// checks if element exists at specified position
		/// </summary>
		/// <param name="pos">position</param>
		/// <returns>true if array has element at pos</returns>
		public bool existsAt(int pos)
		{
			return array.ContainsKey(pos);		
		}
	
		/// <summary>
		/// returns variable at specified position, 
		/// or throws InterpreterException if element is not set at that position
		/// </summary>
		/// <param name="pos"></param>
		/// <returns></returns>
		public Variable getAt(int pos) 
		{ 
			if (!existsAt(pos))
				throw new InterpreterException("Element at array position " + pos + " does not exist.");
			return (Variable)array[pos]; 
		}
	
	
		/// <summary>
		/// sets element at specified position
		/// </summary>
		/// <param name="pos"></param>
		/// <param name="var"></param>
		public void setAt(int pos, Variable var) 
		{ 
			if (pos < 0)
				throw new InterpreterException("Cannot store variable at position " + pos + " in array.");
		
			if (pos > curSize)
				curSize = pos;

			array[pos] = var;
		}

		public VarType Type 
		{
			get 
			{
				return VarType.ARRAY;
			}
		}

		/// <summary>
		/// performs unary opration on array.
		/// The only operation supported is !array, which returns size of the array
		/// else it throws InterpreterException
		/// </summary>
		/// <param name="oper"></param>
		/// <returns></returns>
		public Variable unaryOperation(ExpUnaryOperator oper) 
		{
			switch (oper)
			{
				case ExpUnaryOperator.NOT: return new VarInt(curSize);
				default:	
					throw new InterpreterException("Unary operator '" + oper + "' cannot be applied to array.");		
			}

		}

		/// <summary>
		/// performs binary operator on array.
		/// Always throws InterpreterException because array does
		/// not support binary operators
		/// </summary>
		/// <param name="oper"></param>
		/// <param name="rhs"></param>
		/// <returns></returns>
		public Variable binaryOperation(ExpBinaryOperator oper, Variable rhs) 
		{
			throw new InterpreterException("Binary operator '" + oper + "' cannot be applied to array.");		

		}

		/// <summary>
		/// always throws InterpreterException
		/// </summary>
		/// <returns></returns>
		public double toDouble() 
		{
			throw new InterpreterException("Cannot convert array to double.");		
		}

		/// <summary>
		/// always throws InterpreterException
		/// </summary>
		/// <returns></returns>
		public bool toBoolean() 
		{
			throw new InterpreterException("Cannot convert array to boolean.");		
		}

		/// <summary>
		/// always throws InterpreterException
		/// </summary>
		/// <returns></returns>
		public long toInt() 
		{
			throw new InterpreterException("Cannot convert array int.");		
		}

		/// <summary>
		/// always throws InterpreterException
		/// </summary>
		/// <returns></returns>
		public string toString()
		{
			throw new InterpreterException("Cannot convert array string.");					
		}
	}
}