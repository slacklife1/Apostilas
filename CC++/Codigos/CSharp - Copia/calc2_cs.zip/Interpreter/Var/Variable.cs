using Calc.AST;

namespace Calc.Interpreter.Var 
{

	/// <summary>
	/// all possible variable types
	/// </summary>
	public enum VarType 
	{
		DOUBLE, STRING, BOOL, INT, STRUCT, ARRAY
	};

	public interface Variable 
	{
		VarType Type { get; }
	
		
		/// <summary>
		/// Performs unary operation on this variable.
		/// Should return NEW variable (not update self)
		/// Will throw InterpreterException if variable does not support 
		/// this operation
		/// </summary>
		Variable unaryOperation(ExpUnaryOperator op);
	
		/// <summary>
		/// performs binary operation on self with rhs
		/// Should return NEW variable (not update self)
		/// Will throw InterpreterException if variable does not support
		/// this operation
		/// </summary>
		Variable binaryOperation(ExpBinaryOperator op, Variable rhs);

		/// <summary>
		/// convert variable to double, or throw exception if can't
		/// </summary>
		/// <returns></returns>
		double toDouble();

		/// <summary>
		/// convert variable to boolean, or throw exception if can't
		/// </summary>
		/// <returns></returns>
		bool toBoolean();

		/// <summary>
		/// convert variable to string, or throw exception if can't
		/// </summary>
		/// <returns></returns>
		string toString();
	
		/// <summary>
		/// convert variable to in, or throw exception if can't
		/// </summary>
		/// <returns></returns>
		long toInt();
	}
}