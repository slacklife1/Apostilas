using Calc.AST;
using Calc.Interpreter;

namespace Calc.Interpreter.Var 
{

	public class VarInt : Variable 
	{

		long val;

		public VarInt(long val) 
		{
			this.val = val;
		}

		public VarType Type
		{
			get 
			{
				return VarType.INT;
			}
		}

		public Variable unaryOperation(ExpUnaryOperator oper) 
		{
			switch (oper)
			{
				case ExpUnaryOperator.NEGATIVE: return new VarInt(0 - val);
				case ExpUnaryOperator.POSITIVE: return new VarInt(System.Math.Abs(val));
				case ExpUnaryOperator.DEC: return new VarInt(val--);						
				case ExpUnaryOperator.INC: return new VarInt(val++);	
			
				default:
					throw new InterpreterException("Operator '" + oper + "' cannot be applied to int.");
			}
		}

		public Variable binaryOperation(ExpBinaryOperator oper, Variable rhs) 
		{
			long rhsValue = rhs.toInt();
			switch (oper)
			{
				case ExpBinaryOperator.MINUS: return new VarInt(val - rhsValue);
				case ExpBinaryOperator.PLUS: return new VarInt(val + rhsValue);
				case ExpBinaryOperator.TIMES: return new VarInt(val * rhsValue);
				case ExpBinaryOperator.MOD: return new VarInt(val % rhsValue);
				case ExpBinaryOperator.DIV: return new VarInt(val / rhsValue);
			
				case ExpBinaryOperator.EQUAL: return new VarBool(val == rhsValue);
				case ExpBinaryOperator.NOTEQUAL: return new VarBool(val != rhsValue);

				case ExpBinaryOperator.GT: return new VarBool(val > rhsValue);
				case ExpBinaryOperator.GTE: return new VarBool(val >= rhsValue);
				case ExpBinaryOperator.LT: return new VarBool(val < rhsValue);
				case ExpBinaryOperator.LTE: return new VarBool(val <= rhsValue);
														
			
				default:
					throw new InterpreterException("Operator '" + oper + "' cannot be applied to double.");
			
			}
		}

		public double toDouble() 
		{
			return (double)val;
		}

		public long toInt() 
		{
			return val;
		}

		public bool toBoolean() 
		{
			if (val == 0)
				return false;
			else return true;
		}
	
		public string toString()
		{
			return val.ToString();
		}

	}
}