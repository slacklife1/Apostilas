using System.Collections;
using Calc.Interpreter;
using Calc.AST;
using StringBuilder = System.Text.StringBuilder;

namespace Calc.Interpreter.Var 
{
	public class VarStruct : Variable 
	{
		Hashtable members;

		public VarStruct() 
		{
			this.members = new Hashtable();
		}

		public void addVariable(string name, Variable var)
		{
			members[name] = var;
		}
	
		public bool hasVariable(string name)
		{
			return members.ContainsKey(name);
		}
	
		public Variable getVariable(string name)
		{
			return (Variable)members[name];
		}

		public VarType Type
		{
			get 
			{
				return VarType.STRUCT;
			}
		}

		public Variable unaryOperation(ExpUnaryOperator oper) 
		{
			throw new InterpreterException("Unary operation '" + oper + "' cannot be applied to struct.");
		}

		public Variable binaryOperation(ExpBinaryOperator oper, Variable rhs) 
		{
			throw new InterpreterException("Binary operation '" + oper + "' cannot be applied to struct.");
		}

		public double toDouble() 
		{
			throw new InterpreterException("Struct cannot be converted to double.");
		}

		public bool toBoolean() 
		{
			throw new InterpreterException("Struct cannot be converted to boolean.");
		}

		public long toInt() 
		{
			throw new InterpreterException("Struct cannot be converted to int.");
		}
	
		public string toString()
		{
			// print names of all variables
			StringBuilder buf = new StringBuilder();
			buf.Append("[");
		
			int i=0;
			foreach (string varName in members)
			{
				if (i > 0)
					buf.Append(",");
				buf.Append(varName);
				i++;
			}
			buf.Append("]");
			return buf.ToString();
		}

	}
}