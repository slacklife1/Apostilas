using Calc.AST;
using Calc.Interpreter;

namespace Calc.Interpreter.Var 
{

	/// <summary>
	/// represents variable of type boolean in interpreter
	/// </summary>
	public class VarBool : Variable 
	{

		bool val;

		/// <summary>
		/// creates the variable with initial value
		/// </summary>
		/// <param name="val">initial value</param>
		public VarBool(bool val) 
		{
			this.val = val;
		}

		/// <summary>
		/// returns VarType.BOOL
		/// </summary>
		public VarType Type
		{
			get 
			{
				return VarType.BOOL;
			}
		}

		/// <summary>
		/// performs unary operation on boolean.
		/// Only NOT (!) operation is supported, 
		/// else throws InterpreterException
		/// </summary>
		/// <param name="oper">operation to perform</param>
		/// <returns>new variable after operation</returns>
		public Variable unaryOperation(ExpUnaryOperator oper) 
		{
			switch (oper)
			{
				case ExpUnaryOperator.NOT: return new VarBool(!val);
				default:
					throw new InterpreterException("Operator '" + oper + "' cannot be applied to boolean.");
			}
		}

		/// <summary>
		/// performs binary operation
		/// Only EQUAL (==) and NOTEQUAL (!=) is supported
		/// else throws InterpreterException
		/// </summary>
		/// <param name="oper">operator to perform</param>
		/// <param name="rhs"></param>
		/// <returns></returns>
		public Variable binaryOperation(ExpBinaryOperator oper, Variable rhs) 
		{
			bool rhsValue = rhs.toBoolean();
			switch (oper)
			{
				case ExpBinaryOperator.EQUAL: return new VarBool(val == rhsValue);
				case ExpBinaryOperator.NOTEQUAL: return new VarBool(val != rhsValue);
				default:
					throw new InterpreterException("Operator '" + oper + "' cannot be applied to boolean.");
			
			}
		}

		public double toDouble() 
		{
			if (val)
				return 1;
			else return 0;
		}

		public long toInt() 
		{
			if (val)
				return 1;
			else return 0;
		}


		public bool toBoolean() 
		{
			return val;
		}


		public string toString()
		{
			return val.ToString();
		}
	}
}