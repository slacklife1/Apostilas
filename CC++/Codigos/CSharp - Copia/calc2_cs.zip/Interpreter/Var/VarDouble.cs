using Calc.AST;
using Calc.Interpreter;

namespace Calc.Interpreter.Var 
{

	public class VarDouble : Variable 
	{

		double val;

		public VarDouble(double val) 
		{	
			this.val = val;
		}

		public VarType Type 
		{
			get 
			{
				return VarType.DOUBLE;
			}
		}

		public Variable unaryOperation(ExpUnaryOperator oper) 
		{
			switch (oper)
			{
				case ExpUnaryOperator.NEGATIVE: return new VarDouble(0 - val);
				case ExpUnaryOperator.POSITIVE: return new VarDouble(System.Math.Abs(val));
				case ExpUnaryOperator.DEC: return new VarDouble(val--);						
				case ExpUnaryOperator.INC: return new VarDouble(val++);	
			
				default:
					throw new InterpreterException("Operator '" + oper + "' cannot be applied to double.");
			}
		}

		public Variable binaryOperation(ExpBinaryOperator oper, Variable rhs) 
		{
			double rhsValue = rhs.toDouble();
			switch (oper)
			{
				case ExpBinaryOperator.MINUS: return new VarDouble(val - rhsValue);
				case ExpBinaryOperator.PLUS: return new VarDouble(val + rhsValue);
				case ExpBinaryOperator.TIMES: return new VarDouble(val * rhsValue);
				case ExpBinaryOperator.MOD: return new VarDouble(val % rhsValue);
				case ExpBinaryOperator.DIV: return new VarDouble(val / rhsValue);
			
				case ExpBinaryOperator.EQUAL: return new VarBool(val == rhsValue);
				case ExpBinaryOperator.NOTEQUAL: return new VarBool(val != rhsValue);

				case ExpBinaryOperator.GT: return new VarBool(val > rhsValue);
				case ExpBinaryOperator.GTE: return new VarBool(val >= rhsValue);
				case ExpBinaryOperator.LT: return new VarBool(val < rhsValue);
				case ExpBinaryOperator.LTE: return new VarBool(val <= rhsValue);
														
			
				default:
					throw new InterpreterException("Operator '" + oper + "' cannot be applied to double.");
			
			}
		}

		public double toDouble() 
		{
			return val;
		}

		public long toInt() 
		{
			return (int)val;
		}

		public bool toBoolean() 
		{
			if (val == 0)
				return false;
			else return true;
		}
	
		public string toString()
		{
			return val.ToString();
		}

	}
}