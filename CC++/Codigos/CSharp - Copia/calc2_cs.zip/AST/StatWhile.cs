namespace Calc.AST 
{

	/// <summary>
	/// statement that represents while loop
	/// </summary>
	public class StatWhile : Statement 
	{

		Exp exp;
		Statement block;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="exp">expression that evaluates to bool</param>
		/// <param name="block">body of the while loop</param>
		public StatWhile(Exp exp, Statement block) 
			:base(StatType.WHILE)
		{
			this.exp = exp;
			this.block = block;
		}
	
		/// <summary>
		/// gets the expression for the while loop
		/// </summary>
		public Exp Exp {
			get { return this.exp; }
		}

		/// <summary>
		/// gets the body of the while loop
		/// </summary>
		public Statement Block { 
			get {return this.block; }
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitStatWhile(this);
		}

	}
}