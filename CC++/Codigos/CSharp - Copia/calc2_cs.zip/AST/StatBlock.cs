using System.Collections;

namespace Calc.AST 
{

	/// <summary>
	/// StatBlock is a statement that is a block
	/// </summary>
	public class StatBlock : Statement 
	{

		Block block;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="block">Block for this statement</param>
		public StatBlock(Block block) 
			:base(StatType.BLOCK)
		{
			this.block = block;
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitStatBlock(this);
		}

		/// <summary>
		/// gets the block of this statement
		/// </summary>
		public Block Block
		{
			get 
			{
				return block;
			}
		}

	}
}