namespace Calc.AST
{

	/// <summary>
	/// integer literal value. 
	/// The actual type is long, so that big numbers can be represented
	/// </summary>
	public class ExpLiteralInt : Exp 
	{

		long literalValue;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="v">value for the expression</param>
		public ExpLiteralInt(long v) 
			:base(ExpType.LITERAL_INT)
		{
			this.literalValue = v;
		}
	
		/// <summary>
		/// gets the literal value
		/// </summary>
		public long Value { 
			get {return this.literalValue; }
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitExpLiteralInt(this);		
		}

	}
}