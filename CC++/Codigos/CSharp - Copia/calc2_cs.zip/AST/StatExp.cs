namespace Calc.AST 
{
	/// <summary>
	/// statement which is just an expression
	/// </summary>
	public class StatExp : Statement 
	{

		Exp exp;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="exp">expression for this statement</param>
		public StatExp(Exp exp) 
			: base(StatType.EXP)
		{
			this.exp = exp;
		}
	
		/// <summary>
		/// gets the expression of this statement
		/// </summary>
		public Exp Exp { 
			get { return this.exp; }
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitStatExp(this);
		}

	}
}