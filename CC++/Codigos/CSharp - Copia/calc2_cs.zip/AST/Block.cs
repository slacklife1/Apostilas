using System.Collections;

namespace Calc.AST 
{
	/// <summary>
	/// Block is an array of statements.
	/// Blocks are used in Function and Program.
	/// There is also StatBlock which is a nested block withing a program (e.g. if (..) { })
	/// </summary>
	public class Block : VisitorAcceptor 
	{

		/// <summary>
		/// all statements are put here in order
		/// </summary>
		ArrayList stats;

		public Block() 
			:base()
		{
			stats = new ArrayList();
		}
	
		/// <summary>
		/// add new statement to this block
		/// </summary>
		/// <param name="stat">statement to add</param>
		public void addStatement(Statement stat)
		{
			stats.Add(stat);	
		}

		/// <summary>
		/// gets number of statements in this block
		/// </summary>
		public int NumStatements 
		{
			get { return this.stats.Count; }
		}
	
		/// <summary>
		/// returns statement at pos
		/// </summary>
		/// <param name="pos">position at which to get statement</param>
		/// <returns>Statement</returns>
		public Statement StatementAt(int pos)
		{
			return stats[pos] as Statement;
		}
	

		/// <summary>
		/// used by visitor pattern
		/// </summary>
		/// <param name="v"></param>
		public void acceptVisitor(Visitor v) 
		{
			v.visitBlock(this);
		}

	}
}