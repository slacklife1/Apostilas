namespace  Calc.AST 
{

	/// <summary>
	/// all AST elements implement this interface
	/// </summary>
	public interface VisitorAcceptor 
	{
		void acceptVisitor(Visitor v);
	}

}