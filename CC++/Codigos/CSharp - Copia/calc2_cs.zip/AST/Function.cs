using System.Collections;

namespace Calc.AST 
{

	/// <summary>
	/// represents Function in a program (function definition)
	/// </summary>
	public class Function : VisitorAcceptor 
	{
	
		string name;
		ArrayList args; // names of arguments
		Statement body;	
		int nativeIndex;

		/// <summary>
		/// constructor for non-native function
		/// </summary>
		/// <param name="name">name of the function</param>
		/// <param name="args">array of argument names</param>
		/// <param name="body">body for the function</param>
		public Function(string name, ArrayList args, Statement body) 
		{
			this.body = body;
			this.name = name;
			this.args = args;
			this.nativeIndex = 0;
		}
	
		/// <summary>
		/// constructor for native function
		/// </summary>
		/// <param name="name">name of the function</param>
		/// <param name="args">names of the arguments</param>
		/// <param name="nativeIndex">index of the native function</param>
		public Function(string name, ArrayList args, int nativeIndex)
		{
			this.name = name;
			this.args = args;
			this.body = null;
			this.nativeIndex = nativeIndex;	
		}
	
		/// <summary>
		/// gets whether the function is native
		/// </summary>
		public bool IsNative { 
			get {return nativeIndex > 0; }
		}

		/// <summary>
		/// gets the index of the native function
		/// </summary>
		public int NativeIndex { 
			get {return this.nativeIndex; }
		}
	

		public void acceptVisitor(Visitor v) 
		{
			v.visitFunction(this);
		}

		/// <summary>
		/// gets the body of the function (most likely StatBlock)
		/// </summary>
		public Statement Body 
		{
			get 
			{
				return body;
			}
		}

		/// <summary>
		/// gets the name of the function
		/// </summary>
		public string Name
		{
			get 
			{
				return name;
			}
		}

		/// <summary>
		/// gets number of arguments to the function
		/// </summary>
		public int ArgCount { 
			get { return this.args.Count; }
		}

		/// <summary>
		/// gets an argument as specified position
		/// </summary>
		/// <param name="pos">position of the argument</param>
		/// <returns></returns>
		public string ArgAt(int pos) { 
			return (string)this.args[pos]; 
		}
	}
}