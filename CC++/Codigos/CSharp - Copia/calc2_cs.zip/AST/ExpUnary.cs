namespace Calc.AST 
{

	/// <summary>
	/// represents unary expression
	/// </summary>
	public class ExpUnary : Exp 
	{

		ExpUnaryOperator oper;
		Exp exp;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="oper">operator for the unary expression</param>
		/// <param name="exp">expression to which operator is applied</param>
		public ExpUnary(ExpUnaryOperator oper, Exp exp) 
			:base(ExpType.UNARY)
		{
			this.oper = oper;
			this.exp = exp;
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitExpUnary(this);
		}

		/// <summary>
		/// gets the expression
		/// </summary>
		public Exp Exp 
		{
			get 
			{
				return exp;
			}
		}

		/// <summary>
		/// gets the operator
		/// </summary>
		public ExpUnaryOperator Operator
		{
			get 
			{
				return oper;
			}
		}

	}
}