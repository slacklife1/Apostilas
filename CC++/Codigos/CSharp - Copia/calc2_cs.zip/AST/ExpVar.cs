namespace Calc.AST
{

	/// <summary>
	/// expression that represents use of a variable
	/// </summary>
	public class ExpVar : Exp  
	{

		string name;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="name">name of the variable</param>
		public ExpVar(string name) 
			:base(ExpType.VAR)
		{
			this.name = name;
		}
	
		/// <summary>
		/// returns name of the variable
		/// </summary>
		public string Name { 
			get {return this.name; }
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitExpVar(this);
		}

	}
}