namespace Calc.AST 
{

	/// <summary>
	/// Visitor class for visiting all elements of AST
	/// </summary>
	public interface Visitor 
	{
		void visitProgram(Program p);
	
		void visitFunction(Function func);
		void visitBlock(Block block);

		void visitStatExp(StatExp stat);
		void visitStatIf(StatIf stat);
		void visitStatWhile(StatWhile stat);
		void visitStatFor(StatFor stat);
		void visitStatReturn(StatReturn stat);
		void visitStatBlock(StatBlock stat);
	
		void visitExpAssign(ExpAssign exp);
		void visitExpBinary(ExpBinary exp);
		void visitExpUnary(ExpUnary exp);
		void visitExpVar(ExpVar exp);
		void visitExpFunc(ExpFunc exp);
		void visitExpLiteralDouble(ExpLiteralDouble exp);
		void visitExpLiteralBool(ExpLiteralBool exp);
		void visitExpLiteralString(ExpLiteralString exp);
		void visitExpLiteralInt(ExpLiteralInt exp);
		void visitExpStruct(ExpStruct exp);
		void visitExpArray(ExpArray exp);

	}
}