namespace Calc.AST
{
	/// <summary>
	/// all possible statement types
	/// </summary>
	public enum StatType 
	{
		EXP, VARASSIGN, IFTHENELSE, WHILE, FOR, RETURN, BLOCK
	};

	/// <summary>
	/// all statements derive from this abstract Statement
	/// </summary>
	public abstract class Statement : VisitorAcceptor 
	{
		StatType type;	// type of statement

		/// <summary>
		/// constructor that sets the type of the statement
		/// </summary>
		/// <param name="type"></param>
		public Statement(StatType type) 
		{
			this.type = type;		
		}
	
		/// <summary>
		/// gets the type of the statement
		/// </summary>
		public StatType Type { 
			get {return this.type; }
		}
	
		public abstract void acceptVisitor(Visitor v);
	}
}