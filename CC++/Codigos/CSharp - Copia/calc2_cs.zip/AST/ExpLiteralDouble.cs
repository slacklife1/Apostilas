namespace Calc.AST
{

	/// <summary>
	/// literal expression for double
	/// </summary>
	public class ExpLiteralDouble : Exp 
	{

		double literalValue;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="v">value for the expression</param>
		public ExpLiteralDouble(double v) 
			:base(ExpType.LITERAL_DOUBLE)
		{
			this.literalValue = v;
		}
	
		/// <summary>
		/// gets the double value of the expression
		/// </summary>
		public double Value { 
			get {return this.literalValue; }
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitExpLiteralDouble(this);		
		}

	}
}