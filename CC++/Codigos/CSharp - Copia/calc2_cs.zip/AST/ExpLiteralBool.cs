namespace Calc.AST
{
	/// <summary>
	/// represents literal value of bool
	/// </summary>
	public class ExpLiteralBool : Exp 
	{

		bool literalValue;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="v">value for the literal</param>
		public ExpLiteralBool(bool v) 
			:base(ExpType.LITERAL_BOOL)
		{
			this.literalValue = v;
		}
	
		/// <summary>
		/// gets the value of this literal expression
		/// </summary>
		public bool Value { 
			get {return this.literalValue; }
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitExpLiteralBool(this);		
		}

	}
}