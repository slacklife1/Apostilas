namespace Calc.AST 
{

	/**
	 * @author Andrew Deren
	 *
	 */
	public class ExpBinary : Exp
	{

		Exp left;
		Exp right;
		ExpBinaryOperator oper;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="left">left side of binary expression</param>
		/// <param name="right">right side of binary expression</param>
		/// <param name="oper">operator for the expression</param>
		public ExpBinary(Exp left, Exp right, ExpBinaryOperator oper) 
			:base(ExpType.BINARY)
		{
			this.left = left;
			this.right = right;
			this.oper = oper;
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitExpBinary(this);
		}

		/// <summary>
		/// gets the left side of expression
		/// </summary>
		public Exp LeftExp 
		{
			get 
			{
				return left;
			}
		}

		/// <summary>
		/// gets the operator of the expression
		/// </summary>
		public ExpBinaryOperator Operator 
		{
			get 
			{
				return oper;
			}
		}

		/// <summary>
		/// gets the right side of the expression
		/// </summary>
		public Exp RightExp 
		{
			get 
			{
				return right;
			}
		}

	}
}