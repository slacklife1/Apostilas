using System.Collections;

namespace Calc.AST 
{

	/// <summary>
	/// expression for function call
	/// </summary>
	public class ExpFunc : Exp 
	{

		string name;		// name of function to call
		ArrayList paramList; // expressions for parameters

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="name">name of function to call</param>
		/// <param name="paramList">array of expression arguments to the function</param>
		public ExpFunc(string name, ArrayList paramList) 
			: base(ExpType.FUNC)
		{
			this.name = name;
			this.paramList = paramList;
		}

		/// <summary>
		/// name of function to call
		/// </summary>
		public string Name { 
			get {return this.name; }
		}

		/// <summary>
		/// number of parameters to the function
		/// </summary>
		public int ParamCount { 
			get {return this.paramList.Count;} 
		}

		/// <summary>
		/// gets the expression for a specific position
		/// </summary>
		/// <param name="pos">position at which to get the expression</param>
		/// <returns>expression at pos</returns>
		public Exp ParamAt(int pos) 
		{
			return this.paramList[pos] as Exp;
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitExpFunc(this);
		}

	}
}