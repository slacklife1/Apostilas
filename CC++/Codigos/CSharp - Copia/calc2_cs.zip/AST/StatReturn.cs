namespace Calc.AST 
{

	/// <summary>
	/// statement for return from a function
	/// </summary>
	public class StatReturn : Statement 
	{

		Exp exp;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="exp">expression to return</param>
		public StatReturn(Exp exp) 
			:base(StatType.RETURN)
		{
			this.exp = exp;
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitStatReturn(this);
		}

		/// <summary>
		/// gets the return expression
		/// </summary>
		public Exp Exp
		{
			get 
			{
				return exp;
			}
		}

	}
}