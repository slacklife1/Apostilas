namespace Calc.AST 
{
	/// <summary>
	/// expression for assignment
	/// </summary>
	public class ExpAssign : Exp 
	{

		Exp var;	// expression for variable (lvalue)
		Exp exp;	// expression for the value (rvalue)

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="var">lvalue of the assignment</param>
		/// <param name="exp">rvalue of the assignment</param>
		public ExpAssign(Exp var, Exp exp) 
			: base(ExpType.ASSIGN)
		{

			this.var = var;
			this.exp = exp;
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitExpAssign(this);
		}

		/// <summary>
		/// gets the rvalue of the assignment
		/// </summary>
		public Exp ValueExp
		{
			get 
			{
				return exp;
			}
		}

		/// <summary>
		/// gets the lvalue of the assignment
		/// </summary>
		public Exp VariableExp 
		{
			get 
			{
				return var;
			}
		}

	}
}