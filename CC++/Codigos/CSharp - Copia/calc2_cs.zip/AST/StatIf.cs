namespace Calc.AST 
{
	/// <summary>
	/// statement that represents if then else statement
	/// </summary>
	public class StatIf : Statement 
	{

		Exp exp;
		Statement trueBlock;
		Statement falseBlock;

		/// <summary>
		/// constructor. false expression can be null
		/// </summary>
		/// <param name="exp">expression to evaluate for boolean value</param>
		/// <param name="trueBlock">body of the true branch</param>
		/// <param name="falseBlock">body of the false branch</param>
		public StatIf(Exp exp, Statement trueBlock, Statement falseBlock) 
			:base(StatType.IFTHENELSE)
		{
			this.exp = exp;
			this.trueBlock = trueBlock;
			this.falseBlock = falseBlock;
		}

		/// <summary>
		/// gets the boolean expression 
		/// </summary>
		public Exp Exp { 
			get {return exp; }
		}

		/// <summary>
		/// gets the true branch of the statement
		/// </summary>
		public Statement TrueBlock { 
			get {return this.trueBlock; }
		}

		/// <summary>
		/// gets the false block of the statement
		/// </summary>
		public Statement FalseBlock { 
			get {return this.falseBlock; }
		}

		public override void acceptVisitor(Visitor v) 
		{		
			v.visitStatIf(this);
		}

	}
}