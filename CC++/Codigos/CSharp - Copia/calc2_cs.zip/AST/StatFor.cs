namespace Calc.AST 
{

	/// <summary>
	/// statement that represents for loop
	/// </summary>
	public class StatFor : Statement 
	{

		Exp initExp;
		Exp condExp;
		Exp updateExp;
		Statement body;

		/// <summary>
		/// constructor. Any or all expressions can be null
		/// </summary>
		/// <param name="initExp">initialization expression</param>
		/// <param name="condExp">condition expression</param>
		/// <param name="updateExp">update expression</param>
		/// <param name="body">body of the loop</param>
		public StatFor(Exp initExp, Exp condExp, Exp updateExp, Statement body) 
			:base(StatType.FOR)
		{
			this.initExp = initExp;
			this.condExp = condExp;
			this.updateExp = updateExp;
			this.body = body;
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitStatFor(this);
		}

		/// <summary>
		/// gets the condition expression
		/// </summary>
		public Exp CondExp
		{
			get 
			{
				return condExp;
			}
		}

		/// <summary>
		/// gets the initalization expression
		/// </summary>
		public Exp InitExp
		{
		get {
				return initExp;
			}
		}

		/// <summary>
		/// gets the update expression
		/// </summary>
		public Exp UpdateExp
		{
			get 
			{
				return updateExp;
			}
		}


		/// <summary>
		/// gets the body of the for loop
		/// </summary>
		public Statement Body
		{
			get {
				return body;
			}
		}

	}
}