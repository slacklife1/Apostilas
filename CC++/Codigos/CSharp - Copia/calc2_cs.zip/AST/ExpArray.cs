namespace Calc.AST 
{

	/// <summary>
	/// represents array access
	/// </summary>
	public class ExpArray : Exp 
	{

		Exp exp;		// expression for the array variable
		Exp indexExp;	// expression for index of array

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="exp">expression for array variable</param>
		/// <param name="indexExp">expression for index of array</param>
		public ExpArray(Exp exp, Exp indexExp) 
			:base(ExpType.ARRAY)
		{
			this.exp = exp;
			this.indexExp = indexExp;
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitExpArray(this);
		}

		/// <summary>
		/// gets the expression for the variable
		/// </summary>
		public Exp VariableExp
		{
			get 
			{
				return exp;
			}
		}

		/// <summary>
		/// gets the expression for the index 
		/// </summary>
		public Exp IndexExp
		{
			get 
			{
				return indexExp;
			}
		}

	}
}