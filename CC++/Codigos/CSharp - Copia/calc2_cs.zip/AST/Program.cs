using System.Collections;

namespace Calc.AST 
{

	/// <summary>
	/// represents program as a whole
	/// Array of functions and body block
	/// </summary>
	public class Program : VisitorAcceptor 
	{

		ArrayList functions;
	
		Block body;	

		/// <summary>
		/// constructor
		/// </summary>
		public Program() 
		{
			this.functions = new ArrayList();
		}

		/// <summary>
		/// gets or sets the body of the program
		/// </summary>
		public Block Body { 
			get { return this.body; }
			set { this.body = value; }
		}

	
		/// <summary>
		/// appends new function to the program
		/// </summary>
		/// <param name="func"></param>
		public void addFunction(Function func)
		{
			functions.Add(func);	
		}
	
		/// <summary>
		/// gets how many function are in a program
		/// </summary>
		public int FunctionsCount { 
			get { return functions.Count; }
		}

		/// <summary>
		/// gets a function at specified position
		/// </summary>
		/// <param name="pos"></param>
		/// <returns></returns>
		public Function FunctionAt(int pos) { 
			return functions[pos] as Function; 
		}

	
		public void acceptVisitor(Visitor v)
		{
		
			v.visitProgram(this);
		}	
	
	}
}