namespace Calc.AST
{

	/// <summary>
	/// literal string in the program
	/// </summary>
	public class ExpLiteralString : Exp 
	{

		string literalValue;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="v">string literal value</param>
		public ExpLiteralString(string v) 
			:base(ExpType.LITERAL_STRING)
		{
			this.literalValue = v;
		}
	
		/// <summary>
		/// gets the literal value
		/// </summary>
		public string Value { 
			get {return this.literalValue; }
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitExpLiteralString(this);		
		}

	}
}