namespace Calc.AST 
{

	/// <summary>
	/// all possible binary operators
	/// </summary>
	public enum ExpBinaryOperator 
	{
		PLUS, MINUS, TIMES, DIV, EQUAL, NOTEQUAL, LT, GT, LTE, GTE, MOD
	};

	/// <summary>
	/// all possible unary operators
	/// </summary>
	public enum ExpUnaryOperator
	{
		INC, DEC, NOT, POSITIVE, NEGATIVE
	};

	/// <summary>
	/// all possible expression types
	/// </summary>
	public enum ExpType
	{
		BINARY, UNARY, VAR, FUNC, 
		LITERAL_DOUBLE, LITERAL_BOOL, LITERAL_INT, LITERAL_STRING,
		ASSIGN, STRUCT, ARRAY
	};

	/// <summary>
	/// all expressions are derived from Exp abstract class
	/// </summary>
	public abstract class Exp : VisitorAcceptor 
	{
		
		ExpType type; // type of expression

		public Exp(ExpType type)
		{
			this.type = type;
		}	
	
		/// <summary>
		/// returns type of this expression.
		/// Expression type is set in constructor.
		/// When inheriting from Exp, use base(ExpType.TYPE) in the constructor
		/// </summary>
		public ExpType Type 
		{ 
			get { return this.type; }
		}

		public abstract void acceptVisitor(Visitor v);
	}
}