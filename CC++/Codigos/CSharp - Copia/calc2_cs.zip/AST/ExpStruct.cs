namespace Calc.AST 
{

	/// <summary>
	/// struct expression represents Exp DOT ID (eg. x.y)
	/// </summary>
	public class ExpStruct : Exp 
	{

		Exp exp;
		string name;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="exp">expression that evaluates to struct</param>
		/// <param name="name">member name of the struct</param>
		public ExpStruct(Exp exp, string name) 
			:base(ExpType.STRUCT)
		{
			this.exp = exp;
			this.name = name;
		}

		public override void acceptVisitor(Visitor v) 
		{
			v.visitExpStruct(this);
		}

		/// <summary>
		/// returns expression that evaluates to VarStruct
		/// </summary>
		public Exp Exp 
		{
			get 
			{
				return exp;
			}
		}

		/// <summary>
		/// gets the member name
		/// </summary>
		public string Name
		{
			get 
			{
				return name;
			}
		}

	}
}