using Calc.AST;
using System.IO;

namespace Calc.Printer
{
	/// <summary>
	/// this class takes a program and pretty-prints it to the passed writer.
	/// To output to screen use: prettyPrinter.process(Console.Out)
	/// </summary>
	public class PrettyPrinter : Visitor
	{
		Program program;
		TextWriter writer;

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="prog">program to pretty print</param>
		public PrettyPrinter(Program prog) 
		{
			this.program = prog;
		}

		/// <summary>
		/// prints the program to the passed writer
		/// </summary>
		/// <param name="writer"></param>
		public void process(TextWriter writer)
		{
	
			this.writer = writer;

			program.acceptVisitor(this);	
		
			writer.Flush();

		}
	
		public void visitProgram(Program program)
		{
			// output all functions
			for (int i=0; i<program.FunctionsCount; i++)
			{
				program.FunctionAt(i).acceptVisitor(this);	
			}
		
			program.Body.acceptVisitor(this);
		}

		public void visitFunction(Function func) 
		{
		
			write("function ");
			write(func.Name);
			write("(");
		
			for (int i=0; i<func.ArgCount; i++) 
			{
				if (i > 0)
					write(", ");
				
				write(func.ArgAt(i));	
			}
		
			writeLine(")");
		
			func.Body.acceptVisitor(this);
		
		
		}

		public void visitBlock(Block block) 
		{
		
			for (int i=0; i<block.NumStatements; i++)
				block.StatementAt(i).acceptVisitor(this);
		
		}

		public void visitStatExp(StatExp stat) 
		{
		
			stat.Exp.acceptVisitor(this);
		
			writeLine(";");
		
		}

	
		public void visitStatIf(StatIf stat)
		{
			write("if (");
			stat.Exp.acceptVisitor(this);
			writeLine(") ");

			if (stat.TrueBlock.Type == StatType.BLOCK)
			{
				stat.TrueBlock.acceptVisitor(this);
			}
			else 
			{
				indent();
				stat.TrueBlock.acceptVisitor(this);
				unindent();
			}

			if (stat.FalseBlock != null) 
			{
				Statement falseBlock = stat.FalseBlock;
			
				// so that elseif looks normal
				if (falseBlock.Type == StatType.IFTHENELSE) 
				{
					write("else ");
					unindent();
				}
				else
					writeLine("else");
				
				if (falseBlock.Type == StatType.BLOCK)
				{
					falseBlock.acceptVisitor(this);
				}
				else 
				{
					indent();
					falseBlock.acceptVisitor(this);
					unindent();
				}
			
			}		
		}
	
		public void visitStatWhile(StatWhile stat)
		{
			write("while (");
			stat.Exp.acceptVisitor(this);
			writeLine(")");
		
			if (stat.Block.Type == StatType.BLOCK)
			{
				stat.Block.acceptVisitor(this);			
			}
			else 
			{
				indent();
				stat.Block.acceptVisitor(this);
				unindent();
			}
		}

		public void visitStatFor(StatFor stat)
		{
			Exp initExp = stat.InitExp;
			Exp condExp = stat.CondExp;
			Exp updateExp = stat.UpdateExp;
		
			write("for (");
			if (initExp != null)
				initExp.acceptVisitor(this);
			write("; ");
		
			if (condExp != null)
				condExp.acceptVisitor(this);

			write("; ");
			if (updateExp != null)
				updateExp.acceptVisitor(this);	
						
			
			writeLine(")");				
		
			if (stat.Body.Type == StatType.BLOCK)
			{
				stat.Body.acceptVisitor(this);			
			}
			else 
			{
				indent();
				stat.Body.acceptVisitor(this);			
				unindent();
			}
			
		}
	
		public void visitStatReturn(StatReturn stat)
		{
			write("return ");
			stat.Exp.acceptVisitor(this);
			writeLine(";");	
		}


		public void visitStatBlock(StatBlock block)
		{
			writeLine("{");
			indent();
		
			block.Block.acceptVisitor(this);
		
			unindent();
			writeLine("}");	
		}

		public void visitExpAssign(ExpAssign stat) 
		{
			stat.VariableExp.acceptVisitor(this);		
			write(" = ");
			stat.ValueExp.acceptVisitor(this);		
		}

		public void visitExpBinary(ExpBinary exp) 
		{
		
			write("(");
		
			exp.LeftExp.acceptVisitor(this);
		
			write(" ");
		
			switch (exp.Operator) 
			{
				case ExpBinaryOperator.PLUS: write('+'); break;
				case ExpBinaryOperator.MINUS: write('-'); break;
				case ExpBinaryOperator.TIMES: write('*'); break;
				case ExpBinaryOperator.DIV: write('/'); break;	
				case ExpBinaryOperator.MOD: write('%'); break;				
				case ExpBinaryOperator.EQUAL: write("=="); break;	
				case ExpBinaryOperator.NOTEQUAL: write("!="); break;	
				case ExpBinaryOperator.LT: write('<'); break;	
				case ExpBinaryOperator.GT: write('>'); break;	
				case ExpBinaryOperator.LTE: write("<="); break;	
				case ExpBinaryOperator.GTE: write(">="); break;	
			}
		
			write(" ");		
			exp.RightExp.acceptVisitor(this);
		
		
			write(")");
		}
	
		public void visitExpUnary(ExpUnary exp)
		{
			write("(");
			ExpUnaryOperator oper = exp.Operator;
		
			if (oper == ExpUnaryOperator.NEGATIVE)
				write('-');
			else if (oper == ExpUnaryOperator.POSITIVE)
				write('+');
			if (oper == ExpUnaryOperator.INC)
				write("++");
			else if (oper == ExpUnaryOperator.DEC)
				write("--");
			else if (oper == ExpUnaryOperator.NOT)
				write("!");
		
			exp.Exp.acceptVisitor(this);
				
		
		
			write(")");	
		}

		public void visitExpVar(ExpVar exp) 
		{
			write(exp.Name);
		}

		public void visitExpFunc(ExpFunc exp) 
		{
			write(exp.Name);
			write("(");
		
			for (int i=0; i<exp.ParamCount; i++) 
			{
				if (i > 0)
					write(", ");
				exp.ParamAt(i).acceptVisitor(this);
			}
		
			write(")");
		}

		public void visitExpStruct(ExpStruct exp)
		{
			write("(");
			exp.Exp.acceptVisitor(this);
			write(".");
			write(exp.Name);
			write(")");	
		}

		public void visitExpArray(ExpArray exp)
		{
			write("(");
			exp.VariableExp.acceptVisitor(this);
			write("[");
			exp.IndexExp.acceptVisitor(this);
			write("]");
			write(")");
		}

		public void visitExpLiteralDouble(ExpLiteralDouble exp) 
		{
			write(exp.Value.ToString());
		}

		public void visitExpLiteralInt(ExpLiteralInt exp) 
		{
			write(exp.Value.ToString());
		}

	
		public void visitExpLiteralBool(ExpLiteralBool exp)
		{
			write(exp.Value.ToString());	
		}

		public void visitExpLiteralString(ExpLiteralString exp)
		{
			write("\"");
			write(exp.Value);	
			write("\"");		
		}

		/// writing stuff
		int indentLevel = 0;
		bool isNewLine = false;
		void indent() { indentLevel++; }
		void unindent() { indentLevel--; }
	
		void write(char ch)
		{
			if (isNewLine)
				writeIndent();
			writer.Write(ch);
		}

		void write(string s)
		{
			if (isNewLine) 
				writeIndent();
			writer.Write(s);	
		}
	
		void writeLine(string s)
		{
			if (isNewLine)
				writeIndent();				
			writer.WriteLine(s);
			isNewLine = true;
		}
		void writeLine()
		{
			writer.WriteLine();
			writeIndent();		
		
			isNewLine = true;
		}
	
		void writeIndent()
		{
			for (int i=0; i<indentLevel; i++)
				writer.Write('\t');
			
			isNewLine = false;
		}		
	}
}
