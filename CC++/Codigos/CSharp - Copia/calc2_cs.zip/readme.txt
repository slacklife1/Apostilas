Andrew Deren 
andrew@adersoftware.com
3/6/03

C# implementation of "pygmy" language.
You will need antlr to build the code. You can download it from http://www.antlr.org
Sources:
AST - abstrat syntax tree code the language, is built to parser
Parser - contains calc.g grammar file and generated parser from it
Printer - contains pretty-printer code for printing programs
Interpreter - contains interpreter implementation
Tester.cs file has the main function for testing the interpreter
test - contains couple test files