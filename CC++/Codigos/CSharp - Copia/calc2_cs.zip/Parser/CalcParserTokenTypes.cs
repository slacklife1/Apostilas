// $ANTLR 2.7.2: "Calc.g" -> "CalcLexer.cs"$

	
	using Calc.AST;
	using System.Collections;

namespace Calc.Parser
{
	public class CalcParserTokenTypes
	{
		public const int EOF = 1;
		public const int NULL_TREE_LOOKAHEAD = 3;
		public const int LITERAL_function = 4;
		public const int ID = 5;
		public const int LBRACE = 6;
		public const int RBRACE = 7;
		public const int SEMI = 8;
		public const int LITERAL_if = 9;
		public const int LPAREN = 10;
		public const int RPAREN = 11;
		public const int LITERAL_else = 12;
		public const int LITERAL_while = 13;
		public const int LITERAL_for = 14;
		public const int LITERAL_return = 15;
		public const int COMMA = 16;
		public const int ASSIGN = 17;
		public const int EQUAL = 18;
		public const int NOTEQUAL = 19;
		public const int LTSIGN = 20;
		public const int GTSIGN = 21;
		public const int LTE = 22;
		public const int GTE = 23;
		public const int PLUS = 24;
		public const int MINUS = 25;
		public const int TIMES = 26;
		public const int DIV = 27;
		public const int MOD = 28;
		public const int INC = 29;
		public const int DEC = 30;
		public const int NOT = 31;
		public const int LBRACK = 32;
		public const int RBRACK = 33;
		public const int LITERAL_true = 34;
		public const int LITERAL_false = 35;
		public const int DOUBLE = 36;
		public const int INTEGER = 37;
		public const int STRING_LITERAL = 38;
		public const int DOT = 39;
		public const int POWER = 40;
		public const int NUM = 41;
		public const int ESC = 42;
		public const int SL_COMMENT = 43;
		public const int ML_COMMENT = 44;
		public const int WS = 45;
		public const int DIGIT = 46;
		
	}
}
