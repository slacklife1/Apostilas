// $ANTLR 2.7.2: "Calc.g" -> "CalcParser.cs"$

	
	using Calc.AST;
	using System.Collections;

namespace Calc.Parser
{
	// Generate the header common to all output files.
	using System;
	
	using TokenBuffer              = antlr.TokenBuffer;
	using TokenStreamException     = antlr.TokenStreamException;
	using TokenStreamIOException   = antlr.TokenStreamIOException;
	using ANTLRException           = antlr.ANTLRException;
	using LLkParser = antlr.LLkParser;
	using Token                    = antlr.Token;
	using TokenStream              = antlr.TokenStream;
	using RecognitionException     = antlr.RecognitionException;
	using NoViableAltException     = antlr.NoViableAltException;
	using MismatchedTokenException = antlr.MismatchedTokenException;
	using SemanticException        = antlr.SemanticException;
	using ParserSharedInputState   = antlr.ParserSharedInputState;
	using BitSet                   = antlr.collections.impl.BitSet;
	
	public 	class CalcParser : antlr.LLkParser
	{
		public const int EOF = 1;
		public const int NULL_TREE_LOOKAHEAD = 3;
		public const int LITERAL_function = 4;
		public const int ID = 5;
		public const int LBRACE = 6;
		public const int RBRACE = 7;
		public const int SEMI = 8;
		public const int LITERAL_if = 9;
		public const int LPAREN = 10;
		public const int RPAREN = 11;
		public const int LITERAL_else = 12;
		public const int LITERAL_while = 13;
		public const int LITERAL_for = 14;
		public const int LITERAL_return = 15;
		public const int COMMA = 16;
		public const int ASSIGN = 17;
		public const int EQUAL = 18;
		public const int NOTEQUAL = 19;
		public const int LTSIGN = 20;
		public const int GTSIGN = 21;
		public const int LTE = 22;
		public const int GTE = 23;
		public const int PLUS = 24;
		public const int MINUS = 25;
		public const int TIMES = 26;
		public const int DIV = 27;
		public const int MOD = 28;
		public const int INC = 29;
		public const int DEC = 30;
		public const int NOT = 31;
		public const int LBRACK = 32;
		public const int RBRACK = 33;
		public const int LITERAL_true = 34;
		public const int LITERAL_false = 35;
		public const int DOUBLE = 36;
		public const int INTEGER = 37;
		public const int STRING_LITERAL = 38;
		public const int DOT = 39;
		public const int POWER = 40;
		public const int NUM = 41;
		public const int ESC = 42;
		public const int SL_COMMENT = 43;
		public const int ML_COMMENT = 44;
		public const int WS = 45;
		public const int DIGIT = 46;
		
		
		protected void initialize()
		{
			tokenNames = tokenNames_;
		}
		
		
		protected CalcParser(TokenBuffer tokenBuf, int k) : base(tokenBuf, k)
		{
			initialize();
		}
		
		public CalcParser(TokenBuffer tokenBuf) : this(tokenBuf,1)
		{
		}
		
		protected CalcParser(TokenStream lexer, int k) : base(lexer,k)
		{
			initialize();
		}
		
		public CalcParser(TokenStream lexer) : this(lexer,1)
		{
		}
		
		public CalcParser(ParserSharedInputState state) : base(state,1)
		{
			initialize();
		}
		
	public Program  program() //throws RecognitionException, TokenStreamException
{
		Program program;
		
		
				program = new Program();	
				Function fun = null;
				Block block = new Block();
				Statement astat = null;
			
		
		try {      // for error handling
			{    // ( ... )*
				for (;;)
				{
					if ((LA(1)==LITERAL_function))
					{
						fun=function();
						if (0==inputState.guessing)
						{
							program.addFunction(fun);	
						}
					}
					else
					{
						goto _loop3_breakloop;
					}
					
				}
_loop3_breakloop:				;
			}    // ( ... )*
			{    // ( ... )*
				for (;;)
				{
					if ((tokenSet_0_.member(LA(1))))
					{
						astat=stat();
						if (0==inputState.guessing)
						{
							
										block.addStatement(astat);
									
						}
					}
					else
					{
						goto _loop5_breakloop;
					}
					
				}
_loop5_breakloop:				;
			}    // ( ... )*
			match(Token.EOF_TYPE);
			if (0==inputState.guessing)
			{
				
						program.Body = block;	
					
			}
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_1_);
			}
			else
			{
				throw;
			}
		}
		return program;
	}
	
	public Function  function() //throws RecognitionException, TokenStreamException
{
		Function fun;
		
		Token  name = null;
		
				ArrayList args = null; 
				Statement body = null;	
				fun = null;
			
		
		try {      // for error handling
			match(LITERAL_function);
			name = LT(1);
			match(ID);
			args=funcArgs();
			body=compoundStatement();
			if (0==inputState.guessing)
			{
				
						fun = new Function(name.getText(), args, body);	
					
			}
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_2_);
			}
			else
			{
				throw;
			}
		}
		return fun;
	}
	
	public Statement  stat() //throws RecognitionException, TokenStreamException
{
		Statement astat;
		
		
				Exp e = null;		
				astat = null;
				Statement trueBlock = null;
				Statement falseBlock = null;
				
				// for for loop
				Exp initExp = null;
				Exp condExp = null;
				Exp updateExp = null;
			
		
		try {      // for error handling
			switch ( LA(1) )
			{
			case LBRACE:
			{
				astat=compoundStatement();
				break;
			}
			case ID:
			case LPAREN:
			case PLUS:
			case MINUS:
			case INC:
			case DEC:
			case NOT:
			case LITERAL_true:
			case LITERAL_false:
			case DOUBLE:
			case INTEGER:
			case STRING_LITERAL:
			{
				e=topExp();
				match(SEMI);
				if (0==inputState.guessing)
				{
					
								astat = new StatExp(e);	
							
				}
				break;
			}
			case LITERAL_if:
			{
				match(LITERAL_if);
				match(LPAREN);
				e=topExp();
				match(RPAREN);
				trueBlock=stat();
				{
					if ((LA(1)==LITERAL_else))
					{
						match(LITERAL_else);
						falseBlock=stat();
					}
					else if ((tokenSet_3_.member(LA(1)))) {
					}
					else
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					
				}
				if (0==inputState.guessing)
				{
					
								astat = new StatIf(e, trueBlock, falseBlock);	
							
				}
				break;
			}
			case LITERAL_while:
			{
				match(LITERAL_while);
				match(LPAREN);
				e=topExp();
				match(RPAREN);
				trueBlock=stat();
				if (0==inputState.guessing)
				{
					
								astat = new StatWhile(e, trueBlock);	
							
				}
				break;
			}
			case LITERAL_for:
			{
				match(LITERAL_for);
				match(LPAREN);
				{
					switch ( LA(1) )
					{
					case ID:
					case LPAREN:
					case PLUS:
					case MINUS:
					case INC:
					case DEC:
					case NOT:
					case LITERAL_true:
					case LITERAL_false:
					case DOUBLE:
					case INTEGER:
					case STRING_LITERAL:
					{
						initExp=topExp();
						break;
					}
					case SEMI:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					 }
				}
				match(SEMI);
				{
					switch ( LA(1) )
					{
					case ID:
					case LPAREN:
					case PLUS:
					case MINUS:
					case INC:
					case DEC:
					case NOT:
					case LITERAL_true:
					case LITERAL_false:
					case DOUBLE:
					case INTEGER:
					case STRING_LITERAL:
					{
						condExp=topExp();
						break;
					}
					case SEMI:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					 }
				}
				match(SEMI);
				{
					switch ( LA(1) )
					{
					case ID:
					case LPAREN:
					case PLUS:
					case MINUS:
					case INC:
					case DEC:
					case NOT:
					case LITERAL_true:
					case LITERAL_false:
					case DOUBLE:
					case INTEGER:
					case STRING_LITERAL:
					{
						updateExp=topExp();
						break;
					}
					case RPAREN:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					 }
				}
				match(RPAREN);
				trueBlock=stat();
				if (0==inputState.guessing)
				{
					
								astat = new StatFor(initExp, condExp, updateExp, trueBlock);
							
				}
				break;
			}
			case LITERAL_return:
			{
				match(LITERAL_return);
				e=topExp();
				match(SEMI);
				if (0==inputState.guessing)
				{
					astat = new StatReturn(e);
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			 }
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_3_);
			}
			else
			{
				throw;
			}
		}
		return astat;
	}
	
	public ArrayList  funcArgs() //throws RecognitionException, TokenStreamException
{
		ArrayList args;
		
		Token  id = null;
		Token  id2 = null;
		
				args = new ArrayList();	
			
		
		try {      // for error handling
			match(LPAREN);
			{
				switch ( LA(1) )
				{
				case ID:
				{
					id = LT(1);
					match(ID);
					if (0==inputState.guessing)
					{
						args.Add(id.getText());
					}
					{    // ( ... )*
						for (;;)
						{
							if ((LA(1)==COMMA))
							{
								match(COMMA);
								id2 = LT(1);
								match(ID);
								if (0==inputState.guessing)
								{
									args.Add(id2.getText());
								}
							}
							else
							{
								goto _loop18_breakloop;
							}
							
						}
_loop18_breakloop:						;
					}    // ( ... )*
					break;
				}
				case RPAREN:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				 }
			}
			match(RPAREN);
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_4_);
			}
			else
			{
				throw;
			}
		}
		return args;
	}
	
	public Statement  compoundStatement() //throws RecognitionException, TokenStreamException
{
		Statement astat;
		
		
				astat = null;
				Block block = new Block();
				Statement addStat = null; 		
			
		
		try {      // for error handling
			match(LBRACE);
			{    // ( ... )*
				for (;;)
				{
					if ((tokenSet_0_.member(LA(1))))
					{
						addStat=stat();
						if (0==inputState.guessing)
						{
							
										block.addStatement(addStat);
									
						}
					}
					else
					{
						goto _loop9_breakloop;
					}
					
				}
_loop9_breakloop:				;
			}    // ( ... )*
			match(RBRACE);
			if (0==inputState.guessing)
			{
				astat = new StatBlock(block);
			}
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_5_);
			}
			else
			{
				throw;
			}
		}
		return astat;
	}
	
	public Exp  topExp() //throws RecognitionException, TokenStreamException
{
		Exp exp;
		
		exp = null;
		
		try {      // for error handling
			exp=assignExp();
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_6_);
			}
			else
			{
				throw;
			}
		}
		return exp;
	}
	
	public Exp  assignExp() //throws RecognitionException, TokenStreamException
{
		Exp exp;
		
		
				exp = null; 
				Exp e = null;
			
		
		try {      // for error handling
			exp=relationalExp();
			{
				switch ( LA(1) )
				{
				case ASSIGN:
				{
					match(ASSIGN);
					e=assignExp();
					if (0==inputState.guessing)
					{
						
									if (exp.Type == ExpType.VAR || exp.Type == ExpType.STRUCT || exp.Type == ExpType.ARRAY)
									{
										exp = new ExpAssign(exp, e);
									}
									else
										throw new ApplicationException("LHS of assignment must be a variable.");
								
					}
					break;
				}
				case SEMI:
				case RPAREN:
				case COMMA:
				case RBRACK:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				 }
			}
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_6_);
			}
			else
			{
				throw;
			}
		}
		return exp;
	}
	
	public Exp  relationalExp() //throws RecognitionException, TokenStreamException
{
		Exp exp;
		
		
				exp = null; 
				ExpBinaryOperator oper = ExpBinaryOperator.EQUAL;
				Exp e = null;
			
		
		try {      // for error handling
			exp=addExp();
			{    // ( ... )*
				for (;;)
				{
					if (((LA(1) >= EQUAL && LA(1) <= GTE)))
					{
						{
							switch ( LA(1) )
							{
							case EQUAL:
							{
								match(EQUAL);
								if (0==inputState.guessing)
								{
									oper = ExpBinaryOperator.EQUAL;
								}
								break;
							}
							case NOTEQUAL:
							{
								match(NOTEQUAL);
								if (0==inputState.guessing)
								{
									oper = ExpBinaryOperator.NOTEQUAL;
								}
								break;
							}
							case LTSIGN:
							{
								match(LTSIGN);
								if (0==inputState.guessing)
								{
									oper = ExpBinaryOperator.LT;
								}
								break;
							}
							case GTSIGN:
							{
								match(GTSIGN);
								if (0==inputState.guessing)
								{
									oper = ExpBinaryOperator.GT;
								}
								break;
							}
							case LTE:
							{
								match(LTE);
								if (0==inputState.guessing)
								{
									oper = ExpBinaryOperator.LTE;
								}
								break;
							}
							case GTE:
							{
								match(GTE);
								if (0==inputState.guessing)
								{
									oper = ExpBinaryOperator.GTE;
								}
								break;
							}
							default:
							{
								throw new NoViableAltException(LT(1), getFilename());
							}
							 }
						}
						e=addExp();
						if (0==inputState.guessing)
						{
							
										exp = new ExpBinary(exp, e, oper);	
									
						}
					}
					else
					{
						goto _loop25_breakloop;
					}
					
				}
_loop25_breakloop:				;
			}    // ( ... )*
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_7_);
			}
			else
			{
				throw;
			}
		}
		return exp;
	}
	
	public Exp  addExp() //throws RecognitionException, TokenStreamException
{
		Exp exp;
		
		
				Exp e = null; 
				exp = null;
				ExpBinaryOperator op = ExpBinaryOperator.PLUS;
			
		
		try {      // for error handling
			exp=multExp();
			{    // ( ... )*
				for (;;)
				{
					if ((LA(1)==PLUS||LA(1)==MINUS))
					{
						{
							switch ( LA(1) )
							{
							case PLUS:
							{
								match(PLUS);
								if (0==inputState.guessing)
								{
									op = ExpBinaryOperator.PLUS;
								}
								break;
							}
							case MINUS:
							{
								match(MINUS);
								if (0==inputState.guessing)
								{
									op = ExpBinaryOperator.MINUS;
								}
								break;
							}
							default:
							{
								throw new NoViableAltException(LT(1), getFilename());
							}
							 }
						}
						e=multExp();
						if (0==inputState.guessing)
						{
							
										exp = new ExpBinary(exp, e, op);	
									
						}
					}
					else
					{
						goto _loop29_breakloop;
					}
					
				}
_loop29_breakloop:				;
			}    // ( ... )*
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_8_);
			}
			else
			{
				throw;
			}
		}
		return exp;
	}
	
	public Exp  multExp() //throws RecognitionException, TokenStreamException
{
		Exp exp;
		
		
				Exp e = null; 
				exp = null;
				ExpBinaryOperator op = ExpBinaryOperator.TIMES;// just a default so compiler doesn't complain
			
		
		try {      // for error handling
			exp=unaryExp();
			{    // ( ... )*
				for (;;)
				{
					if (((LA(1) >= TIMES && LA(1) <= MOD)))
					{
						{
							switch ( LA(1) )
							{
							case TIMES:
							{
								match(TIMES);
								if (0==inputState.guessing)
								{
									op = ExpBinaryOperator.TIMES;
								}
								break;
							}
							case DIV:
							{
								match(DIV);
								if (0==inputState.guessing)
								{
									op = ExpBinaryOperator.DIV;
								}
								break;
							}
							case MOD:
							{
								match(MOD);
								if (0==inputState.guessing)
								{
									op = ExpBinaryOperator.MOD;
								}
								break;
							}
							default:
							{
								throw new NoViableAltException(LT(1), getFilename());
							}
							 }
						}
						e=unaryExp();
						if (0==inputState.guessing)
						{
							exp = new ExpBinary(exp, e, op);	
						}
					}
					else
					{
						goto _loop33_breakloop;
					}
					
				}
_loop33_breakloop:				;
			}    // ( ... )*
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_9_);
			}
			else
			{
				throw;
			}
		}
		return exp;
	}
	
	public Exp  unaryExp() //throws RecognitionException, TokenStreamException
{
		Exp exp;
		
		
				exp = null;
			
		
		try {      // for error handling
			switch ( LA(1) )
			{
			case INC:
			{
				match(INC);
				exp=unaryExp();
				if (0==inputState.guessing)
				{
					exp = new ExpUnary(ExpUnaryOperator.INC, exp);
				}
				break;
			}
			case DEC:
			{
				match(DEC);
				exp=unaryExp();
				if (0==inputState.guessing)
				{
					exp = new ExpUnary(ExpUnaryOperator.DEC, exp);
				}
				break;
			}
			case MINUS:
			{
				match(MINUS);
				exp=unaryExp();
				if (0==inputState.guessing)
				{
					exp = new ExpUnary(ExpUnaryOperator.NEGATIVE, exp);
				}
				break;
			}
			case PLUS:
			{
				match(PLUS);
				exp=unaryExp();
				if (0==inputState.guessing)
				{
					exp = new ExpUnary(ExpUnaryOperator.POSITIVE, exp);
				}
				break;
			}
			case NOT:
			{
				match(NOT);
				exp=unaryExp();
				if (0==inputState.guessing)
				{
					exp = new ExpUnary(ExpUnaryOperator.NOT, exp);
				}
				break;
			}
			case ID:
			case LPAREN:
			case LITERAL_true:
			case LITERAL_false:
			case DOUBLE:
			case INTEGER:
			case STRING_LITERAL:
			{
				exp=postfixExp();
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			 }
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_10_);
			}
			else
			{
				throw;
			}
		}
		return exp;
	}
	
	public Exp  postfixExp() //throws RecognitionException, TokenStreamException
{
		Exp exp;
		
		Token  funcName = null;
		
				ArrayList paramList = null;
				Exp e = null;	
				exp = null;
			
		
		try {      // for error handling
			bool synPredMatched37 = false;
			if (((LA(1)==ID)))
			{
				int _m37 = mark();
				synPredMatched37 = true;
				inputState.guessing++;
				try {
					{
						match(ID);
						match(LPAREN);
					}
				}
				catch (RecognitionException)
				{
					synPredMatched37 = false;
				}
				rewind(_m37);
				inputState.guessing--;
			}
			if ( synPredMatched37 )
			{
				funcName = LT(1);
				match(ID);
				paramList=parenArgs();
				if (0==inputState.guessing)
				{
					
							exp = new ExpFunc(funcName.getText(), paramList);	
						
				}
			}
			else if ((tokenSet_11_.member(LA(1)))) {
				e=atom();
				if (0==inputState.guessing)
				{
					exp = e;
				}
				{
					switch ( LA(1) )
					{
					case LBRACK:
					{
						match(LBRACK);
						e=topExp();
						match(RBRACK);
						if (0==inputState.guessing)
						{
							
										exp = new ExpArray(exp, e);	
									
						}
						break;
					}
					case SEMI:
					case RPAREN:
					case COMMA:
					case ASSIGN:
					case EQUAL:
					case NOTEQUAL:
					case LTSIGN:
					case GTSIGN:
					case LTE:
					case GTE:
					case PLUS:
					case MINUS:
					case TIMES:
					case DIV:
					case MOD:
					case RBRACK:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					 }
				}
			}
			else
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_10_);
			}
			else
			{
				throw;
			}
		}
		return exp;
	}
	
	public ArrayList  parenArgs() //throws RecognitionException, TokenStreamException
{
		ArrayList paramList;
		
		
				paramList = new ArrayList(); 
				Exp e = null;
			
		
		try {      // for error handling
			match(LPAREN);
			{
				switch ( LA(1) )
				{
				case ID:
				case LPAREN:
				case PLUS:
				case MINUS:
				case INC:
				case DEC:
				case NOT:
				case LITERAL_true:
				case LITERAL_false:
				case DOUBLE:
				case INTEGER:
				case STRING_LITERAL:
				{
					e=topExp();
					if (0==inputState.guessing)
					{
						paramList.Add(e);
					}
					{    // ( ... )*
						for (;;)
						{
							if ((LA(1)==COMMA))
							{
								match(COMMA);
								e=topExp();
								if (0==inputState.guessing)
								{
									paramList.Add(e);
								}
							}
							else
							{
								goto _loop42_breakloop;
							}
							
						}
_loop42_breakloop:						;
					}    // ( ... )*
					break;
				}
				case RPAREN:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				 }
			}
			match(RPAREN);
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_10_);
			}
			else
			{
				throw;
			}
		}
		return paramList;
	}
	
	public Exp  atom() //throws RecognitionException, TokenStreamException
{
		Exp exp;
		
		Token  numD = null;
		Token  numI = null;
		Token  stringToken = null;
		
				Exp e = null; 
				exp = null;
			
		
		try {      // for error handling
			switch ( LA(1) )
			{
			case ID:
			{
				exp=ident();
				break;
			}
			case LITERAL_true:
			{
				match(LITERAL_true);
				if (0==inputState.guessing)
				{
					exp = new ExpLiteralBool(true);
				}
				break;
			}
			case LITERAL_false:
			{
				match(LITERAL_false);
				if (0==inputState.guessing)
				{
					exp = new ExpLiteralBool(false);
				}
				break;
			}
			case DOUBLE:
			{
				numD = LT(1);
				match(DOUBLE);
				if (0==inputState.guessing)
				{
					exp = new ExpLiteralDouble(Double.Parse(numD.getText()));
				}
				break;
			}
			case INTEGER:
			{
				numI = LT(1);
				match(INTEGER);
				if (0==inputState.guessing)
				{
					exp = new ExpLiteralInt(Int32.Parse(numI.getText()));
				}
				break;
			}
			case STRING_LITERAL:
			{
				stringToken = LT(1);
				match(STRING_LITERAL);
				if (0==inputState.guessing)
				{
					
							string val = stringToken.getText();
							exp = new ExpLiteralString(val.Substring(1, val.Length - 2)); 
						
				}
				break;
			}
			case LPAREN:
			{
				match(LPAREN);
				e=topExp();
				match(RPAREN);
				if (0==inputState.guessing)
				{
					exp = e;
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			 }
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_12_);
			}
			else
			{
				throw;
			}
		}
		return exp;
	}
	
	public Exp  ident() //throws RecognitionException, TokenStreamException
{
		Exp exp;
		
		Token  id = null;
		Token  dot = null;
		
				exp = null;	
			
		
		try {      // for error handling
			id = LT(1);
			match(ID);
			if (0==inputState.guessing)
			{
				exp = new ExpVar(id.getText());
			}
			{    // ( ... )*
				for (;;)
				{
					if ((LA(1)==DOT))
					{
						match(DOT);
						dot = LT(1);
						match(ID);
						if (0==inputState.guessing)
						{
							
										exp = new ExpStruct(exp, dot.getText());
									
						}
					}
					else
					{
						goto _loop46_breakloop;
					}
					
				}
_loop46_breakloop:				;
			}    // ( ... )*
		}
		catch (RecognitionException ex)
		{
			if (0 == inputState.guessing)
			{
				reportError(ex);
				consume();
				consumeUntil(tokenSet_12_);
			}
			else
			{
				throw;
			}
		}
		return exp;
	}
	
	private void initializeFactory()
	{
	}
	
	public static readonly string[] tokenNames_ = new string[] {
		@"""<0>""",
		@"""EOF""",
		@"""<2>""",
		@"""NULL_TREE_LOOKAHEAD""",
		@"""function""",
		@"""ID""",
		@"""LBRACE""",
		@"""RBRACE""",
		@"""SEMI""",
		@"""if""",
		@"""LPAREN""",
		@"""RPAREN""",
		@"""else""",
		@"""while""",
		@"""for""",
		@"""return""",
		@"""COMMA""",
		@"""ASSIGN""",
		@"""EQUAL""",
		@"""NOTEQUAL""",
		@"""LTSIGN""",
		@"""GTSIGN""",
		@"""LTE""",
		@"""GTE""",
		@"""PLUS""",
		@"""MINUS""",
		@"""TIMES""",
		@"""DIV""",
		@"""MOD""",
		@"""INC""",
		@"""DEC""",
		@"""NOT""",
		@"""LBRACK""",
		@"""RBRACK""",
		@"""true""",
		@"""false""",
		@"""DOUBLE""",
		@"""INTEGER""",
		@"""STRING_LITERAL""",
		@"""DOT""",
		@"""POWER""",
		@"""NUM""",
		@"""ESC""",
		@"""SL_COMMENT""",
		@"""ML_COMMENT""",
		@"""WS""",
		@"""DIGIT"""
	};
	
	private static long[] mk_tokenSet_0_()
	{
		long[] data = { 536384431712L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_0_ = new BitSet(mk_tokenSet_0_());
	private static long[] mk_tokenSet_1_()
	{
		long[] data = { 2L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_1_ = new BitSet(mk_tokenSet_1_());
	private static long[] mk_tokenSet_2_()
	{
		long[] data = { 536384431730L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_2_ = new BitSet(mk_tokenSet_2_());
	private static long[] mk_tokenSet_3_()
	{
		long[] data = { 536384435938L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_3_ = new BitSet(mk_tokenSet_3_());
	private static long[] mk_tokenSet_4_()
	{
		long[] data = { 64L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_4_ = new BitSet(mk_tokenSet_4_());
	private static long[] mk_tokenSet_5_()
	{
		long[] data = { 536384435954L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_5_ = new BitSet(mk_tokenSet_5_());
	private static long[] mk_tokenSet_6_()
	{
		long[] data = { 8590002432L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_6_ = new BitSet(mk_tokenSet_6_());
	private static long[] mk_tokenSet_7_()
	{
		long[] data = { 8590133504L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_7_ = new BitSet(mk_tokenSet_7_());
	private static long[] mk_tokenSet_8_()
	{
		long[] data = { 8606648576L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_8_ = new BitSet(mk_tokenSet_8_());
	private static long[] mk_tokenSet_9_()
	{
		long[] data = { 8656980224L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_9_ = new BitSet(mk_tokenSet_9_());
	private static long[] mk_tokenSet_10_()
	{
		long[] data = { 9126742272L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_10_ = new BitSet(mk_tokenSet_10_());
	private static long[] mk_tokenSet_11_()
	{
		long[] data = { 532575945760L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_11_ = new BitSet(mk_tokenSet_11_());
	private static long[] mk_tokenSet_12_()
	{
		long[] data = { 13421709568L, 0L};
		return data;
	}
	public static readonly BitSet tokenSet_12_ = new BitSet(mk_tokenSet_12_());
	
}
}
