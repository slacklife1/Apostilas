using System;

using Calc.AST;
using Calc.Parser;
using Calc.Printer;
using Calc.Interpreter;

using CharBuffer			= antlr.CharBuffer;
using RecognitionException	= antlr.RecognitionException;
using TokenStreamException	= antlr.TokenStreamException;

using System.IO;

namespace Calc
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Tester
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			string filename;
			if (args.Length == 0)
			{
				Console.WriteLine("Usage: Calc filename");
				return;
			}

			filename = args[0];

			try 
			{
				StreamReader reader = new StreamReader(filename);

				CalcLexer lexer = new CalcLexer(new CharBuffer(reader));
				lexer.setFilename(filename);
				
				CalcParser parser = new CalcParser(lexer);
				parser.setFilename(filename);

				// Parse the input expression
				Program program = parser.program();

			    Console.WriteLine("Parsed program OK");
			    Console.WriteLine("---------------------------------------------");
	
	
				PrettyPrinter printer = new PrettyPrinter(program);
				printer.process(Console.Out);		    
			    Console.WriteLine("---------------------------------------------");

				Console.WriteLine("Interpreting:");
				Calc.Interpreter.Interpreter interpreter = new Calc.Interpreter.Interpreter(program);
				interpreter.process(Console.Out);
			    Console.WriteLine("\n---------------------------------------------");			

			}
			catch(TokenStreamException e) 
			{
				Console.Error.WriteLine("exception: "+e);
			}
			catch(RecognitionException e) 
			{
				Console.Error.WriteLine("exception: "+e);
			}

		}
	}
}
