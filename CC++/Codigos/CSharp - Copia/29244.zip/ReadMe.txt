This is a simple A* (A-Star) implementation. I did this for one of my university projects, so don't expect it would be very good.
Anyway, it's very simple because I'm not a C# programmer.
There are four classes, first one (class1.cs) is just a test for path finding, it opens a file and fills an array and uses it to pathfinding.
The second class, Path(path.cs) is used by third class to find the path.
The third class Node, is used by Path class.
The fourth class, PathFinding(pathfinding.cs) has a function, FindPath(), you can use it to get shortest path, its inputs are:
starti: column of start point in the array
startj: row of start point in the array
nexti: column of destination point in the array
nextj: row of destination point in the array
map: this is our array that has the map

BTW, excuse me for my poor English.

Cheers,
H.Ebrahimi