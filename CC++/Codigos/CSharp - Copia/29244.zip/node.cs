using System;

namespace Path_UProject
{
	/// <summary>
	/// This class is used as a container
	/// </summary>
	public class Node
	{
		public Node()
		{
		}

		public int i;
		public int j;
	}
}
