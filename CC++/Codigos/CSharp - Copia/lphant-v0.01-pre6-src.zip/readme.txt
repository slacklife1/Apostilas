lphant Copyright (C)2003 Juanjo < j_u_a_n_j_o@users.sourceforge.net / http://lphant.sourceforge.net >
 
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

-----------------------------------------------------------------------------------


Welcome to lphant, a filesharing client based on the eDonkey2000(C) network.


Visit us at
 http://www.lphant.com
and
 http://sourceforge.net/projects/lphant

The official Forum is also at http://www.lphant.com

Please remember that this is an early version, not all features are implemented yet,
and not everything might work as expected.

You will need Visual Studio 2003 or the .NET Framework 1.1 SDK to compile lphant. 
If you are interested in compile it under MONO or DOTGNU you can work in this task and 
let me know. We will include your changes in the next official release.

You can also compile lphant with SharpDevelop and .NET framework 1.1 SDK.
