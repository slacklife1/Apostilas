#region Copyright (c)2003 Juanjo < http://lphant.sourceforge.net >
/*
* This file is part of eLePhant
* Copyright (C)2003 Juanjo < j_u_a_n_j_o@users.sourceforge.net / http://lphant.sourceforge.net >
* 
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either
* version 2 of the License, or (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#endregion

using System;
using System.IO;
using System.Net;
using System.Diagnostics;
using System.Collections;
using eLePhant.Types;


/*CIPFilter IPFilter = new CIPFilter();
IPFilter.LoadIPFilter(Application.StartupPath,"ipfilter.dat",128);

- 192.168.100.3
Debug.WriteLine(IPFilter.BlockIP("192.168.100.3",128).ToString());
Debug.WriteLine(IPFilter.BlockedIPDescription);

- 239.168.100.3
Debug.WriteLine(IPFilter.BlockIP(40151279,128).ToString());
*/

namespace eLePhant.eDonkey
{
	public class CIPFilter
	{	
		#region Instance fields
		private struct IPRange
		{
			private uint m_IPfrom;
			private uint m_IPto;
			private byte m_Filter;
			private string m_Description;

			public IPRange(uint IPfrom, uint IPto, byte Filter, string Description) 
			{
				m_IPfrom = IPfrom;
				m_IPto = IPto;
				m_Filter = Filter;
				m_Description = Description;
			}
			
			public uint IPfrom
			{
				get	{return m_IPfrom;}
			}
			
			public uint IPto
			{
				get	{return m_IPto;}
			}
			
			public byte Filter
			{
				get	{return m_Filter;}
			}
			
			public string Description
			{
				get	{return m_Description;}
			}
		}

		private ArrayList m_IPFilterList = new ArrayList();
		private string m_BlockedIPDescription;
		#endregion
		
		#region Propertys
		public string BlockedIPDescription
		{
			get	{return m_BlockedIPDescription;}
		}
		#endregion
		
		#region Constructors & Methods
		public CIPFilter()
		{
			
		}
		
		/// <summary>
		/// Loads a IPfilter.dat.
		/// </summary>
		/// <returns>
		/// -1 = no file or the number of ranges
		/// </returns>
		/// <param name="path">
		/// The path of the ipfilter.dat.
		/// </param>
		/// <param name="fileName">
		/// The filename of the ipfilter.dat.
		/// </param>
		/// <param name="maxFilter">
		/// The filter at loading, 255 = no filter.
		/// </param>
		public void LoadIPFilter(string path,string fileName,byte maxFilter)
		{	
			uint IPfrom;
			uint IPto;
			byte Filter;
			int count=0;
			
			string fullpath = path + "\\" + fileName;

			if (File.Exists(fullpath)) 
			{
				using(StreamReader sr = File.OpenText(fullpath))
				{
					string s = "";
					while ((s = sr.ReadLine()) != null) 
					{
						//000.000.000.000 - 000.255.255.255 , 100 , LOW_ID (invalid)
						
						//ignore comments and short string
						if(s[0]=='#' || s[0]=='/' || s.Length<5) continue;
						
						string [] splitString = s.Split(new Char [] {'-', ',', ','});
						try
						{
							Filter = Convert.ToByte(splitString[2]);
							if(Filter>maxFilter) continue;

							IPfrom = IPConvert(splitString[0]);
							IPto = IPConvert(splitString[1]);
							
							IPRange myIPRange = new IPRange(IPfrom,IPto,Filter,splitString[3]);
							m_IPFilterList.Add(myIPRange);
							count++;
						}
						catch(Exception e)
						{
							Debug.WriteLine(s+" : "+e.Message);
						}
					}
				}
				CLog.Log(Constants.Log.Info,count.ToString() + " IP in " + fileName + " loaded" );
			}
		}
		
		/// <summary>
		/// The IP must be blocked.
		/// </summary>
		/// <param name="in_IPtoTest">
		/// The IP to test, string or uint
		/// </param>
		/// <param name="in_filter">
		/// The max filter.
		/// </param>
		public bool BlockIP(uint in_IPtoTest, byte in_filter)
		{
			try
			{	
				byte filter = in_filter;
				uint IPtoTest = IPConvert(in_IPtoTest);
				return IsFiltered(IPtoTest,filter);
			}
			catch(Exception e)
			{
				Debug.WriteLine(e.Message);
				return false;
			}
		}
		
		public bool BlockIP(string in_IPtoTest, byte in_filter)
		{
			try
			{	
				byte filter = in_filter;
				uint IPtoTest = IPConvert(in_IPtoTest);
				return IsFiltered(IPtoTest,filter);
			}
			catch(Exception e)
			{
				Debug.WriteLine(e.Message);
				return false;
			}
		}
		
		/// <summary>
		/// Filter the IP.
		/// </summary>
		/// <param name="IPtoTest">
		/// The IP to test, always the integer value.
		/// </param>
		/// <param name="filter">
		/// The max filter.
		/// </param>
		private bool IsFiltered(uint IPtoTest, byte filter)
		{	
			if(m_IPFilterList.Count==0 || IPtoTest==0) return false; 

			foreach(IPRange ip in m_IPFilterList)
			{
				if(IPtoTest>=ip.IPfrom && IPtoTest<=ip.IPto && ip.Filter<filter)
				{	
					m_BlockedIPDescription = ip.Description;
					return true;
				}
			}
			return false;
		}
		
		/// <summary>
		/// Converts an IP(192.168.100.10 or uint IP) into an integer.
		/// </summary>
		/// <returns>
		/// Returns an IP into an integer
		/// </returns>
		/// <param name="in_IP">
		/// The IP, could be a string or a unit.
		/// </param>
		private uint IPConvert(uint in_IP)
		{
			string ipString = (new IPAddress(in_IP)).ToString();
			return IPConvert(ipString);
		}
		
		private uint IPConvert(string in_IP)
		{
			string [] IP = in_IP.Split(".".ToCharArray());
			
			try
			{
				return (Convert.ToUInt32(IP[0])*(16777216) + Convert.ToUInt32(IP[1])*65536 + Convert.ToUInt32(IP[2])*256 + Convert.ToUInt32(IP[3]));
			}
			catch(Exception e)
			{
				throw(e);
			}
		}
		#endregion
	}
}
