#region Copyright (c)2003 Juanjo < http://lphant.sourceforge.net >
/*
* This file is part of eLePhant
* Copyright (C)2003 Juanjo < j_u_a_n_j_o@users.sourceforge.net / http://lphant.sourceforge.net >
* 
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either
* version 2 of the License, or (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#endregion

using System;
using System.Collections;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;
using System.Net;
using eLePhant.Types;

namespace eLePhant.eDonkey
{
	/// <summary>
	/// CServersList handles a list of eDonkey network servers.
	/// </summary>
	internal class CServersList:ArrayList
	{
		#region Instance fields
		/// <summary>Store for the current connection index.</summary>
		private int m_ConnectionIndex;
		/// <summary>Store for the failed connection count.</summary>
		private int m_FailedConnetions;
		/// <summary>Store for the last send UDP source time.</summary>
		private DateTime m_LastUDPSourceSearch;
		/// <summary>Store for the last send UDP ping time.</summary>
		private DateTime m_LastPingUDP;
		/// <summary>Store for the file UDP search index.</summary>
		private int m_UDPSourceSearchFileIndex;
		/// <summary>Store for the server search index.</summary>
		private int m_SourceSearchServerIndex;
		/// <summary>Store for the UDP search ping index.</summary>
		private int m_ServerPingUDPIndex;
		/// <summary>Store for the active server.</summary>
		private CServer m_ActiveServer;
		/// <summary>Store for the file TCP search index.</summary>
		private int m_TCPSourceSearchFileIndex;
		/// <summary>Store for the last send TCP source search time.</summary>
		private DateTime m_NextTCPSourcesSearch;

		#endregion

		#region Propertys
		/// <summary>
		/// Specify the active server.
		/// </summary>
		public CServer ActiveServer
		{
			get
			{
				return m_ActiveServer;
			}
			set
			{
				m_ActiveServer=value;
			}
		}
		public DateTime NextTCPSourcesSearch
		{
			set
			{
				m_NextTCPSourcesSearch=value;
			}
		}
		
		#endregion

		#region Constructors
		/// <summary>
		/// Creates a new ServerList.
		/// </summary>
		public CServersList()
		{
			m_ConnectionIndex=0;
			ActiveServer=null;
			m_LastUDPSourceSearch=DateTime.MinValue;
			m_LastPingUDP=DateTime.MinValue;
			m_NextTCPSourcesSearch=DateTime.MaxValue;
			m_UDPSourceSearchFileIndex=0;
			m_TCPSourceSearchFileIndex=0;
			m_SourceSearchServerIndex=0;
			m_ServerPingUDPIndex=0;
		}

		/// <summary>
		/// Destroy the ServerList.
		/// </summary>
		~CServersList()
		{
			// disconnect from server if connected
			if (ActiveServer!=null) ActiveServer.Disconnect();
		}
		#endregion

		#region Internal Methods
		/// <summary>
		/// Connect to the next server.
		/// </summary>
		private void m_ConnectToNextServers()
		{
			CServer server;

			if (ActiveServer!=null) 
			{
				//we have a good connection 
				m_DeleteFailedServers();
				return;
			}
			if (m_FailedConnetions<=0) m_FailedConnetions=Protocol.MaxParalelConnections;
			while ((m_FailedConnetions>0)&(m_ConnectionIndex<this.Count))
			{
				server=(CServer)this[m_ConnectionIndex];
				m_ConnectionIndex++;
				m_FailedConnetions--;
				server.Connect();
			}
		}

		/// <summary>
		/// Delete all servers where connection failed too often.
		/// </summary>
		private void m_DeleteFailedServers()
		{
			CServer server;
			int deleted=0;
			for (int i=0;i!=this.Count;i++)
			{
				server=(CServer)this[i];
				if (server.Fails>=CKernel.Preferences.GetShort("MaxServerFails"))
				{
					if (server!=ActiveServer) 
					{
						this.RemoveAt(i);
						CKernel.DeleteServer(server.IP,server.Port);
						deleted++;
					}
				}
			}
			CLog.Log(Constants.Log.Info,"SRV_DELETED",deleted);
		}
		#endregion

		#region Methods
		/// <summary>
		/// Returns a server.
		/// </summary>
		/// <param name="ip">IP of the server.</param>
		/// <param name="port">Port of the server.</param>
		/// <returns>Server which match the given IP and Port.</returns>
		public CServer GetServer(uint ip, ushort port)
		{
			CServer server;
			int nServers=this.Count;
			lock(this)
			{
				for (int i=0;i!=nServers;i++)
				{
					server=(CServer)this[i];
					if ((server.IP==ip)&&((port==0)||(server.Port==port)))
						return server;
				}
			}
			return null;
		}

		/// <summary>
		/// Set a server priority.
		/// </summary>
		/// <param name="ip">IP of the server.</param>
		/// <param name="port">Port of the server.</param>
		/// <param name="priority">New priority of the server.</param>
		public void SetServerPriority(uint ip, ushort port, Constants.ServerPriority priority)
		{
			CServer server;
			int nServers=this.Count;
			lock(this)
			{
				for (int i=0;i!=nServers;i++)
				{
					server=(CServer)this[i];
					if ((server.IP==ip)&&((port==0)||(server.Port==port)))
					{
						server.Priority=priority;
						break;
					}
				}
			}
		}
		/// <summary>
		/// Add a server to the list.
		/// </summary>
		/// <param name="ip">IP of the server.</param>
		/// <param name="port">Port of the server.</param>
		/// <returns>The new server.</returns>
		public CServer AddServer(uint ip, ushort port)
		{
			if ((ip<Protocol.LowIDLimit)||(port==0)) return null;
			CServer server;
			if (GetServer(ip,port)==null)
			{
				server=new CServer(ip,port);
				this.Add(server);
				CKernel.NewServer(server);
				return server;
			}
			else
				return null;
		}

		/// <summary>
		/// Remove a Server from list.
		/// </summary>
		/// <param name="ip">IP of the server.</param>
		/// <param name="port">Port of the server.</param>
		/// <returns>Returns true if server successfully removed.</returns>
		public bool DeleteServer(uint ip, ushort port)
		{
			CServer server=GetServer(ip,port);
			if (server!=null)
			{
				this.Remove(server);
				CKernel.DeleteServer(ip,port);
				return true;
			}
			else
				return false;
		}

		/// <summary>
		/// Connect to an specified server.
		/// </summary>
		/// <param name="ip">IP of the server.</param>
		/// <param name="port">Port of the server</param>
		/// <returns>Returns true if connection could be established.</returns>
		public bool ConnectToServer(uint ip, ushort port)
		{
			CServer server=GetServer(ip,port);
			if (server!=null)
			{
				if (ActiveServer!=null)
				{
				ActiveServer.Disconnect();
				ActiveServer=null;
				}
				server.Connect();
				return true;
			}
			else
				return false;
		}

		/// <summary>
		/// Add a server to the list.
		/// </summary>
		/// <param name="strIP">IP of the server.</param>
		/// <param name="port">Port of the server.</param>
		/// <returns>The new server.</returns>
		public CServer AddServer(string strIP, ushort port)
		{
			IPAddress DirectionIP=IPAddress.Parse(strIP);
			uint ip=BitConverter.ToUInt32(DirectionIP.GetAddressBytes(),0);
			return AddServer(ip,port);
		}

		/// <summary>
		/// Remove all servers from the list.
		/// </summary>
		public void Clean()
		{
			if (ActiveServer!=null) 
			{
				ActiveServer.Disconnect();
				ActiveServer=null;
			}			
			this.Clear();
		}

		/// <summary>
		/// Connect to any server.
		/// </summary>
		public void ConnectToAnyServer()
		{
			m_FailedConnetions=0;
			if (m_ConnectionIndex>Count) m_ConnectionIndex=0;
			if (ActiveServer!=null) 
			{
				ActiveServer.Disconnect();
				ActiveServer=null;
				if (!CKernel.Preferences.GetBool("AutoReconnect")) m_ConnectToNextServers();
				return;
			}
			m_ConnectToNextServers();
		}

		/// <summary>
		/// Check if the given server is the active server.
		/// </summary>
		/// <param name="IP">IP of the server</param>
		/// <param name="port">Port of the server</param>
		/// <returns>Returns true if the given server data is the active server.</returns>
		public bool IsTheActiveServer(uint IP, ushort port)
		{
			if ((ActiveServer!=null)&&(ActiveServer.IP==IP)&&(ActiveServer.Port==port))
				return true;
			else
				return false;
		}

		/// <summary>
		/// The connection to server failed.
		/// </summary>
		/// <param name="server">server</param>
		/// <param name="reason">reason</param>
		/// <returns></returns>
		public bool ConnectionFailed(CServer server, byte reason)
		{
			lock(this)
			{
				if (server==ActiveServer) 
				{
					ActiveServer=null;
					m_FailedConnetions=0;
					m_ConnectionIndex=0;
					CLog.Log(Constants.Log.Info, "SRV_CNN_LOST");
					if (!CKernel.Preferences.GetBool("AutoReconnect")) 
						return false;
					else
					{
						m_ConnectToNextServers();
						return false;
					}
				}
				else
					if (ActiveServer!=null) return false;

				if (m_ConnectionIndex>0)
				{
					m_FailedConnetions++;
					//if (m_FailedConnetions==Protocol.MAX_CONEXIONESPARALELAS)
					m_ConnectToNextServers();
				
				}
			}
			return true;
		}

		/// <summary>
		/// Request CallBack via UDP from specified server.
		/// </summary>
		/// <param name="ServerIP">IP of the server.</param>
		/// <param name="ServerPort">Port of the server.</param>
		/// <param name="IDClient">ID of the client.</param>
		public void RequestCallBackUDP(uint ServerIP, ushort ServerPort, uint IDClient)
		{
			CServer server=GetServer(ServerIP,ServerPort);
			if (server==null) server=AddServer(ServerIP,ServerPort);
			if (server!=null) server.RequestCallBackUDP(IDClient);
		}

		/// <summary>
		/// Search sources for the 15 next files using TCP
		/// </summary>
		public void SearchNextSourcesTCP()
		{
			if ((m_NextTCPSourcesSearch>DateTime.Now)||(ActiveServer==null)||(CKernel.FilesList.Count==0)) return;
			ArrayList hashes=new ArrayList();
			CElement Element;
			do
			{
				if (CKernel.FilesList.Count<=m_TCPSourceSearchFileIndex) 
				{
					m_TCPSourceSearchFileIndex=0;
					break;
				}
				else
				{
					Element=CKernel.FilesList[m_TCPSourceSearchFileIndex];
					m_TCPSourceSearchFileIndex++;
				}
				if ((Element.SourcesList!=null)&&(Element.File.FileStatus!=Protocol.FileState.Stopped)&&(CKernel.Preferences.GetInt("MaxSourcesPerFile")>Element.SourcesList.Count()-5)) 
				{
					hashes.Add(Element.File.FileHash);
				}
			}
			while (hashes.Count<Protocol.SourcesPerTCPFrame);
			if ((m_TCPSourceSearchFileIndex==0)||(hashes.Count==0))
				m_NextTCPSourcesSearch=DateTime.Now+new TimeSpan(0,Protocol.ReaskClient,0);
			else
				m_NextTCPSourcesSearch=DateTime.Now+new TimeSpan(0,0,Protocol.ReaskNextTCPFile*hashes.Count);
			if (hashes.Count>0) ActiveServer.RequestSources(hashes);
		}
		/// <summary>
		/// Search sources on the next server via UDP.
		/// </summary>
		public void SearchNextSourcesUDP()
		{
			if ((this.Count<=0)||(CKernel.FilesList.Count<=0)) return;
			if ((DateTime.Now.Ticks-m_LastUDPSourceSearch.Ticks) > Protocol.ReaskServerUDP)
			{
				m_LastUDPSourceSearch=DateTime.Now;
				if (this.Count<=m_SourceSearchServerIndex) m_SourceSearchServerIndex=0;
				CServer server=(CServer)this[m_SourceSearchServerIndex];
				ArrayList hashes=new ArrayList();
				CElement Element;
				uint allComplete=0;
				do 
				{
					m_UDPSourceSearchFileIndex++;
					if (CKernel.FilesList.Count<=m_UDPSourceSearchFileIndex) m_UDPSourceSearchFileIndex=0;
					Element=CKernel.FilesList[m_UDPSourceSearchFileIndex];
					if ((Element.SourcesList!=null)&&(Element.File.FileStatus!=Protocol.FileState.Stopped)&&(CKernel.Preferences.GetInt("MaxSourcesPerFile")>Element.SourcesList.Count()-5)) 
					{
						hashes.Add(Element.File.FileHash);
						if (hashes.Count>=Protocol.MaxRequestsPerServer) break;
					}
					allComplete++;
				}
				while (allComplete<CKernel.FilesList.Count);
				//	if (allComplete<CKernel.FilesList.Count) 
				//	{
				//server.RequestSourcesUDP(Element.File.FileHash);
				server.RequestSourcesUDP(hashes);
				m_SourceSearchServerIndex++;
				//	}
			}
		}

		/// <summary>
		/// Ping next server via UDP.
		/// </summary>
		public void NextPingUDP()
		{
			if (this.Count<=0) return;
			if ((DateTime.Now-m_LastPingUDP)>new TimeSpan(0,Protocol.ReaskPingUDP,0))
			{
				m_LastPingUDP=DateTime.Now;
				if (this.Count<=m_ServerPingUDPIndex) m_ServerPingUDPIndex=0;
				CServer server=(CServer)this[m_ServerPingUDPIndex];
				m_ServerPingUDPIndex++;
				server.RequestUDPPing();
			}
		}
		public void ServerSort()
		{
			IComparer myServerListSorter = new ServerListSorter();
			this.Sort(myServerListSorter);
		}
		#endregion

		#region Load & Save Methods
		/// <summary>
		/// Load a list of servers from binary file (server.met).
		/// </summary>
		/// <param name="fullpathfile">The full Path to the file.</param>
		/// <param name="clean">Set clean to true if the list should be cleaned before read.</param>
		/// <returns>Count of servers which could be loaded.</returns>
		public int LoadServerList(string fullpathfile, bool clean)
		{
			if (clean) Clean();
			FileStream servermet;
			if (fullpathfile.Length==0)
				fullpathfile=Application.StartupPath + "\\server.met";
			try
			{
				servermet=File.OpenRead(fullpathfile);
			}
			catch
			{
				return 0;
			}

			byte version;
			BinaryReader reader=new BinaryReader(servermet);
			int added=0;
			try
			{
				version=reader.ReadByte();

				if (!Enum.IsDefined(typeof(Protocol.ServerMet), version))
				{
					servermet.Close();
					CLog.Log(Constants.Log.Notify,"SRVMET_INVALID");
					return 0;
				}
				uint nServers=reader.ReadUInt32();
				uint ip;
				ushort port;
				CServer server;
				while (nServers>0)
				{
					ip=reader.ReadUInt32();
					port=reader.ReadUInt16();
					server=AddServer(ip,port);
					if (server!=null)
					{
						server.Load(reader);
						added++;
					}
					nServers--;
				}

				ServerSort();
			}
			catch
			{
				CLog.Log(Constants.Log.Info,"SRV_ADDED",added);
				CLog.Log(Constants.Log.Notify,"SRVMET_INVALID");
			}
			servermet.Close();
			CLog.Log(Constants.Log.Info,"SRV_ADDED",added);
			return added;
		}

		/// <summary>
		/// Save list of servers to binary file (server.met).
		/// </summary>
		/// <param name="fullpathfile">Full path to the file.</param>
		public void SaveServerList(string fullpathfile)
		{
			FileStream servermet;
			if (fullpathfile.Length==0)
				fullpathfile=Application.StartupPath + "\\server.met";
			try
			{
				servermet=File.OpenWrite(fullpathfile);
			}
			catch
			{
				return;
			}

			byte version;
			BinaryWriter writer=new BinaryWriter(servermet);

			version=(byte)Protocol.ServerMet.eDonkey;
			writer.Write(version);

			int nServers=(int)this.Count;
			writer.Write(nServers);

			for (int i=0;i!=nServers;i++)
			{
				if (((CServer)this[i]).Fails<CKernel.Preferences.GetShort("MaxServerFails"))
				{
					writer.Write(((CServer)this[i]).IP);
					writer.Write(((CServer)this[i]).Port);
					((CServer)this[i]).Save(writer);
				}
			}
		}
		#endregion

		#region Comparer Class
		/// <summary>
		/// Class compares two servers and order them by files.
		/// </summary>
		public class ServerListSorter : IComparer  
		{			
			int IComparer.Compare(Object x,Object y)  
			{
				if ((x==null)||(y==null)) return 0;

				CServer serverA = (CServer)x;
				CServer serverB = (CServer)y;
				
				byte prioA=(byte)((byte)serverA.Priority+1);
				byte prioB=(byte)((byte)serverB.Priority+1);
				if (prioA==2) prioA=0;
				if (prioB==2) prioB=0;
				
				if (prioA<prioB)
					return -1;
				else if (prioA>prioB) 
					return 1;

				if(serverA.Files>serverB.Files)
					return -1;
				else
					return 1;
			}

		}
		#endregion
	}
}