#region Copyright (c)2003 Juanjo < http://lphant.sourceforge.net >
/*
* This file is part of eLePhant
* Copyright (C)2003 Juanjo < j_u_a_n_j_o@users.sourceforge.net / http://lphant.sourceforge.net >
* 
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either
* version 2 of the License, or (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#endregion

using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Net;
using System.Collections;

namespace eLePhant.eDonkey
{
	/// <summary>
	/// Descripci�n breve de CRemoting.
	/// Servidor remoto, registrar el canal, y publicar la clase.
	/// Previsto algun tipo de autentificaci�n.
	/// </summary>
	internal class CRemoting
	{
		private TcpChannel m_lPhantChannel;
		private int port;

		public CRemoting()
		{
			//
			// TODO: agregar aqu� la l�gica del constructor
			//
			port=CKernel.Preferences.GetInt("RemoteControlPort");
			Hashtable props = new Hashtable();
			props.Add("name","eLePhantService");
			props.Add("priority","10"); //en la ayuda pone que son enteros, pero con ellos da error de conversion.
			props.Add("port", port);
			props.Add("supressChannelData",true);
			props.Add("useIpAddress",true);
			props.Add("rejectRemoteRequests",false);
			BinaryServerFormatterSinkProvider provider = new BinaryServerFormatterSinkProvider();
			provider.TypeFilterLevel = 
				System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;			
			m_lPhantChannel = new TcpChannel(props, null, provider);
			ChannelServices.RegisterChannel(m_lPhantChannel);
			RemotingConfiguration.RegisterWellKnownServiceType(
				typeof(CInterfaceGateway), 
				"InterfazRemota",
				WellKnownObjectMode.Singleton);	
		}

		~CRemoting()
		{
			ChannelServices.UnregisterChannel(m_lPhantChannel);
		}
	}
}