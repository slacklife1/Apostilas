#region Copyright (c)2003 Juanjo < http://lphant.sourceforge.net >
/*
* This file is part of eLePhant
* Copyright (C)2003 Juanjo < j_u_a_n_j_o@users.sourceforge.net / http://lphant.sourceforge.net >
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either
* version 2 of the License,or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not,write to the Free Software
* Foundation,Inc.,675 Mass Ave,Cambridge,MA 02139,USA.
*/
#endregion

using System;
using System.Collections;
using System.Threading;
using System.Diagnostics;
using eLePhant.Types;

namespace eLePhant.eDonkey
{
	/// <summary>
	/// eDonkey Queue for upload
	/// </summary>
	internal class CQueue
	{
		public ArrayList UploadList;

		private ArrayList m_QueueList;
		private Timer m_QueueThread;
		private DateTime m_LastSend;
		private double m_UploadSpeed;

		private ArrayList m_UploadAverages;
		private int m_nSent;
		private int m_EstimatedRate;
		private int m_SumForAverages;
		private DateTime m_LastAcceptedClientTime;

		public float GetUploadSpeed()
		{
			return (float)Math.Round(m_UploadSpeed/1024F,1);
		}

		public int Count
		{
			get
			{
				return m_QueueList.Count;
			}
		}

		public CClient this[int index]
		{
			get
			{
				return (CClient)m_QueueList[index];
			}
		}

		public ArrayList List
		{
			get
			{
				return m_QueueList;
			}
		}

		public CQueue()
		{
			m_QueueList=ArrayList.Synchronized(new ArrayList());
			UploadList=ArrayList.Synchronized(new ArrayList());
			m_UploadAverages=new ArrayList();

			for (int i=0;i!=100;i++)
			{
				m_UploadAverages.Add(0);
			}

			m_QueueThread=new Timer(new TimerCallback(m_Process),null,1000,200);
			m_LastSend=DateTime.Now;
			m_LastAcceptedClientTime=DateTime.MinValue;
		}

		public ushort RefreshClientUDP(uint IP,ushort UDPPort)
		{
			CClient foundClient=null;

			lock(m_QueueList.SyncRoot)
			{
				foreach (CClient client in m_QueueList)
				{
					if ((client.UserID==IP)&&(client.UDPPort==UDPPort))
					{
						foundClient=client;
						break;
					}
				}
			}

			if (foundClient!=null)
			{
				foundClient.IncUploadRequests();
				foundClient.LastUploadRequest=DateTime.Now;
				return m_GetQueuePosition(foundClient);
			}
			else return 0;
		}

		public ushort AddClient(CClient Client)
		{
			Client.IncUploadRequests();
			Client.LastUploadRequest=DateTime.Now;

			if (m_QueueList.Count>=CKernel.Preferences.GetInt("QueueLength"))
			{
//clineeded				CKernel.ClientsList.IsClientNeeded(Client);
				return 0;
			}

			if ((!m_QueueList.Contains(Client))&&(!UploadList.Contains(Client)))
			{
				m_QueueList.Add(Client);
				if (Client.UploadElement!=null)  Client.UploadElement.Statistics.AddUploadChunksAvaibility(Client.UpFileChunks);
				Client.QueueInTime=DateTime.Now;
			}

			return m_GetQueuePosition(Client);
		}

		private ushort m_GetQueuePosition(CClient Client)
		{
			if (!m_QueueList.Contains(Client)) return 0;

			ushort position=1;
			double rating=GetClientRating(Client);

			foreach (CClient compareClient in m_QueueList)
			{
				if (compareClient==Client) continue;

				if (GetClientRating(compareClient)<GetClientRating(Client))
				{
					position++;
				}
			}
			return position;
		}

		private void m_RemoveTimedOutCallBacks()
		{
			ArrayList timedOutCalledBack=null;
			foreach(CClient Client in UploadList)
			{
				if ((Client.UploadState==Protocol.UploadState.WaitCallBack)
					&&(Client.CallBackTimedOut))
				{
					if (timedOutCalledBack==null)
					{
						timedOutCalledBack=new ArrayList();
					}
					timedOutCalledBack.Add(Client);
				}
			}
			if (timedOutCalledBack!=null) 
			{
				foreach (CClient CallBackClient in timedOutCalledBack)
				{
					CallBackClient.OnDisconnect((byte)Protocol.ConnectionReason.CannotConnect);
				}
			}
		}
		private bool m_AllowNewUpload()
		{
			//add new uploads
			if (DateTime.Now-m_LastAcceptedClientTime<new TimeSpan(0,0,10))
				return false;
			if ((m_QueueList.Count < 1)
				||((float)UploadList.Count>=CKernel.Preferences.GetFloat("MaxUploadRate")/2F))
			{
				return false;
			}
//			if (((m_UploadSpeed/UploadList.Count)>2000F)&&((m_UploadSpeed/UploadList.Count)<3000F)) return false;
			return true;
		}
		private void m_AcceptNewUpload()
		{
			if (!m_AllowNewUpload()) return;

			CClient client=SelectNextClient();

			if (client!=null)
			{
				client.StartUpload();
				m_LastAcceptedClientTime=DateTime.Now;
				UploadList.Add(client);
				m_QueueList.Remove(client);
				CKernel.NewUpload(client);
			}
		}

		private void m_Process(Object state)
		{
			DateTime inTime=DateTime.Now;
			
			m_RemoveTimedOutCallBacks();

			CKernel.ServersList.SearchNextSourcesUDP();
			CKernel.ServersList.SearchNextSourcesTCP();
			CKernel.ServersList.NextPingUDP();

			m_QueueThread.Change(Timeout.Infinite,Timeout.Infinite);

			//this is from emule ;)
			m_SumForAverages-=(int)(m_UploadAverages[0]);
			m_UploadAverages.RemoveAt(0);
			m_UploadAverages.Add(m_nSent);
			m_SumForAverages+=m_nSent;
			m_UploadSpeed=10*m_SumForAverages/m_UploadAverages.Count;
			CKernel.GlobalStatistics.IncSessionUp(m_nSent);

			m_AcceptNewUpload();
			if (UploadList.Count==0)
			{
				m_QueueThread.Change(100,Timeout.Infinite);
				return;
			}

			int readyClients=0;

			lock(UploadList.SyncRoot)
			{
				foreach (CClient client in UploadList)
				{
					if ((client.connection!=null)&&(!client.connection.Sending))
					{
						readyClients++;
					}
				}

			}
			if (readyClients==0)
			{
				m_EstimatedRate-=200;
				if (m_EstimatedRate<100)
				{
					m_EstimatedRate=100;
				}
				readyClients++;
			}
			else
			{
				m_EstimatedRate+=200;
				if (m_EstimatedRate>(int)(CKernel.Preferences.GetFloat("MaxUploadRate")*102))
				{
					m_EstimatedRate=(int)(CKernel.Preferences.GetFloat("MaxUploadRate")*102);
				}
			}

			m_nSent=0;
			CClient Client;

			int sendByClient=m_EstimatedRate/readyClients;
			int index=0;

			while (index < UploadList.Count)
			{
				Client=(CClient)(UploadList[index]);
				m_nSent+=Client.SendBlockData(sendByClient);
				index++;
			}
			//  Debug.WriteLine(DateTime.Now.ToString()+": "+m_nSent.ToString()+" ready: "+readyClients.ToString()+" estimated:"+m_EstimatedRate.ToString());
			TimeSpan lostTime=(DateTime.Now-inTime);
			if (lostTime.TotalMilliseconds>=100)
			{
				m_QueueThread.Change(1,Timeout.Infinite);
			}
			else
			{
				m_QueueThread.Change(100-(int)lostTime.TotalMilliseconds,Timeout.Infinite);
			}
		}

		private double GetClientRating(CClient client)
		{
			double priority=1F;
			double credit=1F;
			TimeSpan timeInQueue=DateTime.Now-client.QueueInTime;

			if ((client.UploadElement!=null)&&(client.UploadElement.File!=null))
			{
				switch(client.UploadElement.File.UpPriority)
				{
					case Constants.Priority.VeryLow:
						priority=1;
						break;
					case Constants.Priority.Low:
						priority=2;
						break;
					case Constants.Priority.Normal:
						priority=3;
						break;
					case Constants.Priority.High:
						priority=4;
						break;
					case Constants.Priority.VeryHigh:
						priority=7;
						break;
				}
			}
			//instant credit
			if ((client.DownloadState==Protocol.DownloadState.Downloading))
			{
				credit=1F+client.DownloadSpeed*20F;
			}

			// emule credits systems benefit sources to us by probabilities due to the credit system,we emulate it with a littel benefit to get similar downloads speeds
			if ((client.DownFileHash!=null)&&(client.DownloadState!=Protocol.DownloadState.NoNeededParts))
			{
				if ((client.QRDownload<100)&&(client.QRDownload>0))
				{
					credit*=3.5F;
				}
				else
				{
					credit*=2.5F;
				}
			}
			return timeInQueue.TotalSeconds*priority*credit;
		}

		private CClient SelectNextClient()
		{
			CClient maxClient=null;
			ArrayList deleteList=new ArrayList();
			double maxRating=0;
			double rating=0;
			DateTime nowTime=DateTime.Now;

			lock (m_QueueList.SyncRoot)
			{
				foreach (CClient client in m_QueueList)
				{
					if (nowTime-client.LastUploadRequest>=new TimeSpan(0,Protocol.MinPurgeQueueTime,0))
					{
						deleteList.Add(client);
					}
					else
					{
						rating=GetClientRating(client);
						if (rating > maxRating)
						{
							maxRating=rating;
							maxClient=client;
						}
					}
				}
			}

			foreach (CClient client in deleteList)
			{
				Debug.Write("Client "+client.UserName+" cleaned from queue\n");
				m_QueueList.Remove(client);
				if (client.UploadElement!=null) client.UploadElement.Statistics.RemoveUploadChunksAvaibility(client.UpFileChunks);
				CKernel.ClientsList.IsClientNeeded(client);
			}
			return maxClient;
		}

		public bool ContainsClient(CClient cliente)
		{
			return ((m_QueueList.Contains(cliente))||(UploadList.Contains(cliente)));
		}

		public void Clean()
		{
			m_QueueList.Clear();
			UploadList.Clear();
		}
	}
}