#region Copyright (c)2003 Juanjo < http://lphant.sourceforge.net >
/*
* This file is part of eLePhant
* Copyright (C)2003 Juanjo < j_u_a_n_j_o@users.sourceforge.net / http://lphant.sourceforge.net >
* 
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either
* version 2 of the License,or (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program; if not,write to the Free Software
* Foundation,Inc.,675 Mass Ave,Cambridge,MA 02139,USA.
*/
#endregion

using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Diagnostics;
using System.Net;

using ICSharpCode.SharpZipLib.Zip.Compression;
using ICSharpCode.SharpZipLib.Zip.Compression.Streams;

namespace eLePhant.eDonkey
{
	/// <summary>
	/// Summary description for edonkeyCommands.
	/// </summary>
	internal class DonkeyHeader
	{
		public Protocol.ProtocolType eDonkeyID;
		public uint Packetlength;
		public byte Command;

		public DonkeyHeader(byte command)
		{
			eDonkeyID=Protocol.ProtocolType.eDonkey;
			Command=command;
			Packetlength=6;
		}

		public DonkeyHeader(byte command,Protocol.ProtocolType protocol)
		{
			eDonkeyID=protocol;
			Command=command;
			Packetlength=6;
		}

		public DonkeyHeader(byte command,BinaryWriter writer)
		{
			eDonkeyID=Protocol.ProtocolType.eDonkey;
			Command=command;
			Packetlength=6;
			Serialize(writer);
		}

		public DonkeyHeader(byte command,BinaryWriter writer,Protocol.ProtocolType protocol)
		{
			eDonkeyID=protocol;
			Command=command;
			Packetlength=6;
			Serialize(writer);
		}

		public DonkeyHeader(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			eDonkeyID=(Protocol.ProtocolType)reader.ReadByte();
			Packetlength=(uint)reader.ReadInt32();
			Command=reader.ReadByte();
		}

		public void Serialize(BinaryWriter writer)
		{
			writer.Write((byte)eDonkeyID);
			writer.Write(Packetlength);
			writer.Write(Command);
		}
	}

	internal class CParameterReader
	{
		public byte tipo;
		public byte id;
		public string nombreParam;
		public string valorString;
		public uint valorNum;

		public CParameterReader(BinaryReader reader)
		{
			ushort longitud;
			tipo=reader.ReadByte();
			longitud=reader.ReadUInt16();

			if (longitud==1)
				id=reader.ReadByte();
			else
				nombreParam=new string(reader.ReadChars(longitud));

			if (tipo==2)
			{
				longitud=reader.ReadUInt16();
				//valorString=new string(reader.ReadChars(longitud));
				//valorString=Encoding.UTF8.GetString(reader.ReadBytes(longitud));
				byte [] buf;//=new byte[longitud];
				buf=reader.ReadBytes(longitud);
				valorString=Encoding.Default.GetString(buf);
			} 
			else if (tipo==3) valorNum=reader.ReadUInt32();
			else if (tipo==4) reader.ReadBytes(4);
			else if (tipo==1) reader.ReadBytes(16);
			else if (tipo==5) reader.ReadByte();
		}
	}

	internal class CParametersSaver
	{
		public CParametersSaver(byte tipo,byte id,string nombreParam,string valorString,uint valorNum,BinaryWriter writer)
		{
			switch(tipo)
			{
				case 2:
					ParametroCadenaCadena pCC;
					ParameterNumericString pNC;
					if (nombreParam!=null)
						pCC=new ParametroCadenaCadena(nombreParam,valorString,writer);
					else
						pNC=new ParameterNumericString(id,valorString,writer);
					break;
				case 3:
					ParameterStringNumeric pCN;
					ParameterNumericNumeric pNN;
					if (nombreParam!=null)
						pCN=new ParameterStringNumeric(nombreParam,valorNum,writer);
					else
						pNN=new ParameterNumericNumeric(id,valorNum,writer);
					break;
			}
		}
	}

	public struct ParameterStringNumeric
	{
		private byte tipo;
		private string id;
		private uint valorNum;

		public ParameterStringNumeric(string strID,uint nvalor,BinaryWriter writer)
		{
			tipo=3;
			id=strID;
			valorNum=nvalor;
			Serialize(writer);
		}

		public ParameterStringNumeric(string strID,uint nvalor)
		{
			tipo=3;
			id=strID;
			valorNum=nvalor;
		}

		public void Serialize(BinaryWriter writer)
		{
			writer.Write(tipo);
			writer.Write((ushort)id.ToCharArray().Length);
			writer.Write(id.ToCharArray());
			writer.Write(valorNum);
		}
	}

	public struct ParametroCadenaCadena
	{
		private byte tipo;
		private string id;
		private string valorString;

		public ParametroCadenaCadena(string strID,string strCadena,BinaryWriter writer)
		{
			tipo=2;
			id=strID;
			valorString=strCadena;
			Serialize(writer);
		}

		public ParametroCadenaCadena(string strID,string strCadena)
		{
			tipo=2;
			id=strID;
			valorString=strCadena;
		}

		public void Serialize(BinaryWriter writer)
		{
			writer.Write(tipo);
			writer.Write((ushort)id.ToCharArray().Length);
			writer.Write(id.ToCharArray());
			writer.Write((ushort)valorString.ToCharArray().Length);
			writer.Write(valorString.ToCharArray());
		}
	}

	public struct ParameterNumericString
	{
		private byte tipo;
		private byte id;
		private string valorString;

		public ParameterNumericString(byte nID,string strCadena,BinaryWriter writer)
		{
			tipo=2;
			id=nID;
			valorString=strCadena;
			Serialize(writer);
		}

		public ParameterNumericString(byte nID,string strCadena)
		{
			tipo=2;
			valorString=strCadena;
			id=nID;
		}

		public void Serialize(BinaryWriter writer)
		{
			writer.Write(tipo);
			short tipoparamNombre=1;
			writer.Write(tipoparamNombre);
			writer.Write(id);

			byte[] bytevalorString=Encoding.Default.GetBytes(valorString);
			writer.Write((ushort)bytevalorString.Length);
			writer.Write(bytevalorString);
			//writer.Write((ushort)valorString.ToCharArray().Length);
			//writer.Write(valorString.ToCharArray());
		}
	}

	public struct ParameterNumericNumeric
	{
		private byte tipo;
		private byte id;
		private uint valorNum;

		public ParameterNumericNumeric(byte nID,uint nvalor,BinaryWriter writer)
		{
			tipo=3;
			id=nID;
			valorNum=nvalor;
			Serialize(writer);
		}

		public ParameterNumericNumeric(byte nID,uint nvalor)
		{
			tipo=3;
			id=nID;
			valorNum=nvalor;
		}

		public void Serialize(BinaryWriter writer)
		{
			writer.Write(tipo);
			short tipoparamNombre=1;
			writer.Write(tipoparamNombre);
			writer.Write(id);
			writer.Write(valorNum);
		}
	}

	public struct CReceiveHello
	{
		public byte HashSize;
		public byte[] Hash;
		public uint UserID;
		public ushort UserPort;
		public string UserName;
		public uint Version;
		public uint ServerIP;
		public ushort ServerPort;
		public byte software;

		public CReceiveHello(bool bRespuesta,MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);

			if (bRespuesta)
				HashSize=16;
			else
				HashSize=reader.ReadByte();

			Hash=reader.ReadBytes(HashSize);
			software = (byte)Protocol.Client.eDonkey;

			if ((Hash[5]==14)&&(Hash[14]==111))
			{
				software = (byte)Protocol.Client.eMule;
			}

			UserID=reader.ReadUInt32();
			UserPort=reader.ReadUInt16();
			uint nParametros=reader.ReadUInt32();
			UserName="";
			Version=0;

			for (int i=0;i!=nParametros;i++)
			{
				CParameterReader ParameterReader=new CParameterReader(reader);
				switch( (Protocol.ClientParameter)ParameterReader.id )
				{
					case Protocol.ClientParameter.Name:
						UserName = ParameterReader.valorString;
						break;
					case Protocol.ClientParameter.Version:
						Version = ParameterReader.valorNum;
						break;
					case Protocol.ClientParameter.Port:
						UserPort = (ushort)ParameterReader.valorNum;
						break;           
				}
			}
			ServerIP=reader.ReadUInt32();
			ServerPort=reader.ReadUInt16();

			if (buffer.Length-buffer.Position>=3)
			{
				software  = (byte)Protocol.Client.eDonkeyHybrid;
				uint extra=reader.ReadUInt32();
				if (extra==1262767181)
					software=(byte)Protocol.Client.mlDonkey;
			}

			if (Version > 10000 && Version < 100000)
				Version = Version - (Version/10000)*10000;

			if (Version > 1000)
				Version = Version - (Version/1000)*1000;

			if (Version < 100)
				Version *= 10;

			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}
	}

	internal class CSendHello
	{
		//private byte opcode;
		public CSendHello(bool bRespuesta,MemoryStream buffer,CServer Servidor)
		{
			DonkeyHeader header;
			BinaryWriter writer=new BinaryWriter(buffer);
			if (bRespuesta)
				header=new DonkeyHeader((byte)Protocol.ClientCommand.HelloAnswer,writer);
			else
			{
				header=new DonkeyHeader((byte)Protocol.ClientCommand.Hello,writer);
				writer.Write((byte)CKernel.Preferences.GetByteArray("UserHash").Length);
			}
			writer.Write(CKernel.Preferences.GetByteArray("UserHash"));
			writer.Write(CKernel.Preferences.GetUInt("ID"));
			writer.Write(CKernel.Preferences.GetUShort("TCPPort"));
			uint nParametros=3;
			writer.Write(nParametros);
			ParameterNumericString usuario=new ParameterNumericString((byte)Protocol.ClientParameter.Name,CKernel.Preferences.GetString("UserName"),writer);
			ParameterNumericNumeric version=new ParameterNumericNumeric((byte)Protocol.ClientParameter.Version,Protocol.EDONKEYVERSION,writer); 
			ParameterNumericNumeric port=new ParameterNumericNumeric((byte)Protocol.ClientParameter.Port,(uint)CKernel.Preferences.GetUShort("TCPPort"),writer); 
			//falta enviar la informaci�n del servidor al que estamos conectados
			if (Servidor==null)
			{
				writer.Write((uint)0);
				writer.Write((ushort)0);    
			}
			else
			{
				writer.Write(Servidor.IP);
				writer.Write(Servidor.Port);
			}
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);      
		}
	}

	internal class CFileRequest
	{
		public byte[] FileHash;
		public byte[] Partes;

		public CFileRequest(MemoryStream buffer)
		{
			if (buffer.Length>=16)
			{
				BinaryReader reader=new BinaryReader(buffer);
				FileHash=reader.ReadBytes(16);
				if (buffer.Length>16)
				{
					ushort nChunks=reader.ReadUInt16();
					if (nChunks>0)
					{
						Partes=new byte[nChunks];
						short processedBits=0;
						byte bitArray;
						short i;
						while (processedBits!=nChunks)
						{
							bitArray=reader.ReadByte();
							i=0;
							do //for (i=0;i!=8;i++)
							{
								Partes[processedBits]=(((bitArray>>i)&1)==1) ? (byte)Protocol.ChunkState.Complete : (byte)Protocol.ChunkState.Empty;
								processedBits++;
								i++;
							}
							while ((i!=8)&(processedBits!=nChunks));
						}
					}

				}
				reader.Close();
				buffer.Close();
				buffer=null;
			}
		}

		public CFileRequest(byte[] Hash,byte[] Partes,MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.FileRequest,writer);
			writer.Write(Hash,0,16);
			
			if ((Partes!=null)&&(Partes.Length>0))
			{
				ushort nPartes=(ushort)Partes.Length;
				writer.Write(nPartes);
				if (nPartes>0)
				{
					short bitProcesados=0;
					byte bitArray;
					short i;
					while (bitProcesados!=nPartes)
					{
						bitArray=0;
						i=0;
						do
						{
							if ((Protocol.ChunkState)Partes[bitProcesados]==Protocol.ChunkState.Complete) bitArray |= (byte)(1<<i);
							i++;
							bitProcesados++;
						}
						while ((i!=8)&(bitProcesados!=nPartes));
						writer.Write(bitArray);
					}        
				}
			}
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);              
		}
	}

	internal class CIDFileChange
	{
		public byte[] FileHash;

		public CIDFileChange(MemoryStream buffer)
		{
			if (buffer.Length==16)
			{
				FileHash=new Byte[16];
				buffer.Read(FileHash,0,16);
				buffer.Close();
				buffer=null;
			}
		}

		public CIDFileChange(byte[] Hash,MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.SetRequestFileID,writer);
			writer.Write(Hash,0,16);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);              
		}
	}

	internal class CFileInfo
	{
		public byte[] FileHash;
		public string ClientFileName;

		public CFileInfo(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			//FileHash=new byte[16];
			FileHash=reader.ReadBytes(16);
			ushort LongitudClientFileName;
			LongitudClientFileName=reader.ReadUInt16();
			byte [] buf;//=new byte[longitud];
			buf=reader.ReadBytes(LongitudClientFileName);
			ClientFileName=Encoding.Default.GetString(buf);
			//ClientFileName=new string(reader.ReadChars(LongitudClientFileName));
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}

		public CFileInfo(byte[] in_FileHash,string ClientFileName,MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.FileRequestAnswer,writer);
			writer.Write(in_FileHash,0,16);
			writer.Write((ushort)ClientFileName.ToCharArray().Length);
			writer.Write(ClientFileName.ToCharArray());
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);                        
		}
	}

	internal class CFileStatus
	{
		public byte[] FileHash;
		public ushort nChunks;
		public byte[] Chunks;

		public CFileStatus(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);  
			//FileHash=new byte[16];
			FileHash=reader.ReadBytes(16);
			if (reader.PeekChar()==-1)
				nChunks=0;
			else
				nChunks=reader.ReadUInt16();
			if (nChunks>0)
			{
				Chunks=new byte[nChunks];
				short bitProcesados=0;
				byte bitArray;
				short i;
				while (bitProcesados!=nChunks)
				{
					bitArray=reader.ReadByte();
					i=0;
					do //for (i=0;i!=8;i++)
					{
						Chunks[bitProcesados] = (((bitArray>>i)&1)==1)? (byte)Protocol.ChunkState.Complete : (byte)Protocol.ChunkState.Empty;
						bitProcesados++;
						i++;
					}
					while ((i!=8)&(bitProcesados!=nChunks));
				}
			}
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}

		public CFileStatus(byte[] in_FileHash,byte[] in_Partes,MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.FileState,writer);        
			writer.Write(in_FileHash,0,16);
			if  ((in_Partes==null)||(in_Partes.Length==0)) nChunks=0;
			else nChunks=(ushort)(in_Partes.Length);
			writer.Write(nChunks);
			if (nChunks>0)
			{
				short bitProcesados=0;
				byte bitArray;
				short i;
				while (bitProcesados!=nChunks)
				{
					bitArray=0;
					i=0;
					do
					{
						if ( (Protocol.ChunkState)in_Partes[bitProcesados]==Protocol.ChunkState.Complete )
							bitArray |= (byte)(1<<i);
						i++;
						bitProcesados++;
					}
					while ((i!=8)&(bitProcesados!=nChunks));
					writer.Write(bitArray);
				}        
			}
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);      
		}
	}

	internal class CHashSetRequest
	{
		public CHashSetRequest(byte[] in_FileHash,MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.HashSetRequest,writer);
			writer.Write(in_FileHash,0,16);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);         
		}
	}

	internal class CHashSetResponse
	{
		public CHashSetResponse(MemoryStream buffer,CFile File)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.HashSetAnswer,writer);			
			writer.Write(File.FileHash);
			writer.Write((ushort)File.HashSet.Count);
			foreach (byte[] PartialHash in File.HashSet)
			{
				writer.Write(PartialHash);
			}
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer); 
		}

		public CHashSetResponse(MemoryStream buffer,ref CFile File)
		{
			BinaryReader reader=new BinaryReader(buffer);
			byte[] FileHash;//=new byte[16];
			FileHash=reader.ReadBytes(16);
			if (!CKernel.SameHash(ref FileHash,ref File.FileHash)) return;
			ArrayList NewHashSet=new ArrayList();
			ushort nChunks=reader.ReadUInt16();
			if (nChunks==0)
			{
				NewHashSet.Add(FileHash);
				//Fichero.GetHashSet().Clear();
				//Fichero.SetHashSet(null);
				File.HashSet=NewHashSet;
			}
			else
			{
				byte[] PartialHash;//=new byte[16];
				while (nChunks>0)
				{
					PartialHash=reader.ReadBytes(16);	
					NewHashSet.Add(PartialHash);
					nChunks--;
				}
				byte[] HashSetChecked=CHash.DoHashSetHash(NewHashSet);
				if (CKernel.SameHash(ref HashSetChecked,ref File.FileHash)) 
				{
					//Fichero.GetHashSet().Clear();
					//Fichero.SetHashSet(null);
					File.HashSet=NewHashSet;
				}
			}
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}
	}

	internal class CStartDownload
	{
		public CStartDownload(MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.StartUploadRequest,writer);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);         
		}
	}

	internal class CCancelTransfer
	{
		public CCancelTransfer(MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.CancelTransfer,writer);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);         
		}
	}

	internal class CIDClientChange
	{
		public uint NewID;
		public uint ServerID;

		public CIDClientChange(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			NewID=reader.ReadUInt32();
			ServerID=reader.ReadUInt32();
		}
	}

	internal class CSharedFiles
	{
		public CSharedFiles(MemoryStream buffer,CFilesList fileList)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.AskSharedFilesAnswer,writer);
			writer.Write((uint)fileList.Count);
			lock(fileList)
			{
				foreach (CElement Elemento in fileList.Values)
				{
					writer.Write(Elemento.File.FileHash);
					writer.Write((uint)0);
					writer.Write((ushort)0);
					writer.Write(Elemento.File.FileType);
					ParameterNumericString FileName = new ParameterNumericString((byte)Protocol.FileTag.Name,Elemento.File.FileName,writer);
					ParameterNumericNumeric FileSize = new ParameterNumericNumeric((byte)Protocol.FileTag.Size,Elemento.File.FileSize,writer);
				}
			}
			header.Packetlength = (uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer); 
		}
	}

	internal class CAskSharedFiles
	{
		public CAskSharedFiles(MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.AskSharedFiles,writer);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer); 
		}
	}

	internal class CMuleHello
	{
		public byte VersioneMule;
		public byte VersionEmuleProtocol;
		public byte VersionCompression;
		public byte VersionSourceExchange;
		public byte VersionUDP;
		public byte VersionComments;
		public byte VersionExtendedRequests;
		public uint VersionLphant;
		public uint IDClientCompatible;
		public ushort PortUDP;

		public CMuleHello(MemoryStream buffer,bool isResponse)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header;
			if (isResponse)
				header=new DonkeyHeader((byte)Protocol.ClientCommandExt.eMuleInfoAnswer,writer,Protocol.ProtocolType.eMule);
			else            
				header=new DonkeyHeader((byte)Protocol.ClientCommandExt.eMuleInfo,writer,Protocol.ProtocolType.eMule);
			writer.Write(Protocol.EMULE_VERSION);
			writer.Write(Protocol.EMULE_PROTOCOL_VERSION);
			uint nParameters=8;
			writer.Write(nParameters);
			ParameterNumericNumeric compresion=new ParameterNumericNumeric(Protocol.ET_COMPRESSION,Protocol.EMULE_VERSION_COMPRESION,writer); 
			ParameterNumericNumeric portUDP=new ParameterNumericNumeric(Protocol.ET_UDPPORT,(uint)CKernel.Preferences.GetUShort("UDPPort"),writer); 
			ParameterNumericNumeric VersionUDP=new ParameterNumericNumeric(Protocol.ET_UDPVER,(uint)Protocol.EMULE_VERSION_UDP,writer);
			ParameterNumericNumeric VersionSourceExchange=new ParameterNumericNumeric(Protocol.ET_SOURCEEXCHANGE,(uint)Protocol.EMULE_VERSION_SOURCEEXCHANGE,writer);
			ParameterNumericNumeric VersionComments=new ParameterNumericNumeric(Protocol.ET_COMMENTS,(uint)Protocol.EMULE_VERSION_COMMENTS,writer);
			ParameterNumericNumeric VersionExtendedRequests=new ParameterNumericNumeric(Protocol.ET_EXTENDEDREQUEST,(uint)Protocol.EMULE_VERSION_EXTENDEDREQUEST,writer);
			ParameterNumericNumeric ClientCompatible=new ParameterNumericNumeric(Protocol.ET_COMPATIBLECLIENT,(byte)Protocol.Client.eLePhant,writer);
			ParameterNumericNumeric VersionLphant=new ParameterNumericNumeric(Protocol.ET_ELEPHANTVERSION,Protocol.ELEPHANT_VERSION,writer);

			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);             
		}

		public CMuleHello(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			VersioneMule=reader.ReadByte();
			if (VersioneMule==0x2B) VersioneMule=0x22;
			VersionEmuleProtocol=reader.ReadByte();
			if (VersionEmuleProtocol==Protocol.EMULE_PROTOCOL_VERSION) 
			{
				if(VersioneMule < 0x25 && VersioneMule > 0x22)
					VersionUDP = 1;

				if(VersioneMule < 0x25 && VersioneMule > 0x21)
					VersionSourceExchange = 1;

				if(VersioneMule==0x24)
					VersionComments = 1;
			}
			PortUDP=0;
			VersionCompression=0;
			VersionSourceExchange=1;
			uint nParametros=reader.ReadUInt32();
			if (VersionEmuleProtocol!=Protocol.EMULE_PROTOCOL_VERSION) return;
			for (int i=0;i!=nParametros;i++)
			{
				CParameterReader ParameterReader=new CParameterReader(reader);
				switch(ParameterReader.id)
				{
					case Protocol.ET_COMPRESSION:
						VersionCompression = (byte)ParameterReader.valorNum;
						break;
					case Protocol.ET_UDPPORT:
						PortUDP = (ushort)ParameterReader.valorNum;
						break;
					case Protocol.ET_UDPVER:
						VersionUDP= (byte)ParameterReader.valorNum;
						break;
					case Protocol.ET_SOURCEEXCHANGE:
						VersionSourceExchange=(byte)ParameterReader.valorNum;
						break;
					case Protocol.ET_COMMENTS:
						VersionComments = (byte)ParameterReader.valorNum;
						break;
					case Protocol.ET_EXTENDEDREQUEST:
						VersionExtendedRequests = (byte)ParameterReader.valorNum;
						break;
					case Protocol.ET_COMPATIBLECLIENT:
						IDClientCompatible = ParameterReader.valorNum;
						break;
					case Protocol.ET_ELEPHANTVERSION:
						VersionLphant = ParameterReader.valorNum;
						break;
				}
			}
			if (VersionCompression==0)
			{
				VersionSourceExchange = 0;
				VersionExtendedRequests = 0;
				VersionComments = 0;
				PortUDP = 0;
			}
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}
	}

	internal class CStartUpload
	{
		public CStartUpload(MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.AcceptUploadRequest,writer);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);         
		}
	}

	internal class CFileBlock
	{
		public uint start;
		public uint end;
		public byte[] FileHash;
		public byte[] buffer;
		public uint position;
		public bool compressed;

		public CFileBlock()
		{
			start=0;
			end=0;
			FileHash=null;
			buffer=null;
			position=0;
			compressed=false;
		}
	}

	internal class CFileBlockRequest
	{
		public ArrayList RequestedBlocks;

		public CFileBlockRequest(MemoryStream buffer)
		{
			byte[] FileHash;
			if (buffer.Length!=40) return;
			CFileBlock block1=new CFileBlock();
			CFileBlock block2=new CFileBlock();
			CFileBlock block3=new CFileBlock();
			RequestedBlocks=new ArrayList();
			BinaryReader reader=new BinaryReader(buffer);
			//FileHash=new Byte[16];
			FileHash=reader.ReadBytes(16);
			block1.start=reader.ReadUInt32();
			block2.start=reader.ReadUInt32();
			block3.start=reader.ReadUInt32();
			block1.end=reader.ReadUInt32();
			block2.end=reader.ReadUInt32();
			block3.end=reader.ReadUInt32();
			block1.FileHash=FileHash;
			block2.FileHash=FileHash;
			block3.FileHash=FileHash;
			if (block1.end>block1.start) RequestedBlocks.Add(block1);
			if (block2.end>block2.start) RequestedBlocks.Add(block2);
			if (block3.end>block3.start) RequestedBlocks.Add(block3);
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}

		public CFileBlockRequest(MemoryStream buffer,byte[] FileHash,ref CFileBlock block1,ref CFileBlock block2,ref CFileBlock block3)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.RequestParts,writer);
			writer.Write(FileHash);
			writer.Write(block1.start);
			writer.Write(block2.start);
			writer.Write(block3.start);
			writer.Write(block1.end+1);
			writer.Write(block2.end+1);
			writer.Write(block3.end+1);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer); 
		}
	}

	internal class CSendBlock
	{
		public CSendBlock(MemoryStream data,uint start,uint end,byte[] FileHash,ref ArrayList UploadDataPackets)
		{
			MemoryStream buffer;
			uint size;
			BinaryReader reader=new BinaryReader(data);
			BinaryWriter writer;
			//byte[] aux_buffer;
			while (start!=end)
			{
				buffer=new MemoryStream();
				writer=new BinaryWriter(buffer);
				DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.SendingPart,writer);
				writer.Write(FileHash);
				if (end-start>10240) size=10240;
				else size=end-start;
				writer.Write(start);
				writer.Write(start+size);
				//aux_buffer=reader.ReadBytes((int)size);
				//writer.Write(aux_buffer);
				writer.Write(reader.ReadBytes((int)size));

				start+=size;
				header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
				writer.Seek(0,SeekOrigin.Begin);
				header.Serialize(writer);  
				UploadDataPackets.Add(buffer);
				writer=null;
				buffer=null;
			}
			reader.Close();
			data.Close();
			data=null;
			reader=null;
		}
	}

	internal class CCompressedPacket
	{
		public CCompressedPacket(ref MemoryStream packet)
		{
			byte[] compressedBuffer=null;
			
			BinaryReader reader=new BinaryReader(packet);
			MemoryStream compressedPacket=new MemoryStream();
			packet.Seek(0,SeekOrigin.Begin);
			BinaryWriter writer=new BinaryWriter(compressedPacket);
			
			writer.Write(reader.ReadBytes(5));
			byte opcode=reader.ReadByte();
			writer.Write(opcode);
			byte[] uncompressedBuffer=reader.ReadBytes((int)packet.Length-6);
			int compressedsize=CCompressedBlockSend.ComprimirBuffer(uncompressedBuffer,ref compressedBuffer);
			if (compressedsize+6>=packet.Length)
				return;
			writer.Write(compressedBuffer);
			compressedPacket.Seek(0,SeekOrigin.Begin);
			
			DonkeyHeader header=new DonkeyHeader(opcode,writer,Protocol.ProtocolType.Packet);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer); 
			packet.Close();
			packet=compressedPacket;
		}
	}

	internal class CCompressedBlockSend
	{
		//cualquiera de las dos funciones de comprimir causa un leak de memoria enorme
		public static int ComprimirBuffer(byte[] in_buffer,ref byte[] out_buffer)
		{
			out_buffer=new byte[in_buffer.Length+300];
			Deflater compresor=new Deflater();
			compresor.SetInput(in_buffer);
			compresor.Flush();
			compresor.Finish();
			int compressedsize=compresor.Deflate(out_buffer,0,(int)(in_buffer.Length)+300);
			compresor=null;
			return compressedsize;
		}

		public static int ComprimirBuffer2(byte[] in_buffer,ref byte[] out_buffer)
		{
			try
			{
				MemoryStream ms = new MemoryStream();
				Stream s = new DeflaterOutputStream(ms);
				s.Write(in_buffer,0,in_buffer.Length);
				s.Close();
				out_buffer = (byte[])ms.ToArray();
				return out_buffer.Length;
			}
			catch
			{
				return in_buffer.Length;
			}
		}

		public CCompressedBlockSend(byte[] data,uint start,uint end,byte[] FileHash,ref ArrayList UploadDataPackets)
		{
			//			byte[] buffercomp=new byte[final-inicio+300];
			//			Deflater descompresor=new Deflater();
			//			descompresor.SetInput(datos);
			//			descompresor.Flush();
			//			int compressedsize=descompresor.Deflate(buffercomp,0,(int)(final-inicio)+300);
			//			descompresor.Finish();
			byte[] buffercomp=null;
			int compressedsize=ComprimirBuffer(data,ref buffercomp);
			if (compressedsize>=end-start)
			{
				buffercomp=null;
				MemoryStream strmdatos=new MemoryStream(data);
				CSendBlock EnvioBloque=new CSendBlock(strmdatos,start,end,FileHash,ref UploadDataPackets);
				return;
			}
			Debug.Write("Compressed comp:"+compressedsize.ToString()+" win: "+Convert.ToString(end-start-compressedsize)+"\n");
			MemoryStream datosComp=new MemoryStream(buffercomp);
			end=start+(uint)compressedsize;
			MemoryStream buffer;
			uint size;
			BinaryReader reader=new BinaryReader(datosComp);
			BinaryWriter writer;
			byte[] aux_buffer;
			while (start!=end)
			{
				buffer=new MemoryStream();
				writer=new BinaryWriter(buffer);
				DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommandExt.CompressedPart,writer,Protocol.ProtocolType.eMule);
				writer.Write(FileHash);
				if (end-start>10240) size=10240;
				else size=end-start;
				writer.Write(start);
				writer.Write(compressedsize);
				aux_buffer=reader.ReadBytes((int)size);
				writer.Write(aux_buffer);

				start+=size;
				header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
				writer.Seek(0,SeekOrigin.Begin);
				header.Serialize(writer);  
				UploadDataPackets.Add(buffer);
				writer=null;
				buffer=null;
			}
			reader.Close();
			datosComp.Close();
			datosComp=null;
			reader=null;						
		}
	}

	internal class CReceivedBlock
	{
		public uint Start;
		public uint End;
		public byte[] FileHash;
		public byte[] Data;
		public CReceivedBlock(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			FileHash=reader.ReadBytes(16);
			Start=reader.ReadUInt32();
			End=reader.ReadUInt32();
			Data=reader.ReadBytes((int)(End-Start+1));
			reader.Close();
			buffer.Close();
			buffer=null;
		}
	}

	internal class CNoFile
	{
		public CNoFile(MemoryStream buffer,byte[] FileHash)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.FileRequestAnswerNoFile,writer);
			writer.Write(FileHash);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);         
		}
	}

	internal class CReceivedCompressedBlock
	{
		public uint Start;
		public uint End;
		public byte[] FileHash;
		public byte[] Data;

		public CReceivedCompressedBlock(ref MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			FileHash=reader.ReadBytes(16);
			Start=reader.ReadUInt32();
			End=reader.ReadUInt32()+Start;
			Data=reader.ReadBytes((int)buffer.Length-(int)buffer.Position+1);
			reader.Close();
			buffer.Close();
			buffer=null;
		}

		public static int Uncompress(ref byte[] Data)
		{
			int maxsize=Data.Length*10+300;
			if (maxsize>50000) maxsize=50000;
			byte[] outputData=new byte[maxsize];
			MemoryStream dataStream=new MemoryStream(Data);
			InflaterInputStream inflater=new InflaterInputStream(dataStream);
			//int res=descompresor.Read(packetsalida,0,packetsalida.Length);
			//if (res>0)
			int res;
			int resTotal=0;
			MemoryStream uncompressedStream=new MemoryStream();
			do
			{
				if (inflater.Position==Data.Length) res=0;
				else
					try
					{
						res=inflater.Read(outputData,0,outputData.Length);
					}
					catch 
					{
						res=0;
					}
				if (res>0)
				{
					uncompressedStream.Write(outputData,0,res);
				}
				resTotal+=res;
			}
			while (res>0);
			if (resTotal==0)
			{
				return 0;
			}
			else
			{
				inflater.Close();
				inflater=null;
				dataStream.Close();
				dataStream=null;
				Data=null;
				Data=new byte[resTotal];
				uncompressedStream.Seek(0,SeekOrigin.Begin);
				uncompressedStream.Read(Data,0,resTotal);
				uncompressedStream.Close();
				uncompressedStream=null;
				return resTotal;
			}
		}
	}

	internal class CMuleQR
	{
		ushort QR;

		public CMuleQR(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			QR=reader.ReadUInt16();
		}

		public CMuleQR(MemoryStream buffer,ushort QR)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header;
			header=new DonkeyHeader((byte)Protocol.ClientCommandExt.QueueRanking,writer,Protocol.ProtocolType.eMule);
			writer.Write(QR);
			byte[] empty=new byte[10];
			writer.Write(empty);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);   
		}
	}

	internal class CServerHello
	{
		public CServerHello(MemoryStream buffer)
		{
			DonkeyHeader header;
			BinaryWriter writer=new BinaryWriter(buffer);
			header=new DonkeyHeader((byte)Protocol.ServerCommand.LoginRequest,writer);
			writer.Write(CKernel.Preferences.GetByteArray("UserHash"));
			writer.Write(CKernel.Preferences.GetUInt("ID"));
			writer.Write(CKernel.Preferences.GetUShort("TCPPort"));
			uint nParameters=4;
			writer.Write(nParameters);
			ParameterNumericString user=new ParameterNumericString((byte)Protocol.ClientParameter.Name,CKernel.Preferences.GetString("UserName"),writer);
			ParameterNumericNumeric version=new ParameterNumericNumeric((byte)Protocol.ClientParameter.Version,Protocol.EDONKEYVERSION,writer); 
			ParameterNumericNumeric port=new ParameterNumericNumeric((byte)Protocol.ClientParameter.Port,(uint)CKernel.Preferences.GetUShort("TCPPort"),writer); 
			ParameterNumericNumeric compression=new ParameterNumericNumeric((byte)Protocol.ClientParameter.Compression,1,writer); 
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);      
		}
	}

	/// <summary>
	/// CServerStatus process the server status send by CServer.
	/// </summary>
	internal class CServerStatus
	{
		public uint Users;
		public uint Files;

		public CServerStatus(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			Users=reader.ReadUInt32();
			Files=reader.ReadUInt32();
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}
	}

	/// <summary>
	/// CServerDescription process description send by CServer.
	/// </summary>
	internal class CServerDescription
	{
		public string Name;
		public string Description;

		public CServerDescription(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			reader.ReadBytes(30);
			short length;
			length=reader.ReadInt16();
			Name=Encoding.ASCII.GetString(reader.ReadBytes(length));
			reader.ReadBytes(4);
			length=reader.ReadInt16();
			Description=Encoding.ASCII.GetString(reader.ReadBytes(length));
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}
	}

	/// <summary>
	/// CServerServerList process the serverlist send by/to CServer.
	/// </summary>
	internal class CServerServerList
	{
		public byte NewServers;

		public CServerServerList(MemoryStream buffer)
		{
			DonkeyHeader header;
			BinaryWriter writer=new BinaryWriter(buffer);
			header=new DonkeyHeader((byte)Protocol.ServerCommand.GetServerList,writer);				
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);
		}

		public CServerServerList(MemoryStream buffer,CServersList ServerList)
		{
			BinaryReader reader=new BinaryReader(buffer);
			byte nServers=reader.ReadByte();
			uint IP;
			ushort port;
			NewServers=0;
			try
			{
				for (int i=0;i!=nServers;i++)
				{
					IP=reader.ReadUInt32();
					port=reader.ReadUInt16();
					if (ServerList.AddServer(IP,port)!=null) NewServers++;
				}
			}
			catch {}
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}
	}

	internal class CServerPublishFiles
	{
		public CServerPublishFiles(MemoryStream buffer,CFilesList FilesList)
		{
			DonkeyHeader header;
			BinaryWriter writer=new BinaryWriter(buffer);
			header=new DonkeyHeader((byte)Protocol.ServerCommand.OfferFiles,writer);
			writer.Write((uint)FilesList.Count);
			uint nfiles=0;
			foreach (CElement element in FilesList.Values)
			{
				if (!element.File.Empty)
				{
					writer.Write(element.File.FileHash);
					writer.Write((int)0);
					writer.Write((short)0);//-->TODO why?
					writer.Write(element.File.FileType);
					ParameterNumericString name=new ParameterNumericString((byte)Protocol.FileTag.Name,element.File.FileName,writer);
					ParameterNumericNumeric size=new ParameterNumericNumeric((byte)Protocol.FileTag.Size,element.File.FileSize,writer);
					nfiles++;
				}
			}
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);
			writer.Write(nfiles);
			CLog.Log(Types.Constants.Log.Info,"FIL_PUBLISHED",nfiles);
		}
	}

	class CServerAskSources
	{
		public CServerAskSources(byte[] FileHash,MemoryStream buffer)
		{
			DonkeyHeader header;
			BinaryWriter writer=new BinaryWriter(buffer);
			writer.Seek(0,SeekOrigin.End);
			header=new DonkeyHeader((byte)Protocol.ServerCommand.GetSources/*,writer*/);
			header.Packetlength=17;
			header.Serialize(writer);
			writer.Write(FileHash);
//			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
//			writer.Seek(0,SeekOrigin.Begin);
//			header.Serialize(writer);
		}
	}

	class CServerRequestCallback
	{
		public CServerRequestCallback(uint ID,MemoryStream buffer)
		{
			DonkeyHeader header;
			BinaryWriter writer=new BinaryWriter(buffer);
			header=new DonkeyHeader((byte)Protocol.ServerCommand.CallBackRequest,writer);
			writer.Write(ID);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);				
		}
	}

	class CServerRequestCallBackUDP
	{
		public CServerRequestCallBackUDP(uint ID,uint IP,ushort Port,MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			writer.Write((byte)Protocol.Header.eDonkey);
			writer.Write((byte)Protocol.ServerCommandUDP.GlobalCallBackRequest);
			writer.Write(IP);
			writer.Write(Port);
			writer.Write(ID);
		}
	}

	class CServerAskSourcesUDP
	{
		public CServerAskSourcesUDP(byte[] FileHash,MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			writer.Write((byte)Protocol.Header.eDonkey);
			writer.Write((byte)Protocol.ServerCommandUDP.GlobalGetSources);
			writer.Write(FileHash);
		}

		public CServerAskSourcesUDP(ArrayList FilesHash,MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			writer.Write((byte)Protocol.Header.eDonkey);
			writer.Write((byte)Protocol.ServerCommandUDP.GlobalGetSources);
			foreach (byte[] fileHash in FilesHash)
			{
				writer.Write(fileHash);
			}
		}
	}

	class CServerRequestPingUDP
	{	
		public uint rndvalping;

		public CServerRequestPingUDP(MemoryStream buffer)
		{
			BinaryWriter writer = new BinaryWriter(buffer);
			writer.Write((byte)Protocol.Header.eDonkey);
			writer.Write((byte)Protocol.ServerCommandUDP.GlobalStateRequest);
			Random rnd=new Random();
			rndvalping=(uint)0x55AA0000 + (ushort)rnd.Next();
			writer.Write(rndvalping);
		}
	}

	class CServerPingResponseUDP
	{
		public uint rndretval;
		public uint nUsers;
		public uint nfiles;
		public uint nMaxUsers;

		public CServerPingResponseUDP(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			rndretval=reader.ReadUInt32();
			nUsers=reader.ReadUInt32();
			nfiles=reader.ReadUInt32();
			if (buffer.Length>=16)
				nMaxUsers=reader.ReadUInt32();
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}
	}

	class CQueueFullUDP
	{
		public CQueueFullUDP(MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			writer.Write((byte)Protocol.ProtocolType.eMule);
			writer.Write((byte)Protocol.ClientCommandExtUDP.QueueFull);
		}
	}

	class CFileNotFoundUDP
	{
		public CFileNotFoundUDP(MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			writer.Write((byte)Protocol.ProtocolType.eMule);
			writer.Write((byte)Protocol.ClientCommandExtUDP.FileNotFound);
		}
	}

	class CQueuePositionUDP
	{
		public CQueuePositionUDP(MemoryStream buffer,ushort queuePosition)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			writer.Write((byte)Protocol.ProtocolType.eMule);
			writer.Write((byte)Protocol.ClientCommandExtUDP.ReaskAck);
			writer.Write(queuePosition);
		}
	}

	class CFileReaskUDP
	{
		public CFileReaskUDP(MemoryStream buffer,byte[] FileHash)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			writer.Write((byte)Protocol.ProtocolType.eMule);
			writer.Write((byte)Protocol.ClientCommandExtUDP.ReaskFilePing);
			writer.Write(FileHash);
		}
	}

	class CServerRequestStatusUDP
	{
		public CServerRequestStatusUDP(MemoryStream buffer)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			writer.Write((byte)Protocol.ProtocolType.eDonkey);
			writer.Write((byte)Protocol.ServerCommandUDP.DescriptionRequest);
		}
	}

	class CServerResponseStatusUDP
	{
		public string name;
		public string description;
		public CServerResponseStatusUDP(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			byte [] buf;
			ushort length=reader.ReadUInt16();
			buf=reader.ReadBytes(length);
			name=Encoding.Default.GetString(buf);
			length=reader.ReadUInt16();
			buf=reader.ReadBytes(length);
			description=Encoding.Default.GetString(buf);
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}
	}

	class CServerProcessSources
	{
		public CServerProcessSources(MemoryStream buffer,uint ServerIP,ushort ServerPort)
		{
			byte[] FileHash;
			uint IP;
			ushort Port;
			byte nSources;
			bool moreFiles=true;
			BinaryReader reader=new BinaryReader(buffer);
			do
			{
				FileHash=reader.ReadBytes(16);
				nSources=reader.ReadByte();
				Debug.WriteLine("Received "+nSources.ToString()+" for "+CKernel.HashToString(FileHash));
				while (nSources>0)
				{
					IP=reader.ReadUInt32();
					Port=reader.ReadUInt16();
					nSources--;
					CKernel.ClientsList.AddClientToFile(IP,Port,ServerIP,ServerPort,FileHash);
				}
				if ((reader.PeekChar()!=0)&&(reader.PeekChar()!=-1)) 
				{
					if ((Protocol.ProtocolType)reader.ReadByte() != Protocol.ProtocolType.eDonkey) moreFiles=false;
					if ((reader.PeekChar()==-1)||(reader.ReadByte()!= (byte)Protocol.ServerCommandUDP.GlobalFoundSources))
						moreFiles = false;
				}
				else moreFiles = false;
			}
			while (moreFiles);
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}
	}

	class CServerRequestSearch
	{
		const byte typeNemonic1=0x03;
		const short typeNemonic2=0x0001;
		const uint extensionNemonic= 0x00040001;
		const uint avaibilityNemonic=0x15000101;
		const uint minNemonic=0x02000101;
		const uint maxNemonic=0x02000102;
		const byte stringParameter=1;
		const byte typeParameter=2;
		const byte numericParameter=3;
		const short andParameter=0x0000;
		const short orParameter=0x0100;

		public CServerRequestSearch(MemoryStream buffer,string searchString,bool matchAnyWords,string type,uint maxSize,uint minSize,uint avaibility,bool esUDP)
		{
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ServerCommand.SearchRequest);
			BinaryWriter writer=new BinaryWriter(buffer);
			if (esUDP)
			{
				writer.Write((byte)Protocol.Header.eDonkey);
				//writer.Write((byte)Protocol.ServerCommandsUDP.GlobalSearchRequest);
				writer.Write((byte)Protocol.ServerCommandUDP.GlobalSearchRequest2);
			}
			else
				header.Serialize(writer);

			if (type=="Any") type="";
			//header
			int parametercount=0; //must be written parametercount-1 parmeter headers

			if ( searchString.Length>0)
			{
				parametercount++;
				if (parametercount>1)
					writer.Write(andParameter);
			}

			if (type.Length>0)
			{
				parametercount++;
				if (parametercount>1)
					writer.Write(andParameter);
			}
			  
			if (minSize>0)
			{
				parametercount++;
				if (parametercount>1)
					writer.Write(andParameter);
			}
		        
			if (maxSize>0)
			{
				parametercount++;
				if (parametercount>1)
					writer.Write(andParameter);
			}
		        
			if (avaibility>0)
			{
				parametercount++;
				if (parametercount>1)
					writer.Write(andParameter);
			}
		        
			//				if (extension.GetLength()>0)
			//				{
			//				parametercount++;
			//				if (parametercount>1)
			//					writer.Write(andParameter);
			//				}
			//body
			if (searchString.Length>0) //search a string
			{
				writer.Write(stringParameter); //write the parameter type
				byte[] searchbyte=Encoding.Default.GetBytes(searchString);
				writer.Write((ushort)searchbyte.Length);
				writer.Write(searchbyte);

			}

			if (type.Length>0)
			{
				writer.Write(typeParameter); //write the parameter type
				byte[] searchbyte=Encoding.Default.GetBytes(type);
				writer.Write((ushort)searchbyte.Length);
				writer.Write(searchbyte);
				writer.Write(typeNemonic2);
				writer.Write(typeNemonic1);
			}

			if (minSize>0)
			{
				writer.Write(numericParameter); //write the parameter type
				writer.Write(minSize);		   //write the parameter
				writer.Write(minNemonic);    //nemonic for this kind of parameter
			}

			if (maxSize>0)
			{
				writer.Write(numericParameter); //write the parameter type
				writer.Write(maxSize);		   //write the parameter
				writer.Write(maxNemonic);    //nemonic for this kind of parameter
			}

			if (avaibility>0)
			{
				writer.Write(numericParameter); //write the parameter type
				writer.Write(avaibility);    //write the parameter
				writer.Write(avaibilityNemonic);  //nemonic for this kind of parameter
			}

			//				if (extension.GetLength()>0)
			//				{
			//					data.Write(&stringParameter,1); //write the parameter type
			//					nSize=extension.GetLength(); 
			//					data.Write(&nSize,2);   //write the length
			//					formatC=extension.GetBuffer(); 
			//					data.Write(formatC,nSize); //write parameter
			//					data.Write(&extensionNemonic,3); //nemonic for this kind of parameter (only 3 bytes!!)
			//				}


			if (!esUDP)
			{
				header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
				writer.Seek(0,SeekOrigin.Begin);
				header.Serialize(writer);				
			}
		}
	}

	class CServerCallbackResponse
	{
		public uint IP;
		public ushort Port;
		public CServerCallbackResponse(MemoryStream buffer)
		{
			if (buffer.Length!=6) return;
			BinaryReader reader=new BinaryReader(buffer);
			IP=reader.ReadUInt32();
			Port=reader.ReadUInt16();
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}
	}

	class CServerSearchResults
	{
		public CServerSearchResults(MemoryStream buffer,CSearcher search,bool esUDP)
		{
			BinaryReader reader=new BinaryReader(buffer);
			if (!esUDP)
			{
				uint nResultados=reader.ReadUInt32();
				for (uint i=0;i<nResultados;i++)
				{
					m_ExtractResult(reader,search);
				}
				search.OnTCPSearchEnded();
			}
			else
			{
				m_ExtractResult(reader,search);
				while ((reader.PeekChar()!=0)&&(reader.PeekChar()!=-1)) 
				{
					Debug.WriteLine("MoreUDP results in one packet");
					if ((Protocol.ProtocolType)reader.ReadByte() != Protocol.ProtocolType.eDonkey) break;
					if ((reader.PeekChar()==-1)||(reader.ReadByte() != (byte)Protocol.ServerCommandUDP.GlobalSearchResult))
						break;
					m_ExtractResult(reader,search);
				}
			}
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;				
		}

		private uint m_ExtractResult(BinaryReader reader,CSearcher search)
		{
			CParameterReader parameterReader;
			byte[] HashEncontrado = reader.ReadBytes(16);
			uint IP = reader.ReadUInt32();
			ushort port = reader.ReadUInt16();
			uint nParametros = reader.ReadUInt32();
			string fileName = "?";
			uint fileSize = 0;
			uint nSources = 1;
			string codec="";
			uint bitrate=0;
			string length="";
			for (uint param = 0; param != nParametros; param++)
			{
				parameterReader = new CParameterReader(reader);
				switch( (Protocol.FileTag)parameterReader.id )
				{
					case Protocol.FileTag.Name:
						fileName = parameterReader.valorString;
						break;
					case Protocol.FileTag.Size:
						fileSize = parameterReader.valorNum;
						break;
					case Protocol.FileTag.Sources:
						nSources = parameterReader.valorNum;
						break;
					default:
						if (parameterReader.nombreParam==Protocol.FileExtraTags.codec.ToString())
							codec=parameterReader.valorString;
						else if (parameterReader.nombreParam==Protocol.FileExtraTags.length.ToString())
							length=parameterReader.valorString;
						else if (parameterReader.nombreParam==Protocol.FileExtraTags.bitrate.ToString())
							bitrate=parameterReader.valorNum;
						Debug.WriteLine(parameterReader.id+" name: "+parameterReader.nombreParam+" valString:"+parameterReader.valorString+" valNum: "+parameterReader.valorNum);
						break;
				}
			}
			search.AddFileFound(HashEncontrado,fileName,fileSize,nSources,codec,length,bitrate);
			return nSources;
		}
	}

	public struct stDatosFuente
	{
		public uint IP;
		public ushort Port;
		public uint ServerIP;
		public ushort ServerPort;
	}

	internal class CRequestSourceExchange
	{
		public byte[] FileHash;

		public CRequestSourceExchange(MemoryStream buffer,byte[] FileHash)
		{
			BinaryWriter writer = new BinaryWriter(buffer);
			DonkeyHeader header = new DonkeyHeader((byte)Protocol.ClientCommandExt.SourcesRequest,writer,Protocol.ProtocolType.eMule);
			writer.Write(FileHash);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);     
		}

		public CRequestSourceExchange(MemoryStream buffer)
		{
			BinaryReader reader = new BinaryReader(buffer);
			FileHash = reader.ReadBytes(16);
			reader.Close();
			buffer.Close();
			reader = null;
			buffer = null;			
		}
	}

	internal class CSourceExchangeResponse
	{
		public byte[] FileHash;
		public ushort nSources;
		public stDatosFuente[] Sources;

		public CSourceExchangeResponse(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			FileHash=reader.ReadBytes(16);
			nSources=reader.ReadUInt16();
			Sources=new stDatosFuente[nSources];
			for (int i=0; i!=nSources; i++)
			{
				Sources[i].IP=reader.ReadUInt32();
				Sources[i].Port=reader.ReadUInt16();
				Sources[i].ServerIP=reader.ReadUInt32();
				Sources[i].ServerPort=reader.ReadUInt16();
			}
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}

		public CSourceExchangeResponse(MemoryStream buffer,byte[] FileHash,uint RequesterID,ushort RequesterPort)
		{
			Hashtable IPList=new Hashtable();
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommandExt.SourcesResult,writer,Protocol.ProtocolType.eMule);
			CElement Element=(CElement)CKernel.FilesList[FileHash];
			nSources=0;
			writer.Write(FileHash);
			writer.Write(nSources);
			if ((Element!=null)&&(Element.SourcesList!=null))
			{
				lock(Element.SourcesList.SyncRoot())
				{
					foreach (CClient Client in Element.SourcesList)
					{
						if ((Client.DownloadState != Protocol.DownloadState.None)&&(Client.UserID>Protocol.LowIDLimit))
						{
							IPList[((ulong)Client.UserID << 16) + Client.Port]=((ulong)Client.ServerIP<<16) + Client.ServerPort;
							nSources++;
						}
						if (nSources>=200) break;
					}
				}
				int i=0;
				CClient QueueClient;
				while (i<CKernel.Queue.Count)
				{
					QueueClient=(CClient)CKernel.Queue[i];
					if ((QueueClient.UploadElement==Element)&&(QueueClient.UserID > Protocol.LowIDLimit)&&(QueueClient.DownloadState==Protocol.DownloadState.OnQueue))
					{
						IPList[((ulong)QueueClient.UserID<<16)+QueueClient.Port]=((ulong)QueueClient.ServerIP<<16)+QueueClient.ServerPort;
						nSources++;
					}
					if (nSources>=200) break;
					i++;
				}

			}	
			//do not send oursef
			IPList.Remove(((ulong)CKernel.Preferences.GetUInt("ID")<<16)+CKernel.Preferences.GetUShort("TCPPort"));
			//do not send himself
			IPList.Remove(((ulong)RequesterID<<16)+RequesterPort);
			foreach (ulong ipPort in IPList.Keys)
			{
				uint IP=(uint)(ipPort>>16);
				ushort Port=(ushort)(ipPort&0x00000000FFFF);
				//ushort Port=(ushort)(ipPort-((ulong)IP<<16));
				
				ulong ipServerPort=(ulong)IPList[ipPort];
				uint ServerIP=(uint)(ipServerPort>>16);
				ushort ServerPort=(ushort)(ipServerPort&0x00000000FFFF);
				
				writer.Write(IP);
				writer.Write(Port);
				writer.Write(ServerIP);
				writer.Write(ServerPort);
			}

			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);
			writer.Seek(16,SeekOrigin.Current);
			writer.Write((ushort)IPList.Keys.Count);
		}
	}

	internal class CComment
	{
		public byte rating;
		public string comment;

		public CComment(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			rating=reader.ReadByte();
			int length=reader.ReadInt32();
			if (length>128) length=128;
			if (length==0) comment="";
			else
			{
				byte[] buf=reader.ReadBytes(length);
				comment=Encoding.Default.GetString(buf);
			}
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}

		public CComment(MemoryStream buffer,byte rating,string comment)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommandExt.FileDescription,writer,Protocol.ProtocolType.eMule);
			writer.Write(rating);
			if (comment.Length>128) comment=comment.Substring(0,128);
			byte[] byteStringValue=Encoding.Default.GetBytes(comment);
			writer.Write((uint)byteStringValue.Length);
			writer.Write(byteStringValue);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);
		}
	}

	internal class CClientMessage
	{
		public string Message;

		public CClientMessage(MemoryStream buffer)
		{
			BinaryReader reader=new BinaryReader(buffer);
			ushort length=reader.ReadUInt16();
			if (length>128) length=128;
			if (length==0) Message="";
			else
			{
				byte[] buf=reader.ReadBytes(length);
				Message=Encoding.Default.GetString(buf);
			}
			reader.Close();
			buffer.Close();
			reader=null;
			buffer=null;
		}

		public CClientMessage(MemoryStream buffer,string message)
		{
			BinaryWriter writer=new BinaryWriter(buffer);
			DonkeyHeader header=new DonkeyHeader((byte)Protocol.ClientCommand.Message,writer,Protocol.ProtocolType.eDonkey);
			if (message.Length>128) Message=message.Substring(0,128);
			byte[] byteStringValue=Encoding.Default.GetBytes(message);
			writer.Write((ushort)byteStringValue.Length);
			writer.Write(byteStringValue);
			header.Packetlength=(uint)writer.BaseStream.Length-header.Packetlength+1;
			writer.Seek(0,SeekOrigin.Begin);
			header.Serialize(writer);
		}
	}
}