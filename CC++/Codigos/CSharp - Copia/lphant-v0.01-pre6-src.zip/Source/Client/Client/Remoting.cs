#region Copyright (c)2003 Juanjo < http://lphant.sourceforge.net >
/*
* This file is part of eLePhant
* Copyright (C)2003 Juanjo < j_u_a_n_j_o@users.sourceforge.net / http://lphant.sourceforge.net >
* 
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either
* version 2 of the License, or (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#endregion

using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using eLePhant.eDonkey;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Collections;

namespace eLePhant.Client
{
	/// <summary>
	/// Descripci�n breve de edonkeyCRemoto.
	/// </summary>
	public class CedonkeyCRemoto
	{
		private TcpChannel canalCeLephant;
		private int puertos=4670;
		public CInterfaceGateway  interfazremota;		
		private Hashtable props ;
		public CedonkeyCRemoto()
		{	
			if (ChannelServices.GetChannel("eLePhantClient")==null)
			{
				props = new Hashtable();
				props.Add("name","eLePhantClient");
				props.Add("priority","10");
				props.Add("port",0);
				props.Add("supressChannelData",true);
				props.Add("useIpAddress",true);
				props.Add("rejectRemoteRequests",false);			
				BinaryClientFormatterSinkProvider provider = new BinaryClientFormatterSinkProvider();	
				canalCeLephant = new TcpChannel(props, provider,null);
				ChannelServices.RegisterChannel(canalCeLephant);
			}
		}
		public bool Connect(string IP/*,int puertol,*/,string clave,int puertor)
		{
			if (puertor!=0)
				puertos=puertor;
			System.Security.Cryptography.MD5 cripto=System.Security.Cryptography.MD5.Create();
//			byte [] c=null;
			bool valor=false;
			interfazremota = (CInterfaceGateway) Activator.GetObject(typeof(eLePhant.eDonkey.CInterfaceGateway),
				"tcp://" + IP + ":" + puertos + "/InterfazRemota");
			
			if (interfazremota == null)
				Debug.Write("Can not find lphant server");
			else 
			{	
				try
				{
					valor = interfazremota.CheckPw(clave);
				}
				catch
				{
					Debug.Write("\nCan not find lphant server\n");
				}
//				c = new byte[clave.Length];
//				for (int i=0;i<clave.Length;i++) c[i]=System.Convert.ToByte(clave[i]);
//				cripto.ComputeHash(c);					
//				try
//				{
//					valor = interfazremota.CheckPw( cripto.Hash );						
//				}
//				catch
//				{
//					Debug.Write("\nCan not find lphant server\n");
//				}
			}
			return valor;
		}
		~CedonkeyCRemoto()
		{
			ChannelServices.UnregisterChannel(canalCeLephant);
		}
	}
}
