using System;
using System.Collections;
using System.Windows.Forms;
using System.IO;
using System.Drawing;
using System.Runtime.InteropServices;

namespace eLePhant.Client
{
	/// <summary>
	/// Cache of the system icons associated to file extensions
	/// </summary>
	public class CSystemIconsList
	{
		public ImageList list;
		private Hashtable m_table;
		public CSystemIconsList()
		{
			list=new ImageList();
			m_table=new Hashtable();
		}
		public int GetIconIndexOf(string filename)
		{
			if (m_table[Path.GetExtension(filename)]!=null) return (int)m_table[Path.GetExtension(filename)];
			Win32.SHFILEINFO shinfo = new Win32.SHFILEINFO();
			IntPtr hImgSmall; //the handle to the system image list
			hImgSmall = Win32.SHGetFileInfo(filename, Win32.FILE_ATTRIBUTE_NORMAL, ref shinfo,(uint)Marshal.SizeOf(shinfo),
				Win32.SHGFI_USEFILEATTRIBUTES | Win32.SHGFI_ICON | Win32.SHGFI_SMALLICON);
			System.Drawing.Icon myIcon = System.Drawing.Icon.FromHandle(shinfo.hIcon);
			list.Images.Add(myIcon);
			m_table.Add(Path.GetExtension(filename),list.Images.Count-1);
			return list.Images.Count-1;
		}
		public Image GetIconImageOf(string filename)
		{
			int index=GetIconIndexOf(filename);
			return list.Images[index];
		}
	}
}
