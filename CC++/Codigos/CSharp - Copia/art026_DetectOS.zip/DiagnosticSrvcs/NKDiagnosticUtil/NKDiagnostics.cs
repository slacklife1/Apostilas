// Disclaimer and Copyright Information
// NKDiagnostics.cs : Implementation of NKDiagnostics class
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
//Revision History:
//	3/19/2001	Added

namespace NKDiagnosticUtility
{
    using System;
	using System.Diagnostics;

    /// <summary>
    ///    Summary description for NKDiagnostics.
    /// </summary>
    public class NKDiagnostics
    {
		/// <summary>
		/// Array storing the name of the running processes.
		/// </summary>
		private Process []	m_arrSysProcesses;
		/// <summary>
		/// Array storing the names of the modules loaded by a process.
		/// </summary>
		private String []	m_arrProcNames;
		/// <summary>
		/// Array storing unique IDs of the running processes.
		/// </summary>
		private int []		m_arrIDs;
		/// <summary>
		/// Boolean flag indicating if the class information has been
		/// initialized or not.
		/// </summary>
		private bool		m_bInitialized = false;

		/// <summary>
		/// NKDiagnostics class constructor.
		/// </summary>
        public NKDiagnostics()
        {
			// Initialize the class information.
			Init ();
        }

		/// <summary>
		/// This private method gets called by the constructor. It gets the array of the
		/// processes that are running on a machine. And then it stuffs the information in
		/// the private arrays e.g. Process IDs, names.
		/// </summary>
		private void Init ()
		{
			// Don't pass empty string for local computer. Although documentation says that
			// you can pass empty string, but it throws an exception.
			// This bug in the documentation has been confirmed by VS.Net support team.
			m_arrSysProcesses = Process.GetProcesses (".");

			int nCount = m_arrSysProcesses.Length;
			Console.WriteLine ("Number Of Processes on Machine : {0}", nCount);

			if (nCount > 0)
			{
				m_arrProcNames = new String[nCount];
				m_arrIDs = new int[nCount];
			}

			for (int i = 0; i < nCount; i++)
			{
				m_arrProcNames[i] = m_arrSysProcesses[i].ProcessName;
				m_arrIDs[i] = m_arrSysProcesses[i].Id;
				bool bResponding = m_arrSysProcesses[i].Responding;

				Console.WriteLine ("Process: {0}, ID: {1}, Responding: {2}", m_arrProcNames[i], m_arrIDs[i], bResponding);
			}

			m_bInitialized= true;
		}

	
		///<summary>
		/// Number of processes on the machine.
		/// </summary>
		public int Count
		{
			get
			{
				if (false == m_bInitialized)
				{
					throw (new Exception ("Processes array has not been initialized"));
				}
				return m_arrSysProcesses.Length;
			}
		}

		/// <summary>
		/// Array containing the names of the procedures.
		/// </summary>
		public String [] ProcNames
		{
			get
			{
				if (false == m_bInitialized)
				{
					throw (new Exception ("Processes array has not been initialized"));
				}
				return m_arrProcNames;
			}
		}

		/// <summary>
		/// Array Of Procedure IDs.
		/// </summary>
		public int [] ProcIDs
		{
			get
			{
				if (false == m_bInitialized)
				{
					throw (new Exception ("Processes array has not been initialized"));
				}
				return m_arrIDs;
			}
		}

		/// <summary>
		/// Method to return array of names of the procedures that are loaded by the
		/// process corresponding to given Process ID.
		/// </summary>
		/// <param name="nProcID"> </param>
		/// <param name="nMemSizes"> </param>
		public static String [] GetLoadedModules (int nProcID, ref int [] nMemSizes)
		{
			try
			{
				Process proc = Process.GetProcessById (nProcID);
				ProcessModule [] modules = proc.Modules;
				int nCount = modules.Length;
				Console.WriteLine ("Total Processes Loaded by Process {0} = {1}", nProcID, nCount);
				String [] strNames = null;
				if (nCount > 0)
				{
					strNames = new String[nCount];
					nMemSizes = new int[nCount];
					for (int i = 0; i < nCount; i++)
					{
						strNames[i] = modules[i].ModuleName;
						nMemSizes[i] = modules[i].ModuleMemorySize;
					}
				}
				return strNames;
			}
			catch (Exception e)
			{
				Console.WriteLine (e.Message);
				return null;
			}
		}

		/// <summary>
		/// Method returns an array containg the threads that a process is running.
		/// </summary>
		/// <param name="nProcID"> </param>
		public static ProcessThread [] GetProcessThreads (int nProcID)
		{
			try
			{
				Process proc = Process.GetProcessById (nProcID);
				ProcessThread [] threads = proc.Threads;
				return threads;
			}
			catch ( Exception e)
			{
				Console.WriteLine (e.Message);
				return null;
			}
		}

		/// <summary>
		/// Method translates thread priority level enumerator value into a String value.
		/// </summary>
		/// <param name="level">Thread priority value that needs to be translated. </param>
		public static String PriorityToString (int level)
		{
			switch (level)
			{
				case 8:
					return "Normal";
				case 13:
					return "High";
				case 24:
					return "Real Time";
				case 4:
				default:
					return "Idle";
			}
		}

		/// <summary>
		/// Method translates ThreadState enumerator value into a String value.
		/// </summary>
		/// <param name="state">ThreadState value that needs to be translated. </param>
		public static String ThreadStateToString (ThreadState state)
		{
			switch (state)
			{
				case ThreadState.Initialized:
					return "Initialized";
				case ThreadState.Ready:
					return "Ready";
				case ThreadState.Running:
					return "Running";
				case ThreadState.Standby:
					return "StandBy";
				case ThreadState.Terminated:
					return "Terminated";
				case ThreadState.Transition:
					return "Transition";
				case ThreadState.Wait:
					return "Waiting";
				case ThreadState.Unknown:
				default:
					return "Uknown";
			}
		}

		/// <summary>
		/// Method translates ThreadWaitReason enumerator value into a String value.
		/// </summary>
		/// <param name="reason">ThreadWaitReason value that needs to be translated. </param>
		public static String ThreadWaitReasonToString (ThreadWaitReason reason)
		{
			switch (reason)
			{
				case ThreadWaitReason.EventPairHigh:
					return "EventPairHigh";
				case ThreadWaitReason.EventPairLow:
					return "EventPairLow";
				case ThreadWaitReason.ExecutionDelay:
					return "Execution Delay";
				case ThreadWaitReason.Executive:
					return "Executive";
				case ThreadWaitReason.FreePage:
					return "FreePage";
				case ThreadWaitReason.LpcReceive:
					return "LPC Recieve";
				case ThreadWaitReason.LpcReply:
					return "LPC Reply";
				case ThreadWaitReason.PageIn:
					return "Page In";
				case ThreadWaitReason.PageOut:
					return "Page Out";
				case ThreadWaitReason.Suspended:
					return "Suspended";
				case ThreadWaitReason.SystemAllocation:
					return "System Allocation";
				case ThreadWaitReason.UserRequest:
					return "User Request";
				case ThreadWaitReason.VirtualMemory:
					return "Virtual Memory";
				case ThreadWaitReason.Unknown:
				default:
					return "Unknown";
					
			}
		}
    }
}
