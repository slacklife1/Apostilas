// Disclaimer and Copyright Information
// SysServices.cs : Implementation of Man Form for the application
//
// All rights reserved.
// Copyright � 2001, KohliSoft, Inc.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
///

/// Revision History:
///		3/19/2001	Created Module
///		
namespace ConsoleTesApp
{
    using System;
	using System.Diagnostics;	// required for Trace/Debug classes.
	using NKDiagnosticUtility;

    /// <summary>
    ///    Summary description for Class1.
    /// </summary>
    public class ConsoleTestApp
    {
        public ConsoleTestApp()
        {
            //
            // TODO: Add Constructor Logic here
            //
        }

        public static int Main(string[] args)
        {
			// Clear all the trace listeners.
            Trace.Listeners.Clear();

			// Add our own trace listeners to log all the messages.
			NKTraceListener myListener = new NKTraceListener ("Logfile.log", true);
			Trace.Listeners.Add(myListener);
			Trace.Write ("Starting Test Application");

			NKOSInfo osInfo = new NKOSInfo ();
			string strOS = osInfo.OS;
			string strSP = osInfo.ServicePack;
			int nMajorVer = 0;
			int nMinorVer = 0;
			int nRevision = 0;
			int nBuild = 0;
			osInfo.GetVersionInfo (ref nMajorVer, ref nMinorVer, ref nRevision, ref nBuild); 

			Trace.Write ("Operating System: " + strOS);
			Console.WriteLine ("Operating System: " + strOS);

			Trace.Write ("Service Pack: " + strSP);
			Console.WriteLine ("Service Pack: " + strSP);

			Trace.Write ("Major Version:	" + nMajorVer.ToString ());
			Trace.Write ("Minor Version:	" + nMinorVer.ToString ());
			Trace.Write ("Revision:		" + nRevision.ToString ());
			Trace.Write ("Build:		" + nBuild.ToString ());

			Console.WriteLine ("Major Version:	" + nMajorVer.ToString ());
			Console.WriteLine ("Minor Version:	" + nMinorVer.ToString ());
			Console.WriteLine ("Revision:	" + nRevision.ToString ());
			Console.WriteLine ("Build:		" + nBuild.ToString ());

			Trace.Write ("Closing Test Application");
			// Close the personal trace listener :-)
			myListener.Close ();
            return 0;
        }
    }
}
