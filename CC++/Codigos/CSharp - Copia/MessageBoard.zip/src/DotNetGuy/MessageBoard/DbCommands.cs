/////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2002 Brad Wilson
//
//  This material is provided "as is", with absolutely no warranty
//  expressed or implied. Any use is at your own risk. Permission to
//  use or copy this software for any purpose is hereby granted without
//  fee, provided the above notices are retained on all copies.
//  Permission to modify the code and to distribute modified code is
//  granted, provided the above notices are retained, and a notice that
//  the code was modified is included with the above copyright notice.
//
/////////////////////////////////////////////////////////////////////////////

#define TRACE

using System;
using System.Collections;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;

namespace DotNetGuy.MessageBoard
{
   /// <summary>This class isolates all the database access. This would allow
   /// one to change just these functions, and change the layout of the backend
   /// database, along with implementation details like whether you employ
   /// stored procedures.</summary>
   internal class _DbCommands
   {
      static public string _SqlEscape( string input )
      {
         return input.Replace( "'", "''" );
      }

      static private string _sqlGetTopics =
            "select {0} * from mbTopics order by CreateDate {1}";

      static internal ArrayList _GetTopics( OleDbConnection conn,
            MessageBoard parent, SortOrder so, int maxRecords )
      {
         //  Need a string to represent the maximum # of records

         string topString;

         if( maxRecords < 1 )
            topString = "";
         else
            topString = String.Format( "top {0}", maxRecords );

         //  Construct the SQL query and execute

         string sql = String.Format( _sqlGetTopics, topString,
               so == SortOrder.NewestFirst ? "desc" : "" );

         Trace.WriteLine( "_GetTopics SQL=" + sql );
         Trace.Flush();

         DataSet ds = new DataSet();
         OleDbCommand cmd = new OleDbCommand( sql, conn );

         using( OleDbDataAdapter adapt = new OleDbDataAdapter( cmd ))
         {
            adapt.Fill( ds );
         }

         //  Create each individual topic into a Topic object and add
         //  it to our array

         ArrayList retVal = new ArrayList();

         foreach( DataRow row in ds.Tables[0].Rows )
         {
            Topic topic = new Topic( parent );

            topic._topicKey   = Int32.Parse( row[ "TopicKey" ].ToString());
            topic._topicID    = row[ "TopicID" ].ToString();
            topic._subject    = row[ "Subject" ].ToString();
            topic._name       = row[ "Name" ].ToString();
            topic._email      = row[ "Email" ].ToString();
            topic._message    = row[ "Message" ].ToString();
            topic._createDate = (DateTime)( row[ "CreateDate" ]);

            retVal.Add( topic );
         }

         return retVal;
      }

      static private string _sqlGetTopic1 =
            "select * from mbTopics where TopicKey={0}";

      static internal Topic _GetTopic( OleDbConnection conn,
            MessageBoard parent, int topicKey )
      {
         //  Construct the SQL query and execute

         string sql = String.Format( _sqlGetTopic1, topicKey );

         Trace.WriteLine( "_GetTopic SQL=" + sql );
         Trace.Flush();

         DataSet ds = new DataSet();
         OleDbCommand cmd = new OleDbCommand( sql, conn );

         using( OleDbDataAdapter adapt = new OleDbDataAdapter( cmd ))
         {
            adapt.Fill( ds );
         }

         //  Did we find an object with this key?

         DataRowCollection rows = ds.Tables[0].Rows;

         if( rows.Count == 0 )
            return null;

         //  Fill the topic object

         DataRow row = ds.Tables[0].Rows[0];
         Topic topic = new Topic( parent );

         topic._topicKey   = Int32.Parse( row[ "TopicKey" ].ToString());
         topic._topicID    = row[ "TopicID" ].ToString();
         topic._subject    = row[ "Subject" ].ToString();
         topic._name       = row[ "Name" ].ToString();
         topic._email      = row[ "Email" ].ToString();
         topic._message    = row[ "Message" ].ToString();
         topic._createDate = (DateTime)( row[ "CreateDate" ]);

         return topic;
      }

      static private string _sqlGetTopic2 =
            "select * from mbTopics where TopicID='{0}'";

      static internal Topic _GetTopic( OleDbConnection conn,
            MessageBoard parent, string topicID )
      {
         //  Construct the SQL query and execute

         string sql = String.Format( _sqlGetTopic2, _SqlEscape( topicID ));

         Trace.WriteLine( "_GetTopic SQL=" + sql );
         Trace.Flush();

         DataSet ds = new DataSet();
         OleDbCommand cmd = new OleDbCommand( sql, conn );

         using( OleDbDataAdapter adapt = new OleDbDataAdapter( cmd ))
         {
            adapt.Fill( ds );
         }

         //  Did we find an object with this ID?

         DataRowCollection rows = ds.Tables[0].Rows;

         if( rows.Count == 0 )
            return null;

         //  Fill the topic object

         DataRow row = ds.Tables[0].Rows[0];
         Topic topic = new Topic( parent );

         topic._topicKey   = Int32.Parse( row[ "TopicKey" ].ToString());
         topic._topicID    = row[ "TopicID" ].ToString();
         topic._subject    = row[ "Subject" ].ToString();
         topic._name       = row[ "Name" ].ToString();
         topic._email      = row[ "Email" ].ToString();
         topic._message    = row[ "Message" ].ToString();
         topic._createDate = (DateTime)( row[ "CreateDate" ]);

         return topic;
      }

      static internal ArrayList _SearchTopics( OleDbConnection conn,
            MessageBoard parent, string searchCriteria, SortOrder so )
      {
         //  Not implemented
         return null;
      }

      static private string _sqlCountPostsInTopic =
            "select count(*) from mbPosts where ParentTopicKey={0}";

      static internal int _CountPostsInTopic( OleDbConnection conn,
            int topicKey )
      {
         int retVal = 0;

         // Get a count of the posts for this topic

         string sql = String.Format( _sqlCountPostsInTopic, topicKey );

         Trace.WriteLine( "_CountPostsInTopic SQL=" + sql );
         Trace.Flush();

         OleDbCommand cmd = new OleDbCommand( sql, conn );

         // We're doing something really quickly, so no need to bother
         // with a DataSet

         using( OleDbDataReader reader = cmd.ExecuteReader())
         {
            if( reader.Read())
            {
               retVal = reader.GetInt32(0);
            }
         }

         return retVal;
      }

      static private string _sqlGetPostsInTopic =
            "select * from mbPosts where ParentTopicKey={0} " +
            "order by CreateDate {1}";

      static internal ArrayList _GetPostsInTopic( OleDbConnection conn,
            Topic parent, SortOrder so )
      {
         //  Get all the posts for the topic

         string sql = String.Format( _sqlGetPostsInTopic, parent._topicKey,
               so == SortOrder.NewestFirst ? "desc" : "" );

         Trace.WriteLine( "_GetPostsInTopic SQL=" + sql );
         Trace.Flush();

         OleDbCommand cmd = new OleDbCommand( sql, conn );
         DataSet ds = new DataSet();

         //  Fill all the posts into a DataSet

         using( OleDbDataAdapter adapt = new OleDbDataAdapter( cmd ))
         {
            adapt.Fill( ds );
         }

         //  Create each individual post into a Post object and add
         //  it to our array

         ArrayList retVal = new ArrayList();

         foreach( DataRow row in ds.Tables[0].Rows )
         {
            Post post = new Post( parent, parent.parent );

            post._postKey    = Int32.Parse( row[ "PostKey" ].ToString());
            post._name       = row[ "Name" ].ToString();
            post._email      = row[ "Email" ].ToString();
            post._message    = row[ "Message" ].ToString();
            post._createDate = (DateTime)( row[ "CreateDate" ]);

            retVal.Add( post );
         }

         return retVal;
      }

      static private string _sqlCommitTopic1 =
            "insert into mbTopics " +
            "(TopicID, Subject, Name, Email, Message, CreateDate) " +
            "values ('{1}', '{2}', '{3}', '{4}', '{5}', '{6}')";

      static private string _sqlCommitTopic2 =
            "update mbTopics set Subject='{2}', Name='{3}', Email='{4}', " +
            "Message='{5}' where TopicKey={0}";

      static internal bool _CommitTopic( OleDbConnection conn, Topic topic )
      {
         //  Figure out whether we're inserting or updating

         string cmdTemplate;

         if( topic.topicKey < 0 )
            cmdTemplate = _sqlCommitTopic1;
         else
            cmdTemplate = _sqlCommitTopic2;

         //  Create the command and execute it

         string sql = String.Format( cmdTemplate, topic.topicKey,
               _SqlEscape( topic.topicID ), _SqlEscape( topic.subject ),
               _SqlEscape( topic.name ), _SqlEscape( topic.email ),
               _SqlEscape( topic.message ),
               topic.createDate.ToString( "yyyy/MM/dd HH:mm:ss" ));

         Trace.WriteLine( "_CommitTopic SQL=" + sql );
         Trace.Flush();

         new OleDbCommand( sql, conn ).ExecuteNonQuery();
         return true;
      }

      static private string _sqlCommitPost1 =
            "insert into mbPosts " +
            "(ParentTopicKey, Name, Email, Message, CreateDate) " +
            "values ('{1}', '{2}', '{3}', '{4}', '{5}')";

      static private string _sqlCommitPost2 =
            "update mbTopics set Name='{2}', Email='{3}', Message='{4}' " +
            "where PostKey={0}";

      static internal bool _CommitPost( OleDbConnection conn, Post post )
      {
         //  Figure out whether we're inserting or updating

         string cmdTemplate;

         if( post.postKey < 0 )
            cmdTemplate = _sqlCommitPost1;
         else
            cmdTemplate = _sqlCommitPost2;

         //  Create the command and execute it

         string sql = String.Format( cmdTemplate, post.postKey,
               post.parent.topicKey, _SqlEscape( post.name ),
               _SqlEscape( post.email ), _SqlEscape( post.message ),
               post.createDate.ToString( "yyyy/MM/dd HH:mm:ss" ));

         Trace.WriteLine( "_CommitPost SQL=" + sql );
         Trace.Flush();

         new OleDbCommand( sql, conn ).ExecuteNonQuery();
         return true;
      }

      static private string _sqlDeleteTopic1 =
            "delete from mbTopics where TopicKey={0}";

      static internal bool _DeleteTopic( OleDbConnection conn, int topicKey )
      {
         string sql = String.Format( _sqlDeleteTopic1, topicKey );

         Trace.WriteLine( "_DeleteTopic SQL=" + sql );
         Trace.Flush();

         new OleDbCommand( sql, conn ).ExecuteNonQuery();
         return true;
      }

      static private string _sqlDeleteTopic2 =
            "delete from mbTopics where TopicID='{0}'";

      static internal bool _DeleteTopic( OleDbConnection conn, string topicID )
      {
         string sql = String.Format( _sqlDeleteTopic2, _SqlEscape( topicID ));

         Trace.WriteLine( "_DeleteTopic SQL=" + sql );
         Trace.Flush();

         new OleDbCommand( sql, conn ).ExecuteNonQuery();
         return true;
      }

      static private string _sqlDeletePost =
            "delete from mbPosts where PostKey={0}";

      static internal bool _DeletePost( OleDbConnection conn, int postKey )
      {
         string sql = String.Format( _sqlDeletePost, postKey );

         Trace.WriteLine( "_DeletePost SQL=" + sql );
         Trace.Flush();

         new OleDbCommand( sql, conn ).ExecuteNonQuery();
         return true;
      }
   }
}
