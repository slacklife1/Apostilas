/////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 1995-2002 Brad Wilson
//
//  This material is provided "as is", with absolutely no warranty
//  expressed or implied. Any use is at your own risk. Permission to
//  use or copy this software for any purpose is hereby granted without
//  fee, provided the above notices are retained on all copies.
//  Permission to modify the code and to distribute modified code is
//  granted, provided the above notices are retained, and a notice that
//  the code was modified is included with the above copyright notice.
//
/////////////////////////////////////////////////////////////////////////////

using System;
using System.Data;
using System.Data.OleDb;

namespace DotNetGuy.MessageBoard
{
   /// <summary>Represents a single post for a given topic in the message
   /// base</summary>
   public class Post
   {
      /// <summary>The parent object of this object</summary>
      public Topic parent
      {
         get { return _parent; }
      }

      /// <summary>The identity key for this post (-1 if it's a new
      /// post)</summary>
      public int postKey
      {
         get { return _postKey; }
      }

      /// <summary>The name of the person who wrote this post</summary>
      public string name
      {
         get { return _name; }
         set { _name = value; }
      }

      /// <summary>The e-mail address of the person who wrote this
      /// post</summary>
      public string email
      {
         get { return _email; }
         set { _email = value; }
      }

      /// <summary>The body of the post message</summary>
      public string message
      {
         get { return _message; }
         set { _message = value; }
      }

      /// <summary>The date and time the post was created</summary>
      public DateTime createDate
      {
         get { return _createDate; }
      }

      /// <summary>Commits the changes to the post object to the
      /// database, and destroys the object (if successful)</summary>
      /// <returns>Returns true if the commit was successful</returns>
      public bool CommitAndDispose()
      {
         bool retVal = _DbCommands._CommitPost( _grandparent._conn, this );

         if( retVal )
         {
            _parent      = null;
            _grandparent = null;
            _postKey     = -1;
            _name        = null;
            _email       = null;
            _message     = null;
            _createDate  = DateTime.Now;
         }

         return retVal;
      }

      // Implementation
      internal int          _postKey;
      internal string       _name;
      internal string       _email;
      internal string       _message;
      internal  DateTime     _createDate;
      internal MessageBoard _grandparent;
      internal Topic        _parent;

      internal Post( Topic parent, MessageBoard grandparent, int postKey,
            string name, string email, string message, DateTime createDate )
      {
         _postKey     = postKey;
         _name        = name;
         _email       = email;
         _message     = message;
         _createDate  = createDate;
         _parent      = parent;
         _grandparent = grandparent;
      }

      internal Post( Topic parent, MessageBoard grandparent )
      {
         _parent      = parent;
         _grandparent = grandparent;
         _postKey     = -1;
      }
   }
}
