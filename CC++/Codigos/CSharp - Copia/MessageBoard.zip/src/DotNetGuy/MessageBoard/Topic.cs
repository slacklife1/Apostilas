/////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 1995-2002 Brad Wilson
//
//  This material is provided "as is", with absolutely no warranty
//  expressed or implied. Any use is at your own risk. Permission to
//  use or copy this software for any purpose is hereby granted without
//  fee, provided the above notices are retained on all copies.
//  Permission to modify the code and to distribute modified code is
//  granted, provided the above notices are retained, and a notice that
//  the code was modified is included with the above copyright notice.
//
/////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections;
using System.Data;
using System.Data.OleDb;

namespace DotNetGuy.MessageBoard
{
   /// <summary>Represents a single topic in the message board</summary>
   public class Topic
   {
      /// <summary>Commits the changes to the topic object to the
      /// database, and destroys the object (when successful)</summary>
      /// <returns>Returns true if the commit was successful</returns>
      public bool CommitAndDispose()
      {
         bool retVal = _DbCommands._CommitTopic( parent._conn, this );

         if( retVal )
         {
            _parent     = null;
            _topicKey   = -1;
            _topicID    = null;
            _subject    = null;
            _name       = null;
            _email      = null;
            _message    = null;
            _createDate = DateTime.Now;
         }

         return retVal;
      }

      /// <summary>The parent object of this object</summary>
      public MessageBoard parent
      {
         get { return _parent; }
      }

      /// <summary>The topic ID</summary>
      public string topicID
      {
         get { return String.Copy( _topicID ); }
      }

      /// <summary>The topic key</summary>
      public int topicKey
      {
         get { return _topicKey; }
      }

      /// <summary>The subject of the topic</summary>
      public string subject
      {
         get { return _subject; }
         set { _subject = value; }
      }

      /// <summary>The name of the person who started the topic</summary>
      public string name
      {
         get { return _name; }
         set { _name = value; }
      }

      /// <summary>The e-mail address of the person who posted the
      /// topic</summary>
      public string email
      {
         get { return _email; }
         set { _email = value; }
      }

      /// <summary>The body of the topic message</summary>
      public string message
      {
         get { return _message; }
         set { _message = value; }
      }

      /// <summary>The date and time the topic was created</summary>
      public DateTime createDate
      {
         get { return _createDate; }
      }

      /// <summary>Returns the number of posts for this topic</summary>
      public int ReplyNumPosts()
      {
         return _DbCommands._CountPostsInTopic( _parent._conn, _topicKey );
      }

      /// <summary>Returns the posts for this topic</summary>
      public ArrayList ReplyPosts( SortOrder so )
      {
         return _DbCommands._GetPostsInTopic( _parent._conn, this, so );
      }

      /// <summary>Creates a new populated post</summary>
      public Post ReplyNewPost( string name, string email, string message )
      {
         return new Post( this, _parent, -1, name, email, message,
               DateTime.Now );
      }

      /// <summary>Creates a new empty post</summary>
      public Post ReplyNewPost()
      {
         return new Post( this, _parent );
      }

      // Implementation
      internal MessageBoard _parent;
      internal int          _topicKey;
      internal string       _topicID;
      internal string       _subject;
      internal string       _name;
      internal string       _email;
      internal string       _message;
      internal DateTime     _createDate;

      internal Topic( MessageBoard parent, int topicKey, string topicID,
            string subject, string name, string email, string message,
            DateTime createDate )
      {
         _parent     = parent;
         _topicKey   = topicKey;
         _topicID    = topicID;
         _subject    = subject;
         _name       = name;
         _email      = email;
         _message    = message;
         _createDate = createDate;
      }

      internal Topic( MessageBoard parent )
      {
         _parent = parent;
      }
   }
}
