/////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2002 Brad Wilson
//
//  This material is provided "as is", with absolutely no warranty
//  expressed or implied. Any use is at your own risk. Permission to
//  use or copy this software for any purpose is hereby granted without
//  fee, provided the above notices are retained on all copies.
//  Permission to modify the code and to distribute modified code is
//  granted, provided the above notices are retained, and a notice that
//  the code was modified is included with the above copyright notice.
//
/////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections;
using System.Data;
using System.Data.OleDb;

namespace DotNetGuy.MessageBoard
{
   /// <summary>Main Message Board class</summary>
   public class MessageBoard
   {
      /// <summary>Constructor</summary>
      /// <param name="conn">OLE DB connection to the message board
      /// database</param>
      public MessageBoard( OleDbConnection conn )
      {
         _conn = conn;
      }

      /// <summary>Returns all the topics in the system</summary>
      /// <param name="so">The sort order</param>
      /// <returns>An ArrayList of Topic objects</returns>
      public ArrayList ReplyTopics( SortOrder so )
      {
         return _DbCommands._GetTopics( _conn, this, so, -1 );
      }

      /// <summary>Returns the first N topics in the system</summary>
      /// <param name="maxTopics">The maximum number of topics to return</param>
      /// <param name="so">The sort order</param>
      /// <returns>An ArrayList of Topic objects</returns>
      public ArrayList ReplyTopics( int maxTopics, SortOrder so )
      {
         return _DbCommands._GetTopics( _conn, this, so, maxTopics );
      }

      /// <summary>Searches for topics that match the string</summary>
      /// <param name="searchCriteria">The search string</param>
      /// <param name="so">The sort order</param>
      /// <returns>An ArrayList of Topic objects</returns>
      public ArrayList ReplyTopicsSearch( string searchCriteria,
            SortOrder so )
      {
         return _DbCommands._SearchTopics( _conn, this, searchCriteria, so );
      }

      /// <summary>Loads a topic based on its topic key. Can optionally
      /// create the topic automatically, if it does not exist.</summary>
      /// <param name="key">The topic key to load/create</param>
      /// <returns>The Topic object</returns>
      public Topic ReplyTopic( int key )
      {
         return _DbCommands._GetTopic( _conn, this, key );
      }

      /// <summary>Loads a topic based on its topic ID. Can optionally
      /// create the topic automatically, if it does not exist.</summary>
      /// <param name="id">The topic ID to load/create</param>
      /// <returns>The Topic object</returns>
      public Topic ReplyTopic( string id )
      {
         return _DbCommands._GetTopic( _conn, this, id );
      }

      /// <summary>Creates a new topic object</summary>
      /// <param name="topicId">The topic ID (may be null if you want a
      /// topic ID to be automatically assigned)</param>
      /// <param name="subject">The subject (title) of the topic</param>
      /// <param name="name">The topic poster's name</param>
      /// <param name="email">The topic poster's e-mail address</param>
      /// <param name="message">The body of the topic message</param>
      /// <returns>A populated Topic object. The object has not been added
      /// to the database yet; to add it, call Topic.Commit().</returns>
      public Topic ReplyNewTopic( string topicId, string subject, string name,
            string email, string message )
      {
         return new Topic( this, -1, topicId, subject, name, email,
               message, DateTime.Now );
      }

      /// <summary>Creates a new topic object</summary>
      /// <param name="subject">The subject (title) of the topic</param>
      /// <param name="name">The topic poster's name</param>
      /// <param name="email">The topic poster's e-mail address</param>
      /// <param name="message">The body of the topic message</param>
      /// <returns>A populated Topic object. The object has not been added
      /// to the database yet; to add it, call Topic.Commit().</returns>
      public Topic ReplyNewTopic( string subject, string name, string email,
            string message )
      {
         return new Topic( this, -1, Guid.NewGuid().ToString(), subject, name,
               email, message, DateTime.Now );
      }

      /// <summary>Creates a new topic object</summary>
      /// <param name="topicId">The topic ID (may be null if you want a
      /// topic ID to be automatically assigned)</param>
      /// <returns>A populated Topic object. The object has not been added
      /// to the database yet; to add it, call Topic.Commit().</returns>
      public Topic ReplyNewTopic( string topicId )
      {
         return new Topic( this, -1, topicId, null, null, null, null,
               DateTime.Now );
      }

      /// <summary>Creates a new topic object</summary>
      /// <returns>A populated Topic object. The object has not been added
      /// to the database yet; to add it, call Topic.Commit().</returns>
      public Topic ReplyNewTopic()
      {
         return new Topic( this, -1, Guid.NewGuid().ToString(), null, null,
               null, null, DateTime.Now );
      }

      /// <summary>Deletes a topic and all its posts from the database</summary>
      /// <param name="topic">The topic object to delete</param>
      /// <returns>Returns true if the delete was successful</returns>
      public bool DeleteTopic( Topic topic )
      {
         return _DbCommands._DeleteTopic( _conn, topic._topicKey );
      }

      /// <summary>Deletes a topic and all its posts from the database</summary>
      /// <param name="topicKey">The topic key to delete</param>
      /// <returns>Returns true if the delete was successful</returns>
      public bool DeleteTopic( int topicKey )
      {
         return _DbCommands._DeleteTopic( _conn, topicKey );
      }

      /// <summary>Deletes a topic and all its posts from the database</summary>
      /// <param name="topicID">The topic ID to delete</param>
      /// <returns>Returns true if the delete was successful</returns>
      public bool DeleteTopic( string topicID )
      {
         return _DbCommands._DeleteTopic( _conn, topicID );
      }

      /// <summary>Deletes a post from the database</summary>
      /// <param name="post">The post object to delete</param>
      /// <returns>Returns true if the delete was successful</returns>
      public bool DeletePost( Post post )
      {
         return _DbCommands._DeletePost( _conn, post._postKey );
      }

      /// <summary>Deletes a post from the database</summary>
      /// <param name="postKey">The post key to delete</param>
      /// <returns>Returns true if the delete was successful</returns>
      public bool DeletePost( int postKey )
      {
         return _DbCommands._DeletePost( _conn, postKey );
      }

      // Implementation
      internal OleDbConnection _conn;
   }
}
