/////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2002 Brad Wilson
//
//  This material is provided "as is", with absolutely no warranty
//  expressed or implied. Any use is at your own risk. Permission to
//  use or copy this software for any purpose is hereby granted without
//  fee, provided the above notices are retained on all copies.
//  Permission to modify the code and to distribute modified code is
//  granted, provided the above notices are retained, and a notice that
//  the code was modified is included with the above copyright notice.
//
/////////////////////////////////////////////////////////////////////////////

using System;

namespace DotNetGuy.MessageBoard
{
   /// <summary>Sort orders for returning lists of topics/posts</summary>
   public enum SortOrder
   {
      /// <summary>Sorts by date, with the newest item first</summary>
      NewestFirst,

      /// <summary>Sorts by date, with the oldest item first</summary>
      OldestFirst,
   }
}
