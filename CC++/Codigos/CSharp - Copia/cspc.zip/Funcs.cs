﻿using System;
using System.Collections;
using System.IO;
using CSPCUtil;
using System.Drawing;
using System.Text;

namespace NS
{
  public class Functions
  {
    private static Object[] globals = new Object[1024];

    public Functions()
    {
    }

    /*
     * Memo-ized version of Fibonacci number calculation, avoids
     * redundant calculations.
     */

    private static long CalcFib(int x, long[] memo)
    {
      long result;

      if (x == 1 || x == 2)
      {
        result = 1;
      }
      else
      {
        if (memo[x - 2] == 0)
        {
          memo[x - 2] = CalcFib(x - 2, memo);
        }

        if (memo[x - 1] == 0)
        {
          memo[x - 1] = CalcFib(x - 1, memo);
        }

          result = memo[x - 2] + memo[x - 1];
      }

      return result;
    }

    public static long Fib(int x)
    {
      return CalcFib(x, new long[x]);
    }

    public static double Sin(double x)
    {
      return Math.Sin(x);
    }
    
    public static double Cos(double x)
    {
      return Math.Cos(x);
    }
    
    public static long Factorial(int n)
    
    // Calculates n! using a recursive algorithm.
    
    {
      long result = 1;

      // By default, C# code will not throw
      // exceptions when overflows happen.  To
      // ensure that an exception is thrown when
      // overflows occur, enclose the code in a 
      // checked block.

      checked
      {
        if (n > 1)
        {
          result = n * Factorial(n - 1);
        }
      }
    
      return result;
    }

 }
}